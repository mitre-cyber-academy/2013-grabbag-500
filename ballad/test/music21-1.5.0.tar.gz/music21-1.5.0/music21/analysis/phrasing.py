# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:         analysis/phrasing.py
# Purpose:      
#
# Authors:      Dylan Nagler
#               Michael Scott Cuthbert
#
# Copyright:    Copyright � 2012 Michael Scott Cuthbert and the music21 Project
# License:      LGPL, see license.txt
#-------------------------------------------------------------------------------


# Group elements that are beamed together...

# Group elements within integer .beat property.



#### Not in here but in stream, but put it here for now:
#  emptyStream = copyStreamHierarchy(streamIn)
#  

