# -*- coding: utf-8 -*-

'''
converter routines from Music21 to Abjad (see translate.py) -- 
called 'abj' to avoid namespace conflicts with the 'abjad'
package
'''

from translate import *
