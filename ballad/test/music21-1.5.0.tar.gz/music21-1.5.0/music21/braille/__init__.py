# -*- coding: utf-8 -*-

__all__ = ['basic',
           'examples',
           'lookup',
           'segment',
           'test',
           'text',
           'translate']
           
import basic
import examples
import lookup
import segment
import test
import text
import translate

#------------------------------------------------------------------------------
# eof