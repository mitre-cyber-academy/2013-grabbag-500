#!/usr/bin/python
#-------------------------------------------------------------------------------
# Name:         corpus/metadataCache__init__.py
# Purpose:      Stored metadata
#
# Authors:      Christopher Ariza
#
# Copyright:    (c) 2010 The music21 Project
# License:      LGPL
#-------------------------------------------------------------------------------
