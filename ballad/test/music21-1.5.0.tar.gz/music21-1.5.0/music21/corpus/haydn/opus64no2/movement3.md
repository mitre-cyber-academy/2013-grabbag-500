&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/03/01} [KHM:3475307147]
TIMESTAMP: DEC/26/2001 [md5sum:10d352e0ff13b841430afec56f0ed797]
11/21/94 W Hewlett
WK#:64,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Menuetto
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:2   T:3/4  C:4  D:Allegretto
F#4    2        q     u
measure 1
B4     2        q     d
C#5    2        q     d
D5     2        q     d
measure 2
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 3
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 4
F#5    2        q     d
F#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
C#5    1        e     d  ]
measure 5
B4     2        q     d
rest   2        q
D5     2        q     d
measure 6
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 7
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 8
D5     2        q     d
D5     1        e     d  [
E5     1        e     d  =
F#5    1        e     d  =
G5     1        e     d  ]
measure 9
A5     2        q     d
A5     2        q     d
A5     2        q     d
measure 10
A5     2        q     d
A5     2        q     d
A5     2        q     d
measure 11
A5     1        e     d  [
A5     1        e     d  =
A5     1        e     d  =
A5     1        e     d  =
A5     1        e     d  =
A5     1        e     d  ]
measure 12
A5     1        e     d  [
B5     1        e     d  =
C#6    1        e     d  =
D6     1        e     d  =
E6     1        e     d  =
F#6    1        e     d  ]
measure 13
G6     2        q     d
E6     2        q     d
C#6    2        q     d
measure 14
D6     2        q     d
rest   2        q
mheavy4                  :|:
B3     2        q     u
measure 15
C4     2        q n   u
A3     2        q     u
A3     2        q     u
measure 16
B3     2        q     u
G3     2        q     u
B4     2        q     d
measure 17
C5     2        q n   d
C5     1        e     d  [
B4     1        e     d  ]
C5     2        q     d
measure 18
B4     2        q     d
rest   2        q
B4     2        q     d
measure 19
D5     2        q     d
D5     1        e     d  [
C#5    1        e     d  ]
D5     2        q     d
measure 20
C#5    2        q     d
rest   2        q
C#5    2        q     d
measure 21
C#5    4        h     d
D5     2        q     d
measure 22
C#5    2        q     d
rest   2        q
F#5    2        q     d
measure 23
G5     2        q     d
rest   2        q
E#5    2        q #   d
measure 24
F#5    2        q     d
rest   2        q
C#5    2        q     d
measure 25
D5     2        q     d
rest   2        q
E#4    2        q #   u
measure 26
F#4    2        q     u
rest   2        q
F#4    2        q     u
measure 27
B4     2        q     d
C#5    2        q     d
D5     2        q     d
measure 28
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 29
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 30
F#5    2        q     d
F#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
C#5    1        e     d  ]
measure 31
B5     2        q     d
B5     1        e     d  [
A5     1        e     d  =
G5     1        e     d  =
F#5    1        e     d  ]
measure 32
E6     2        q     d
E6     1        e     d  [
D6     1        e     d  =
C#6    1        e     d  =
B5     1        e     d  ]
measure 33
A#5    2        q #   d
rest   2        q
rest   2        q
measure 34
rest   6
measure 35
rest   6
measure 36
rest   6
measure 37
A#4    1        e #   u  [
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  ]
measure 38
A#4    1        e #   u  [
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  ]
measure 39
A#4    1        e #   u  [
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  =
A#4    1        e     u  ]
measure 40
B4     1        e     d  [
C#5    1        e     d  =
D5     1        e     d  =
E5     1        e     d  =
F#5    1        e     d  =
G5     1        e     d  ]
measure 41
F#5    1        e     d  [
G5     1        e     d  =
F#5    1        e     d  =
E5     1        e     d  =
D5     1        e     d  =
C#5    1        e     d  ]
measure 42
B4     2        q     d
rest   2        q
mheavy4                  :|:
$   K:5   T:3/4    D:Trio
F#5    2        q     d
measure 43
B5     4        h     d
D#6    2        q #   d
measure 44
C#6    4        h     d
G#6    2        q #   d
measure 45
F#6    4        h     d
E6     2        q     d
measure 46
D#6    2        q #   d
rest   2        q
D#6    2        q     d
measure 47
C#6    4        h     d
B5     2        q     d
measure 48
A#5    2        q #   d
B5     2        q     d
B#5    2        q #   d
measure 49
C#6    4        h     d
B5     1        e     d  [
G#5    1        e #   d  ]
measure 50
F#5    2        q     d
rest   2        q
mheavy4                  :|:
F#5    2        q     d
measure 51
F#6    4        h     d
D#6    1        e #   d  [
B#5    1        e #   d  ]
measure 52
C#6    2        q     d
E6     1        e     d  [
C#6    1        e     d  ]
A#5    2        q #   d
measure 53
B5     2        q     d
D#6    1        e #   d  [
B5     1        e     d  =
G#5    1        e #   d  =
E#5    1        e #   d  ]
measure 54
F#5    2        q     d
rest   2        q
F#5    2        q     d
measure 55
B5     4        h     d
D#6    2        q #   d
measure 56
C#6    4        h     d
G#6    2        q #   d
measure 57
F#6    4        h     d
E6     2        q     d
measure 58
D#6    4        h #   d
F#6    2        q     d
measure 59
B6     4        h     d
F#6    2        q     d
measure 60
G#6    4        h #   d
E6     1        e     d  [
C#6    1        e     d  ]
measure 61
B5     4        h     d
C#6    2        q     d
measure 62
B5     2        q     d
rest   2        q
mheavy2                          :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/03/02} [KHM:3475307147]
TIMESTAMP: DEC/26/2001 [md5sum:0c7b5e6a8a6a51e744f4a63db136753b]
11/21/94 W Hewlett
WK#:64,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Menuetto
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:2   T:3/4  C:4  D:Allegretto
rest   2        q
measure 1
F#4    2        q     u
E4     2        q     u
D4     2        q     u
measure 2
G4     2        q     u
rest   2        q
G4     2        q     u
measure 3
G4     2        q     u
rest   2        q
G4     2        q     u
measure 4
E4     4        h     u
 A#3   4        h #   u
E4     2        q     u
 A#3   2        q     u
measure 5
D4     2        q     u
 B3    2        q     u
rest   2        q
F#4    2        q     u
measure 6
G4     2        q     u
rest   2        q
G4     2        q     u
measure 7
G4     2        q     u
rest   2        q
G4     2        q     u
measure 8
F#4    2        q     u
rest   2        q
D5     2        q     d
measure 9
G5     2        q     d
G5     1        e     d  [
F#5    1        e     d  ]
G5     2        q     d
measure 10
F#5    2        q     d
F#5    2        q     d
D5     2        q     d
measure 11
C#5    2        q     d
C#5    1        e     d  [
B4     1        e     d  ]
C#5    2        q     d
measure 12
D5     2        q     d
rest   2        q
rest   2        q
measure 13
B4     2        q     d
G4     2        q     u
E4     2        q     u
measure 14
F#4    2        q     u
rest   2        q
mheavy4                  :|:
rest   2        q
measure 15
rest   6
measure 16
rest   6
measure 17
rest   4        h
F#4    2        q     u
measure 18
A4     2        q     u
A4     1        e     u  [
G#4    1        e #   u  ]
A4     2        q     u
measure 19
G#4    2        q #   u
rest   2        q
G#4    2        q     u
measure 20
B4     2        q     d
B4     1        e     u  [
A#4    1        e #   u  ]
B4     2        q     d
measure 21
A#4    4        h #   u
B4     2        q     d
measure 22
A#4    2        q #   u
rest   2        q
A#4    2        q     u
measure 23
B4     2        q     d
rest   2        q
B4     2        q     d
measure 24
A#4    2        q #   u
rest   2        q
A#4    2        q     u
measure 25
B4     2        q     d
rest   2        q
B3     2        q     u
measure 26
A#3    2        q #   u
rest   2        q
rest   2        q
measure 27
F#4    2        q     u
E4     2        q     u
D4     2        q     u
measure 28
G4     2        q     u
rest   2        q
G4     2        q     u
measure 29
G4     2        q     u
rest   2        q
G4     2        q     u
measure 30
E4     4        h #   u
 A#3   4        h     u
E4     2        q     u
 A#3   2        q     u
measure 31
D4     4        h     u
 B3    4        h     u
D4     2        q     u
 B3    2        q     u
measure 32
C#4    4        h     u
C#4    2        q     u
measure 33
C#4    2        q     u
rest   2        q
rest   2        q
measure 34
rest   4        h
B3     2        q     u
measure 35
C4     2        q n   u
C4     1        e     u  [
B3     1        e     u  ]
C4     2        q     u
measure 36
C4     2        q n   u
C4     1        e     u  [
B3     1        e     u  ]
C4     2        q     u
measure 37
C4     2        q n   u
C4     1        e     u  [
B3     1        e     u  ]
C4     2        q     u
measure 38
C4     2        q n   u
C4     1        e     u  [
B3     1        e     u  ]
C4     2        q     u
measure 39
D4     2        q     u
D4     1        e     u  [
C#4    1        e     u  ]
D4     2        q     u
measure 40
D4     2        q     u
rest   2        q
D4     2        q     u
measure 41
C#4    2        q     u
rest   2        q
C#4    2        q     u
measure 42
D4     2        q     u
rest   2        q
mheavy4                  :|:
$   K:5   T:3/4    D:Trio
rest   2        q
measure 43
F#4    2        q     u
D#4    2        q #   u
B3     2        q     u
measure 44
G#4    2        q #   u
E4     2        q     u
C#4    2        q     u
measure 45
A#4    2        q #   u
F#4    2        q     u
C#4    2        q     u
measure 46
B4     2        q     d
F#4    2        q     u
D#4    2        q #   u
measure 47
F#4    2        q     u
A#4    2        q #   u
G#4    2        q #   u
measure 48
F#4    6-       h.    u        -
measure 49
F#4    2        q     u
E#4    2        q #   u
E#4    2        q     u
measure 50
F#4    2        q     u
rest   2        q
mheavy4                  :|:
rest   2        q
measure 51
D#4    4        h #   u
A4     2        q     u
measure 52
G#4    4        h #   u
G4     2        q n   u
measure 53
F#4    4        h     u
D4     2        q     u
measure 54
C#4    2        q     u
rest   2        q
rest   2        q
measure 55
F#4    2        q     u
D#4    2        q #   u
B3     2        q     u
measure 56
G#4    2        q #   u
E4     2        q     u
C#4    2        q     u
measure 57
A#4    2        q #   u
F#4    2        q     u
C#4    2        q     u
measure 58
B4     2        q     d
F#4    2        q     u
D#4    2        q #   u
measure 59
F#4    2        q     u
B4     2        q     d
D#5    2        q #   d
measure 60
G#4    2        q #   u
C#5    2        q     d
E5     2        q     d
measure 61
D#5    2        q #   d
B4     2        q     d
A#4    2        q #   u
measure 62
B4     2        q     d
rest   2        q
mheavy2                          :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/03/03} [KHM:3475307147]
TIMESTAMP: DEC/26/2001 [md5sum:7d1e0f3780eb762aaa3a93cd5dfada04]
11/21/94 W Hewlett
WK#:64,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Menuetto
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:2   T:3/4  C:13  D:Allegretto
rest   2        q
measure 1
D4     2        q     d
C#4    2        q     d
B3     2        q     u
measure 2
E4     2        q     d
rest   2        q
E4     2        q     d
measure 3
E4     2        q     d
rest   2        q
E4     2        q     d
measure 4
C#4    4        h     d
A#3    2        q #   u
measure 5
B3     2        q     u
rest   2        q
B3     2        q     u
measure 6
E4     2        q     d
rest   2        q
E4     2        q     d
measure 7
E4     2        q     d
rest   2        q
E4     2        q     d
measure 8
D4     2        q     d
rest   2        q
A4     2        q     d
measure 9
E4     2        q     d
E4     1        e     d  [
D4     1        e     d  ]
E4     2        q     d
measure 10
D4     2        q     d
rest   2        q
D4     2        q     d
measure 11
E4     2        q     d
E4     1        e     d  [
D4     1        e     d  ]
E4     2        q     d
measure 12
A4     2        q     d
F#4    2        q     d
D4     2        q     d
measure 13
B3     2        q     u
rest   2        q
G3     2        q     u
measure 14
F#3    2        q     u
rest   2        q
mheavy4                  :|:
rest   2        q
measure 15
D3     6-       h.    u        -
measure 16
D3     2        q     u
rest   2        q
rest   2        q
measure 17
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 18
D#4    2        q #   d
rest   2        q
D#4    2        q     d
measure 19
E4     1        e     d  [
E4     1        e     d  =
E4     1        e     d  =
E4     1        e     d  =
E4     1        e     d  =
E4     1        e     d  ]
measure 20
E#4    2        q #   d
rest   2        q
E#4    2        q     d
measure 21
F#4    2        q     d
rest   2        q
rest   2        q
measure 22
rest   4        h
C#5    2        q     d
measure 23
D5     2        q     d
rest   2        q
D5     2        q     d
measure 24
C#5    2        q     d
rest   2        q
E4     2        q     d
measure 25
D4     2        q     d
rest   2        q
D4     2        q     d
measure 26
C#4    2        q     d
rest   2        q
rest   2        q
measure 27
D4     2        q     d
C#4    2        q     d
B3     2        q     u
measure 28
E4     2        q     d
rest   2        q
E4     2        q     d
measure 29
E4     2        q     d
rest   2        q
E4     2        q     d
measure 30
C#4    4        h     d
F#3    2        q     u
measure 31
G3     4        h     u
G3     2        q     u
measure 32
G3     4        h     u
G3     2        q     u
measure 33
G3     2        q     u
rest   2        q
rest   2        q
measure 34
rest   6
measure 35
G3     2        q     u
rest   2        q
G3     2        q     u
measure 36
G3     2        q     u
rest   2        q
G3     2        q     u
measure 37
G3     2        q     u
rest   2        q
G3     2        q     u
measure 38
G3     2        q     u
rest   2        q
G3     2        q     u
measure 39
G#3    2        q #   u
rest   2        q
G#3    2        q     u
measure 40
B3     2        q     u
rest   2        q
B3     2        q     u
measure 41
A#3    2        q #   u
rest   2        q
A#3    2        q     u
measure 42
B3     2        q     u
rest   2        q
mheavy4                  :|:
$   K:5   T:3/4    D:Trio
rest   2        q
measure 43
D#4    2        q #   d
B3     2        q     u
F#3    2        q     u
measure 44
E4     2        q     d
C#4    2        q     d
E3     2        q     u
measure 45
F#4    2        q     d
C#4    2        q     d
A#3    2        q #   u
measure 46
F#4    2        q     d
D#4    2        q #   d
B3     2        q     u
measure 47
A#3    2        q #   u
F#4    2        q     d
C#4    2        q     d
measure 48
C#4    2        q     d
F#3    2        q     u
G#3    2        q #   u
measure 49
G#3    6        h.#   u
measure 50
A#3    2        q #   u
rest   2        q
mheavy4                  :|:
rest   2        q
measure 51
B#3    4        h #   u
B#3    1        e     d  [
D#4    1        e #   d  ]
measure 52
E4     4        h     d
C#4    1        e     d  [
E4     1        e     d  ]
measure 53
D#4    4        h #   d
B3     2        q     u
measure 54
A#3    2        q #   u
rest   2        q
rest   2        q
measure 55
D#4    2        q #   d
B3     2        q     u
F#3    2        q     u
measure 56
E4     2        q     d
C#4    2        q     d
E3     2        q     u
measure 57
F#4    2        q     d
C#4    2        q     d
A#3    2        q #   u
measure 58
F#4    2        q     d
D#4    2        q #   d
B3     2        q     u
measure 59
D#4    2        q #   d
F#4    2        q     d
B4     2        q     d
measure 60
B3     2        q     u
E4     2        q     d
G#4    2        q #   d
measure 61
F#4    4        h     d
E4     2        q     d
measure 62
D#4    2        q #   d
rest   2        q
mheavy2                          :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/03/04} [KHM:3475307147]
TIMESTAMP: DEC/26/2001 [md5sum:69a3ef817c332a36329ac9f4ce6239e1]
11/21/94 W Hewlett
WK#:64,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Menuetto
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:2   T:3/4  C:22  D:Allegretto
rest   2        q
measure 1
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
F#3    4        h     d
F#3    2        q     d
measure 5
B2     2        q     u
rest   2        q
B3     2        q     d
measure 6
A3     2        q     d
rest   2        q
A3     2        q     d
measure 7
A3     2        q     d
rest   2        q
A3     2        q     d
measure 8
F#3    2        q     d
rest   2        q
D3     2        q     d
measure 9
C#3    2        q     u
rest   2        q
C#3    2        q     u
measure 10
D3     2        q     d
rest   2        q
F#3    2        q     d
measure 11
G3     2        q     d
G3     1        e     d  [
F#3    1        e     d  ]
G3     2        q     d
measure 12
F#3    2        q     d
D3     2        q     d
B2     2        q     u
measure 13
G2     2        q     u
rest   2        q
A2     2        q     u
measure 14
D3     2        q     d
rest   2        q
mheavy4                  :|:
G2     2        q     u
measure 15
F#2    2        q     u
F#2    1        e     u  [
E2     1        e     u  ]
F#2    2        q     u
measure 16
G2     2        q     u
rest   2        q
rest   2        q
measure 17
rest   6
measure 18
rest   6
measure 19
rest   6
measure 20
rest   4        h
C#2    2        q     u
measure 21
F#2    2        q     u
F#2    1        e     u  [
E#2    1        e #   u  ]
F#2    2        q     u
measure 22
F#2    2        q     u
F#2    1        e     u  [
E#2    1        e #   u  ]
F#2    2        q     u
measure 23
F#2    2        q     u
F#2    1        e     u  [
E#2    1        e #   u  ]
F#2    2        q     u
measure 24
F#2    2        q     u
F#2    1        e     u  [
E#2    1        e #   u  ]
F#2    2        q     u
measure 25
F#2    2        q     u
F#2    1        e     u  [
E#2    1        e #   u  ]
F#2    2        q     u
measure 26
F#2    2        q     u
rest   2        q
rest   2        q
measure 27
rest   6
measure 28
rest   6
measure 29
rest   6
measure 30
F#3    4        h     d
F#3    2        q     d
measure 31
G3     4        h     d
G3     2        q     d
measure 32
E3     4        h     d
E3     2        q     d
measure 33
E3     2        q     d
rest   2        q
rest   2        q
measure 34
rest   6
measure 35
E3     2        q     d
rest   2        q
E3     2        q     d
measure 36
E3     2        q     d
rest   2        q
E3     2        q     d
measure 37
E3     2        q     d
rest   2        q
E3     2        q     d
measure 38
E3     2        q     d
rest   2        q
E3     2        q     d
measure 39
E#3    2        q #   d
rest   2        q
E#3    2        q     d
measure 40
F#3    2        q     d
rest   2        q
F#3    2        q     d
measure 41
F#3    2        q     d
rest   2        q
F#3    2        q     d
measure 42
B2     2        q     u
rest   2        q
mheavy4                  :|:
$   K:5   T:3/4    D:Trio
rest   2        q
measure 43
B2     2        q     u
rest   2        q
rest   2        q
measure 44
E2     2        q     u
rest   2        q
rest   2        q
measure 45
F#2    2        q     u
rest   2        q
rest   2        q
measure 46
B2     2        q     u
rest   2        q
B3     2        q     d
measure 47
A#3    4        h #   d
E#3    2        q #   d
measure 48
F#3    2        q     d
D#3    2        q #   d
D3     2        q n   d
measure 49
C#3    6        h.    u
measure 50
F#3    2        q     d
rest   2        q
mheavy4                  :|:
rest   2        q
measure 51
F#3    6-       h.    d        -
measure 52
F#3    6-       h.    d        -
measure 53
F#3    6-       h.    d        -
measure 54
F#3    2        q     d
rest   2        q
rest   2        q
measure 55
B2     2        q     u
rest   2        q
rest   2        q
measure 56
E2     2        q     u
rest   2        q
rest   2        q
measure 57
F#2    2        q     u
rest   2        q
rest   2        q
measure 58
B2     2        q     u
rest   2        q
rest   2        q
measure 59
D#3    6        h.#   d
measure 60
E3     6        h.    d
measure 61
F#3    6        h.    d
measure 62
B2     2        q     u
rest   2        q
mheavy2                           :|
/END
/eof
//
