&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/02/01} [KHM:834474206]
TIMESTAMP: DEC/26/2001 [md5sum:7a1830f07c0db9d41bdeefe083b1e674]
11/21/94 W Hewlett
WK#:64,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[Second Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:5   Q:48   T:3/4  C:4  D:Adagio ma non troppo
*               D       mezza voce
P  C25:f33  C17:Y65
F#5  144        h.    d        (
measure 2
G#5  144        h.    d        )
measure 3
A#4  144        h.    u
measure 4
B4    96        h     d
rest  48        q
measure 5
F#5  144        h.    d        (
measure 6
E#5   96        h #   d
F#5   48        q     d        )
measure 7
D#5   48        q     d        (
C#5   72        q.    d
E#4   24        e #   u        )
measure 8
F#4   48        q     u
rest  48        q
rest  48        q
measure 9
F#5   96-       h     d        -(
F#5   24        e     d  [
F##5  24        e x   d  ]     )
measure 10
G#5   96        h     d        [
gF#5   5        s     u        (
E5    24        e     d  [     )
gD#5   5        s     u        (
C#5   24        e     d  ]     )]
measure 11
gB4    5        s     u
A#4  144        h.    u        (t
gG#4   5        s     u  [[
gA#4   5        s     u  ]]    )
measure 12
B4    48        q     d
rest  48        q
rest  48        q
measure 13
F#5  144        h.    d
measure 14
E#5   48-       q #   d        -(
E#5   12        s     d  [[
D#6   12        s     d  ==
C#6   12        s     d  ==
E#5   12        s     d  ]]    )
F#5   48        q     d
measure 15
D#5   18        s.    d  [[    (
E#5    6        t #   d  ]]\
F#5   18        s.    d  [[
E#5    3        x     d  ==[[
D#5    3        x     d  ]]]]  )
C#5   72        q.    d        (
E#4   24        e #   u        )
measure 16
G#4   48        q     u        (
F#4   24        e     u        )
rest  24        e
rest  48        q
measure 17
F#5  144        h.    d        (
measure 18
E#5  144        h.#   d
measure 19
E5    96        h n   d        )+
D#5   48        q     d
measure 20
C#5   24        e     d  [     (
D#5   24        e     d  =
E5    24        e     d  =
F#5   24        e     d  ]     )
G#5   12        s     d  [[     .
G#5   12        s     d  ==    (t
A#5   12        s     d  ==
B5    12        s     d  ]]    )
measure 21
B4    48        q     d        (
A#4   24        e     u        )
rest  24        e
rest  48        q
measure 22
E5    96        h     d        (
D#5   48        q     d        )
measure 23
C#5   96        h     d        (
B4    48        q     d        )
measure 24
G#4   48        q     u        (
F#4   72        q.    u
A#3   24        e     u        )
measure 25
C#4   48        q     u        (
B3    24        e     u        )
rest  24        e
rest  48        q
measure 26
F#5  144        h.    d        (
measure 27
E#5  144        h.#   d
measure 28
E5    96        h n   d        )+
D#5   48        q     d
measure 29
C#5   24        e     d  [     (
gD#5   4        t     u  [[[
gC#5   4        t     u  ===
gB#4   4        t     u  ]]]
C#5   18        s.    d  =[
D#5    6        t     d  ]]\   )
E5    24        e     d  [     (
gF#5   4        t     u  [[[
gE5    4        t     u  ===
gD#5   4        t     u  ]]]
E5    18        s.    d  =[
F#5    6        t     d  ]]\   )
G#5   12        s     d  [[     .
G#5   12        s     d  ==    (t
A#5   12        s     d  ==
B5    12        s n   d  ]]    )+
measure 30
B4    48        q     d        (
A#4   24        e     u        )
rest  24        e
rest  48        q
measure 31
E5    96        h     d        (
D#5   48        q     d        )
measure 32
C#5   48-       q     d        (-
C#5   24        e     d  [
G#5   12        s     d  =[
A#4   12        s     d  ]]    )
C#5   12        s     d  [[    (
B4    12        s     d  ==
D#5   12        s     d  ==
B4    12        s     d  ]]    )
measure 33
A#4   12        s     u  [[    (
G#4   12        s     u  ==
B4    12        s     u  ==
G#4   12        s     u  ]]    )
F#4   72        q.    u        (
A#3   24        e     u        )
measure 34
C#4   36        e.    u  [     (
D#4    6        t     u  =[[
C#4    6        t     u  ]]]   )
B3    24        e     u
rest  24        e
rest  48        q
measure 35
F#5   96        h     d
B4     6        t     d  [[[   (
C#5    6        t     d  ===
D#5    6        t     d  ===
E5     6        t     d  ]]]
F#5    6        t     d  [[[
G#5    6        t     d  ===
A#5    6        t     d  ===
B5     6        t     d  ]]]   )
measure 36
B5    36        e.    d  [     (
G#5   12        s     d  ]\    )
G#5   48-       q     d        -(
G#5   12        s     d  [[
G#5   12        s     d  ==    [
A#5   12        s     d  ==
B5    12        s     d  ]]    )]
measure 37
B5    12        s     d  [[    (
A#5   12        s     d  ]]    )
rest  12        s
A#5   12        s     d         .
rest  12        s
A#5   12        s     d         .
rest  12        s
A#5   12        s     d         .
rest  12        s
A#5   12        s     d  [[    (
E6    12        s     d  ==
A#5   12        s     d  ]]    )
measure 38
C#6   24-       e     d  [     -k(
C#6    6        t     d  =[[
D#6    6        t     d  ===
A#5    6        t     d  ===
C#6    6        t     d  ]]]   )
B5    24        e     d
rest  24        e
rest  48        q
measure 39
F#5   72        q.    d
D#6   24        e     d  [     (
gC#6   5        s     u
B5    24        e     d  =
gA#5   5        s     u
G#5   24        e     d  ]     )
measure 40
F#5   12        s     d  [[    (
E#5   12        s #   d  ]]    )
E#5   48        q     d
E#6   24        e #   d  [     (
F#6   24        e     d  =     )
F#6   24        e     d  ]      .
measure 41
D#6   12        s     d  [[    (
E#6   12        s #   d  ==
F#6   12        s     d  ==
D#6   12        s     d  ]]    )
C#6   72        q.    d        (
E#5   24        e #   d        )
measure 42
G#5   48        q     d        (
F#5   24        e     d        )
rest  24        e
rest  48        q
measure 43
C#5   24        e     d  [     (
A#5   24        e     d  =
F#5   24        e     d  =     )
C#6   24        e     d  =     (
A#5   24        e     d  =
F#5   24        e     d  ]     )
measure 44
E#5   24        e #   d  [     (Z
P    C33:Y62
B5    24        e     d  =
G#5   24        e     d  =     )
D6    24        e n   d  =     (Z
P    C33:Y62
B5    24        e     d  =
G#5   24        e     d  ]     )
measure 45
E5    24        e n   d  [     (+Z
P    C34:Y66
C#6   24        e     d  =
A#5   24        e     d  =     )
E6    24        e     d  =     (Z
P    C33:Y61
D#6   24        e #   d  =      +
B5    24        e     d  ]     )
measure 46
A#5   12        s     d  [[    (
G#5   12        s     d  ==
F##5  12        s x   d  ==
G#5   12        s     d  ]]
F#5   12        s S   d  [[
E5    12        s     d  ==
D#5   12        s     d  ==
E5    12        s     d  ]]
D#5   12        s     d  [[
C#5   12        s     d  ]]
B#4    8        s #3  d  [[     *
C#5    8        s  3  d  ==
G#5    8        s  3  d  ]]    )!
measure 47
B4    48        q n   d        (+
A#4   24        e     u        )
rest  24        e
rest  48        q
measure 48
E5    48-       q     d        -(
E5     6        t     d  [[[
D#5    6        t     d  ===
C#5    6        t     d  ===
B4     6        t     d  ]]]
A#4    6        t     u  [[[
G#4    6        t     u  ===
F#4    6        t     u  ===
E4     6        t     u  ]]]   )
D#4   12        s     u  [[    (
F#4   12        s     u  ==
B4    12        s     u  ==
D#5   12        s     u  ]]    )
measure 49
C#5   48-       q     d        -(
C#5   12        s     d  [[
E5    12        s     d  ==
C#5   12        s     d  ==
A#4   12        s     d  ]]    )
B4    12        s     d  [[    (
C#5   12        s     d  ==
D#5   12        s     d  ==
B4    12        s     d  ]]    )
measure 50
G#4   12        s     u  [[    (
A#4   12        s     u  ==
B4    12        s     u  ==
G#4   12        s     u  ]]    )
F#4   48        q     u
gG#4   5        s     u        (
F#4   12        s     u  [[    )(
E4     6        t     u  ==[
D#4    6        t     u  ]]]   )
gD#4   5        s     u        (
C#4   12        s     u  [[    )(
B3     6        t     u  ==[
A#3    6        t     u  ]]]   )
measure 51
C#4   48        q     u        (
B3    24        e     u        )
rest  24        e
rest  48        q
measure 52
F#4  144        h.    u         pt
P    C33:Y58
measure 53
G#4  144        h.    u         t
measure 54
A#4  144        h.    u        (t
gG#4   5        s     u  [[
gA#4   5        s     u  ]]    )
measure 55
B4    96        h     d
rest  48        q
measure 56
F#5  144        h.    d        (
measure 57
E#5   96        h #   d
F#5   48        q     d        )
measure 58
D#5   48        q     d        (
C#5   24        e     d  [
B#4   24        e #   d  =
C#5   24        e     d  =
B4    24        e n   d  ]     )
measure 59
B4    48        q     d        (
A#4   24        e     u        )
rest  24        e
rest  48        q
measure 60
F#5  144        h.    d        (
measure 61
E#5  144        h.#   d
measure 62
E5    96        h n   d        )+
D#5   48        q     d
measure 63
C#5   24        e     d  [     (
D#5   24        e     d  =
E5    24        e     d  =
F#5   24        e     d  ]     )
G#5   12        s     d  [[     .
G#5   12        s     d  ==    (t
A#5   12        s     d  ==
B5    12        s     d  ]]    )
measure 64
B4    48        q     d        (
A#4   24        e     u        )
rest  24        e
rest  48        q
measure 65
E5    96        h     d        (
D#5   48        q     d        )
measure 66
C#5   96        h     d        (
B4    48        q     d        )
measure 67
G#4   48        q     u        (
F#4   24        e     u  [
E#4   24        e #   u  =
F#4   24        e     u  =
A#3   24        e     u  ]     )
measure 68
C#4   48        q     u        (
B3    24        e     u        )
rest  24        e
rest  48        q
measure 69
*               D       mezza voce
P  C25:f33  C17:Y65
F#5   96-       h     d        -(
F#5   24        e     d  [
F##5  24        e x   d  ]     )
measure 70
G#5   96        h     d
G#4   12        s     d  [[    (
G#5   12        s     d  ==
E5    12        s     d  ==
C#5   12        s     d  ]]    )
measure 71
gB4    5        s     u        (
A#4  144        h.    u        )t(
gG#4   5        s     u  [[
gA#4   5        s     u  ]]    )
measure 72
B4    48        q     d
rest  48        q
rest  48        q
measure 73
F#5  144        h.    d
measure 74
E#5   48-       q #   d        -(
E#5   12        s     d  [[
D#6   12        s     d  ==
C#6   12        s     d  ==
E#5   12        s     d  ]]    )
F#5   48        q     d
measure 75
D#5   18        s.    d  [[    (
E#5    6        t #   d  ]]\
F#5   18        s.    d  [[
E#5    3        x     d  ==[[
D#5    3        x     d  ]]]]  )
C#5   72        q.    d        (
E#4   24        e #   u        )
measure 76
G#4   48        q     u        (
F#4   24        e     u        )
rest  24        e
rest  48        q
measure 77
F#4   12        s     d  [[    (
C#5   12        s     d  ==
A#4   12        s     d  ==
F#5   12        s     d  ]]    )
C#5   12        s     d  [[    (
A#5   12        s     d  ==
F#5   12        s     d  ==
C#6   12        s     d  ]]    )
B5    12        s     d  [[    (
A#5   12        s     d  ==
G#5   12        s     d  ==
F#5   12        s     d  ]]    )
measure 78
G#4   12        s     d  [[    (
E#5   12        s #   d  ==
B4    12        s     d  ==
G#5   12        s     d  ]]    )
E#5   12        s     d  [[    (
D6    12        s n   d  ==
B5    12        s     d  ==
G#5   12        s     d  ]]    )
E#5   12        s     d  [[    (
D5    12        s n   d  ==
B4    12        s     d  ==
G#4   12        s     d  ]]    )
measure 79
E4    12        s n   d  [[    (+
C#5   12        s     d  ==
A#4   12        s #   d  ==     +
E5    12        s     d  ]]    )
C#5   12        s     d  [[    (
G#5   12        s     d  ==
F#5   12        s     d  ==
E5    12        s     d  ]]    )
E5    12        s     d  [[    (
D#5   12        s     d  ==    )
D#5   12        s     d  ==     .
D#5   12        s     d  ]]     .
measure 80
B#4   12        s #   d  [[     .
C#5   12        s     d  ==     .
D5    12        s n   d  ==     .
D#5   12        s #   d  ]]     .
E5    12        s     d  [[     .
E#5   12        s #   d  ==     .
F#5   12        s     d  ==     .
F##5  12        s x   d  ]]     .
G#5   12        s     d  [[     .
G#5   12        s     d  ==    (t
A#5   12        s     d  ==
B5    12        s     d  ]]    )
measure 81
B4    36        e.    d  [     (
C#5    6        t     d  =[[
B4     6        t     d  ]]]   )
A#4   24        e     u         .
rest  24        e
rest  48        q
measure 82
E5    96        h     d        (
D#5   48        q     d        )
measure 83
C#5   96        h     d        (
B4    48        q     d        )
measure 84
G#4   48        q     u        (
F#4   72        q.    u
A#3   24        e     u        )
measure 85
C#4   48        q     u        (
B3    24        e     u        )
rest  24        e
rest  48        q
measure 86
E5    12        s     d  [[    (
A#5   12        s     d  ==
C#6   12        s     d  ==
A#5   12        s     d  ]]    )
E6    12        s     d  [[    (
C#6   12        s     d  ==
A#5   12        s     d  ==
E5    12        s     d  ]]    )
D#5   12        s     d  [[    (
B5    12        s     d  ==
F#5   12        s     d  ==
D#5   12        s     d  ]]    )
measure 87
C#5   12        s     d  [[    (
G#5   12        s     d  ==
E5    12        s     d  ==
C#5   12        s     d  ]]    )
A#4   12        s     d  [[    (
E5    12        s     d  ==
C#5   12        s     d  ==
A#4   12        s     d  ]]    )
B4    12        s     d  [[    (
C#5   12        s     d  ==
D#5   12        s     d  ==
B4    12        s     d  ]]    )
measure 88
G#4   12        s     u  [[    (
A#4   12        s     u  ==
B4    12        s     u  ==
G#4   12        s     u  ]]    )
F#4   72        q.    u        (
A#3   24        e     u        )
measure 89
gB3    0        e     u        (
P    C32:o
B4   144        h.    d        )p
P    C33:Y68
measure 90
A4   144        h.n   u
measure 91
G4   144        h.n   u
measure 92
*               D       dim.
P  C25:f33  C17:Y70
E4   144        h.    u
measure 93
D#4   24        e     u         .pp
P    C34:Y74
rest  24        e
D#4   24        e     u         .
rest  24        e
D#4   24        e     u         .
rest  24        e
measure 94
D#4   24        e     u
rest  24        e
rest  48        q
rest  48        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/02/02} [KHM:834474206]
TIMESTAMP: DEC/26/2001 [md5sum:dd811b7bedd0777dd9bc12640083935c]
11/21/94 W Hewlett
WK#:64,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[Second Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:5   Q:4   T:3/4  C:4  D:Adagio ma non troppo
*               D       mezza voce
P  C25:f33
B3     2        e     u  [     (
F#4    2        e     u  =     )
D#4    2        e     u  =     (
B4     2        e     u  =     )
F#4    2        e     u  =     (
D#4    2        e     u  ]     )
measure 2
B3     2        e     u  [     (
G#4    2        e     u  =     )
E4     2        e     u  =     (
B4     2        e     u  =     )
G#4    2        e     u  =     (
E4     2        e     u  ]     )
measure 3
C#4    2        e     u  [      .
G#4    2        e     u  =     (
F#4    2        e     u  =
E4     2        e     u  =
D#4    2        e     u  =
C#4    2        e     u  ]     )
measure 4
D#4    4        q     u
rest   4        q
rest   4        q
measure 5
B3     2        e     u  [     (
F#4    2        e     u  =     )
D#4    2        e     u  =     (
B4     2        e     u  =     )
F#4    2        e     u  =     (
D#4    2        e     u  ]     )
measure 6
B3     2        e     u  [     (
G#4    2        e     u  =     )
E#4    2        e #   u  =     (
B4     2        e     u  =     )
A#4    2        e     u  =     (
F#4    2        e     u  ]     )
measure 7
G#4    4        q     u
G#4    6        q.    u        (
G#3    2        e     u        )
measure 8
A#3    4        q     u
rest   4        q
rest   4        q
measure 9
B3     2        e     u  [     (
F#4    2        e     u  =     )
D#4    2        e     u  =     (
B4     2        e     u  =     )
F#4    2        e     u  =     (
D#4    2        e     u  ]     )
measure 10
B3     2        e     u  [     (
G#4    2        e     u  =     )
E4     2        e     u  =     (
B4     2        e     u  =     )
G#4    2        e     u  =     (
E4     2        e     u  ]     )
measure 11
C#4    2        e     u  [      .
G#4    2        e     u  =     (
F#4    2        e     u  =
E4     2        e     u  =
D#4    2        e     u  =
C#4    2        e     u  ]     )
measure 12
D#4    4        q     u
rest   4        q
rest   4        q
measure 13
B3     2        e     u  [     (
F#4    2        e     u  =     )
D#4    2        e     u  =     (
B4     2        e     u  =     )
F#4    2        e     u  =     (
D#4    2        e     u  ]     )
measure 14
B3     2        e     u  [     (
G#4    2        e     u  =     )
E#4    2        e #   u  =     (
B4     2        e     u  =     )
A#4    2        e     u  =     (
F#4    2        e     u  ]     )
measure 15
G#4    4        q     u
G#4    6        q.    u        (
G#3    2        e     u        )
measure 16
B3     4        q     u        (
A#3    2        e     u        )
rest   2        e
rest   4        q
measure 17
C#4    2        e     u  [     (
A#4    2        e     u  =     )
F#4    2        e     u  =     (
C#5    2        e     u  =     )
A#4    2        e     u  =     (
F#4    2        e     u  ]     )
measure 18
B3     2        e     u  [     (
B4     2        e     u  =     )
G#4    2        e     u  =     (
D5     2        e n   u  =     )
B4     2        e     u  =     (
G#4    2        e     u  ]     )
measure 19
G4     2        e n   u  [     (
F#4    2        e     u  =     )
A#4    2        e     u  =     (
A#3    2        e     u  =     )
B3     2        e     u  =     (
B4     2        e     u  ]     )
measure 20
G#4    2        e #   u  [     (+
A4     2        e n   u  ]     )
G#4    4        q     u
B3     4-       q     u        -(
measure 21
B3     2        e     u  [
E#4    2        e #   u  =     )
F#4    2        e     u  ]      .
rest   2        e
rest   4        q
measure 22
A#3    2        e     u  [     (
E4     2        e n   u  =     )+
C#4    2        e     u  =     (
G#4    2        e     u  =     )
F#4    2        e     u  =     (
B3     2        e     u  ]     )
measure 23
A#3    2        e     u  [     (
G#4    2        e     u  =     )
C#4    2        e     u  =     (
E4     2        e     u  =     )
D#4    2        e     u  =     (
B3     2        e     u  ]     )
measure 24
C#4    6        q.    u        (
D4     2        e n   u  [     )
D#4    2        e #   u  =     (
E4     2        e     u  ]     )
measure 25
E4     4        q     u        (
D#4    2        e     u        )
rest   2        e
rest   4        q
measure 26
C#4    2        e     u  [     (
A#4    2        e     u  =     )
F#4    2        e     u  =     (
C#5    2        e     u  =     )
A#4    2        e     u  =     (
F#4    2        e     u  ]     )
measure 27
B3     2        e     u  [     (
B4     2        e     u  =     )
G#4    2        e     u  =     (
D5     2        e n   u  =     )
B4     2        e     u  =     (
G#4    2        e     u  ]     )
measure 28
G4     2        e n   u  [     (
F#4    2        e     u  =     )
A#4    2        e     u  =     (
A#3    2        e     u  =     )
B3     2        e     u  =     (
B4     2        e     u  ]     )
measure 29
G#4    2        e     u  [     (
A4     2        e n   u  ]     )
G#4    4        q     u
B3     4-       q     u        -(
measure 30
B3     2        e     u  [
E#4    2        e #   u  =     )
F#4    2        e     u  ]      .
rest   2        e
rest   4        q
measure 31
A#3    2        e     u  [     (
E4     2        e n   u  =     )+
C#4    2        e     u  =     (
G#4    2        e     u  =     )
F#4    2        e     u  =     (
B3     2        e     u  ]     )
measure 32
A#3    2        e     u  [     (
G#4    2        e     u  =     )
C#4    2        e     u  =     (
E4     2        e     u  =     )
D#4    2        e     u  =     (
B3     2        e     u  ]     )
measure 33
C#4    6        q.    u        (
D4     2        e n   u  [     )
D#4    2        e #   u  =     (
E4     2        e     u  ]     )
measure 34
E4     4        q     u        (
D#4    2        e     u        )
rest   2        e
rest   4        q
measure 35
B3     2        e     u  [     (
F#4    2        e     u  =
D#4    2        e     u  =     )
B4     2        e     u  =     (
F#4    2        e     u  =
D#4    2        e     u  ]     )
measure 36
B3     2        e     u  [     (
G#4    2        e     u  =
E4     2        e     u  =     )
B4     2        e     u  =     (
G#4    2        e     u  =
E4     2        e     u  ]     )
measure 37
C#4    2        e     u  [     (
G#4    2        e     u  =     )
F#4    2        e     u  =     (
E4     2        e     u  =     )
D#4    2        e     u  =     (
C#4    2        e     u  ]     )
measure 38
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 39
B3     2        e     u  [     (
F#4    2        e     u  =
D#4    2        e     u  =     )
B4     2        e     u  =     (
F#4    2        e     u  =
D#4    2        e     u  ]     )
measure 40
B3     2        e     u  [     (
G#4    2        e     u  =
E#4    2        e #   u  =     )
B4     2        e     u  =     (
A#4    2        e     u  =
F#4    2        e     u  ]     )
measure 41
G#4    4        q     u
G#4    6        q.    u
G#4    2        e     u
measure 42
E#4    4        q #   u        (
F#4    2        e     u        )
rest   2        e
rest   4        q
measure 43
C#4   12        h.    u
measure 44
D4    12        h.n   u
measure 45
E4     6        q.    u
C#4    2        e     u        (
B3     2        e     u  [     )
B3     2        e     u  ]      .
measure 46
C#4   12        h.    u
measure 47
D#4    4        q     u        (
C#4    2        e     u        )
rest   2        e
rest   4        q
measure 48
A#3    2        e     u  [     (
E4     2        e     u  =
C#4    2        e     u  =     )
G#4    2        e     u  =     (
F#4    2        e     u  =
B3     2        e     u  ]     )
measure 49
A#3    2        e     u  [     (
G#4    2        e     u  =
C#4    2        e     u  =     )
E4     2        e     u  =     (
D#4    2        e     u  =
B3     2        e     u  ]     )
measure 50
C#4    6        q.    u        (
D4     2        e n   u        )
D#4    2        e #   u  [     (.
E4     2        e     u  ]     ).
measure 51
E4     4        q     u        (
D#4    2        e     u        )
rest   2        e
rest   4        q
measure 52
D#4   12        h.    u         p
P    C33:Y66
measure 53
E4    12-       h.    u        -
measure 54
E4    12        h.    u
measure 55
F#4    8        h     u
rest   4        q
measure 56
B4    12-       h.    d        -
measure 57
B4     8        h     d        (
A#4    4        q     u        )
measure 58
G#4   12-       h.    u        -
measure 59
G#4    4        q     u        (
F#4    2        e     u        )
rest   2        e
rest   4        q
measure 60
C#5   12        h.    d        (
measure 61
B4    12        h.    d
measure 62
C#5    8        h     d        )
B4     4        q     d
measure 63
G#4    2        e     u  [     (
F#4    2        e     u  =
E4     2        e     u  =
D#4    2        e     u  =
C#4    2        e     u  =
D4     2        e n   u  ]     )
measure 64
D#4    4        q #   u        (+
C#4    2        e     u        )
rest   2        e
rest   4        q
measure 65
A#4    4        q     u        (
C#5    4        q     d
B4     4        q     d        )
measure 66
A#4    8        h     u        (
B4     4        q     u        )
measure 67
C#4   12        h.    u
measure 68
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 69
*               D       mezza voce
P  C25:f33  C17:Y85
B3     1        s     u  [[    (
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B4     1        s     u  [[    (
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B3     1        s     u  [[    (
B4     1        s     u  ==
F#4    1        s     u  ==
D#4    1        s     u  ]]    )
measure 70
B3     1        s     u  [[    (
G#4    1        s     u  ==
E4     1        s     u  ==
G#4    1        s     u  ]]    )
B4     1        s     u  [[    (
G#4    1        s     u  ==
E4     1        s     u  ==
G#4    1        s     u  ]]    )
B3     1        s     u  [[    (
B4     1        s     u  ==
G#4    1        s     u  ==
E4     1        s     u  ]]    )
measure 71
C#4    1        s     u  [[    (
E4     1        s     u  ==    )
G#4    1        s     u  ==     .
G#4    1        s     u  ]]     .
G#4    1        s     u  [[    (
F#4    1        s     u  ==    )
F#4    1        s     u  ==    (
E4     1        s     u  ]]    )
E4     1        s     u  [[    (
D#4    1        s     u  ==    )
D#4    1        s     u  ==    (
C#4    1        s     u  ]]    )
measure 72
D#4    4        q     u
rest   4        q
rest   4        q
measure 73
B3     1        s     u  [[    (
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B4     1        s     u  [[    (
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B3     1        s     u  [[    (
B4     1        s     u  ==
F#4    1        s     u  ==
D#4    1        s     u  ]]    )
measure 74
B3     1        s     u  [[    (
G#4    1        s     u  ==
E#4    1        s #   u  ==
G#4    1        s     u  ]]    )
B4     1        s     u  [[    (
G#4    1        s     u  ==
E#4    1        s     u  ==
B4     1        s     u  ]]    )
A#4    1        s     u  [[    (
G#4    1        s     u  ==
A#4    1        s     u  ==
F#4    1        s     u  ]]    )
measure 75
G#4    4        q     u
G#4    6        q.    u        (
G#3    2        e     u        )
measure 76
B3     4        q     u        (
A#3    2        e     u        )
rest   2        e
rest   4        q
measure 77
C#4   12        h.    u
measure 78
D4    12        h.n   u
measure 79
E4     6        q.    u
C#4    2        e     u         .
B3     2        e     u  [      .
B3     2        e     u  ]      .
measure 80
C#4    8        h     u
D4     4        q n   u
measure 81
D#4    4        q #   u        (+
C#4    2        e     u        )
rest   2        e
rest   4        q
measure 82
A#3    1        s     u  [[    (
E4     1        s     u  ==
C#4    1        s     u  ==
E4     1        s     u  ]]    )
C#4    1        s     u  [[    (
G#4    1        s     u  ==
E4     1        s     u  ==
G#4    1        s     u  ]]    )
F#4    1        s     u  [[    (
B3     1        s     u  ==
F#4    1        s     u  ==
B3     1        s     u  ]]    )
measure 83
C#4    1        s     u  [[    (
G#4    1        s     u  ==
E4     1        s     u  ==
G#4    1        s     u  ]]    )
C#4    1        s     u  [[    (
E4     1        s     u  ==
C#4    1        s     u  ==
E4     1        s     u  ]]    )
D#4    1        s     u  [[    (
B3     1        s     u  ==
D#4    1        s     u  ==
B3     1        s     u  ]]    )
measure 84
C#4    4-       q     u        -(
C#4    1        s     u  [[
D4     1        s n   u  ==
C#4    1        s     u  ==
D4     1        s     u  ]]    )
D#4    2        e #   u  [     (.
E4     2        e     u  ]     ).
measure 85
E4     4        q     u        (
D#4    2        e     u        )
rest   2        e
rest   4        q
measure 86
C#4    8        h     u        (
D#4    4        q     u        )
measure 87
E4     8        h     u        (
D#4    4        q     u        )
measure 88
C#4    4        q     u
D#4    1        s     u  [[    (
E4     1        s     u  ==
F#4    1        s     u  ==
D#4    1        s     u  ]]    )
C#4    1        s     u  [[    (
D#4    1        s     u  ==
E4     1        s     u  ==    )
E4     1        s     u  ]]     .
measure 89
B3     1        s     u  [[    (p
P    C33:Y80
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B4     1        s     u  [[    (
F#4    1        s     u  ==
D#4    1        s     u  ==
F#4    1        s     u  ]]    )
B3     1        s     u  [[    (
B4     1        s     u  ==
F#4    1        s     u  ==
D#4    1        s     u  ]]    )
measure 90
C4     1        s n   u  [[    (
A4     1        s n   u  ==
F#4    1        s     u  ==
A4     1        s     u  ]]    )
C5     1        s n   u  [[    (
A4     1        s     u  ==
F#4    1        s     u  ==
A4     1        s     u  ]]    )
D#4    1        s     u  [[    (
C5     1        s     u  ==
A4     1        s     u  ==
F#4    1        s     u  ]]    )
measure 91
B3     1        s     u  [[    (
G4     1        s n   u  ==
E4     1        s     u  ==
G4     1        s     u  ]]    )
B4     1        s     u  [[    (
G4     1        s     u  ==
E4     1        s     u  ==
G4     1        s     u  ]]    )
B3     1        s     u  [[    (
B4     1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]    )
measure 92
*               D       dim.
P  C25:f33  C17:Y93
A#3    1        s #   u  [[    (+
E4     1        s     u  ==
C#4    1        s #   u  ==     +
E4     1        s     u  ]]    )
G4     1        s n   u  [[    (
E4     1        s     u  ==
C#4    1        s     u  ==
E4     1        s     u  ]]    )
A#3    1        s     u  [[    (
E4     1        s     u  ==
C#4    1        s     u  ==
A#3    1        s     u  ]]    )
measure 93
B3     2        e     u         .pp
P    C34:Y84
rest   2        e
B3     2        e     u         .
rest   2        e
B3     2        e     u         .
rest   2        e
measure 94
B3     2        e     u
rest   2        e
rest   4        q
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/02/03} [KHM:834474206]
TIMESTAMP: DEC/26/2001 [md5sum:a3eda3b1a32df6ce85a70478e0fe5172]
11/21/94 W Hewlett
WK#:64,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[Second Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:5   Q:4   T:3/4  C:13  D:Adagio ma non troppo
*               D       mezza voce
P  C25:f33  C17:Y75
D#3   12        h.    u
measure 2
E3    12-       h.    u        -
measure 3
E3     4        q     u
D#3    2        e     u  [     (
C#3    2        e     u  =
F#3    2        e     u  =
E3     2        e     u  ]     )
measure 4
D#3    4        q     u
rest   4        q
rest   4        q
measure 5
B3    12        h.    u
measure 6
G#3    8        h     u
F#3    2        e     u  [     (
A#3    2        e     u  ]     )
measure 7
F#4    2        e     d  [     (
D#4    2        e     d  =     )
F#4    2        e     d  =     (
C#4    2        e     d  =     )
E#4    2        e #   d  =     (
B3     2        e     d  ]     )
measure 8
A#3    4        q     u
rest   4        q
rest   4        q
measure 9
D#3   12        h.    u
measure 10
E3    12-       h.    u        -
measure 11
E3     4        q     u
D#3    2        e     u  [     (
C#3    2        e     u  =
F#3    2        e     u  =
E3     2        e     u  ]     )
measure 12
D#3    4        q     u
rest   4        q
rest   4        q
measure 13
B3    12        h.    u
measure 14
G#3    8        h     u
F#3    2        e     u  [     (
A#3    2        e     u  ]     )
measure 15
F#4    2        e     d  [     (
D#4    2        e     d  =     )
F#4    2        e     d  =     (
C#4    2        e     d  ]     )
E#4    2        e #   d  [     (
B3     1        s     d  =[
G#3    1        s     d  ]]    )
measure 16
E#3    4        q #   u        (
F#3    2        e     u        )
rest   2        e
rest   4        q
measure 17
A#3    8        h     u        (
C#4    4        q     d        )
measure 18
D4    12        h.n   d
measure 19
C#4    8        h     d
B3     4        q     u
measure 20
C#4    2        e     u  [     (
B#3    2        e #   u  ]     )
C#4    4        q     d
D4     4        q n   d
measure 21
D#4    4        q #   d        (+
C#4    2        e     d        )
rest   2        e
rest   4        q
measure 22
C#4    4        q     u        (
A#3    4        q     u
B3     4        q     u        )
measure 23
E4     4        q     d        (
A#3    4        q     u
B3     4        q     u        )
measure 24
B3     8-       h     u        -
B3     2        e     u  [     (
C#4    2        e     u  ]     )
measure 25
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 26
A#3    8        h     u        (
C#4    4        q     u        )
measure 27
D4    12        h.n   d
measure 28
C#4    8        h     d
B3     4        q     u
measure 29
C#4    2        e     u  [     (
B#3    2        e #   u  ]     )
C#4    4        q     d
D4     4        q n   d
measure 30
D#4    4        q #   d        (+
C#4    2        e     d        )
rest   2        e
rest   4        q
measure 31
C#4    4        q     u        (
A#3    4        q     u
B3     4        q     u        )
measure 32
E4     4        q     d        (
A#3    4        q     u
B3     4        q     u        )
measure 33
B3     8-       h     u        -
B3     2        e     u  [     (
C#4    2        e     u  ]     )
measure 34
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 35
D#3   12        h.    u
measure 36
E3    12-       h.    u        -
measure 37
E3     4        q     u
D#3    2        e     u  [     (
C#3    2        e     u  =     )
F#3    2        e     u  =     (
E3     2        e     u  ]     )
measure 38
E3     4        q     u        (
D#3    2        e     u        )
rest   2        e
rest   4        q
measure 39
B3    12        h.    u
measure 40
G#3    8        h     u
F#3    2        e     u  [     (
A#3    2        e     u  ]     )
measure 41
F#4    2        e     d  [     (
D#4    2        e     d  =     )
F#4    2        e     d  =     (
C#4    2        e     d  =     )
E#4    2        e #   d  =     (
B3     2        e     d  ]     )
measure 42
B3     4        q     u        (
A#3    2        e     u        )
rest   2        e
rest   4        q
measure 43
A#3   12        h.    u
measure 44
B3    12        h.    u
measure 45
C#4    6        q.    d
A#3    2        e     u        (
B3     2        e     u  [     )
G#3    2        e     u  ]      .
measure 46
G#3   12        h.    u
measure 47
F#3    4        q     u
rest   4        q
rest   4        q
measure 48
C#4    4        q     u        (
A#3    4        q     u
B3     4        q     u        )
measure 49
E4     4        q     d        (
A#3    2        e     u  [
C#4    2        e     u  ]
B3     4        q     u        )
measure 50
B3     8-       h     u        -
B3     2        e     u  [     (.
C#4    2        e     u  ]     ).
measure 51
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 52
B3    12-       h.    u        -p
P    C33:Y58
measure 53
B3    12        h.    u
measure 54
C#4   12        h.    d
measure 55
D#4    8        h     d
rest   4        q
measure 56
F#4   12        h.    d        (
measure 57
G#4    8        h     d
F#4    4        q     d        )
measure 58
F#4    8-       h     d        -
F#4    2        e     d  [     (
E#4    2        e #   d  ]     )
measure 59
E#4    4        q #   d        (
F#4    2        e     d        )
rest   2        e
rest   4        q
measure 60
A#4   12        h.    d        (
measure 61
G#4   12        h.    d
measure 62
A#4    8        h     d        )
B4     4        q     d
measure 63
E4     2        e     u  [     (
A3     2        e n   u  =
G#3    2        e     u  =
F#3    2        e     u  =
E3     2        e     u  =
E#3    2        e #   u  ]     )
measure 64
F#3    2        e     u  [     (
E#3    2        e #   u  ]
F#3    2        e     u        )
rest   2        e
rest   4        q
measure 65
C#5    4        q     d        ([
F#4    4        q     d        )
F#4    4        q     d        ].
measure 66
E4     8        h     d        (
D#4    4        q     d        )
measure 67
B3     8        h     u        (
A#3    2        e #   u  [      +
E3     2        e     u  ]     )
measure 68
E3     4        q     u        (
D#3    2        e     u        )
rest   2        e
rest   4        q
measure 69
*               D       mezza voce
P  C25:f33
D#3    4-       q     u        -
D#3    1        s     u  [[    (
F#3    1        s     u  ==
B3     1        s     u  ==
D#4    1        s     u  ]]    )
D#3    2        e     u  [      .
D#3    2        e     u  ]      .
measure 70
E3     4-       q     u        -
E3     1        s     u  [[    (
G#3    1        s     u  ==
B3     1        s     u  ==
E4     1        s     u  ]]    )
E3     2        e     u  [      .
E3     2        e     u  ]      .
measure 71
E3     4        q     u
D#3    2        e     u  [     (
C#3    2        e     u  =     )
F#3    2        e     u  =     (
E3     2        e     u  ]     )
measure 72
D#3    4        q     u
rest   4        q
rest   4        q
measure 73
D#3    4-       q     u        -
D#3    1        s     u  [[
F#3    1        s     u  ==
B3     1        s     u  ==
D#4    1        s     u  ]]
D#3    2        e     u  [      .
B3     2        e     u  ]      .
measure 74
G#3    4-       q     u        -
G#3    1        s     d  [[    (
B3     1        s     d  ==
E#4    1        s #   d  ==
G#4    1        s     d  ]]    )
F#4    2        e     d  [      .
F#4    2        e     d  ]      .
measure 75
F#4    1        s     d  [[    (
G#4    1        s     d  ==
F#4    1        s     d  ==
D#4    1        s     d  ]]    )
F#4    1        s     d  [[    (
E#4    1        s #   d  ==
F#4    1        s     d  ==
C#4    1        s     d  ]]
E#4    1        s     d  [[
C#4    1        s     d  ==
B3     1        s     d  ==
G#3    1        s     d  ]]    )
measure 76
E#3    4        q #   u        (
F#3    2        e     u        )
rest   2        e
rest   4        q
measure 77
A#3   12        h.    u
measure 78
B3    12        h.    u
measure 79
C#4    6        q.    d
A#3    2        e     u         .
B3     2        e     u  [      .
G#3    2        e     u  ]      .
measure 80
G#3    8        h     u
B3     4-       q     u        -(
measure 81
B3     2        e     d  [
E#4    2        e #   d  =     )
F#4    2        e     d  ]
rest   2        e
rest   4        q
measure 82
C#4    4        q     u        (
A#3    4        q     u
B3     4        q     u        )
measure 83
E4     4        q     d        (
A#3    4        q     u
B3     4        q     u        )
measure 84
B3     8-       h     u        -
B3     2        e     u  [     (
C#4    2        e     u  ]     ).
measure 85
A#3    4        q     u        (
B3     2        e     u        )
rest   2        e
rest   4        q
measure 86
A#3    8        h     u        (
B3     4        q     u        )
measure 87
C#4    8        h     d        (
B3     4        q     u        )
measure 88
B3     4        q     u
B3     1        s     u  [[    (
C#4    1        s     u  ==
D#4    1        s     u  ==
B3     1        s     u  ]]    )
A#3    1        s     u  [[    (
B3     1        s     u  ==
C#4    1        s     u  ==    )
C#4    1        s     u  ]]     .
measure 89
B3     2        e     u  [      .p
P    C34:Y57
D#3    2        e     u  ]      .
D#3    8-       h     u        -
measure 90
D#3   12        h.    u
measure 91
E3    12        h.    u
measure 92
*               D       dim.
P  C25:f33  C17:Y66
G3    12        h.n   u
measure 93
F#3    2        e     u         .pp
P    C34:Y70
rest   2        e
F#3    2        e     u         .
rest   2        e
F#3    2        e     u         .
rest   2        e
measure 94
F#3    2        e     u
rest   2        e
rest   4        q
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/02/04} [KHM:834474206]
TIMESTAMP: DEC/26/2001 [md5sum:4dbbf19863306b2b6672f930a045b95b]
11/21/94 W Hewlett
WK#:64,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[Second Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:5   Q:4   T:3/4  C:22  D:Adagio ma non troppo
*               D       mezza voce
P  C25:f33  C17:Y65
B2     8        h     u
rest   4        q
measure 2
E3     8        h     d
rest   4        q
measure 3
F#2   12        h.    u
measure 4
B2     2        e     u  [     (
A#2    2        e     u  =
B2     2        e     u  =
F#2    2        e     u  =
G#2    2        e     u  =
E2     2        e     u  ]     )
measure 5
D#2   12        h.    u
measure 6
C#2    8        h     u
D#2    4        q     u
measure 7
B#1    4        q #   u
C#2    8        h     u
measure 8
F#2    2        e     u  [     (
A#2    2        e     u  =
C#3    2        e     u  =
F#3    2        e     u  =
E3     2        e     u  =
C#3    2        e     u  ]     )
measure 9
B2     8        h     u
rest   4        q
measure 10
E3     8        h     d
rest   4        q
measure 11
F#2   12        h.    u
measure 12
B2     2        e     u  [     (
A#2    2        e     u  =
B2     2        e     u  =
F#2    2        e     u  =
G#2    2        e     u  =
E2     2        e     u  ]     )
measure 13
D#2   12        h.    u
measure 14
C#2    8        h     u
D#2    4        q     u
measure 15
B#1    4        q #   u
C#2    8        h     u
measure 16
F#2    6        q.    u
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 17
F#3   12-       h.    d        -
measure 18
F#3   12-       h.    d        -
measure 19
F#3    8        h     d
G#3    4        q     d
measure 20
E3     8        h     d
E#3    4        q #   d
measure 21
F#3    6        q.    d
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 22
F#2   12-       h.    u        -
measure 23
F#2    8        h     u
G#2    4        q     u
measure 24
E2     2        e     u  [     (
E#2    2        e #   u  ]     )
F#2    8        h     u
measure 25
B2     6        q.    u
B2     2        e     u  [      .
A#2    2        e     u  =      .
G#2    2        e     u  ]      .
measure 26
F#2   12-       h.    u        -
measure 27
F#2   12-       h.    u        -
measure 28
F#2    8        h     u
G#2    4        q     u
measure 29
E2     8        h     u
E#2    4        q #   u
measure 30
F#2    6        q.    u
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 31
F#2   12-       h.    u        -
measure 32
F#2    8        h     u
G#2    4        q     u
measure 33
E2     2        e     u  [
E#2    2        e #   u  ]
F#2    8        h     u
measure 34
B2     6        q.    u
B3     2        e     d  [      .
F#3    2        e     d  =      .
D#3    2        e     d  ]      .
measure 35
B2     8        h     u
rest   4        q
measure 36
E3     8        h     d
rest   4        q
measure 37
F#2   12        h.    u
measure 38
B2     6        q.    u
F#2    2        e     u  [     (
G#2    2        e     u  =
E2     2        e     u  ]     )
measure 39
D#2   12        h.    u
measure 40
C#2    8        h     u
D#2    4        q     u
measure 41
B#1    4        q #   u
C#2    8        h     u
measure 42
F#2    6        q.    u
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 43
F#2    4        q     u
F#3    8-       h     d        -
measure 44
F#3   12-       h.    d        -
measure 45
F#3    8        h     d
G#3    4        q     d
measure 46
E3    12        h.    d
measure 47
F#3    6        q.    d
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 48
F#2   12-       h.    u        -
measure 49
F#2    8        h     u
G#2    4        q     u
measure 50
E2     2        e     u  [     (
E#2    2        e #   u  ]     )
F#2    8        h     u
measure 51
B2     6        q.    u
B3     2        e     d  [      .
F#3    2        e     d  =      .
D#3    2        e     d  ]      .
measure 52
B2     2        e     d  [     (p
P    C33:Y76
F#3    2        e     d  =
D#3    2        e     d  =     )
B3     2        e     d  =     (
F#3    2        e     d  =
D#3    2        e     d  ]     )
measure 53
B2     2        e     d  [     (
G#3    2        e     d  =
E3     2        e     d  =     )
B3     2        e     d  =     (
G#3    2        e     d  =
E3     2        e     d  ]     )
measure 54
F#2    2        e     u  [     (
G#3    2        e     u  =     )
F#3    2        e     u  =     (
E3     2        e     u  =     )
D#3    2        e     u  =     (
C#3    2        e     u  ]     )
measure 55
B2     2        e     u  [     (
A#2    2        e     u  =     )
B2     2        e     u  =     (
F#2    2        e     u  =     )
G#2    2        e     u  =     (
E2     2        e     u  ]     )
measure 56
D#2    2        e     u  [     (
F#3    2        e     u  =
D#3    2        e     u  =     )
B3     2        e     u  =     (
F#3    2        e     u  =
D#3    2        e     u  ]     )
measure 57
C#2    2        e     u  [     (
G#3    2        e     u  =
E#3    2        e #   u  =     )
B3     2        e     u  =      .
D#2    2        e     u  =      .
D#3    2        e     u  ]      .
measure 58
B#1    2        e #   u  [     (
B#2    2        e #   u  =
C#3    2        e     u  =
D3     2        e n   u  =     )
C#3    2        e     u  =      .
C#2    2        e     u  ]      .
measure 59
F#2    6        q.    u
F#3    2        e     u  [      .
C#3    2        e     u  =      .
A#2    2        e     u  ]      .
measure 60
F#2    2        e     d  [     (
A#3    2        e     d  =
F#3    2        e     d  =     )
C#4    2        e     d  =     (
A#3    2        e     d  =
F#3    2        e     d  ]     )
measure 61
F#2    2        e     d  [     (
B3     2        e     d  =
G#3    2        e     d  =     )
D4     2        e n   d  =     (
B3     2        e     d  =
G#3    2        e     d  ]     )
measure 62
F#2    2        e     d  [     (
C#4    2        e     d  =
A#3    2        e     d  =     )
F#2    2        e     d  =     (
G#2    2        e     d  =
G#3    2        e     d  ]     )
measure 63
E3     2        e     u  [     (
B#2    2        e #   u  =
C#3    2        e     u  =
D#3    2        e     u  =
E3     2        e     u  =
E#3    2        e #   u  ]     )
measure 64
F#3    2        e     u  [     (
E#3    2        e #   u  =
F#3    2        e     u  =
C#3    2        e     u  =
A#2    2        e     u  =
C#3    2        e     u  ]     )
measure 65
F#2    2        e     u  [     (
F#3    2        e     u  =
A#2    2        e     u  =     )
F#3    2        e     u  =     (
B2     2        e     u  =
F#3    2        e     u  ]     )
measure 66
F#2    2        e     u  [     (
F#3    2        e     u  =
F##3   2        e x   u  =     )
F##2   2        e x   u  =     (
G#2    2        e     u  =
G#3    2        e     u  ]     )
measure 67
E2     2        e     u  [     (
E#2    2        e #   u  =
F#2    2        e     u  =
G2     2        e n   u  =
F#2    2        e     u  =
F#3    2        e     u  ]     )
measure 68
B2     6        q.    u
B3     2        e     d  [      .
F#3    2        e     d  =      .
D#3    2        e     d  ]      .
measure 69
*               D       mezza voce
P  C25:f33  C17:Y77
B2     2        e     d  [      .
B3     2        e     d  ]      .
rest   2        e
B2     2        e     u         .
rest   2        e
B2     2        e     u         .
measure 70
E2     2        e     u  [      .
E3     2        e     u  ]      .
rest   2        e
E2     2        e     u         .
rest   2        e
E2     2        e     u         .
measure 71
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
rest   2        e
F#2    2        e     u         .
measure 72
B2     1        s     u  [[    (
A#2    1        s     u  ==
B2     1        s     u  ==
A#2    1        s     u  ]]    )
B2     1        s     u  [[    (
F#2    1        s     u  ==
G#2    1        s     u  ==
F#2    1        s     u  ]]    )
G#2    1        s     u  [[    (
F#2    1        s     u  ==
G#2    1        s     u  ==
E2     1        s     u  ]]    )
measure 73
D#2    2        e     u  [      .
D#3    2        e     u  ]      .
rest   2        e
D#2    2        e     u         .
rest   2        e
D#2    2        e     u         .
measure 74
C#2    2        e     u  [      .
C#3    2        e     u  ]      .
rest   2        e
C#2    2        e     u         .
D#2    2        e     u  [      .
D#3    2        e     u  ]      .
measure 75
B#1    2        e #   u  [      .
B#2    2        e #   u  =      .
C#2    2        e     u  =      .
C#3    2        e     u  ]      .
rest   2        e
C#2    2        e     u         .
measure 76
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   1        s
F#3    1        s     d  [[    (
E#3    1        s #   d  ==
F#3    1        s     d  ]]    )
C#3    1        s     u  [[    (
F#3    1        s     u  ==
A#2    1        s     u  ==
C#3    1        s     u  ]]    )
measure 77
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#3    2        e     d         .
rest   2        e
F#3    2        e     d         .
measure 78
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#3    2        e     d         .
rest   2        e
F#3    2        e     d         .
measure 79
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
G#2    2        e     u  [      .
G#3    2        e     u  ]      .
measure 80
E3     8        h     d
E#3    4        q #   d
measure 81
F#3    4-       q     d        -
F#3    1        s     d  [[
F#3    1        s     d  ==    (
E#3    1        s #   d  ==
F#3    1        s     d  ]]    )
C#3    1        s     u  [[    (
F#3    1        s     u  ==
A#2    1        s     u  ==
C#3    1        s     u  ]]    )
measure 82
F#2    2        e     u  [
F#3    2        e     u  ]
rest   2        e
F#2    2        e     u
rest   2        e
F#2    2        e     u
measure 83
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
G#2    2        e     u  [      .
G#3    2        e     u  ]      .
measure 84
E2     1        s     u  [[    (
D#2    1        s     u  ==
E2     1        s     u  ==
E#2    1        s #   u  ]]    )
F#2    2        e     u  [      .
F#2    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
measure 85
B2     2        e     d  [      .
B3     2        e     d  ]      .
rest   1        s
F#3    1        s     d  [[    (
E#3    1        s #   d  ==
F#3    1        s     d  ]]    )
E3     1        s n   d  [[    (
D#3    1        s     d  ==
C#3    1        s     d  ==
B2     1        s     d  ]]    )
measure 86
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
rest   2        e
F#2    2        e     u         .
measure 87
F#2    2        e     u  [      .
F#3    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
G#2    2        e     u  [      .
G#3    2        e     u  ]      .
measure 88
E2     2        e     u  [     (
E#2    2        e #   u  =
F#2    2        e     u  =     )
F#2    2        e     u  ]      .
rest   2        e
F#2    2        e     u         .
measure 89
B2     2        e     u  [      .p
P    C34:Y63
B2     2        e     u  ]      .
rest   2        e
B2     2        e     u         .
rest   2        e
B2     2        e     u         .
measure 90
B2     2        e     u  [      .
B2     2        e     u  ]      .
rest   2        e
B2     2        e     u         .
rest   2        e
B2     2        e     u         .
measure 91
B2     2        e     u  [      .
B2     2        e     u  ]      .
rest   2        e
B2     2        e     u         .
rest   2        e
B2     2        e     u         .
measure 92
*               D       dim.
P  C25:f33  C17:Y69
B2     2        e     u  [      .
B2     2        e     u  ]      .
rest   2        e
B2     2        e     u         .
rest   2        e
B2     2        e     u         .
measure 93
B2     1        s     d  [[    (pp
P    C33:Y79
D#3    1        s     d  ==
F#3    1        s     d  ==
D#3    1        s     d  ]]    )
B2     1        s     d  [[    (
D#3    1        s     d  ==
F#3    1        s     d  ==
D#3    1        s     d  ]]    )
B2     1        s     d  [[    (
D#3    1        s     d  ==
F#3    1        s     d  ==
D#3    1        s     d  ]]    )
measure 94
B2     2        e     u
rest   2        e
rest   4        q
rest   4        q
mheavy2
/END
/eof
//
