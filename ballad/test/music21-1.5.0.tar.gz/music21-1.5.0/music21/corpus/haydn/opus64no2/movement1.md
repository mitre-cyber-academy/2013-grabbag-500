&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/01/01} [KHM:3913947735]
TIMESTAMP: DEC/26/2001 [md5sum:37421a495ad9bc15fa0c3e5061bc598d]
11/21/94 W Hewlett
WK#:64,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[First Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:8   T:1/1  C:4  D:Allegro spirituoso
D5    12        q.    d         p
P    C33:Y60
E5     1        t     d  [[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
G5     4        e     d  ]      .
measure 2
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  ]     )
B5     4        e     d         .
A5     4        e     d  [      .
G5     4        e     d  =      .
F#5    4        e     d  =      .
E5     4        e     d  ]      .f
P    C34:Y66
measure 3
E5    16        h     d        (
D5     4        e     d  [     )
A#4    4        e #   d  =     (
B4     4        e     d  =
gD5    5        s     u
C#5    4        e     d  ]     )
measure 4
B4    16        h     d        (
A#4    8        q #   u        ).
rest   8        q
measure 5
D5    12        q.    d         p
P    C33:Y60
E5     1        t     d  [[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
G5     4        e     d  ]      .
measure 6
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  ]     )
B5     4        e     d         .
A5     4        e     d  [      .
G5     4        e     d  =      .
F#5    4        e     d  =      .
E5     4        e     d  ]      .f
P    C34:Y64
measure 7
E5    16        h     d        (
D5     4        e     d  [     )
B4     4        e     d  =     (
C#5    4        e     d  =     )
E5     4        e     d  ]      .
measure 8
B4     8        q     d         .
rest   8        q
A#4    8        q #   u         .p
P    C34:Y57
rest   8        q
measure 9
B3    12        q.    u         f
P    C33:Y81
C#4    1        t     u  [[[   (
B3     1        t     u  ===
A#3    1        t #   u  ===
B3     1        t     u  ]]]   )
D4     4        e     u  [     (
A#3    4        e     u  =
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 10
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  ]     )
C#5    1        t     u  [[[   (mf
P    C33:Y62
B4     1        t     u  ===
A#4    1        t #   u  ===
B4     1        t     u  ]]]   )
D5     4        e     d  [     (
A#4    4        e     d  =
B4     4        e     d  =     )
E5     4        e     d  ]      .
measure 11
D5     4        e     d  [     (
A#4    4        e #   d  =
B4     4        e     d  =     )
E5     4        e     d  ]      .
D#5    4        e #   d  [     (
E5     4        e     d  =
F#5    4        e     d  =     )
A5     4        e     d  ]      .
measure 12
G5     4        e     d  [     (
D#5    4        e #   d  ]
E5     4        e     d        )
E5     1        t n   d  [[[   (
D5     1        t n   d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
C#5    4        e     d  [     (
D5     4        e     d  =
E5     4        e     d  =     )
G5     4        e     d  ]      .
measure 13
F#5    4        e     d  [     (
C#5    4        e     d  ]
D5     4        e     d        )
E5     1        t     d  [[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
G5     4        e     d  [     (
C#5    4        e     d  ]
D5     4        e     d        )
D5     1        t     d  [[[   (
E5     1        t     d  ===
F#5    1        t     d  ===
G5     1        t     d  ]]]   )
measure 14
A5     4        e     d  [     (
C#6    4        e     d  =
D6     4        e     d  =
A#5    4        e #   d  ]     )
B5     4        e     d  [     (
F#5    4        e     d  =
G5     4        e     d  =
E5     4        e     d  ]     )
measure 15
D5     8        q     d        (
C#5    4        e     d  [     )
A5     4        e n   d  ]      +
A5     4        e     d  [     (
G#5    4        e #   d  =
G5     4        e n   d  =     )
F#5    4        e     d  ]      .
measure 16
F#5    4        e     d  [     (
F5     4        e n   d  =
E5     4        e     d  =     )
D5     4        e     d  ]      .
C#5    4        e     d  [     (
gD5    4        t     u  [[[
gC#5   4        t     u  ===
gB4    4        t     u  ]]]
C#5    3        s.    d  =[
D5     1        t     d  ]]\   )
E5     4        e     d  [      .
A5     4        e     d  ]      .
measure 17
A5     4        e     d  [     (
G#5    4        e #   d  =
G5     2        s n   d  ]\    )
rest   2        s
F#5    4        e     d         .
F#5    4        e     d  [     (
E#5    4        e #   d  =
E5     2        s n   d  ]\    )
rest   2        s
D5     4        e     d         .
measure 18
D5     4        e     d  [     (
C#5    4        e     d  =
C5     2        s n   d  ]\    )
rest   2        s
B4     4        e     d         .
B4     4        e     u  [     (
A#4    4        e #   u  =
A4     4        e n   u  =     )
G#4    4        e #   u  ]      .
measure 19
G4    12        q.n   u        (+
F#4    4        e     u        )
F#4    4        e     u  [     (
E4     4        e     u  =     )
B4     4        e     u  =      .
C#4    4        e     u  ]      .
measure 20
D4     8        q     u
rest   4        e
D6     4        e     d         .
C#6    4        e     d  [      .
C#6    4        e     d  ]      .
B5     4        e     d  [      .
B5     2        s     d  =[    (
D6     2        s     d  ]]    )
measure 21
A5     4        e     d         .
rest   4        e
rest   4        e
G5     4        e     d         .
F#5    4        e     d  [      .
F#5    4        e     d  ]      .
E5     4        e     d  [      .
E5     2        s     d  =[    (
A5     2        s     d  ]]    )
measure 22
D5     8        q     d
rest   4        e
F#5    4        e     d         .
gF#5   5        s     u        (
E5     4        e     d  [     )(t
D5     4        e     d  =     )
D5     4        e     d  =      .
F#5    4        e     d  ]      .
measure 23
gF#5   5        s     u        (
E5     4        e     d  [     )t(
D5     4        e     d  =     )
D5     4        e     d  =      .
F#5    4        e     d  ]      .
gF#5   5        s     u        (
E5     4        e     d  [     )t(
D5     4        e     d  =     )
D5     4        e     d  =      .
F#5    4        e     d  ]      .
@    This is an E5 in the Dover Edition
measure 24
gF#5   5        s     u        (
E5     4        e     d  [     )t(
D5     4        e     d  =     )
D5     4        e     d  =      .
E5     4        e     d  ]      .
D5     4        e     d  [     (t
C#5    4        e     d  =     )
C#5    4        e     d  =      t.
B4     4        e     d  ]      .
measure 25
B4     4        e     u  [     (t
A4     4        e     u  =     )
A4     4        e     u  =      t.
G4     4        e     u  ]      .
G4     4        e     u  [     (t
F#4    4        e     u  =     )
F#4    4        e     u  =     (t
E4     4        e     u  ]     )
measure 26
D4    12        q.    u         Z
P    C33:Y71
C#4    2        s #   u  [[    (+
D4     2        s     u  ]]    )
F4     2        s n   u  [[    (
A4     2        s     u  ==    )
C#5    2        s #   u  ==     .+
D5     2        s     u  ]]     .
F5     2        s n   d  [[    (
A5     2        s     d  ==    )
F5     2        s     d  ==     .
D5     2        s     d  ]]     .
measure 27
Bf5   12        q.f   d         Z
P    C33:Y60
F#5    2        s #   d  [[    (+
G5     2        s     d  ]]    )
Bf5    2        s f   d  [[    (+
G5     2        s     d  ==    )
Ef5    2        s f   d  ==     .
Bf4    2        s f   d  ]]     .
G4     2        s     u  [[    (
Ef4    2        s f   u  ==    )
Bf3    2        s f   u  ==     .
G3     2        s     u  ]]     .
measure 28
Af3   16        h f   u        (Z
P    C33:Y94
F4    16        h n   u        )
measure 29
A3    16        h n   u        (+p
P    C34:Y87
F#4   16        h #   u        )+
measure 30
Bf3    8        q f   u        (
G4     8        q     u        )
B3     8        q n   u        (
G4     8        q     u        )
measure 31
C#4    4        e #   u  [     (+
G4     4        e     u  =
E4     4        e     u  =
G4     4        e     u  ]     )
D4     4        e     u  [     (
F#4    4        e #   u  =      +
A3     4        e     u  =
D4     4        e     u  ]     )
measure 32
A#3    2        s #   u  [[    (f
P    C33:Y92
B3     2        s     u  ==    )
D#4    2        s #   u  ==    (
E4     2        s     u  ]]    )
F#4    2        s     u  [[    (
G4     2        s     u  ==    )
A#4    2        s #   u  ==    (
B4     2        s     u  ]]    )
D#5    2        s #   d  [[    (
E5     2        s     d  ==    )
F#5    2        s     d  ==    (
G5     2        s     d  ]]    )
A#5    2        s #   d  [[    (
B5     2        s     d  ==    )
G5     2        s     d  ==    (
E5     2        s     d  ]]    )
measure 33
F#5    2        s     d  [[     .
D5     2        s n   d  ==     .+
F#5    2        s     d  ==     .
A5     2        s n   d  ]]     .+
D6     2        s     d  [[    (
A5     2        s     d  ==    )
F#5    2        s     d  ==     .
D5     2        s     d  ]]     .
E5    16        h     d         t
measure 34
D5     4        e     d         .
rest   4        e
D5     4        e     d  [      .mf
P    C34:Y81
E5     1        t     d  =[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
E5     4        e     d         .
rest   4        e
E5     4        e     d  [      .
F#5    1        t     d  =[[   (
E5     1        t     d  ===
D5     1        t     d  ===
E5     1        t     d  ]]]   )
measure 35
F#5    4        e     d         .
rest   4        e
G5     4        e     d  [      .
A5     1        t     d  =[[   (
G5     1        t     d  ===
F#5    1        t     d  ===
G5     1        t     d  ]]]   )
F#5    4        e     d  [     (
A5     4        e     d  =     )
E5     4        e     d  =      .
A5     4        e     d  ]      .
measure 36
*               D +     pizz.
P  C25:f33  C17:Y-10
D4     4        e     u
rest   4        e
*               D +     arco
P  C25:f33  C17:Y-15
D5     4        e     d  [      .
E5     1        t     d  =[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
E5     4        e     d         .
rest   4        e
E5     4        e     d  [      .
F#5    1        t     d  =[[   (
E5     1        t     d  ===
D5     1        t     d  ===
E5     1        t     d  ]]]   )
measure 37
F#5    4        e     d         .
rest   4        e
G5     4        e     d  [      .
A5     1        t     d  =[[   (
G5     1        t     d  ===
F#5    1        t     d  ===
G5     1        t     d  ]]]   )
F#5    4        e     d  [     (
A5     4        e     d  =     )
E5     4        e     d  =      .
A5     4        e     d  ]      .
measure 38
*               D +     pizz.
P  C25:f33  C17:Y-10
D4     4        e     u         .
rest   4        e
*               D +     arco
P  C25:f33  C17:Y-52
*               DH      cresc.
P  C25:f33  C17:Y65 C18:Y65
C#6    2        s     d  [[    (
D6     2        s     d  ==
E6     2        s     d  ==
C#6    2        s     d  ]]    )
D6     4        e     d  [      .
D6     4        e     d  ]      .
E6     2        s     d  [[    (
F#6    2        s     d  ==
G6     2        s     d  ==
E6     2        s     d  ]]    )
measure 39
F#6    4        e     d  [      .
*               J
F#6    4        e     d  ]      .
E6     2        s     d  [[    (
F#6    2        s     d  ==
G6     2        s     d  ==
E6     2        s     d  ]]    )
F#6    4        e     d  [
F#6    4        e     d  =
E6     4        e     d  =      f
P    C33:Y61
A6     4        e     d  ]
measure 40
D4     8        q     u
rest   8        q
rest  16        h
mheavy4 41                       :|:
G4    12        q.    u         f
 G3   12        q.    u
&
This appears as below in the Dover Edition
G4     8        q     u
 G3    8        q     u
rest   4        e
&
G5     4        e     d         .
G5     4        e     d  [     (
F#5    4        e     d  =
F5     4        e n   d  =     )
E5     4        e     d  ]      .
measure 42
E5     4        e     d  [     (
D#5    4        e #   d  =
D5     4        e n   d  =     )
C5     4        e n   d  ]      .
C5     4        e     d  [     (
B4     4        e     d  =
D5     4        e     d  =     )
B4     4        e     d  ]      .
measure 43
A4    12        q.    u         Z
 A3   12        q.    u
A5     4        e     d         .
A5     4        e     d  [     (
G#5    4        e #   d  =
G5     4        e n   d  =     )
F#5    4        e     d  ]      .
measure 44
F#5    4        e     d  [     (
F5     4        e n   d  =
E5     4        e     d  =     )
D5     4        e     d  ]      .
D5     4        e     d  [     (
C#5    4        e #   d  =      +
E5     4        e     d  =     )
C#5    4        e     d  ]      .
measure 45
B4    12        q.    d         Z
P    C33:Y69
B5     4        e     d         .
B5     4        e     d  [     (
A#5    4        e #   d  =
A5     4        e n   d  =     )
G5     4        e     d  ]      .
measure 46
G5     4        e     d  [     (
F#5    4        e     d  =
F5     4        e n   d  =     )
E5     4        e     d  ]      .
E5     4        e     d  [     (
D#5    4        e #   d  =
E5     4        e     d  =     )
F#5    4        e #   d  ]      .
measure 47
G5    12        q.    d         Z
P    C33:Y60
F#5    2        s     d  [[    (
G5     2        s     d  ]]    )
B5     2        s     d  [[    (
G5     2        s     d  ==    )
B5     2        s     d  ==    (
G5     2        s     d  ]]    )
B5     2        s     d  [[    (
G5     2        s     d  ==    )
E5     2        s     d  ==    (
B4     2        s     d  ]]    )
measure 48
G#5   12        q.#   d
F#5    2        s     d  [[    (
G#5    2        s     d  ]]    )
B5     2        s     d  [[    (
G#5    2        s     d  ==    )
B5     2        s     d  ==    (
G#5    2        s     d  ]]    )
B5     2        s     d  [[    (
G#5    2        s     d  ==    )
E5     2        s     d  ==    (
B4     2        s     d  ]]    )
measure 49
G#5   12        q.#   d         Z
P    C33:Y60
F##5   2        s x   d  [[    (
G#5    2        s     d  ]]    )
B5     2        s     d  [[    (
G#5    2        s     d  ==    )
B5     2        s     d  ==    (
G#5    2        s     d  ]]    )
B5     2        s     d  [[    (
G#5    2        s     d  ==    )
E#5    2        s #   d  ==    (
C#5    2        s     d  ]]    )
measure 50
F#5   12        q.    d         Z
P    C33:Y60
E#5    2        s #   d  [[    (
F#5    2        s     d  ]]    )
A5     2        s     d  [[    (
F#5    2        s     d  ==    )
A5     2        s     d  ==    (
F#5    2        s     d  ]]    )
A5     2        s     d  [[    (
F#5    2        s     d  ==    )
C#5    2        s     d  ==    (
A4     2        s     d  ]]    )
measure 51
F#5   12        q.    d         Z
P    C33:Y60
E#5    2        s #   d  [[    (
F#5    2        s     d  ]]    )
A5     2        s     d  [[    (
F#5    2        s     d  ==    )
A5     2        s     d  ==    (
F#5    2        s     d  ]]    )
A5     2        s     d  [[    (
F#5    2        s     d  ==    )
D5     2        s     d  ==    (
A4     2        s     d  ]]    )
measure 52
F#5   12        q.    d         Z
P    C33:Y60
E#5    2        s #   d  [[    (
F#5    2        s     d  ]]    )
A5     2        s     d  [[    (
F#5    2        s     d  ==    )
D#5    2        s #   d  ==    (
B#4    2        s #   d  ]]    )
A4     2        s     u  [[    (
F#4    2        s     u  ==    )
D#4    2        s #   u  ==    (
B#3    2        s #   u  ]]    )
measure 53
C#4   16        h     u        (
C#5   16        h     d        )
measure 54
D4    16        h n   u        (+p
P    C34:Y66
D5    16        h n   d        )+
measure 55
D#4   16        h #   u        (
D#5   16        h #   d        )
measure 56
E4    16        h     u        (
E5    16        h     d        )
measure 57
E#4   16        h #   u        (
E#5   16        h #   d        )
measure 58
*               D       cresc.
P  C25:f33  C17:Y65
F#4    8        q     u        (
F#5    8        q     d        )
G#4    4        e #   d  [     (
G#5    4        e #   d  ]     )
A#4    4        e #   d  [     (
A#5    4        e #   d  ]     )
measure 59
B4     2        s     d  [[    (f
P    C33:Y70
D5     2        s     d  ==    )
F#5    2        s     d  ==     .
B5     2        s     d  ]]     .
B4     2        s     d  [[    (
D#5    2        s #   d  ==    )
F#5    2        s     d  ==     .
A5     2        s     d  ]]     .
B4     2        s     d  [[    (
E5     2        s     d  ==    )
G5     2        s     d  ==     .
B5     2        s     d  ]]     .
B4     2        s     d  [[    (
D#5    2        s     d  ==    )
F#5    2        s     d  ==     .
A5     2        s     d  ]]     .
measure 60
G5     2        s     d  [[    (
A5     2        s     d  ==    )
B5     2        s     d  ==     .
A5     2        s     d  ]]     .
G5     2        s     d  [[    (
F#5    2        s     d  ==    )
E5     2        s     d  ==     .
D#5    2        s #   d  ]]     .
E5     2        s     d  [[    (
F#5    2        s     d  ==    )
G5     2        s     d  ==     .
F#5    2        s     d  ]]     .
E5     2        s     d  [[    (
D5     2        s n   d  ==    )
C#5    2        s     d  ==     .
B4     2        s     d  ]]     .
measure 61
A4     2        s     d  [[    (
C#5    2        s     d  ==    )
E5     2        s     d  ==     .
A5     2        s     d  ]]     .
A4     2        s     d  [[    (
C#5    2        s     d  ==    )
E5     2        s     d  ==     .
G5     2        s     d  ]]     .
A4     2        s     d  [[    (
D5     2        s     d  ==    )
F#5    2        s     d  ==     .
A5     2        s     d  ]]     .
A4     2        s     d  [[    (
C#5    2        s     d  ==    )
E5     2        s     d  ==     .
G5     2        s     d  ]]     .
measure 62
F#5    2        s     d  [[    (
G5     2        s     d  ==    )
A5     2        s     d  ==     .
G5     2        s     d  ]]     .
F#5    2        s     d  [[    (
E5     2        s     d  ==    )
D5     2        s     d  ==     .
C#5    2        s     d  ]]     .
D5     2        s     d  [[    (
C#5    2        s     d  ==    )
B4     2        s     d  ==     .
A4     2        s     d  ]]     .
G4     2        s     u  [[    (
F#4    2        s     u  ==    )
E4     2        s     u  ==     .
D4     2        s     u  ]]     .
measure 63
C#4    2        s     u  [[    (
D4     2        s     u  ==    )
E4     2        s     u  ==     .
F#4    2        s     u  ]]     .
G4     2        s     u  [[    (
F#4    2        s     u  ==    )
E4     2        s     u  ==     .
D4     2        s     u  ]]     .
C#4    2        s     u  [[    (
D4     2        s     u  ==    )
E4     2        s     u  ==     .
F#4    2        s     u  ]]     .
G4     2        s     u  [[    (
E4     2        s     u  ==    )
D4     2        s     u  ==     .
C#4    2        s     u  ]]     .
measure 64
D4     2        s     u  [[    (
E4     2        s     u  ==    )
F#4    2        s     u  ==     .
G4     2        s     u  ]]     .
A4     2        s     u  [[    (
G4     2        s     u  ==    )
F#4    2        s     u  ==     .
E4     2        s     u  ]]     .
D#4    2        s #   u  [[    (
E4     2        s     u  ==    )
F#4    2        s     u  ==     .
G4     2        s     u  ]]     .
A4     2        s     u  [[    (
F#4    2        s     u  ==    )
E4     2        s     u  ==     .
D#4    2        s     u  ]]     .
measure 65
E4     2        s     u  [[    (
F#4    2        s     u  ==    )
G4     2        s     u  ==     .
A4     2        s     u  ]]     .
B4     2        s     u  [[    (
A4     2        s     u  ==    )
G4     2        s     u  ==     .
F#4    2        s     u  ]]     .
E#4    2        s #   d  [[    (Z
P    C33:Y92
D5     2        s     d  ==    )
C#5    2        s     d  ==    (
B4     2        s     d  ]]    )
A#4    2        s #   u  [[    (
B4     2        s     u  ==    )
A#4    2        s     u  ==    (
B4     2        s     u  ]]    )
measure 66
A#4    2        s #   d  [[    (
B4     2        s     d  ==    )
C#5    2        s     d  ==     .
D5     2        s     d  ]]     .
E5     2        s     d  [[    (
D5     2        s     d  ==    )
C#5    2        s     d  ==     .
B4     2        s     d  ]]     .
A#4    2        s     d  [[    (
B4     2        s     d  ==    )
C#5    2        s     d  ==    (
D5     2        s     d  ]]    )
C#5    2        s     d  [[    (
D5     2        s     d  ==    )
E5     2        s     d  ==    (
F#5    2        s     d  ]]    )
measure 67
G5     8        q     d
rest   8        q
rest   4        e
A#4    4        e #   d  [      p.
P    C33:Y72
B4     4        e     d  =      .
C#5    4        e     d  ]      .
measure 68
D5    12        q.    d
E5     1        t     d  [[[   (
D5     1        t     d  ===
C#5    1        t     d  ===
D5     1        t     d  ]]]   )
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
G5     4        e     d  ]      .
measure 69
F#5    4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
B5     4        e     d  ]      .
A5     4        e     d  [      .
G5     4        e     d  =      .
F#5    4        e     d  =      .
E5     4        e     d  ]      .f
P    C34:Y63
measure 70
E5    16        h     d        (
D5     4        e     d  [     )
A#4    4        e #   d  =     (
B4     4        e     d  =
gD5    5        s     u
C#5    4        e     d  ]     )
measure 71
B4    16        h     d        (
A#4    8        q #   u        )
rest   8        q
measure 72
D#5   12        q.#   d         mf
P    C33:Y61
C6     4        e n   d         .
B5     4        e     d  [     (
D#5    4        e     d  =
E5     4        e     d  =     )
G5     4        e     d  ]      .
measure 73
C#5   12        q.    d
B5     4        e     d         .
A5     4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
D6     4        e     d  ]      .
measure 74
D6     4        e     d  [     (
C#6    4        e     d  =
C6     4        e n   d  =     )
B5     4        e     d  ]      .
B5     4        e     d  [     (
A#5    4        e #   d  =
A5     4        e n   d  =     )
G5     4        e     d  ]      .
measure 75
G5     4        e     d  [     (
F#5    4        e     d  =
E#5    4        e #   d  =
F#5    4        e     d  ]     )
F#5    4        e     d  [     (
E5     4        e n   d  =     )
G5     4        e     d  =      .
E5     4        e     d  ]      .
measure 76
E5     4        e     d  [     (t
D5     4        e     d  =     )
F#5    4        e     d  =      .
D5     4        e     d  ]      .
D5     4        e     d  [     (t
C#5    4        e     d  =     )
E5     4        e     d  =      .
A#4    4        e #   d  ]      .
measure 77
B4     8        q     d
rest   4        e
B5     4        e     d         .
A5     4        e n   d  [      +.
A5     4        e     d  ]      .
G5     4        e     d  [      .
G5     2        s     d  =[    (
A5     2        s     d  ]]    )
measure 78
F#5    8        q     d
rest   4        e
C6     4        e n   d         .
B5     4        e     d  [      .
B5     4        e     d  ]      .
A5     4        e     d  [      .
A5     2        s     d  =[    (
B5     2        s     d  ]]    )
measure 79
G5     8        q     d
rest   4        e
B5     2        s     d  [[    (
A5     2        s     d  ]]    )
G5     4        e     d  [      .
G5     2        s     d  =[    (
F#5    2        s     d  ]]    )
E5     4        e     d  [      .
E5     2        s     d  =[    (
D5     2        s     d  ]]    )
measure 80
C#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E#5    2        s #   d  ==     .
F#5    2        s     d  ]]     .
E#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E5     2        s n   d  ==     .
F#5    2        s     d  ]]     .
D5     2        s     d  [[    (
F#5    2        s     d  ==    )
G5     2        s     d  ==     .
F#5    2        s     d  ]]     .
B5     2        s     d  [[    (
F#5    2        s     d  ==    )
D5     2        s     d  ==     .
B4     2        s     d  ]]     .
measure 81
A#4    4        e #   u  [
A#3    4        e #   u  =     (
B3     4        e     u  =
C#4    4        e     u  ]     )
D4     4        e     u         .
rest   4        e
rest   4        e
B4     2        s     d  [[    (
D5     2        s     d  ]]    )
measure 82
C#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E#5    2        s #   d  ==     .
F#5    2        s     d  ]]     .
E#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E5     2        s n   d  ==     .
F#5    2        s     d  ]]     .
D5     2        s     d  [[    (
F#5    2        s     d  ==    )
G5     2        s     d  ==     .
F#5    2        s     d  ]]     .
B5     2        s     d  [[    (
F#5    2        s     d  ==    )
D5     2        s     d  ==     .
B4     2        s     d  ]]     .
measure 83
F#5    8        q     d
rest   8        q
rest  16        h
measure 84
rest   8        q
rest   4        e
B4     4        e     d         p.
P    C33:Y68
B4     4        e     u  [     (
A#4    4        e #   u  =
A4     4        e n   u  =     )
G4     4        e     u  ]      .
measure 85
G4    16        h     u        (
F#4    8        q     u        )
rest   8        q
measure 86
rest   8        q
rest   4        e
B4     4        e     d         .
B4     4        e     d  [     (
C5     4        e n   d  =
C#5    4        e #   d  =     )
D5     4        e     d  ]      .
measure 87
D#5   16        h #   d        (
E5     8        q     d        ).
rest   4        e
G5     4        e     d         f.
P    C33:Y61
measure 88
G5     4        e     d  [     (
F#5    4        e     d  =
E#5    4        e #   d  =     )
E#5    4        e     d  ]      .
E#5   16        h     d
measure 89
E5     4        e n   d  [     (+
D5     4        e     d  =
C#5    4        e     d  =     )
C#5    4        e     d  ]      .
C#5    4        e     d  [     (
B4     4        e     d  =
A#4    4        e #   d  =     )
A#4    4        e     d  ]      .
measure 90
A#4   16        h #   u        (
B4     8        q     d        ).
rest   4        e
D5     4        e     d         .p
P    C34:Y60
measure 91
C#5    8        q     d         .
rest   8        q
A#4    8        q #   u         .
rest   8        q
measure 92
B3    12        q.    u         f
P    C33:Y81
gC#4   4        t     u  [[[   (
gB3    4        t     u  ===
gA#3   4        t     u  ]]]
B3     4        e     u        ).
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 93
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  =     )
B4     4        e     u  ]      p.
P    C33:Y57
A#4    4        e #   u  [     (
E#4    4        e #   u  =
F#4    4        e     u  =     )
E5     4        e n   u  ]      +
measure 94
D5     4        e     d  [     (
A#4    4        e #   d  =
B4     4        e     d  =     )
B5     4        e     d  ]      .
A#5    4        e #   d  [     (
E#5    4        e #   d  =
F#5    4        e     d  =     )
E6     4        e n   d  ]      +.
measure 95
D6     4        e     d         .
rest   4        e
B5     4        e     d  [      .
gC#6   4        t     u  [[[   (
gB5    4        t     u  ===
gA#5   4        t     u  ]]]
B5     4        e     d  ]     ).
A#5    4        e #   d         .+
rest   4        e
E5     4        e     d  [      .
gF#5   4        t     u  [[[   (
gE5    4        t     u  ===
gD#5   4        t     u  ]]]
E5     4        e     d  ]     ).
measure 96
D5     4        e n   d         +
rest   4        e
*               D       cresc.
P  C25:f33  C17:Y63
B5     4        e     d  [      .
gC#6   4        t     u  [[[   (
gB5    4        t     u  ===
gA#5   4        t     u  ]]]
B5     4        e     d  ]     ).
A#5    4        e #   d         .+
rest   4        e
E5     4        e     d  [      .
gF#5   4        t     u  [[[   (
gE5    4        t     u  ===
gD#5   4        t     u  ]]]
E5     4        e     d  ]     ).
measure 97
D5     2        s n   d  [[     +
E5     2        s     d  ==
F#5    2        s     d  ==
E5     2        s     d  ]]
D5     2        s     d  [[
C#5    2        s     d  ==
B4     2        s     d  ==
A#4    2        s #   d  ]]
B4     2        s     u  [[
A4     2        s n   u  ==
G4     2        s     u  ==
F#4    2        s     u  ]]
E4     2        s     u  [[
D4     2        s     u  ==
C#4    2        s     u  ==
B3     2        s     u  ]]
measure 98
C4    16        h n   u         f
P    C33:Y76
C6    16        h n   d         Z
P    C33:Y60
measure 99
D4    16        h     u         Z
P    C33:Y71
D6    16        h     d         Z
P    C33:Y60
measure 100
F#4    8        q     u         Z
P    C33:Y63
F#6   16        h     d
E6     2        s     d  [[    (
D6     2        s     d  ==
C#6    2        s     d  ==
B5     2        s     d  ]]    )
measure 101
C#6   32        w     d         t
measure 102
B5     4        e     d         .
rest   4        e
B4     4        e     u  [      mf
P    C33:Y62
C#5    1        t     u  =[[   (
B4     1        t     u  ===
A#4    1        t #   u  ===
B4     1        t     u  ]]]   )
C#5    4        e     d         .
rest   4        e
C#5    4        e     d  [      .
D5     1        t     d  =[[   (
C#5    1        t     d  ===
B4     1        t     d  ===
C#5    1        t     d  ]]]   )
measure 103
D5     4        e     d         .
rest   4        e
E5     4        e     d  [      .
F#5    1        t     d  =[[   (
E5     1        t     d  ===
D#5    1        t #   d  ===
E5     1        t     d  ]]]   )
D5     4        e n   d  [     (
F#5    4        e     d  =     )
C#5    4        e     d  =      .
F#5    4        e     d  ]      .
measure 104
B3     4        e     u         .
rest   4        e
B4     4        e     u  [      .
C#5    1        t     u  =[[   (
B4     1        t     u  ===
A#4    1        t #   u  ===
B4     1        t     u  ]]]   )
C#5    4        e     d         .
rest   4        e
C#5    4        e     d  [      .
D5     1        t     d  =[[   (
C#5    1        t     d  ===
B4     1        t     d  ===
C#5    1        t     d  ]]]   )
measure 105
D5     4        e     d         .
rest   4        e
E5     4        e     d  [      .
F#5    1        t     d  =[[   (
E5     1        t     d  ===
D#5    1        t #   d  ===
E5     1        t     d  ]]]   )
D5     4        e n   d  [     (
F#5    4        e     d  =     )
C#5    4        e     d  =      .
F#5    4        e     d  ]      .
measure 106
B3     4        e     u         .
rest   4        e
*               DH      cresc.
P  C25:f33  C17:Y62 C18:Y62
A#5    2        s #   d  [[    (
B5     2        s     d  ==
C#6    2        s     d  ==
A#5    2        s     d  ]]    )
B5     4        e     d  [      .
B5     4        e     d  ]      .
C#6    2        s     d  [[    (
D6     2        s     d  ==
E6     2        s     d  ==
C#6    2        s     d  ]]    )
measure 107
D6     4        e     d  [      .
*               J
D6     4        e     d  ]      .
E6     2        s     d  [[    (
F#6    2        s     d  ==
G6     2        s     d  ==
E6     2        s     d  ]]    )
F#6    4        e     d  [      .
F#6    4        e     d  ]      .
A#6    4        e #   d  [      .f
P    C34:Y61
A#6    4        e     d  ]      .
measure 108
B6     8        q     d
rest   8        q
rest  16        h
mheavy2                         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/01/02} [KHM:3913947735]
TIMESTAMP: DEC/26/2001 [md5sum:aa4014c8ddd9a817006b44f29a73eb5d]
11/21/94 W Hewlett
WK#:64,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[First Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:8   T:1/1  C:4  D:Allegro spirituoso
rest  32
measure 2
rest  16        h
rest   8        q
rest   4        e
A#4    4        e #   u         .f
P    C34:Y62
measure 3
A#4   16        h #   u        (
B4     4        e     u  [     )
E4     4        e     u  =     (
F#4    4        e     u  =     )
G4     4        e     u  ]      .
measure 4
F#4   16        h     u
rest  16        h
measure 5
rest  16        h
rest   8        q
rest   4        e
A#4    4        e #   u         .p
P    C34:Y57
measure 6
B4     4        e     d         .
rest   4        e
rest   4        e
G5     4        e     d         .
F#5    4        e     d  [      .
E5     4        e     d  =      .
D5     4        e     d  =      .
C#5    4        e     d  ]      .f
P    C34:Y71
measure 7
C#5   16        h     d        (
B4     4        e     u  [     )
F#4    4        e     u  =     (
G4     4        e     u  =     )
E4     4        e     u  ]      .
measure 8
D4     8        q     u         .
rest   8        q
C#4    8        q     u         .p
P    C34:Y79
rest   8        q
measure 9
B3    12        q.    u         f
P    C33:Y81
C#4    1        t     u  [[[   (
B3     1        t     u  ===
A#3    1        t #   u  ===
B3     1        t     u  ]]]   )
D4     4        e     u  [     (
A#3    4        e     u  =
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 10
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  ]     )
rest   4        e
rest   4        e
G4     4        e     u  [     (mf
P    C33:Y72
F#4    4        e     u  ]     )
rest   4        e
measure 11
rest   4        e
G4     4        e     u  [     (
F#4    4        e     u  =     )
B4     4        e     u  ]      .
A4     4        e     u  [     (
G4     4        e     u  =
F#4    4        e     u  =     )
D#4    4        e #   u  ]      .
measure 12
E4     4        e     u  [     (
F#4    4        e     u  =
G4     4        e     u  =     )
A4     4        e     u  ]      .
G4     4        e     u  [     (
F#4    4        e     u  =
E4     4        e     u  =     )
C#4    4        e     u  ]      .
measure 13
D4     8        q     u         .
rest   8        q
C#4    8        q     u         .
rest   8        q
measure 14
D4    16-       h     u        -
D4     4        e     u  [
D#4    4        e #   u  =     (
E4     4        e     u  =
G4     4        e     u  ]     )
measure 15
F#4    8        q     u        (
E4     4        e     u  [     )
A4     4        e     u  ]      .
A4     4        e     u  [     (
B4     4        e     u  =
A4     4        e     u  =     )
A4     4        e     u  ]      .
measure 16
B4    16        h     d        (
A4     8        q     u        )
rest   4        e
A4     4        e     u         .
measure 17
A4     4        e     u  [     (
B4     4        e     u  =
A4     4        e     u  ]     )
A4     4        e     u
B4    12        q.    d
A4     4        e     u         .
measure 18
G4    12        q.    u
F#4    4        e     u         .
E4    12        q.    u
D4     4        e     u         .
measure 19
D4     8        q     u        (
C#4    4        e     u  [     )
D4     4        e     u  ]      .
B3     8        q     u
rest   4        e
E4     4        e     u         .
measure 20
F#4    4        e     u         .
rest   4        e
rest   4        e
B5     4        e     d         .
A5     4        e     d  [      .
A5     4        e     d  ]      .
G5     4        e     d  [      .
G5     2        s     d  =[    (
B5     2        s     d  ]]    )
measure 21
F#5    4        e     d         .
rest   4        e
rest   4        e
B4     4        e     d         .
A4     4        e     u  [      .
A4     4        e     u  =      .
G4     4        e     u  =      .
G4     4        e     u  ]      .
measure 22
F#4    8        q     u
rest   4        e
A4     4        e     u         .
gA4    5        s     u        (
G4     4        e     u  [     )t(
F#4    4        e     u  =     )
F#4    4        e     u  =      .
A4     4        e     u  ]      .
measure 23
gA4    5        s     u        (
G4     4        e     u  [     )t(
F#4    4        e     u  =     )
F#4    4        e     u  =      .
D4     4        e     u  ]      .
D4    16        h     u
measure 24
D4    12        q.    u
B4     4        e     d         .
B4     4        e     u  [     (t
A4     4        e     u  =     )
A4     4        e     u  =      t.
G4     4        e     u  ]      .
measure 25
G4     4        e     u  [     (t
F#4    4        e     u  =     )
F#4    4        e     u  =      .t
E4     4        e     u  ]      .
E4     4        e     u  [     (t
D4     4        e     u  =     )
D4     4        e     u  =     (t
C#4    4        e     u  ]     )
measure 26
D4    24        h.    u         Z
 A3   24        h.    u
F4     8        q n   u
 A3    8        q     u
measure 27
Ef4   24        h.f   u         Z
 Bf3  24        h.f   u
G3     8        q     u
measure 28
Af3   16        h f   u        (Z
P    C33:Y94
F4    16        h n   u        )
measure 29
A3    16        h n   u        (+p
P    C34:Y87
F#4   16        h #   u        )+
measure 30
Bf3    8        q f   u        (
G4     8        q     u        )
B3     8        q n   u        (
G4     8        q     u        )
measure 31
A3    32        w     u
measure 32
E4     8        q     u         f
 G3    8        q     u
rest   8        q
rest  16        h
measure 33
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
C#5   16        h     d         t
measure 34
D5     4        e     d         .
rest   4        e
rest   8        q
rest   8        q
C#5    4        e     d  [      mf.
P    C33:Y74
A4     4        e     d  ]      .
measure 35
D5     4        e     u  [      .
D4     4        e     u  ]      .
D4     4        e     u  [      .
D4     4        e     u  ]      .
D4     4        e     u         .
rest   4        e
C#4    4        e     u         .
rest   4        e
measure 36
*               D +     pizz.
P  C25:f33  C17:Y-10
D4     4        e     u         .
rest   4        e
rest   4        e
*               D +     arco
P  C25:f33  C17:Y-11
F#4    4        e     u         .
rest   4        e
E4     4        e     u
 C#4   4        e     u         .
rest   4        e
E4     4        e     u
 C#4   4        e     u         .
measure 37
rest   4        e
A4     4        e     u         .
rest   4        e
E5     4        e     d         .
rest   4        e
D5     4        e     u
 F#4   4        e     u         .
rest   4        e
C#5    4        e     u
 E4    4        e     u         .
measure 38
D5     4        e     u  [
 D4    4        e     u         .
F#5    4        e     u  ]      .
*               DH      cresc.
P  C25:f33
E5     4        e     d  [      .
A5     4        e     d  ]      .
*               D +     pizz.
P  C25:f33  C17:Y-10
D4     4        e     u         .
rest   4        e
*               D +     arco
P  C25:f33  C17:Y-11
C#5    4        e     d         .
rest   4        e
measure 39
D5     4        e     d         .
*               J
rest   4        e
C#5    4        e     d         .
rest   4        e
D5     4        e     d         .
rest   4        e
E5     4        e     d         .f
P    C34:Y68
 C#5   4        e     d
 A4    4        e     d
rest   4        e
measure 40
F#5    8        e     u
 A4    8        e     u
 D4    8        e     u
rest   8        q
rest  16        h
mheavy4 41                       :|:
G4    16        h     u         f
 G3   16        h     u
D4    12        q.    u        (
E4     4        e     u        )
measure 42
A4    12        q.    u        (
G4     4        e     u        )
F4    16        h n   u
measure 43
E4    16        h     u         Z
P    C33:Y66
E4    12        q.    u        (
F#4    4        e #   u        ).+
measure 44
B4    12        q.    d        (
A4     4        e     u        ).
G4    16        h     u
measure 45
F#4   16        h     u         Z
P    C33:Y63
F#4   12        q.    u        (
G4     4        e     u        ).
measure 46
C5    12        q.n   d        (
B4     4        e     d        ).
A4     8        q     u
B4     4        e     u  [      .
A4     4        e     u  ]      .
measure 47
G4     4        e     u         Z
P    C33:Y62
B4     8        q     d
B4     4        e     d
G4     2        s     u  [[    (
B4     2        s     u  ==    )
G4     2        s     u  ==    (
B4     2        s     u  ]]    )
G4     2        s     u  [[    (
B4     2        s     u  ==    )
G4     2        s     u  ==    (
B4     2        s     u  ]]    )
measure 48
B3     4        e     u         Z
P    C33:Y81
B4     8        q     d
B4     4        e     d
G#4    2        s #   u  [[    (
B4     2        s     u  ==    )
G#4    2        s     u  ==    (
B4     2        s     u  ]]    )
G#4    2        s     u  [[    (
B4     2        s     u  ==    )
G#4    2        s     u  ==    (
B4     2        s     u  ]]    )
measure 49
B3     4        e     u         Z
P    C33:Y81
B4     8        q     d
B4     4        e     d
G#4    2        s #   u  [[    (
B4     2        s     u  ==    )
G#4    2        s     u  ==    (
B4     2        s     u  ]]    )
G#4    2        s     u  [[    (
B4     2        s     u  ==    )
G#4    2        s     u  ==    (
B4     2        s     u  ]]    )
measure 50
A3     4        e     u         Z
P    C33:Y86
A4     8        q     u
A4     4        e     u
F#4    2        s     u  [[    (
A4     2        s     u  ==    )
F#4    2        s     u  ==    (
A4     2        s     u  ]]    )
F#4    2        s     u  [[    (
A4     2        s     u  ==    )
F#4    2        s     u  ==    (
A4     2        s     u  ]]    )
measure 51
A3     4        e     u         Z
P    C33:Y86
A4     8        q     u
A4     4        e     u
F#4    2        s     u  [[    (
A4     2        s     u  ==    )
F#4    2        s     u  ==    (
A4     2        s     u  ]]    )
F#4    2        s     u  [[    (
A4     2        s     u  ==    )
F#4    2        s     u  ==    (
A4     2        s     u  ]]    )
measure 52
A3     4        e     u         Z
P    C33:Y86
A4     8        q     u
A4     4        e     u
F#4    2        s     u  [[    (
A4     2        s     u  ==    )
F#4    2        s     u  ==    (
A4     2        s     u  ]]    )
F#4    4        e     u  [
B#3    4        e #   u  ]
measure 53
C#4   16        h     u        (
C#5   16        h     d        )
measure 54
D4    16        h     u        (p
P    C33:Y65
D5    16        h     d        )
measure 55
A3    32        w     u
measure 56
G3     4        e     u  [     (
B3     4        e     u  =
G3     4        e     u  =
B3     4        e     u  ]     )
G3     4        e     u  [     (
B3     4        e     u  =
G3     4        e     u  =
B3     4        e     u  ]     )
measure 57
B3     4        e     u  [     (
D4     4        e     u  =
B3     4        e     u  =
D4     4        e     u  ]     )
B3     4        e     u  [     (
D4     4        e     u  =
B3     4        e     u  =
D4     4        e     u  ]     )
measure 58
*               D       cresc.
P  C25:f33  C17:Y95
A#3    4        e #   u  [     (
C#4    4        e     u  =
A#3    4        e     u  =
C#4    4        e     u  ]     )
B3     4        e     u  [     (
D4     4        e     u  =
C#4    4        e     u  =
E4     4        e     u  ]     )
measure 59
F#4    4        e     u         f
P    C33:Y63
rest   4        e
A4     4        e     u
rest   4        e
G4     4        e     u
rest   4        e
F#4    4        e     u
rest   4        e
measure 60
G4     8        q     u
rest   8        q
B4     8        q     d
rest   8        q
measure 61
E4     4        e     u
rest   4        e
G4     4        e     u
rest   4        e
F#4    4        e     u
rest   4        e
E4     4        e     u
rest   4        e
measure 62
F#4    8        q     u
 A3    8        q     u
rest   8        q
A3     8        q     u
rest   8        q
measure 63
A3    32        w     u
measure 64
D4    16        h     u        (
C4    16        h n   u        )Z
P    C33:Y79
measure 65
B3    16        h     u        (
D4    12        q.    u        )Z
P    C33:Y75
B3     4        e     u
measure 66
C#4   32-       w     u        -
measure 67
C#4    8        q     u
rest   8        q
rest  16        h
measure 68
rest  16        h
rest   8        q
rest   4        e
A#4    4        e #   u         .p
P    C34:Y57
measure 69
B4     4        e     d         .
rest   4        e
rest   4        e
G5     4        e     d         .
F#5    4        e     d  [      .
E5     4        e     d  =      .
D5     4        e     d  =      .
C#5    4        e     d  ]      .f
P    C34:Y71
measure 70
C#5   16        h     d        (
B4     4        e     u  [     )
E4     4        e     u  =     (
F#4    4        e     u  =     )
G4     4        e     u  ]      .
measure 71
F#4   16        h     u
rest  16        h
measure 72
rest   4        e
C5     4        e n   d  [     (mf
P    C33:Y71
B4     4        e     d  =
A4     4        e     d  ]     )
G4     4        e     u  [     (
A4     4        e     u  =
B4     4        e     u  =     )
G4     4        e     u  ]      .
measure 73
E4     4        e     u  [      .
B4     4        e     u  =     (
A4     4        e     u  =
G4     4        e     u  ]     )
F#4    4        e     d  [     (
G4     4        e     d  =
A4     4        e     d  =     )
A5     4        e     d  ]      .
measure 74
G5    12        q.    d
F#5    4        e     d         .
E5    12        q.    d
D5     4        e     d         .
measure 75
C#5   12        q.    d        (
D5     2        s     d  [[
C#5    2        s     d  ]]    )
B4     4        e     d         .
rest   4        e
rest   4        e
C#5    4        e     d         .
measure 76
C#5    4        e     d  [     (t
B4     4        e     d  =     )
D5     4        e     d  =      .
B4     4        e     d  ]      .
B4     4        e     u  [     (t
A#4    4        e #   u  =     )
C#5    4        e     u  =      .
E4     4        e     u  ]      .
measure 77
D4     8        q     u
rest   4        e
G5     4        e     d         .
F#5    4        e     d  [      .
F#5    4        e     d  ]      .
E5     4        e     d  [      .
E5     2        s     d  =[    (
F#5    2        s     d  ]]    )
measure 78
D#5    8        q #   d
rest   4        e
A5     4        e     d         .
G5     4        e     d  [      .
G5     4        e     d  ]      .
F#5    4        e     d  [      .
F#5    2        s     d  =[    (
G5     2        s     d  ]]    )
measure 79
E5     8        q     d
rest   4        e
G5     2        s     d  [[    (
F#5    2        s     d  ]]    )
E5     4        e     d  [      .
E5     2        s     d  =[    (
D5     2        s n   d  ]]    )+
C#5    4        e     d  [      .
C#5    2        s     d  =[    (
B4     2        s     d  ]]    )
measure 80
A#4    4        e #   d  [
A#4    4        e     d  =     (
B4     4        e     d  =
C#5    4        e     d  ]     )
D5     4        e     d         .
rest   4        e
rest   4        e
B4     2        s     d  [[    (
D5     2        s     d  ]]    )
measure 81
C#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E#5    2        s #   d  ==     .
F#5    2        s     d  ]]     .
E#5    2        s     d  [[    (
F#5    2        s     d  ==    )
E5     2        s n   d  ==     .
F#5    2        s     d  ]]     .
D5     2        s     d  [[    (
F#5    2        s     d  ==    )
G5     2        s     d  ==     .
F#5    2        s     d  ]]     .
B5     2        s     d  [[    (
F#5    2        s     d  ==    )
D5     2        s     d  ==     .
B4     2        s     d  ]]     .
measure 82
A#4    4        e #   u  [      .
A#4    4        e     u  =     (
B4     4        e     u  =
C#5    4        e     u  ]     )
D5     4        e     d         .
rest   4        e
rest   4        e
B4     2        s     d  [[    (
D5     2        s     d  ]]    )
measure 83
C#5    8        q     d
rest   8        q
rest  16        h
measure 84
rest   8        q
rest   4        e
F#4    4        e     u         .p
P    C34:Y64
E4     8        q     u
rest   4        e
D4     4        e     u         .
measure 85
C#4   24        h.    u
rest   8        q
measure 86
rest  32
measure 87
C5    16        h n   d        (
B4     8        q     d        ).
rest   4        e
B4     4        e     d         .f
P    C34:Y69
measure 88
B4    12        q.    d
B4     4        e     d         .
B4     4        e     d  [     (
C#5    4        e     d  =
D5     4        e     d  =     )
D5     4        e     d  ]      .
measure 89
C#5    4        e     u  [     (
B4     4        e     u  =
A#4    4        e #   u  =     )
F#4    4        e     u  ]      .
E4     4        e     u  [     (
F#4    4        e     u  =
G4     4        e     u  =     )
E4     4        e     u  ]      .
measure 90
E4    16        h     u        (
D4     8        q     u        ).
rest   4        e
F#4    4        e     u         .p
P    C34:Y64
measure 91
E4     8        q     u         .
rest   8        q
C#4    8        q     u         .
rest   8        q
measure 92
B3    12        q.    u         f
P    C33:Y81
gC#4   4        t     u  [[[   (
gB3    4        t     u  ===
gA#3   4        t     u  ]]]
B3     4        e     u        ).
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 93
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  ]     )
rest   4        e
rest   4        e
D4     4        e     u  [     (p
P    C33:Y74
C#4    4        e     u  ]     )
rest   4        e
measure 94
rest   4        e
G4     4        e     u  [     (
F#4    4        e     u  ]     )
rest   4        e
rest   4        e
D5     4        e     d  [     (
C#5    4        e     d  ]     )
rest   4        e
measure 95
rest   4        e
B4     4        e     u  [     (
F#4    4        e     u  =
D5     4        e     u  ]     )
rest   4        e
C#5    4        e     u  [     (
F#4    4        e     u  =
A#4    4        e #   u  ]     )
measure 96
rest   4        e
gC#5   4        t     u  [[[   (
gB4    4        t     u  ===
gA#4   4        t     u  ]]]
B4     4        e     u  [     )(
*               D       cresc.
P  C25:f33  C17:Y67
F#4    4        e     u  =
D5     4        e     u  ]     )
rest   4        e
gD5    4        t     u  [[[   (
gC#5   4        t     u  ===
gB4    4        t     u  ]]]
C#5    4        e     u  [     )(
F#4    4        e     u  =
A#4    4        e #   u  ]     )+
measure 97
rest   4        e
B3     4        e     u  [      .
B3     4        e     u  =      .
C#4    4        e     u  ]      .
D4     8        q     u
rest   8        q
measure 98
C4    32        w n   u         f
P    C33:Y79
measure 99
B3    32        w     u        (Z
P    C33:Y90
measure 100
D4    24        h.    u        )Z
P    C33:Y74
B4     8        q     d
measure 101
B4    16        h     d
A#4   16        h #   u         t
measure 102
B4     8        q     d
rest   8        q
rest   8        q
A#4    4        e #   u  [      .mf
P    C34:Y62
F#4    4        e     u  ]      .
measure 103
B4     4        e     u  [      .
B3     4        e     u  =      .
B3     4        e     u  =      .
B3     4        e     u  ]      .
B3     4        e     u         .
rest   4        e
A#3    4        e #   u         .
rest   4        e
measure 104
B3     4        e     u         .
rest   4        e
rest   4        e
D4     4        e     u         .
rest   4        e
E4     4        e     u
 C#4   4        e     u         .
rest   4        e
E4     4        e     u
 C#4   4        e     u         .
measure 105
rest   4        e
D4     4        e     u         .
rest   4        e
C#5    4        e     d         .
rest   4        e
B4     4        e     d         .
rest   4        e
A#4    4        e #   u         .
measure 106
B4     4        e     d  [      .
D5     4        e     d  =      .
*               DH      cresc.
P  C25:f33  C17:Y72 C18:Y72
C#5    4        e     d  =      .
F#5    4        e     d  ]      .
B4     4        e     d         .
rest   4        e
A#4    2        s #   d  [[    (
B4     2        s     d  ==
C#5    2        s     d  ==
A#4    2        s     d  ]]    )
measure 107
B4     4        e     d  [      .
*               J
B4     4        e     d  ]      .
C#5    2        s     d  [[    (
D5     2        s     d  ==
E5     2        s     d  ==
C#5    2        s     d  ]]    )
D5     4        e     d  [      .
D5     4        e     d  ]      .
C#5    4        e     u  [      f
 E4    4        e     u         .
C#5    4        e     u  ]
 E4    4        e     d         .
measure 108
B4     8        q     u
 D4    8        q     u
rest   8        q
rest  16        h
mheavy2                         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/01/03} [KHM:3913947735]
TIMESTAMP: DEC/26/2001 [md5sum:01fe869ae81ee3c7a21076e004f79d93]
11/21/94 W Hewlett
WK#:64,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[First Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:8   T:1/1  C:13  D:Allegro spirituoso
rest  32
measure 2
rest  16        h
rest   8        q
rest   4        e
C#4    4        e     d         .f
P    C34:Y69
measure 3
C#4   16        h     d        (
B3     4        e     d  [     )
C#4    4        e     d  =     (
D4     4        e     d  =     )
E4     4        e     d  ]      .
measure 4
D4    16        h     d        (
C#4    8        q     d        ).
rest   8        q
measure 5
rest   4        e
B4     4        e     d  [      p.
P    C33:Y57
A4     4        e     d  =      .
G4     4        e     d  ]      .
F#4    4        e     d  [      .
E4     4        e     d  =      .
D4     4        e     d  =      .
C#4    4        e     d  ]      .
measure 6
D4     8        q     d
rest   4        e
E4     4        e     d
F#4   12        q.    d
A#4    4        e #   d         .f
P    C34:Y61
measure 7
A#4   16        h #   d        (
B4     4        e     d  [     )
D4     4        e     d  =     (
E4     4        e     d  =     )
G4     4        e     d  ]      .
measure 8
F#4    8        q     d         .
rest   8        q
F#4    8        q     d         .p
P    C34:Y58
rest   8        q
measure 9
B3    12        q.    u         f
P    C33:Y62
C#4    1        t     u  [[[   (
B3     1        t     u  ===
A#3    1        t #   u  ===
B3     1        t     u  ]]]   )
D4     4        e     u  [     (
A#3    4        e     u  =
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 10
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  ]     )
rest   4        e
rest   4        e
E4     4        e     d  [     (mf
P    C33:Y68
D4     4        e     d  ]     )
rest   4        e
measure 11
rest   4        e
E4     4        e     d  [     (
D4     4        e     d  ]     )
rest   4        e
rest   8        q
rest   4        e
F#4    4        e     d         .
measure 12
B4     4        e     d  [     (
A4     4        e     d  =
G4     4        e     d  ]     )
F#4    4        e     d         .
E4     4        e     d  [     (
D4     4        e     d  =
C#4    4        e     d  =     )
A3     4        e     d  ]      .
measure 13
A3     8        q     u         .
rest   8        q
A3     8        q     u         .
rest   8        q
measure 14
D3     8        q     u         .
rest   8        q
rest   4        e
A4     4        e     d  [     (
G4     4        e     d  =
B4     4        e     d  ]     )
measure 15
A4     8        q     d
rest   4        e
E4     4        e     d         .
E4     4        e     d  [     (
F4     4        e n   d  =
E4     4        e     d  =     )
D4     4        e     d  ]      .
measure 16
D4     8        q     d
rest   4        e
B4     4        e     d         .
E4     8        q     d
rest   4        e
E4     4        e     d         .
measure 17
E4     4        e     d  [     (
F4     4        e n   d  =
E4     4        e     d  ]     )
D4     4        e     d         .
G4    12        q.    d
F#4    4        e #   d         .
measure 18
E4    12        q.    d
D4     4        e     d         .
C#4   12        q.    d
D4     4        e     d         .
measure 19
D4     8        q     d        (
E4     4        e     d  [     )
A3     4        e     d  ]      .
B3     4        e     u         .
rest   4        e
rest   4        e
G3     4        e     u         .
measure 20
F#3    2        s     u  [[    (
A3     2        s     u  ==    )
D4     2        s     u  ==     .
F#4    2        s     u  ]]     .
D4     4        e     d         .
rest   4        e
rest  16        h
measure 21
D4     2        s     d  [[    (
F#4    2        s     d  ==    )
A4     2        s     d  ==     .
F#4    2        s     d  ]]     .
D5     4        e     d         .
rest   4        e
rest   8        q
C#4    8        q     d
measure 22
D4     2        s     d  [[    (
F#4    2        s     d  ==    )
A4     2        s     d  ==     .
F#4    2        s     d  ]]     .
D5     4        e     d  [      .
A4     4        e     d  ]      .
C#5    4        e     d  [     (
D5     4        e     d  =     )
D5     4        e     d  =      .
A4     4        e     d  ]      .
measure 23
C#5    4        e     d  [     (
D5     4        e     d  =     )
D5     4        e     d  ]      .
rest   4        e
rest  16        h
measure 24
rest   8        q
rest   4        e
B4     4        e     d         .
E4     8        q     d
rest   8        q
measure 25
rest   8        q
rest   4        e
B3     4        e     u         .
B3     4        e     u  [     (t
A3     4        e     u  =     )
A3     4        e     u  =     (t
G3     4        e     u  ]     )
measure 26
F3    24        h.n   u         Z
P    C33:Y66
D3     8        q     u
measure 27
Ef3   24        h.f   u         Z
P    C33:Y70
G3     8        q     u
measure 28
Af3   16        h f   u        (Z
P    C33:Y62
F4    16        h n   d        )
measure 29
A3    16        h n   u        (+p
P    C34:Y57
F#4   16        h #   d        )+
measure 30
Bf3    8        q f   u        (
G4     8        q     d        )
B3     8        q n   u        (
G4     8        q     d        )
measure 31
E3    16        h     u        (
F#3   16        h     u        )
measure 32
B3     8        q     u         f
P    C33:Y62
rest   8        q
rest  16        h
measure 33
D4     4        e     d  [
D4     4        e     d  =
D4     4        e     d  =
D4     4        e     d  ]
G3     4        e     u  [
G3     4        e     u  =
G3     4        e     u  =
G3     4        e     u  ]
measure 34
F#3    4        e     u         .
rest   4        e
F#4    4        e     d  [      .mf
P    C34:Y71
D4     4        e     d  =      .
C#4    4        e     d  =      .
A3     4        e     d  ]      .
rest   8        q
measure 35
rest   8        q
D4     4        e     d  [      .
D4     4        e     d  ]      .
F#4    4        e     d         .
rest   4        e
G4     4        e     d         .
rest   4        e
measure 36
F#4    4        e     d         .
rest   4        e
rest   4        e
A4     4        e     d         .
rest   4        e
A4     4        e     d         .
rest   4        e
C#4    4        e     d         .
measure 37
rest   4        e
F#4    4        e     d         .
rest   4        e
B4     4        e     d         .
rest   4        e
A4     4        e     d         .
rest   4        e
G4     4        e     d         .
measure 38
F#4    4        e     d  [      .
D4     4        e     d  =      .
*               DH      cresc.
P  C25:f33  C17:Y68 C18:Y68
A4     4        e     d  =      .
G4     4        e     d  ]      .
F#4    4        e     d  [      .
F#4    4        e     d  =      .
E4     4        e     d  =      .
A4     4        e     d  ]      .
measure 39
D4     4        e     d         .
*               J
rest   4        e
A4     4        e     d         .
rest   4        e
A4     4        e     d         .
rest   4        e
G4     4        e     d         .f
P    C34:Y61
rest   4        e
measure 40
F#4    8        q     d
rest   8        q
rest  16        h
mheavy4 41                       :|:
G3    16        h     u         f
P    C33:Y63
B3    12        q.    u        (
C4     4        e n   u        )
measure 42
F4    12        q.n   d        (
E4     4        e     d        )
D4    16        h     d
measure 43
C#4   16        h #   d         +
C#4   12        q.    d        (
D4     4        e     d        ).
measure 44
G4    12        q.    d        (
F#4    4        e #   d        ).+
E4    16        h     d
measure 45
D#4   16        h #   d         Z
P    C33:Y65
D#4   12        q.    d        (
E4     4        e     d        ).
measure 46
A4    12        q.    d        (
G4     4        e     d        ).
F#4    8        q     d
G4     4        e     d  [     (
D#4    4        e #   d  ]     )
measure 47
E4     4        e     d         Z
P    C33:Y61
E4     8        q     d
E4     4        e     d
E4    16        h     d
measure 48
E4     4        e     d         Z
P    C33:Y61
E4     8        q     d
E4     4        e     d
E4    16        h     d
measure 49
E#4    4        e #   d         Z
P    C33:Y61
E#4    8        q     d
E#4    4        e     d
E#4   16        h     d
measure 50
C#4    4        e     d         Z
P    C33:Y69
C#4    8        q     d
C#4    4        e     d
C#4   16        h     d
measure 51
D4     4        e     d         Z
P    C33:Y65
D4     8        q     d
D4     4        e     d
D4    16        h     d
measure 52
D#4    4        e #   d         Z
P    C33:Y65
D#4    8        q     d
D#4    4        e     d
D#4   12        q.    d
B#3    4        e #   u
measure 53
C#4   16        h     d        (
C#3   16        h     u        )
measure 54
D3    16        h     u        (p
P    C33:Y72
D4    16        h     d        )
measure 55
F#3    4        e     u  [     (
A3     4        e     u  =
F#3    4        e     u  =
A3     4        e     u  ]     )
F#3    4        e     u  [     (
A3     4        e     u  =
F#3    4        e     u  =
A3     4        e     u  ]     )
measure 56
E3     4        e     u  [     (
G3     4        e     u  =
E3     4        e     u  =
G3     4        e     u  ]     )
E3     4        e     u  [     (
G3     4        e     u  =
E3     4        e     u  =
G3     4        e     u  ]     )
measure 57
D4     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
B3     4        e     u  ]     )
D4     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
B3     4        e     u  ]     )
measure 58
*               D       cresc.
P  C25:f33  C17:Y65
F#4    8        q     d        (
C#4    4        e     u  [
A#3    4        e #   u  ]     )
D4     4        e     d  [     (
B3     4        e     d  =
E4     4        e     d  =
C#4    4        e     d  ]     )
measure 59
B3     4        e     u         f
P    C33:Y62
rest   4        e
B3     4        e     u
rest   4        e
B3     4        e     u
rest   4        e
B3     4        e     u
rest   4        e
measure 60
B3     8        q     u
rest   8        q
B3     8        q     u
rest   8        q
measure 61
C#4    4        e     d
rest   4        e
E4     4        e     d
rest   4        e
D4     4        e     d
rest   4        e
C#4    4        e     d
rest   4        e
measure 62
D4     8        q     d
rest   8        q
D4     8        q     d
rest   8        q
measure 63
G3    32        w     u
measure 64
A3    32        w     u
measure 65
G3    16        h     u        (
B3    16        h     u        )Z
P    C33:Y62
measure 66
A#3   32-       w #   u        -
measure 67
A#3    8        q     u
rest   8        q
rest  16        h
measure 68
rest   4        e
B4     4        e     d  [      .p
P    C34:Y57
A4     4        e n   d  =      +.
G4     4        e     d  ]      .
F#4    4        e     d  [      .
E4     4        e     d  =      .
D4     4        e     d  =      .
C#4    4        e     d  ]      .
measure 69
D4     8        q     d
rest   4        e
E4     4        e     d         .
F#4   12        q.    d
A#3    4        e #   u         .f
P    C34:Y68
measure 70
A#3   16        h #   u        (
B3     4        e     u  [     )
C#4    4        e     u  =     (
D4     4        e     u  =     )
E4     4        e     u  ]      .
measure 71
D4    16        h     d        (
C#4    8        q     d        )
rest   8        q
measure 72
rest   4        e
A4     4        e     d  [     (mf
P    C33:Y61
G4     4        e     d  =
D#4    4        e #   d  ]     )
E4     4        e     d  [     (
F#4    4        e     d  =
G4     4        e     d  =     )
E4     4        e     d  ]      .
measure 73
rest   4        e
G4     4        e     d  [     (
F#4    4        e     d  =
C#4    4        e     d  ]     )
D4     4        e     d  [     (
E4     4        e     d  =
F#4    4        e     d  =     )
F#5    4        e     d  ]      .
measure 74
E5    12        q.    d
D5     4        e     d         .
C#5   12        q.    d
B4     4        e     d         .
measure 75
E4    12        q.    d        (
D4     4        e     d        )
G4     8        q     d
rest   4        e
E4     4        e     d         .
measure 76
F#4    8        q     d
rest   8        q
rest   8        q
rest   4        e
C#4    4        e     d         .
measure 77
B3     8        q     u
rest   8        q
rest  16        h
measure 78
rest  16        h
D#4   16        h #   d        (Z
P    C33:Y65
measure 79
E4     8        q     d        )
rest   8        q
rest  16        h
measure 80
rest   4        e
F#4    4        e     d  [     (
G#4    4        e #   d  =
A#4    4        e #   d  ]     )
B4     4        e     d         .
rest   4        e
rest   4        e
E#4    4        e #   d         .
measure 81
F#4    4        e     u  [      .
F#3    4        e     u  =     (
G#3    4        e #   u  =
A#3    4        e #   u  ]     )
B3     8        q     u
rest   4        e
E#4    4        e #   d         .
measure 82
F#4    4        e     d  [      .
F#4    4        e     d  =     (
G#4    4        e #   d  =
A#4    4        e #   d  ]     )
B4     8        q     d
rest   4        e
E#4    4        e #   d
measure 83
F#4    8        q     d
rest   8        q
rest  16        h
measure 84
rest   8        q
rest   4        e
D4     4        e     d         .p
P    C34:Y64
C#4    8        q     d
rest   4        e
B3     4        e     u         .
measure 85
A#3   24        h.#   u
rest   8        q
measure 86
rest  32
measure 87
A4    16        h     d        (
G4     8        q     d        ).
rest   8        q
measure 88
rest   8        q
rest   4        e
D4     4        e     d         .f
P    C34:Y66
D4     4        e     d  [     (
C#4    4        e     d  =
B3     4        e     d  =     )
B3     4        e     d  ]      .
measure 89
A#3    4        e #   u  [     (
B3     4        e     u  =
C#4    4        e     u  =     )
C#4    4        e     u  ]      .
C#4    4        e     d  [     (
D4     4        e     d  =
E4     4        e     d  =     )
C#4    4        e     d  ]      .
measure 90
C#4   16        h     d        (
B3     8        q     u        ).
rest   4        e
F#4    4        e     d         p.
P    C33:Y58
measure 91
G4     8        q     d         .
rest   8        q
E4     8        q     d         .
rest   8        q
measure 92
B3    12        q.    u         f
P    C33:Y62
gC#4   4        t     u  [[[   (
gB3    4        t     u  ===
gA#3   4        t     u  ]]]
B3     4        e     u        ).
D4     4        e     u  [     (
A#3    4        e #   u  =      +
B3     4        e     u  =     )
E4     4        e     u  ]      .
measure 93
D4     4        e     u  [     (
A#3    4        e #   u  =
B3     4        e     u  ]     )
rest   4        e
rest   4        e
B3     4        e     u  [     (p
P    C33:Y57
A#3    4        e     u  ]     )
rest   4        e
measure 94
rest   4        e
E4     4        e     d  [     (
D4     4        e     d  ]     )
rest   4        e
rest   4        e
B4     4        e     d  [     (
A#4    4        e #   d  ]     )
rest   4        e
measure 95
rest   4        e
F#4    4        e     d  [      .
D4     4        e     d  =      .
B3     4        e     d  ]      .
F#3    8        q     u
rest   8        q
measure 96
rest   4        e
F#4    4        e     d  [      .
*               D       cresc.
P  C25:f33  C17:Y72
D4     4        e     d  =      .
B3     4        e     d  ]      .
F#3    8        q     u
rest   8        q
measure 97
rest   4        e
D4     4        e     d  [      .
D4     4        e     d  =      .
E4     4        e     d  ]      .
F#4    8        q     d
rest   8        q
measure 98
G3    32        w     u         f
P    C33:Y65
measure 99
G#3   32        w #   u        (Z
P    C33:Y70
measure 100
B3    24        h.    u        )Z
P    C33:Y62
D4     8        q     d
measure 101
F#4   24        h.    d
gF#4   5        s     u        (
E4     4        e     d  [     )(
D4     2        s     d  =[
E4     2        s     d  ]]    )
measure 102
D4     4        e     d
rest   4        e
D4     4        e     d  [      mf
P    C33:Y73
B3     4        e     d  ]
A#3    4        e #   u  [      .
F#3    4        e     u  ]      .
rest   8        q
measure 103
rest   8        q
B3     4        e     u  [      .
B3     4        e     u  ]      .
D4     4        e     d         .
rest   4        e
E4     4        e     d         .
rest   4        e
measure 104
D4     4        e     d         .
rest   4        e
rest   4        e
F#4    4        e     d         .
rest   4        e
A#3    4        e #   u         .
rest   4        e
A#3    4        e     u         .
measure 105
rest   4        e
B3     4        e     u         .
rest   4        e
G4     4        e     d         .
rest   4        e
D4     4        e     d         .
rest   4        e
C#4    4        e     d         .
measure 106
D4     4        e     d  [      .
B3     4        e     d  =      .
*               DH      cresc.
P  C25:f33  C17:Y75 C18:Y75
F#4    4        e     d  =      .
E4     4        e     d  ]      .
D4     4        e     d  [      .
D4     4        e     d  =      .
C#4    4        e     d  =      .
F#4    4        e     d  ]      .
measure 107
F#4    4        e     d         .
*               J
rest   4        e
rest   8        q
B3     4        e     u  [      .
B3     4        e     u  =      .
F#3    4        e     u  =      .f
P    C34:Y74
F#3    4        e     u  ]      .
measure 108
B3     8        q     u
rest   8        q
rest  16        h
mheavy2                           :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/01/04} [KHM:3913947735]
TIMESTAMP: DEC/26/2001 [md5sum:19d946d358f8c269c7dedb44ffaba96c]
11/21/94 W Hewlett
WK#:64,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
[First Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:8   T:1/1  C:22  D:Allegro spirituoso
rest  32
measure 2
rest  16        h
rest   8        q
rest   4        e
F#3    4        e     d         f.
P    C33:Y62
measure 3
F#3   16        h     d        (
G3    12        q.    d        )
E3     4        e     d         .
measure 4
F#3   16        h     d        (
F#2    4        e     u  [     )
E3     4        e     u  =      .p
P    C34:Y57
D3     4        e     u  =      .
C#3    4        e     u  ]      .
measure 5
B2     8        q     u
rest   8        q
rest  16        h
measure 6
rest  16        h
rest   8        q
rest   4        e
F#3    4        e     d         f.
P    C33:Y62
measure 7
G3    16-       h     d        -
G3     4        e     d  [
D3     4        e     d  =     (
E3     4        e     d  =     )
C#3    4        e     d  ]      .
measure 8
F#3    8        q     d         .
rest   8        q
F#2    8        q     u         .p
P    C34:Y74
rest   8        q
measure 9
B2    12        q.    u         f
P    C33:Y62
C#3    1        t     u  [[[   (
B2     1        t     u  ===
A#2    1        t #   u  ===
B2     1        t     u  ]]]   )
D3     4        e     u  [     (
A#2    4        e     u  =
B2     4        e     u  =     )
E3     4        e     u  ]      .
measure 10
D3     4        e     u  [     (
A#2    4        e #   u  =
B2     4        e     u  ]     )
rest   4        e
rest  16        h
measure 11
rest   8        q
rest   4        e
G3     4        e     d         .mf
P    C34:Y60
F#3    4        e     d  [     (
E3     4        e     d  =
D#3    4        e #   d  =     )
B2     4        e     d  ]      .
measure 12
E3     8        q     d
rest   8        q
rest   8        q
rest   4        e
A2     4        e     u         .
measure 13
D3     8        q     d         .
rest   8        q
E3     8        q     d         .
rest   8        q
measure 14
F#3   16        h     d        (
G3    16        h     d        )
measure 15
A3     4        e     d  [      .
A2     4        e     d  =      .
A2     4        e     d  =      .
C#4    4        e     d  ]      .
C#4    4        e     d  [     (
D4     4        e     d  =
C#4    4        e     d  =     )
D4     4        e     d  ]      .
measure 16
G3    12        q.    d
G#3    4        e #   d         .
A3     8        q     d
rest   4        e
C#4    4        e     d         .
measure 17
C#4    4        e     d  [     (
D4     4        e     d  =
C#4    4        e     d  ]     )
rest   4        e
rest  16        h
measure 18
rest  16        h
rest   8        q
rest   4        e
B2     4        e     u         .
measure 19
B2     4        e     u  [     (
Bf2    4        e f   u  =
A2     4        e     u  =     )
D3     4        e     u  ]      .
G2    12        q.    u
A2     4        e     u         .
measure 20
D2     4        e     u  [      .
D3     4        e     u  =      .
D3     4        e     u  =      .
D3     4        e     u  ]      .
D3     4        e     d  [      .
D3     4        e     d  =      .
D3     4        e     d  =      .
D3     4        e     d  ]      .
measure 21
D2     4        e     u  [      .
D3     4        e     u  =      .
D3     4        e     u  =      .
D3     4        e     u  ]      .
D3     4        e     d  [      .
D3     4        e     d  =      .
D3     4        e     d  =      .
D3     4        e     d  ]      .
measure 22
D2     4        e     u  [
D4     4        e     d  =
D4     4        e     d  =
D4     4        e     d  ]
D4     4        e     d  [
D4     4        e     d  =
D4     4        e     d  =
D4     4        e     d  ]
measure 23
D4     8        q     d
rest   4        e
F#3    4        e     d         .
G3     4        e     d  [     (
A3     4        e     d  =     )
B3     4        e     d  =      .
F#3    4        e     d  ]      .
measure 24
G3     4        e     d  [     (
A3     4        e     d  =     )
B3     4        e     d  =      .
G#3    4        e #   d  ]      .
A3     8        q     d
rest   4        e
C#3    4        e     u         .
measure 25
D3     8        q     d
rest   4        e
G2     4        e     u         .
A2     8        q     u
A2     8        q     u
measure 26
F2     4        e n   u  [      Z
P    C33:Y71
F2     4        e     u  =
F2     4        e     u  =
F2     4        e     u  ]
F2     4        e     u  [
F2     4        e     u  =
F2     4        e     u  =
F2     4        e     u  ]
measure 27
G2     4        e     u  [      Z
P    C33:Y66
G2     4        e     u  =
G2     4        e     u  =
G2     4        e     u  ]
G2     4        e     u  [
G2     4        e     u  =
G2     4        e     u  =
G2     4        e     u  ]
measure 28
Af2   16        h f   u        (Z
P    C33:Y62
F3    16        h n   d        )
measure 29
A2    16        h n   u        (+p
P    C34:Y58
F#3   16        h #   d        )+
measure 30
Bf2    8        q f   u        (
G3     8        q     d        )
B2     8        q n   u        (
G3     8        q     d        )
measure 31
C#3   16        h #   u        (+
D3    16        h     u        )
measure 32
G2     8        q     u         f
rest   8        q
rest  16        h
measure 33
A2     4        e     u  [
A2     4        e     u  =
A2     4        e     u  =
A2     4        e     u  ]
A2     4        e     u  [
A2     4        e     u  =
A2     4        e     u  =
A2     4        e     u  ]
measure 34
D3     4        e     u  [      .
D2     4        e     u  ]      .
rest   8        q
rest  16        h
measure 35
rest   8        q
B3     4        e     d  [      mf.
P    C33:Y61
B3     4        e     d  ]      .
A3     4        e     d         .
rest   4        e
A2     4        e     u         .
rest   4        e
measure 36
D3     4        e     u  [      .
D2     4        e     u  ]      .
rest   4        e
D4     4        e     d         .
rest   4        e
A3     4        e     d         .
rest   4        e
A3     4        e     d         .
measure 37
rest   4        e
D3     4        e     d         .
rest   4        e
G2     4        e     u         .
rest   4        e
A2     4        e     u         .
rest   4        e
A2     4        e     u         .
measure 38
D3     8        q     d
rest   8        q
rest   8        q
*               DH      cresc.
P  C25:f33  C17:Y71 C18:Y71
A3     8        q     d
measure 39
D3     4        e     d  [      .
*               J
D3     4        e     d  ]      .
A2     4        e     d  [      .
A3     4        e     d  ]      .
*               D +     pizz.
P  C25:f33  C17:Y-13
D3     4        e     d         .
rest   4        e
*               D +     arco
P  C25:f33  C17:Y-13
A2     4        e     u         .f
P    C34:Y69
rest   4        e
measure 40
D2     8        q     u
rest   8        q
rest  16        h
mheavy4 41                       :|:
G2    32-       w     u        -f
P    C33:Y73
measure 42
G2    16        h     u
G#2   16        h #   u         Z
P    C33:Y66
measure 43
A2    32-       w     u        -Z
P    C33:Y70
measure 44
A2    16        h     u
A#2   16        h #   u         Z
P    C33:Y63
measure 45
B2    32-       w     u        -Z
P    C33:Y67
measure 46
B2    32        w     u
measure 47
E2     4        e     u  [      Z
P    C33:Y76
E3     4        e     u  =
E3     4        e     u  =
E3     4        e     u  ]
E3     4        e     d  [
E3     4        e     d  =
E3     4        e     d  =
E3     4        e     d  ]
measure 48
D2     4        e     u  [
D3     4        e     u  =
D3     4        e     u  =
D3     4        e     u  ]
D3     4        e     d  [
D3     4        e     d  =
D3     4        e     d  =
D3     4        e     d  ]
measure 49
C#2    4        e     u  [      Z
P    C33:Y86
C#3    4        e     u  =
C#3    4        e     u  =
C#3    4        e     u  ]
C#3    4        e     u  [
C#3    4        e     u  =
C#3    4        e     u  =
C#3    4        e     u  ]
measure 50
C#2    4        e     u  [      Z
P    C33:Y86
C#3    4        e     u  =
C#3    4        e     u  =
C#3    4        e     u  ]
C#3    4        e     u  [
C#3    4        e     u  =
C#3    4        e     u  =
C#3    4        e     u  ]
measure 51
D2     4        e     u  [      Z
P    C33:Y81
D3     4        e     u  =
D3     4        e     u  =
D3     4        e     u  ]
D3     4        e     d  [
D3     4        e     d  =
D3     4        e     d  =
D3     4        e     d  ]
measure 52
B#1    4        e #   u  [      Z
P    C33:Y91
B#2    4        e #   u  =
B#2    4        e     u  =
B#2    4        e     u  ]
B#2    4        e     u  [
B#2    4        e     u  =
B#2    4        e     u  =
B#2    4        e     u  ]
measure 53
C#3   16        h     u        (
C#4   16        h     d        )
measure 54
D3    16        h     d        (p
P    C33:Y68
D4    16        h     d        )
measure 55
B2    32-       w     u        -
measure 56
B2    32        w     u
measure 57
G2    32        w     u
measure 58
*               D       cresc.
P  C25:f33  C17:Y73
F#2   16        h     u
E#2    8        q #   u        (
E2     8        q n   u        )
measure 59
D2     4        e     u         f
P    C33:Y81
rest   4        e
D#2    4        e #   u
rest   4        e
E2     4        e     u
rest   4        e
D#2    4        e     u
rest   4        e
measure 60
E2     8        q     u
rest   8        q
G2     8        q     u
rest   8        q
measure 61
A2     4        e     u
rest   4        e
C#3    4        e     u
rest   4        e
D3     4        e     d
rest   4        e
C#3    4        e     u
rest   4        e
measure 62
D3     8        q     d
rest   8        q
F#3    8        q     d
rest   8        q
measure 63
E3    32        w     d
measure 64
F#3   32        w     d
measure 65
G3    32        w     d
measure 66
F#3   32        w     d
measure 67
E3     8        q     d
rest   8        q
rest  16        h
measure 68
rest  32
measure 69
rest  16        h
rest   8        q
rest   4        e
F#3    4        e     d         f.
P    C33:Y62
measure 70
F#3   16        h     d        (
G3    12        q.    d        )
E3     4        e     d         .
measure 71
F#3   16        h     d        (
F#2    4        e     u  [     )
*               E   15
P    C17:Y62
E3     4        e     u  =      .
D3     4        e     u  =      .
*               F   0
C#3    4        e     u  ]      .
measure 72
B2     8        q     u         mf
P    C33:Y62
rest   8        q
rest  16        h
measure 73
A2     8        q     u
rest   8        q
rest  16        h
measure 74
rest  16        h
rest   8        q
rest   4        e
B3     4        e     d         .
measure 75
A#3   12        q.#   d        (
B3     4        e     d        )
G3     8        q n   d         +
rest   4        e
E3     4        e     d         .
measure 76
F#3    8        q     d
rest   8        q
F#2    8        q     u
rest   8        q
measure 77
B2     4        e     d  [
B3     4        e     d  =
B3     4        e     d  =
B3     4        e     d  ]
B3     4        e     d  [
B3     4        e     d  =
B3     4        e     d  =
B3     4        e     d  ]
measure 78
B2     4        e     d  [
B3     4        e     d  =
B3     4        e     d  =
B3     4        e     d  ]
B3     4        e     d  [
B3     4        e     d  =
B3     4        e     d  =
B3     4        e     d  ]
measure 79
E2     4        e     u  [
E3     4        e     u  =
E3     4        e     u  =
E3     4        e     u  ]
E3     4        e     d  [
E3     4        e     d  =
E3     4        e     d  =
E3     4        e     d  ]
measure 80
F#3    8        q     d
rest   8        q
rest  16        h
measure 81
F#3    8        q     d
rest   8        q
rest  16        h
measure 82
F#3    8        q     d
rest   8        q
rest  16        h
measure 83
F#2    8        q     u
rest   4        e
F#2    4        e     u         .p
P    C34:Y74
G2     4        e     u  [     (
G#2    4        e #   u  =
A2     4        e     u  =     )
A#2    4        e #   u  ]      .
measure 84
B2     8        q     u
rest   8        q
rest  16        h
measure 85
rest  32
measure 86
rest  32
measure 87
rest  16        h
rest   8        q
rest   4        e
E3     4        e     d         .f
P    C34:Y66
measure 88
E3     4        e     d  [     (
D3     4        e     d  =
C#3    4        e     d  =     )
C#3    4        e     d  ]      .
C#3   16        h     u
measure 89
F#3   32        w     d
measure 90
G3    16        h     d        (
G3     8        q     d        ).
rest   4        e
B2     4        e     u         .p
P    C34:Y63
measure 91
E3     8        q     d         .
rest   8        q
F#3    8        q     d         .
rest   8        q
measure 92
B2    12        q.    u         f
P    C33:Y62
gC#3   4        t     u  [[[   (
gB2    4        t     u  ===
gA#2   4        t     u  ]]]
B2     4        e     u        ).
D3     4        e     u  [     (
A#2    4        e #   u  =
B2     4        e     u  =     )
E3     4        e     u  ]      .
measure 93
D3     4        e     u  [     (
A#2    4        e #   u  =
B2     4        e     u  ]     )
rest   4        e
rest  16        h
measure 94
rest  32
measure 95
B3     4        e     d  [      p
P    C33:Y57
F#3    4        e     d  =
D4     4        e     d  =
F#3    4        e     d  ]
C#4    4        e     d  [
F#3    4        e     d  =
A#3    4        e #   d  =
F#3    4        e     d  ]
measure 96
B3     4        e     d  [
F#3    4        e     d  =
*               D       cresc.
P  C25:f33  C17:Y68
D4     4        e     d  =
F#3    4        e     d  ]
C#4    4        e     d  [
F#3    4        e     d  =
A#3    4        e #   d  =
F#3    4        e     d  ]
measure 97
B3     8        q     d
rest   8        q
D3     8        q     d
rest   8        q
measure 98
E3     4        e     d  [      f
P    C33:Y68
E3     4        e     d  =
E3     4        e     d  =
E3     4        e     d  ]
E3     4        e     d  [
E3     4        e     d  =
E3     4        e     d  =
E3     4        e     d  ]
measure 99
E#3    4        e #   d  [
E#3    4        e     d  =
E#3    4        e     d  =
E#3    4        e     d  ]
E#3    4        e     d  [
E#3    4        e     d  =
E#3    4        e     d  =
E#3    4        e     d  ]
measure 100
F#3    4        e     d  [      Z
P    C33:Y66
F#3    4        e     d  =
F#3    4        e     d  =
F#3    4        e     d  ]
F#3    4        e     d  [
F#3    4        e     d  =
F#3    4        e     d  =
F#3    4        e     d  ]
measure 101
F#2    4        e     u  [
F#2    4        e     u  =
F#2    4        e     u  =
F#2    4        e     u  ]
F#2    4        e     u  [
F#2    4        e     u  =
F#2    4        e     u  =
F#2    4        e     u  ]
measure 102
B2     8        q     u
rest   8        q
rest  16        h
measure 103
rest   8        q
G3     4        e     d  [      .mf
P    C34:Y64
G3     4        e     d  ]      .
F#3    4        e     d         .
rest   4        e
F#2    4        e     u         .
rest   4        e
measure 104
B2     4        e     d  [      .
B3     4        e     d  ]      .
rest   4        e
B3     4        e     d         .
rest   4        e
F#3    4        e     d         .
rest   4        e
F#3    4        e     d         .
measure 105
rest   4        e
B3     4        e     d         .
rest   4        e
E3     4        e     d         .
rest   4        e
F#3    4        e     d         .
rest   4        e
F#3    4        e     d         .
measure 106
B2     4        e     u         .
rest   4        e
rest   8        q
rest   8        q
F#3    4        e     d         .
rest   4        e
measure 107
B2     4        e     u         .
rest   4        e
rest   8        q
F#2    4        e     u         .
rest   4        e
F#2    4        e     u         .f
P    C34:Y79
rest   4        e
measure 108
B2     8        q     u
rest   8        q
rest  16        h
mheavy2                      :|
/END
/eof
//
