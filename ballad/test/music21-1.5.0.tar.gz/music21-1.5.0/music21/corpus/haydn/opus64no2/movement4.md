&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/04/01} [KHM:1635258311]
TIMESTAMP: DEC/26/2001 [md5sum:dc63d799a39af2e8ec03720f59778efc]
11/21/94 W Hewlett
WK#:64,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Finale
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:8   T:2/4  C:4  D:Presto
F#4    4        e     u  [
F#4    4        e     u  ]
measure 1
B4     6        e.    d  [
C#5    2        s     d  ]\
D5     4        e     d  [
D5     4        e     d  ]
measure 2
D5     4        e     d
rest   4        e
F#5    4        e     d  [
F#5    4        e     d  ]
measure 3
C#5    6        e.    d  [
D5     2        s     d  ]\
C#5    4        e     d  [
C#5    4        e     d  ]
measure 4
C#5    4        e     d
rest   4        e
A5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
G5     2        s     d  ]]
measure 5
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 6
D5     4        e     d  [
B4     4        e     d  ]
A5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
G5     2        s     d  ]]
measure 7
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 8
D5     4        e     u  [
B4     4        e     u  =
B3     4        e     u  =
B3     4        e     u  ]
measure 9
C4     4        e n   u  [
E4     2        s     u  ]\
rest   2        s
D#4    4        e #   u  [
F#4    2        s     u  ]\
rest   2        s
measure 10
E4     4        e     u  [
G4     2        s     u  ]\
rest   2        s
F#4    2        s     u  [[
G#4    2        s #   u  ==
A#4    2        s #   u  ==
F#4    2        s     u  ]]
measure 11
B4     4        e     d  [
D5     4        e     d  =
C#5    4        e     d  =
F#5    4        e     d  ]
measure 12
B4     4        e     d
rest   4        e
F#4    4        e     u  [
F#4    4        e     u  ]
measure 13
B4     6        e.    d  [
C#5    2        s     d  ]\
D5     4        e     d  [
D5     4        e     d  ]
measure 14
D5     4        e     d
rest   4        e
D4     4        e     u  [
D4     4        e     u  ]
measure 15
C4     4        e n   u  [
B3     4        e     u  =
C4     4        e     u  =
A#3    4        e #   u  ]
measure 16
B3     4        e     u  [
G3     4        e     u  =
D#4    4        e #   u  =
D#4    4        e     u  ]
measure 17
E4     2        s     u  [[
F#4    2        s     u  ==
G4     2        s     u  ==
F#4    2        s     u  ]]
A4     2        s     u  [[
G4     2        s     u  ==
B4     2        s     u  ==
A4     2        s     u  ]]
measure 18
C5     2        s n   d  [[
B4     2        s     d  ==
E5     2        s     d  ==
D#5    2        s #   d  ]]
F#5    2        s     d  [[
E5     2        s     d  ==
G5     2        s     d  ==
F#5    2        s     d  ]]
measure 19
A5     2        s     d  [[
G5     2        s     d  ==
B5     2        s     d  ==
A5     2        s     d  ]]
G5     2        s     d  [[
F#5    2        s     d  ==
E5     2        s     d  ==
D5     2        s     d  ]]
measure 20
C#5    4        e     d
rest   4        e
A5     4        e     d  [
A5     4        e     d  ]
measure 21
D6     6        e.    d  [
C#6    1        t     d  =[[
B5     1        t     d  ]]]
A5     4        e     d  [
A5     4        e     d  ]
measure 22
A5     4        e     d
rest   4        e
E6     4        e     d  [
E6     4        e     d  ]
measure 23
C#6    4        e     d  [
C#6    4        e     d  =
G5     4        e     d  =
G5     4        e     d  ]
measure 24
F#5    4        e     d  [
D5     4        e     d  =
A5     4        e     d  =
A5     4        e     d  ]
measure 25
D6     6        e.    d  [
C#6    1        t     d  =[[
B5     1        t     d  ]]]
A5     4        e     d  [
A5     4        e     d  ]
measure 26
A5     4        e     d
rest   4        e
D#6    2        s #   d  [[
E6     2        s     d  ==
D#6    2        s     d  ==
E6     2        s     d  ]]
measure 27
B#5    2        s #   d  [[
C#6    2        s     d  ==
B#5    2        s     d  ==
C#6    2        s     d  ]]
F#5    2        s     d  [[
G5     2        s     d  ==
F#5    2        s     d  ==
G5     2        s     d  ]]
measure 28
F#5    4        e     d  [
D5     4        e     d  ]
D4     2        s     u  [[
E4     2        s     u  ==
F#4    2        s     u  ==
D4     2        s     u  ]]
measure 29
E4     2        s     u  [[
F#4    2        s     u  ==
G4     2        s     u  ==
E4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ]]
measure 30
G4     2        s     u  [[
A4     2        s     u  ==
B4     2        s     u  ==
G4     2        s     u  ]]
D4     4        e     u  [
D5     4        e     u  ]
measure 31
rest   4        e
E5     4        e     d
rest   4        e
F#5    4        e     d
measure 32
rest   4        e
F#5    2        s     d  [[
G5     2        s     d  ]]
B5     4        e     d  [
B5     4        e     d  ]
measure 33
B5    16-       h     d        -
measure 34
B5     4        e     d  [
F#5    2        s     d  =[
G5     2        s     d  ]]
B5     4        e     d  [
B5     4        e     d  ]
measure 35
B5    16-       h     d        -
measure 36
B5     4        e     d  [
F#5    2        s     d  =[
G5     2        s     d  ]]
B5     4        e     d  [
B5     4        e     d  ]
measure 37
B5     4        e     d  [
A5     2        s     d  =[
C#6    2        s     d  ]]
E6     4        e     d  [
E6     4        e     d  ]
measure 38
E6     4        e     d  [
C#6    2        s     d  =[
E6     2        s     d  ]]
G6     4        e     d  [
G6     4        e     d  ]
measure 39
G6    12        q.    d
E6     4        e     d
measure 40
F#6    4        e     d  [
D6     2        s     d  =[
F#6    2        s     d  ]]
A6     4        e     d  [
A6     4        e     d  ]
measure 41
A6    12        q.    d
A5     4        e     d
measure 42
B5     4        e     d  [
G5     2        s     d  =[
B5     2        s     d  ]]
D6     4        e     d  [
B5     2        s     d  =[
D6     2        s     d  ]]
measure 43
G6     4        e     d  [
G6     4        e     d  =
F#6    4        e     d  =
E6     4        e     d  ]
measure 44
F#6    2        s     d  [[
D6     2        s     d  ==
G6     2        s     d  ==
E6     2        s     d  ]]
A6     4        e     d  [
A6     4        e     d  ]
measure 45
E6    16        h     d
measure 46
D6     4        e     d
rest   4        e
A3     4        e     u  [
A3     4        e     u  ]
measure 47
B3     6        e.    u  [
C#4    2        s     u  ]\
D4     4        e     u  [
D4     4        e     u  ]
measure 48
A3     8        q     u
A4     4        e     u  [
A4     4        e     u  ]
measure 49
A4     6        e.    u  [
G4     2        s     u  ]\
F#4    4        e     u  [
E4     4        e     u  ]
measure 50
G4     4        e     u  [
F#4    4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
measure 51
B3     6        e.    u  [
C#4    2        s     u  ]\
D4     4        e     u  [
D4     4        e     u  ]
measure 52
A3     8        q     u
C#4    2        s     u  [[
D4     2        s     u  ==
F#4    2        s     u  ==
D4     2        s     u  ]]
measure 53
B3     4        e     u  [
B3     4        e     u  ]
C#4    2        s     u  [[
D4     2        s     u  ==
F#4    2        s     u  ==
D4     2        s     u  ]]
measure 54
A3     4        e     u  [
A3     4        e     u  ]
C#4    2        s     u  [[
D4     2        s     u  ==
F#4    2        s     u  ==
D4     2        s     u  ]]
measure 55
G3     2        s     u  [[
G4     2        s     u  ==
B4     2        s     u  ==
A4     2        s     u  ]]
G4     2        s     u  [[
F#4    2        s     u  ==
E4     2        s     u  ==
D4     2        s     u  ]]
measure 56
C#4    2        s     u  [[
E4     2        s     u  ==
E5     2        s     u  ==
D5     2        s     u  ]]
C#5    2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]
measure 57
F#4    2        s     d  [[
A5     2        s     d  ==
G5     2        s     d  ==
F#5    2        s     d  ]]
E5     2        s     d  [[
D5     2        s     d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
measure 58
A4     2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[
C#4    2        s     u  ==
B3     2        s     u  ==
A3     2        s     u  ]]
measure 59
G3     4        e     u  [
G3     4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
measure 60
D4     4        e     u
rest   4        e
F#4    4        e     u  [
F#4    4        e     u  ]
measure 61
rest   8        q
A4     4        e     u  [
A4     4        e     u  ]
measure 62
rest   8        q
D5     4        e     d  [
D5     4        e     d  ]
measure 63
rest   8        q
F#5    4        e     d  [
F#5    4        e     d  ]
measure 64
rest   8        q
mheavy4                  :|:
A5     4        e     d  [
A5     4        e     d  ]
measure 65
A5     6        e.    d  [
B5     2        s     d  ]\
C6     4        e n   d  [
C6     4        e     d  ]
measure 66
B5     4        e     d
rest   4        e
G4     4        e     u  [
G4     4        e     u  ]
measure 67
D4     6        e.    u  [
E4     2        s     u  ]\
D4     2        s     u  [[
C4     2        s n   u  ==
B3     2        s     u  ==
A3     2        s     u  ]]
measure 68
G3     4        e     u
rest   4        e
F#5    4        e     d  [
F#5    4        e     d  ]
measure 69
F#5    6        e.    d  [
G5     2        s     d  ]\
A5     4        e     d  [
A5     4        e     d  ]
measure 70
G5     4        e     d
rest   4        e
E5     4        e     d  [
E5     4        e     d  ]
measure 71
B4     6        e.    d  [
C5     2        s n   d  ]\
B4     2        s     u  [[
A4     2        s     u  ==
G4     2        s     u  ==
F#4    2        s     u  ]]
measure 72
E4     4        e     u
rest   4        e
G5     4        e     d  [
G5     4        e     d  ]
measure 73
G5     4        e     d  [
A#4    4        e #   d  =
F#5    4        e     d  =
F#5    4        e     d  ]
measure 74
F#5    4        e     d  [
B4     4        e     d  =
A5     4        e     d  =
A5     4        e     d  ]
measure 75
A5     4        e     d  [
B#4    4        e #   d  =
G#5    4        e #   d  =
G#5    4        e     d  ]
measure 76
G#5    4        e #   d  [
C#5    4        e     d  ]
rest   8        q
measure 77
rest  16
measure 78
rest   8        q
C#4    4        e     u  [
C#4    4        e     u  ]
measure 79
F#4    6        e.    u  [
G#4    2        s #   u  ]\
A4     4        e     u  [
A4     4        e     u  ]
measure 80
A4     4        e     u
rest   4        e
C#5    4        e     d  [
C#5    4        e     d  ]
measure 81
G#4    6        e.#   u  [
A4     2        s     u  ]\
G#4    4        e     u  [
G#4    4        e     u  ]
measure 82
G#4    4        e #   u
rest   4        e
C#5    4        e     d  [
C#5    4        e     d  ]
measure 83
F##4   6        e.x   u  [
G#4    2        s #   u  ]\
F##4   4        e     u  [
F##4   4        e     u  ]
measure 84
F##4   4        e x   u
rest   4        e
E5     4        e     d  [
E5     4        e     d  ]
measure 85
E5     4        e     d  [
F##4   4        e x   d  =
E5     4        e     d  =
E5     4        e     d  ]
measure 86
E5     4        e     d  [
F##4   4        e x   d  ]
rest   8        q
measure 87
rest  16
measure 88
rest   8        q
D#4    4        e #   u  [
D#4    4        e     u  ]
measure 89
G#4    6        e.#   u  [
A#4    2        s #   u  ]\
B4     4        e     d  [
B4     4        e     d  ]
measure 90
B4     4        e     d
rest   4        e
B3     4        e     u  [
B3     4        e     u  ]
measure 91
F#4    6        e.    u  [
G#4    2        s #   u  ]\
A4     4        e     u  [
A4     4        e     u  ]
measure 92
A4     4        e     u
rest   4        e
rest   8        q
measure 93
rest  16
measure 94
rest   8        q
B4     4        e     d  [
B4     4        e     d  ]
measure 95
E5     6        e.    d  [
F#5    2        s     d  ]\
G5     4        e     d  [
G5     4        e     d  ]
measure 96
G5     4        e     d
rest   4        e
G3     4        e     u  [
G3     4        e     u  ]
measure 97
D4     6        e.    u  [
E4     2        s     u  ]\
F4     4        e n   u  [
F4     4        e     u  ]
measure 98
F4     4        e n   u
rest   4        e
G5     4        e     d  [
G5     4        e     d  ]
measure 99
B4     4        e     d
rest   4        e
G5     4        e     d  [
G5     4        e     d  ]
measure 100
C5     4        e n   d
rest   4        e
G5     4        e     d  [
G5     4        e     d  ]
measure 101
G#5    4        e #   d
rest   4        e
G#5    4        e     d  [
G#5    4        e     d  ]
measure 102
A5     4        e     d
rest   4        e
A5     4        e     d  [
A5     4        e     d  ]
measure 103
C#5    4        e     d
rest   4        e
A5     4        e     d  [
A5     4        e     d  ]
measure 104
D5     4        e     d
rest   4        e
A5     4        e     d  [
A5     4        e     d  ]
measure 105
A#5    8        q #   d
A#5    4        e     d  [
A#5    4        e     d  ]
measure 106
B5     4        e     d
rest   4        e
B5     4        e     d  [
B5     4        e     d  ]
measure 107
B5     4        e     d
rest   4        e
B5     4        e     d  [
B5     4        e     d  ]
measure 108
B3     4        e     u
rest   4        e
B5     4        e     d  [
B5     4        e     d  ]
measure 109
D#4    4        e #   u
rest   4        e
B5     4        e     d  [
B5     4        e     d  ]
measure 110
B3     4        e     u
rest   4        e
B5     4        e     d  [
B5     4        e     d  ]
measure 111
B5     6        e.    d  [
C#6    2        s     d  ]\
D6     4        e     d  [
D6     4        e     d  ]
measure 112
D6     8        q     d
E#5    4        e #   d  [
E#5    4        e     d  ]
measure 113
F#5    6        e.    d  [
A5     2        s     d  ]\
C#6    4        e     d  [
C#6    4        e     d  ]
measure 114
C#6    4        e     d
rest   4        e
C#6    4        e     d  [
C#6    4        e     d  ]
measure 115
B#5    6        e.#   d  [
D#6    2        s #   d  ]\
F#6    4        e     d  [
F#6    4        e     d  ]
measure 116
F#6    4        e     d
rest   4        e
B#5    4        e #   d  [
B#5    4        e     d  ]
measure 117
C#6    6        e.    d  [
D#6    2        s #   d  ]\
E6     4        e     d  [
E6     4        e     d  ]
measure 118
E6     4        e     d
rest   4        e
G#5    4        e #   d  [
G#5    4        e     d  ]
measure 119
F#5    2        s     d  [[
G#5    2        s #   d  ==
A5     2        s     d  ==
F#5    2        s     d  ]]
D#5    2        s #   d  [[
E5     2        s     d  ==
F#5    2        s     d  ==
D#5    2        s     d  ]]
measure 120
E5     2        s     d  [[
F#5    2        s     d  ==
G#5    2        s #   d  ==
E5     2        s     d  ]]
C#5    2        s     d  [[
D#5    2        s #   d  ==
E5     2        s     d  ==
C#5    2        s     d  ]]
measure 121
B#4    2        s #   d  [[
C#5    2        s     d  ==
D#5    2        s #   d  ==
B#4    2        s     d  ]]
F#4    2        s     u  [[
G#4    2        s #   u  ==
A4     2        s     u  ==
F#4    2        s     u  ]]
measure 122
E4     2        s     u  [[
F#4    2        s     u  ==
G#4    2        s #   u  ==
E4     2        s     u  ]]
C#4    2        s     u  [[
D#4    2        s #   u  ==
E4     2        s     u  ==
C#4    2        s     u  ]]
measure 123
B#3    2        s #   u  [[
C#4    2        s     u  ==
D#4    2        s #   u  ==
B#3    2        s     u  ]]
G#3    4        e #   u  [
G#3    4        e     u  ]
measure 124
G#3    8        q #   u
rest   8        q
measure 125
A3    16-       h     u        -
measure 126
A3     8        q     u
E4     4        e     u  [
E4     4        e     u  ]
measure 127
F#4    6        e.    u  [
G4     2        s     u  ]\
A4     4        e     u  [
A4     4        e     u  ]
measure 128
A4     4        e     u
rest   4        e
F#4    4        e     u  [
F#4    4        e     u  ]
measure 129
E4     6        e.    u  [
F#4    2        s     u  ]\
G4     4        e     u  [
G4     4        e     u  ]
measure 130
G4     4        e     u
rest   4        e
rest   8        q
measure 131
rest  16
measure 132
rest   8        q
F#4    4        e     u  [
F#4    4        e     u  ]
measure 133
B4     6        e.    d  [
C#5    2        s     d  ]\
D5     4        e     d  [
D5     4        e     d  ]
measure 134
D5     4        e     d
rest   4        e
F#5    4        e     d  [
F#5    4        e     d  ]
measure 135
C#5    6        e.    d  [
D5     2        s     d  ]\
C#5    4        e     d  [
C#5    4        e     d  ]
measure 136
C#5    4        e     d
rest   4        e
A5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
G5     2        s     d  ]]
measure 137
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 138
D5     4        e     d  [
B4     4        e     d  ]
A5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
G5     2        s     d  ]]
measure 139
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 140
D5     4        e     d  [
B4     4        e     d  ]
rest   8        q
measure 141
rest  16
measure 142
rest  16
measure 143
rest  16
measure 144
rest   8        q
C#5    2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
C#5    2        s     d  ]]
measure 145
D5     4        e     d
rest   4        e
D#5    2        s #   d  [[
E5     2        s     d  ==
F#5    2        s     d  ==
D#5    2        s     d  ]]
measure 146
E5     2        s     d  [[
F#5    2        s     d  ==
G5     2        s     d  ==
E5     2        s     d  ]]
F#5    2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
F#5    2        s     d  ]]
measure 147
G5     2        s     d  [[
A5     2        s     d  ==
B5     2        s     d  ==
G5     2        s     d  ]]
A#5    2        s #   d  [[
B5     2        s     d  ==
C#6    2        s     d  ==
A#5    2        s     d  ]]
measure 148
B5     2        s     d  [[
C#6    2        s     d  ==
D6     2        s     d  ==
B5     2        s     d  ]]
F#5    4        e     d  [
F#5    4        e     d  ]
measure 149
B5     2        s     d  [[
C#6    2        s     d  ==
D6     2        s     d  ==
B5     2        s     d  ]]
F#5    4        e     d  [
F#5    4        e     d  ]
measure 150
G5     2        s     d  [[
A5     2        s     d  ==
B5     2        s     d  ==
G5     2        s     d  ]]
E5     2        s     d  [[
F#5    2        s     d  ==
G5     2        s     d  ==
E5     2        s     d  ]]
measure 151
C#5    2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
C#5    2        s     d  ]]
A#4    2        s #   d  [[
B4     2        s     d  ==
C#5    2        s     d  ==
A#4    2        s     d  ]]
measure 152
B4     2        s     d  [[
C#5    2        s     d  ==
D5     2        s     d  ==
B4     2        s     d  ]]
E#4    4        e #   u  [
E#4    4        e     u  ]
measure 153
B4     2        s     d  [[
C#5    2        s     d  ==
D5     2        s     d  ==
B4     2        s     d  ]]
E#4    4        e #   u  [
E#4    4        e     u  ]
measure 154
rest   8        q
F#4    4        e     u  [
F#4    4        e     u  ]
measure 155
rest   8        q
F#4    4        e     u  [
F#4    4        e     u  ]
measure 156
rest   8        q
F#4    4        e     u  [
F#4    4        e     u  ]
measure 157
rest   8        q
F#4    4        e     u  [
F#4    4        e     u  ]
mdouble 158
$      K:5
B4     6        e.    d  [
C#5    2        s     d  ]\
D#5    4        e #   d  [
D#5    4        e     d  ]
measure 159
D#5    4        e #   d
rest   4        e
F#5    4        e     d  [
F#5    4        e     d  ]
measure 160
C#5    6        e.    d  [
D#5    2        s #   d  ]\
C#5    4        e     d  [
C#5    4        e     d  ]
measure 161
C#5    4        e     d
rest   4        e
F##5   2        s x   d  [[
G#5    2        s #   d  ==
F##5   2        s     d  ==
G#5    2        s     d  ]]
measure 162
F#5    2        s     d  [[
E5     2        s     d  ==
D#5    2        s #   d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 163
D#5    4        e #   d  [
B4     4        e     d  ]
F##5   2        s x   d  [[
G#5    2        s #   d  ==
F##5   2        s     d  ==
G#5    2        s     d  ]]
measure 164
F#5    2        s     d  [[
E5     2        s     d  ==
D#5    2        s #   d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A#4    2        s #   d  ==
C#5    2        s     d  ==
E5     2        s     d  ]]
measure 165
D#5    4        e #   d  [
B4     4        e     d  ]
D#4    4        e #   u  [
B3     2        s     u  ]\
rest   2        s
measure 166
E4     4        e     u  [
C#4    2        s     u  ]\
rest   2        s
F#4    4        e     u  [
D#4    2        s #   u  ]\
rest   2        s
measure 167
G#4    4        e #   u  [
E4     2        s     u  ]\
rest   2        s
E5     2        s     d  [[
D#5    2        s #   d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
measure 168
A#4    4        e #   u  [
A#4    4        e     u  ]
G#5    2        s #   d  [[
F#5    2        s     d  ==
E5     2        s     d  ==
D#5    2        s #   d  ]]
measure 169
C#5    4        e     d  [
C#5    4        e     d  ]
A#5    2        s #   d  [[
C#6    2        s     d  ==
E6     2        s     d  ==
C#6    2        s     d  ]]
measure 170
A#5    4        e #   d  [
A#5    4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
measure 171
D#5    4        e #   d  [
D#5    4        e     d  =
G#5    4        e #   d  =
G#5    4        e     d  ]
measure 172
F#5    4        e     d  [
F#5    4        e     d  =
A#4    4        e #   d  =
A#4    4        e     d  ]
measure 173
B4     4        e     d
rest   4        e
F#4    4        e     u  [
F#4    4        e     u  ]
measure 174
G#4    6        e.#   u  [
A#4    2        s #   u  ]\
B4     4        e     d  [
B4     4        e     d  ]
measure 175
F#4    4        e     u
rest   4        e
F#5    4        e     d  [
F#5    4        e     d  ]
measure 176
F#5    6        e.    d  [
E5     2        s     d  ]\
D#5    4        e #   d  [
C#5    4        e     d  ]
measure 177
D#5    4        e #   u  [
B4     4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]
measure 178
G#4    6        e.#   u  [
A#4    2        s #   u  ]\
B4     4        e     d  [
B4     4        e     d  ]
measure 179
F#4    4        e     u
rest   4        e
A#4    2        s #   d  [[
B4     2        s     d  ==
D#5    2        s #   d  ==
B4     2        s     d  ]]
measure 180
G#4    4        e #   u  [
G#4    4        e     u  ]
A#4    2        s #   d  [[
B4     2        s     d  ==
D#5    2        s #   d  ==
B4     2        s     d  ]]
measure 181
F#4    4        e     u  [
F#4    4        e     u  ]
A#4    2        s #   d  [[
B4     2        s     d  ==
D#5    2        s #   d  ==
B4     2        s     d  ]]
measure 182
E4     4        e     u  [
E4     4        e     u  ]
A#4    2        s #   d  [[
B4     2        s     d  ==
D#5    2        s #   d  ==
B4     2        s     d  ]]
measure 183
D#4    4        e #   u  [
F#4    4        e     u  =
B4     4        e     u  =
D#5    4        e #   u  ]
measure 184
F#5    4        e     d  [
B5     4        e     d  =
D#6    4        e #   d  =
B5     4        e     d  ]
measure 185
F##5   2        s x   d  [[
G#5    2        s #   d  ==
F##5   2        s     d  ==
G#5    2        s     d  ]]
A#5    2        s #   d  [[
B5     2        s     d  ==
A#5    2        s     d  ==
B5     2        s     d  ]]
measure 186
F##5   2        s x   d  [[
G#5    2        s #   d  ==
F##5   2        s     d  ==
G#5    2        s     d  ]]
D#5    2        s #   d  [[
E5     2        s     d  ==
B#4    2        s #   d  ==
C#5    2        s     d  ]]
measure 187
F#4   16        h     u
measure 188
C#5   16        h     d
measure 189
B4     2        s     d  [[
F#5    2        s     d  ==
G#5    2        s #   d  ==
F#5    2        s     d  ]]
E5     2        s     d  [[
D#5    2        s #   d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
measure 190
A#4    2        s #   d  [[
C#5    2        s     d  ==
E5     2        s     d  ==
G#5    2        s #   d  ]]
F#5    2        s     d  [[
E5     2        s     d  ==
D#5    2        s #   d  ==
C#5    2        s     d  ]]
measure 191
B4     2        s     d  [[
F#5    2        s     d  ==
G#5    2        s #   d  ==
F#5    2        s     d  ]]
E5     2        s     d  [[
D#5    2        s #   d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
measure 192
A#4    2        s #   d  [[
C#5    2        s     d  ==
E5     2        s     d  ==
G#5    2        s #   d  ]]
F#5    2        s     d  [[
E5     2        s     d  ==
D#5    2        s #   d  ==
C#5    2        s     d  ]]
measure 193
B4     4        e     d
rest   4        e
D#5    4        e #   d  [
D#5    4        e     d  ]
measure 194
rest   8        q
F#5    4        e     d  [
F#5    4        e     d  ]
measure 195
rest   8        q
B5     4        e     d  [
B5     4        e     d  ]
measure 196
rest   8        q
D#6    4        e #   d  [
D#6    4        e     d  ]
measure 197
rest   8        q
F#6    4        e     d  [
F#6    4        e     d  ]
measure 198
rest   8        q
B6     4        e     d  [
B6     4        e     d  ]
measure 199
B6     8        q     d
rest   8        q
measure 200
rest  16
measure 201
rest   8        q
mheavy2                        :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/04/02} [KHM:1635258311]
TIMESTAMP: DEC/26/2001 [md5sum:5550cce5609757f7cca19a05025f4142]
11/21/94 W Hewlett
WK#:64,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Finale
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:4   T:2/4  C:4  D:Presto
rest   4        q
measure 1
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
measure 2
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
measure 3
rest   2        e
G4     1        s     u  [[
F#4    1        s     u  ]]
G4     2        e     u  [
E4     2        e     u  ]
measure 4
C#4    2        e     u
rest   2        e
rest   4        q
measure 5
E4     6        q.    u
 A#3   6        q.#   u
A#3    2        e     u
measure 6
B3     2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 7
E4     6        q.    u
 A#3   6        q.#   u
A#3    2        e     u
measure 8
B3     2        e     u  [
D4     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 9
C4     2        e n   u  [
E4     1        s     u  ]\
rest   1        s
D#4    2        e #   u  [
F#4    1        s     u  ]\
rest   1        s
measure 10
E4     2        e     u  [
G4     1        s     u  ]\
rest   1        s
F#4    1        s     u  [[
G#4    1        s #   u  ==
A#4    1        s #   u  ==
F#4    1        s     u  ]]
measure 11
B4     2        e     d  [
D5     1        s     d  ]\
rest   1        s
C#5    2        e     d  [
F#5    2        e     d  ]
measure 12
B4     2        e     d
rest   2        e
rest   4        q
measure 13
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
measure 14
D4     4        q     u
rest   4        q
measure 15
rest   8
measure 16
rest   4        q
C4     2        e n   u  [
C4     2        e     u  ]
measure 17
B3     4        q     u
rest   4        q
measure 18
rest   8
measure 19
B4     8        h     d
measure 20
E4     4        q     u
rest   4        q
measure 21
F#4    3        e.    u  [
G4     1        s     u  ]\
A4     2        e     u  [
F#4    2        e     u  ]
measure 22
G4     8-       h     u        -
 A3    8-       h     u        -
measure 23
G4     6        q.    u
 A3    6        q.    u
E4     2        e     u
measure 24
F#4    4        q     u
rest   4        q
measure 25
F#4    3        e.    u  [
G4     1        s     u  ]\
A4     2        e     u  [
F#4    2        e     u  ]
measure 26
G4     8-       h     u        -
 A3    8-       h     u        -
measure 27
G4     6        q.    u
 A3    6        q.    u
E4     2        e     u
measure 28
F#4    2        e     u
rest   2        e
rest   4        q
measure 29
rest   8
measure 30
rest   4        q
D4     1        s     u  [[
E4     1        s     u  ==
F#4    1        s     u  ==
D4     1        s     u  ]]
measure 31
E4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
F#4    1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
F#4    1        s     u  ]]
measure 32
G4     2        e     u
rest   2        e
G5     2        e     d  [
G5     2        e     d  ]
measure 33
G5     8-       h     d        -
measure 34
G5     2        e     d  [
D#5    1        s #   d  =[
E5     1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
measure 35
G5     8-       h     d        -
measure 36
G5     4        q     d
rest   4        q
measure 37
G5     4        q     d
rest   4        q
measure 38
rest   2        e
A4     1        s     d  [[
C#5    1        s     d  ]]
E5     2        e     d  [
E5     2        e     d  ]
measure 39
E5     2        e     d  [
C#5    2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 40
A4     4        q     u
rest   2        e
F#4    1        s     u  [[
A4     1        s     u  ]]
measure 41
D5     2        e     d  [
A4     1        s     d  =[
D5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 42
B4     8-       h     d        -
measure 43
B4     4        q     d
rest   4        q
measure 44
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]
measure 45
C#5    8        h     d
measure 46
D5     4        q     d
rest   4        q
measure 47
rest   8
measure 48
rest   4        q
A3     4        q     u
measure 49
B3     4        q     u
C#4    4        q     u
measure 50
C#4    2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 51
rest   4        q
B3     2        e     u  [
B3     2        e     u  ]
measure 52
A3     4        q     u
rest   4        q
measure 53
D4     4        q     u
rest   4        q
measure 54
D4     4        q     u
rest   4        q
measure 55
G4     4        q     u
rest   4        q
measure 56
G4     4        q     u
rest   4        q
measure 57
F#4    4        q     u
rest   4        q
measure 58
rest   4        q
rest   2        e
D4     2        e     u
measure 59
G3     2        e     u  [
G3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 60
A3     2        e     u  [
A3     2        e     u  ]
rest   4        q
measure 61
A3     2        e     u  [
A3     2        e     u  ]
rest   4        q
measure 62
A3     2        e     u  [
A3     2        e     u  ]
rest   4        q
measure 63
A3     2        e     u  [
A3     2        e     u  ]
rest   4        q
measure 64
A3     2        e     u  [
A3     2        e     u  =
mheavy4                  :|:
D5     2        e     u  =
D5     2        e     u  ]
measure 65
D5     6        q.    d
F#4    2        e     u
measure 66
G4     2        e     u
rest   2        e
G4     2        e     u  [
G4     2        e     u  ]
measure 67
D4     3        e.    u  [
E4     1        s     u  ]\
D4     1        s     u  [[
C4     1        s n   u  ==
B3     1        s     u  ==
A3     1        s     u  ]]
measure 68
G3     2        e     u
rest   2        e
B4     2        e     d  [
B4     2        e     d  ]
measure 69
B4     6        q.    d
D#4    2        e #   u
measure 70
E4     2        e     u
rest   2        e
E5     2        e     d  [
E5     2        e     d  ]
measure 71
B4     3        e.    d  [
C5     1        s n   d  ]\
B4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
measure 72
E4     2        e     u
rest   2        e
A#4    2        e #   u  [
A#4    2        e     u  ]
measure 73
A#4    2        e #   u
rest   2        e
B4     2        e     d  [
B4     2        e     d  ]
measure 74
B4     2        e     d
rest   2        e
B#4    2        e #   d  [
B#4    2        e     d  ]
measure 75
B#4    2        e #   d
rest   2        e
C#5    2        e     d  [
C#5    2        e     d  ]
measure 76
C#5    2        e     d
rest   2        e
rest   4        q
measure 77
rest   8
measure 78
rest   4        q
C#4    2        e     u  [
C#4    2        e     u  ]
measure 79
A3     2        e     u  [
C#4    1        s     u  =[
B3     1        s     u  ]]
A3     2        e     u  [
A3     2        e     u  ]
measure 80
rest   2        e
C#4    1        s     u  [[
B3     1        s     u  ]]
A3     2        e     u  [
A3     2        e     u  ]
measure 81
rest   2        e
D4     1        s     u  [[
C#4    1        s     u  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 82
C#4    1        s     u  [[
D#4    1        s #   u  ==
C#4    1        s     u  ==
B#3    1        s #   u  ]]
C#4    1        s     u  [[
B#3    1        s     u  ==
C#4    1        s     u  ==
B#3    1        s     u  ]]
measure 83
C#4    1        s     u  [[
D#4    1        s #   u  ==
C#4    1        s     u  ==
B#3    1        s #   u  ]]
C#4    1        s     u  [[
B#3    1        s     u  ==
C#4    1        s     u  ==
B#3    1        s     u  ]]
measure 84
C#4    1        s     u  [[
D#4    1        s #   u  ==
C#4    1        s     u  ==
B#3    1        s #   u  ]]
C#4    1        s     u  [[
B#3    1        s     u  ==
C#4    1        s     u  ==
B#3    1        s     u  ]]
measure 85
C#4    2        e     u
rest   2        e
rest   4        q
measure 86
C#4    4        q     u
rest   4        q
measure 87
rest   8
measure 88
rest   4        q
D#4    2        e #   u  [
D#4    2        e     u  ]
measure 89
G#4    3        e.#   u  [
A#4    1        s #   u  ]\
B4     2        e     d  [
B4     2        e     d  ]
measure 90
B4     2        e     d
rest   2        e
rest   4        q
measure 91
F#4    8-       h     u        -
measure 92
F#4    2        e     u
rest   2        e
rest   4        q
measure 93
rest   8
measure 94
rest   4        q
B4     2        e     d  [
B4     2        e     d  ]
measure 95
E5     3        e.    d  [
F#5    1        s     d  ]\
G5     2        e     d  [
G5     2        e     d  ]
measure 96
G5     2        e     d
rest   2        e
rest   4        q
measure 97
D4     8-       h     u        -
measure 98
D4     2        e     u
rest   2        e
rest   4        q
measure 99
G4     2        e     u  [
G4     2        e     u  ]
rest   4        q
measure 100
G4     2        e     u  [
G4     2        e     u  ]
rest   4        q
measure 101
F4     2        e n   u  [
F4     2        e     u  ]
rest   4        q
measure 102
E4     2        e     u  [
E4     2        e     u  ]
rest   4        q
measure 103
A4     2        e     u  [
A4     2        e     u  ]
rest   4        q
measure 104
A4     2        e     u  [
A4     2        e     u  ]
rest   4        q
measure 105
G4     2        e     u  [
G4     2        e     u  ]
rest   4        q
measure 106
F#4    2        e     d  [
F#4    2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]
measure 107
G5     3        e.    d  [
F#5    1        s     d  ]\
E5     2        e     d  [
E5     2        e     d  ]
measure 108
E5     2        e     d
rest   2        e
G5     2        e     d  [
G5     2        e     d  ]
measure 109
A5     3        e.    d  [
G5     1        s     d  ]\
F#5    2        e     d  [
F#5    2        e     d  ]
measure 110
F#5    2        e     d
rest   2        e
F#5    2        e     d  [
F#5    2        e     d  ]
measure 111
G#5    3        e.#   d  [
F#5    1        s     d  ]\
E#5    2        e #   d  [
E#5    2        e     d  ]
measure 112
E#5    4        q #   d
G#4    2        e #   u  [
G#4    2        e     u  ]
measure 113
F#4    1        s     u  [[
G#4    1        s #   u  ==
F#4    1        s     u  ==
E#4    1        s #   u  ]]
F#4    1        s     u  [[
E#4    1        s     u  ==
F#4    1        s     u  ==
E#4    1        s     u  ]]
measure 114
F#4    1        s     u  [[
G#4    1        s #   u  ==
F#4    1        s     u  ==
E#4    1        s #   u  ]]
F#4    1        s     u  [[
E#4    1        s     u  ==
F#4    1        s     u  ==
E#4    1        s     u  ]]
measure 115
F#4    1        s     u  [[
G#4    1        s #   u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
D#4    1        s #   u  [[
E4     1        s     u  ==
D#4    1        s     u  ==
C#4    1        s     u  ]]
measure 116
B#3    1        s #   u  [[
C#4    1        s     u  ==
D#4    1        s #   u  ==
E4     1        s     u  ]]
F#4    1        s     u  [[
A4     1        s     u  ==
G#4    1        s #   u  ==
F#4    1        s     u  ]]
measure 117
E4     1        s     u  [[
F#4    1        s     u  ==
E4     1        s     u  ==
D#4    1        s #   u  ]]
C#4    1        s     u  [[
B#3    1        s #   u  ==
C#4    1        s     u  ==
B#3    1        s     u  ]]
measure 118
C#4    1        s     u  [[
B#3    1        s #   u  ==
C#4    1        s     u  ==
D#4    1        s #   u  ]]
E4     1        s     d  [[
E5     1        s     d  ==
D#5    1        s #   d  ==
C#5    1        s     d  ]]
measure 119
B#4    8        h #   d
measure 120
C#5    4        q     d
E4     4        q     u
measure 121
D#4    4        q #   u
B#3    4        q #   u
measure 122
C#4    4        q     u
E4     4        q     u
measure 123
G#4    2        e #   u  [
G#3    2        e #   u  =
G#3    2        e     u  =
G#3    2        e     u  ]
measure 124
G#3    4        q #   u
rest   4        q
measure 125
A3     8        h     u
measure 126
C#4    8        h     u
measure 127
D4     3        e.    u  [
E4     1        s     u  ]\
F#4    2        e     u  [
F#4    2        e     u  ]
measure 128
F#4    2        e     u
rest   2        e
D4     2        e     u  [
D4     2        e     u  ]
measure 129
C#4    3        e.    u  [
D4     1        s     u  ]\
E4     2        e     u  [
E4     2        e     u  ]
measure 130
E4     2        e     u
rest   2        e
rest   4        q
measure 131
rest   8
measure 132
rest   8
measure 133
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
measure 134
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
measure 135
rest   2        e
G4     1        s     u  [[
F#4    1        s     u  ]]
G4     2        e     u  [
E4     2        e     u  ]
measure 136
C#4    2        e     u
rest   2        e
rest   4        q
measure 137
E4     6        q.#   u
 A#3   6        q.    u
A#3    2        e     u
measure 138
B3     2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 139
E4     6        q.    u
 A#3   6        q.#   u
A#3    2        e     u
measure 140
B3     2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 141
C#4    1        s     u  [[
D4     1        s     u  ==
E4     1        s     u  ==
C#4    1        s     u  ]]
D#4    2        e #   u
rest   2        e
measure 142
E4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
F#4    2        e     u
rest   2        e
measure 143
G4     1        s     u  [[
A4     1        s     u  ==
B4     1        s     u  ==
G4     1        s     u  ]]
E4     2        e     u
rest   2        e
measure 144
B4     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ]]
F#4    2        e     u
rest   2        e
measure 145
D5     1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
D5     1        s     d  ]]
B4     2        e     u  [
A4     2        e     u  ]
measure 146
G4     2        e     u  [
E4     2        e     u  =
D#4    2        e #   u  =
B3     2        e     u  ]
measure 147
E4     2        e     u  [
G4     2        e     u  =
C#4    2        e     u  =
E4     2        e     u  ]
measure 148
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 149
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 150
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 151
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
measure 152
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 153
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 154
D4     2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 155
D4     2        e     u  [
D4     2        e     u  ]
rest   4        q
measure 156
C#4    2        e     u  [
C#4    2        e     u  ]
rest   4        q
measure 157
C#4    2        e     u  [
C#4    2        e     u  ]
rest   4        q
mdouble 158
$      K:5
D#4    2        e #   u  [
F#4    1        s     u  =[
E4     1        s     u  ]]
D#4    2        e     u  [
D#4    2        e     u  ]
measure 159
rest   2        e
F#4    1        s     u  [[
E4     1        s     u  ]]
D#4    2        e #   u  [
D#4    2        e     u  ]
measure 160
rest   2        e
G#4    1        s #   u  [[
F#4    1        s     u  ]]
G#4    2        e     u  [
E4     2        e     u  ]
measure 161
C#4    2        e     u
rest   2        e
rest   4        q
measure 162
E4     6        q.#   u
 A#3   6        q.    u
A#3    2        e     u
measure 163
B3     2        e     u  [
D#4    2        e #   u  ]
rest   4        q
measure 164
E4     6        q.#   u
 A#3   6        q.    u
A#3    2        e     u
measure 165
B3     2        e     u  [
D#4    2        e #   u  ]
D#4    2        e     u  [
B3     1        s     u  ]\
rest   1        s
measure 166
E4     2        e     u  [
C#4    1        s     u  ]\
rest   1        s
F#4    2        e     u  [
D#4    1        s #   u  ]\
rest   1        s
measure 167
G#4    2        e #   u  [
E4     1        s     u  ]\
rest   1        s
rest   4        q
measure 168
E4     2        e     u  [
E4     2        e     u  ]
E5     1        s     d  [[
D#5    1        s #   d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
measure 169
A#4    2        e #   u  [
A#4    2        e     u  ]
rest   4        q
measure 170
A#4    2        e #   d  [
A#4    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]
measure 171
B4     2        e     d  [
B4     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
measure 172
D#5    2        e #   d  [
D#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]
measure 173
B4     4        q     d
rest   4        q
measure 174
rest   8
measure 175
rest   4        q
F#4    4        q     u
measure 176
G#4    4        q #   u
A#4    4        q #   u
measure 177
B4     4        q     d
rest   4        q
measure 178
rest   4        q
G#4    4        q #   u
measure 179
F#4    4        q     u
rest   4        q
measure 180
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 181
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 182
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 183
D#4    8        h #   u
measure 184
B3     2        e     u  [
D#4    2        e #   u  =
F#4    2        e     u  =
B4     2        e     u  ]
measure 185
B4     4        q     d
rest   4        q
measure 186
C#5    4        q     d
rest   4        q
measure 187
B4     8        h     d
measure 188
A#4    8        h #   u
measure 189
B4     4        q     d
rest   4        q
measure 190
E4     4        q     u
 A#3   4        q #   u
rest   4        q
measure 191
D#4    4        q     u
 B3    4        q #   u
rest   4        q
measure 192
E4     4        q #   u
 A#3   4        q     u
rest   4        q
measure 193
D#4    2        e #   u
 B3    2        e     u
rest   2        e
B4     2        e     d  [
B4     2        e     d  ]
measure 194
rest   4        q
D#5    2        e #   d  [
D#5    2        e     d  ]
measure 195
rest   4        q
F#5    2        e     d  [
F#5    2        e     d  ]
measure 196
rest   4        q
B5     2        e     d  [
B5     2        e     d  ]
measure 197
rest   4        q
D#6    2        e #   d  [
D#6    2        e     d  ]
measure 198
rest   4        q
D#6    2        e #   d  [
D#6    2        e     d  ]
measure 199
D#6    4        q #   d
rest   4        q
measure 200
rest   8
measure 201
rest   4        q
mheavy2                        :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/04/03} [KHM:1635258311]
TIMESTAMP: DEC/26/2001 [md5sum:88b0a1cdf1a1f2f3714aa391b6c2f86a]
11/21/94 W Hewlett
WK#:64,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Finale
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:4   T:2/4  C:13  D:Presto
rest   4        q
measure 1
rest   2        e
D4     1        s     d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 2
rest   2        e
D4     1        s     d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 3
rest   2        e
E4     1        s     d  [[
D4     1        s     d  ]]
E4     2        e     d  [
C#4    2        e     d  ]
measure 4
A#3    2        e #   u
rest   2        e
rest   4        q
measure 5
C#4    8        h     d
measure 6
D4     4        q     d
rest   4        q
measure 7
C#4    8        h     d
measure 8
D4     4        q     d
B3     2        e     u  [
B3     2        e     u  ]
measure 9
C4     2        e n   d  [
E4     1        s     d  ]\
rest   1        s
D#4    2        e #   d  [
F#4    1        s     d  ]\
rest   1        s
measure 10
E4     2        e     d  [
G4     1        s     d  ]\
rest   1        s
F#4    1        s     d  [[
G#4    1        s #   d  ==
A#4    1        s #   d  ==
F#4    1        s     d  ]]
measure 11
B4     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
F#4    2        e     d  ]
measure 12
B4     2        e     d
rest   2        e
rest   4        q
measure 13
rest   2        e
D4     1        s     d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 14
B3     2        e     u
rest   2        e
D3     2        e     u  [
D3     2        e     u  ]
measure 15
D3     8-       h     u        -
measure 16
D3     2        e     u
rest   2        e
A3     2        e     u  [
A3     2        e     u  ]
measure 17
G3     4        q     u
rest   4        q
measure 18
rest   8
measure 19
G3     6        q.    u
G#3    2        e #   u
measure 20
A3     4        q     u
rest   4        q
measure 21
D4     3        e.    d  [
E4     1        s     d  ]\
F#4    2        e     d  [
D4     2        e     d  ]
measure 22
E4     8-       h     d        -
measure 23
E4     8        h     d
measure 24
A3     4        q     u
rest   4        q
measure 25
A3     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
F#4    2        e     d  [
D4     2        e     d  ]
measure 26
E4     8-       h     d        -
measure 27
E4     8        h     d
measure 28
D4     8-       h     d        -
measure 29
D4     8-       h     d        -
measure 30
D4     4        q     d
F#3    2        e     u  [
D4     2        e     u  ]
measure 31
G3     2        e     d  [
E4     2        e     d  =
A3     2        e     d  =
F#4    2        e     d  ]
measure 32
B3     4        q     u
rest   4        q
measure 33
rest   2        e
D#4    1        s #   d  [[
E4     1        s     d  ]]
C#5    2        e     d  [
C#5    2        e     d  ]
measure 34
C#5    8-       h     d        -
measure 35
C#5    2        e     d  [
D#4    1        s #   d  =[
E4     1        s     d  ]]
C#5    2        e     d  [
C#5    2        e     d  ]
measure 36
C#5    4        q     d
rest   4        q
measure 37
E4     4        q     d
rest   4        q
measure 38
G4     4        q     d
 A3    4        q     d
rest   4        q
measure 39
A3     4        q     u
C#4    4        q     d
measure 40
D4     4        q     d
F#4    4        q     d
measure 41
D4     8-       h     d        -
measure 42
D4     8        h     d
measure 43
E4     2        e     d  [
B4     2        e     d  =
A4     2        e     d  =
G4     2        e     d  ]
measure 44
F#4    2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 45
A4     4        q     d
G3     4        q     u
measure 46
F#3    8        h     u
measure 47
G3     8        h     u
measure 48
F#3    8        h     u
measure 49
G3     8        h     u
measure 50
E3     2        e     u  [
F#3    2        e     u  =
F#3    2        e     u  =
F#3    2        e     u  ]
measure 51
G3     8        h     u
measure 52
F#3    4        q     u
rest   4        q
measure 53
D4     4        q     d
rest   4        q
measure 54
D4     4        q     d
rest   4        q
measure 55
D4     4        q     d
rest   4        q
measure 56
C#4    4        q     d
rest   4        q
measure 57
D4     4        q     d
rest   4        q
measure 58
rest   4        q
rest   2        e
D3     2        e     u
measure 59
G3     2        e     u  [
G3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 60
F#3    2        e     u  [
F#3    2        e     u  ]
rest   4        q
measure 61
F#3    2        e     u  [
F#3    2        e     u  ]
rest   4        q
measure 62
F#3    2        e     u  [
F#3    2        e     u  ]
rest   4        q
measure 63
F#3    2        e     u  [
F#3    2        e     u  ]
rest   4        q
measure 64
F#3    2        e     u  [
F#3    2        e     u  =
mheavy4                  :|:
F#4    2        e     u  =
F#4    2        e     u  ]
measure 65
F#4    3        e.    d  [
G4     1        s     d  ]\
A4     2        e     d  [
A4     2        e     d  ]
measure 66
G4     2        e     d
rest   2        e
G4     2        e     d  [
G4     2        e     d  ]
measure 67
D4     3        e.    d  [
E4     1        s     d  ]\
D4     1        s     u  [[
C4     1        s n   u  ==
B3     1        s     u  ==
A3     1        s     u  ]]
measure 68
G3     2        e     u
rest   2        e
D#4    2        e #   d  [
D#4    2        e     d  ]
measure 69
D#4    3        e.#   d  [
E4     1        s     d  ]\
F#4    2        e     d  [
F#4    2        e     d  ]
measure 70
E4     2        e     d
rest   2        e
E5     2        e     d  [
E5     2        e     d  ]
measure 71
B4     3        e.    d  [
C5     1        s n   d  ]\
B4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s     d  ]]
measure 72
E4     2        e     d
rest   2        e
E4     2        e     d  [
E4     2        e     d  ]
measure 73
E4     2        e     d
rest   2        e
D#4    2        e #   d  [
D#4    2        e     d  ]
measure 74
D#4    2        e #   d
rest   2        e
F#4    2        e     d  [
F#4    2        e     d  ]
measure 75
F#4    2        e     d
rest   2        e
E#4    2        e #   d  [
E#4    2        e     d  ]
measure 76
E#4    2        e #   d
rest   2        e
rest   4        q
measure 77
rest   8
measure 78
rest   4        q
C#4    2        e     d  [
C#4    2        e     d  ]
measure 79
F#3    2        e     u  [
A3     1        s     u  =[
G#3    1        s #   u  ]]
F#3    2        e     u  [
F#3    2        e     u  ]
measure 80
rest   2        e
A3     1        s     u  [[
G#3    1        s #   u  ]]
F#3    2        e     u  [
F#3    2        e     u  ]
measure 81
G#3    8-       h #   u        -
measure 82
G#3    8        h     u
measure 83
A#3    8-       h #   u        -
measure 84
A#3    4        q     u
A#3    2        e #   u  [
A#3    2        e     u  ]
measure 85
A#3    4        q #   u
rest   4        q
measure 86
A#3    4        q #   u
rest   4        q
measure 87
rest   8
measure 88
rest   4        q
D#4    2        e #   d  [
D#4    2        e     d  ]
measure 89
G#4    3        e.#   d  [
A#4    1        s #   d  ]\
B4     2        e     d  [
B4     2        e     d  ]
measure 90
B4     2        e     d
rest   2        e
rest   4        q
measure 91
B3     8-       h     u        -
measure 92
B3     2        e     u
rest   2        e
rest   4        q
measure 93
rest   8
measure 94
rest   4        q
B3     2        e     u  [
B3     2        e     u  ]
measure 95
E4     3        e.    d  [
F#4    1        s     d  ]\
G4     2        e     d  [
G4     2        e     d  ]
measure 96
G4     2        e     d
rest   2        e
rest   4        q
measure 97
G3     8-       h     u        -
measure 98
G3     2        e     u
rest   2        e
rest   4        q
measure 99
F4     2        e n   d  [
F4     2        e     d  ]
rest   4        q
measure 100
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
measure 101
D4     2        e     d  [
D4     2        e     d  ]
rest   4        q
measure 102
C#4    2        e     d  [
C#4    2        e     d  ]
rest   4        q
measure 103
G4     2        e     d  [
G4     2        e     d  ]
rest   4        q
measure 104
F#4    2        e     d  [
F#4    2        e     d  ]
rest   4        q
measure 105
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
measure 106
D#4    2        e #   d  [
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]
measure 107
E4     4        q     d
rest   4        q
measure 108
rest   4        q
E4     2        e     d  [
E4     2        e     d  ]
measure 109
F#4    3        e.    d  [
E4     1        s     d  ]\
D#4    2        e #   d  [
D#4    2        e     d  ]
measure 110
D#4    2        e #   d
rest   2        e
D#4    2        e     d  [
D#4    2        e     d  ]
measure 111
E#4    3        e.#   d  [
F#4    1        s     d  ]\
G#4    2        e #   d  [
G#4    2        e     d  ]
measure 112
G#4    2        e #   d  [
B4     2        e     d  =
D5     2        e     d  =
D4     2        e     d  ]
measure 113
C#4    8-       h     d        -
measure 114
C#4    8        h     d
measure 115
D#4    8-       h #   d        -
measure 116
D#4    8        h     d
measure 117
E4     8-       h     d        -
measure 118
E4     8        h     d
measure 119
D#4    4        q #   d
F#4    4        q     d
measure 120
E4     4        q     d
G#4    4        q #   d
measure 121
F#4    4        q     d
D#4    4        q #   d
measure 122
E4     4        q     d
C#4    4        q     d
measure 123
G#3    2        e #   u  [
G#4    2        e #   u  =
G#3    2        e     u  =
G#3    2        e     u  ]
measure 124
G#3    4        q #   u
rest   4        q
measure 125
A3     8        h     u
measure 126
G3     8        h     u
measure 127
F#3    3        e.    u  [
E3     1        s     u  ]\
D3     2        e     u  [
D3     2        e     u  ]
measure 128
D3     4        q     u
F#3    2        e     u  [
F#3    2        e     u  ]
measure 129
G3     3        e.    u  [
F#3    1        s     u  ]\
E3     2        e     u  [
D3     2        e     u  ]
measure 130
C#3    2        e     u
rest   2        e
rest   4        q
measure 131
rest   8
measure 132
rest   8
measure 133
rest   2        e
D4     1        s     d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 134
rest   2        e
D4     1        s     d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 135
rest   2        e
E4     1        s     d  [[
D4     1        s     d  ]]
E4     2        e     d  [
C#4    2        e     d  ]
measure 136
A#3    2        e #   u
rest   2        e
rest   4        q
measure 137
C#4    8        h     d
measure 138
D4     4        q     d
rest   4        q
measure 139
C#4    8        h     d
measure 140
D4     2        e     d
rest   2        e
D3     2        e     u  [
B3     2        e     u  ]
measure 141
E3     2        e     u  [
B3     2        e     u  =
F#3    2        e     u  =
B3     2        e     u  ]
measure 142
G3     2        e     u  [
B3     2        e     u  ]
F#4    1        s     d  [[
G4     1        s     d  ==
A4     1        s     d  ==
F#4    1        s     d  ]]
measure 143
G4     2        e     d
rest   2        e
A#4    1        s #   d  [[
B4     1        s     d  ==
C#5    1        s     d  ==
A#4    1        s     d  ]]
measure 144
B4     2        e     d
rest   2        e
A#3    2        e #   d  [
F#4    2        e     d  ]
measure 145
B3     2        e     d  [
D4     2        e     d  ]
rest   4        q
measure 146
rest   8
measure 147
rest   8
measure 148
F#3    2        e     u  [
F#3    2        e     u  =
F#3    2        e     u  =
F#3    2        e     u  ]
measure 149
F#3    2        e     u  [
F#3    2        e     u  =
F#3    2        e     u  =
F#3    2        e     u  ]
measure 150
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 151
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 152
G#3    2        e #   u  [
G#3    2        e     u  =
G#3    2        e     u  =
G#3    2        e     u  ]
measure 153
G#3    2        e #   u  [
G#3    2        e     u  =
G#3    2        e     u  =
G#3    2        e     u  ]
measure 154
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 155
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 156
B3     2        e     u  [
B3     2        e     u  ]
rest   4        q
measure 157
A#3    2        e #   u  [
A#3    2        e     u  ]
rest   4        q
mdouble 158
$      K:5
B3     2        e     d  [
D#4    1        s #   d  =[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 159
rest   2        e
D#4    1        s #   d  [[
C#4    1        s     d  ]]
B3     2        e     u  [
B3     2        e     u  ]
measure 160
rest   2        e
E4     1        s     d  [[
D#4    1        s #   d  ]]
E4     2        e     d  [
C#4    2        e     d  ]
measure 161
A#3    2        e #   u
rest   2        e
rest   4        q
measure 162
C#4    8        h     d
measure 163
D#4    4        q #   d
rest   4        q
measure 164
C#4    8        h     d
measure 165
D#4    2        e #   d
rest   2        e
D#4    2        e     d  [
B3     1        s     d  ]\
rest   1        s
measure 166
E4     2        e     d  [
C#4    1        s     d  ]\
rest   1        s
F#4    2        e     d  [
D#4    1        s #   d  ]\
rest   1        s
measure 167
G#4    2        e #   d  [
E4     1        s     d  ]\
rest   1        s
rest   4        q
measure 168
C#4    2        e     d  [
C#4    2        e     d  ]
rest   4        q
measure 169
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
measure 170
E4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
measure 171
F#4    2        e     d  [
F#4    2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]
measure 172
B4     2        e     d  [
B4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 173
D#4    4        q #   d
D#3    4        q #   u
measure 174
E3     8        h     u
measure 175
D#3    8        h #   u
measure 176
E3     8        h     u
measure 177
D#3    8        h #   u
measure 178
E3     8        h     u
measure 179
D#3    4        q #   u
rest   4        q
measure 180
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
measure 181
D#4    2        e #   d  [
D#4    2        e     d  ]
rest   4        q
measure 182
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
measure 183
F#4    8-       h     d        -
measure 184
F#4    8        h     d
measure 185
G#4    4        q #   d
rest   4        q
measure 186
G#4    4        q #   d
rest   4        q
measure 187
D#4    2        e #   d  [
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]
measure 188
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 189
D#4    4        q #   d
rest   4        q
measure 190
C#4    4        q     d
rest   4        q
measure 191
B3     4        q     u
rest   4        q
measure 192
C#4    4        q     d
rest   4        q
measure 193
D#4    2        e #   d  [
D#4    2        e     d  ]
rest   4        q
measure 194
F#4    2        e #   d  [
 D#4   2        e     d
F#4    2        e     d  ]
 D#4   2        e     d
rest   4        q
measure 195
F#4    2        e     d  [
 D#4   2        e #   d
F#4    2        e     d  ]
 D#4   2        e     d
rest   4        q
measure 196
F#4    2        e     d  [
 D#4   2        e #   d
F#4    2        e     d  ]
 D#4   2        e     d
rest   4        q
measure 197
F#4    2        e     d  [
 D#4   2        e #   d
F#4    2        e     d  ]
 D#4   2        e     d
rest   4        q
measure 198
F#4    2        e #   d  [
 D#4   2        e     d
F#4    2        e     d  ]
 D#4   2        e     d
rest   4        q
measure 199
rest   8
measure 200
rest   8
measure 201
rest   4        q
mheavy2                        :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n2/stage2/04/04} [KHM:1635258311]
TIMESTAMP: DEC/26/2001 [md5sum:324f2f8eb487a4eeef6d7f00f2fd6371]
11/21/94 W Hewlett
WK#:64,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 2, in B Minor
Finale
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:4   T:2/4  C:22  D:Presto
rest   4        q
measure 1
B2     4        q     u
rest   4        q
measure 2
B2     4        q     u
rest   4        q
measure 3
A#2    4        q #   u
rest   4        q
measure 4
A#2    4        q #   u
rest   4        q
measure 5
F#3    8        h     d
measure 6
B2     4        q     u
rest   4        q
measure 7
F#3    8        h     d
measure 8
B2     4        q     u
B2     2        e     u  [
B2     2        e     u  ]
measure 9
C3     2        e n   d  [
E3     1        s     d  ]\
rest   1        s
D#3    2        e #   d  [
F#3    1        s     d  ]\
rest   1        s
measure 10
E3     2        e     d  [
G3     1        s     d  ]\
rest   1        s
F#3    1        s     d  [[
G#3    1        s #   d  ==
A#3    1        s #   d  ==
F#3    1        s     d  ]]
measure 11
B3     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  =
F#3    2        e     d  ]
measure 12
B3     4        q     d
rest   4        q
measure 13
B2     4        q     u
rest   4        q
measure 14
B2     4        q     u
rest   4        q
measure 15
F#2    8        h     u
measure 16
G2     2        e     u
rest   2        e
F#3    2        e     d  [
F#3    2        e     d  ]
measure 17
G3     4        q     d
rest   4        q
measure 18
rest   8
measure 19
G3     6        q.    d
G#3    2        e #   d
measure 20
A3     4        q     d
rest   4        q
measure 21
D3     4        q     d
rest   4        q
measure 22
C#2    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
measure 23
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
measure 24
D3     4        q     d
rest   4        q
measure 25
D3     4        q     d
rest   4        q
measure 26
C#2    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
measure 27
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
measure 28
D3     4        q     d
F#2    2        e     u  [
D3     2        e     u  ]
measure 29
G2     2        e     u  [
D3     2        e     u  =
A2     2        e     u  =
D3     2        e     u  ]
measure 30
B2     2        e     u  [
D3     2        e     u  ]
rest   4        q
measure 31
rest   8
measure 32
rest   8
measure 33
rest   2        e
B#3    1        s #   d  [[
C#4    1        s     d  ]]
E4     2        e     d  [
E4     2        e     d  ]
measure 34
E4     8-       h     d        -
measure 35
E4     2        e     d  [
B#3    1        s #   d  =[
C#4    1        s     d  ]]
E4     2        e     d  [
E4     2        e     d  ]
measure 36
E4     4        q     d
rest   4        q
measure 37
C#4    4        q     d
rest   4        q
measure 38
C#4    4        q     d
rest   4        q
measure 39
C#4    2        e     d  [
A3     1        s     d  =[
C#4    1        s     d  ]]
E4     2        e     d  [
C#4    2        e     d  ]
measure 40
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 41
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 42
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 43
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 44
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 45
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 46
D2     8-       h     u        -
measure 47
D2     8-       h     u        -
measure 48
D2     8-       h     u        -
measure 49
D2     8-       h     u        -
measure 50
D2     8-       h     u        -
measure 51
D2     8-       h     u        -
measure 52
D2     4        q     u
rest   4        q
measure 53
G2     4        q     u
rest   4        q
measure 54
F#2    4        q     u
rest   4        q
measure 55
E2     4        q     u
rest   4        q
measure 56
A2     4        q     u
rest   4        q
measure 57
D2     4        q     u
rest   4        q
measure 58
rest   4        q
rest   2        e
F#2    2        e     u
measure 59
G2     2        e     u  [
G2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]
measure 60
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 61
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 62
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 63
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 64
D3     2        e     d  [
D3     2        e     d  ]
mheavy4                  :|:
rest   4        q
measure 65
rest   8
measure 66
rest   4        q
G3     2        e     d  [
G3     2        e     d  ]
measure 67
D3     3        e.    d  [
E3     1        s     d  ]\
D3     1        s     u  [[
C3     1        s n   u  ==
B2     1        s     u  ==
A2     1        s     u  ]]
measure 68
G2     2        e     u
rest   2        e
rest   4        q
measure 69
rest   8
measure 70
rest   4        q
E4     2        e     d  [
E4     2        e     d  ]
measure 71
B3     3        e.    d  [
C4     1        s n   d  ]\
B3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F#3    1        s     d  ]]
measure 72
E3     2        e     d
rest   2        e
rest   4        q
measure 73
rest   8
measure 74
rest   8
measure 75
rest   8
measure 76
rest   8
measure 77
rest   8
measure 78
rest   4        q
C#3    2        e     u  [
C#3    2        e     u  ]
measure 79
F#2    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 80
F#2    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 81
E#2    2        e #   u  [
E#3    2        e #   u  =
E#3    2        e     u  =
E#3    2        e     u  ]
measure 82
E2     2        e     u  [
E3     2        e     u  =
E3     2        e     u  =
E3     2        e     u  ]
measure 83
D#2    2        e #   u  [
D#3    2        e #   u  =
D#3    2        e     u  =
D#3    2        e     u  ]
measure 84
D#2    2        e #   u  [
D#3    2        e #   u  =
D#3    2        e     u  =
D#3    2        e     u  ]
measure 85
D#3    4        q #   d
rest   4        q
measure 86
D#3    4        q #   d
rest   4        q
measure 87
rest   8
measure 88
rest   4        q
D#3    2        e #   d  [
D#3    2        e     d  ]
measure 89
G#3    3        e.#   d  [
A#3    1        s #   d  ]\
B3     2        e     d  [
B3     2        e     d  ]
measure 90
B3     2        e     d
rest   2        e
rest   4        q
measure 91
D#3    8-       h #   d        -
measure 92
D#3    2        e     d
rest   2        e
rest   4        q
measure 93
rest   8
measure 94
rest   4        q
B3     2        e     d  [
B3     2        e     d  ]
measure 95
E4     3        e.    d  [
F#4    1        s     d  ]\
G4     2        e     d  [
G4     2        e     d  ]
measure 96
G4     2        e     d
rest   2        e
rest   4        q
measure 97
B2     8-       h     u        -
measure 98
B2     2        e     u
rest   2        e
rest   4        q
measure 99
rest   8
measure 100
rest   8
measure 101
rest   8
measure 102
rest   8
measure 103
rest   8
measure 104
rest   8
measure 105
rest   8
measure 106
rest   4        q
B2     2        e     u  [
B2     2        e     u  ]
measure 107
E3     3        e.    d  [
F#3    1        s     d  ]\
G3     2        e     d  [
G3     2        e     d  ]
measure 108
G3     2        e     d
rest   2        e
B2     2        e     u  [
B2     2        e     u  ]
measure 109
F#3    3        e.    d  [
G3     1        s     d  ]\
A3     2        e     d  [
A3     2        e     d  ]
measure 110
A3     2        e     d
rest   2        e
B2     2        e     u  [
B2     2        e     u  ]
measure 111
G#3    3        e.#   d  [
A3     1        s     d  ]\
B3     2        e     d  [
B3     2        e     d  ]
measure 112
B3     2        e     d  [
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]
measure 113
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 114
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 115
G#3    2        e #   d  [
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]
measure 116
G#3    2        e #   d  [
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]
measure 117
G#3    2        e #   d  [
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]
measure 118
G#3    2        e #   d  [
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]
measure 119
G#2    8-       h #   u        -
measure 120
G#2    8-       h     u        -
measure 121
G#2    8-       h     u        -
measure 122
G#2    8        h     u
measure 123
G#2    2        e #   u  [
G#3    2        e #   u  =
G#2    2        e     u  =
G#2    2        e     u  ]
measure 124
G#2    4        q #   u
rest   4        q
measure 125
A2     8-       h     u        -
measure 126
A2     8-       h     u        -
measure 127
A2     8-       h     u        -
measure 128
A2     8        h     u
measure 129
A#2    8-       h #   u        -
measure 130
A#2    2        e     u
rest   2        e
rest   4        q
measure 131
rest   8
measure 132
rest   8
measure 133
B2     4        q     u
rest   4        q
measure 134
B2     4        q     u
rest   4        q
measure 135
A#2    4        q #   u
rest   4        q
measure 136
A#2    4        q #   u
rest   4        q
measure 137
F#3    8        h     d
measure 138
B2     4        q     u
rest   4        q
measure 139
F#3    8        h     d
measure 140
B2     2        e     u
rest   2        e
B3     1        s     d  [[
C#4    1        s     d  ==
D4     1        s     d  ==
B3     1        s     d  ]]
measure 141
C#4    2        e     d
rest   2        e
D#4    1        s #   d  [[
E4     1        s     d  ==
F#4    1        s     d  ==
D#4    1        s     d  ]]
measure 142
E4     2        e     d
rest   2        e
D#3    2        e #   d  [
B3     2        e     d  ]
measure 143
E3     2        e     d  [
G3     2        e     d  =
C#3    2        e     d  =
E3     2        e     d  ]
measure 144
D3     2        e     d  [
B3     2        e     d  ]
rest   4        q
measure 145
rest   8
measure 146
rest   8
measure 147
rest   8
measure 148
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 149
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 150
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 151
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 152
E#3    2        e #   d  [
E#3    2        e     d  =
E#3    2        e     d  =
E#3    2        e     d  ]
measure 153
E#3    2        e #   d  [
E#3    2        e     d  =
E#3    2        e     d  =
E#3    2        e     d  ]
measure 154
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
measure 155
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
measure 156
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
measure 157
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
mdouble 158
$      K:5
B2     4        q     u
rest   4        q
measure 159
B2     4        q     u
rest   4        q
measure 160
A#2    4        q #   u
rest   4        q
measure 161
A#2    4        q #   u
rest   4        q
measure 162
F#3    8        h     d
measure 163
B2     4        q     u
rest   4        q
measure 164
F#3    8        h     d
measure 165
B2     2        e     u
rest   2        e
D#3    2        e #   u  [
B2     1        s     u  ]\
rest   1        s
measure 166
E3     2        e     d  [
C#3    1        s     d  ]\
rest   1        s
F#3    2        e     d  [
D#3    1        s #   d  ]\
rest   1        s
measure 167
G#3    2        e #   d  [
E3     1        s     d  ]\
rest   1        s
rest   4        q
measure 168
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
measure 169
F#3    2        e     d  [
F#3    2        e     d  ]
rest   4        q
measure 170
F#3    2        e     d  [
F#3    2        e     d  =
A#3    2        e #   d  =
A#3    2        e     d  ]
measure 171
B3     2        e     d  [
B3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 172
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 173
B2     8-       h     u        -
measure 174
B2     8-       h     u        -
measure 175
B2     8-       h     u        -
measure 176
B2     8-       h     u        -
measure 177
B2     8-       h     u        -
measure 178
B2     8-       h     u        -
measure 179
B2     4        q     u
rest   4        q
measure 180
E3     2        e     d  [
E3     2        e     d  ]
rest   4        q
measure 181
D#3    2        e #   d  [
D#3    2        e     d  ]
rest   4        q
measure 182
C#3    2        e     u  [
C#3    2        e     u  ]
rest   4        q
measure 183
B2     2        e     u  [
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]
measure 184
D#3    2        e #   d  [
D#3    2        e     d  =
D#3    2        e     d  =
D#3    2        e     d  ]
measure 185
E3     4        q     d
rest   4        q
measure 186
E3     4        q     d
rest   4        q
measure 187
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 188
F#2    2        e     u  [
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  ]
measure 189
B2     4        q     u
rest   4        q
measure 190
F#3    4        q     d
rest   4        q
measure 191
B2     4        q     u
rest   4        q
measure 192
F#3    4        q     d
rest   4        q
measure 193
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 194
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 195
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 196
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 197
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 198
B2     2        e     u  [
B2     2        e     u  ]
rest   4        q
measure 199
rest   8
measure 200
rest   8
measure 201
rest   4        q
mheavy2                        :|
/END
/eof
//
