&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/01/01} [KHM:3195760256]
TIMESTAMP: DEC/26/2001 [md5sum:c8fa5c4ad655a1c55294dca35e2d2ecd]
11/09/94 W Hewlett
WK#:55,3      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 55, No. 3, in B-flat Major
[First Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:8   T:3/4  C:4  D:Vivace Assai
Bf3   16        h     u        (p
A3     8        q     u        )
measure 2
Ef4   16        h     u        (
D4     8        q     u        )
measure 3
G4    16        h     u        (
F4     8        q     u        )
measure 4
E4     8        q n   u
rest   8        q
rest   8        q
measure 5
gA3    5        s     u  [[    (
gF4    5        s     u  ]]
Ef5   16        h f   d        )+f(
D5     8        q     d        )
measure 6
C5     8        q     d        (t
gB4    5        s     u  [[
gC5    5        s     u  ]]
D5     8        q     d
Bf4    8        q     d        )
measure 7
A4     8        q     u        (
Bf4    8        q     d
B4     8        q n   d        )
measure 8
C5     8        q     d
rest   8        q
rest   8        q
measure 9
Bf3   16        h     u        (p
A3     8        q     u        )
measure 10
Ef4   16        h     u        (
D4     8        q     u        )
measure 11
G4    16        h     u        (
F4     8        q     u        )
measure 12
Af4    8        q f   u
rest   8        q
rest   8        q
measure 13
B4    16        h n   d        (f
P    C33:Y65
C5     8        q     d        )
measure 14
D5     8        q     d        (
F5     8        q     d
Ef5    4        e     d  [
C5     4        e     d  ]     )
measure 15
Bf4   16        h f   d         +
C5     4        e     d  [     (
A4     4        e     d  ]     )
measure 16
*               E   0
P    C17:Y70
Bf4   12        q.    d        (
C5     2        s     d  [[
D5     2        s     d  ]]
Ef5    2        s     d  [[
F5     2        s     d  ==
G5     2        s     d  ==
*               F   15
A5     2        s     d  ]]    )
measure 17
Bf5    8        q     d        (
A5     8        q     d
G5     8        q     d        )
measure 18
F5     8        q     d        (
Af5    8        q f   d
G5     8        q     d        )
measure 19
F5     8        q     d        (
Ef5    8        q     d
D5     8        q     d        )
measure 20
C5     8        q     d         p.
P    C33:Y63
C5     8        q     d         .
C5     8        q     d         .
measure 21
C5     8-       q     d        -Z
P    C33:Y65
C5     6        e.    d  [     (
Df5    2        s f   d  =\
C5     6        e.    d  =
Df5    2        s     d  ]\    )
measure 22
C5     8        q     d         .
C5     8        q     d         .
C5     8        q     d         .
measure 23
C5     8-       q     d        -Z
P    C33:Y65
C5     6        e.    d  [     (
Df5    2        s f   d  =\
C5     6        e.    d  =
Df5    2        s     d  ]\    )
measure 24
*               E   0
P    C17:Y70
C5     8        q     d
C5     8        q     d
*      6        F   15
C5     8        q     d
measure 25
C5     6        e.    d  [     (f
Df5    2        s f   d  =\    )
C5     6        e.    d  =     (
Df5    2        s     d  =\    )
C5     6        e.    d  =     (
Df5    2        s     d  ]\    )
measure 26
C5     8        q     d
rest   8        q
rest   8        q
measure 27
Bf4   16        h     d        (p
A4     8        q     u        )
measure 28
Ef5   16        h     d        (
D5     8        q n   d        )+
measure 29
*      4        E   0
P    C17:Y65
G5    16        h     d        (
*      4        F   15
F#5    8        q #   d        )
measure 30
C6     8        q     d         .f
P    C34:Y60
Bf5    8        q     d         .
rest   8        q
measure 31
rest   8        q
C5     8        q     d        (.p
P    C34:Y63
C5     8        q     d        ).
measure 32
C5    12        q.    d        (
D5     2        s     d  [[
E5     2        s n   d  ]]
F5     8        q     d        )
measure 33
F5     4        e     d  [     (
Bf5    4        e     d  =     )
Bf5    4        e     d  =     (
A5     4        e     d  =     )
A5     4        e     d  =     (
G5     4        e     d  ]     )
measure 34
G5     8        q     d
G5     8        q     d
G5     8        q     d
measure 35
G5     4        e     d  [     (
C6     4        e     d  =     )
C6     4        e     d  =     (
Bf5    4        e     d  =     )
Bf5    4        e     d  =     (
A5     4        e     d  ]     )
measure 36
A5     8        q     d
A5     8        q     d
A5     8        q     d
measure 37
A5     4        e     d  [     (
*               DH      cresc.
P  C25:f33  C17:Y66  C18:Y66
D6     4        e     d  =     )
D6     4        e     d  =     (
C6     4        e     d  =     )
C6     4        e     d  =     (
Bf5    4        e     d  ]     )
measure 38
Bf5    4        e     d  [     (
A5     4        e     d  =     )
A5     4        e     d  =     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e     d  ]     )
measure 39
F5     4        e     d  [     (
E5     4        e n   d  =     )
E5     4        e     d  =     (
D5     4        e     d  =     )
D5     4        e     d  =     (
*               J
C5     4        e     d  ]     )
measure 40
C5     4        e     d  [     (f
B4     4        e n   d  ]     )
*               E   15
B4    16        h     d
measure 41
*     16        F   0
Bf4   24        h.f   d         +
measure 42
Bf4    4        e     u  [     (p
A4     4        e     u  =     )
A4     4        e     u  =     (
G4     4        e     u  =     )
D5     4        e     u  =     (
G4     4        e     u  ]     )
measure 43
gD5    0        e     u        (
F4    16        h     u        )
gA4    0        e     u        (
G4     6        e.    u  [     )(
F4     2        s     u  ]\    )
measure 44
F4     8        q     u        (
Bf4    8        q     d        )
Bf4    8        q     d         .
measure 45
gA4    5        s     u  [[    (
gC5    5        s     u  ]]
Bf4    8        q     d        )
Bf3    8        q     u        (.pp
Bf3    8        q     u        ).
measure 46
Bf3    8        q     u        (.
Bf3    8        q     u         .
Bf3    8        q     u        ).
measure 47
Bf3    8        q     u        (.
Bf3    8        q     u         .
Bf3    8        q     u        ).
measure 48
Bf3    8        q     u
Bf3    8        q     u
Bf3    8        q     u
measure 49
Bf3    8        q     u
Bf3    8        q     u
Bf3    8        q     u
measure 50
Bf3    8        q     u
Bf3    8        q     u
Bf3    8        q     u
measure 51
Bf3    8        q     u
*               D       dolce
P  C25:f33  C17:Y70
C5     8        q     d        (
D5     8        q     d        )
measure 52
Ef5    8        q f   d         +.
E5    16        h n   d         Z
P    C33:Y60
measure 53
F5     8        q     d         .
F#5   16        h #   d         Z
P    C33:Y60
measure 54
*               E   0
P    C17:Y70
G5     4        e     d  [     (
A5     4        e     d  =
Bf5    4        e     d  =     )
A5     4        e     d  =      .
G5     4        e     d  =      .
F5     4        e n   d  ]      .+
measure 55
E5     4        e n   d  [     (
F5     4        e     d  =
G5     4        e     d  =     )
C5     4        e     d  =      .
D5     4        e     d  =      .
*               F   18
E5     4        e     d  ]      .
measure 56
F5     8        q     d         f
P    C33:Y60
F5    12        q.    d        (
G5     2        s     d  [[
A5     2        s     d  ]]    )
measure 57
Bf5    8        q     d
D6     8        q     d
D6     8        q     d
measure 58
D6    16        h     d
C6     4        e     d  [     (
Bf5    4        e     d  ]     )
measure 59
gBf5   0        e     u        (
A5    16        h     d        )
gG5    0        e     u        (
F5     2        s     d  [[    )(
E5     2        s n   d  ==
F5     2        s     d  ==
G5     2        s     d  ]]    )
measure 60
Af5    4        e f   d  [     (Z
P    C33:Y64
E5     4        e n   d  =     )
F5     4        e     d  =      .
Af5    4        e     d  =      .
B5     4        e n   d  =      .
D6     4        e     d  ]      .
measure 61
F6     4        e     d  [      .
D6     4        e     d  =      .
B5     4        e n   d  =      .
Af5    4        e f   d  =      .
F5     4        e     d  =      .
D5     4        e     d  ]      .
measure 62
B4     4        e n   u  [      .
Af4    4        e f   u  =      .
F4     4        e     u  =      .
D4     4        e     u  =      .
B3     4        e n   u  =      .
Af3    4        e f   u  ]      .
measure 63
G3    12        q.    u        (p
A3     2        s n   u  [[     +
Bf3    2        s     u  ]]
C4     2        s     u  [[
D4     1        t     u  ==[
E4     1        t n   u  ===
F4     1        t     u  ===
G4     1        t     u  ===
A4     1        t     u  ===
Bf4    1        t     u  ]]]   )
measure 64
C5     8        q     d        (
A4     8        q     u
F4     8        q     u        )
measure 65
D4     8        q     u        (
P    C32:o
Bf4    8        q     d
G4     8        q     u        )
measure 66
C4     8        q     u        (
D4     8        q     u
E4     8        q n   u        )
measure 67
G4    16        h     u        (
F4     8        q     u        )
measure 68
Bf4   16        h     d        (
A4     8        q     u        )
measure 69
D5    16        h     d        (
C5     8        q     d        )
measure 70
Bf5   16        h     d        (Z
P    C33:Y60
A5     2        s     d  [[
G5     2        s     d  ==
F5     2        s     d  ==
E5     2        s n   d  ]]    )
measure 71
F5     8        q     d
rest   8        q
C4     4        e     u  [     (p
P    C33:Y75
F4     4        e     u  ]     )
measure 72
E4     4        e n   u  [     (
G4     4        e     u  =
Bf4    4        e     u  =     )
D5     4        e     u  =      .
C5     4        e     u  =      .
E4     4        e     u  ]      .
measure 73
F4     8        q     u
rest   8        q
C5     4        e     d  [     (
F5     4        e     d  ]     )
measure 74
E5     4        e n   d  [     (
G5     4        e     d  =
Bf5    4        e     d  =     )
D6     4        e     d  =      .
C6     4        e     d  =      .
E5     4        e     d  ]      .
measure 75
F5     8        q     d
rest   8        q
rest   8        q
mheavy4 76                    :|:
F#4   16        h #   u        (p
P    C33:Y62
G4     8        q     u        )
measure 77
D4    16        h     u        (
Ef4    8        q f   u        )+
measure 78
B3    16        h n   u        (
C4     8        q     u        )
measure 79
G3     8        q     u         f
Af5   16        h     d
 B4   16        h f   d
 D4   16        h n   d
measure 80
G5     8        q     d        (
B5     8        q n   d
C6     8        q     d        )
measure 81
D6     8        q     d        (
F5     8        q     d        )
F5     2        s     d  [[    (
Ef5    2        s     d  ==
D5     2        s     d  ==
Ef5    2        s     d  ]]    )
measure 82
D5     8        q     d
D5     6        e.    d  [     (
Ef5    2        s     d  =\
D5     6        e.    d  =
Ef5    2        s     d  ]\    )
measure 83
D5     8        q     d
rest   8        q
rest   8        q
measure 84
Af3   16        h f   u        (p
P    C33:Y88
G3     8        q     u        )
measure 85
Df4   16        h f   u        (
C4     8        q     u        )
measure 86
F4    16        h     u        (
Ef4    8        q     u        )
measure 87
D4     8        q n   u         +
rest   8        q
rest   8        q
measure 88
gEf4   5        s     u  [[    (
g G3   5        s     u
gBf4   5        s     u  ]]
Df5   16        h f   d        )f(
P    C33:Y60
C5     8        q     d        )
measure 89
Bf4    8        q     d        (
C5     8        q     d
Af4    8        q f   u        )
measure 90
G4     8        q     u        (
Af4    8        q f   u
A4     8        q n   u        )
measure 91
Bf4    8        q     d
rest   8        q
rest   8        q
measure 92
rest   8        q
Ef4    8        q     u        (.p
P    C34:Y78
Ef4    8        q     u        ).
measure 93
Ef4   12        q.    u        (
F4     2        s     u  [[
G4     2        s     u  ]]
Af4    8        q f   u        )
measure 94
Af4    4        e f   d  [     (
Df5    4        e f   d  =     )
Df5    4        e     d  =     (
C5     4        e     d  =     )
C5     4        e     d  =     (
Bf4    4        e     d  ]     )
measure 95
Bf4    8        q     d
Bf4    8        q     d
Bf4    8        q     d
measure 96
*               E   0
P    C17:Y73
Bf4    4        e     d  [     (
Ef5    4        e     d  =     )
Ef5    4        e     d  =     (
Df5    4        e f   d  =     )
Df5    4        e     d  =     (
C5     4        e     d  ]     )
measure 97
C5     8        q     d
C5     8        q     d
*               F   16
C5     8        q     d
measure 98
C5     4        e     d  [     (f
P    C33:Y66
*               E   16
P    C17:Y68
Af5    4        e f   d  =     )
Af5    4        e     d  =     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e     d  ]     )
measure 99
F5     4        e     d  [     (
Ef5    4        e     d  ]     )
Ef5    4        e     d  [     (
D5     4        e n   d  ]     )+
*               F   0
D5     4        e     d  [     (
C5     4        e     d  ]     )
measure 100
B4     8        q n   d
G4     8        q     u        (.pp
G4     8        q     u        ).
measure 101
G4     8        q     u        (.
G4     8        q     u         .
G4     8        q     u        ).
measure 102
G4     8        q     u        (.
G4     8        q     u         .
G4     8        q     u        ).
measure 103
G4     8        q     u        (.
G4     8        q     u         .
G4     8        q     u        ).
measure 104
G4     8        q     u        (.
G4     8        q     u         .
G4     8        q     u        ).
measure 105
G4     8        q     u        (.
G4     8        q     u         .
G4     8        q     u        ).
measure 106
G4     8        q     u         .
*               D       dolce
P  C25:f33  C17:Y70
G4     8        q     u        (
A4     8        q n   u        )+
measure 107
Bf4    8        q f   d         +.
B4    16        h n   d         Z
measure 108
C5     8        q     d         .
C#5   16        h #   d         Z
P    C33:Y68
measure 109
D5     4        e     d  [     (
Ef5    4        e     d  =
F5     4        e     d  =     )
Ef5    4        e     d  =      .
D5     4        e     d  =      .
C5     4        e n   d  ]      .+
measure 110
B4     4        e n   d  [     (
Af5    4        e f   d  =
G5     4        e     d  =     )
F5     4        e     d  =      .
Ef5    4        e     d  =      .
D5     4        e     d  ]      .
measure 111
C5     4        e     d  [     (
Ef5    4        e     d  =
G5     4        e     d  =     )
F5     4        e     d  =      .
Ef5    4        e     d  =      .
D5     4        e     d  ]      .
measure 112
C5     4        e     d  [     (
G5     4        e     d  =
C6     4        e     d  =     )
Bf5    4        e f   d  =      .+
A5     4        e n   d  =      .+
G5     4        e     d  ]      .
measure 113
F#5    4        e #   d  [     (
G5     4        e     d  =
A5     4        e     d  =
G5     4        e     d  =
F#5    4        e     d  =
Ef5    4        e     d  ]     )
measure 114
D5     4        e     d  [     (
Ef5    4        e     d  =
D5     4        e     d  =     )
C5     4        e     d  =      .
Bf4    4        e     d  =      .
A4     4        e     d  ]      .
measure 115
Bf4    4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F#5    4        e #   d  =     )
F#5    4        e     d  =     (
A5     4        e     d  ]     )
measure 116
A5     4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e n   d  =     )+
F5     4        e     d  =     (
Ef5    4        e     d  ]     )
measure 117
*               E   0
P    C17:Y65
Ef5    4        e     d  [     (
D5     4        e     d  =     )
D5     4        e     d  =     (
Ef5    4        e     d  =     )
Ef5    4        e     d  =     (
*               F   15
D5     4        e     d  ]     )
measure 118
D5     4        e     d  [     (
C5     4        e     d  =     )
*               E   16
P    C17:Y70
C5     4        e     d  =     (
B4     4        e n   d  =     )
B4     4        e     d  =     (
C5     4        e     d  ]     )
measure 119
C5     4        e     u  [     (
Bf4    4        e f   u  =     )+
Bf4    4        e     u  =     (
A4     4        e     u  =     )
A4     4        e     u  =     (
*               F   0
G4     4        e     u  ]     )
measure 120
*               E   0
*     20        F   15
G4    24-       h.    u        -
measure 121
*               E   15
*     20        F   0
G4    24-       h.    u        -
measure 122
G4    16        h     u         p
Bf4    4        e     u  [     (
A4     4        e     u  ]     )
measure 123
C5     4        e     d  [     (f
P    C33:Y70
B4     4        e n   d  =
D5     4        e     d  =     )
F5     4        e     d  =      .
Af5    4        e f   d  =      .
B5     4        e n   d  ]      .
measure 124
D6     4        e     d  [      .
B5     4        e n   d  =      .
Af5    4        e f   d  =      .
F5     4        e     d  =      .
D5     4        e     d  =      .
B4     4        e n   d  ]      .
measure 125
D5     4        e     d  [     (Z
P    C33:Y67
C5     4        e     d  =
Ef5    4        e     d  =     )
G5     4        e     d  =      .
C6     4        e     d  =      .
Ef6    4        e     d  ]      .
measure 126
G6     4        e     d  [      .
Ef6    4        e     d  =      .
C6     4        e     d  =      .
G5     4        e     d  =      .
Ef5    4        e     d  =      .
C5     4        e     d  ]      .
measure 127
Bf4    4        e f   d  [     (+Z
P    C34:Y75
A4     4        e n   d  =      +
Ef6    4        e     d  =     )
C6     4        e     d  =      .
A5     4        e     d  =      .
F5     4        e     d  ]      .
measure 128
*               E   15
P    C17:Y75
Ef5    4        e     u  [      .
C5     4        e     u  =      .
A4     4        e     u  =      .
F4     4        e     u  =      .
Ef4    4        e     u  =      .
*               F   0
C4     4        e     u  ]      .
measure 129
Bf3   16        h     u        (p
A3     8        q     u        )
measure 130
Ef4   16        h f   u        (+
D4     8        q     u        )
measure 131
G4    16        h     u        (
F4     8        q     u        )
measure 132
E4     8        q n   u
rest   8        q
rest   8        q
measure 133
gA3    5        s     u  [[    (
gF4    5        s     u  ]]
Ef5   16        h f   d        )f+(
D5     8        q n   d        )+
measure 134
C5     8        q     d        (t
gB4    5        s     u  [[
gC5    5        s     u  ]]
D5     8        q     d
Bf4    8        q f   d        )
measure 135
A4     8        q     u        (
Bf4    8        q     d
B4     8        q n   d        )
measure 136
C5     8        q     d
rest   8        q
rest   8        q
measure 137
Bf3    4        e f   u  [     (+p
P    C34:Y80
C4     4        e     u  =
D4     4        e     u  =
Ef4    4        e     u  =
E4     4        e n   u  =
F4     4        e     u  ]     )
measure 138
F#4    4        e #   u  [     (
G4     4        e     u  =
Af4    4        e f   u  =
A4     4        e n   u  =
C5     4        e     u  =
Bf4    4        e     u  ]     )
measure 139
Bf4    4        e     d  [     (
Ef5    4        e f   d  =     )+
Ef5    4        e     d  =     (
D5     4        e     d  =     )
D5     4        e     d  =     (
C5     4        e     d  ]     )
measure 140
C5     8        q     d
C5     8        q     d
C5     8        q     d
measure 141
C5     4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e     d  =     )
F5     4        e     d  =     (
E5     4        e n   d  ]     )
measure 142
E5     4        e n   d  [     (
D6     4        e     d  =     )
D6     4        e     d  =     (
C6     4        e     d  =     )
C6     4        e     d  =     (
Bf5    4        e     d  ]     )
measure 143
A5    16        h     d        (
G5     8        q     d        )
measure 144
F5     8        q     d        (
D5     8        q     d
C5     8        q     d        )
measure 145
C5     4        e     u  [     (
Bf4    4        e     u  =     )
Bf4    4        e     u  =     (
A4     4        e     u  =     )
A4     4        e     u  =     (
G4     4        e     u  ]     )
measure 146
G4     4        e     u  [     (
D5     4        e     u  =     )
D5     4        e     u  =     (
C5     4        e     u  =     )
C5     4        e     u  =     (
G4     4        e     u  ]     )
measure 147
A4     4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e     d  =     )
F5     4        e     d  =     (
C5     4        e     d  ]     )
measure 148
D5     8        q     d
rest   8        q
rest   8        q
measure 149
rest  24
measure 150
rest  24
measure 151
rest  24
measure 152
*               GE  15  f
Ef5   16        h f   d        (+
*               F   0
D5     8        q     d        )
measure 153
C5     8        q     d        (p
P    C33:Y65
D5     8        q     d         t
gC5    5        s     u  [[
gD5    5        s     u  ]]
Ef5    8        q     d        )
measure 154
Bf4   16        h     d        (
D5     4        e     d  [
C5     4        e     d  ]     )
measure 155
Bf4    4        e     d  [     (
Ef5    4        e     d  =     )
Ef5    4        e     d  =     (
*               D       cresc.
P  C25:f33  C17:Y65
D5     4        e     d  =     )
D5     4        e     d  =     (
G5     4        e     d  ]     )
measure 156
G5     4        e     d  [     (
F5     4        e     d  =     )
F5     4        e     d  =     (
Bf5    4        e     d  =     )
Bf5    4        e     d  =     (
A5     4        e     d  ]     )
measure 157
A5     4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =     (
F5     4        e     d  =     )
F5     4        e     d  =     (
E5     4        e n   d  ]     )
measure 158
*               GE  16  f
P   C17:Y65  C18:Y65
E5    24        h.n   d
measure 159
*     16        F   0
Ef5   24        h.f   d         +
measure 160
Ef5    4        e     d  [     (p
P    C33:Y62
D5     4        e     d  =     )
D5     4        e     d  =     (
C5     4        e     d  =     )
G5     4        e     d  =     (
C5     4        e     d  ]     )
measure 161
gG5    0        e     u        (
Bf4   16        h     d        )
gD5    0        e     u        (
C5     6        e.    d  [     )(
Bf4    2        s     d  ]\    )
measure 162
Bf4    8        q     d        (
Ef5    8        q     d        )
Ef5    8        q     d         .
measure 163
gD5    5        s     u  [[    (
gF5    5        s     u  ]]
Ef5    8        q     d        )
Ef4    8        q     u        (.pp
Ef4    8        q     u        ).
measure 164
Ef4    8        q     u        (.
Ef4    8        q     u         .
Ef4    8        q     u        ).
measure 165
Ef4    8        q     u
Ef4    8        q     u
Ef4    8        q     u
measure 166
Ef4    8        q     u
Ef4    8        q     u
Ef4    8        q     u
measure 167
Ef4    8        q     u
Ef4    8        q     u
Ef4    8        q     u
measure 168
Ef4    8        q     u
Ef4    8        q     u
Ef4    8        q     u
measure 169
Ef4    8        q     u
*               D       dolce
P  C25:f33  C17:Y65
F5     8        q     d        (
E5     8        q n   d        )
measure 170
Ef5    8        q f   d         +.
D5    16        h     d         Z
measure 171
C5     8        q     d         .
B4    16        h n   d         Z
measure 172
C5     4        e     d  [     (
D5     4        e     d  =
Ef5    4        e     d  =     )
D5     4        e     d  =      .
C5     4        e     d  =      .
Bf4    4        e f   d  ]      .+
measure 173
A4    24        h.    u
measure 174
Ef4    8        q     u
Ef4    8        q     u
Ef4    8        q     u
measure 175
Gf5    8        q f   d        (>
F5     8        q     d        )
rest   8        q
measure 176
Gf5    8        q f   d        (>
F5     8        q     d        )
rest   8        q
measure 177
Af5    8        q f   d        (>
G5     8        q     d        )
rest   8        q
measure 178
Af5    8        q f   d        (>
G5     8        q     d        )
rest   8        q
measure 179
E5     4        e n   d  [     (
F5     4        e     d  =
G5     4        e     d  =     )
F5     4        e     d  =      .
E5     4        e     d  =      .
F5     4        e     d  ]      .
measure 180
E5     4        e n   d  [     (
F5     4        e     d  =
G5     4        e     d  =     )
F5     4        e     d  =      .
E5     4        e     d  =      .
F5     4        e     d  ]      .
measure 181
*               E   0
P    C17:Y70
E5     4        e n   d  [     (
F5     4        e     d  =     )
A5     4        e n   d  =     (+
G5     4        e     d  =     )
Bf5    4        e     d  =     (
A5     4        e     d  ]     )
measure 182
C6     4        e     d  [     (
Bf5    4        e     d  =     )
*               F   16
G5     4        e     d  =      .
E5     4        e n   d  =      .
C5     4        e     d  =      .
Bf4    4        e     d  ]      .
measure 183
A4     4        e     d  [     (f
P    C33:Y76
Bf4    4        e     d  =     )
D5     4        e     d  =     (
C5     4        e     d  =     )
Ef5    4        e f   d  =     (+
D5     4        e     d  ]     )
measure 184
F5     4        e     d  [     (
Ef5    4        e     d  =     )
C5     4        e     d  =      .
A4     4        e     d  =      .
F4     4        e     d  =      .
Ef4    4        e     d  ]      .
measure 185
D4     4        e     u  [     (p
P    C33:Y72
F4     4        e     u  =     )
Bf4    4        e     u  =     (
F4     4        e     u  =     )
D5     4        e     u  =     (
Bf4    4        e     u  ]     )
measure 186
*               E   0
P    C17:Y75
A4     4        e     d  [     (
G4     4        e     d  =     )
F#5    4        e #   d  =     (
G5     4        e     d  =
Ef5    4        e     d  =
*               F   15
C5     4        e     d  ]     )
measure 187
Bf4    8        q     d        (f
D5     8        q     d
F5     8        q n   d        )+
measure 188
F4     8        q     u        (
G4     8        q     u
A4     8        q     u        )
measure 189
C5    16        h     d        (p
P    C33:Y66
Bf4    8        q     d        )
measure 190
Ef5   16        h     d        (
D5     8        q     d        )
measure 191
G5    16        h     d        (
F5     8        q     d        )
measure 192
Ef6   16        h     d        (Z
P    C33:Y62
D6     2        s     d  [[
C6     2        s     d  ==
Bf5    2        s     d  ==
A5     2        s     d  ]]    )
measure 193
Bf5    8        q     d
rest   8        q
F4     4        e     u  [      p
P    C33:Y62
Bf4    4        e     u  ]
measure 194
A4     4        e     d  [     (
C5     4        e     d  =
Ef5    4        e     d  =     )
G5     4        e     d  =      .
F5     4        e     d  =      .
A4     4        e     d  ]      .
measure 195
Bf4    8        q     d
rest   8        q
rest   8        q
measure 196
Ef4   24        h.    u        (
measure 197
D4     8        q     u        )
rest   8        q
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/01/02} [KHM:3195760256]
TIMESTAMP: DEC/26/2001 [md5sum:0c949678d23c090df8fddcd2f686bb0f]
11/09/94 W Hewlett
WK#:55,3      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 55, No. 3, in B-flat Major
[First Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:3/4  C:4  D:Vivace Assai
Bf3    8        h     u        (p
P    C33:Y82
A3     4        q     u        )
measure 2
Ef4    8        h     u        (
D4     4        q     u        )
measure 3
G4     8        h     u        (
F4     4        q     u        )
measure 4
E4     4        q n   u
rest   4        q
rest   4        q
measure 5
C5     8        h     d        (f
P    C33:Y65
Bf4    4        q     d        )
measure 6
G4    12        h.    u
measure 7
F4     4        q     u        (
G4     4        q     u
G#4    4        q #   u        )
measure 8
A4     4        q     u
rest   4        q
rest   4        q
measure 9
Bf3    8        h f   u        (+p
P    C34:Y83
A3     4        q     u        )
measure 10
Ef4    8        h     u        (
D4     4        q     u        )
measure 11
G4     8        h     u        (
F4     4        q     u        )
measure 12
Af4    4        q f   u
rest   4        q
rest   4        q
measure 13
B4     8        h n   d        (f
P    C33:Y67
C5     4        q     d        )
measure 14
F4     4        q     u        (
D4     4        q     u
Ef4    2        e     u  [
G4     2        e     u  ]     )
measure 15
F4     8        h     u
F4     1        s     u  [[    (
Ef4    1        s     u  ==
D4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 16
D4     4        q     u
rest   4        q
rest   2        e
Ef5    1        s     d  [[    (
F5     1        s     d  ]]    )
measure 17
G5     4        q     d        (
F5     4        q     d
Ef5    4        q     d        )
measure 18
D5     4        q     d        (
F5     4        q     d
Ef5    4        q     d        )
measure 19
D5     4        q     d        (
C5     4        q     d
Bf4    4        q     d        )
measure 20
Bf4    4        q     d         p.
Bf4    4        q     d         .
Bf4    4        q     d         .
measure 21
Bf4   12        h.    d         Z
measure 22
Bf4    4        q     d         .
Bf4    4        q     d         .
Bf4    4        q     d         .
measure 23
Bf4   12        h.    d         Z
measure 24
*               E   0
P    C17:Y68
Bf4    3        e.    u  [     (
G4     1        s n   u  =\    )+
Bf4    3        e.    u  =     (
G4     1        s     u  =\    )
Bf4    3        e.    u  =     (
*               F   15
G4     1        s     u  ]\    )
measure 25
A4     3        e.    u  [     (f
Bf4    1        s     u  =\    )
A4     3        e.    u  =     (
Bf4    1        s     u  =\    )
A4     3        e.    u  =     (
Bf4    1        s     u  ]\    )
measure 26
A4     4        q     u
rest   4        q
rest   4        q
measure 27
rest  12
measure 28
C5     8        h     d        (p
P    C33:Y64
Bf4    4        q     d        )
measure 29
rest   4        q
*               E   0
P    C17:Y67
D5     4        q     d         .
*               F   15
C5     4        q     d         .
measure 30
A5     4        q     d         .f
P    C34:Y60
G5     4        q     d         .
rest   4        q
measure 31
rest   4        q
C4     4        q     u        (.p
P    C34:Y88
C4     4        q     u        ).
measure 32
G4     8        h     u        (
F4     4        q     u        )
measure 33
F4    12-       h.    u        -
measure 34
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 35
E4    12        h.n   u
measure 36
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 37
F4     2        e     d  [     (
*               DH      cresc.
P  C25:f33
A5     2        e     d  =     )
A5     2        e     d  =     (
G5     2        e     d  =     )
G5     2        e     d  =     (
F5     2        e     d  ]     )
measure 38
F5     2        e     d  [     (
E5     2        e n   d  =     )
E5     2        e     d  =     (
D5     2        e     d  =     )
D5     2        e     d  =     (
C5     2        e     d  ]     )
measure 39
C5     2        e     u  [     (
Bf4    2        e     u  =     )
Bf4    2        e     u  =     (
A4     2        e     u  =     )
A4     2        e     u  =     (
G4     2        e     u  ]     )
*               J
measure 40
G4     2        e     u  [     (f
P    C33:Y65
*               E   15
P    C17:Y68
F4     2        e     u  ]     )
F4     8        h     u
measure 41
G4     8        h     u        (
*               F   0
E4     4        q n   u        )
measure 42
F4     4        q     u        (p
P    C33:Y64
D4     4        q     u        )
D4     4        q     u
measure 43
A3     8        h     u        [
gC4    0        e     u        (
Bf3    4        q     u        )]
measure 44
A3     4        q     u        (
F4     4        q     u        )
F4     4        q     u         .
measure 45
G4     4        q     u
C4     4        q     u        (pp.
P    C33:Y88
C4     4        q     u        ).
measure 46
C4     4        q     u        (.
C4     4        q     u         .
C4     4        q     u        ).
measure 47
C4     4        q     u        (.
C4     4        q     u         .
C4     4        q     u        ).
measure 48
C4     4        q     u
C4     4        q     u
C4     4        q     u
measure 49
C4     4        q     u
C4     4        q     u
C4     4        q     u
measure 50
C4     4        q     u
C4     4        q     u
C4     4        q     u
measure 51
C4     4        q     u
C5     4        q     d        (.
C5     4        q     d        ).
measure 52
C5     4        q     d        (.
C5     4        q     d         .
C5     4        q     d        ).
measure 53
C5     4        q     d
C5     4        q     d
C5     4        q     d
measure 54
*               E   0
P    C17:Y70
C5     4        q     d
C5     4        q     d
C5     4        q     d
measure 55
C5     4        q     d
C5     4        q     d
*               F   15
C5     4        q     d
measure 56
C5     2        e     u  [      f
Bf4    2        e     u  =
A4     2        e     u  =
G4     2        e     u  =
F4     2        e     u  =
E4     2        e n   u  ]
measure 57
D4     4        q     u
Bf5    4        q     d
Bf5    4        q     d
measure 58
Bf5    8        h     d
A5     2        e     d  [     (
G5     2        e     d  ]     )
measure 59
gG5    0        e     u        (
F5     8        h     d        )
rest   4        q
measure 60
F4    12-       h.f   u        -Z
P    C33:Y92
 Af3  12-       h.    u        -
measure 61
F4    12-       h.    u        -
 Af3  12-       h.    u        -
measure 62
F4     4        q     u
 Af3   4        q     u
F4     4        q     u
 Af3   4        q f   u
F4     4        q     u
 Af3   4        q     u
measure 63
E4    12        h.    u         p
P    C33:Y85
 G3   12        h.n   u
measure 64
C4    12        h.    u
measure 65
D4    12        h.    u
measure 66
Bf3   12        h.    u
measure 67
Bf3    8        h     u        (
A3     4        q n   u        )+
measure 68
E4     8        h n   u        (
F4     4        q     u        )
measure 69
Bf4    8        h     d        (
A4     4        q     u        )
measure 70
E4     8        h n   u        (Z
Bf4    4        q     d        )
measure 71
A4     4        q     u
rest   4        q
rest   4        q
measure 72
Bf3   12        h.    u        (p
P    C33:Y84
measure 73
A3     4        q     u        )
rest   4        q
rest   4        q
measure 74
Bf4   12        h.    d        (
measure 75
A4     4        q     u        )
rest   4        q
rest   4        q
mheavy4 76                    :|:
F#4    8        h #   u        (
G4     4        q     u        )
measure 77
D4     8        h     u        (
Ef4    4        q f   u        )+
measure 78
B3     8        h n   u        (
C4     4        q     u        )
measure 79
G3     2        e     u  [      f
Af4    2        e f   u  =
G4     2        e     u  =
F4     2        e n   u  =      +
Ef4    2        e     u  =
D4     2        e     u  ]
measure 80
Ef4    2        e     u  [
G4     2        e     u  =
Af4    2        e f   u  =
G4     2        e     u  =
F4     2        e     u  =
Ef4    2        e     u  ]
measure 81
D4     2        e     u  [
Ef4    2        e     u  =
F4     2        e     u  =
B4     2        e n   u  ]
D5     1        s     d  [[    (
C5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]    )
measure 82
B4     4        q n   d
B4     3        e.    d  [     (
C5     1        s     d  =\
B4     3        e.    d  =
C5     1        s     d  ]\    )
measure 83
B4     4        q n   d
rest   4        q
rest   4        q
measure 84
Af3    8        h f   u        (p
P    C33:Y85
G3     4        q     u        )
measure 85
Df4    8        h f   u        (
C4     4        q     u        )
measure 86
F4     8        h     u        (
Ef4    4        q     u        )
measure 87
D4     4        q n   u         +
rest   4        q
rest   4        q
measure 88
Bf4    8        h f   d        (+f
Af4    4        q f   u        )
measure 89
F4    12        h.    u
measure 90
Ef4    4        q     u        (
F4     4        q     u
F#4    4        q #   u        )
measure 91
G4     4        q     u
rest   4        q
rest   4        q
measure 92
rest  12
measure 93
Bf3    8        h     u        (p
P    C33:Y83
Af3    4        q f   u        )
measure 94
Af3    4        q f   u
Af4    4        q f   u
Af4    4        q     u
measure 95
Af4    4        q f   u
Af4    4        q     u
Af4    4        q     u
measure 96
*               E   0
P    C17:Y72
G4    12        h.    u
measure 97
Bf4    4        q     d
Bf4    4        q     d
*               F   15
Bf4    4        q     d
measure 98
*               GE  15  f
P   C17:Y65  C18:Y65
Af4   12        h.f   u
measure 99
*      8        F   0
A4    12        h.n   u         +
measure 100
D4     4        q     u
rest   4        q
rest   4        q
measure 101
F4     4        q n   u        (+pp.
F4     4        q     u         .
F4     4        q     u        ).
measure 102
F4     4        q     u        (.
F4     4        q     u         .
F4     4        q     u        ).
measure 103
F4     4        q     u        (.
F4     4        q     u         .
F4     4        q     u        ).
measure 104
F4     4        q     u        (.
F4     4        q     u         .
F4     4        q     u        ).
measure 105
F4     4        q     u        (.
F4     4        q     u         .
F4     4        q     u        ).
measure 106
F4     4        q     u        (.
G4     4        q     u         .
G4     4        q     u        ).
measure 107
G4     4        q     u        (.
G4     4        q     u         .
G4     4        q     u        ).
measure 108
G4     4        q     u        (.
G4     4        q     u         .
G4     4        q     u        ).
measure 109
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 110
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 111
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 112
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 113
A4     4        q n   u         +
A4     4        q     u
A4     4        q     u
measure 114
A4     4        q     u
A4     4        q     u
A4     4        q     u
measure 115
Bf4    2        e     d  [     (
D5     2        e     d  =     )
D5     2        e     d  =     (
C5     2        e     d  =     )
C5     2        e     d  =     (
Ef5    2        e     d  ]     )
measure 116
Ef5    2        e     d  [     (
D5     2        e     d  =     )
D5     2        e     d  =     (
C5     2        e     d  =     )
C5     2        e     d  =     (
Bf4    2        e     d  ]     )
measure 117
*               E   0
P    C17:Y65
Bf4    2        e     u  [     (
A4     2        e     u  =     )
A4     2        e     u  =     (
Bf4    2        e     u  =     )
Bf4    2        e     u  =     (
*               F   15
Af4    2        e f   u  ]     )
measure 118
Af4    2        e f   u  [     (
G4     2        e     u  =     )
*               E   15
P    C17:Y70
G4     2        e     u  =     (
F4     2        e     u  =     )
F4     2        e     u  =     (
G4     2        e     u  ]     )
measure 119
G4     2        e     u  [     (
F4     2        e     u  =     )
F4     2        e     u  =     (
Ef4    2        e     u  =     )
Ef4    2        e     u  =     (
*               F   0
D4     2        e     u  ]     )
measure 120
*               E   0
P    C17:Y78
D4     2        e     u  [     (
C#4    2        e #   u  =     )
C#4    2        e     u  =     (
D4     2        e     u  =     )
D4     2        e     u  =     (
*               F   15
Ef4    2        e     u  ]     )
measure 121
*               E   15
P    C17:Y77
Ef4    2        e     u  [     (
G4     2        e     u  =     )
Ef4    2        e     u  =     (
D4     2        e     u  =     )
D4     2        e     u  =     (
*               F   0
C#4    2        e #   u  ]     )
measure 122
D4     4        q     u        (p
P    C33:Y70
G4     4        q     u        )
F#4    4        q #   u
measure 123
F4    12-       h.n   u        -f+
P    C33:Y64
measure 124
F4    12        h.    u
measure 125
Ef4   12-       h.    u        -Z
P    C33:Y72
measure 126
Ef4   12-       h.    u        -
measure 127
Ef4   12-       h.    u        -Z
P    C33:Y72
measure 128
*               E   15
P    C17:Y65
*     10        F   0
Ef4   12        h.    u
measure 129
rest   4        q
G3     4        q     u        (p
P    C33:Y91
A3     4        q     u        )
measure 130
rest   4        q
C4     4        q     u        (
Bf3    4        q     u        )
measure 131
rest   4        q
Bf3    4        q     u        (
B3     4        q n   u        )
measure 132
Bf3    4        q f   u         +
rest   4        q
rest   4        q
measure 133
C5     8        h     d        (f
P    C33:Y67
Bf4    4        q     d        )
measure 134
G4    12        h.    u
measure 135
F4     4        q     u        (
G4     4        q     u
G#4    4        q #   u        )
measure 136
A4     4        q     u
rest   4        q
rest   4        q
measure 137
rest  12
measure 138
rest  12
measure 139
rest  12
measure 140
G4     2        e n   d  [     (+p
P    C34:Y75
C5     2        e     d  =     )
C5     2        e     d  =     (
Bf4    2        e     d  =     )
Bf4    2        e     d  =     (
A4     2        e     d  ]     )
measure 141
A4     8        h     u        (
Bf4    4        q     d        )
measure 142
Bf4    4        q     u
 G4    4        q     u
E5     4        q n   d        (
G5     4        q     d        )
measure 143
G5     4        q     d        (
F5     4        q     d        )
rest   4        q
measure 144
rest  12
measure 145
rest  12
measure 146
rest  12
measure 147
rest  12
measure 148
*               D       p dolce
P  C25:f33  C25:f1  C27:f33  C17:Y70
Bf4    8        h     d        (
A4     4        q     u        )
measure 149
*               E   0
P    C17:Y65
Ef5    8        h f   d        (+
*      2        F   15
D5     4        q     d        )
measure 150
*               E   15
P    C17:Y60
G5     8        h     d        (
*               F   0
F5     4        q     d        )
measure 151
E5     4        q n   d
rest   4        q
rest   4        q
measure 152
*               GE  15  f
P   C17:Y70  C18:Y70
C5     8        h     d        (
*      2        F   0
Bf4    4        q     d        )
measure 153
G4     4        q     u        (p
F4     4        q     u
Ef4    4        q f   u        )+
measure 154
D4     8        h     u        (
F4     2        e     u  [
Ef4    2        e     u  ]     )
measure 155
D4     2        e     u  [     (
Bf4    2        e     u  ]     )
*               D       cresc.
P  C25:f33  C17:Y72
Bf4    4        q     d
Bf4    4        q     d
measure 156
Bf4    6        q.    d
F5     2        e     d  [      .
F5     2        e     d  =     (
Ef5    2        e     d  ]     )
measure 157
Ef5    2        e     d  [     (
D5     2        e     d  =     )
D5     2        e     d  =     (
C5     2        e     d  =     )
C5     2        e     d  =     (
Bf4    2        e     d  ]     )
measure 158
*      2        E   18
P    C17:Y70
Bf4   12        h.    d         f
measure 159
C5     8        h     d        (
*               F   0
A4     4        q     u        )
measure 160
Bf4    4        q     d        (p
G4     4        q     u        )
G4     4        q     u
measure 161
D4     8        h     u        (
gF4    0        e     u
Ef4    4        q f   u        )+
measure 162
D4     4        q     u        (
Bf4    4        q     d        )
Bf4    4        q     d         .
measure 163
C5     4        q     d
F4     4        q     u        (.pp
F4     4        q     u        ).
measure 164
F4     4        q     u        (.
F4     4        q     u         .
F4     4        q     u        ).
measure 165
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 166
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 167
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 168
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 169
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 170
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 171
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 172
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 173
F4     4        q     u
F4     4        q     u
F4     4        q     u
measure 174
C5     2        e     d  [     (
D5     2        e     d  =
Ef5    2        e     d  =     )
D5     2        e     d  =      .
C5     2        e     d  =      .
Bf4    2        e     d  ]      .
measure 175
A4     2        e     d  [     (
Bf4    2        e     d  =
C5     2        e     d  =     )
Bf4    2        e     d  =      .
A4     2        e     d  =      .
Bf4    2        e     d  ]      .
measure 176
A4     2        e     d  [     (
Bf4    2        e     d  =
C5     2        e     d  =     )
Bf4    2        e     d  =      .
A4     2        e     d  =      .
Bf4    2        e     d  ]      .
measure 177
B4     2        e n   d  [     (
C5     2        e     d  =
D5     2        e     d  =     )
C5     2        e     d  =      .
B4     2        e     d  =      .
C5     2        e     d  ]
measure 178
B4     2        e n   d  [     (
C5     2        e     d  =
D5     2        e     d  =     )
C5     2        e     d  =      .
B4     2        e     d  =      .
C5     2        e     d  ]      .
measure 179
Bf4    4        q f   d         +
Bf4    4        q     d
Bf4    4        q     d
measure 180
Bf4    4        q     d
Bf4    4        q     d
Bf4    4        q     d
measure 181
*               E   0
P    C17:Y70
Bf4   12        h.    d
measure 182
*      4        F   15
E4    12        h.n   u
measure 183
Ef4   12        h.f   u         +f
measure 184
A3    12        h.    u
measure 185
Bf3    4        q     u        (p
P    C33:Y80
D4     4        q     u
F4     4        q     u        )
measure 186
*               E   0
P    C17:Y75
Bf3    8        h     u
G4     2        e     u  [     (
*               F   15
Ef4    2        e     u  ]     )
measure 187
D4    12        h.    u         f
measure 188
Ef4   12        h.    u
measure 189
Ef4    8        h     u        (p
P    C33:Y68
D4     4        q     u        )
measure 190
A4     8        h     u        (
Bf4    4        q     d        )
measure 191
Ef5    8        h     d        (
D5     4        q     d        )
measure 192
A4     8        h     u        (Z
Ef5    4        q     d        )
measure 193
D5     4        q     d
rest   4        q
rest   4        q
measure 194
A4    12        h.    u        (p
P    C33:Y55
measure 195
Bf4    4        q     d        )
rest   4        q
rest   4        q
measure 196
C4    12        h.    u        (
measure 197
D4     4        q     u        )
rest   4        q
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/01/03} [KHM:3195760256]
TIMESTAMP: DEC/26/2001 [md5sum:3ed580ff90c38b6d8711f269bb8affe8]
11/09/94 W Hewlett
WK#:55,3      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 55, No. 3, in B-flat Major
[First Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:3/4  C:13  D:Vivace Assai
Bf3    8        h     u        (p
P    C33:Y55
A3     4        q     u        )
measure 2
Ef4    8        h     d        (
D4     4        q     d        )
measure 3
G4     8        h     d        (
F4     4        q     d        )
measure 4
E4     4        q n   d
rest   4        q
rest   4        q
measure 5
F4    12        h.    d         f
P    C33:Y60
measure 6
G4     4        q     d        (
Ef4    4        q f   d         +
C4     4        q     d        )
measure 7
C4     4        q     d
rest   4        q
rest   4        q
measure 8
rest  12
measure 9
Bf3    8        h f   u        (+p
P    C34:Y55
A3     4        q     u        )
measure 10
Ef4    8        h     d        (
D4     4        q     d        )
measure 11
G4     8        h     d        (
F4     4        q     d        )
measure 12
Af4    4        q f   d
rest   4        q
rest   4        q
measure 13
F4     8        h     d        (f
P    C33:Y60
Ef4    2        e     d  [
C4     2        e     d  ]     )
measure 14
G3     4        q     u        (
G4     4        q     d        )
G4     2        e     d  [     (
Ef4    2        e     d  ]     )
measure 15
D4     8        h     d
Ef4    2        e     d  [     (
C4     2        e     d  ]     )
measure 16
Bf3    4        q     u
rest   4        q
rest   4        q
measure 17
rest  12
measure 18
Bf3    6        q.    u        (
C4     1        s     d  [[
D4     1        s     d  ]]
Ef4    1        s     d  [[
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]    )
measure 19
Bf4    4        q     d        (
F#4    4        q #   d
G4     4        q     d        )
measure 20
Ef4    4        q     d        (p
P    C33:Y59
E4     4        q n   d
F4     4        q n   d        )+
measure 21
Gf4    8        h f   d        (Z
P    C33:Y60
F4     4        q     d        )
measure 22
Ef4    4        q     d        (
E4     4        q n   d
F4     4        q     d        )
measure 23
Gf4    8        h f   d        (Z
P    C33:Y60
F4     4        q     d        )
measure 24
*               E   0
P    C17:Y65
E4     4        q n   d         .
E4     4        q     d         .
*      2        F   15
E4     4        q     d         .
measure 25
F4     4        q     d         .
F4     4        q     d         .
F4     4        q     d         .
measure 26
F4     4        q     d
rest   4        q
rest   4        q
measure 27
D4     8        h     d        (p
P    C33:Y63
C4     4        q     d        )
measure 28
rest   4        q
F4     4        q     d        (.
F4     4        q     d        ).
measure 29
rest   4        q
*               E   0
P    C17:Y65
Bf4    4        q     d         .
*               F   15
A4     4        q     d         .
measure 30
F#4    4        q #   d         .f
P    C34:Y60
G4     4        q     d         .
rest   4        q
measure 31
A3     8        h     u        (p
G3     4        q     u        )
measure 32
E4     6        q.n   d        (
F4     1        s n   d  [[     +
G4     1        s     d  ]]
C4     4        q     d        )
measure 33
D4    12-       h.    d        -
measure 34
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 35
E4    12-       h.n   d        -
measure 36
E4     4        q     d
E4     4        q n   d
E4     4        q     d
measure 37
F4     2        e     d  [     (
*               DH      cresc.
P  C25:f33  C17:Y70  C18:Y70
F5     2        e     d  =     )
F5     2        e     d  =     (
E5     2        e n   d  =     )
E5     2        e     d  =     (
D5     2        e     d  ]     )
measure 38
D5     2        e     d  [     (
C5     2        e     d  =     )
C5     2        e     d  =     (
Bf4    2        e     d  =     )
Bf4    2        e     d  =     (
A4     2        e     d  ]     )
measure 39
A4     2        e     d  [     (
G4     2        e     d  =     )
G4     2        e     d  =     (
F4     2        e     d  =     )
F4     2        e     d  =     (
E4     2        e n   d  ]     )
*               J
measure 40
E4     2        e n   d  [     (f
D4     2        e     d  ]     )
*               E   15
P    C17:Y65
D4     8        h     d
measure 41
Df4    8        h f   d        (
*               F   0
C4     4        q     d        )
measure 42
C4     4        q     d        (p
D4     4        q n   d         +
F3     4        q     u        )
measure 43
F3     8        h     u        (
E3     4        q n   u        )
measure 44
F3     4        q     u        (
D4     4        q     d        )
D4     4        q     d
measure 45
C4     4        q     d
rest   4        q
rest   4        q
measure 46
rest  12
measure 47
rest  12
measure 48
rest  12
measure 49
rest  12
measure 50
rest  12
measure 51
rest   4        q
Bf4    4        q     d        (pp.
P    C33:Y57
Bf4    4        q     d        ).
measure 52
Bf4    4        q     d        (.
Bf4    4        q     d         .
Bf4    4        q     d        ).
measure 53
Bf4    4        q     d
Bf4    4        q     d
Bf4    4        q     d
measure 54
*               E   0
P    C17:Y65
Bf4    4        q     d
Bf4    4        q     d
Bf4    4        q     d
measure 55
Bf4    4        q     d
Bf4    4        q     d
*      2        F   15
Bf4    4        q     d
measure 56
A4     4        q     d         f
P    C33:Y60
A4     6        q.    d        (
Bf4    1        s     d  [[
C5     1        s     d  ]]    )
measure 57
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
measure 58
E4    12        h.n   d
measure 59
F4     4        q     d
rest   4        q
rest   4        q
measure 60
D4    12-       h.    d        -Z
P    C33:Y65
measure 61
D4    12-       h.    d        -
measure 62
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 63
C4    12        h.    d         p
measure 64
F4    12        h.    d
measure 65
G4    12        h.    d
measure 66
G3    12        h.    u
 E3   12        h.n   u
measure 67
E3     8        h n   u        (
F3     4        q     u        )
measure 68
G3     8        h     u        (
F3     4        q     u        )
measure 69
E4     8        h n   d        (
F4     4        q     d        )
measure 70
G4    12        h.    d         Z
P    C33:Y60
measure 71
F4     4        q     d
rest   4        q
rest   4        q
measure 72
G3    12        h.    u        (p
P    C33:Y63
measure 73
A3     4        q     u        )
rest   4        q
rest   4        q
measure 74
G4    12        h.    d        (
measure 75
A4     4        q     d        )
rest   4        q
rest   4        q
mheavy4 76                    :|:
F#4    8        h #   d        (
G4     4        q     d        )
measure 77
D4     8        h     d        (
Ef4    4        q f   d        )+
measure 78
B3     8        h n   u        (
C4     4        q     d        )
measure 79
G3     2        e     d  [      f
P    C33:Y84
F4     2        e n   d  =      +
Ef4    2        e     d  =
D4     2        e     d  =
C4     2        e     d  =
B3     2        e n   d  ]
measure 80
C4     2        e     d  [
Ef4    2        e     d  =
F4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 81
B3     2        e n   d  [
C4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  =
Ef4    2        e     d  ]
measure 82
G4     4        q     d
G3     4        q     u
G3     4        q     u
measure 83
G3     4        q     u
rest   4        q
rest   4        q
measure 84
Af3    8        h f   u        (p
G3     4        q     u        )
measure 85
Df4    8        h f   d        (
C4     4        q     d        )
measure 86
F4     8        h     d        (
Ef4    4        q     d        )
measure 87
D4     4        q n   d         +
rest   4        q
rest   4        q
measure 88
Ef4   12        h.    d         f
P    C33:Y60
measure 89
F4     4        q     d        (
Df4    4        q f   d
Bf3    4        q     u        )
measure 90
Bf3    4        q     u
rest   4        q
rest   4        q
measure 91
rest  12
measure 92
C4     8        h     d        (p
Bf3    4        q     u        )
measure 93
G3     6        q.    u        (
Af3    1        s f   u  [[
Bf3    1        s     u  ]]
Ef3    4        q     u        )
measure 94
F3    12        h.    u
measure 95
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 96
*               E   0
P    C17:Y63
Ef4   12        h.    d
measure 97
G4     4        q     d
G4     4        q     d
*               F   15
G4     4        q     d
measure 98
*               GE  16  f
P   C17:Y65  C18:Y65
F4    12        h.    d
measure 99
*      6        F   0
F#4   12        h.#   d
measure 100
G4     4        q     d
rest   4        q
rest   4        q
measure 101
rest  12
measure 102
rest  12
measure 103
rest  12
measure 104
rest  12
measure 105
rest  12
measure 106
rest   4        q
F4     4        q n   d        (+pp.
P    C34:Y57
F4     4        q     d        ).
measure 107
F4     4        q     d        (.
F4     4        q     d         .
F4     4        q     d        ).
measure 108
F4     4        q     d        (.
F4     4        q     d         .
F4     4        q     d        ).
measure 109
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 110
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 111
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 112
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 113
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 114
F#4    4        q #   d
F#4    4        q     d
F#4    4        q     d
measure 115
G4     2        e     d  [     (
Bf4    2        e     d  =     )
Bf4    2        e     d  =     (
A4     2        e     d  =     )
A4     2        e     d  =     (
C5     2        e     d  ]     )
measure 116
C5     2        e     d  [     (
Bf4    2        e     d  =     )
Bf4    2        e     d  =     (
Af4    2        e f   d  =     )
Af4    2        e     d  =     (
G4     2        e     d  ]     )
measure 117
*               E   0
P    C17:Y62
G4     2        e     d  [     (
F#4    2        e #   d  =     )
F#4    2        e     d  =     (
G4     2        e     d  =     )
G4     2        e     d  =     (
*               F   15
F4     2        e n   d  ]     )
measure 118
F4     2        e     d  [     (
Ef4    2        e     d  =     )
*               E   15
P    C17:Y70
Ef4    2        e     d  =     (
D4     2        e     d  =     )
D4     2        e     d  =     (
Ef4    2        e     d  ]     )
measure 119
Ef4    2        e     d  [     (
D4     2        e     d  =     )
D4     2        e     d  =     (
C4     2        e     d  =     )
C4     2        e     d  =     (
*               F   0
Bf3    2        e     d  ]     )
measure 120
*               E   0
P    C17:Y65
*     10        F   15
Bf3   12-       h.    u        -
measure 121
*               E   15
P    C17:Y65
*     10        F   0
Bf3   12-       h.    u        -
measure 122
Bf3    8        h     u         p
D4     2        e     d  [     (
C4     2        e     d  ]     )
measure 123
D4    12-       h.    d        -f
P    C33:Y65
measure 124
D4    12        h.    d
measure 125
C4    12-       h.    d        -Z
measure 126
C4    12        h.    d
measure 127
C4    12-       h.    d        -Z
measure 128
*               E   15
P    C17:Y70
*     10        F   0
C4    12        h.    d
measure 129
rest   4        q
Df3    4        q f   u        (p
C3     4        q     u        )
measure 130
rest   4        q
Gf3    4        q f   u        (
F3     4        q     u        )
measure 131
rest   4        q
G3     4        q n   u        (+.
G3     4        q     u        ).
measure 132
G3     4        q     u
rest   4        q
rest   4        q
measure 133
F4    12        h.    d         f
P    C33:Y60
measure 134
G4     4        q     d        (
Ef4    4        q     d
C4     4        q     d        )
measure 135
C4     4        q     d
rest   4        q
rest   4        q
measure 136
rest  12
measure 137
*               D       p dolce
P  C25:f33  C25:f1  C26:f33
Bf3    8        h f   u        (+
A3     4        q     u        )
measure 138
Ef4    8        h     d        (
D4     4        q     d        )
measure 139
G4     8        h     d        (
F4     4        q     d        )
measure 140
E4     4        q n   d
E4     4        q     d
E4     4        q     d
measure 141
Ef4    8        h f   d        (+
D4     4        q n   d        )+
measure 142
C4    12        h.    d
measure 143
F3     2        e     u  [     (
G3     2        e     u  =
A3     2        e     u  =
Bf3    2        e     u  =
B3     2        e n   u  =
C4     2        e     u  ]     )
measure 144
C#4    2        e #   d  [     (
D4     2        e     d  =
Ef4    2        e f   d  =      +
E4     2        e n   d  =
G4     2        e     d  =
F4     2        e     d  ]     )
measure 145
F4    12        h.    d
measure 146
E4    12        h.n   d
measure 147
Ef4   12        h.f   d         +
measure 148
D4     8        h     d        (
C4     4        q     d        )
measure 149
*               E   0
P    C17:Y60
C5     8        h     d        (
*               F   15
Bf4    4        q     d        )
measure 150
*               E   15
P    C17:Y60
G4     2        e     d  [     (
A4     2        e     d  =
Bf4    2        e     d  =
C5     2        e     d  =
D5     2        e     d  =
*               F   0
C5     2        e     d  ]     )
measure 151
Bf4    4        q     d
rest   4        q
rest   4        q
measure 152
*               GE  15  f
P   C17:Y65  C18:Y65
*     10        F   0
F4    12        h.    d
measure 153
Ef4    4        q     d        (p
P    C33:Y58
F4     4        q     d
G4     4        q     d        )
measure 154
F4     4        q     d        (
D4     4        q     d
A3     4        q     u        )
measure 155
Bf3    2        e     d  [     (
G4     2        e     d  =     )
G4     2        e     d  =     (
*               D       cresc.
P  C25:f33  C17:Y75
F4     2        e     d  =     )
F4     2        e     d  =     (
Ef4    2        e     d  ]     )
measure 156
Ef4    2        e     d  [     (
D4     2        e     d  =     )
D4     2        e     d  =     (
D5     2        e     d  =     )
D5     2        e     d  =     (
C5     2        e     d  ]     )
measure 157
C5     2        e     d  [     (
Bf4    2        e     d  =     )
Bf4    2        e     d  =     (
A4     2        e     d  =     )
A4     2        e     d  =     (
G4     2        e     d  ]     )
measure 158
*               GE  16  f
P   C17:Y65  C18:Y65
G4    12        h.    d
measure 159
Gf4    8        h f   d        (
*               F   0
F4     4        q     d        )
measure 160
F4     4        q     d        (p
P    C33:Y55
G4     4        q n   d         +
Bf3    4        q     u        )
measure 161
Bf3    8        h     u        (
A3     4        q     u        )
measure 162
Bf3    4        q     u        (
G4     4        q     d        )
G4     4        q     d         .
measure 163
F4     4        q     d
rest   4        q
rest   4        q
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest   4        q
Ef4    4        q     d        (.pp
P    C34:Y60
Ef4    4        q     d        ).
measure 170
Ef4    4        q     d        (.
Ef4    4        q     d         .
Ef4    4        q     d        ).
measure 171
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 172
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 173
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 174
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 175
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 176
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 177
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 178
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 179
G4     2        e     d  [     (
Af4    2        e f   d  =
Bf4    2        e     d  =     )
Af4    2        e     d  =      .
G4     2        e     d  =      .
Af4    2        e     d  ]      .
measure 180
G4     2        e     d  [     (
Af4    2        e f   d  =
Bf4    2        e     d  =     )
Af4    2        e     d  =      .
G4     2        e     d  =      .
Af4    2        e     d  ]      .
measure 181
*               E   0
P    C17:Y60
G4    12-       h.    d        -
measure 182
*      4        F   16
G4    12        h.    d
measure 183
A4    12        h.n   d         +f
P    C34:Y60
measure 184
C5     8        h     d
C4     4        q     d
measure 185
D4    12        h.    d         p
P    C33:Y65
measure 186
*               E   0
P    C17:Y65
Ef4    8        h     d
*      2        F   15
G3     4        q     u
measure 187
Bf3   12        h.    u         f
measure 188
A3     4        q     u        (
Bf3    4        q     u
C4     4        q     d        )
measure 189
A3     8        h     u        (p
Bf3    4        q     u        )
measure 190
C4     8        h     d        (
Bf3    4        q     u        )
measure 191
A4     8        h     d        (
Bf4    4        q     d        )
measure 192
C5    12        h.    d         Z
P    C33:Y60
measure 193
Bf4    4        q     d
rest   4        q
rest   4        q
measure 194
C4    12        h.    d        (p
measure 195
D4     4        q     d        )
rest   4        q
F3     2        e     u  [     (
Bf3    2        e     u  ]     )
measure 196
A3     2        e     d  [     (
C4     2        e     d  =
Ef4    2        e     d  =     )
G4     2        e     d  =      .
F4     2        e     d  =      .
A3     2        e     d  ]      .
measure 197
Bf3    4        q     u
rest   4        q
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/01/04} [KHM:3195760256]
TIMESTAMP: DEC/26/2001 [md5sum:66499eedc13d091907f51ced7e217c32]
11/09/94 W Hewlett
WK#:55,3      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 55, No. 3, in B-flat Major
[First Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:3/4  C:22  D:Vivace Assai
Bf2    8        h     u        (p
A2     4        q     u        )
measure 2
Ef3    8        h     d        (
D3     4        q     d        )
measure 3
G3     8        h     d        (
F3     4        q     d        )
measure 4
E3     4        q n   d
rest   4        q
rest   4        q
measure 5
A2     8        h     u        (f
Bf2    4        q     u        )
measure 6
Ef3    8        h f   d        (+
E3     4        q n   d        )
measure 7
F3    12-       h.    d        -
measure 8
*               E   15
P    C17:Y67
F3     4        q     d
Ef3    4        q f   d        (+
*               F   0
C3     4        q     u        )
measure 9
Bf2    8        h f   u        (+p
A2     4        q     u        )
measure 10
Ef3    8        h     d        (
D3     4        q     d        )
measure 11
G3     8        h     d        (
F3     4        q     d        )
measure 12
Af3    4        q f   d
rest   4        q
rest   4        q
measure 13
D3     8        h     d        (f
Ef3    4        q     d        )
measure 14
B2     8        h n   u        (
P    C32:u
C3     2        e     u  [
Ef3    2        e     u  ]     )
measure 15
F3    12        h.    d
measure 16
Bf3    4        q f   d        (+
G3     4        q     d
Ef3    4        q     d        )
measure 17
Bf2    6        q.    u        (
C3     1        s     u  [[
D3     1        s     u  ]]
Ef3    1        s     d  [[
F3     1        s     d  ==
G3     1        s     d  ==
A3     1        s n   d  ]]    )+
measure 18
Bf3    4        q     d
rest   4        q
rest   4        q
measure 19
rest  12
measure 20
rest  12
measure 21
rest  12
measure 22
rest  12
measure 23
rest  12
measure 24
rest  12
measure 25
rest  12
measure 26
rest  12
measure 27
rest   4        q
E3     4        q n   d        (p
P    C33:Y65
F3     4        q     d        )
measure 28
rest   4        q
A3     4        q     d        (
Bf3    4        q     d        )
measure 29
rest  12
measure 30
rest  12
measure 31
F3     8        h n   d        (+p
P    C34:Y60
E3     4        q n   d        )
measure 32
Bf3    8        h     d        (
A3     4        q     d        )
measure 33
D4     8        h     d        (
C4     4        q     d        )
measure 34
B3     4        q n   d
B3     4        q     d
B3     4        q     d
measure 35
C4    12        h.    d
measure 36
C#4    4        q #   d
C#4    4        q     d
C#4    4        q     d
measure 37
D4     4        q     d
rest   4        q
rest   4        q
measure 38
rest  12
measure 39
rest  12
measure 40
rest   2        e
Af3    2        e f   d  [      .f
P    C34:Y65
*               E   15
P    C17:Y69
Af3    2        e     d  =     (
G3     2        e     d  =     )
G3     2        e     d  =     (
F3     2        e     d  ]     )
measure 41
F3     2        e     d  [     (
E3     2        e n   d  =     )
F3     2        e     d  =     (
E3     2        e     d  =     )
G3     2        e     d  =     (
*               F   0
C3     2        e     d  ]     )
measure 42
F3     4        q     d         p
P    C33:Y60
Bf2    4        q     u        (
B2     4        q n   u        )
measure 43
C3    12        h.    u
measure 44
D3     4        q     d
D3     4        q     d
D3     4        q     d
measure 45
E3     4        q n   d
rest   4        q
rest   4        q
measure 46
rest   4        q
C3     4        q     u        (pp
*               D       dolce
P  C25:f33  C17:Y70
D3     4        q     d        )
measure 47
Ef3    4        q f   d         +.
E3     8        h n   d         Z
P    C33:Y65
measure 48
F3     4        q     d         .
F#3    8        h #   d         Z
P    C33:Y60
measure 49
G3     2        e     d  [     (
A3     2        e     d  =
Bf3    2        e     d  =     )
A3     2        e     d  =      .
G3     2        e     d  =      .
F3     2        e n   d  ]      .+
measure 50
E3     2        e n   d  [     (
F3     2        e     d  =
G3     2        e     d  =     )
F3     2        e     d  =      .
E3     2        e     d  =      .
D3     2        e     d  ]      .
measure 51
C3     4        q     u
rest   4        q
rest   4        q
measure 52
rest  12
measure 53
rest  12
measure 54
rest  12
measure 55
rest  12
measure 56
A3     2        e     d  [      f
P    C33:Y65
G3     2        e     d  =
F3     2        e     d  =
E3     2        e n   d  =
D3     2        e     d  =
C3     2        e     d  ]
measure 57
Bf2    2        e     u  [
A2     2        e     u  =
G2     2        e     u  =
F2     2        e     u  =
E2     2        e n   u  =
D2     2        e     u  ]
measure 58
C2     2        e     u  [     (
E2     2        e n   u  =     )
G2     2        e     u  =      .
C3     2        e     u  =      .
E3     2        e n   u  =      .
C3     2        e     u  ]      .
measure 59
F2     2        e     u  [     (
A2     2        e     u  =     )
C3     2        e     u  =      .
F3     2        e     u  =      .
A3     2        e     u  =      .
F3     2        e     u  ]      .
measure 60
B2    12-       h.n   u        -Z
measure 61
B2    12-       h.    u        -
measure 62
B2     4        q     u
B2     4        q n   u
B2     4        q     u
measure 63
Bf2   12        h.f   u         p+
measure 64
A2    12        h.    u
measure 65
Bf2   12        h.    u
measure 66
C3    12        h.    u
measure 67
rest   4        q
F2     4        q     u
F2     4        q     u
measure 68
rest   4        q
F2     4        q     u
F2     4        q     u
measure 69
rest   4        q
F2     4        q     u
F2     4        q     u
measure 70
C2    12        h.    u         Z
measure 71
F2     4        q     u
rest   4        q
rest   4        q
measure 72
C3    12        h.    u         p
measure 73
F3     4        q     d
rest   4        q
rest   4        q
measure 74
C4    12        h.    d
measure 75
F3     4        q     d
rest   4        q
rest   4        q
mheavy4 76                    :|:
F#3    8        h #   d        (p
P    C33:Y60
G3     4        q     d        )
measure 77
D3     8        h     d        (
Ef3    4        q f   d        )+
measure 78
B2     8        h n   u        (
C3     4        q     u        )
measure 79
G2    12-       h.    u        -f
P    C33:Y70
measure 80
G2    12-       h.    u        -
measure 81
G2    12-       h.    u        -
measure 82
G2     4        q     u
G2     4        q     u
G2     4        q     u
measure 83
G2     4        q     u
rest   4        q
rest   4        q
measure 84
Af2    8        h f   u        (p
G2     4        q     u        )
measure 85
Df3    8        h f   d        (
C3     4        q     u        )
measure 86
F3     8        h     d        (
Ef3    4        q     d        )
measure 87
D3     4        q n   d         +
rest   4        q
rest   4        q
measure 88
G2     8        h     u        (f
Af2    4        q f   u        )
measure 89
Df3    8        h f   d        (
D3     4        q n   d        )
measure 90
Ef3   12-       h.    d        -
measure 91
*               E   15
P    C17:Y73
Ef3    4        q     d
Df3    4        q f   d        (
*               F   0
Bf2    4        q     u        )
measure 92
Af2    8        h f   u        (p
G2     4        q     u        )
measure 93
Df3    8        h f   d        (
C3     4        q     u        )
measure 94
F3     8        h     d        (
Ef3    4        q     d        )
measure 95
D3     4        q n   d         +
D3     4        q     d
D3     4        q     d
measure 96
*               E   0
P    C17:Y70
Ef3   12        h.    d
measure 97
E3     4        q n   d
E3     4        q     d
*               F   15
E3     4        q     d
measure 98
*               GE  16  f
P   C17:Y65  C18:Y65
F3    12        h.    d
measure 99
*      6        F   0
F#3   12        h.#   d
measure 100
G3     4        q     d
rest   4        q
rest   4        q
measure 101
rest   4        q
*               D +     dolce
P  C25:f33  C17:Y-15
G2     4        q     u        (pp
A2     4        q n   u        )+
measure 102
Bf2    4        q     u         .
B2     8        h n   u         Z
measure 103
C3     4        q     u         .
C#3    8        h #   u         Z
measure 104
D3     2        e     d  [     (
Ef3    2        e f   d  =      +
F3     2        e n   d  =     )+
Ef3    2        e     d  =      .
D3     2        e     d  =      .
C3     2        e n   d  ]      +.
measure 105
B2     2        e n   u  [     (
C3     2        e     u  =
D3     2        e     u  =     )
C3     2        e     u  =      .
B2     2        e     u  =      .
A2     2        e     u  ]      .
measure 106
G2     4        q     u
rest   4        q
rest   4        q
measure 107
rest  12
measure 108
rest  12
measure 109
rest  12
measure 110
rest  12
measure 111
rest  12
measure 112
rest  12
measure 113
rest  12
measure 114
rest  12
measure 115
rest  12
measure 116
rest  12
measure 117
rest  12
measure 118
rest  12
measure 119
rest  12
measure 120
rest   2        e
C#3    2        e #   u  [      .p
*               E   0
P    C17:Y65
C#3    2        e     u  =     (
D3     2        e     u  =     )
D3     2        e     u  =     (
*               F   15
Ef3    2        e     u  ]     )
measure 121
*               E   15
P    C17:Y75
Ef3    2        e     d  [     (
G3     2        e     d  =     )
Ef3    2        e     d  =     (
D3     2        e     d  =     )
D3     2        e     d  =     (
*               F   0
C#3    2        e #   d  ]     )
measure 122
D3    12        h.    d         p
measure 123
G2    12-       h.    u        -f
P    C33:Y70
measure 124
G2    12-       h.    u        -
measure 125
G2    12-       h.    u        -Z
P    C33:Y73
measure 126
G2    12        h.    u
measure 127
F2    12-       h.    u        -Z
P    C33:Y77
measure 128
*               E   15
P    C17:Y70
*     10        F   0
F2    12        h.    u
measure 129
rest   4        q
E2     4        q n   u        (p
P    C33:Y77
F2     4        q     u        )
measure 130
rest   4        q
A2     4        q     u        (
Bf2    4        q     u        )
measure 131
rest   4        q
Ef3    4        q f   d        (+
Df3    4        q f   d        )
measure 132
C3     4        q     u
rest   4        q
rest   4        q
measure 133
A2     8        h     u        (f
Bf2    4        q     u        )
measure 134
Ef3    8        h     d        (
E3     4        q n   d        )
measure 135
F3    12-       h.    d        -
measure 136
F3     4        q     d        (
Ef3    4        q f   d         +
C3     4        q     u        )
measure 137
Bf2    4        q f   u         +p
rest   4        q
rest   4        q
measure 138
rest  12
measure 139
rest  12
measure 140
rest  12
measure 141
rest  12
measure 142
rest  12
measure 143
*               D       p dolce
P  C25:f1   C27:f33  C17:Y70
F3     8        h     d        (
E3     4        q n   d        )
measure 144
Bf3    8        h     d        (
A3     4        q     d        )
measure 145
D4     8        h     d        (
C4     4        q     d        )
measure 146
Bf3   12        h.    d
measure 147
F3    12        h.    d
measure 148
Bf2    2        e     d  [     (
C3     2        e     d  =
D3     2        e     d  =
Ef3    2        e f   d  =      +
E3     2        e n   d  =
F3     2        e     d  ]     )
measure 149
*               E   0
P    C17:Y65
F#3    2        e #   d  [     (
G3     2        e     d  =
Af3    2        e f   d  =
A3     2        e n   d  =
Bf3    2        e     d  =
*               F   15
G3     2        e     d  ]     )
measure 150
*               E   15
P    C17:Y65
Ef3    2        e f   d  [     (+
F3     2        e n   d  =      +
G3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  =
*               F   0
B3     2        e n   d  ]     )
measure 151
C4     4        q     d
rest   4        q
rest   4        q
measure 152
*               GE  15  f
P   C17:Y65 C18:Y65
A3     8        h     d        (
*      2        F   0
Bf3    4        q f   d        )+
measure 153
Ef3    4        q     d        (p
P    C33:Y65
D3     4        q     d
C3     4        q     u        )
measure 154
F3    12        h.    d
measure 155
Bf2    4        q     u
rest   4        q
rest   4        q
measure 156
rest  12
measure 157
rest  12
measure 158
rest   2        e
Df4    2        e f   d  [      f
P    C33:Y62
*               E   15
P    C17:Y65
Df4    2        e     d  =     (
C4     2        e     d  =     )
C4     2        e     d  =     (
Bf3    2        e     d  ]     )
measure 159
Bf3    2        e     d  [     (
A3     2        e     d  =     )
Bf3    2        e     d  =     (
A3     2        e     d  =     )
C4     2        e     d  =     (
*               F   0
F3     2        e     d  ]     )
measure 160
Bf3    4        q     d         p
P    C33:Y57
Ef3    4        q     d        (
E3     4        q n   d        )
measure 161
F3    12        h.    d
measure 162
G3     4        q     d
G3     4        q     d
G3     4        q     d
measure 163
A3     4        q     d
rest   4        q
rest   4        q
measure 164
rest   4        q
*               D +     dolce
P  C25:f33  C17:Y-9
F2     4        q     u        (pp
G2     4        q     u        )
measure 165
Af2    4        q f   u         .
A2     8        h n   u         Z
measure 166
Bf2    4        q     u         .
B2     8        h n   u         Z
measure 167
C3     2        e     u  [     (
D3     2        e     u  =
Ef3    2        e f   u  =     )+
D3     2        e     u  =      .
C3     2        e     u  =      .
Bf2    2        e f   u  ]      .+
measure 168
A2     2        e     u  [     (
Bf2    2        e     u  =
C3     2        e     u  =     )
Bf2    2        e     u  =      .
A2     2        e     u  =      .
G2     2        e     u  ]      .
measure 169
F2     4        q     u
rest   4        q
rest   4        q
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
C4     2        e     d  [     (
D4     2        e     d  =
Ef4    2        e     d  =     )
D4     2        e     d  =      .
C4     2        e     d  =      .
Bf3    2        e     d  ]      .
measure 174
A3     4        q     d
rest   4        q
rest   4        q
measure 175
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 176
Ef4    4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 177
D4     2        e     d  [     (
Ef4    2        e     d  =
F4     2        e     d  =     )
Ef4    2        e     d  =      .
D4     2        e     d  =      .
Ef4    2        e     d  ]      .
measure 178
D4     2        e     d  [     (
Ef4    2        e     d  =
F4     2        e     d  =     )
Ef4    2        e     d  =      .
D4     2        e     d  =      .
Ef4    2        e     d  ]      .
measure 179
Df4    4        q f   d        (>
C4     4        q     d        )
rest   4        q
measure 180
Df4    4        q f   d        (>
C4     4        q     d        )
rest   4        q
measure 181
*               E   0
P    C17:Y63
C4    12-       h.    d        -
measure 182
*      4        F   15
C4    12        h.    d
measure 183
F3    12-       h.    d        -f
measure 184
F3    12        h.    d
measure 185
Bf2   12        h.    u         p
P    C33:Y58
measure 186
*               E   0
P    C17:Y65
*     10        F   15
Ef3   12        h.    d
measure 187
F3    12        h.    d         f
measure 188
F2    12        h.    u
measure 189
rest   4        q
Bf2    4        q     u         p
P    C33:Y58
Bf2    4        q     u
measure 190
rest   4        q
Bf2    4        q     u
Bf2    4        q     u
measure 191
rest   4        q
Bf2    4        q     u
Bf2    4        q     u
measure 192
F2    12        h.    u         Z
measure 193
Bf2    4        q     u
rest   4        q
rest   4        q
measure 194
F3    12        h.    d         p
P    C33:Y60
measure 195
Bf2    4        q     u
rest   4        q
rest   4        q
measure 196
F2    12        h.    u
measure 197
Bf2    4        q     u
rest   4        q
rest   4        q
mheavy2
/END
/eof
//
