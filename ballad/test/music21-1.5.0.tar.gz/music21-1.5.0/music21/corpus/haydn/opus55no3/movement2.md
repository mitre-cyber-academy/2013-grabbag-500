&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/02/01} [KHM:683049028]
TIMESTAMP: DEC/26/2001 [md5sum:c43df9eaea7fd1884546f08747d1df5b]
11/09/94 W Hewlett
WK#:55,3      MV#:2
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
[Second Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:16   T:2/4  C:4  D:Adagio ma non troppo
Bf4    8        e     d         f
measure 1
Ef5   16        q     d        (
D5     6        s.    d  [[    )
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 2
F5     8        e     d  [      .p
P    C34:Y58
F5     8        e     d  ]      .
rest   8        e
Bf4    8        e     d         f
measure 3
G5    16        q     d        (
F5     6        s.    d  [[    )
G5     2        t     d  =]\
G5     6        s.    d  =[    (t
F5     1        x     d  ==[[
G5     1        x     d  ]]]]  )
measure 4
Af5    8        e     d  [      .p
P    C34:Y55
Af5    8        e     d  ]      .
rest   8        e
C6     8        e     d         f
P    C33:Y60
measure 5
D5    12        e.    d  [     (
Ef5    2        t     d  =[[
F5     2        t     d  ]]]
Ef5    8        e     d  [     )
Bf4    8        e     d  ]
measure 6
*               E   15
P    C17:Y70
Bf4   24        q.    d
Af4    4        s     u  [[    (
*               F   0
G4     4        s     u  ]]    )
measure 7
F4     8        e     u  [     (p
P    C33:Y63
G4     6        s.    u  =[
F4     1        x     u  ==[[
G4     1        x     u  ]]]]  )
Af4    8        e     u  [
gAf4   0        e     u        (
G4     2        t     u  =[[   ()
F4     2        t     u  ===
G4     2        t     u  ===
Af4    2        t     u  ]]]   )
measure 8
G4    16        q     u        (
F4     8        e     u        )
mheavy4                :|:
F5     8        e     d
measure 9
Bf4   16-       q     d        -
Bf4    4        s     d  [[
F#5    4        s #   d  ==    (
G5     4        s     d  ==
Ef5    4        s     d  ]]    )
measure 10
C5    24        q.    d
F5     8        e n   d         +
measure 11
*               E   0
P    C17:Y65
F5    32-       h     d        -
measure 12
F5    24        q.    d
*               F   15
Ef5    4        s     d  [[    (
D5     4        s     d  ]]    )
measure 13
C5     4        s     d  [[     .f
C5     4        s     d  ==    (t[
P    C34:u
gB4    5        s     u  [[
gC5    5        s     u  ]]    ]
D5     4        s     d  ==
Ef5    4        s     d  ]]    )
*               E   15
Bf4    8        e     d  [
gD5    0        e     u        (
C5     6        s.    d  =[    )(
*               F   0
Bf4    2        t     d  ]]\   )
measure 14
Bf4   16-       q     d        -p
Bf4    4        s     d  [[
Bf4    4        s     d  ==    (t[
P    C34:u
gA4    5        s     u  [[
gBf4   5        s     u  ]]    ]
Df5    4        s f   d  ==
C5     4        s     d  ]]    )
measure 15
Bf4    4        s f   d  [[    (+
A4     4        s n   d  ==
Af4    4        s f   d  ==
F5     4        s     d  ]]    )
Af4    4        s     d  [[    (
G4     4        s     d  ==
Ef5    4        s     d  ==
G4     4        s     d  ]]    )
measure 16
gAf4   0        e     u        (
G4     8        e     u  [     )(
F4     8        e     u  ]     )
rest   8        e
Bf4    8        e     d         f
measure 17
Ef5   16        q     d        (
D5     6        s.    d  [[    )
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 18
F5     8        e     d  [      p.
P    C33:Y58
F5     8        e     d  ]      .
rest   8        e
Bf4    8        e     d         f
measure 19
G5    16        q     d        (
F5     6        s.    d  [[    )
G5     2        t     d  =]\
G5     6        s.    d  =[    (t
F5     1        x     d  ==[[
G5     1        x     d  ]]]]  )
measure 20
Af5    8        e     d  [      .p
P    C34:Y58
Af5    8        e     d  ]      .
rest   8        e
C6     8        e     d         f
P    C33:Y62
measure 21
D5    12        e.    d  [     (
Ef5    2        t     d  =[[
F5     2        t     d  ]]]
Ef5    8        e     d  [     )
Bf4    8        e     d  ]
measure 22
*               E   15
P    C17:Y65
Bf4   16        q     d        (
*               F   0
A4     8        e n   u  [     )
Af4    8-       e f   u  ]     -p
P    C33:Y58
measure 23
Af4    4        s     u  [[    (
G4     4        s     u  ==
F4     4        s     u  ==
C5     4        s     u  ]]    )
Ef4    8        e     u  [
gG4    0        e     u        (
F4     6        s.    u  =[    )(
Ef4    2        t     u  ]]\   )
measure 24
Ef4   16        q     u
rest   8        e
mheavy4                :|:
rest   8        e
measure 25
rest  32
measure 26
rest   2        t
Bf5    2        t     d  [[[   (mf
P    C33:Y60
A5     2        t n   d  ===
Bf5    2        t     d  =]]
A5     2        t     d  =[[
Bf5    2        t     d  ===
C6     2        t     d  ===
Bf5    2        t     d  ]]]   )
Af5    2        t f   d  [[[
G5     2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  =]]
D5     2        t     d  =[[
C5     2        t     d  ===
Bf4    2        t     d  ===
Af4    2        t     d  ]]]
measure 27
G4    16        q     u
rest  16        q
measure 28
rest   2        t
Ef6    2        t     d  [[[   (
D6     2        t     d  ===
Ef6    2        t     d  =]]
D6     2        t     d  =[[
Ef6    2        t     d  ===
F6     2        t     d  ===
Ef6    2        t     d  ]]]   )
D6     2        t     d  [[[   (
C6     2        t     d  ===
Bf5    2        t     d  ===
Af5    2        t     d  =]]
G5     2        t     d  =[[
F5     2        t     d  ===
Af5    2        t     d  ===
C6     2        t     d  ]]]   )
measure 29
Ef5    2        t     d  [[[   (
D5     2        t     d  ===   )
C6     2        t     d  ===   (
Bf5    2        t     d  =]]   )
Ef5    2        t     d  =[[   (
D5     2        t     d  ===   )
C6     2        t     d  ===   (
Bf5    2        t     d  ]]]   )
Af5    2        t     d  [[[   (
G5     2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  =]]   )
D5     2        t     d  =[[   (
Ef5    2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  ]]]   )
measure 30
*               E   0
C5     2        t     d  [[[   (
Bf4    2        t     d  ===   )
Bf4    2        t     d  ===    .
Bf4    2        t     d  =]]    .
Df5    2        t f   d  =[[   (
C5     2        t     d  ===   )
C5     2        t     d  ===    .
*               F   15
C5     2        t     d  ]]]    .
*               E   15
P    C17:Y73
Df5    2        t     u  [[[   (
C5     2        t     u  ===
Df5    2        t     u  ===
C5     2        t     u  =]]   )
Bf4    2        t     u  =[[   (
Af4    2        t     u  ===
G4     2        t     u  ===
*               F   0
F4     2        t     u  ]]]   )
measure 31
Ef4    2        t     u  [[[   (p
P    C33:Y72
D4     2        t n   u  ===    +
C5     2        t     u  ===
Bf4    2        t     u  =]]   )
F4     2        t     u  =[[   (
Ef4    2        t     u  ===
C5     2        t     u  ===
Bf4    2        t     u  ]]]   )
A4     2        t n   d  [[[   (
Bf4    2        t     d  ===
Af4    2        t f   d  ===
F5     2        t     d  =]]   )
Af4    2        t     d  =[[   (
G4     2        t     d  ===
Ef5    2        t     d  ===
G4     2        t     d  ]]]   )
measure 32
Bf4   12        e.    u  [     (
Af4    1        x     u  =[[[
G4     1        x     u  ====
F4     1        x     u  ====
G4     1        x     u  ]]]]  )
F4     8        e     u
mheavy4                :|:
F5     8        e     d
measure 33
Bf4   16-       q     d        -
Bf4    2        t     d  [[[
F#5    2        t #   d  ===   (
G5     2        t     d  ===
F#5    2        t     d  =]]
G5     2        t     d  =[[
F#5    2        t     d  ===
G5     2        t     d  ===
Ef5    2        t     d  ]]]   )
measure 34
C5    16-       q     d        -
C5     2        t     d  [[[
F5     2        t n   d  ===   (+
E5     2        t n   d  ===
F5     2        t     d  =]]
E5     2        t     d  =[[
F5     2        t     d  ===
G5     2        t     d  ===
F5     2        t     d  ]]]   )
measure 35
*               E   0
P    C17:Y70
F5    32-       h     d        -
measure 36
F5    24        q.    d
F5     2        t     d  [[[   (
Ef5    2        t f   d  ===   )+
Ef5    2        t     d  ===   (
*               F   15
D5     2        t     d  ]]]   )
measure 37
D5     2        t     d  [[[   (f
C5     2        t     d  ===
B4     2        t n   d  ===
C5     2        t     d  =]]
D5     2        t     d  =[[
Ef5    2        t     d  ===
F#5    2        t #   d  ===
G5     2        t     d  ]]]   )
gG5    0        e     u        (
*               E   15
Bf4    8        e f   d  [     )
gD5    0        e     u        (
C5     6        s.    d  =[    )(
*               F   0
Bf4    2        t     d  ]]\   )
measure 38
Bf4   16-       q     d        -p
Bf4    2        t     d  [[[
A4     2        t n   d  ===   (
Bf4    2        t     d  ===
C5     2        t     d  =]]
Ef5    2        t     d  =[[
Df5    2        t f   d  ===
C5     2        t     d  ===
Bf4    2        t     d  ]]]   )
measure 39
Bf4    2        t     d  [[[   (
A4     2        t n   d  ===
Bf4    2        t     d  ===
A4     2        t     d  =]]   )
Bf4    2        t     d  =[[   (
Af4    2        t f   d  ===
F5     2        t     d  ===
Af4    2        t     d  ]]]   )
Af4    2        t     u  [[[   (
G4     2        t     u  ===
Af4    2        t     u  ===
Bf4    2        t     u  =]]   )
B4     2        t n   u  =[[   (
C5     2        t     u  ===
Af4    2        t     u  ===
F4     2        t     u  ]]]   )
measure 40
Ef4   12        e.    u  [     (
F4     2        t     u  =[[
Ef4    2        t     u  ]]]   )
D4     8        e     u
rest   8        e
measure 41
rest  32
measure 42
rest   2        t
Bf5    2        t     d  [[[   (mf
P    C33:Y62
A5     2        t n   d  ===
Bf5    2        t     d  =]]
A5     2        t     d  =[[
Bf5    2        t     d  ===
C6     2        t     d  ===
Bf5    2        t     d  ]]]   )
Af5    2        t f   d  [[[
G5     2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  =]]
D5     2        t     d  =[[
C5     2        t     d  ===
Bf4    2        t     d  ===
Af4    2        t     d  ]]]
measure 43
G4    16        q     u
rest  16        q
measure 44
rest   2        t
Ef6    2        t     d  [[[   (
D6     2        t     d  ===
Ef6    2        t     d  =]]
D6     2        t     d  =[[
Ef6    2        t     d  ===
F6     2        t     d  ===
Ef6    2        t     d  ]]]   )
D6     2        t     d  [[[   (
C6     2        t     d  ===
Bf5    2        t     d  ===
Af5    2        t     d  =]]   )
G5     2        t     d  =[[   (
F5     2        t     d  ===
Af5    2        t     d  ===
C6     2        t     d  ]]]   )
measure 45
Ef5    2        t     d  [[[   (
D5     2        t     d  ===   )
C6     2        t     d  ===   (
Bf5    2        t     d  =]]   )
Ef5    2        t     d  =[[   (
D5     2        t     d  ===   )
C6     2        t     d  ===   (
Bf5    2        t     d  ]]]   )
Af5    2        t     d  [[[   (
G5     2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  =]]   )
D5     2        t     d  =[[   (
Ef5    2        t     d  ===
F5     2        t     d  ===
Ef5    2        t     d  ]]]   )
measure 46
*               E   15
C5     2        t     d  [[[   (
Bf4    2        t     d  ===   )
Bf4    2        t     d  ===    .
Bf4    2        t     d  =]]    .
G5     2        t     d  =[[   (
Bf4    2        t     d  ===   )
Bf4    2        t     d  ===    .
Bf4    2        t     d  ]]]    .
Bf4    2        t     d  [[[   (
A4     2        t n   d  ===   )
A4     2        t     d  ===    .
A4     2        t     d  =]]    .
F5     2        t     d  =[[   (
Af4    2        t f   d  ===   )
Af4    2        t     d  ===    .
*               F   0
Af4    2        t     d  ]]]    .
measure 47
Af4    2        t     u  [[[   (p
G4     2        t     u  ===
F#4    2        t #   u  ===
G4     2        t     u  =]]   )
E4     2        t n   u  =[[   (
F4     2        t n   u  ===
Af4    2        t     u  ===
C5     2        t     u  ]]]   )
gC5    0        e     u        (
Ef4    8        e f   u  [     )
gG4    0        e     u        (
F4     6        s.    u  =[    )(
Ef4    2        t     u  ]]\   )
measure 48
Ef4   16        q     u
rest   8        e
mheavy2                :|
rest   8        e
measure 49
rest  32
measure 50
rest  16        q
rest   8        e
Ef4    8        e     u         p
measure 51
Af4   16        q     u        (
G4     6        s.    u  [[    )
A4     2        t n   u  =]\
A4     6        s.    u  =[    (t
G4     1        x     u  ==[[
A4     1        x     u  ]]]]  )
measure 52
Bf4    8        e     d  [      .
Bf4    8        e     d  ]      .
rest   8        e
Af4    8        e f   u         +
measure 53
Df5   16        q f   d        (
C5     6        s.    d  [[    )
D5     2        t n   d  =]\
D5     6        s.    d  =[    (t
C5     1        x     d  ==[[
D5     1        x     d  ]]]]  )
measure 54
Ef5    8        e     d  [      .
Ef5    8        e     d  ]      .
D5     8        e     d  [     (
Df5    8        e f   d  ]     )
measure 55
C5     6        s.    d  [[
D5     2        t n   d  ==\    +
Ef5    6        s.    d  ==
Bf4    2        t     d  ]]\
Af4    6        s.    u  [[
F4     2        t     u  ==\
G4     6        s.    u  ==
Af4    2        t     u  ]]\
measure 56
G4    16        q     u        (
F4     8        e     u        )
F5     8        e     d
measure 57
Bf4   16-       q     d        -
Bf4    4        s     d  [[
F#5    4        s #   d  ==    (
G5     4        s     d  ==
Ef5    4        s     d  ]]    )
measure 58
C5    24        q.    d
F5     8        e n   d         +
measure 59
*               E   0
P    C17:Y65
F5    32-       h     d        -
measure 60
F5    24        q.    d
Ef5    4        s     d  [[    (
*               F   15
D5     4        s     d  ]]    )
measure 61
C5     4        s     d  [[     f.
C5     4        s     d  ==    (t[
P    C34:u
gB4    5        s     u  [[
gC5    5        s     u  ]]    ]
D5     4        s     d  ==
Ef5    4        s     d  ]]    )
*               E   15
Bf4    8        e     d  [
gD5    0        e     u        (
C5     6        s.    d  =[    )(
*               F   0
Bf4    2        t     d  ]]\   )
measure 62
Bf4   16-       q     d        -p
Bf4    4        s     d  [[
Bf4    4        s     d  ==    (t[
P    C34:u
gA4    5        s     u  [[
gBf4   5        s     u  ]]    ]
Df5    4        s f   d  ==
C5     4        s     d  ]]    )
measure 63
Bf4    4        s     d  [[    (
A4     4        s n   d  ==
Af4    4        s f   d  ==
F5     4        s     d  ]]    )
Af4    4        s     d  [[    (
G4     4        s     d  ==
Ef5    4        s f   d  ==     +
G4     4        s     d  ]]    )
measure 64
gAf4   0        e     u        (
G4     8        e     u  [     )(
F4     8        e     u  ]     )
rest   8        e
Bf4    8        e     d         f
measure 65
Ef5   16        q     d        (
D5     6        s.    d  [[    )
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 66
F5     8        e     d  [      .
F5     8        e     d  ]      .
rest   8        e
Ef5    8        e     d
measure 67
Af5   16        q     d        (
G5     6        s.    d  [[    )
A5     2        t n   d  =]\
A5     6        s.    d  =[    (t
G5     1        x     d  ==[[
A5     1        x     d  ]]]]  )
measure 68
*               E   15
P    C17:Y62
Bf5   16        q     d        (
A5     8        e n   d  [     )
*               F   0
Af5    8-       e f   d  ]     -
measure 69
Af5    4        s     d  [[     p
P    C33:Y57
G5     4        s     d  ==    (
P    C33:Y58
F5     4        s     d  ==
C6     4        s     d  ]]    )
Ef5    8        e     d  [
gG5    0        e     u        (
F5     6        s.    d  =[    )(
Ef5    2        t     d  ]]\   )
measure 70
Ef5   16        q     d
rest   8        e
Bf4    8        e     d
measure 71
Ef5   16        q     d
D5     6        s.    d  [[
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 72
F5     8        e     d  [      .
F5     8        e     d  ]      .
rest   8        e
Bf4    8        e     d
measure 73
*               DH      cresc.
P  C25:f33  C17:Y70  C18:Y70
G5    16        q     d        (
F5     6        s.    d  [[    )
G5     2        t     d  =]\
G5     6        s.    d  =[    (t
F5     1        x     d  ==[[
G5     1        x     d  ]]]]  )
measure 74
Af5    8        e     d  [      .
Af5    8        e     d  ]      .
rest   8        e
*               GJ      f
P   C17:Y70
C6     8        e     d
measure 75
D5    12        e.    d  [     (
Ef5    2        t     d  =[[
F5     2        t     d  ]]]   )
Ef5    8        e     d  [
Bf4    4        s     d  =[     .p
P    C34:Y70
Bf4    4        s     d  ]]     .
measure 76
Bf4    4        s     d  [[     .
rest   4        s
Bf4    4        s     d  ==     .
Bf4    4        s     d  ]]     .
A4     4        s n   u  [[     .
rest   4        s
Af4    4        s f   u  ==     .
Af4    4        s     u  ]]     .
measure 77
Af4    4        s     u  [[    (
G4     4        s     u  ==
F4     4        s     u  ==
C5     4        s     u  ]]    )
Ef4    8        e     u  [
gG4    0        e     u        (
F4     6        s.    u  =[    )(
Ef4    2        t     u  ]]\   )
measure 78
Ef4    8        e     u
rest   8        e
F4     4        s     u  [[
F4     4        s     u  =]
F4     6        s.    u  =[    (t
Ef4    1        x     u  ==[[
F4     1        x     u  ]]]]  )
measure 79
Bf4    8        e     u  [     (
G4     4        s     u  =[
Ef4    4        s     u  ]]    )
F4     4        s     u  [[
F4     4        s     u  =]
gG4    0        e     u        (
F4     2        t     u  =[[   )(
Ef4    2        t     u  ===
F4     2        t     u  ===
G4     2        t     u  ]]]   )
measure 80
Ef4    8        e     u
rest   8        e
F4     2        t     u  [[[    pp.
P    C33:Y65
G4     2        t     u  ===    .
Af4    2        t     u  ===    .
Bf4    2        t     u  =]]    .
C5     2        t     u  =[[    .
D5     2        t     u  ===    .
Ef5    2        t     u  ===    .
F5     2        t     u  ]]]    .
measure 81
G5     4        s     d  [[    (
Ef5    4        s     d  ==    )
Bf4    4        s     d  ==     .
G4     4        s     d  ]]     .
F4     2        t     u  [[[   (
C5     2        t     u  ===
Bf4    2        t     u  ===
Af4    2        t     u  =]]
G4     2        t     u  =[[
F4     2        t     u  ===
Af4    2        t     u  ===
F4     2        t     u  ]]]   )
measure 82
Ef4    8        e     u  [
Ef4    8        e     u  =
Ef4    8        e     u  ]
rest   8        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/02/02} [KHM:683049028]
TIMESTAMP: DEC/26/2001 [md5sum:82ae5f2ec3ac1688f822f4c228f631e5]
11/09/94 W Hewlett
WK#:55,3      MV#:2
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
[Second Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:16   T:2/4  C:4  D:Adagio ma non troppo
rest   8        e
measure 1
Bf4   32        h     d         f
measure 2
Bf4    8        e     d  [      .p
P    C34:Y65
Bf4    8        e     d  ]      .
rest  16        q
measure 3
Bf4   32        h     d         f
measure 4
Af4    8        e     u  [      .p
P    C34:Y58
Af4    8        e     u  ]      .
rest   8        e
Ef4    8        e     u         f
measure 5
F4    12        e.    u  [     (
G4     2        t     u  =[[
Af4    2        t     u  ]]]
Bf4    8        e     u  [     )
Ef4    8        e     u  ]
measure 6
D4     6        s.    u  [[    (
E4     2        t n   u  =]\   )
E4     6        s.    u  =[    (t
D4     1        x     u  ==[[
E4     1        x     u  ]]]]  )
*               E   15
P    C17:Y73
F4    12        e.    u  [     (
*               F   0
Ef4    4        s f   u  ]\    )
measure 7
D4     8        e     u  [     (p
P    C33:Y73
Ef4    6        s.    u  =[
D4     1        x     u  ==[[
Ef4    1        x     u  ]]]]  )
F4     8        e     u  [
gF4    0        e     u        (
Ef4    2        t     u  =[[   )(
D4     2        t     u  ===
Ef4    2        t     u  ===
F4     2        t     u  ]]]   )
measure 8
Ef4   16        q     u        (
D4     8        e     u        )
mheavy4                :|:
rest   8        e
measure 9
rest   8        e
Bf4    2        t     u  [[[   (
Af4    2        t     u  ===
G4     2        t     u  ===
Af4    2        t     u  ]]]   )
G4     8        e     u
rest   8        e
measure 10
rest   8        e
C5     2        t     u  [[[   (
Bf4    2        t     u  ===
A4     2        t n   u  ===
Bf4    2        t     u  ]]]   )
A4     8        e     u  [
Bf4    8        e     u  ]
measure 11
*               E   0
A4     6        s.n   u  [[
B4     2        t n   u  =]\
B4     6        s.    u  =[    (t
A4     1        x     u  ==[[
B4     1        x     u  ]]]]  )
C5     8        e     d  [     (
Bf4    8        e f   d  ]     )
measure 12
A4     6        s.n   u  [[
B4     2        t n   u  =]\
B4     6        s.    u  =[    (t
A4     1        x     u  ==[[
B4     1        x     u  ]]]]  )
*               F   15
C5    12        e.    d  [     (
B4     4        s     d  ]\    )
measure 13
C5     4        s     d  [[     .f
C5     4        s     d  ==    (
B4     4        s n   d  ==
C5     4        s     d  ]]    )
*               E   15
P    C17:Y70
D4     8        e     u  [
gF4    0        e     u        (
*               F   0
Ef4    8        e     u  ]     )
measure 14
D4     8        e     u  [      p
P    C33:Y68
Bf4    2        t f   u  =[[   (+
C5     2        t     u  ===
Bf4    2        t     u  ===
Af4    2        t f   u  ]]]   )+
G4    16        q     u
measure 15
F4    16        q     u        (
Ef4   16        q     u        )
measure 16
gF4    0        e     u        (
Ef4    8        e     u  [     )(
D4     8        e     u  ]     )
rest  16        q
measure 17
Bf4   32        h     d         f
measure 18
Bf4    8        e     d  [      .p
P    C34:Y65
Bf4    8        e     d  ]      .
rest  16        q
measure 19
Bf4   32        h     d         f
measure 20
Af4    8        e     u  [      p
Af4    8        e     u  ]
rest   8        e
Ef4    8        e     u         f
measure 21
F4    12        e.    u  [     (
G4     2        t     u  =[[
Af4    2        t     u  ]]]
Bf4    8        e     u  [     )
Ef4    8        e     u  ]
measure 22
*               E   15
P    C17:Y85
D4     8        e     u  [     (
Df4    8        e f   u  =
C4     8        e     u  =
*               F   0
Cf4    8        e f   u  ]     )
measure 23
Bf3    8        e     u  [     (p
C4     8        e n   u  ]     )+
G3     8        e     u  [
gBf3   0        e     u        (
Af3    8        e     u  ]     )
measure 24
G3    16        q     u
rest   8        e
mheavy4                :|:
*               D +     dolce
P  C25:f33  C17:Y-10
Bf4    8        e     d         mf
measure 25
Ef5   16        q     d        (
D5     6        s.    d  [[    )
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 26
F5     8        e     d  [      .
F5     8        e     d  ]      .
rest   8        e
Bf4    8        e     d
measure 27
G5    16        q     d        (
F5     6        s.    d  [[    )
G5     2        t     d  =]\
G5     6        s.    d  =[    (t
F5     1        x     d  ==[[
G5     1        x     d  ]]]]  )
measure 28
Af5    8        e     d  [      .
Af5    8        e     d  ]      .
rest   8        e
C5     8        e     d
measure 29
Bf4   16        q     u        (
 D4   16        q     u        [
Bf4    8        e     u  [     )
 Ef4   8        e     u        ]
Ef4    8        e     u  ]
measure 30
*               E   0
P    C17:Y75
D4     8        e     u  [     (
*      4        F   15
E4     8        e n   u  ]     )
*               E   15
P    C17:Y75
*     14        F   0
F4    16        q     u
measure 31
Bf3   24-       q.    u        -p
Bf3    4        s     u  [     (
Ef4    4        s f   u  ]\    )+
measure 32
G4    12        e.    u  [     (
F4     1        x     u  =[[[
Ef4    1        x     u  ====
D4     1        x     u  ====
Ef4    1        x     u  ]]]]  )
D4     8        e     u
mheavy4                :|:
rest   8        e
measure 33
F4     2        t     u  [[[   (
G4     2        t     u  ===
Af4    2        t     u  ===
G4     2        t     u  =]]
Af4    2        t     u  =[[
G4     2        t     u  ===
Af4    2        t     u  ===
F#4    2        t #   u  ]]]   )
G4     8        e     u
rest   8        e
measure 34
G4     2        t     u  [[[   (
A4     2        t n   u  ===
Bf4    2        t     u  ===
A4     2        t     u  =]]
Bf4    2        t     u  =[[
A4     2        t     u  ===
Bf4    2        t     u  ===
G4     2        t     u  ]]]   )
A4     8        e     u  [
Bf4    8        e     u  ]
measure 35
*               E   0
A4     2        t n   d  [[[   (
Bf4    2        t     d  ===
A4     2        t     d  ===
C5     2        t     d  =]]   )
B4     2        t n   d  =[[   (
C5     2        t     d  ===
B4     2        t     d  ===
D5     2        t     d  ]]]   )
D5     2        t     d  [[[   (
C5     2        t     d  ===   )
C5     2        t     d  ===    .
C5     2        t     d  =]]    .
C5     2        t     d  =[[   (
Bf4    2        t f   d  ===   )
Bf4    2        t     d  ===    .
Bf4    2        t     d  ]]]    .
measure 36
A4     2        t n   d  [[[   (
Bf4    2        t     d  ===
A4     2        t     d  ===
C5     2        t     d  =]]   )
B4     2        t n   d  =[[   (
C5     2        t     d  ===
B4     2        t     d  ===
D5     2        t     d  ]]]   )
D5     2        t     d  [[[   (
C5     2        t     d  ===   )
C5     2        t     d  ===    .
C5     2        t     d  =]]    .
*               F   15
B4     8        e     d  ]     (
measure 37
C5     8        e     d        )f
rest   8        e
*               E   15
P    C17:Y70
F4     8        e     u  [
*      4        F   0
Ef4    8        e     u  ]
measure 38
Df4    8        e f   u         p
rest   8        e
C4    16-       q     u        -
measure 39
C4     8        e     u
Bf3   16        q     u
Af3    4        s     u  [[
C4     4        s     u  ]]
measure 40
Bf3    8        e     u
rest   8        e
rest   8        e
Bf4    8        e     d         mf
measure 41
Ef5   16        q     d        (
D5     6        s.    d  [[    )
Ef5    2        t     d  =]\
Ef5    6        s.    d  =[    (t
D5     1        x     d  ==[[
Ef5    1        x     d  ]]]]  )
measure 42
F5     8        e     d  [      .
F5     8        e     d  ]      .
rest   8        e
Bf4    8        e     d
measure 43
G5    16        q     d        (
F5     6        s.    d  [[    )
G5     2        t     d  =]\
G5     6        s.    d  =[    (t
F5     1        x     d  ==[[
G5     1        x     d  ]]]]  )
measure 44
Af5    8        e     d  [      .
Af5    8        e     d  ]      .
rest   8        e
C5     8        e     d
measure 45
Bf4   16        q     u        (
 D4   16        q     u        [
Bf4    8        e     u  [     )
 Ef4   8        e     u        ]
Ef4    8        e     u  ]
measure 46
*               E   15
P    C17:Y85
D4     8        e     u  [     (
Df4    8        e f   u  =
C4     8        e     u  =
*               F   0
Cf4    8        e f   u  ]     )
measure 47
Bf3    8        e     u  [     (
C4     8        e n   u  ]     )+
G3     8        e     u  [
gBf3   0        e     u        (
Af3    8        e     u  ]     )
measure 48
G3    16        q     u
rest   8        e
mheavy2                :|
Bf3    8        e     u         p
P    C33:Y75
measure 49
Ef4   16        q     u        (
D4     6        s.    u  [[    )
Ef4    2        t     u  =]\
Ef4    6        s.    u  =[    (t
D4     1        x     u  ==[[
Ef4    1        x     u  ]]]]  )
measure 50
F4     8        e     u  [      .
F4     8        e     u  ]      .
rest  16        q
measure 51
rest   8        e
F4     8        e     u
Bf3    6        s.    u  [[
C4     2        t     u  =]\
C4     6        s.    u  =[    (t
Bf3    1        x     u  ==[[
C4     1        x     u  ]]]]  )
measure 52
Bf3    8        e     u  [      .
Bf3    8        e     u  ]      .
rest  16        q
measure 53
rest   8        e
Bf4    8        e     d
Ef4    6        s.    u  [[
F4     2        t     u  =]\
F4     6        s.    u  =[     t
Ef4    1        x     u  ==[[
F4     1        x     u  ]]]]
measure 54
Ef4    8        e     u
F4    16        q     u
Ef4    8-       e     u        -
measure 55
Ef4   16        q     u
F4     6        s.    u  [[
D4     2        t     u  ==\
Ef4    6        s.    u  ==
F4     2        t     u  ]]\
measure 56
Ef4   16        q     u        (
D4     8        e     u        )
rest   8        e
measure 57
rest   8        e
Bf4    2        t     u  [[[   (
Af4    2        t     u  ===
G4     2        t     u  ===
Af4    2        t     u  ]]]   )
G4     8        e     u
rest   8        e
measure 58
rest   8        e
C5     2        t     u  [[[   (
Bf4    2        t     u  ===
A4     2        t n   u  ===
Bf4    2        t     u  ]]]   )
A4     8        e     u  [
Bf4    8        e     u  ]
measure 59
*               E   0
P    C17:Y75
A4     6        s.n   u  [[
B4     2        t n   u  =]\
B4     6        s.    u  =[    (t
A4     1        x     u  ==[[
B4     1        x     u  ]]]]  )
C5     8        e     d  [     (
Bf4    8        e f   d  ]     )
measure 60
A4     6        s.n   u  [[
B4     2        t n   u  =]\
B4     6        s.    u  =[    (t
A4     1        x     u  ==[[
B4     1        x     u  ]]]]  )
C5    12        e.    d  [     (
*               F   15
B4     4        s     d  ]\    )
measure 61
C5     4        s     d  [[     .f
P    C34:Y73
C5     4        s     d  ==    (
B4     4        s n   d  ==
C5     4        s     d  ]]    )
*               E   15
P    C17:Y70
D4     8        e     u  [
gF4    0        e     u        (
*      6        F   0
Ef4    8        e     u  ]     )
measure 62
D4     8        e     u  [      p
P    C33:Y68
Bf4    2        t f   u  =[[   (+
C5     2        t     u  ===
Bf4    2        t     u  ===
Af4    2        t f   u  ]]]   )+
G4    16        q     u
measure 63
F4    16        q     u        (
Ef4   16        q f   u        )+
measure 64
gF4    0        e     u        (
Ef4    8        e     u  [     )(
D4     8        e     u  ]     )
rest   8        e
Bf4    8        e     d         f
measure 65
G4    16        q     u        (
F4     6        s.    u  [[    )
G4     2        t     u  =]\
G4     6        s.    u  =[    (t
F4     1        x     u  ==[[
G4     1        x     u  ]]]]  )
measure 66
Af4    8        e     u
rest   8        e
rest  16        q
measure 67
rest   8        e
F5     8        e     d
Bf4    6        s.    d  [[
C5     2        t     d  =]\
C5     6        s.    d  =[    (t
Bf4    1        x     d  ==[[
C5     1        x     d  ]]]]  )
measure 68
*               E   15
P    C17:Y70
Bf4    8        e     d  [     (
Df5    8        e f   d  =
C5     8        e     d  =
*               F   0
Cf5    8        e f   d  ]     )
measure 69
Bf4    8        e     d  [     (p
P    C33:Y67
C5     8        e n   d  ]     )+
G4     8        e     u  [
gBf4   0        e     u        (
Af4    6        s.f   u  =[    )+(
G4     2        t     u  ]]\   )
measure 70
G4     2        t     d  [[[   (
Bf4    2        t     d  ===   )
Ef5    2        t     d  ===    .
Bf4    2        t     d  =]]    .
G4     2        t     d  =[[   (
Bf4    2        t     d  ===   )
Af4    2        t     d  ===    .
Bf4    2        t     d  ]]]    .
G4     2        t     u  [[[    .
Bf4    2        t     u  ===    .
F4     2        t     u  ===    .
Bf4    2        t     u  =]]    .
G4     2        t     u  =[[    .
Bf4    2        t     u  ===    .
Af4    2        t     u  ===    .
Bf4    2        t     u  ]]]    .
measure 71
G4     2        t     d  [[[   (
Bf4    2        t     d  ===   )
Ef5    2        t     d  ===    .
Bf4    2        t     d  =]]    .
G4     2        t     d  =[[   (
Bf4    2        t     d  ===   )
G4     2        t     d  ===    .
Bf4    2        t     d  ]]]    .
Af4    2        t     u  [[[    .
Bf4    2        t     u  ===    .
Af4    2        t     u  ===    .
Bf4    2        t     u  =]]    .
G4     2        t     u  =[[    .
Bf4    2        t     u  ===    .
G4     2        t     u  ===    .
Bf4    2        t     u  ]]]    .
measure 72
F4     2        t     u  [[[   (
Bf4    2        t     u  ===   )
G4     2        t     u  ===    .
Bf4    2        t     u  =]]    .
Af4    2        t     u  =[[   (
Bf4    2        t     u  ===   )
G4     2        t     u  ===    .
Bf4    2        t     u  ]]]    .
F4     2        t     u  [[[    .
Bf4    2        t     u  ===    .
G4     2        t     u  ===    .
Bf4    2        t     u  =]]    .
Af4    2        t     u  =[[    .
Bf4    2        t     u  ===    .
F4     2        t     u  ===    .
Bf4    2        t     u  ]]]    .
measure 73
*               DH      cresc.
P  C25:f33  C17:Y70C18:Y70
Ef4    2        t     u  [[[   (
Bf4    2        t     u  ===   )
Ef5    2        t     u  ===    .
Bf4    2        t     u  =]]    .
Ef5    2        t     u  =[[   (
Bf4    2        t     u  ===   )
Ef5    2        t     u  ===    .
Bf4    2        t     u  ]]]    .
Ef4    2        t     u  [[[   (
Bf4    2        t     u  ===   )
Ef5    2        t     u  ===    .
Bf4    2        t     u  =]]    .
Ef4    2        t     u  =[[   (
Bf4    2        t     u  ===   )
Ef5    2        t     u  ===    .
Bf4    2        t     u  ]]]    .
measure 74
Ef4    2        t     u  [[[   (
Af4    2        t     u  ===   )
C5     2        t     u  ===    .
Af4    2        t     u  =]]    .
C5     2        t     u  =[[   (
Af4    2        t     u  ===   )
C5     2        t     u  ===    .
Af4    2        t     u  ]]]    .
Ef4    2        t     u  [[[   (
Af4    2        t     u  ===   )
C5     2        t     u  ===    .
Af4    2        t     u  =]]    .
Ef4    2        t     u  =[[   (
Af4    2        t     u  ===   )
C5     2        t     u  ===    .
Af4    2        t     u  ]]]    .
measure 75
*               GJ      f
P   C17:Y70
F4     2        t     u  [[[   (
Af4    2        t     u  ===   )
D5     2        t     u  ===    .
Af4    2        t     u  =]]    .
F4     2        t     u  =[[    .
Af4    2        t     u  ===    .
F4     2        t     u  ===    .
D4     2        t     u  ]]]    .
Ef4    8        e     u  [
Ef4    4        s     u  =[     p.
P    C33:Y70
Ef4    4        s     u  ]]     .
measure 76
D4     4        s     u  [[     .
rest   4        s
P    C1:Y40
Df4    4        s f   u  ==     .
Df4    4        s     u  ]]     .
C4     4        s     u  [[     .
rest   4        s
P    C1:Y40
Cf4    4        s f   u  ==     .
Cf4    4        s     u  ]]     .
measure 77
Bf3    8        e     u  [     (
C4     8        e n   u  ]     )+
G3     8        e     u  [
gBf3   0        e     u        (
Af3    8        e     u  ]     )
measure 78
G3     2        t     u  [[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  =]]    .
G3     2        t     u  =[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  ]]]    .
Af3    2        t     u  [[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  =]]   )
Af3    2        t     u  =[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  ]]]   )
measure 79
G3     2        t     u  [[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  =]]    .
G3     2        t     u  =[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  ]]]    .
Af3    2        t     u  [[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  =]]   )
Af3    2        t     u  =[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  ]]]   )
measure 80
G3     2        t     u  [[[   (pp
P    C33:Y92
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  =]]    .
G3     2        t     u  =[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  ]]]    .
Af3    2        t     u  [[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  =]]   )
Af3    2        t     u  =[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  ]]]   )
measure 81
G3     2        t     u  [[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  =]]    .
G3     2        t     u  =[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  ]]]    .
Af3    2        t     u  [[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  =]]   )
Af3    2        t     u  =[[   (
Bf3    2        t     u  ===
Af3    2        t     u  ===
Bf3    2        t     u  ]]]   )
measure 82
G3     2        t     u  [[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  =]]    .
G3     2        t     u  =[[   (
Bf3    2        t     u  ===   )
Ef4    2        t     u  ===    .
Bf3    2        t     u  ]]]    .
G3     8        e     u         .
rest   8        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/02/03} [KHM:683049028]
TIMESTAMP: DEC/26/2001 [md5sum:e5f207cee0060028d044825b8cbda3f2]
11/09/94 W Hewlett
WK#:55,3      MV#:2
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
[Second Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:16   T:2/4  C:13  D:Adagio ma non troppo
rest   8        e
measure 1
G4    16        q     d        (f
P    C33:Y62
Af4    8        e     d  [
G4     8        e     d  ]     )
measure 2
F4     8        e     d  [      .p
P    C34:Y58
F4     8        e     d  ]      .
rest  16        q
measure 3
Ef4   16        q     d        (f
P    C33:Y63
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 4
Ef4    8        e     d  [      p.
P    C33:Y58
Ef4    8        e     d  ]      .
rest   8        e
C4     8        e     d         f
measure 5
Bf3   24        q.    u
Bf3    8        e     u
measure 6
Af3    8        e     u  [     (
Bf3    8        e     u  ]     )
*               E   15
P    C17:Y70
C4    12        e.    u  [     (
*               F   0
Af3    4        s     u  ]\    )
measure 7
Bf3   32-       h     u        -p
measure 8
Bf3   16        q     u
rest   8        e
mheavy4                :|:
rest   8        e
measure 9
rest   8        e
G4     2        t     d  [[[   (
F4     2        t     d  ===
Ef4    2        t     d  ===
F4     2        t     d  ]]]   )
Ef4    8        e     d
rest   8        e
measure 10
rest   8        e
A4     2        t     d  [[[   (
G4     2        t     d  ===
F4     2        t     d  ===
G4     2        t     d  ]]]   )
F4     8        e     d  [
F4     8        e     d  ]
measure 11
*               E   0
P    C17:Y65
Ef4    8        e     d  [     (
F4     8        e     d  =
G4     8        e     d  =
F4     8        e     d  ]     )
measure 12
Ef4    8        e     d  [     (
F4     8        e     d  =
G4    12        e.    d  =
*               F   15
Af4    4        s f   d  ]\    )+
measure 13
G4     4        s     d  [[     .f
P    C34:Y63
G4     4        s     d  ==    (
F4     4        s     d  ==
Ef4    4        s     d  ]]    )
*               E   15
P    C17:Y67
F4     8        e     u  [
A3     6        s.n   u  =[    (
*               F   0
Bf3    2        t     u  ]]\   )
measure 14
Bf3    8        e     d  [      p
P    C33:Y81
G4     2        t     d  =[[   (
Af4    2        t f   d  ===    +
G4     2        t     d  ===
F4     2        t     d  ]]]   )
E4    16        q n   d
measure 15
F4     8        e     d  [     (
D4     8        e     d  ]     )
Bf3   12        e.    u  [
C4     4        s     u  ]\
measure 16
Bf3   16        q     u
rest  16        q
measure 17
G4    16        q     d        (f
P    C33:Y63
Af4    8        e     d  [
G4     8        e     d  ]     )
measure 18
F4     8        e     d  [      p.
P    C33:Y58
F4     8        e     d  ]      .
rest  16        q
measure 19
Ef4   16        q f   d        (+f
P    C34:Y63
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 20
Ef4    8        e     d  [      p.
P    C33:Y57
Ef4    8        e     d  ]      .
rest   8        e
C4     8        e     d         f
measure 21
Bf3   24        q.    u
Bf3    8        e     u
measure 22
*               E   15
P    C17:Y77
Af3    8        e     u  [     (
G3     8        e     u  =
Gf3    8        e f   u  =
*               F   0
F3     8        e     u  ]     )
measure 23
Ef3   24        q.    u        (p
P    C33:Y73
D3     8        e     u        )
measure 24
Ef3   16        q     u
rest   8        e
mheavy4                :|:
rest   8        e
measure 25
Bf4   32        h     u
back  32
G4    16        q     d        (mf
P    C33:Y71
Af4    8        e     d  [
G4     8        e     d  ]     )
measure 26
Bf4    8        e     d  [      .
 F4    8        e     d
Bf4    8        e     d  ]      .
 F4    8        e     d
rest  16        q
measure 27
Bf4   32        h     d
measure 28
Ef4    8        e     d  [      .
Ef4    8        e     d  ]      .
rest   8        e
F4     8        e     d
measure 29
F4    16        q     d        (
G4     8        e     d  [     )
Bf3    8        e     d  ]
measure 30
*               E   0
P    C17:Y69
Af3    8        e     u  [     (
*      4        F   15
Bf3    8        e     u  ]     )
*               E   15
P    C17:Y69
*     14        F   0
C4    16        q     d
measure 31
F3     8        e     u  [      p
Ef3    8        e     u  =
F4     8        e     u  =
Ef4    8        e     u  ]
measure 32
Bf3   16        q     u
rest   8        e
mheavy4                :|:
rest   8        e
measure 33
D4     2        t     d  [[[   (
Ef4    2        t     d  ===
F4     2        t     d  ===
Ef4    2        t     d  =]]
F4     2        t     d  =[[
Ef4    2        t     d  ===
F4     2        t     d  ===
D4     2        t     d  ]]]   )
Ef4    8        e     d
rest   8        e
measure 34
E4     2        t n   d  [[[   (
F4     2        t     d  ===
G4     2        t     d  ===
F4     2        t     d  =]]
G4     2        t     d  =[[
F4     2        t     d  ===
G4     2        t     d  ===
E4     2        t     d  ]]]   )
F4     8        e     d  [
F4     8        e     d  ]
measure 35
*               E   0
P    C17:Y65
Ef4    8        e f   d  [     (+
F4     8        e     d  =
G4     8        e     d  =
F4     8        e     d  ]     )
measure 36
Ef4    8        e     d  [     (
F4     8        e     d  =
G4     8        e     d  =
*               F   15
Af4    8        e f   d  ]     )+
measure 37
G4    16        q     d         f
P    C33:Y60
*               E   15
P    C17:Y65
D4     8        e     u  [
*      4        F   0
A3     8        e n   u  ]
measure 38
rest   2        t
C4     2        t     d  [[[   (p
Df4    2        t f   d  ===
C4     2        t     d  =]]
Df4    2        t     d  =[[
C4     2        t     d  ===
Bf3    2        t     d  ===
Af3    2        t f   d  ]]]   )+
G3    16        q     u
measure 39
F3     8        e     u  [
F4     8        e     u  ]
Ef4   12        e.    d  [     (
C4     2        t     d  =[[
Af3    2        t     d  ]]]   )
measure 40
G3    12        e.    u  [     (
Af3    2        t     u  =[[
G3     2        t     u  ]]]   )
F3     8        e     u
rest   8        e
measure 41
Bf4   32        h     u
back  32
G4    16        q     d        (mf
P    C33:Y71
Af4    8        e     d  [
G4     8        e     d  ]     )
measure 42
Bf4    8        e     d  [      .
 F4    8        e     d
Bf4    8        e     d  ]      .
 F4    8        e     d
rest  16        q
measure 43
Bf4   32        h     d
measure 44
Ef4    8        e     d  [      .
Ef4    8        e     d  ]      .
rest   8        e
F4     8        e     d
measure 45
F4    16        q     d        (
G4     8        e     d  [     )
Bf3    8        e     d  ]
measure 46
*               E   15
P    C17:Y77
Af3    8        e     u  [     (
G3     8        e     u  =
Gf3    8        e f   u  =
*               F   0
F3     8        e     u  ]     )
measure 47
Ef3   24        q.    u        (p
P    C33:Y74
D3     8        e     u        )
measure 48
Ef3   16        q     u
rest   8        e
mheavy2                :|
rest   8        e
measure 49
rest   8        e
Ef3    8        e     u         p
P    C33:Y65
Bf3   16        q     u        (
measure 50
Af3    6        s.    u  [[    )
Bf3    2        t     u  =]\
Bf3    6        s.    u  =[    (t
Af3    1        x     u  ==[[
Bf3    1        x     u  ]]]]  )
C4     8        e     d  [      .
C4     8        e     d  ]      .
measure 51
rest   8        e
D3     8        e     u  [
G3     8        e     u  =
F3     8        e     u  ]
measure 52
F3     6        s.    u  [[
G3     2        t     u  =]\
G3     6        s.    u  =[    (t
F3     1        x     u  ==[[
G3     1        x     u  ]]]]  )
Af3    8        e     u  [      .
Af3    8        e     u  ]      .
measure 53
rest   8        e
G3     8        e     u  [
C4     8        e     u  =
Bf3    8        e     u  ]
measure 54
Bf3    6        s.    u  [[
C4     2        t     u  =]\
C4     6        s.    u  =[    (t
Bf3    1        x     u  ==[[
C4     1        x     u  ]]]]  )
D4     6        s.    u  [[
Bf3    2        t     u  =]\
Bf3    6        s.    u  =[    (t
Af3    1        x     u  ==[[
Bf3    1        x     u  ]]]]  )
measure 55
C4     8        e     u  [
Bf3    8        e     u  =
Bf3    8        e     u  =
Bf3    8        e     u  ]
measure 56
Bf3   16        q     u
rest  16        q
measure 57
rest   8        e
G4     2        t     d  [[[   (
F4     2        t     d  ===
Ef4    2        t     d  ===
F4     2        t     d  ]]]   )
Ef4    8        e     d
rest   8        e
measure 58
rest   8        e
A4     2        t     d  [[[   (
G4     2        t     d  ===
F4     2        t     d  ===
G4     2        t     d  ]]]   )
F4     8        e     d  [
F4     8        e     d  ]
measure 59
*               E   0
Ef4    6        s.    d  [[
F4     2        t     d  =]\
F4     6        s.    d  =[    (t
Ef4    1        x     d  ==[[
F4     1        x     d  ]]]]  )
G4     8        e     d  [     (
F4     8        e     d  ]     )
measure 60
Ef4    6        s.    d  [[
F4     2        t     d  =]\
F4     6        s.    d  =[    (t
Ef4    1        x     d  ==[[
F4     1        x     d  ]]]]  )
G4    12        e.    d  [     (
*               F   15
Af4    4        s f   d  ]\    )+
measure 61
G4     4        s     d  [[     f.
P    C33:Y63
G4     4        s     d  ==    (
F4     4        s     d  ==
Ef4    4        s     d  ]]    )
*               E   15
P    C17:Y68
F4     8        e     u  [
A3     6        s.n   u  =[    (
*               F   0
Bf3    2        t     u  ]]\   )
measure 62
Bf3    8        e     d  [      p
P    C33:Y80
G4     2        t     d  =[[   (
Af4    2        t f   d  ===    +
G4     2        t     d  ===
F4     2        t     d  ]]]   )
E4    16        q n   d
measure 63
F4     8        e     d  [     (
D4     8        e     d  ]     )
Bf3   12        e.    u  [     (
C4     4        s     u  ]\    )
measure 64
Bf3   16        q     u
rest  16        q
measure 65
rest   8        e
Bf3    8        e     u  [      f
Af3    8        e     u  =
G3     8        e     u  ]
measure 66
C4     6        s.    d  [[
D4     2        t     d  =]\
D4     6        s.    d  =[    (t
C4     1        x     d  ==[[
D4     1        x     d  ]]]]  )
Ef4    8        e f   d  [      +.
Ef4    8        e     d  ]      .
measure 67
rest   8        e
D4     8        e     d  [
G4     8        e     d  =
F4     8        e     d  ]
measure 68
*               E   15
P    C17:Y75
F4     6        s.    d  [[
G4     2        t     d  =]\
G4     6        s.    d  =[    (t
F4     1        x     d  ==[[
G4     1        x     d  ]]]]  )
A4     8        e n   d  [     (
*               F   0
F4     8        e     d  ]     )
measure 69
Ef4   24        q.    d        (p
P    C33:Y62
D4     8        e     d        )
measure 70
Ef4    8        e     d  [
Ef4    4        s     d  =[     .
F4     4        s     d  ]]     .
Ef4    4        s     d  [[     .
D4     4        s     d  ==     .
Ef4    4        s     d  ==     .
F4     4        s     d  ]]     .
measure 71
Ef4    8        e     d  [
Ef4    8        e     d  =
F4     8        e     d  =
Ef4    8        e     d  ]
measure 72
D4     4        s     d  [[     .
Ef4    4        s     d  ==     .
F4     4        s     d  ==     .
Ef4    4        s     d  ]]     .
D4     4        s     d  [[     .
Ef4    4        s     d  ==     .
F4     4        s     d  ==     .
D4     4        s     d  ]]     .
measure 73
*               DH      cresc.
P  C25:f33  C17:Y70  C18:Y70
Df4   32        h f   d
measure 74
C4    32        h     d
measure 75
*               GJ      f
P   C17:Y75
Af3   16        q     u
G3     8        e     u  [
Bf3    4        s     u  =[     p.
Bf3    4        s     u  ]]     .
measure 76
Af3    4        s     u  [[     .
rest   4        s
P    C1:Y30
G3     4        s     u  ==     .
G3     4        s     u  ]]     .
Gf3    4        s f   u  [[     .
rest   4        s
P    C1:Y30
F3     4        s     u  ==     .
F3     4        s     u  ]]     .
measure 77
Ef3   24        q.    u        (
D3     8        e     u        )
measure 78
Ef3   16        q     u        (
D3    16        q     u        )
measure 79
Ef3   16        q     u        (
D3    16        q     u        )
measure 80
Ef3   16        q     u        (pp
P    C33:Y79
D3    16        q     u        )
measure 81
Ef3   16        q     u        (
D3    16        q     u        )
measure 82
Ef3    8        e     u  [
G3     8        e     u  =
Ef3    8        e     u  ]
rest   8        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/02/04} [KHM:683049028]
TIMESTAMP: DEC/26/2001 [md5sum:68794bff7b6c9d7c4e991ac7410146ff]
11/09/94 W Hewlett
WK#:55,3      MV#:2
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
[Second Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:16   T:2/4  C:22  D:Adagio ma non troppo
rest   8        e
measure 1
Ef4   16        q     d        (f
P    C33:Y62
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 2
D4     8        e     d  [      p.
P    C33:Y57
D4     8        e     d  ]      .
rest  16        q
measure 3
Ef4   16        q     d        (f
P    C33:Y63
D4     8        e     d  [
Df4    8        e f   d  ]     )
measure 4
C4     8        e     d  [      p.
P    C33:Y57
C4     8        e     d  ]      .
rest   8        e
Af3    8        e     d         f
P    C33:Y63
measure 5
Af3   16        q     d        (
G3     8        e     d  [     )
G3     8        e     d  ]
measure 6
F3     8        e     d  [     (
G3     8        e     d  ]     )
*               E   15
P    C17:Y65
*     12        F   0
Af3   16-       q     d        -
measure 7
Af3    8        e     d  [      p
P    C33:Y65
G3     8        e     d  =
D3     8        e     d  =
Ef3    8        e     d  ]
measure 8
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
mheavy4                :|:
rest   8        e
measure 9
rest   8        e
*               E   15
P    C17:Y60
D4     8        e     d  [     (
*               F   0
Ef4    8        e     d  ]     )
rest   8        e
measure 10
rest   8        e
*               E   15
P    C17:Y62
E4     8        e n   d  [     (
*      4        F   0
F4     8        e     d  =
D4     8        e     d  ]     )
measure 11
*               E   0
P    C17:Y65
C4     8        e     d  [     (
D4     8        e     d  =
Ef4    8        e f   d  =      +
D4     8        e     d  ]     )
measure 12
C4     8        e     d  [     (
D4     8        e     d  =
Ef4   12        e.    d  =
*               F   15
F4     4        s     d  ]\    )
measure 13
Ef4    4        s     d  [[     .
Ef4    4        s     d  ==    (
D4     4        s     d  ==
C4     4        s     d  ]]    )
*               E   15
P    C17:Y65
*     14        F   0
F3    16        q     d
measure 14
Bf2   32-       h     u        -p
measure 15
Bf2   16-       q     u        -
Bf2   12        e.    u  [     (
A2     4        s n   u  ]\    )
measure 16
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
rest   8        e
measure 17
Ef4   16        q     d        (f
P    C33:Y63
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 18
D4     8        e     d  [      p.
P    C33:Y57
D4     8        e     d  ]      .
rest  16        q
measure 19
Ef4   16        q     d        (f
P    C33:Y63
D4     8        e     d  [
Df4    8        e f   d  ]     )
measure 20
C4     8        e     d  [      p.
P    C33:Y57
C4     8        e     d  ]      .
rest   8        e
Af3    8        e     d         f
P    C33:Y63
measure 21
Af3   16        q     d        (
G3     8        e     d  [     )
G3     8        e     d  ]
measure 22
*               E   15
P    C17:Y71
F3     8        e     d  [     (
E3     8        e n   d  =
Ef3    8        e f   d  =
*               F   0
D3     8        e     d  ]     )
measure 23
Ef3    8        e     u  [      p
Af2    8        e     u  ]
Bf2   16        q     u
measure 24
Ef3    8        e     u  [
Bf2    8        e     u  =
Ef2    8        e     u  ]
mheavy4                :|:
rest   8        e
measure 25
Ef4   16        q     d        (mf
P    C33:Y63
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 26
D4     8        e     d  [      .
D4     8        e     d  ]      .
rest  16        q
measure 27
Ef4   16        q     d        (
D4     8        e     d  [
Df4    8        e f   d  ]     )
measure 28
C4     8        e     d  [      .
C4     8        e     d  ]      .
rest   8        e
Af3    8        e     d
measure 29
Af3   16        q     d        (
G3     8        e     d  [     )
G3     8        e     d  ]
measure 30
*               E   0
P    C17:Y65
F3     8        e     d  [
*      4        F   15
G3     8        e     d  ]
*               E   15
P    C17:Y65
*     14        F   0
Af3   16-       q     d        -
measure 31
Af3    8        e     d  [      p
P    C33:Y68
G3     8        e     d  =
D3     8        e     d  =
Ef3    8        e     d  ]
measure 32
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
mheavy4                :|:
rest   8        e
measure 33
rest   8        e
Bf2    8        e     u  [
Ef2    8        e     u  ]
rest   8        e
measure 34
rest   8        e
C3     8        e     u  [
F2     8        e     u  ]
D4     8        e     d
measure 35
*               E   0
P    C17:Y65
C4     8        e     d  [     (
D4     8        e     d  =
Ef4    8        e     d  =
D4     8        e     d  ]     )
measure 36
C4     8        e     d  [     (
D4     8        e     d  =
Ef4    8        e     d  =
*               F   15
F4     8        e     d  ]     )
measure 37
Ef4   16        q     d         f
P    C33:Y62
*               E   15
P    C17:Y65
F3     8        e     d  [
*      4        F   0
F3     8        e     d  ]
measure 38
rest   2        t
A2     2        t n   u  [[[   (p
Bf2    2        t     u  ===
A2     2        t     u  =]]
Bf2    2        t     u  =[[
Af2    2        t f   u  ===
G2     2        t     u  ===
F2     2        t     u  ]]]   )
E2    16        q n   u
measure 39
F2     8        e     u  [
D2     8        e     u  =
Ef2    8        e f   u  =      +
Af2    8        e     u  ]
measure 40
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
rest   8        e
measure 41
Ef4   16        q     d        (mf
P    C33:Y63
F4     8        e     d  [
Ef4    8        e     d  ]     )
measure 42
D4     8        e     d  [      .
D4     8        e     d  ]      .
rest  16        q
measure 43
Ef4   16        q     d        (
D4     8        e     d  [
Df4    8        e f   d  ]     )
measure 44
C4     8        e     d  [      .
C4     8        e     d  ]      .
rest   8        e
Af3    8        e     d
measure 45
Af3   16        q     d        (
G3     8        e     d  [     )
G3     8        e     d  ]
measure 46
*               E   15
P    C17:Y70
F3     8        e     d  [     (
E3     8        e n   d  =
Ef3    8        e f   d  =
*               F   0
D3     8        e     d  ]     )
measure 47
Ef3    8        e     u  [      p
P    C33:Y58
Af2    8        e     u  ]
Bf2   16        q     u
measure 48
Ef3    8        e     u  [
Bf2    8        e     u  =
Ef2    8        e     u  ]
mheavy2                :|
rest   8        e
measure 49
rest  32
measure 50
rest  32
measure 51
rest   8        e
Bf2    8        e     u         p
P    C33:Y58
Ef3   16        q     d        (
measure 52
D3     6        s.    d  [[    )
E3     2        t n   d  =]\
E3     6        s.    d  =[    (t
D3     1        x     d  ==[[
E3     1        x     d  ]]]]  )
F3     8        e     d  [      .
F3     8        e     d  ]      .
measure 53
rest   8        e
Ef3    8        e f   d         +
Af3   16        q     d        (
measure 54
G3     6        s.    d  [[    )
A3     2        t n   d  =]\
A3     6        s.    d  =[    (t
G3     1        x     d  ==[[
A3     1        x     d  ]]]]  )
Bf3    6        s.    d  [[
G3     2        t     d  =]\
G3     6        s.    d  =[    (ts
F3     1        x     d  ==[[
G3     1        x     d  ]]]]  )
measure 55
Af3    8        e f   d  [      +
G3     8        e     d  =
D3     8        e     d  =
Ef3    8        e     d  ]
measure 56
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
rest   8        e
measure 57
rest   8        e
*               E   15
P    C17:Y60
D4     8        e     d  [     (
*               F   0
Ef4    8        e     d  ]     )
rest   8        e
measure 58
rest   8        e
*               E   15
P    C17:Y60
E4     8        e n   d  [     (
*               F   0
F4     8        e     d  =     )
D4     8        e     d  ]
measure 59
*               E   0
P    C17:Y65
C4     6        s.    d  [[
D4     2        t     d  =]\
D4     6        s.    d  =[    (t
C4     1        x     d  ==[[
D4     1        x     d  ]]]]  )
Ef4    8        e f   d  [     (+
D4     8        e     d  ]     )
measure 60
C4     6        s.    d  [[
D4     2        t     d  =]\
D4     6        s.    d  =[    (t
C4     1        x     d  ==[[
D4     1        x     d  ]]]]  )
Ef4   12        e.    d  [     (
*               F   15
F4     4        s     d  ]\    )
measure 61
Ef4    4        s     d  [[     .f
P    C34:Y60
Ef4    4        s     d  ==    (
D4     4        s     d  ==
C4     4        s     d  ]]    )
*               E   15
P    C17:Y65
*     14        F   0
F3    16        q     d
measure 62
Bf2   32-       h     u        -p
measure 63
Bf2   16-       q     u        -
Bf2   12        e.    u  [
A2     4        s n   u  ]\
measure 64
Bf2    8        e     d  [
Bf3    8        e     d  =
Bf2    8        e     d  ]
rest   8        e
measure 65
rest   8        e
Ef2    8        e f   u         +f
Bf2   16        q     u        (
measure 66
Af2    6        s.f   u  [[    )+
Bf2    2        t     u  =]\
Bf2    6        s.    u  =[    (t
Af2    1        x     u  ==[[
Bf2    1        x     u  ]]]]  )
C3     8        e     u  [      .
C3     8        e     u  ]      .
measure 67
rest   8        e
Bf2    8        e     u
Ef3   16        q     d        (
measure 68
*               E   15
P    C17:Y85
D3     6        s.    d  [[    )
E3     2        t n   d  =]\
E3     6        s.    d  =[    (t
D3     1        x     d  ==[[
E3     1        x     d  ]]]]  )
F3     8        e     d  [     (
*               F   0
D3     8        e     d  ]     )
measure 69
Ef3    8        e f   u  [      +p
Af2    8        e f   u  =      +
Bf2    8        e     u  =
Bf2    8        e     u  ]
measure 70
Ef3   16        q     d
rest  16        q
measure 71
rest  32
measure 72
rest  16        q
Bf2    8        e     u  [
Bf2    8        e     u  ]
measure 73
*               DH      cresc.
P  C25:f33  C17:Y85C18:Y85
Ef2   32-       h     u        -
measure 74
Ef2   32-       h     u        -
measure 75
*               GJ      f
P   C17:Y85
Ef2   24        q.    u
G3     4        s     d  [[     p.
P    C33:Y60
G3     4        s     d  ]]     .
measure 76
F3     4        s     d  [[     .
rest   4        s
P    C1:Y10
E3     4        s n   d  ==     .
E3     4        s     d  ]]     .
Ef3    4        s f   d  [[     .
rest   4        s
P    C1:Y10
D3     4        s     d  ==     .
D3     4        s     d  ]]     .
measure 77
Ef3    8        e     u  [
Af2    8        e     u  =
Bf2    8        e     u  =
Bf2    8        e     u  ]
measure 78
Ef2   32-       h     u        -
measure 79
Ef2   32-       h     u        -
measure 80
Ef2   32-       h     u        -pp
P    C33:Y80
measure 81
Ef2   32        h     u
measure 82
Ef2    8        e     u  [
Ef2    8        e     u  =
Ef2    8        e     u  ]
rest   8        e
mheavy2
/END
/eof
//
