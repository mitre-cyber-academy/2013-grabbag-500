&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/04/01} [KHM:1032453914]
TIMESTAMP: DEC/26/2001 [md5sum:1f7a49780d0a5cba0e1e748ee176fc11]
11/09/94 W Hewlett
WK#:55,3      MV#:4
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Finale [Fourth Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:8   T:6/8  C:4  D:Finale Presto
Bf5    2        s     d  [[    (f
P    C33:Y60
A5     2        s     d  ]]    )
measure 1
G5     2        s     d  [[    (
F5     2        s     d  ==    )
Ef5    2        s     d  ==     .
D5     2        s     d  ==     .
G5     2        s     d  ==    (
F5     2        s     d  ]]    )
Ef5    2        s     d  [[    (
D5     2        s     d  ==    )
C5     2        s     d  ==     .
Bf4    2        s     d  ==     .
Ef5    2        s     d  ==    (
D5     2        s     d  ]]    )
measure 2
C5     2        s     u  [[     .
Bf4    2        s     u  ==     .
A4     2        s     u  ==     .
G4     2        s     u  ==     .
F4     2        s     u  ==     .
Ef4    2        s     u  ]]     .
D4     2        s     u  [[
F4     2        s     u  ==
Ef4    2        s     u  ==
G4     2        s     u  ==
F4     2        s     u  ==
A4     2        s     u  ]]
measure 3
G4     2        s     d  [[
Bf4    2        s     d  ==
A4     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     d  [[
D5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ==
Bf4    2        s     d  ]]
measure 4
E5     2        s n   d  [[    (
F5     2        s     d  ==    )
E5     2        s     d  ==    (
F5     2        s     d  ==    )
D5     2        s     d  ==     .
Bf4    2        s     d  ]]     .
F5     8        q     d
Bf5    2        s     d  [[    (
A5     2        s     d  ]]    )
measure 5
G5     2        s     d  [[    (
F5     2        s     d  ==    )
Ef5    2        s f   d  ==     +.
D5     2        s     d  ==     .
G5     2        s     d  ==    (
F5     2        s     d  ]]    )
Ef5    2        s     d  [[    (
D5     2        s     d  ==    )
C5     2        s     d  ==     .
Bf4    2        s     d  ==     .
Ef5    2        s     d  ==    (
D5     2        s     d  ]]    )
measure 6
C5     2        s     u  [[     .
Bf4    2        s     u  ==     .
A4     2        s     u  ==     .
G4     2        s     u  ==     .
F4     2        s     u  ==     .
Ef4    2        s     u  ]]     .
D4     2        s     u  [[
F4     2        s     u  ==
Ef4    2        s     u  ==
G4     2        s     u  ==
F4     2        s     u  ==
A4     2        s     u  ]]
measure 7
G4     2        s     d  [[
Bf4    2        s     d  ==
A4     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     d  [[
G5     2        s     d  ==
F#5    2        s #   d  ==
G5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]
measure 8
Bf4    2        s     d  [[
D5     2        s     d  ==
F5     2        s n   d  ==     +
D5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]
Bf4    8        q     d
Bf5    4        e     d        (p
P    C33:Y55
measure 9
A5     4        e     d  [     )
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
F6     4        e     d  [      .
F6     4        e     d  =      .
D6     2        s     d  =[    (
Bf5    2        s     d  ]]    )
measure 10
A5     4        e     d  [      .
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
Bf5    4        e     d  [      .
Bf5    4        e     d  =      .
Bf5    4        e     d  ]     (
measure 11
A5     4        e     d  [     )
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
F6     4        e     d  [      .
F6     4        e     d  =      .
D6     2        s     d  =[    (
Bf5    2        s     d  ]]    )
measure 12
A5     4        e     d  [      .
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
Bf5    4        e     d  [
Bf5    4        e     d  =
D6     2        s     d  =[     f
P    C33:Y63
C#6    2        s #   d  ]]
measure 13
D6     2        s     d  [[
C#6    2        s #   d  ==
D6     2        s     d  ==
C#6    2        s     d  ==
D6     2        s     d  ==
A5     2        s     d  ]]
Bf5    2        s     d  [[
A5     2        s     d  ==
Bf5    2        s     d  ==
G5     2        s     d  ==
C6     2        s n   d  ==     Z
P    C33:Y60
B5     2        s n   d  ]]
measure 14
C6     2        s     d  [[
B5     2        s n   d  ==
C6     2        s     d  ==
B5     2        s     d  ==
C6     2        s     d  ==
G5     2        s     d  ]]
A5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
F5     2        s     d  ==
C5     2        s     d  ==
F5     2        s     d  ]]
measure 15
E5     2        s n   d  [[
G5     2        s     d  ==
E5     2        s     d  ==
C5     2        s     d  ==
F5     2        s     d  ==
A5     2        s     d  ]]
G5     2        s     d  [[
Bf5    2        s     d  ==
G5     2        s     d  ==
C5     2        s     d  ==
A5     2        s     d  ==
F5     2        s     d  ]]
measure 16
E5     2        s n   d  [[
G5     2        s     d  ==
E5     2        s     d  ==
C5     2        s     d  ==
F5     2        s     d  ==
A5     2        s     d  ]]
G5     2        s     d  [[
Bf5    2        s     d  ==
G5     2        s     d  ==
C5     2        s     d  ==
A5     2        s     d  ==
F5     2        s     d  ]]
measure 17
C6     4        e     d  [
C6     4        e     d  =
C6     4        e     d  ]
C6     4        e     d  [
C6     4        e     d  =
C6     4        e     d  ]
measure 18
C6     4        e     d  [
C6     4        e     d  =
C6     4        e     d  ]
C6     4        e     d  [
C6     4        e     d  =
C6     4        e     d  ]
measure 19
C6     4        e     d  [     (
B5     4        e n   d  =     )
B5     4        e     d  ]      .
B5     4        e     d  [     (
Bf5    4        e f   d  =     )
Bf5    4        e     d  ]      .
measure 20
Bf5   12-       q.    d        -Z
P    C33:Y60
Bf5    4        e     d  [
gC6    0        e     u        (
Bf5    2        s     d  =[    )(
A5     2        s     d  ==
Bf5    2        s     d  ==
C6     2        s     d  ]]    )
measure 21
D6     4        e     d
rest   4        e
rest   4        e
rest   8        q
A5     4        e     d         .p
P    C34:Y57
measure 22
A5     4        e     d  [     (
Bf5    4        e     d  =
A5     4        e     d  ]     )
gA5    0        e     u        (
G5     4        e     d  [     ).
F5     4        e     d  =      .
G5     4        e     d  ]      .
measure 23
*               E   0
P    C17:Y58
F5     8        q     d
*               F   15
A5     4        e     d
*               E   15
P    C17:Y58
C6     4        e     d  [     (
B5     4        e n   d  =
*               F   0
Bf5    4        e f   d  ]     )
measure 24
A5     4        e     d  [     (
Bf5    4        e     d  =
A5     4        e     d  ]     )
gA5    0        e     u        (
G5     4        e     d  [     ).
F5     4        e     d  =      .
G5     4        e     d  ]      .
measure 25
F5     8        q     d
A5     4        e     d
*               D       cresc.
P  C25:f33  C17:Y60
C6     4        e     d  [     (
B5     4        e n   d  =
Bf5    4        e f   d  ]     )
measure 26
A5     4        e     d  [     (f
P    C33:Y60
Bf5    4        e     d  =
A5     4        e     d  ]     )
gA5    0        e     u        (
G5     4        e     d  [     ).
F5     4        e     d  =      .
G5     4        e     d  ]      .
measure 27
F5    12-       q.    d        -
F5     4        e     d  [
G5     4        e     d  =      .
A5     4        e     d  ]      .
measure 28
Bf5   12        q.    d        (t
P    C32:u
gA5    5        s     u  [[
gBf5   5        s     u  ]]    )
D6     8        q     d
D6     4        e     d
measure 29
C6     4        e     d  [      .
A5     4        e     d  =      .
C6     4        e     d  ]      .
gC6    0        e     u        (
Bf5    4        e     d  [     ).
A5     4        e     d  =      .
G5     4        e     d  ]      .
measure 30
F5     2        s     d  [[    (
E5     2        s n   d  ==
F5     2        s     d  ==
G5     2        s     d  ==
A5     2        s     d  ==
Bf5    2        s     d  ]]    )
*               E   15
P    C17:Y60
C6     4        e     d  [      .
C6     4        e     d  =      .
*               F   0
C6     4        e     d  ]      .
measure 31
C6    24-       h.    d        -p
P    C33:Y55
measure 32
C6    24-       h.    d        -
measure 33
C6    24-       h.    d        -
measure 34
C6     4        e     d  [
*               DH      cresc.
P  C25:f33  C17:Y65 C18:Y65
F6     4        e     d  =      .
F6     4        e     d  ]      .
F6     4        e     d  [     (
E6     4        e n   d  =
Ef6    4        e f   d  ]     )
measure 35
C#6   12        q.#   d        (
D6     4        e     d  [     )
*               V
E6     2        s n   d  =[    (
F#6    2        s #   d  ==
G6     2        s     d  ==
A6     2        s     d  ]]    )
measure 36
Bf6    4        e     d  [      .
Bf6    4        e     d  =      .
Bf6    4        e     d  ]      .
Bf6    4        e     d  [      .
A6     4        e     d  =      .
G6     4        e     d  ]      .
measure 37
*               GJ      f
P   C17:Y65
F6    12        q.n   d         +
G6    12        q.    d        (t
P    C32:u
gF6    5        s     u  [[
gG6    5        s     u  ]]    )
measure 38
F6     2        s     d  [[    (
A6     2        s     d  ==    )
C7     2        s     d  ==     .
A6     2        s     d  ==     .
C7     2        s     d  ==     .
A6     2        s     d  ]]     .
F6     2        s     d  [[    (
A6     2        s     d  ==    )
C7     2        s     d  ==     .
A6     2        s     d  ==     .
C7     2        s     d  ==     .
A6     2        s     d  ]]     .
measure 39
F6     4        e     d  [
rest   4        e
F6     4        e     d  ]
F6     4        e     d  [
rest   4        e
F6     4        e     d  ]
measure 40
F6     4        e     d  [
rest   4        e
F6     4        e     d  ]      .p
P    C34:Y57
F6     4        e     d  [      .
F6     4        e     d  =      .
F6     4        e     d  ]      .
measure 41
F6     8        q     d
*               W
rest   4        e
rest   8        q
mheavy4                        :|:
rest   4        e
measure 42
rest  24
measure 43
rest  24
measure 44
rest  24
measure 45
rest   8        q
rest   4        e
rest   8        q
G5     2        s     d  [[    (f
P    C33:Y62
F5     2        s     d  ]]    )
measure 46
Ef5    2        s     d  [[    (
D5     2        s     d  =]    )
C5     4        e     d  ]
rest   4        e
rest   4        e
Bf5    2        s     d  [[    (
Af5    2        s f   d  ==    )
G5     2        s     d  ==     .
F5     2        s     d  ]]     .
measure 47
Ef5    2        s     d  [[     .
F5     2        s     d  ==     .
G5     2        s     d  ==     .
F5     2        s     d  ==     .
Ef5    2        s     d  ==     .
D5     2        s     d  ]]     .
C5     2        s     d  [[
D5     2        s     d  ==
Ef5    2        s     d  ==
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ]]
measure 48
A4     2        s n   u  [[     +
Bf4    2        s     u  ==
C5     2        s     u  ==
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]
F#4    4        e #   u
rest   4        e
rest   4        e
measure 49
G4     2        s     d  [[     .
Bf4    2        s     d  ==     .
D5     2        s     d  ==     .
G5     2        s     d  ==     .
D5     2        s     d  ==     .
Bf4    2        s     d  ]]     .
A4     4        e     u
rest   4        e
rest   4        e
measure 50
G4     2        s     d  [[
Bf4    2        s     d  ==
D5     2        s     d  ==
G5     2        s     d  ==
D5     2        s     d  ==
Bf4    2        s     d  ]]
G4     4        e     u
rest   4        e
rest   4        e
measure 51
A4     2        s     d  [[
C5     2        s     d  ==
Ef5    2        s     d  ==
G5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]
B4     4        e n   d
rest   4        e
rest   4        e
measure 52
G4     2        s     d  [[
C5     2        s     d  ==
Ef5    2        s     d  ==
G5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]
Bf4    4        e f   d         +
rest   4        e
rest   4        e
measure 53
Af4    2        s f   d  [[
C5     2        s     d  ==
Ef5    2        s     d  ==
Af5    2        s f   d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]
Bf4    4        e     d
rest   4        e
rest   4        e
measure 54
A4     2        s n   d  [[     +
C5     2        s     d  ==
F5     2        s     d  ==
A5     2        s     d  ==
F5     2        s     d  ==
C5     2        s     d  ]]
Bf4    4        e     d
rest   4        e
rest   4        e
measure 55
Bf4    2        s     d  [[
Df5    2        s f   d  ==
Gf5    2        s f   d  ==
Bf5    2        s     d  ==
Gf5    2        s     d  ==
Df5    2        s     d  ]]
Bf4    4        e     d
rest   4        e
rest   4        e
measure 56
Bf4    2        s     d  [[
D5     2        s n   d  ==     +
F5     2        s     d  ==
Bf5    2        s     d  ==
F5     2        s     d  ==
D5     2        s     d  ]]
Bf4    4        e     d
rest   4        e
rest   4        e
measure 57
G4     2        s n   d  [[     +
Bf4    2        s     d  ==
Ef5    2        s     d  ==
G5     2        s     d  ==
Ef5    2        s     d  ==
Bf4    2        s     d  ]]
Af4    4        e f   u
rest   4        e
rest   4        e
measure 58
Ef4    2        s     u  [[
G4     2        s     u  ==
C5     2        s     u  ==
Ef5    2        s     u  ==
C5     2        s     u  ==
G4     2        s     u  ]]
F4     4        e     u
rest   4        e
rest   4        e
measure 59
D4     2        s     u  [[
F4     2        s     u  ==
Bf4    2        s     u  ==
D5     2        s     u  ==
Bf4    2        s     u  ==
F4     2        s     u  ]]
E4     4        e n   u
rest   4        e
rest   4        e
measure 60
F4     2        s     d  [[
A4     2        s n   d  ==     +
C5     2        s     d  ==
F5     2        s     d  ==
C5     2        s     d  ==
A4     2        s     d  ]]
F4     8        q     u
F4     2        s     u  [[    (mf
G4     2        s     u  ]]    )
measure 61
A4     2        s     d  [[     .
Bf4    2        s     d  ==     .
C5     2        s     d  ==     .
D5     2        s     d  ==     .
Ef5    2        s f   d  ==     .+
F5     2        s     d  ]]     .
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ==
A4     2        s     d  ==
C5     2        s     d  ]]
measure 62
Bf4    2        s     d  [[
C5     2        s     d  ==
D5     2        s     d  ==
Ef5    2        s     d  ==
F5     2        s     d  ==
G5     2        s     d  ]]
A5     2        s     d  [[    ([
Bf5    2        s     d  ==    )
A5     2        s     d  ==    (
Bf5    2        s     d  ==    )]
F4     2        s     d  ==    (
G4     2        s     d  ]]    )
measure 63
A4     2        s     d  [[     .
Bf4    2        s     d  ==     .
C5     2        s     d  ==     .
D5     2        s     d  ==     .
Ef5    2        s     d  ==     .
F5     2        s     d  ]]     .
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ==
A4     2        s     d  ==
C5     2        s     d  ]]
measure 64
Bf4    2        s     d  [[
C5     2        s     d  ==
D5     2        s     d  ==
Ef5    2        s     d  ==
F5     2        s     d  ==
G5     2        s     d  ]]
A5     2        s     d  [[    ([
Bf5    2        s     d  ==    )
A5     2        s     d  ==    (
Bf5    2        s     d  ==    )]
F4     2        s     d  ==    (
G4     2        s     d  ]]    )
measure 65
A4     2        s     d  [[     .
Bf4    2        s     d  ==     .
A4     2        s     d  ==     .
Bf4    2        s     d  ==     .
C5     2        s     d  ==     .
D5     2        s     d  ]]     .
Ef5    2        s     d  [[
F5     2        s     d  ==
G5     2        s     d  ==
A5     2        s     d  ==
*               GE  15  f
P   C17:Y65 C18:Y65
Bf5    2        s     d  ==    (
*               F   0
A5     2        s     d  ]]    )
measure 66
G5     2        s     d  [[    (
F5     2        s     d  ==    )
Ef5    2        s     d  ==     .
D5     2        s     d  ==     .
G5     2        s     d  ==    (
F5     2        s     d  ]]    )
Ef5    2        s     d  [[    (
D5     2        s     d  ==    )
C5     2        s     d  ==     .
Bf4    2        s     d  ==     .
Ef5    2        s     d  ==    (
D5     2        s     d  ]]    )
measure 67
C5     2        s     u  [[     .
Bf4    2        s     u  ==     .
A4     2        s     u  ==     .
G4     2        s     u  ==     .
F4     2        s     u  ==     .
Ef4    2        s     u  ]]     .
D4     2        s     u  [[    (
F4     2        s     u  ==    )
Ef4    2        s     u  ==     .
G4     2        s     u  ==     .
F4     2        s     u  ==     .
A4     2        s     u  ]]     .
measure 68
G4     2        s     d  [[
Bf4    2        s     d  ==
A4     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     d  [[
D5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ==
Bf4    2        s     d  ]]
measure 69
E5     2        s n   d  [[    (
F5     2        s     d  ==    )
E5     2        s     d  ==    (
F5     2        s     d  ==    )
D5     2        s     d  ==     .
Bf4    2        s     d  ]]     .
F5     4        e     d  [      .
rest   4        e
D5     2        s     d  =[    (
Ef5    2        s f   d  ]]    )
measure 70
F5     2        s     d  [[    (
G5     2        s     d  ==    )
A5     2        s     d  ==     .
Bf5    2        s     d  ==     .
Bf4    2        s     d  ==    (
C5     2        s     d  ]]    )
D5     2        s     d  [[    (
Ef5    2        s     d  ==    )
F5     2        s     d  ==     .
G5     2        s     d  ==     .
G4     2        s     d  ==    (
A4     2        s     d  ]]    )
measure 71
Bf4    2        s     d  [[     .
C5     2        s     d  ==     .
D5     2        s     d  ==     .
Ef5    2        s     d  ==     .
F5     2        s     d  ==     .
G5     2        s     d  ]]     .
F5     4        e     d  [
F5     4        e     d  =
F5     4        e     d  ]
measure 72
F5     4        e     d  [
Ef5    4        e     d  =
D5     4        e     d  ]
C5     4        e     d  [
C5     4        e     d  =
C5     4        e     d  ]
measure 73
C5     8        q     d        (
D5     4        e     d        )
C5     8        q     d        (
D5     4        e     d        )
measure 74
C5     2        s     d  [[     fp.
P    C33:Y71
Ef5    2        s     d  ==    (
D5     2        s     d  ==
Ef5    2        s     d  ==
D5     2        s     d  ==
Ef5    2        s     d  ]]    )
rest   2        s
*               E   0
P    C17:Y65
A5     2        s     d  [[    (
Bf5    2        s     d  ==
A5     2        s     d  ==
Bf5    2        s     d  ==
A5     2        s     d  ]]    )
measure 75
rest   2        s
B5     2        s n   d  [[    (
C6     2        s     d  ==
B5     2        s     d  ==
C6     2        s     d  ==
B5     2        s     d  ]]    )
rest   2        s
D6     2        s     d  [[    (
Ef6    2        s     d  ==
D6     2        s     d  ==
Ef6    2        s     d  ==
*               F   15
D6     2        s     d  ]]    )
measure 76
Ef6    4        e     d  [     (f
P    C33:Y62
C6     4        e     d  =
A5     4        e     d  ]     )
G5     4        e     d  [     (
F5     4        e     d  =
E5     4        e n   d  ]     )
measure 77
Ef5   12-       q.f   d        -+
Ef5    8        q     d         F
P    C33:Y-13
gC5    0        e     u        (
Bf4    1        t     u  [[[   )(p
A4     1        t     u  ===
Bf4    1        t     u  ===
C5     1        t     u  ]]]   )
measure 78
Df5    8        q f   d        (.
Df5    4        e     d         .
Df5    8        q     d         .
Df5    4        e     d        ).
measure 79
Df5   12        q.f   d        (
C5     4        e     d        )
rest   4        e
gDf5   0        e     u        (
C5     1        t     d  [[[   )(
Bf4    1        t     d  ===
C5     1        t     d  ===
D5     1        t n   d  ]]]   )
measure 80
Ef5    8        q     d        (.
Ef5    4        e     d         .
Ef5    8        q     d         .
Ef5    4        e     d        ).
measure 81
Ef5   12        q.    d        (
D5     4        e     d        )
rest   4        e
gEf5   0        e     u        (
D5     1        t     d  [[[   )(
C5     1        t     d  ===
D5     1        t     d  ===
E5     1        t n   d  ]]]   )
measure 82
F5     8        q     d        (.
F5     4        e     d         .
F5     8        q     d         .
F5     4        e     d        ).
measure 83
F5     8        q     d        (
E5     4        e n   d        )
rest   8        q
C5     4        e     d        (t
P    C32:u
gB4    5        s     u  [[
gC5    5        s     u  ]]    )
measure 84
Ef5   12        q.f   d        (+
D5     8        q     d        )
Bf4    4        e     d         .f
measure 85
G4     2        s n   d  [[    (+
Ef5    2        s     d  ==
D5     2        s     d  ==
C5     2        s     d  ==
B4     2        s n   d  ==
C5     2        s     d  ]]    )
F#5    2        s #   d  [[    (
G5     2        s     d  ==
F5     2        s n   d  ==
Ef5    2        s     d  ==
D5     2        s     d  ==
C5     2        s     d  ]]    )
measure 86
Bf4   12        q.f   d         +
C5    12        q.    d        (t
P    C32:u
gBf4   5        s     u  [[
gC5    5        s     u  ]]    )
measure 87
Bf4    2        s     d  [[    (
A4     2        s     d  ==
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ==
Ef5    2        s     d  ]]    )
*               E   15
P    C17:Y60
F5     4        e     d  [      .
F5     4        e     d  =      .
*               F   0
F5     4        e     d  ]      .
measure 88
F5    24-       h.    d        -p
P    C33:Y57
measure 89
F5    24-       h.    d        -
measure 90
F5    24-       h.    d        -
measure 91
F5    24-       h.    d        -
measure 92
F5    24-       h.    d        -
measure 93
*               DH      cresc.
P  C25:f33  C17:Y67 C18:Y67
F5     4        e     d  [
Bf5    4        e     d  =      .
Bf5    4        e     d  ]      .
Bf5    4        e     d  [     (
A5     4        e     d  =
Af5    4        e f   d  ]     )
measure 94
F#5   12        q.#   d        (
G5     4        e     d  [     )
A5     2        s n   d  =[    (+
B5     2        s n   d  ==
C6     2        s     d  ==
D6     2        s     d  ]]    )
measure 95
Ef6    4        e     d  [      .
Ef6    4        e     d  =      .
Ef6    4        e     d  ]      .
Ef6    4        e     d  [      .
D6     4        e     d  =      .
C6     4        e     d  ]      .
measure 96
*               GJ      f
P   C17:Y68
Bf5   12        q.f   d         +
C6    12        q.    d        (t
P    C32:u
gBf5   5        s     u  [[
gC6    5        s     u  ]]    )
measure 97
Bf5    8        q     d
Bf5    4        e     d        (
A5     4        e     d  [     )
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
measure 98
F6     4        e     d  [      .
F6     4        e     d  =      .
D6     2        s     d  =[    (
Bf5    2        s     d  ]]    )
A5     4        e     d  [      .
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
measure 99
Bf5    4        e     d  [      .
Bf5    4        e     d  =      .
Bf5    4        e     d  ]     (mf
P    C33:Y62
A5     4        e     d  [     )
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
measure 100
F6     4        e     d  [      .
F6     4        e     d  =      .
D6     2        s     d  =[    (
Bf5    2        s     d  ]]    )
A5     4        e     d  [      .
A5     4        e     d  =      .
C6     2        s     d  =[    (
F5     2        s     d  ]]    )
measure 101
Bf5    4        e     d  [
rest   4        e
P    C1:Y0
Ef6    2        s     d  =[    (p
P    C33:Y58
A5     2        s     d  ]]    )
Bf5    4        e     d  [
rest   4        e
P    C1:Y0
Ef6    2        s     d  =[    (pp
P    C33:Y58
A5     2        s     d  ]]    )
measure 102
Bf5    4        e     d  [
rest   4        e
P    C1:Y0
Ef6    2        s     d  =[    (
A5     2        s     d  ]]    )
Bf5    4        e     d  [      .
Bf5    4        e     d  =      .
Bf5    4        e     d  ]      .
measure 103
Bf5    8        q     d
rest   4        e
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/04/02} [KHM:1032453914]
TIMESTAMP: DEC/26/2001 [md5sum:ed6636959add83657d7ea75e1fc7f959]
11/09/94 W Hewlett
WK#:55,3      MV#:4
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Finale [Fourth Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:6/8  C:4  D:Finale Presto
rest   2        e
measure 1
rest   4        q
rest   2        e
rest   4        q
Ef5    1        s     d  [[    (f
D5     1        s     d  ]]    )
measure 2
C5     1        s     u  [[     .
Bf4    1        s     u  ==     .
A4     1        s     u  ==     .
G4     1        s     u  ==     .
F4     1        s     u  ==     .
Ef4    1        s     u  ]]     .
D4     2        e     u  [      .
Ef4    2        e     u  =      .
F4     2        e     u  ]      .
measure 3
G4     2        e     u  [      .
A4     2        e     u  =      .
Bf4    2        e     u  ]      .
F4     6        q.    u
measure 4
C5     2        e     d  [      .
C5     2        e     d  =      .
D5     2        e     d  ]      .
C5     4        q     d
rest   2        e
measure 5
rest   4        q
rest   2        e
rest   4        q
Ef5    1        s     d  [[    (
D5     1        s     d  ]]    )
measure 6
C5     1        s     u  [[     .
Bf4    1        s     u  ==     .
A4     1        s     u  ==     .
G4     1        s     u  ==     .
F4     1        s     u  ==     .
Ef4    1        s     u  ]]     .
D4     2        e     u  [      .
Ef4    2        e     u  =      .
F4     2        e     u  ]      .
measure 7
G4     2        e     u  [      .
A4     2        e     u  =      .
Bf4    2        e     u  ]      .
C5     6        q.    d
measure 8
Bf4    2        e     d  [
D5     1        s     d  =[
Bf4    1        s     d  ==
C5     1        s     d  ==
A4     1        s     d  ]]
*               E   15
P    C17:Y75
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ==
*               F   0
Bf4    1        s     d  ]]
measure 9
Ef5    1        s     d  [[     p
P    C33:Y70
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
measure 10
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ==
Bf4    1        s     d  ]]
measure 11
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
measure 12
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    2        e     d  [
Bf4    2        e     d  =
D5     1        s     d  =[     f
P    C33:Y73
C#5    1        s #   d  ]]
measure 13
D5     1        s     d  [[
C#5    1        s #   d  ==
D5     1        s     d  ==
C#5    1        s     d  ==
D5     1        s     d  ==
A4     1        s     d  ]]
Bf4    1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
G4     1        s     u  ==
C5     1        s n   u  ==     Z
P    C33:Y64
B4     1        s n   u  ]]
measure 14
C5     1        s     u  [[
B4     1        s n   u  ==
C5     1        s     u  ==
B4     1        s     u  ==
C5     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
F4     1        s     u  =]
A4     2        e     u  ]
measure 15
Bf4    2        e f   u  [      +.
Bf4    2        e     u  =     (
A4     2        e     u  ]     )
E4     2        e n   u  [      .
E4     2        e     u  =     (
F4     2        e     u  ]     )
measure 16
G4     2        e     u  [      .
G4     2        e     u  =     (
A4     2        e     u  ]     )
Bf4    2        e     u  [      .
Bf4    2        e     u  =     (
A4     2        e     u  ]     )
measure 17
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
measure 18
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
measure 19
C5     2        e     d  [     (
F5     2        e     d  =     )
F5     2        e     d  ]      .
F5     2        e     d  [     (
G5     2        e     d  =     )
G5     2        e     d  ]      .
measure 20
G5     6-       q.    d        -Z
P    C33:Y63
G5     2        e     d
rest   2        e
rest   2        e
measure 21
rest  12
measure 22
F5     2        e     d  [     (p
P    C33:Y57
G5     2        e     d  =
F5     2        e     d  ]     )
C5     2        e     d  [      .
C5     2        e     d  =      .
C5     2        e     d  ]      .
measure 23
*               E   0
C5     1        s     d  [[    (
A4     1        s     d  ==
F4     1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ==
*               F   15
F5     1        s     d  ]]    )
*               E   15
P    C17:Y65
A5     2        e     d  [     (
G#5    2        e #   d  =
*               F   0
G5     2        e n   d  ]     )
measure 24
F5     2        e     d  [     (
G5     2        e     d  =
F5     2        e     d  ]     )
C5     2        e     d  [      .
C5     2        e     d  =      .
C5     2        e     d  ]      .
measure 25
C5     1        s     d  [[    (
A4     1        s     d  ==
F4     1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ==
F5     1        s     d  ]]    )
*               D       cresc.
P  C25:f33  C17:Y65
A5     2        e     d  [     (
G#5    2        e #   d  =
G5     2        e n   d  ]     )
measure 26
F5     2        e     d  [     (f
P    C33:Y62
G5     2        e     d  =
F5     2        e     d  ]     )
C5     2        e     d  [      .
C5     2        e     d  =      .
C5     2        e     d  ]      .
measure 27
C5     4        q     d
C5     1        s     d  [[    (
Bf4    1        s     d  ]]    )
A4     2        e     d  [      .
Bf4    2        e     d  =      .
C5     2        e     d  ]      .
measure 28
Bf4    6        q.    d
Bf5    4        q     d
Bf5    2        e     d
measure 29
A5     2        e     d  [      .
F5     2        e     d  =      .
A5     2        e     d  ]      .
gA5    0        e     u        (
G5     2        e     d  [     ).
F5     2        e     d  =      .
E5     2        e n   d  ]      .
measure 30
F5     4        q     d
rest   2        e
rest   4        q
A4     2        e     u         .p
P    C34:Y58
measure 31
A4     2        e     u  [     (
Bf4    2        e     u  =
A4     2        e     u  ]     )
gA4    0        e     u        (
G4     2        e     u  [     ).
F4     2        e     u  =      .
G4     2        e     u  ]      .
measure 32
*               E   0
P    C17:Y65
F4     4        q     u
*               F   15
A4     2        e     u
*               E   15
P    C17:Y69
C5     2        e     d  [     (
B4     2        e n   d  =
*               F   0
Bf4    2        e f   d  ]     )
measure 33
A4     2        e     u  [     (
Bf4    2        e     u  =
A4     2        e     u  ]     )
gA4    0        e     u        (
G4     2        e     u  [     ).
F4     2        e     u  =      .
G4     2        e     u  ]      .
measure 34
F4     2        e     d  [      .
*               DH      cresc.
P  C25:f33  C17:Y70 C18:Y70
F5     2        e     d  =      .
F5     2        e     d  ]      .
F5     2        e     d  [     (
E5     2        e n   d  =
Ef5    2        e f   d  ]     )
measure 35
C#5    6        q.#   d        (
D5     2        e     d  [     )
E5     1        s n   d  =[    (
F#5    1        s #   d  ==
G5     1        s     d  ==
A5     1        s     d  ]]    )
measure 36
Bf5    2        e     d  [      .
D6     2        e     d  =      .
D6     2        e     d  ]      .
D6     2        e     d  [      .
C6     2        e n   d  =      +.
Bf5    2        e     d  ]      .
measure 37
*               GJ      f
P   C17:Y70
A5     2        e     d  [     (
C6     2        e     d  =     )
F5     2        e     d  ]      .
E5     6        q.n   d        (t
P    C32:u
gD5    5        s     u  [[
gE5    5        s     u  ]]    )
measure 38
F5     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
measure 39
A4     1        s     u  [[    (
G#4    1        s #   u  ==    )
A4     1        s     u  ==    (
G#4    1        s     u  ==    )
A4     1        s     u  ==    (
Bf4    1        s f   u  ]]    )+
C5     1        s     d  [[    (
B4     1        s n   d  ==    )
C5     1        s     d  ==    (
B4     1        s     d  ==    )
C5     1        s     d  ==    (
D5     1        s     d  ]]    )
measure 40
Ef5    2        e f   d  [      +
rest   2        e
Ef5    2        e     d  ]      .p
P    C34:Y58
Ef5    2        e     d  [      .
Ef5    2        e     d  =      .
Ef5    2        e     d  ]      .
measure 41
Ef5    4        q     d
rest   2        e
rest   4        q
mheavy4                        :|:
rest   2        e
measure 42
rest  12
measure 43
rest   4        q
rest   2        e
rest   4        q
G4     1        s     u  [[    (f
P    C33:Y65
A4     1        s     u  ]]    )
measure 44
B4     1        s n   d  [[    (
C5     1        s     d  ==    )
B4     1        s     d  ==     .
C5     1        s     d  ==     .
D5     1        s     d  ==     .
Ef5    1        s     d  ]]     .
D5     1        s     d  [[    (
Ef5    1        s     d  ==    )
F5     1        s     d  ==     .
G5     1        s     d  ==     .
Af5    1        s f   d  ==     .
G5     1        s     d  ]]     .
measure 45
F5     1        s     d  [[     .
Ef5    1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ==     .
B4     1        s n   d  ==     .
Af4    1        s f   d  ]]     .
G4     1        s     u  [[
Af4    1        s     u  ==
G4     1        s     u  ==
F4     1        s     u  ==
Ef4    1        s     u  ==
D4     1        s     u  ]]
measure 46
C4     2        e     d  [
C6     1        s     d  =[    (
Bf5    1        s f   d  ==    )+
Af5    1        s f   d  ==    (
G5     1        s     d  ]]    )
F5     2        e     d
rest   2        e
rest   2        e
measure 47
rest   4        q
Ef4    1        s     u  [[    (
F4     1        s     u  ]]    )
G4     2        e     u  [
rest   2        e
C4     1        s     u  =[    (
D4     1        s     u  ]]    )
measure 48
Ef4    2        e     u  [
rest   2        e
P    C1:Y30
A3     1        s n   u  =[    (+
Bf3    1        s     u  ]]    )
C4     2        e     u
rest   2        e
rest   2        e
measure 49
G3     2        e     u
rest   2        e
rest   2        e
A4     1        s     d  [[     .
C5     1        s     d  ==     .
F#5    1        s #   d  ==     .
A5     1        s     d  ==     .
F#5    1        s     d  ==     .
C5     1        s     d  ]]     .
measure 50
Bf4    2        e     d
rest   2        e
rest   2        e
G4     1        s     d  [[
Bf4    1        s     d  ==
Ef5    1        s     d  ==
G5     1        s     d  ==
Ef5    1        s     d  ==
Bf4    1        s     d  ]]
measure 51
A4     2        e     u
rest   2        e
rest   2        e
B4     1        s n   d  [[
D5     1        s     d  ==
F5     1        s n   d  ==     +
Af5    1        s f   d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
measure 52
C5     2        e     d
rest   2        e
rest   2        e
G4     1        s     d  [[
Bf4    1        s f   d  ==     +
Df5    1        s f   d  ==
G5     1        s     d  ==
Df5    1        s     d  ==
Bf4    1        s     d  ]]
measure 53
Af4    2        e f   u
rest   2        e
rest   2        e
G4     1        s     d  [[
Bf4    1        s     d  ==
E5     1        s n   d  ==
G5     1        s     d  ==
E5     1        s     d  ==
Bf4    1        s     d  ]]
measure 54
A4     2        e n   u         +
rest   2        e
rest   2        e
Bf4    1        s     d  [[
Df5    1        s f   d  ==
F5     1        s     d  ==
Bf5    1        s     d  ==
F5     1        s     d  ==
Df5    1        s     d  ]]
measure 55
Bf4    2        e     d
rest   2        e
rest   2        e
Bf4    1        s     d  [[
Ef5    1        s f   d  ==     +
Gf5    1        s f   d  ==
Bf5    1        s     d  ==
Gf5    1        s     d  ==
Ef5    1        s     d  ]]
measure 56
Bf4    2        e     d
rest   2        e
rest   2        e
Bf4    1        s     d  [[
D5     1        s n   d  ==     +
F5     1        s     d  ==
Af5    1        s f   d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
measure 57
Bf4    2        e     d
rest   2        e
rest   2        e
F4     1        s     d  [[
B4     1        s n   d  ==
D5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ]]
measure 58
C5     2        e     d
rest   2        e
rest   2        e
F4     1        s     d  [[
A4     1        s n   d  ==     +
C5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ==
A4     1        s     d  ]]
measure 59
F4     2        e     u
rest   2        e
rest   2        e
G4     1        s     d  [[
Bf4    1        s     d  ==
C5     1        s     d  ==
E5     1        s n   d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
measure 60
A4     2        e     u
rest   2        e
rest   2        e
rest   4        q
rest   2        e
measure 61
Ef4   12        h.f   u         +
 C4   12        h.    u        (
measure 62
D4    12        h.    u        )
measure 63
Ef4   12        h.    u
 C4   12        h.    u        (
measure 64
D4    12        h.    u        )
measure 65
Ef4    4        q     u
 C4    4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 66
rest   4        q
*               GE  15  f
P   C17:Y63 C18:Y63
Bf4    1        s     u  [[    (
*               F   0
A4     1        s     u  ]]    )
G4     1        s     u  [[    (
F4     1        s     u  ==    )
Ef4    1        s     u  ==     .
D4     1        s     u  ==     .
G4     1        s     u  ==    (
F4     1        s     u  ]]    )
measure 67
Ef4    1        s     u  [[     .
D4     1        s     u  ==     .
C4     1        s     u  ==     .
Bf3    1        s     u  ==     .
A3     1        s     u  ==     .
C4     1        s     u  ]]     .
D4     2        e     u  [      .
Ef4    2        e     u  =      .
F4     2        e     u  ]      .
measure 68
G4     2        e     u  [      .
A4     2        e     u  =      .
Bf4    2        e     u  ]      .
F4     6        q.    u
measure 69
C5     2        e     d  [      .
C5     2        e     d  =      .
D5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
D5     1        s     d  =[    (
C5     1        s     d  ]]    )
measure 70
Bf4    1        s     u  [[    (
A4     1        s     u  ==    )
G4     1        s     u  ==     .
F4     1        s     u  ==     .
Bf4    1        s     u  ==    (
A4     1        s     u  ]]    )
G4     1        s     u  [[    (
F4     1        s     u  ==    )
Ef4    1        s     u  ==     .
D4     1        s     u  ==     .
G4     1        s     u  ==    (
F4     1        s     u  ]]    )
measure 71
Ef4    1        s     u  [[     .
D4     1        s     u  ==     .
C4     1        s     u  ==     .
Bf3    1        s     u  =]     .
A3     2        e     u  ]      .
Bf3    2        e     u
rest   2        e
rest   2        e
measure 72
rest   4        q
rest   2        e
Bf4    2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  ]
measure 73
A4     4        q     u        (
Bf4    2        e     d        )
A4     4        q     u        (
Bf4    2        e     d        )
measure 74
A4     4        q     u         fp
rest   2        e
*               E   0
P    C17:Y67
Ef5    4        q f   d         +
rest   2        e
measure 75
Ef5    4        q     d
rest   2        e
*               F   15
C5     4        q     d
rest   2        e
measure 76
A4    12-       h.    u        -Z
measure 77
A4     6-       q.    u        -
A4     4        q     u         F
rest   2        e
measure 78
Bf4   12        h.    d         p
measure 79
Af4    6        q.f   u        (
Gf4    2        e f   u        )
rest   2        e
rest   2        e
measure 80
C5    12        h.    d
measure 81
Bf4    6        q.    d        (
Af4    2        e f   u        )
rest   2        e
rest   2        e
measure 82
D5     6        q.    d        (
C5     6        q.    d        )
measure 83
B4     6        q.n   d        (
Bf4    2        e f   d        )
rest   2        e
rest   2        e
measure 84
C5     6        q.    d        (
Bf4    4        q     d        )
F4     2        e     u         .f
P    C34:Y70
measure 85
G4     4        q n   u         +
rest   2        e
rest   4        q
rest   2        e
measure 86
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  ]
Ef4    2        e     u  [
Ef4    2        e     u  =
Ef4    2        e     u  ]
measure 87
D4     4        q     u
rest   2        e
rest   4        q
D5     2        e     d         .p
P    C34:Y60
measure 88
D5     2        e     d  [     (
Ef5    2        e     d  =
D5     2        e     d  ]     )
gD5    0        e     u        (
C5     2        e     d  [     ).
Bf4    2        e     d  =      .
C5     2        e     d  ]      .
measure 89
*               E   0
P    C17:Y70
Bf4    4        q     d
*               F   15
D5     2        e     d
*               E   15
P    C17:Y65
F5     2        e     d  [     (
E5     2        e n   d  =
*               F   0
Ef5    2        e f   d  ]     )
measure 90
D5     2        e     d  [     (
Ef5    2        e     d  =
D5     2        e     d  ]     )
gD5    0        e     u        (
C5     2        e     d  [     ).
Bf4    2        e     d  =      .
C5     2        e     d  ]      .
measure 91
*               E   0
P    C17:Y68
Bf4    4        q     d
*               F   15
D5     2        e     d
*               E   15
P    C17:Y65
F5     2        e     d  [     (
E5     2        e n   d  =
*               F   0
Ef5    2        e f   d  ]     )
measure 92
D5     2        e     d  [     (
Ef5    2        e     d  =
D5     2        e     d  ]     )
gD5    0        e     u        (
C5     2        e     d  [     ).
Bf4    2        e     d  =      .
C5     2        e     d  ]      .
measure 93
*               DH      cresc.
P  C25:f33  C17:Y70 C18:Y70
Bf4    2        e     d  [      .
Bf4    2        e     d  =      .
Bf4    2        e     d  ]      .
Bf4    2        e     u  [     (
A4     2        e     u  =
Af4    2        e f   u  ]     )
measure 94
F#4    6        q.#   u        (
G4     2        e     u  [     )
A4     1        s n   u  =[    (+
B4     1        s n   u  ==
C5     1        s     u  ==
D5     1        s     u  ]]    )
measure 95
Ef5    2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
G5     2        e     d  [      .
F5     2        e n   d  =      .+
Ef5    2        e     d  ]      .
measure 96
*               GJ      f
P   C17:Y75
D5     2        e     d  [     ([
F5     2        e     d  =     )
Bf4    2        e     d  ]     ].
A4     6        q.    u        (t
gG4    5        s     u  [[
gA4    5        s     u  ]]    )
measure 97
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ==
Bf4    1        s     d  ]]
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
measure 98
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
measure 99
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ==
Bf4    1        s     d  ]]
Ef5    1        s     d  [[     mf
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
measure 100
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
measure 101
Bf4    2        e     d  [
rest   2        e
C5     2        e     d  ]     (p
P    C33:Y65
D5     2        e     d  [     )
rest   2        e
C5     2        e     d  ]     (pp
P    C33:Y64
measure 102
D5     2        e     d  [     )
rest   2        e
C5     2        e     d  ]      f
P    C33:Y66
D5     2        e     d  [      .
D5     2        e     d  =      .
D5     2        e     d  ]      .
measure 103
D5     4        q     d
rest   2        e
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/04/03} [KHM:1032453914]
TIMESTAMP: DEC/26/2001 [md5sum:933fa9e8c4813d161c33a6cc21e2feeb]
11/09/94 W Hewlett
WK#:55,3      MV#:4
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Finale [Fourth Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:6/8  C:13  D:Finale Presto
rest   2        e
measure 1
rest   4        q
rest   2        e
rest   4        q
Ef4    1        s     d  [[    (f
P    C33:Y73
D4     1        s     d  ]]    )
measure 2
C4     1        s     u  [[     .
Bf3    1        s     u  ==     .
A3     1        s     u  ==     .
G3     1        s     u  ==     .
F3     1        s     u  ==     .
Ef3    1        s     u  ]]     .
D3     2        e     u  [      .
Ef3    2        e     u  =      .
F3     2        e     u  ]      .
measure 3
G3     2        e     u  [      .
A3     2        e     u  =      .
Bf3    2        e     u  ]      .
C4     4        q     d        (
Bf3    2        e     u        )
measure 4
A3     2        e     u  [      .
A3     2        e     u  =      .
Bf3    2        e     u  ]      .
A3     4        q     u
rest   2        e
measure 5
rest   4        q
rest   2        e
rest   4        q
Ef4    1        s     d  [[    (
D4     1        s     d  ]]    )
measure 6
C4     1        s     u  [[     .
Bf3    1        s     u  ==     .
A3     1        s     u  ==     .
G3     1        s     u  ==     .
F3     1        s     u  ==     .
Ef3    1        s     u  ]]     .
D3     2        e     u  [      .
Ef3    2        e     u  =      .
F3     2        e     u  ]      .
measure 7
G3     2        e     u  [      .
A3     2        e     u  =      .
Bf3    2        e     u  ]      .
G3     4        q     u
G4     2        e     d
measure 8
D4     4        q     d
C4     1        s     d  [[
Ef4    1        s     d  ]]
*               E   15
P    C17:Y70
D4     1        s     d  [[
Ef4    1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
*               F   0
D4     1        s     d  ]]
measure 9
C4     1        s     d  [[     p
P    C33:Y69
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
F4     1        s     d  ]]
measure 10
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
D4     1        s     d  [[
Ef4    1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ]]
measure 11
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
F4     1        s     d  ]]
measure 12
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  =
A4     2        e     d  ]      f
P    C33:Y61
measure 13
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
Bf4    2        e     d  [
rest   2        e
P    C1:Y10
G4     2        e     d  ]      Z
P    C33:Y60
measure 14
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
A4     4        q     d
rest   2        e
measure 15
C5    12-       h.    d        -
measure 16
C5    12        h.    d
measure 17
C4     1        s     d  [[
E4     1        s n   d  ==
D4     1        s     d  ==
F4     1        s     d  ==
E4     1        s     d  ==
G4     1        s     d  ]]
F4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
measure 18
E4     1        s n   d  [[
C4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ==
G4     1        s     d  ==
E4     1        s     d  ]]
A4     1        s     d  [[
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
B3     1        s n   d  ]]
measure 19
C4     2        e     d  [     (
D4     2        e     d  =     )
D4     2        e     d  ]      .
D4     2        e     d  [     (
C4     2        e     d  =     )
C4     2        e     d  ]      .
measure 20
C4     6-       q.    d        -Z
C4     2        e     d
rest   2        e
rest   2        e
measure 21
rest  12
measure 22
F3     1        s     u  [[    (p
P    C33:Y63
G3     1        s     u  ==
A3     1        s     u  ==
Bf3    1        s f   u  ==     +
C4     1        s     u  ==
D4     1        s     u  ]]
E4     1        s n   d  [[
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]    )
measure 23
A4     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 24
rest  12
measure 25
rest  12
measure 26
F3     1        s     u  [[    (f
G3     1        s     u  ==
A3     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ==
D4     1        s     u  ]]
E4     1        s n   d  [[
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]    )
measure 27
A4     1        s     d  [[    (
Bf4    1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s f   d  ==     +
D5     1        s     d  ]]    )
C5     2        e     d  [      .
Bf4    2        e     d  =      .
A4     2        e     d  ]      .
measure 28
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
measure 29
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 30
A3     4        q     u
rest   2        e
rest   4        q
F4     2        e     d         .p
P    C34:Y59
measure 31
F4     2        e     d  [     (
G4     2        e     d  =
F4     2        e     d  ]     )
C4     4        q     d
C4     2        e     d
measure 32
*               E   0
P    C17:Y62
A3     4        q     u
*               F   15
F4     2        e     d
*               E   15
P    C17:Y62
A4     2        e     d  [     (
G#4    2        e #   d  =
*               F   0
G4     2        e n   d  ]     )
measure 33
F4     2        e     d  [     (
G4     2        e     d  =
F4     2        e     d  ]     )
C4     2        e     d  [      .
C4     2        e     d  =      .
C4     2        e     d  ]      .
measure 34
*      2        DH      cresc.
P  C25:f33  C17:Y70 C18:Y70
C4     6-       q.    d        -
C4     4        q     d
F4     2        e     d
measure 35
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
measure 36
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
G4     2        e     d  [
A4     2        e     d  =
Bf4    2        e     d  ]
measure 37
*               GJ      f
P   C17:Y70
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
Bf4    2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  ]
measure 38
A4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
measure 39
F4     1        s     d  [[    (
E4     1        s n   d  ==    )
F4     1        s     d  ==    (
E4     1        s     d  ==    )
F4     1        s     d  ==    (
G4     1        s     d  ]]    )
A4     1        s     d  [[    (
G#4    1        s #   d  ==    )
A4     1        s     d  ==    (
G#4    1        s     d  ==    )
A4     1        s     d  ==    (
Bf4    1        s     d  ]]    )
measure 40
C5     2        e     d  [
rest   2        e
P    C1:Y0
C5     2        e     d  ]      .p
P    C34:Y55
C5     2        e     d  [      .
C5     2        e     d  =      .
C5     2        e     d  ]      .
measure 41
C5     4        q     d
rest   2        e
rest   4        q
mheavy4                        :|:
rest   2        e
measure 42
rest   2        e
D4     1        s     d  [[     f.
P    C33:Y64
E4     1        s n   d  ==     .
F#4    1        s #   d  ==     .
G4     1        s     d  ]]     .
F#4    1        s     d  [[    (
G4     1        s     d  ==    )
A4     1        s     d  ==     .
Bf4    1        s     d  ==     .
C5     1        s     d  ==     .
D5     1        s     d  ]]     .
measure 43
Ef5    1        s f   d  [[     +.
D5     1        s     d  ==     .
C5     1        s     d  ==     .
Bf4    1        s     d  ==     .
A4     1        s     d  ==     .
G4     1        s     d  ]]     .
F#4    1        s #   d  [[
G4     1        s     d  ==
F#4    1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
measure 44
B3     2        e n   d  [
F4     1        s n   d  =[     +.
Ef4    1        s     d  ==     .
D4     1        s     d  ==     .
C4     1        s     d  ]]     .
B3     1        s     d  [[    (
C4     1        s     d  ==    )
D4     1        s     d  ==     .
Ef4    1        s     d  ==     .
F4     1        s     d  ==     .
G4     1        s     d  ]]     .
measure 45
Af4    1        s f   d  [[     .
G4     1        s     d  ==     .
F4     1        s     d  ==     .
Ef4    1        s     d  ==     .
D4     1        s     d  ==     .
C4     1        s     d  ]]     .
B3     1        s n   u  [[
C4     1        s     u  ==
B3     1        s     u  ==
G3     1        s     u  ==
A3     1        s n   u  ==     +
B3     1        s     u  ]]
measure 46
C4     2        e     d  [
rest   2        e
F4     1        s     d  =[    (
Ef4    1        s     d  ]]    )
D4     1        s     d  [[    (
C4     1        s     d  =]    )
Bf3    2        e f   d  ]      +
rest   2        e
measure 47
G4     1        s     d  [[     .
F4     1        s     d  ==     .
Ef4    1        s     d  ==     .
D4     1        s     d  ==     .
C4     1        s     d  ==     .
D4     1        s     d  ]]     .
Ef4    1        s     d  [[
D4     1        s     d  ==
C4     1        s     d  ==
Bf3    1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ]]
measure 48
C4    12        h.    d        (
measure 49
Bf3    2        e     d  [     )
G4     2        e     d  =
Bf4    2        e     d  ]
D4     2        e     d  [
A4     2        e     d  =
C5     2        e     d  ]
measure 50
D4     2        e     d  [
G4     2        e     d  =
Bf4    2        e     d  ]
Ef4    2        e     d  [
 G3    2        e     d
G4     2        e     d  =
Bf4    2        e     d  ]
measure 51
Ef4    2        e     d  [
A4     2        e n   d  =      +
C5     2        e     d  ]
F4     2        e     d  [
B4     2        e n   d  =
D5     2        e     d  ]
measure 52
C4     2        e     d  [
G4     2        e     d  =
C5     2        e     d  ]
Df4    2        e f   d  [
G4     2        e     d  =
Bf4    2        e f   d  ]      +
measure 53
C4     2        e     d  [
Af4    2        e f   d  =
C5     2        e     d  ]
C4     2        e     d  [
G4     2        e     d  =
Bf4    2        e     d  ]
measure 54
F4     2        e     d  [
A4     2        e n   d  =      +
C5     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  =
Df5    2        e f   d  ]
measure 55
Gf4    2        e f   d  [
Bf4    2        e     d  =
Df5    2        e f   d  ]
Gf4    2        e     d  [
Bf4    2        e     d  =
Ef5    2        e     d  ]
measure 56
D4     2        e n   d  [      +
Bf4    2        e     d  =
D5     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  =
Af4    2        e f   d  ]
measure 57
Bf3    2        e     d  [
G4     2        e n   d  =      +
Bf4    2        e     d  ]
F4     2        e     d  [
B4     2        e n   d  =
D5     2        e     d  ]
measure 58
G3     2        e     d  [
Ef4    2        e     d  =
G4     2        e     d  ]
C4     2        e     d  [
A4     2        e n   d  =      +
C5     2        e     d  ]
measure 59
Bf3    2        e f   d  [      +
D4     2        e     d  =
F4     2        e     d  ]
Bf3    2        e     d  [
Bf4    2        e     d  =
E4     2        e n   d  ]
measure 60
A3     2        e     d  [
F4     2        e     d  =
A4     2        e     d  ]
A3     1        s     d  [[
C4     1        s     d  ==
F4     1        s     d  ==
A4     1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ]]
measure 61
A3     2        e     u  [      mf
A3     2        e     u  =
A3     2        e     u  ]
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  ]
measure 62
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 63
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  ]
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  ]
measure 64
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 65
A3     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 66
rest   4        q
rest   2        e
rest   4        q
*               GE  15  f
P   C17:Y63 C18:Y63
Bf4    1        s     d  [[    (
*               F   0
A4     1        s     d  ]]    )
measure 67
G4     1        s     d  [[     .
F4     1        s     d  ==     .
Ef4    1        s     d  ==     .
D4     1        s     d  ==     .
C4     1        s     d  ==     .
A3     1        s     d  ]]     .
Bf3    2        e     d  [      .
C4     2        e     d  =      .
D4     2        e     d  ]      .
measure 68
Ef4    2        e     d  [      .
F4     2        e     d  =      .
G4     2        e     d  ]      .
C4     4        q     d        (
Bf3    2        e     u        )
measure 69
A3     2        e     u  [      .
A3     2        e     u  =      .
Bf3    2        e     u  ]      .
A3     2        e     u  [      .
rest   2        e
Bf3    1        s     u  =[    (
C4     1        s     u  ]]    )
measure 70
D4     2        e     u  [
rest   2        e
G3     1        s     u  =[    (
A3     1        s     u  ]]    )
Bf3    2        e     u  [
rest   2        e
Ef3    1        s     u  =[    (
F3     1        s     u  ]]    )
measure 71
G3     2        e     u
rest   2        e
rest   2        e
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
measure 72
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
measure 73
E4     1        s n   d  [[    (
F4     1        s     d  ==    )
E4     1        s     d  ==    (
F4     1        s     d  ==    )
D4     1        s     d  ==     .
Bf3    1        s     d  ]]     .
E4     1        s     d  [[    (
F4     1        s     d  ==    )
E4     1        s     d  ==    (
F4     1        s     d  ==    )
D4     1        s     d  ==     .
Bf3    1        s     d  ]]     .
measure 74
F4     4        q     d         fp
P    C33:Y62
rest   2        e
*               E   0
P    C17:Y64
C5     4        q     d
rest   2        e
measure 75
A4     4        q     d
rest   2        e
*               F   15
A4     4        q     d
rest   2        e
measure 76
C4    12-       h.    d        -Z
measure 77
C4     6-       q.    d        -
C4     4        q     d         F
rest   2        e
measure 78
Ef4    6        q.    d        (p
P    C33:Y60
Ff4    6        q.f   d        )
measure 79
F4     6        q.n   d        (+
Ef4    2        e     d        )
rest   2        e
rest   2        e
measure 80
Gf4   12        h.f   d
measure 81
G4     6        q.n   d        (+
F4     2        e     d        )
rest   2        e
rest   2        e
measure 82
Af4   12        h.f   d
measure 83
G4     6-       q.    d        -
G4     2        e     d
rest   2        e
rest   2        e
measure 84
Gf4    6        q.f   d        (
F4     4        q     d        )
F4     2        e     d         .f
P    C34:Y60
measure 85
Ef4    4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 86
Bf4    2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  ]
A4     2        e n   d  [      +
A4     2        e     d  =
A4     2        e     d  ]
measure 87
Bf4    4        q     d
rest   2        e
rest   4        q
Bf4    2        e     d         .p
P    C34:Y55
measure 88
Bf4    2        e     d  [     (
C5     2        e     d  =
Bf4    2        e     d  ]     )
F4     4        q     d
F4     2        e     d
measure 89
*               E   0
P    C17:Y65
D4     4        q     d
*               F   15
Bf4    2        e     d
*               E   15
P    C17:Y65
D5     2        e     d  [     (
C#5    2        e #   d  =
*               F   0
C5     2        e n   d  ]     )
measure 90
Bf4    2        e     d  [     (
C5     2        e     d  =
Bf4    2        e     d  ]     )
F4     4        q     d
F4     2        e     d
measure 91
*               E   0
P    C17:Y62
D4     4        q     d
*               F   15
Bf4    2        e     d
*               E   15
P    C17:Y62
D5     2        e     d  [     (
C#5    2        e #   d  =
*               F   0
C5     2        e n   d  ]     )
measure 92
Bf4    2        e     d  [     (
C5     2        e     d  =
Bf4    2        e     d  ]     )
F4     4        q     d
F4     2        e     d
measure 93
*               DH      cresc.
P  C25:f33  C17:Y70 C18:Y70
F4     6-       q.    d        -
F4     4        q     d
Bf3    2        e     u
measure 94
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
measure 95
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
C4     2        e     d  [
D4     2        e     d  =
Ef4    2        e     d  ]
measure 96
*               GJ      f
P   C17:Y70
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  ]
measure 97
D4     1        s     d  [[
Ef4    1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ]]
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
measure 98
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
F4     1        s     d  ]]
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
measure 99
D4     1        s     d  [[
Ef4    1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ]]
C4     1        s     d  [[     mf
P    C33:Y73
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
measure 100
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
F4     1        s     d  ]]
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]
measure 101
D4     2        e     d  [
rest   2        e
A4     1        s     d  =[    (p
P    C33:Y60
C5     1        s     d  ]]    )
Bf4    2        e     d  [
rest   2        e
P    C1:Y10
A4     1        s     d  =[    (pp
P    C33:Y60
C5     1        s     d  ]]    )
measure 102
Bf4    2        e     d  [
rest   2        e
P    C1:Y10
A4     1        s     d  =[    (f
P    C33:Y62
C5     1        s     d  ]]    )
Bf4    2        e     d  [      .
F4     2        e     d  =      .
D4     2        e     d  ]      .
measure 103
Bf3    4        q     u
rest   2        e
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/04/04} [KHM:1032453914]
TIMESTAMP: DEC/26/2001 [md5sum:6dc972adb85c56143f2f060de53dc5d8]
11/09/94 W Hewlett
WK#:55,3      MV#:4
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Finale [Fourth Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:4   T:6/8  C:22  D:Finale Presto
rest   2        e
measure 1
rest   4        q
rest   2        e
rest   4        q
Ef4    1        s     d  [[    (f
P    C33:Y63
D4     1        s     d  ]]    )
measure 2
C4     1        s     d  [[     .
Bf3    1        s     d  ==     .
A3     1        s     d  ==     .
G3     1        s     d  ==     .
F3     1        s     d  ==     .
Ef3    1        s     d  ]]     .
D3     2        e     d  [      .
Ef3    2        e     d  =      .
F3     2        e     d  ]      .
measure 3
G3     2        e     d  [      .
A3     2        e     d  =      .
Bf3    2        e     d  ]      .
A3     4        q     d        (
Bf3    2        e     d        )
measure 4
F3     2        e     d  [      .
F3     2        e     d  =      .
F3     2        e     d  ]      .
F3     4        q     d
rest   2        e
measure 5
rest   4        q
rest   2        e
rest   4        q
Ef4    1        s     d  [[    (
D4     1        s     d  ]]    )
measure 6
C4     1        s     d  [[     .
Bf3    1        s     d  ==     .
A3     1        s     d  ==     .
G3     1        s     d  ==     .
F3     1        s     d  ==     .
Ef3    1        s     d  ]]     .
D3     2        e     d  [      .
Ef3    2        e     d  =      .
F3     2        e     d  ]      .
measure 7
G3     2        e     d  [      .
A3     2        e     d  =      .
Bf3    2        e     d  ]      .
Ef3    6        q.    d        (
measure 8
F3     2        e     d  [     )
F3     2        e     d  =      .
F3     2        e     d  ]      .
Bf2    4        q     u
rest   2        e
measure 9
F3     4        q     d         p
P    C33:Y60
rest   2        e
Bf2    4        q     u
rest   2        e
measure 10
F3     4        q     d
rest   2        e
Bf2    4        q     u
rest   2        e
measure 11
rest   2        e
F3     2        e     d  [
F3     2        e     d  ]
rest   2        e
Bf2    2        e     u  [
Bf2    2        e     u  ]
measure 12
rest   2        e
F3     2        e     d  [
F3     2        e     d  ]
Bf2    4        q     u
F#4    2        e #   d         f
P    C33:Y60
measure 13
F#4    2        e #   d  [
F#4    2        e     d  =
F#4    2        e     d  ]
G4     2        e     d  [
rest   2        e
P    C1:Y0
E4     2        e n   d  ]
measure 14
E4     2        e n   d  [
E4     2        e     d  =
E4     2        e     d  ]
F4     4        q     d
rest   2        e
measure 15
rest  12
measure 16
Bf3    2        e     d  [      .
Bf3    2        e     d  =     (
A3     2        e     d  ]     )
E3     2        e n   d  [      .
E3     2        e     d  =     (
F3     2        e     d  ]     )
measure 17
C3     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 18
C3     1        s     d  [[
E3     1        s n   d  ==
D3     1        s     d  ==
F3     1        s     d  ==
E3     1        s     d  ==
G3     1        s     d  ]]
F3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F3     1        s     d  ==
E3     1        s     d  ==
D3     1        s     d  ]]
measure 19
C3     2        e     u  [     (
D3     2        e     u  =     )
D3     2        e     u  ]      .
D3     2        e     d  [     (
E3     2        e n   d  =     )
E3     2        e     d  ]      .
measure 20
E3     6-       q.n   d        -Z
P    C33:Y65
E3     2        e     d
rest   2        e
rest   2        e
measure 21
rest  12
measure 22
rest  12
measure 23
rest  12
measure 24
F2     1        s     u  [[    (p
P    C33:Y68
G2     1        s     u  ==
A2     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ==
D3     1        s     u  ]]
E3     1        s n   d  [[
F3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]    )
measure 25
A3     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 26
rest  12
measure 27
F2     1        s     u  [[    (f
P    C33:Y77
G2     1        s     u  ==
A2     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ==
D3     1        s     u  ]]    )
Ef3    2        e f   d  [      +
Ef3    2        e     d  =
Ef3    2        e     d  ]
measure 28
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  ]
measure 29
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
measure 30
F3     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 31
rest  12
measure 32
rest  12
measure 33
F2     1        s     u  [[    (p
P    C33:Y68
G2     1        s     u  ==
A2     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ==
D3     1        s     u  ]]
E3     1        s n   d  [[
F3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]    )
measure 34
A3     2        e     d  [
*               DH      cresc.
P  C25:f33  C17:Y65 C18:Y65
A3     2        e     d  =
A3     2        e     d  ]
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  ]
measure 35
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  ]
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  ]
measure 36
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  ]
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  ]
measure 37
*               GJ      f
P   C17:Y65
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
measure 38
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 39
F3     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 40
*               E   15
P    C17:Y65
F4     1        s     d  [[    (
E4     1        s n   d  ==    )
F4     1        s     d  ==    (
E4     1        s     d  ==    )
F4     1        s     d  ==    (
*               F   0
G4     1        s     d  ]]    )
A4     2        e     d  [      .p
P    C34:Y57
A4     2        e     d  =      .
A4     2        e     d  ]      .
measure 41
A4     4        q     d
rest   2        e
rest   4        q
mheavy4                        :|:
D3     1        s     d  [[    (f
E3     1        s n   d  ]]    )
measure 42
F#3    1        s #   d  [[    (
G3     1        s     d  ==    )
F#3    1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ]]
A3     1        s     d  [[    (
Bf3    1        s     d  ==    )
C4     1        s     d  ==     .
D4     1        s     d  ==     .
Ef4    1        s f   d  ==     +.
D4     1        s     d  ]]     .
measure 43
C4     1        s     d  [[     .
Bf3    1        s     d  ==     .
A3     1        s     d  ==     .
G3     1        s     d  ==     .
F#3    1        s #   d  ==     .
Ef3    1        s     d  ]]     .
D3     1        s     u  [[
Ef3    1        s     u  ==
D3     1        s     u  ==
C3     1        s     u  ==
Bf2    1        s     u  ==
A2     1        s     u  ]]
measure 44
G2    12-       h.    u        -
measure 45
G2    12        h.    u
measure 46
C4     1        s     d  [[    (
Bf3    1        s f   d  ==    )+
Af3    1        s f   d  ==    (
G3     1        s     d  =]    )
F3     2        e     d  ]
Bf3    1        s     d  [[    (
Af3    1        s     d  ==    )
G3     1        s     d  ==    (
F3     1        s     d  =]    )
Ef3    2        e     d  ]
measure 47
rest  12
measure 48
C4     1        s     d  [[    (
Bf3    1        s     d  ==    )
A3     1        s n   d  ==    (+
G3     1        s     d  ==    )
F#3    1        s #   d  ==    (
Ef3    1        s f   d  ]]    )+
D3     1        s     u  [[
Ef3    1        s     u  ==
D3     1        s     u  ==
C3     1        s     u  ==
Bf2    1        s     u  ==
A2     1        s     u  ]]
measure 49
G3     6        q.    u         Z
 G2    6        q.    u
F#3    6        q.#   d         Z
measure 50
G3     6        q.    d         Z
Ef3    6        q.    d         Z
measure 51
*               D       sempre sf
P  C25:f33  C32:f1
C3     6        q.    u
D3     6        q.    d
measure 52
Ef3    6        q.    d
Ef2    6        q.    u
measure 53
Ef3    6        q.    d
E3     6        q.n   d
measure 54
Ef3    6        q.f   d         +
Df3    6        q.f   d
measure 55
Gf3    6        q.f   d
Ef3    6        q.    d
measure 56
Bf2    6        q.    u
D3     6        q.n   d         +
measure 57
Ef3    6        q.    d
D3     6        q.    d
measure 58
C3     6        q.    u
A2     6        q.    u
measure 59
Bf2    6        q.    u
G2     6        q.    u
measure 60
F2     6        q.    u
F2     1        s     u  [[
A2     1        s     u  ==
C3     1        s     u  ==
F3     1        s     u  ==
C3     1        s     u  ==
A2     1        s     u  ]]
measure 61
F2     2        e     u  [      mf
F2     2        e     u  =
F2     2        e     u  ]
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 62
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 63
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 64
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 65
F2     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 66
rest  12
measure 67
rest   4        q
*               GE  15  f
F2     1        s     u  [[    (
*               F   0
A2     1        s     u  ]]    )
Bf2    2        e     u  [      .
C3     2        e     u  =      .
D3     2        e     u  ]      .
measure 68
Ef3    2        e     d  [      .
F3     2        e     d  =      .
G3     2        e     d  ]      .
A3     4        q     d        (
Bf3    2        e     d        )
measure 69
F3     2        e     d  [      .
F3     2        e     d  =      .
F3     2        e     d  ]      .
F3     2        e     d  [
rest   2        e
Bf3    1        s     d  =[    (
A3     1        s     d  ]]    )
measure 70
G3     1        s     d  [[    (
F3     1        s     d  ==    )
Ef3    1        s     d  ==     .
D3     1        s     d  ==     .
G3     1        s     d  ==    (
F3     1        s     d  ]]    )
Ef3    1        s     d  [[    (
D3     1        s     d  ==    )
C3     1        s     d  ==     .
Bf2    1        s     d  ==     .
Ef3    1        s     d  ==    (
D3     1        s     d  ]]    )
measure 71
C3     1        s     u  [[     .
Bf2    1        s     u  ==     .
A2     1        s     u  ==     .
G2     1        s     u  ==     .
F2     1        s     u  ==     .
Ef2    1        s     u  ]]     .
D2     1        s     u  [[
F2     1        s     u  ==
Ef2    1        s     u  ==
G2     1        s     u  ==
F2     1        s     u  ==
A2     1        s     u  ]]
measure 72
G2     1        s     u  [[
Bf2    1        s     u  ==
A2     1        s     u  ==
C3     1        s     u  ==
Bf2    1        s     u  ==
D3     1        s     u  ]]
Ef3    1        s     d  [[
F3     1        s     d  ==
G3     1        s     d  ==
E3     1        s n   d  ==
F3     1        s     d  ==
G3     1        s     d  ]]
measure 73
E3     1        s n   d  [[    (
F3     1        s     d  ==    )
E3     1        s     d  ==    (
F3     1        s     d  ==    )
D3     1        s     d  ==     .
Bf2    1        s     d  ]]     .
E3     1        s     d  [[    (
F3     1        s     d  ==    )
E3     1        s     d  ==    (
F3     1        s     d  ==    )
D3     1        s     d  ==     .
Bf2    1        s     d  ]]     .
measure 74
F3     4        q     d         fp
rest   2        e
*               E   0
P    C17:Y65
F3     4        q     d
rest   2        e
measure 75
F3     4        q     d
rest   2        e
*               F   15
F3     4        q     d
rest   2        e
measure 76
F3    12-       h.    d        -
measure 77
F3     6-       q.    d        -
F3     4        q     d         F
rest   2        e
measure 78
Gf3    6        q.f   d        (p
P    C33:Y57
G3     6        q.n   d        )
measure 79
Af3    6-       q.f   d        -
Af3    2        e     d
rest   2        e
rest   2        e
measure 80
Af3    6        q.f   d        (
A3     6        q.n   d        )
measure 81
Bf3    6-       q.    d        -
Bf3    2        e     d
rest   2        e
rest   2        e
measure 82
B3     6        q.n   d        (
C4     6        q.    d        )
measure 83
Df4    6        q.f   d        (
C4     2        e     d        )
rest   2        e
rest   2        e
measure 84
A3     6        q.n   d        (+
Bf3    4        q     d        )
D3     2        e     d         .f
measure 85
Ef3   12        h.    d
measure 86
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 87
Bf2    4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 88
rest  12
measure 89
rest  12
measure 90
Bf2    1        s     d  [[    (p
P    C33:Y77
C3     1        s     d  ==
D3     1        s     d  ==
Ef3    1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ]]
A3     1        s     d  [[
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ==
F4     1        s     d  ]]    )
measure 91
D4     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 92
Bf2    1        s     d  [[    (
C3     1        s     d  ==
D3     1        s     d  ==
Ef3    1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ]]
A3     1        s     d  [[
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ==
F4     1        s     d  ]]    )
measure 93
*               DH      cresc.
P  C25:f33  C17:Y73 C18:Y73
D4     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
measure 94
Ef3    2        e     d  [
Ef3    2        e     d  =
Ef3    2        e     d  ]
Ef3    2        e     d  [
Ef3    2        e     d  =
Ef3    2        e     d  ]
measure 95
Ef3    2        e     d  [
Ef3    2        e     d  =
Ef3    2        e     d  ]
Ef3    2        e     d  [
Ef3    2        e     d  =
Ef3    2        e     d  ]
measure 96
*               GJ      f
P   C17:Y73
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 97
Bf2    4        q     u
rest   2        e
F3     4        q     d
rest   2        e
measure 98
Bf2    4        q     u
rest   2        e
F3     4        q     d
rest   2        e
measure 99
Bf2    4        q     u
rest   2        e
rest   2        e
F3     2        e     d  [      mf
P    C33:Y66
F3     2        e     d  ]
measure 100
rest   2        e
Bf2    2        e     u  [
Bf2    2        e     u  ]
rest   2        e
F3     2        e     d  [
F3     2        e     d  ]
measure 101
Bf2    2        e     d  [
rest   2        e
F3     2        e     d  ]     (p
P    C33:Y60
Bf3    2        e     d  [     )
rest   2        e
P    C1:Y10
F3     2        e     d  ]     (pp
P    C33:Y57
measure 102
Bf3    2        e     d  [     )
rest   2        e
F2     2        e     d  ]      f
Bf2    2        e     u  [      .
Bf2    2        e     u  =      .
Bf2    2        e     u  ]      .
measure 103
Bf2    4        q     u
rest   2        e
rest   4        q
mheavy2
/END
/eof
//
