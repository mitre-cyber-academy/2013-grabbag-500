&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/03/01} [KHM:3569760769]
TIMESTAMP: DEC/26/2001 [md5sum:9e0f20ef05529e3603224c4ca3b954e0]
11/09/94 W Hewlett
WK#:55,3      MV#:3
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Menuetto [Third Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:12   T:3/4  C:4   D:Menuetto
Bf3    3        s     u  [/     f
D4     9        e.    u  =
F4     3        s     u  ]\
measure 1
Bf4   12        q     d
rest   9        e.
F4     3        s     u  [/
Bf4    9        e.    u  =
D5     3        s     u  ]\
measure 2
F5    12        q     d
F5    12        q     d
F5    12        q     d
measure 3
F5    12        q     d        (
E5     9        e.n   d  [     )
G5     3        s     d  =\
A5     9        e.    d  =
Bf5    3        s     d  ]\
measure 4
Bf5   12        q     d        (
A5    12        q     d        )
gG5    4        t     u  [[[   (
gF5    4        t     u  ===
gE5    4        t     u  ]]]
F5     9        e.    d  [     )(p
P    C34:Y58
G5     3        s     d  ]\    )
measure 5
F5    12        q     d        (
Ef5   12        q f   d        )+
Ef5   12        q     d         .
measure 6
Ef5   12        q     d        (
D5    12        q     d        )
gEf5   4        t     u  [[[   (
gD5    4        t     u  ===
gC5    4        t     u  ]]]
D5     9        e.    d  [     )(
Ef5    3        s     d  ]\    )
measure 7
D5    12        q     d        (
C5    12        q     d        )
C5    12        q     d         .
measure 8
C5    12        q     d        (
Bf4   12        q     d        )
*               D       poco
P  C25:f33  C17:Y75
Bf4    9        e.    d  [      t
C5     3        s     d  ]\
measure 9
Bf4    9        e.    d  [      f
A4     3        s     d  =\
F5     9        e.    d  =
A4     3        s     d  =\
Bf4    9        e.    d  =      Zt
C5     3        s     d  ]\
measure 10
Bf4    9        e.    d  [
A4     3        s     d  =\
G5     9        e.    d  =
A4     3        s     d  =\
Bf4    9        e.    d  =      tZ
D5     3        s     d  ]\
measure 11
G4     9        e.    d  [
D5     3        s     d  =\
Ef5    9        e.    d  =
D5     3        s     d  =\
C5     9        e.    d  =
Bf4    3        s     d  ]\
measure 12
Bf4   12        q     d        (
A4     6        e     u        )
rest   3        s
mheavy4                    :|:
rest   3        s
rest  12        q
measure 13
rest  12        q
Ef5   12        q     d        (p
P    C33:Y58
D5    12        q     d
measure 14
Df5   12        q f   d
C5    12        q     d        )
rest  12        q
measure 15
rest  12        q
F5    12        q     d        (
E5    12        q n   d
measure 16
Ef5   12        q f   d         +
D5    12        q n   d        )+
rest  12        q
measure 17
rest  12        q
Gf5   12        q f   d        (f
P    C33:Y62
F5    12        q     d        )
measure 18
Af5   12        q f   d        (Z
P    C33:Y60
G5     9        e.n   d  [     )+b
F5     3        s     d  =\
Ef5    9        e.    d  =
D5     3        s     d  ]\
measure 19
C5    12-       q     d        -
C5     9        e.    d  [
D5     3        s     d  =\     .
C5     9        e.    d  =
D5     3        s     d  ]\     .
measure 20
C5    12-       q     d        -Z
P    C33:Y65
C5     9        e.    d  [
F5     3        s     d  =\
Ef5    9        e.f   d  =      +
D5     3        s     d  ]\
measure 21
C5    12-       q     d        ->p
P    C34:Y65
C5     9        e.    d  [
D5     3        s     d  ]\     .
C5     9        e.    d  [
D5     3        s     d  ]\     .
measure 22
C5    12-       q     d        ->
C5     9        e.    d  [
F5     3        s     d  ]\     .
Ef5    9        e.f   d  [      +
D5     3        s     d  ]\     .
measure 23
C5    12-       q     d        -
C5     9        e.    d  [
D5     3        s     d  ]\     .
C5     9        e.    d  [
D5     3        s     d  ]\     .
measure 24
C5    12        q     d
rest   9        e.
Bf3    3        s     u  [/     f
D4     9        e.    u  =
F4     3        s     u  ]\
measure 25
Bf4   12        q     d
rest   9        e.
F4     3        s     u  [/
Bf4    9        e.    u  =
D5     3        s     u  ]\
measure 26
F5    12        q     d
F5    12        q     d
F5    12        q     d
measure 27
F5    12        q     d        (
E5     9        e.n   d  [     )
G5     3        s     d  =\
A5     9        e.    d  =
Bf5    3        s     d  ]\
measure 28
Bf5   12        q     d        (
A5    12        q     d        )
F5     9        e.    d  [      tp
P    C34:Y58
G5     3        s     d  ]\
measure 29
F5    12        q     d        (
Ef5   12        q f   d        )+
Ef5   12        q     d         .
measure 30
Ef5   12        q     d        (
D5    12        q     d        )
G5     9        e.    d  [      t
Af5    3        s f   d  ]\
measure 31
G5    12        q     d        (
F5    12        q     d        )
F5    12        q     d         .
measure 32
F5    12        q     d        (
Ef5   12        q     d        )
Bf5    9        e.    d  [      ft
P    C33:Y62
C6     3        s     d  ]\
measure 33
Bf5    9        e.    d  [
A5     3        s n   d  =\     +
Ef6    9        e.    d  =
A5     3        s     d  =\
Bf5    9        e.    d  =      Zt
P    C33:Y59
C6     3        s     d  ]\
measure 34
Bf5    9        e.    d  [
A5     3        s     d  =\
Ef6    9        e.    d  =
A5     3        s     d  =\
Bf5    9        e.    d  =      tZ
P    C34:Y59
C6     3        s     d  ]\
measure 35
Bf5    9        e.    d  [      ff
P    C33:Y60
A5     3        s     d  =\
Ef6    9        e.    d  =
A5     3        s     d  =\
Ef6    9        e.    d  =
A5     3        s     d  ]\
measure 36
Ef6   12        q     d
rest  12        q
rest  12        q
measure 37
rest  12        q
rest   9        e.
F4     3        s     u  [/     p
P    C33:Y55
Bf4    9        e.    u  =
D5     3        s     u  ]\
measure 38
F5    12        q     d
rest   9        e.
G4     3        s     d  [/
C5     9        e.    d  =
Ef5    3        s     d  ]\
measure 39
Bf4   12        q     d         .
rest  12        q
rest  12        q
measure 40
gD5    0        e     u        (
C5    12        q     d        )
rest   9        e.
D5     3        s     d  [/
C5     9        e.    d  =
D5     3        s     d  ]\
measure 41
Bf4   12        q     d         .
rest   4        e  3            *
Bf5    4        e  3  d  [      f.
P    C33:Y63
A5     4        e  3  d  ]      !.
Ef6    4        e  3  d  [      *.
C6     4        e  3  d  =      .
A5     4        e  3  d  ]      !.
measure 42a                  start-end1
Bf5   12        q     d
rest   6        e
rest   3        s
mheavy2 42b              :|  stop-end1 start-end2
Bf5   12        q     d
rest   4        e  3
*               B       Fine
P   C25:f33
mdouble                      stop-end2
$   T:3/4   D:Trio
*               D       p dolce
P  C25:f33  C25:f1  C27:f33  C17:Y65
F5     4        e  3  d  [     (*
D5     4        e  3  d  ]     )!
G5     4        e  3  d  [     (*
Ef5    4        e  3  d  =
C5     4        e  3  d  ]     )!
measure 43
F5    12        q     d
rest   4        e  3            *
D5     4        e  3  d  [     (
Bf4    4        e  3  d  ]     )!
Ef5    4        e  3  d  [     (*
C5     4        e  3  d  =
A4     4        e  3  d  ]     )!
measure 44
Bf4   12        q     d
rest   4        e  3            *
F5     4        e  3  d  [     (
D5     4        e  3  d  ]     )!
Bf5    4        e  3  d  [     (*
G5     4        e  3  d  =
Ef5    4        e  3  d  ]     )!
measure 45
F5    12        q     d
rest   4        e  3            *
D5     4        e  3  d  [     (
Bf4    4        e  3  d  ]     )!
Ef5    4        e  3  d  [     (*
C5     4        e  3  d  =
A4     4        e  3  d  ]     )!
measure 46
Bf4   12        q     d
rest   4        e  3            *
C5     4        e  3  d  [     (
A4     4        e  3  d  ]     )!
D5     4        e  3  d  [     (*
Bf4    4        e  3  d  =
F4     4        e  3  d  ]     )!
measure 47
Ef5   12        q     d
rest   4        e  3            *
*               E   0
C5     4        e  3  d  [     (
A4     4        e  3  d  ]     )!
D5     4        e  3  d  [     (*
Bf4    4        e  3  d  =
F4     4        e  3  d  ]     )!
measure 48
Ef5   12        q     d
rest   4        e  3            *
C5     4        e  3  d  [     (
A4     4        e  3  d  ]     )!
D5     4        e  3  d  [     (*
*               F   15
Bf4    4        e  3  d  =
G4     4        e  3  d  ]     )!
measure 49
F4     4        e  3  u  [      f
A4     4        e  3  u  =
C5     4        e  3  u  ]
E5     4        e n3  d  [
F5     4        e  3  d  =
A5     4        e  3  d  ]
Bf5    4        e  3  d  [
G5     4        e  3  d  =
E5     4        e  3  d  ]
measure 50
F5    12        q     d
rest   4        e  3
mheavy4                      :|:
A5     4        e  3  d  [     (*p
P    C34:Y55
F5     4        e  3  d  ]     )!
C6     4        e  3  d  [     (*
A5     4        e  3  d  =
F5     4        e  3  d  ]     )!
measure 51
Ef5   12        q f   d         +
rest   4        e  3            *
Ef5    4        e  3  d  [     (
C5     4        e  3  d  ]     )!
D5     4        e  3  d  [     (*
Bf4    4        e  3  d  =
G4     4        e  3  d  ]     )!
measure 52
F4    12        q     u
rest   4        e  3            *
A5     4        e  3  d  [     (
F5     4        e  3  d  ]     )!
C6     4        e  3  d  [     (*
A5     4        e  3  d  =
F5     4        e  3  d  ]     )!
measure 53
Ef5   12        q     d
rest   4        e  3            *
Ef5    4        e  3  d  [     (
C5     4        e  3  d  ]     )!
D5     4        e  3  d  [     (*
Bf4    4        e  3  d  =
G4     4        e  3  d  ]     )!
measure 54
F4    12        q     u
rest   4        e  3            *
A4     4        e  3  u  [     (
F4     4        e  3  u  ]     )!
C5     4        e  3  u  [     (*
A4     4        e  3  u  =
Ef4    4        e  3  u  ]     )!
measure 55
D4     4        e  3  u  [
Bf4    4        e  3  u  =
A4     4        e  3  u  ]
*               E   0
P    C17:Y73
G4     4        e  3  d  [
C5     4        e  3  d  =
Bf4    4        e  3  d  ]
A4     4        e  3  d  [
D5     4        e  3  d  =
C5     4        e  3  d  ]
measure 56
Bf4    4        e  3  d  [
Ef5    4        e  3  d  =
D5     4        e  3  d  ]
C5     4        e  3  d  [
F5     4        e  3  d  =
Ef5    4        e  3  d  ]
D5     4        e  3  d  [
D6     4        e  3  d  =
*               F   15
C6     4        e  3  d  ]
measure 57
*               E   15
P    C17:Y70
Bf5    4        e  3  d  [
A5     4        e  3  d  =
G5     4        e  3  d  ]
F5     4        e  3  d  [
E5     4        e n3  d  =
D5     4        e  3  d  ]
C5     4        e  3  d  [
D5     4        e  3  d  =
*               F   0
Bf4    4        e  3  d  ]
measure 58
A4     4        e  3  d  [
F5     4        e  3  d  =
F5     4        e  3  d  ]
F5    24-       h     d        -
measure 59
F5     4        e  3  d  [
C6     4        e  3  d  =
A5     4        e  3  d  ]
F5    24-       h     d        -
measure 60
*               D       cresc.
P  C25:f33  C17:Y65
F5     4        e  3  d  [
C6     4        e  3  d  =
A5     4        e  3  d  ]
F5     4        e  3  d  [
Ef5    4        e  3  d  =
C5     4        e  3  d  ]
A4     4        e  3  u  [
F4     4        e  3  u  =
Ef4    4        e  3  u  ]
measure 61
D4     4        e  3  u  [      f
F4     4        e  3  u  =
Bf4    4        e  3  u  ]
Ef4    4        e  3  u  [
G4     4        e  3  u  =
C5     4        e  3  u  ]
D5     4        e  3  d  [
Ef5    4        e  3  d  =
A4     4        e  3  d  ]
measure 62
Bf4   12        q     d
rest   4        e  3
*               B       Menuetto D.C. al Fine
P  C25:f33
mheavy2                     :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/03/02} [KHM:3569760769]
TIMESTAMP: DEC/26/2001 [md5sum:a3c1d77943c39ac4ecb1443b74a2f3eb]
11/09/94 W Hewlett
WK#:55,3      MV#:3
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Menuetto [Third Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:12   T:3/4  C:4   D:Menuetto
rest   3        s
rest  12        q
measure 1
Bf4   12        q     u         f
 D4   12        q     u         .
rest  12        q
rest  12        q
measure 2
rest  12        q
F4    12        q     u
F4    12        q     u
measure 3
F4    12        q     u        (
E4    12        q n   u        )
E4    12        q     u
measure 4
E4    12        q n   u        (
F4    12        q     u        )
rest  12        q
measure 5
rest  12        q
Bf4   12        q     d        (p
A4    12        q     u        )
measure 6
Af4   24        h f   u
rest  12        q
measure 7
rest  12        q
G4    12        q     u        (
Gf4   12        q f   u        )
measure 8
F4    24        h     u
*               D       poco
P  C25:f33  C17:Y65
rest  12        q
measure 9
Ef4   24        h f   u         +f
D4    12        q     u         Z
measure 10
Ef4   24        h     u
D4    12-       q     u        -Z
P    C33:Y80
measure 11
D4    12        q     u
C4    12        q     u
Ef4   12        q     u
measure 12
D4    12        q     u        (
C4     6        e     u        )
rest   3        s
mheavy4                    :|:
rest   3        s
rest  12        q
measure 13
rest  12        q
C5    12        q     d        (
B4    12        q n   d
measure 14
Bf4   12        q f   d         +
A4    12        q     u        )
rest  12        q
measure 15
rest  12        q
D5    12        q     d        (
C#5   12        q #   d
measure 16
C5    12        q n   d         +
Bf4   12        q     d        )
rest  12        q
measure 17
rest  12        q
Ef5   12        q     d        (f
P    C33:Y60
D5    12        q     d        )
measure 18
F5    12        q     d        (Z
P    C33:Y60
Ef5   12        q     d        )
rest  12        q
measure 19
rest  12        q
G4    12        q     u        (
Bf4   12        q     d        )
measure 20
Bf4   12        q     d        (Z
A4    12        q     u        )
rest  12        q
measure 21
rest  12        q
G4    12        q     u        (p
P    C33:Y58
Bf4   12        q     d        )
measure 22
Bf4   12        q     d        (>
A4    12        q     u        )
rest  12        q
measure 23
rest  12        q
G4    12        q     u        (
Bf4   12        q     d        )
measure 24
A4    12        q     u
rest  12        q
rest  12        q
measure 25
Bf4   12        q     u         f
 D4   12        q     u         .
rest  12        q
rest  12        q
measure 26
rest  12        q
F4    12        q     u
F4    12        q     u
measure 27
F4    12        q     u        (
E4    12        q n   u        )
E4    12        q     u
measure 28
E4    12        q n   u        (
F4    12        q     u        )
rest  12        q
measure 29
rest  12        q
Bf4   12        q     d        (p
A4    12        q     u        )
measure 30
Af4   24        h f   u
rest  12        q
measure 31
rest  12        q
C5    12        q     d        (
Cf5   12        q f   d        )
measure 32
Bf4   24        h     d
Df4   12        q f   u         f
measure 33
Ef4   24        h     u
Df4   12        q f   u         Z
measure 34
Ef4   24        h     u
Df4   12        q f   u         Z
measure 35
Ef4   12        q     u         ff.
P    C33:Y75
Ef4   12        q     u         .
Ef4   12        q     u         .
measure 36
C4    12        q     u         .
rest  12        q
rest  12        q
measure 37
rest  36
measure 38
Bf3   12        q     u         p.
P    C33:Y86
rest  12        q
C4    12        q     u         .
measure 39
D4    12        q     u         .
rest  12        q
rest  12        q
measure 40
Ef4   12        q     u         .
rest  12        q
Ef4   12        q     u         .
measure 41
D4    12        q     u         .
rest  12        q
A5    12        q     d         .f
 C5   12        q     d
 F4   12        q     d
measure 42a                  start-end1
Bf5   12        q     d         .
 Bf4  12        q     d
 D4   12        q     d
rest   6        e
rest   3        s
mheavy2 42b              :|  stop-end1 start-end2
Bf5   12        q     d         .
 Bf4  12        q     d
 D4   12        q     d
rest   4        e  3
*               B       Fine
P   C25:f33
mdouble                      stop-end2
$   T:3/4    D:Trio
rest   8        e  3
rest  12        q
measure 43
rest  12        q
F4    12        q     u         .p
P    C34:Y64
rest  12        q
measure 44
rest  12        q
F4    12        q     u         .
G4    12        q     u         .
measure 45
rest  12        q
F4    12        q     u         .
Ef4   12        q     u         .
measure 46
rest  12        q
C4    12        q     u         .
D4    12        q     u         .
measure 47
rest  12        q
*               E   0
P    C17:Y75
C4    12        q     u         .
D4    12        q     u         .
measure 48
rest  12        q
A4    12        q     u         .
*               F   15
G4    12        q     u         .
measure 49
F4    24        h     u         f
E4     8        e.n   u  [     (
G4     4        s     u  ]\    )
measure 50
F4    12        q     u
rest   4        e
mheavy4                      :|:
rest   8        e
rest  12        q
measure 51
rest  12        q
C4    12        q     u        (p
P    C33:Y77
E4    12        q n   u        )
measure 52
F4     4        e  3  u  [     (*
A4     4        e  3  u  =
C5     4        e  3  u  ]     )!
F5    12        q     d
rest  12        q
measure 53
rest  12        q
C4    12        q     u        (
E4    12        q n   u        )
measure 54
F4     4        e  3  u  [     (*
A4     4        e  3  u  =
C5     4        e  3  u  ]     )!
F5    12        q     d
Ef4   12        q f   u         +
measure 55
D4    12        q     u         .
*               E   0
P    C17:Y70
Ef4   12        q     u         .
F4    12        q     u         .
measure 56
G4    12        q     u         .
A4    12        q     u         .
*               F   15
Bf4   12        q     d         .
measure 57
E4    36        h.n   u         >
measure 58
F4    12        q     u
rest   4        e  3            *
Ef4    4        e f3  u  [     (+
F4     4        e  3  u  ]     )!
D4     4        e  3  u  [     (*
F4     4        e  3  u  =
Bf4    4        e  3  u  ]     )!
measure 59
A4    12        q     u
rest   4        e  3            *
Ef4    4        e  3  u  [     (
F4     4        e  3  u  ]     )!
D4     4        e  3  u  [     (*
F4     4        e  3  u  =
Bf4    4        e  3  u  ]     )!
measure 60
*               D       cresc.
P  C25:f33  C17:Y65
A4    12        q     u
rest  12        q
C4    12        q     u         .
measure 61
F4    12        q     u         .f
P    C34:Y69
G4    12        q     u         .
Ef4   12        q     u         .
measure 62
D4    12        q     u         .
rest   4        e  3
*               B       Menuetto D.C. al Fine
P  C25:f33
mheavy2                     :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/03/03} [KHM:3569760769]
TIMESTAMP: DEC/26/2001 [md5sum:bfd8b64780c13f6eec852206df6b4eba]
11/09/94 W Hewlett
WK#:55,3      MV#:3
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Menuetto [Third Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:12   T:3/4  C:13    D:Menuetto
rest   3        s
rest  12        q
measure 1
F4    12        q     d         .f
P    C34:Y62
rest  12        q
rest  12        q
measure 2
rest  12        q
D4    12        q     d        (
C4    12        q     d        )
measure 3
Bf3   24        h     u
G3    12        q     u
measure 4
F3    12        q     u
rest  12        q
rest  12        q
measure 5
rest  12        q
G4    12        q     d        (p
P    C33:Y57
F#4   12        q #   d        )
measure 6
F4    24        h n   d         +
rest  12        q
measure 7
rest  12        q
E4    12        q n   d        (
Ef4   12        q f   d        )
measure 8
D4    24        h     d
*               D       poco
P  C25:f33  C17:Y65
rest  12        q
measure 9
C4    24        h     d         f
D4    12        q     d         Z
measure 10
C4    24        h     d
Bf3   12        q     u         Z
measure 11
G3    36        h.    u
measure 12
F3    12        q     u
rest   6        e
rest   3        s
mheavy4                    :|:
rest   3        s
rest  12        q
measure 13
rest  36
measure 14
rest  36
measure 15
rest  36
measure 16
rest  36
measure 17
rest  12        q
A3    12        q     u        (f
P    C33:Y64
Bf3   12        q     u        )
measure 18
B3    12        q n   u        (Z
C4    12        q     d        )
rest  12        q
measure 19
rest  12        q
Ef4   12        q     d        (
E4    12        q n   d        )
measure 20
F4    24        h     d         Z
P    C33:Y60
rest  12        q
measure 21
rest  12        q
Ef4   12        q f   d        (+p
P    C34:Y60
E4    12        q n   d        )
measure 22
F4    24        h     d         >
rest  12        q
measure 23
rest  12        q
Ef4   12        q f   d        (+
E4    12        q n   d        )
measure 24
F4    12        q     d
rest  12        q
rest  12        q
measure 25
F4    12        q     d         .f
P    C34:Y60
rest  12        q
rest  12        q
measure 26
rest  12        q
D4    12        q     d        (
C4    12        q     d        )
measure 27
Bf3   24        h     u
G3    12        q     u
measure 28
F3    12        q     u         .
rest  12        q
rest  12        q
measure 29
rest  12        q
G4    12        q     d        (p
P    C33:Y58
F#4   12        q #   d        )
measure 30
F4    24        h n   d         +
rest  12        q
measure 31
rest  12        q
A4    12        q     d        (
Af4   12        q f   d        )
measure 32
G4    24        h n   d         +
Bf3   12        q     u         f
measure 33
C4    24        h     d
Bf3   12        q     u         Z
measure 34
C4    24        h     d
Bf3   12        q     u         Z
measure 35
C4    12        q     d         ff.
C4    12        q     d         .
C4    12        q     d         .
measure 36
A3    12        q     u         .
rest  12        q
rest  12        q
measure 37
rest  36
measure 38
F3    12        q     u         .p
P    C34:Y69
rest  12        q
G3    12        q     u         .
measure 39
Bf3   12        q     u         .
rest  12        q
rest  12        q
measure 40
A3    12        q     u         .
rest  12        q
A3    12        q     u         .
measure 41
Bf3   12        q     u         .
rest  12        q
Ef4   12        q     d         .f
P    C34:Y62
measure 42a                  start-end1
D4    12        q     d         .
rest   6        e
rest   3        s
mheavy2 42b              :|  stop-end1 start-end2
D4    12        q     d         .
rest   4        e  3
*               B       Fine
P   C25:f33
mdouble                      stop-end2
$   T:3/4    D:Trio
rest   8        e  3
rest  12        q
measure 43
rest  12        q
D4    12        q     d         .p
P    C34:Y64
rest  12        q
measure 44
rest  12        q
D4    12        q     d         .
Ef4   12        q     d         .
measure 45
rest  12        q
D4    12        q     d         .
C4    12        q     d         .
measure 46
rest  12        q
A3    12        q     u         .
Bf3   12        q     u         .
measure 47
rest  12        q
*               E   0
P    C17:Y65
A3    12        q     u         .
Bf3   12        q     u         .
measure 48
rest  12        q
C4    12        q     d         .
*               F   15
Bf3   12        q     u         .
measure 49
A3    24        h     u         f
G3     8        e.    u  [     (
Bf3    4        s     u  ]\    )
measure 50
A3    12        q     u
rest   4        e
mheavy4                      :|:
rest   8        e
rest  12        q
measure 51
rest  12        q
A3    12        q     u        (p
Bf3   12        q     u        )
measure 52
A3    36-       h.    u        -
measure 53
A3    24        h     u        (
Bf3   12        q     u        )
measure 54
A3    36        h.    u
measure 55
Bf3   12        q     u         .
rest  12        q
rest  12        q
measure 56
rest  36
measure 57
G3    36        h.    u         >
measure 58
A3    12        q     u
rest  12        q
rest  12        q
measure 59
rest  36
measure 60
rest  12        q
*               D       cresc.
P  C25:f33  C17:Y70
rest   4        e  3            *
F3     4        e  3  u  [     (
A3     4        e  3  u  ]     )!
C4     4        e  3  d  [     (*
F4     4        e  3  d  =
A4     4        e  3  d  ]     )!
measure 61
Bf4   12        q     d         .f
P    C34:Y63
G4    12        q     d         .
C4    12        q     d         .
measure 62
D4    12        q     d         .
rest   4        e  3
*               B       Menuetto D.C. al Fine
P  C25:f33
mheavy2                     :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n3/stage2/03/04} [KHM:3569760769]
TIMESTAMP: DEC/26/2001 [md5sum:c2bff2d661c36a708dfb801f4b3b54df]
11/09/94 W Hewlett
WK#:55,3      MV#:3
T.Trautwein No.41, 803, Berlin; HV III:62
String Quartet Op. 55, No. 3, in B-flat Major
Menuetto [Third Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-2   Q:12   T:3/4  C:22   D:Menuetto
rest   3        s
rest  12        q
measure 1
Bf3   12        q     d         .f
P    C34:Y62
Bf2   12        q     u         .
rest  12        q
measure 2
rest  12        q
Bf3   12        q     d        (
A3    12        q     d        )
measure 3
G3    24        h     d
C3    12        q     u
measure 4
F3    12        q     d
F2    12        q     u
rest  12        q
measure 5
rest  36
measure 6
rest  36
measure 7
rest  36
measure 8
rest  36
measure 9
*               C       poco f
P  C25:f33  C30:f1  C17:Y65
F3    36-       h.    d        -
measure 10
F3    24        h     d
G3    12        q     d         Z
measure 11
Ef3   36        h.    d
measure 12
F3    12        q     d
rest   6        e
rest   3        s
mheavy4                    :|:
F2     3        s     u  [/     p
P    C33:Y67
A2     9        e.    u  =
C3     3        s     u  ]\
measure 13
F3    12        q     d
rest  12        q
rest  12        q
measure 14
rest  12        q
rest   9        e.
F2     3        s     u  [/
A2     9        e.    u  =
C3     3        s     u  ]\
measure 15
F3    12        q     d
rest  12        q
rest  12        q
measure 16
rest  12        q
rest   9        e.
F2     3        s     u  [/     f
Bf2    9        e.    u  =
D3     3        s     u  ]\
measure 17
F3    36        h.    d
measure 18
D3    12        q     d        (Z
Ef3   12        q     d        )
rest  12        q
measure 19
rest  36
measure 20
rest  36
measure 21
rest  36
measure 22
rest  36
measure 23
rest  36
measure 24
rest  36
measure 25
Bf3   12        q     d         .f
P    C34:Y60
Bf2   12        q     u         .
rest  12        q
measure 26
rest  12        q
Bf3   12        q     d        (
A3    12        q     d        )
measure 27
G3    24        h     d
C3    12        q     u
measure 28
F3    12        q     d
F2    12        q     u
rest  12        q
measure 29
rest  36
measure 30
rest  36
measure 31
rest  36
measure 32
rest  12        q
rest  12        q
Gf3   12        q f   d         f
P    C33:Y60
measure 33
F3    24        h     d
Gf3   12        q f   d         Z
P    C33:Y60
measure 34
F3    24        h     d
Gf3   12        q f   d         Z
P    C33:Y60
measure 35
F3    12        q     d         ff.
P    C33:Y60
F3    12        q     d         .
F3    12        q     d         .
measure 36
F3    12        q     d         .
rest  12        q
rest  12        q
measure 37
rest  36
measure 38
D3    12        q     d         .p
rest  12        q
Ef3   12        q     d         .
measure 39
F3    12        q     d         .
rest  12        q
rest  12        q
measure 40
F3    12        q     d         .
rest  12        q
F3    12        q     d         .
measure 41
Bf2   12        q     u         .
rest  12        q
F2    12        q     u         .f
P    C34:Y77
measure 42a                  start-end1
Bf2   12        q     u
rest   6        e
rest   3        s
mheavy2 42b              :|  stop-end1 start-end2
Bf2   12        q     u
rest   4        e  3
*               B       Fine
P   C25:f33  C17:Y70
mdouble                      stop-end2
$   T:3/4   D:Trio
rest   8        e  3
rest  12        q
measure 43
rest  12        q
Bf3   12        q     d         .p
P    C34:Y57
rest  12        q
measure 44
rest  12        q
Bf3   12        q     d         .
Bf3   12        q     d         .
measure 45
rest  12        q
Bf3   12        q     d         .
F3    12        q     d         .
measure 46
rest  12        q
F3    12        q     d         .
Bf3   12        q     d         .
measure 47
rest  12        q
*               E   0
P    C17:Y65
F3    12        q     d         .
Bf3   12        q     d         .
measure 48
rest  12        q
F3    12        q     d         .
*               F   15
Bf2   12        q     u         .
measure 49
C3    36        h.    u         f
measure 50
F2    12        q     u
F3     4        e     d
mheavy4                      :|:
rest   8        e
rest  12        q
measure 51
F2     4        e  3  u  [     (*p
A2     4        e  3  u  =
C3     4        e  3  u  ]     )!
F3    24-       h     d        -
measure 52
F3    36        h.    d
measure 53
F2     4        e  3  u  [     (*
A2     4        e  3  u  =
C3     4        e  3  u  ]     )!
F3    24-       h     d        -
measure 54
F3    24        h     d
Ef3   12        q     d         .
measure 55
D3    12        q     d         .
rest  12        q
rest  12        q
measure 56
rest  36
measure 57
C3    36        h.    u         >
measure 58
F2    12        q     u
rest   4        e  3            *
C4     4        e  3  d  [     (
A3     4        e  3  d  ]     )!
D4     4        e  3  d  [     (*
Bf3    4        e  3  d  =
F3     4        e  3  d  ]     )!
measure 59
Ef4   12        q     d
rest   4        e  3            *
C4     4        e  3  d  [     (
A3     4        e  3  d  ]     )!
D4     4        e  3  d  [     (*
Bf3    4        e  3  d  =
F3     4        e  3  d  ]     )!
measure 60
*               D       cresc.
P  C25:f33  C17:Y65
Ef4   12        q     d
rest  12        q
Ef3   12        q     d         .
measure 61
D3    12        q     d         .f
Ef3   12        q     d         .
F3    12        q     d         .
measure 62
Bf2   12        q     u         .
rest   4        e  3
*               B       Menuetto D.C. al Fine
P  C25:f33
mheavy2                     :|
/END
/eof
//
