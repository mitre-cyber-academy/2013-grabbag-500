&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/04/01} [KHM:2799591906]
TIMESTAMP: DEC/26/2001 [md5sum:8ac1ac865b2bcf85f298f4ffd2715c65]
11/13/94 W Hewlett
WK#:64,1      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Finale [Fourth Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:6/8  C:4  D:Presto
C5     2        e     d         .p
P    C34:Y64
measure 1
C5     2        e     d  [      .
rest   2        e
C5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
C5     1        s     d  =[     .
C5     1        s     d  ]]     .
measure 2
C5     2        e     d  [      .
B4     2        e     d  =      .
A4     2        e     d  ]      .
G4     2        e     u  [      .
rest   2        e
F4     2        e     u  ]      .
measure 3
F4     4        q     u        (
E4     2        e     u        )
D4     2        e     u  [     (
F4     2        e     u  =
A4     2        e     u  ]     )
measure 4
C4     6        q.    u        (
B3     2        e     u        )
rest   2        e
C5     2        e     d         .
measure 5
C5     2        e     d  [      .
rest   2        e
C5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
C5     1        s     d  =[     .
C5     1        s     d  ]]     .
measure 6
C5     2        e     d  [      .
B4     2        e     d  =      .
A4     2        e     d  ]      .
G4     2        e     u  [      .
rest   2        e
F4     2        e     u  ]      .
measure 7
F4     4        q     u        (
E4     2        e     u        )
D4     2        e     u  [     (
F4     2        e     u  =
A4     2        e     u  ]     )
measure 8
C4     4        q     u        (
E4     1        s     u  [[
D4     1        s     u  ]]    )
C4     2        e     u
rest   2        e
F#5    1        s #   d  [[    (f
P    C33:Y63
G5     1        s     d  ]]    )
measure 9
A5     1        s     d  [[    (
G5     1        s     d  ==
F5     1        s n   d  ==    )+
E5     1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ]]     .
B4     1        s     u  [[    (
A4     1        s     u  ==
G4     1        s     u  ==    )
F4     1        s     u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
measure 10
C4     2        e     u  [      .
E4     2        e     u  =      .
G4     2        e     u  ]      .
C5     2        e     d  [      .
E5     2        e     d  =      .
F#5    1        s #   d  =[    (
G5     1        s     d  ]]    )
measure 11
A5     1        s     d  [[    (
G5     1        s     d  ==
F5     1        s n   d  ==    )+
E5     1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ]]     .
B4     1        s     u  [[    (
A4     1        s     u  ==
G4     1        s     u  ==    )
F4     1        s     u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
measure 12
C4     2        e     u  [      .
E4     2        e     u  =      .
G4     2        e     u  ]      .
C5     2        e     d  [      .
E5     2        e     d  =      .
G#5    1        s #   d  =[    (
A5     1        s     d  ]]    )
measure 13
B5     1        s     d  [[    (
A5     1        s     d  ==
C6     1        s     d  ==    )
B5     1        s     d  ==     .
A5     1        s     d  ==     .
G5     1        s n   d  ]]     .+
F#5    1        s #   d  [[    (
E5     1        s     d  ==
D5     1        s     d  ==    )
C5     1        s     d  ==     .
B4     1        s     d  ==     .
A4     1        s     d  ]]     .
measure 14
G4     2        e     d  [      .
B4     2        e     d  =      .
D5     2        e     d  ]      .
G5     2        e     d  [      .
B5     2        e     d  =      .
D6     2        e     d  ]      .
measure 15
D6     2        e     d  [      .
rest   2        e
P    C1:Y-5
D6     2        e     d  ]      .
D6     2        e     d         .
rest   2        e
D6     1        s     d  [[     .
D6     1        s     d  ]]     .
measure 16
D6     2        e     d  [     (
C6     2        e     d  =     )
C6     2        e     d  ]      .
C6     2        e     d  [     (
A#5    2        e #   d  =
B5     2        e     d  ]     )
measure 17
B5     2        e     d  [     (
A5     2        e n   d  =     )+
A5     2        e     d  ]      .
A5     2        e     d  [     (
F#5    2        e #   d  =
G5     2        e     d  ]     )
measure 18
G5     1        s     d  [[    (
F#5    1        s #   d  ==    )
A5     1        s     d  ==    (
G5     1        s     d  ==    )
B5     1        s     d  ==    (
A5     1        s     d  ]]    )
G5     2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
measure 19
G5     1        s     d  [[    (
F#5    1        s #   d  ==    )
A5     1        s     d  ==    (
G5     1        s     d  ==    )
B5     1        s     d  ==    (
A5     1        s     d  ]]    )
G5     2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
measure 20
G5     1        s     d  [[    (
F#5    1        s #   d  ==    )
A5     1        s     d  ==    (
G5     1        s     d  ==    )
Bf5    1        s f   d  ==    (
A5     1        s     d  ]]    )
G5     2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
measure 21
F#5    2        e #   d  [      .
F#5    2        e     d  =      .
F#5    2        e     d  ]      .
F#5    2        e     d  [      .
F#5    2        e     d  =      .
F#5    2        e     d  ]      .
measure 22
F#5    2        e #   d
rest   2        e
rest   2        e
rest   4        q
D6     1        s     d  [[    (
C6     1        s     d  ]]    )
measure 23
B5     1        s n   d  [[    (+
A5     1        s     d  ==
G5     1        s     d  ==    )
F#5    1        s #   d  ==     .
E5     1        s n   d  ==     .+
D5     1        s     d  ]]     .
C5     1        s     u  [[    (
B4     1        s     u  ==
A4     1        s     u  ==    )
G4     1        s     u  ==     .
F#4    1        s #   u  ==     .
E4     1        s     u  ]]     .
measure 24
D4     2        e     u  [      .
F#4    2        e #   u  =      .
A4     2        e     u  ]      .
C5     2        e     d         .
rest   2        e
C6     1        s     d  [[    (
B5     1        s     d  ]]    )
measure 25
A5     1        s     d  [[    (
G5     1        s     d  ==
F#5    1        s #   d  ==    )
E5     1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ]]     .
B4     1        s     u  [[    (
A4     1        s     u  ==
G4     1        s     u  ==    )
F#4    1        s #   u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
measure 26
C4     2        e     u  [     (
B3     2        e     u  =     )
F#4    2        e #   u  ]      .
G4     4        q     u
F#5    1        s #   d  [[     .
G5     1        s     d  ]]     .
measure 27
A5     1        s     d  [[    (
G5     1        s     d  ==    )
B5     1        s     d  ==    (
G5     1        s     d  ==    )
D#5    1        s #   d  ==     .
E5     1        s     d  ]]     .
F#5    1        s #   d  [[    (
E5     1        s     d  ==    )
G5     1        s     d  ==    (
E5     1        s     d  ==    )
B4     1        s     d  ==     .
C5     1        s     d  ]]     .
measure 28
D5     1        s n   d  [[    (+
C5     1        s     d  ==    )
E5     1        s     d  ==    (
C5     1        s     d  ==    )
G#4    1        s #   d  ==     .
A4     1        s     d  ]]     .
C5     1        s     d  [[    (
B4     1        s     d  ==    )
D5     1        s     d  ==    (
C5     1        s     d  ==    )
E5     1        s     d  ==    (
D5     1        s     d  ]]    )
measure 29
F5     1        s n   d  [[    (+
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]    )
F5     1        s     d  [[    (
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]    )
measure 30
G4     4        q     u        (
B4     1        s     u  [[
A4     1        s     u  ]]    )
G4     2        e     u
rest   2        e
D4     2        e     u         .mf
P    C34:Y77
measure 31
gE4    4        t     u  [[[   (
gD4    4        t     u  ===
gC#4   4        t     u  ]]]
D4     2        e     u  [     ).
G4     2        e     u  =      .
B4     2        e     u  ]      .
gF#4   4        t     u  [[[   (
gE4    4        t     u  ===
gD#4   4        t     u  ]]]
E4     2        e     u  [     ).
A4     2        e     u  =      .
C5     2        e     u  ]      .
measure 32
gG4    4        t     u  [[[   (
gF#4   4        t     u  ===
gE4    4        t     u  ]]]
F#4    2        e #   u  [     )+.
A4     2        e     u  =      .
D5     2        e     u  ]      .
E5     1        s     d  [[    (
D5     1        s     d  ==    )
C5     1        s     d  ==    (
B4     1        s     d  ==    )
A4     1        s     d  ==    (
G4     1        s     d  ]]    )
measure 33
gA4    4        t     u  [[[   (
gG4    4        t     u  ===
gF#4   4        t     u  ]]]
G4     2        e     d  [     ).
G5     2        e     d  =      .
G5     2        e     d  ]      .
A5     1        s     d  [[    (
G5     1        s     d  ==    )
F#5    1        s #   d  ==    (
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]    )
measure 34
B4     3        e.    d  [     (
C5     1        s     d  =\    )
A4     2        e     d  ]      .
G4     2        e     u         .
rest   2        e
rest   2        e
measure 35
rest   2        e
D6     2        e     d  [      .p
P    C34:Y56
D6     2        e     d  ]      .
D6     2        e     d  [     (
C6     2        e     d  =     )
C6     2        e     d  ]      .
measure 36
D6     1        s     d  [[    (
C6     1        s     d  ==    )
B5     1        s     d  ==    (
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s #   d  ]]    )
G5     2        e     d         .
rest   2        e
G4     2        e     u         .
measure 37
gA4    4        t     u  [[[   (
gG4    4        t     u  ===
gF#4   4        t     u  ]]]
G4     2        e     d  [     ).
G5     2        e     d  =      .
G5     2        e     d  ]      .
A5     1        s     d  [[    (
G5     1        s     d  ==    )
F#5    1        s #   d  ==    (
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]    )
measure 38
B4     3        e.    d  [     (
C5     1        s     d  =\    )
A4     2        e     d  ]      .
G4     2        e     u         .
rest   2        e
G5     2        e     d         .
measure 39
G5     2        e     d  [      .
rest   2        e
P    C1:Y10
G5     2        e     d  ]      .
G5     2        e     d  [      .
rest   2        e
P    C1:Y10
G5     1        s     d  =[     .
G5     1        s     d  ]]     .
measure 40
G5     2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
G5     2        e     d         .
rest   2        e
mheavy2                      :|
G5     2        e     d         .f
P    C34:Y61
measure 41
G5     1        s     d  [[    (
B5     1        s     d  ==
D6     1        s     d  ==    )
C6     1        s     d  ==     .
B5     1        s     d  ==     .
A5     1        s     d  ]]     .
G5     2        e     d         .
rest   2        e
rest   2        e
measure 42
rest  12
measure 43
rest  12
measure 44
rest  12
measure 45
rest  12
measure 46
rest  12
measure 47
rest   2        e
rest   2        e
A4     2        e     u         .
A4     2        e     u  [      .
rest   2        e
A4     2        e     u  ]      .
measure 48
A4     2        e     u  [
rest   2        e
A4     1        s     u  =[     .
A4     1        s     u  ]]     .
A4     2        e     u  [     (
G#4    2        e #   u  =     )
A4     2        e     u  ]      .
measure 49
B4     2        e     d  [      .
rest   2        e
B4     1        s     d  =[     .
B4     1        s     d  ]]     .
B4     2        e     u  [     (
A4     2        e     u  =     )
B4     2        e     u  ]      .
measure 50
C5     2        e     d  [     (
B4     2        e     d  =     )
C5     2        e     d  ]      .
D5     2        e     d  [      .
rest   2        e
D5     1        s     d  =[     .
D5     1        s     d  ]]     .
measure 51
*               E   0
P    C17:Y65
D5     2        e     d  [     (
C5     2        e     d  =     )
D5     2        e     d  ]      .
E5     2        e     d  [     (
D5     2        e     d  =     )
*               GF  15  f
P   C17:Y65 C18:Y65
E5     2        e     d  ]      .
measure 52
F5     2        e     d  [      .
rest   2        e
P    C1:Y10
F5     2        e     d  ]      .
F5     2        e     d  [      .
rest   2        e
P    C1:Y10
F5     1        s     d  =[     .
F5     1        s     d  ]]     .
measure 53
F5     2        e     d  [      .
E5     2        e     d  =      .
D5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
P    C1:Y10
A5     2        e     d  ]      .
measure 54
A5     2        e     d  [      .
rest   2        e
P    C1:Y0
A5     1        s     d  =[     .
A5     1        s     d  ]]     .
A5     2        e     d  [      .
G5     2        e     d  =      .
F5     2        e     d  ]      .
measure 55
E5     2        e     d  [      .
rest   2        e
P    C1:Y10
C6     1        s     d  =[     .
C6     1        s     d  ]]     .
C6     2        e     d  [      .
A5     2        e     d  =      .
G5     1        s     d  =[    (
F5     1        s     d  ]]    )
measure 56
E5     2        e     d  [      .
G5     2        e     d  =      .
G5     2        e     d  ]      .
rest   2        e
G5     2        e     d  [      .
G5     2        e     d  ]      .
measure 57
rest   2        e
G5     1        s     d  [[     .
G5     1        s     d  =]     .
G5     2        e     d  ]      .
G5     2        e     d  [      .
F5     2        e     d  =      .
E5     2        e     d  ]      .
measure 58
D5     2        e     d  [      .
A5     2        e     d  =      .
A5     2        e     d  ]      .
rest   2        e
A5     2        e     d  [      .
A5     2        e     d  ]      .
measure 59
rest   2        e
A5     1        s     d  [[     .
A5     1        s     d  =]     .
A5     2        e     d  ]      .
A5     2        e     d  [      .
G5     2        e     d  =      .
F5     2        e     d  ]      .
measure 60
E5     2        e     d  [      .
rest   2        e
E5     2        e     d  ]      .
E5     2        e     d  [      .
rest   2        e
E5     1        s     d  =[     .
E5     1        s     d  ]]     .
measure 61
D#5    2        e #   d  [      .
D#5    2        e     d  =      .
D#5    2        e     d  ]      .
E5     2        e     d  [      .
rest   2        e
P    C1:Y10
F5     2        e     d  ]      .
measure 62
F5     2        e     d  [      .
rest   2        e
P    C1:Y10
F5     2        e     d  ]      .
F5     2        e     d         .
rest   2        e
E5     1        s     d  [[    (
F5     1        s     d  ]]    )
measure 63
E5     1        s     d  [[    (
F5     1        s     d  ==    )
B5     1        s     d  ==    (
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]    )
E5     1        s     d  [[    (
F5     1        s     d  ==
B5     1        s     d  ==
F5     1        s     d  =]    )
F5     2        e     d  ]      .
measure 64
F5     2        e     d  [      .
rest   2        e
P    C1:Y10
F5     2        e     d  ]      .
F5     2        e     d         .
rest   2        e
D#5    1        s #   d  [[    (
E5     1        s     d  ]]    )
measure 65
D#5    1        s #   d  [[    (
E5     1        s     d  ==    )
D6     1        s n   d  ==    (+
E5     1        s     d  ==
D#5    1        s #   d  ==     +
E5     1        s     d  ]]    )
D#5    1        s     d  [[    (
E5     1        s     d  ==    )
D6     1        s n   d  ==    (+
E5     1        s     d  ==    )
G#5    1        s #   d  ==     .
A5     1        s     d  ]]     .
measure 66
G#5    1        s #   d  [[    (
A5     1        s     d  ==    )
C6     1        s     d  ==    (
A5     1        s     d  ==    )
E5     1        s     d  ==     .
F5     1        s     d  ]]     .
E5     1        s     d  [[    (
F5     1        s     d  ==    )
A5     1        s     d  ==    (
F5     1        s     d  ]]    )
C#5    1        s #   d  [[     .ff
P    C34:Y74
D5     1        s     d  ]]     .
measure 67
C#5    1        s #   d  [[    (
D5     1        s     d  ==    )
F5     1        s     d  ==    (
D5     1        s     d  ==    )
A#4    1        s #   d  ==     .
B4     1        s     d  ]]     .
A#4    1        s     d  [[    (
B4     1        s     d  ==    )
D5     1        s     d  ==    (
B4     1        s     d  ==    )
G#4    1        s #   d  ==     .
A4     1        s n   d  ]]     .
measure 68
G#4    1        s #   u  [[    (
A4     1        s     u  ==    )
C5     1        s     u  ==    (
A4     1        s     u  ==    )
E4     1        s     u  ==     .
C4     1        s     u  ]]     .
F4     1        s     u  [[     .
D4     1        s     u  ==     .
E4     1        s     u  ==     .
C4     1        s     u  ==     .
D4     1        s     u  ==     .
B3     1        s     u  ]]     .
measure 69
*               GE  15  Z
P   C17:Y100 C18:Y100
A3    12        h.    u        (
measure 70
*               GF  0   p
P   C17:Y100
Bf3    2        e f   u  [     ).
rest   2        e
P    C1:Y40
Bf3    2        e     u  ]      .
Bf3    2        e     u  [      .
rest   2        e
P    C1:Y40
Bf3    1        s     u  =[     .
Bf3    1        s     u  ]]     .
measure 71
Bf3    2        e f   u  [     (
A3     2        e     u  =
C#4    2        e #   u  ]     )
*               E   0
D4     2        e     u  [     (
E4     2        e     u  =
*               F   15
F4     2        e     u  ]     )
measure 72
*               E   15
E4     6        q.    u        (
*               F   0
D4     2        e     u        )
rest   2        e
C5     2        e n   d         +.p
P    C35:Y64
measure 73
C5     2        e     d  [      .
rest   2        e
C5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
C5     1        s     d  =[     .
C5     1        s     d  ]]     .
measure 74
C5     2        e     d  [      .
B4     2        e     d  =      .
A4     2        e     d  ]      .
G4     2        e     u  [      .
rest   2        e
F4     2        e     u  ]      .
measure 75
F4     4        q     u        (
E4     2        e     u        )
D4     2        e     u  [     (
F4     2        e     u  =
A4     2        e     u  ]     )
measure 76
C4     6        q.    u        (
B3     2        e     u        )
rest   2        e
B4     1        s     d  [[    (
C5     1        s     d  ]]    )
measure 77
B4     1        s     d  [[    (
C5     1        s     d  ==    )
E5     1        s     d  ==    (
C5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]    )
B4     1        s     d  [[    (
C5     1        s     d  ==    )
E5     1        s     d  ==    (
C5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]    )
measure 78
D5     1        s     d  [[    (
C5     1        s     d  ==    )
C5     1        s     d  ==    (
B4     1        s     d  ==    )
B4     1        s     d  ==    (
A4     1        s     d  ]]    )
A4     1        s     u  [[    (
G4     1        s     u  ==    )
F#4    1        s #   u  ==    (
G4     1        s     u  ==    )
E4     1        s     u  ==    (
F4     1        s n   u  ]]    )
measure 79
E4     1        s     u  [[    (
F4     1        s     u  ==    )
A4     1        s     u  ==    (
F4     1        s     u  ==    )
D#4    1        s #   u  ==    (
E4     1        s     u  ]]    )
C#4    1        s #   u  [[    (
D4     1        s n   u  ==    )
E4     1        s     u  ==    (
F4     1        s     u  ==    )
G4     1        s     u  ==    (
A4     1        s     u  ]]    )
measure 80
C4     4        q n   u        (+
E4     1        s     u  [[
D4     1        s     u  ]]    )
C4     2        e     u
rest   2        e
F#5    1        s #   d  [[    (f
P    C33:Y63
G5     1        s     d  ]]    )
measure 81
A5     1        s     d  [[    (
G5     1        s     d  ==
F5     1        s n   d  ==    )+
E5     1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ]]     .
B4     1        s     u  [[    (
A4     1        s     u  ==
G4     1        s     u  ==    )
F4     1        s     u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
measure 82
C4     2        e     u  [      .
E4     2        e     u  =      .
G4     2        e     u  ]      .
C5     2        e     d  [      .
E5     2        e     d  =      .
F#5    1        s #   d  =[    (
G5     1        s     d  ]]    )
measure 83
A5     1        s     d  [[    (
G5     1        s     d  ==
F5     1        s n   d  ==    )+
E5     1        s     d  ==     .
D5     1        s     d  ==     .
C5     1        s     d  ]]     .
B4     1        s     u  [[    (
A4     1        s     u  ==
G4     1        s     u  ==    )
F4     1        s     u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
measure 84
C4     2        e     u  [      .
E4     2        e     u  =      .
G4     2        e     u  ]      .
C5     2        e     d  [      .
E5     2        e     d  =      .
G5     1        s     d  =[    (
A5     1        s     d  ]]    )
measure 85
Bf5    1        s f   d  [[    (
A5     1        s     d  ==
G5     1        s     d  ==    )
F5     1        s     d  ==     .
E5     1        s     d  ==     .
D5     1        s     d  ]]     .
C5     1        s     u  [[    (
Bf4    1        s f   u  ==
A4     1        s     u  ==    )
G4     1        s     u  ==     .
F4     1        s     u  ==     .
E4     1        s     u  ]]     .
measure 86
F4     2        e     u  [      .
A4     2        e     u  =      .
C5     2        e     u  ]      .
F5     2        e     d  [      .
A5     2        e     d  =      .
C6     2        e     d  ]      .
measure 87
C6     2        e     d  [      .
rest   2        e
P    C1:Y-5
C6     2        e     d  ]      .
C6     2        e     d  [      .
rest   2        e
P    C1:Y-5
C6     1        s     d  =[     .
C6     1        s     d  ]]     .
measure 88
C6     2        e     d  [     (
Bf5    2        e f   d  =     )
Bf5    2        e     d  ]      .
Bf5    2        e     d  [     (
G#5    2        e #   d  =
A5     2        e     d  ]     )
measure 89
A5     2        e     d  [     (
G5     2        e n   d  =     )+
G5     2        e     d  ]      .
G5     2        e     d  [     (
E5     2        e     d  =
F5     2        e     d  ]     )
measure 90
F5     1        s     d  [[    (
G5     1        s     d  ==
A5     1        s     d  ==    )
B5     1        s n   d  ==     +.
C6     1        s     d  ==     .
D6     1        s     d  ]]     .
E5     1        s     d  [[    (
F5     1        s     d  ==
G5     1        s     d  ==    )
A5     1        s     d  ==     .
B5     1        s     d  ==     .
C6     1        s     d  ]]     .
measure 91
A4     1        s     d  [[    (
B4     1        s     d  ==
C5     1        s     d  ==    )
D5     1        s     d  ==     .
E5     1        s     d  ==     .
F#5    1        s #   d  ]]     .
G5     2        e     d  [
rest   2        e
P    C1:Y10
G5     1        s     d  =[    (
F5     1        s n   d  ]]    )
measure 92
E5     1        s     d  [[    (
D5     1        s     d  ==
C5     1        s     d  ==    )
B4     1        s     d  ==     .
A4     1        s     d  ==     .
G4     1        s     d  ]]     .
F4     1        s     u  [[    (
E4     1        s     u  ==
D4     1        s     u  ==    )
C4     1        s     u  ==     .
B3     1        s     u  ==     .
A3     1        s     u  ]]     .
measure 93
G3     2        e     u  [      .
B3     2        e     u  =      .
D4     2        e     u  ]      .
F4     2        e     u         .
rest   2        e
G3     1        s     u  [[    (
A3     1        s     u  ]]    )
measure 94
B3     1        s     u  [[    (
C4     1        s     u  ==
D4     1        s     u  ==    )
E4     1        s     u  ==     .
F4     1        s     u  ==     .
G4     1        s     u  ]]     .
F4     1        s     d  [[    (
B4     1        s     d  ==
D5     1        s     d  ==    )
F5     1        s     d  ==     .
A5     1        s     d  ==     .
F5     1        s     d  ]]     .
measure 95
F5     2        e     d  [     (
E5     2        e     d  =     )
B5     2        e     d  ]      .
C6     2        e     d  [      .
rest   2        e
P    C1:Y-5
B5     1        s     d  =[     .
C6     1        s     d  ]]     .
measure 96
B5     1        s     d  [[    (
C6     1        s     d  ==
E6     1        s     d  ==
C6     1        s     d  ==    )
G#5    1        s #   d  ==     .
A5     1        s     d  ]]     .
G#5    1        s     d  [[    (
A5     1        s     d  ==
C6     1        s     d  ==
A5     1        s     d  ==    )
E5     1        s     d  ==     .
F5     1        s     d  ]]     .
measure 97
E5     1        s     d  [[    (
F5     1        s     d  ==
A5     1        s     d  ==
F5     1        s     d  ==    )
C#5    1        s #   d  ==     .
D5     1        s     d  ]]     .
F5     1        s     d  [[    (
E5     1        s     d  ==    )
G5     1        s n   d  ==    (+
F5     1        s     d  ==    )
A5     1        s     d  ==    (
G5     1        s     d  ]]    )
measure 98
Bf5    1        s f   d  [[    (
A5     1        s     d  ==    )
G5     1        s     d  ==    (
F5     1        s     d  ==    )
E5     1        s     d  ==    (
D5     1        s     d  ]]    )
C5     2        e n   d  [     (+
B4     2        e n   d  =     )+
A5     2        e     d  ]      .
measure 99
A5     2        e     d  [      .
rest   2        e
P    C1:Y0
A5     2        e     d  ]      .
A5     2        e     d  [      .
rest   2        e
P    C1:Y0
A5     1        s     d  =[     .
A5     1        s     d  ]]     .
measure 100
A5     2        e     d  [     (
G5     2        e     d  =
F5     2        e     d  ]     )
E5     2        e     d  [     (
D5     2        e     d  =
F5     2        e     d  ]     )
measure 101
C5     4        q     d        (
E5     1        s     d  [[
D5     1        s     d  ]]    )
C5     2        e     d  [      .
rest   2        e
A4     2        e     d  ]      .mf
P    C34:Y72
measure 102
A4     2        e     u  [      .
rest   2        e
A4     2        e     u  ]      .
A4     2        e     u  [      .
rest   2        e
A4     1        s     u  =[     .
A4     1        s     u  ]]     .
measure 103
A4     2        e     u  [     (
G4     2        e     u  =
F4     2        e     u  ]     )
E4     2        e     u  [     (
D4     2        e     u  =
F4     2        e     u  ]     )
measure 104
C4     4        q     u        (
E4     1        s     u  [[
D4     1        s     u  ]]    )
C4     2        e     u  [      .
rest   2        e
C5     2        e     u  ]      .p
P    C34:Y57
measure 105
C5     2        e     d  [      .
rest   2        e
C5     2        e     d  ]      .
C5     2        e     d  [      .
rest   2        e
C5     1        s     d  =[     .
C5     1        s     d  ]]     .
measure 106
C5     2        e     d  [      .
B4     2        e     d  =      .
A4     2        e     d  ]      .
G4     2        e     u  [      .
rest   2        e
E4     2        e     u  ]      .
measure 107
E4     2        e     u  [      .
rest   2        e
P    C1:Y30
F4     2        e     u  ]      .
F4     2        e     u  [      .
rest   2        e
F4     1        s     u  =[     .
F4     1        s     u  ]]     .
measure 108
F4     2        e     u  [      .
E4     2        e     u  =      .
D4     2        e     u  ]      .
C4     2        e     u         .
rest   2        e
rest   2        e
measure 109
D4     1        s     u  [[    (pp
P    C33:Y79
C#4    1        s #   u  ==
D4     1        s     u  ==    )
F4     1        s     u  ==     .
E4     1        s     u  ==     .
D4     1        s     u  ]]     .
C4     2        e n   u         .
rest   2        e
rest   2        e
measure 110
B3     6        q.    u        (
C4     2        e     u        )
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/04/02} [KHM:2799591906]
TIMESTAMP: DEC/26/2001 [md5sum:f8a63c7adcf9eb9bfa6d3e96621e2fea]
11/13/94 W Hewlett
WK#:64,1      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Finale [Fourth Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:6/8  C:4  D:Presto
E4     2        e     u
measure 1
E4     2        e     u
rest   2        e
F4     2        e     u
G4     2        e     u
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 2
G4     2        e     u  [
F4     2        e     u  =
E4     2        e     u  ]
D4     2        e     u
rest   2        e
D4     2        e     u
measure 3
D4     4        q     u
C4     2        e     u
A3     6        q.    u
measure 4
G3     2        e     u
rest   2        e
rest   2        e
rest   4        q
E4     2        e     u
measure 5
E4     2        e     u
rest   2        e
F4     2        e     u
G4     2        e     u
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 6
G4     2        e     u  [
F4     2        e     u  =
E4     2        e     u  ]
D4     2        e     u
rest   2        e
D4     2        e     u
measure 7
D4     4        q     u
C4     2        e     u
C4     6        q.    u
measure 8
C4     4        q     u
B3     2        e     u
C4     2        e     u  [
E4     2        e     u  =
E4     2        e     u  ]
measure 9
F4    12        h.    u
 G3   12        h.    u
measure 10
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
measure 11
F4    12        h.    u
 G3   12        h.    u
measure 12
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
measure 13
A4     6        q.    u
 E4    6        q.    u
A4     6        q.    u
 D4    6        q.    u
measure 14
B4     4        q     u
 G4    4        q     u
rest   2        e
rest   4        q
A4     1        s     u  [[
B4     1        s     u  ]]
measure 15
C5     1        s     d  [[
B4     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     1        s     u  [[
F#4    1        s #   u  ==
E4     1        s     u  ==
D4     1        s     u  ==
C4     1        s     u  ==
B3     1        s     u  ]]
measure 16
G4     6        q.    u
F#4    6        q.#   u
measure 17
E4     6        q.    u
D4     4        q     u
D5     1        s     d  [[
B4     1        s     d  ]]
measure 18
A4     6-       q.    u        -
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
measure 19
A4     6-       q.    u        -
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
measure 20
Bf4    6-       q.f   d        -
Bf4    2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  ]
measure 21
A4     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ]]
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
measure 22
C5     2        e     d
rest   2        e
rest   2        e
rest   4        q
D4     2        e     u
measure 23
D4     2        e     u
rest   2        e
D4     2        e     u
D4     2        e     u
rest   2        e
D4     1        s     u  [[
D4     1        s     u  ]]
measure 24
D4     2        e     u
rest   2        e
D4     2        e     u
D4     1        s     u  [[
F#4    1        s #   u  ==
A4     1        s     u  ==
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 25
F#4    2        e #   u
rest   2        e
F#4    2        e     u
 A3    2        e     u
F#4    2        e     u
 A3    2        e     u
rest   2        e
F#4    1        s     u  [[
 A3    1        s     u
F#4    1        s     u  ]]
 A3    1        s     u
measure 26
G4     2        e     u
 G3    2        e     u
rest   2        e
rest   2        e
rest   4        q
rest   2        e
measure 27
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
B4     2        e     d  [
B4     2        e     d  ]
rest   2        e
measure 28
G4     2        e     u  [
G4     2        e     u  ]
rest   2        e
rest   4        q
rest   2        e
measure 29
rest   4        q
rest   2        e
A3     4        q     u
rest   2        e
measure 30
D4     4        q     u
C4     2        e     u
B3     2        e     u
rest   2        e
rest   2        e
measure 31
rest  12
measure 32
rest   4        q
rest   2        e
rest   4        q
D4     2        e     u
measure 33
E4     2        e     d  [
E5     2        e     d  =
E5     2        e     d  ]
E5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
measure 34
G4     3        e.    u  [
A4     1        s     u  =\
F#4    2        e #   u  ]
G4     2        e     u
rest   2        e
D4     2        e     u
measure 35
D4     2        e     u  [
G4     2        e     u  =
B4     2        e     u  ]
E4     2        e     u  [
A4     2        e     u  =
C5     2        e     u  ]
measure 36
F#4    2        e #   u  [
A4     2        e     u  =
D5     2        e     u  ]
D5     2        e     d  [
C5     1        s     d  =[
B4     1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ]]
measure 37
E4     2        e     d  [
E5     2        e     d  =
E5     2        e     d  ]
E5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
measure 38
G4     3        e.    u  [
A4     1        s     u  =\
F#4    2        e #   u  ]
G4     2        e     u
rest   2        e
B4     2        e     d
measure 39
C5     2        e     d
rest   2        e
C#5    2        e #   d
D5     2        e     d
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 40
F5     2        e     d  [
F5     2        e     d  =
F5     2        e     d  ]
F5     2        e     d
rest   2        e
mheavy2                      :|
F5     2        e     d
 D5    2        e     d
measure 41
F5     2        e     d  [
 D5    2        e     d
F5     2        e     d  =
 D5    2        e     d
F5     2        e     d  ]
 D5    2        e     d
F5     2        e     d
 D5    2        e     d
rest   2        e
rest   2        e
measure 42
rest  12
measure 43
rest  12
measure 44
rest  12
measure 45
rest   4        q
rest   2        e
rest   4        q
D4     2        e     u
measure 46
D4     2        e     u
rest   2        e
D4     2        e     u
D4     2        e     u
rest   2        e
D4     1        s     u  [[
D4     1        s     u  ]]
measure 47
D4     2        e     u  [
C#4    2        e #   u  =
D4     2        e     u  ]
E4     2        e     u
rest   2        e
E4     1        s     u  [[
E4     1        s     u  ]]
measure 48
E4     2        e     u  [
D4     2        e     u  =
C4     2        e     u  ]
B3     4        q     u
A3     2        e     u
measure 49
G#3    6        q.#   u
A3     4        q     u
rest   2        e
measure 50
rest   4        q
C5     1        s     d  [[
C5     1        s     d  ]]
C5     2        e     d  [
B4     2        e     d  =
A4     2        e     d  ]
measure 51
G4    12        h.    u
measure 52
C4     4        q     u
rest   2        e
rest   4        q
G5     2        e     d
measure 53
G5     2        e     d
rest   2        e
G5     2        e     d
G5     2        e     d
rest   2        e
G5     1        s     d  [[
G5     1        s     d  ]]
measure 54
G5     2        e     d  [
F5     2        e     d  =
E5     2        e     d  ]
D5     2        e     d
rest   2        e
Bf5    1        s f   d  [[
Bf5    1        s     d  ]]
measure 55
Bf5    2        e f   d  [
A5     2        e     d  =
G5     2        e     d  ]
A5     2        e     d  [
F5     2        e     d  =
E5     1        s     d  =[
D5     1        s     d  ]]
measure 56
E5     2        e     u  [
D#4    1        s #   u  =[
E4     1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
rest   2        e
D#4    1        s     u  [[
E4     1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
measure 57
rest  12
measure 58
rest   2        e
E4     1        s     u  [[
F4     1        s     u  ==
A4     1        s     u  ==
F4     1        s     u  ]]
rest   2        e
E4     1        s     u  [[
F4     1        s     u  ==
A4     1        s     u  ==
F4     1        s     u  ]]
measure 59
rest   4        q
rest   2        e
rest   4        q
C5     2        e     d
measure 60
C5     2        e     d
rest   2        e
C5     2        e     d
C5     2        e     d
rest   2        e
C5     1        s     d  [[
C5     1        s     d  ]]
measure 61
C5     2        e     d  [
B4     2        e     d  =
A4     2        e     d  ]
G#4    2        e #   u
rest   2        e
D5     2        e     d
measure 62
D5     2        e     d
rest   2        e
D5     2        e     d
D5     2        e     d
rest   2        e
rest   2        e
measure 63
D5     2        e     d
rest   2        e
D5     2        e     d
D5     2        e     d
rest   2        e
D5     2        e     d
measure 64
D5     2        e     d
rest   2        e
D5     2        e     d
D5     2        e     d
rest   2        e
rest   2        e
measure 65
D5     2        e     d
rest   2        e
D5     2        e     d
D5     2        e     d
rest   2        e
G#4    1        s #   u  [[
A4     1        s     u  ]]
measure 66
G#4    1        s #   u  [[
A4     1        s     u  ==
C5     1        s     u  ==
A4     1        s     u  ==
E4     1        s     u  ==
F4     1        s     u  ]]
E4     1        s     u  [[
F4     1        s     u  ==
A4     1        s     u  ==
F4     1        s     u  ==
C#5    1        s #   u  ==
D5     1        s     u  ]]
measure 67
C#5    1        s #   d  [[
D5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ==
A#4    1        s #   d  ==
B4     1        s     d  ]]
A#4    1        s     d  [[
B4     1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ==
G#4    1        s #   d  ==
A4     1        s n   d  ]]
measure 68
G#4    1        s #   u  [[
A4     1        s     u  ==
C5     1        s     u  ==
A4     1        s     u  ==
E4     1        s     u  ==
C4     1        s     u  ]]
F4     1        s     u  [[
D4     1        s     u  ==
E4     1        s     u  ==
C4     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ]]
measure 69
A3    12        h.    u
measure 70
G3     2        e     u
rest   2        e
G3     2        e     u
G3     2        e     u
rest   2        e
G3     1        s     u  [[
G3     1        s     u  ]]
measure 71
G3     2        e     u  [
A3     2        e     u  =
Bf3    2        e f   u  ]
A3     2        e     u  [
C#4    2        e #   u  =
D4     2        e     u  ]
measure 72
C4     6        q.    u
B3     2        e     u
rest   2        e
E4     2        e     u
measure 73
E4     2        e     u
rest   2        e
F4     2        e     u
G4     2        e     u
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 74
G4     2        e     u  [
F4     2        e     u  =
E4     2        e     u  ]
D4     2        e     u
rest   2        e
D4     2        e     u
measure 75
D4     4        q     u
C4     2        e     u
A3     6        q.    u
measure 76
G3     2        e     u
rest   2        e
rest   2        e
rest   4        q
E4     2        e     u
measure 77
E4     2        e     u
rest   2        e
F4     2        e     u
G4     2        e     u
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 78
G4     2        e     u  [
F4     2        e     u  =
E4     2        e     u  ]
D4     2        e     u
rest   2        e
D4     2        e     u
measure 79
D4     4        q     u
C4     2        e     u
C4     6        q.    u
measure 80
C4     4        q     u
B3     2        e     u
C4     2        e     u  [
E4     2        e     u  =
E4     2        e     u  ]
measure 81
F4    12        h.    u
 G3   12        h.    u
measure 82
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
measure 83
F4    12        h.    u
 G3   12        h.    u
measure 84
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 G3    2        e     u
E4     2        e     u
 G3    2        e     u
rest   2        e
E4     2        e     u
 Bf3   2        e f   u
measure 85
E4    12        h.f   u
 Bf3  12        h.    u
measure 86
F4     2        e     u
 A3    2        e     u
rest   2        e
rest   2        e
rest   4        q
G4     1        s     u  [[
A4     1        s     u  ]]
measure 87
Bf4    1        s f   u  [[
A4     1        s     u  ==
C5     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F4     1        s     u  [[
E4     1        s     u  ==
D4     1        s     u  ==
C4     1        s     u  ==
Bf3    1        s f   u  ==
A3     1        s     u  ]]
measure 88
F4     6        q.    u
E4     6        q.    u
measure 89
D4     6        q.    u
C4     2        e     u
rest   2        e
rest   2        e
measure 90
D4     6        q.    u
 B3    6        q.    u
E4     6        q.    u
 C4    6        q.    u
measure 91
F#4    4        q #   u
 A3    4        q     u
A4     2        e     u
G4     2        e     u
rest   2        e
E4     2        e     u
measure 92
E4     2        e     u
rest   2        e
E4     2        e     u
E4     2        e     u
rest   2        e
E4     1        s     u  [[
E4     1        s     u  ]]
measure 93
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
E4     1        s     u  ==
D4     1        s     u  ==
C4     1        s     u  ]]
B3     2        e     u
rest   2        e
B3     1        s     u  [[
C4     1        s     u  ]]
measure 94
D4     2        e     u
rest   2        e
D4     2        e     u
D4     2        e     u
rest   2        e
B3     1        s     u  [[
B3     1        s     u  ]]
measure 95
C4     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 96
G5     2        e     d  [
G5     2        e     d  ]
rest   2        e
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
measure 97
C5     2        e     d  [
C5     2        e     d  ]
rest   2        e
rest   4        q
rest   2        e
measure 98
rest   4        q
rest   2        e
rest   4        q
F5     2        e     d
measure 99
F5     2        e     d
rest   2        e
F5     2        e     d
F5     2        e     d
rest   2        e
F5     1        s     d  [[
F5     1        s     d  ]]
measure 100
F5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  ]
C5     2        e     u  [
A4     2        e     u  =
A4     1        s     u  =[
F4     1        s     u  ]]
measure 101
E4     4        q     u
F4     2        e     u
E4     2        e     u
rest   2        e
F4     2        e     u
measure 102
F4     2        e     u
rest   2        e
F4     2        e     u
F4     2        e     u
rest   2        e
F4     1        s     u  [[
F4     1        s     u  ]]
measure 103
F4     2        e     u  [
E4     2        e     u  =
D4     2        e     u  ]
C4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  ]
measure 104
C4     4        q     u
B3     2        e     u
C4     2        e     u
rest   2        e
E4     2        e     u
measure 105
E4     2        e     u
rest   2        e
F4     2        e     u
F4     2        e     u
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 106
A4     2        e     u  [
G4     2        e     u  =
F4     2        e     u  ]
E4     2        e     u
rest   2        e
Bf3    2        e f   u
measure 107
Bf3    2        e f   u
rest   2        e
A3     2        e     u
A3     2        e     u
rest   2        e
B3     1        s n   u  [[
B3     1        s     u  ]]
measure 108
B3     6        q.    u
C4     2        e     u
rest   2        e
rest   2        e
measure 109
B3     6        q.    u
C4     2        e     u
rest   2        e
rest   2        e
measure 110
D4     6        q.    u
E4     2        e     u
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/04/03} [KHM:2799591906]
TIMESTAMP: DEC/26/2001 [md5sum:19966ddacdf2d64ebb41638dfe314dbf]
11/13/94 W Hewlett
WK#:64,1      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Finale [Fourth Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:6/8  C:13  D:Presto
C4     2        e     d
measure 1
C4     2        e     d
rest   2        e
D4     2        e     d
E4     2        e     d
rest   2        e
F4     1        s     d  [[
F4     1        s     d  ]]
measure 2
E4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     u
rest   2        e
B3     2        e     u
measure 3
B3     4        q     u
C4     2        e     d
A3     2        e     u  [
D3     2        e     u  =
F3     2        e     u  ]
measure 4
E3     6        q.    u
D3     2        e     u
rest   2        e
C4     2        e     d
measure 5
C4     2        e     d
rest   2        e
D4     2        e     d
E4     2        e     d
rest   2        e
F4     1        s     d  [[
F4     1        s     d  ]]
measure 6
E4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     u
rest   2        e
B3     2        e     u
measure 7
B3     4        q     u
C4     2        e     d
A3     2        e     u  [
D3     2        e     u  =
F3     2        e     u  ]
measure 8
E3     4        q     u
F3     2        e     u
E3     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
measure 9
D4    12        h.    d
 B3   12        h.    d
measure 10
E4     2        e     d
 C4    2        e     d
rest   2        e
C4     2        e     d
C4     2        e     d
rest   2        e
E4     2        e     d
measure 11
D4    12        h.    d
 B3   12        h.    d
measure 12
E4     2        e     d
 C4    2        e     d
rest   2        e
C4     2        e     d
C4     2        e     d
rest   2        e
rest   2        e
measure 13
E4     6        q.    d
F#4    6        q.#   d
measure 14
G4     4        q     d
rest   2        e
rest   4        q
F#4    1        s #   d  [[
G4     1        s     d  ]]
measure 15
A4     1        s     d  [[
G4     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s #   d  ]]
E4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
B3     1        s     u  ==
A3     1        s     u  ==
G3     1        s     u  ]]
measure 16
E4     6        q.    d
D4     2        e     d
rest   2        e
rest   2        e
measure 17
C4     6        q.    d
B3     2        e     u
rest   2        e
rest   2        e
measure 18
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
E4     1        s     d  [[
D#4    1        s #   d  ==
F#4    1        s #   d  ==
E4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s     d  ]]
measure 19
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
E4     1        s     d  [[
D#4    1        s #   d  ==
F#4    1        s #   d  ==
E4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s     d  ]]
measure 20
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
E4     1        s     d  [[
D#4    1        s #   d  ==
F#4    1        s #   d  ==
E4     1        s     d  ==
G4     1        s     d  ==
E4     1        s     d  ]]
measure 21
F#4    1        s #   d  [[
G4     1        s     d  ==
A4     1        s     d  ==
G#4    1        s #   d  ==
A4     1        s     d  ==
G#4    1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 22
A4     2        e     d
rest   2        e
rest   2        e
rest   4        q
B3     2        e     u
measure 23
B3     2        e     u
rest   2        e
B3     2        e     u
B3     2        e     u
rest   2        e
B3     1        s     u  [[
B3     1        s     u  ]]
measure 24
C4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
B3     1        s     u  ==
A3     1        s     u  ==
G3     1        s     u  ]]
F#3    2        e #   u
rest   2        e
D4     2        e     d
measure 25
D4     2        e     d
rest   2        e
C4     2        e     d
C4     2        e     d
rest   2        e
C4     1        s     u  [[
A3     1        s     u  ]]
measure 26
G3     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 27
B4     2        e     d  [
B4     2        e     d  ]
rest   2        e
G4     2        e     d  [
G4     2        e     d  ]
rest   2        e
measure 28
E4     2        e     d  [
E4     2        e     d  ]
rest   2        e
rest   4        q
rest   2        e
measure 29
rest   4        q
rest   2        e
E3     2        e     u  [
G#3    2        e #   u  =
A3     2        e     u  ]
measure 30
B3     2        e     u  [
G3     2        e     u  =
F#3    2        e #   u  ]
G3     2        e     u
rest   2        e
rest   2        e
measure 31
rest   2        e
B3     2        e     u  [
G3     2        e     u  ]
rest   2        e
C4     2        e     u  [
A3     2        e     u  ]
measure 32
rest   2        e
F#4    2        e #   d  [
C5     2        e     d  ]
B4     2        e     d
rest   2        e
rest   2        e
measure 33
rest  12
measure 34
rest   2        e
D4     2        e     d  [
C4     2        e     d  ]
B3     2        e     d  [
B4     2        e     d  ]
rest   2        e
measure 35
rest   2        e
B3     2        e     u  [
G3     2        e     u  ]
rest   2        e
C4     2        e     u  [
A3     2        e     u  ]
measure 36
rest   2        e
F#4    2        e #   d  [
C5     2        e     d  ]
B4     2        e     d
rest   2        e
rest   2        e
measure 37
rest  12
measure 38
rest   2        e
D4     2        e     d  [
C4     2        e     d  ]
B3     2        e     u
rest   2        e
G4     2        e     d
measure 39
A4     2        e     d
rest   2        e
A#4    2        e #   d
B4     2        e     d
rest   2        e
C#5    2        e #   d
measure 40
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  ]
D5     2        e     d
rest   2        e
mheavy2                      :|
B4     2        e     d
measure 41
B4     2        e     d  [
B4     2        e     d  =
B4     2        e     d  ]
B4     2        e     d
rest   2        e
rest   2        e
measure 42
rest  12
measure 43
rest   4        q
Ef3    2        e f   u
Ef3    2        e     u
rest   2        e
Ef3    2        e     u
measure 44
Ef3    2        e f   u
rest   2        e
Ef3    1        s     u  [[
Ef3    1        s     u  ]]
Ef3    2        e     u  [
D3     2        e     u  =
E3     2        e n   u  ]
measure 45
F3     2        e     u
rest   2        e
F3     1        s     u  [[
F3     1        s     u  ]]
F3     2        e     u  [
E3     2        e     u  =
F#3    2        e #   u  ]
measure 46
G3     2        e     u
rest   2        e
C4     1        s     d  [[
C4     1        s     d  ]]
C4     2        e     u  [
Bf3    2        e f   u  =
A3     2        e     u  ]
measure 47
G3     4        q     u
F3     2        e     u
E3     2        e     u  [
A3     2        e     u  =
G3     2        e     u  ]
measure 48
G3     2        e     u  [
F3     2        e     u  =
E4     2        e     u  ]
D4     4        q     d
C4     2        e     d
measure 49
B3     6        q.    u
C4     4        q     d
B3     1        s     u  [[
A3     1        s     u  ]]
measure 50
G3     2        e     u  [
F3     2        e     u  =
E3     2        e     u  ]
D3     2        e     u
rest   2        e
G3     1        s     u  [[
A3     1        s     u  ]]
measure 51
B3     2        e     u  [
A3     2        e     u  =
B3     2        e     u  ]
C4     2        e     u  [
B3     2        e     u  =
Bf3    2        e f   u  ]
measure 52
A3     1        s     u  [[
Bf3    1        s f   u  ==
C4     1        s     u  ==
A3     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
D4     1        s     d  [[
C4     1        s     d  ==
D4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ]]
measure 53
G3     4        q     u
rest   2        e
rest   2        e
C4     2        e     d  [
E4     2        e     d  ]
measure 54
D4     2        e     d
rest   1        s
F4     1        s     d  [[
G4     1        s     d  ==
A4     1        s     d  ]]
Bf4    1        s f   d  [[
A4     1        s     d  ==
Bf4    1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 55
G4     2        e     d  [
A4     2        e     d  =
Bf4    2        e f   d  ]
A4     4        q     d
B4     2        e n   d
measure 56
C5     2        e     d
rest   2        e
E4     2        e     d
E4     2        e     d
rest   2        e
E4     1        s     d  [[
E4     1        s     d  ]]
measure 57
E4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     u
rest   2        e
F4     2        e     d
measure 58
F4     2        e     d
rest   2        e
F4     2        e     d
F4     2        e     d
rest   2        e
F4     1        s     d  [[
F4     1        s     d  ]]
measure 59
F4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  ]
C4     2        e     d
rest   2        e
A4     2        e     d
measure 60
A4     2        e     d
rest   2        e
A4     2        e     d
A4     2        e     d
rest   2        e
A3     1        s     u  [[
A3     1        s     u  ]]
measure 61
A3     1        s     u  [[
G#3    1        s #   u  ==
A3     1        s     u  ==
B3     1        s     u  ==
C4     1        s     u  ==
A3     1        s     u  ]]
B3     4        q     u
A#3    1        s #   u  [[
B3     1        s     u  ]]
measure 62
A#3    1        s #   u  [[
B3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ==
A#3    1        s     u  ==
B3     1        s     u  ]]
A#3    1        s     u  [[
B3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ]]
rest   2        e
measure 63
B4     2        e     d
 G#4   2        e #   d
rest   2        e
B4     2        e     d
 G#4   2        e     d
B4     2        e     d
 G#4   2        e     d
rest   2        e
A#3    1        s #   u  [[
B3     1        s     u  ]]
measure 64
A#3    1        s #   u  [[
B3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ==
A#3    1        s     u  ==
B3     1        s     u  ]]
A#3    1        s     u  [[
B3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ]]
rest   2        e
measure 65
B4     2        e #   d
 G#4   2        e     d
rest   2        e
B4     2        e     d
 G#4   2        e     d
B4     2        e     d
 G#4   2        e     d
rest   2        e
rest   2        e
measure 66
rest   4        q
rest   2        e
rest   4        q
C#4    1        s #   d  [[
D4     1        s     d  ]]
measure 67
C#4    1        s #   d  [[
D4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ==
A#3    1        s #   d  ==
B3     1        s     d  ]]
A#3    1        s     u  [[
B3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ==
G#3    1        s #   u  ==
A3     1        s n   u  ]]
measure 68
G#3    1        s #   u  [[
A3     1        s     u  ==
C4     1        s     u  ==
A3     1        s     u  ==
E4     1        s     u  ==
C4     1        s     u  ]]
F4     1        s     d  [[
D4     1        s     d  ==
E4     1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ==
B3     1        s     d  ]]
measure 69
A3    12        h.    u
measure 70
C3     2        e     u
rest   2        e
C3     2        e     u
C3     2        e     u
rest   2        e
C3     1        s     u  [[
C3     1        s     u  ]]
measure 71
C3     4        q     u
G3     2        e     u
A3     2        e     u  [
G3     2        e     u  =
F3     2        e     u  ]
measure 72
G3     6-       q.    u        -
G3     2        e     u
rest   2        e
C4     2        e     d
measure 73
C4     2        e     d
rest   2        e
D4     2        e     d
E4     2        e     d
rest   2        e
F4     1        s     d  [[
F4     1        s     d  ]]
measure 74
E4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     u
rest   2        e
B3     2        e     u
measure 75
B3     4        q     u
C4     2        e     d
A3     2        e     u  [
D3     2        e     u  =
F3     2        e     u  ]
measure 76
E3     6        q.    u
D3     2        e     u
rest   2        e
C4     2        e     d
measure 77
C4     2        e     d
rest   2        e
D4     2        e     d
E4     2        e     d
rest   2        e
F4     1        s     d  [[
F4     1        s     d  ]]
measure 78
E4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     u
rest   2        e
B3     2        e     u
measure 79
B3     4        q     u
C4     2        e     d
A3     2        e     u  [
D3     2        e     u  =
F3     2        e     u  ]
measure 80
E3     4        q     u
F3     2        e     u
E3     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
measure 81
D4    12        h.    d
 B3   12        h.    d
measure 82
E4     2        e     d
 C4    2        e     d
rest   2        e
C4     2        e     d
C4     2        e     d
rest   2        e
E4     2        e     d
measure 83
D4    12        h.    d
 B3   12        h.    d
measure 84
E4     2        e     d
 C4    2        e     d
rest   2        e
E4     2        e     d
E4     2        e     d
rest   2        e
E4     2        e     d
measure 85
G4    12        h.    d
measure 86
A4     2        e     d
rest   2        e
rest   2        e
rest   4        q
E4     1        s     d  [[
F4     1        s     d  ]]
measure 87
G4     1        s     d  [[
F4     1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
E4     1        s     d  ]]
D4     1        s     u  [[
C4     1        s     u  ==
Bf3    1        s f   u  ==
A3     1        s     u  ==
G3     1        s     u  ==
F3     1        s     u  ]]
measure 88
D4     6        q.    d
C4     2        e     d
rest   2        e
rest   2        e
measure 89
Bf3    6        q.f   u
A3     2        e     u
rest   2        e
rest   2        e
measure 90
F4     4        q     d
D4     2        e     d
E4     6        q.    d
measure 91
C4     6        q.    d
B3     2        e     u
rest   2        e
G3     2        e     u
measure 92
G3     2        e     u
rest   2        e
G3     2        e     u
G3     2        e     u
rest   2        e
G3     1        s     u  [[
G3     1        s     u  ]]
measure 93
G3     2        e     u
rest   2        e
G3     2        e     u
G3     1        s     d  [[
B3     1        s     d  ==
D4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
measure 94
B3     2        e     u
rest   2        e
B3     2        e     u
B3     2        e     u
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 95
C4     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 96
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
C5     2        e     d  [
C5     2        e     d  ]
rest   2        e
measure 97
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
C#4    2        e #   d  [
D4     2        e     d  =
E4     2        e     d  ]
measure 98
F4     2        e     d
rest   2        e
F4     2        e     d
E4     2        e     d  [
D4     2        e     d  =
C#4    1        s #   d  =[
D4     1        s     d  ]]
measure 99
C#4    1        s #   d  [[
D4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ==
C#4    1        s     d  ==
D4     1        s     d  ]]
C#4    1        s     d  [[
D4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ==
C#4    1        s     d  ==
D4     1        s     d  ]]
measure 100
D4     1        s     d  [[
E4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ==
B4     1        s     d  ]]
C5     2        e     d
rest   2        e
D4     2        e     d
measure 101
C4     4        q     d
B3     2        e     u
C4     2        e     d
rest   2        e
C#3    1        s #   u  [[
D3     1        s     u  ]]
measure 102
C#3    1        s #   u  [[
D3     1        s     u  ==
F3     1        s     u  ==
D3     1        s     u  ==
C#3    1        s     u  ==
D3     1        s     u  ]]
C#3    1        s     u  [[
D3     1        s     u  ==
F3     1        s     u  ==
D3     1        s     u  ==
C#3    1        s     u  ==
D3     1        s     u  ]]
measure 103
D3     1        s     u  [[
E3     1        s     u  ==
F3     1        s     u  ==
G3     1        s     u  ==
A3     1        s     u  ==
B3     1        s     u  ]]
C4     2        e     d
rest   2        e
A3     2        e     u
measure 104
E3     4        q     u
F3     2        e     u
E3     2        e     u
rest   2        e
Bf3    2        e f   u
measure 105
Bf3    2        e f   u
rest   2        e
A3     2        e     u
A3     2        e     u
rest   2        e
F3     1        s     u  [[
F3     1        s     u  ]]
measure 106
F3     1        s     u  [[
E3     1        s     u  ==
F3     1        s     u  ==
G3     1        s     u  ==
A3     1        s     u  ==
B3     1        s     u  ]]
C4     2        e     d
rest   2        e
G3     2        e     u
measure 107
G3     2        e     u
rest   2        e
F3     2        e     u
F3     2        e     u
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
measure 108
D3     1        s     u  [[
C#3    1        s #   u  ==
D3     1        s     u  ==
E3     1        s     u  ==
F3     1        s     u  ==
G3     1        s     u  ]]
E3     2        e     u
rest   2        e
rest   2        e
measure 109
F3     6        q.    u
E3     2        e     u
rest   2        e
rest   2        e
measure 110
F3     1        s     u  [[
E3     1        s     u  ==
F3     1        s     u  ==
A3     1        s     u  ==
G3     1        s     u  ==
F3     1        s     u  ]]
E3     2        e     u
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/04/04} [KHM:2799591906]
TIMESTAMP: DEC/26/2001 [md5sum:db2e69cd3c875ad7a3cc3c900b4d6dac]
11/13/94 W Hewlett
WK#:64,1      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Finale [Fourth Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:6/8  C:22  D:Presto
rest   2        e
measure 1
rest  12
measure 2
rest   4        q
rest   2        e
rest   4        q
G2     2        e     u
measure 3
G2     4        q     u
A2     2        e     u
F2     6        q.    u
measure 4
G2     6-       q.    u        -
G2     2        e     u
rest   2        e
rest   2        e
measure 5
rest  12
measure 6
rest   4        q
rest   2        e
rest   4        q
G2     2        e     u
measure 7
G2     4        q     u
A2     2        e     u
F2     6        q.    u
measure 8
G2     6        q.    u
C2     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
measure 9
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 10
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 11
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 12
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 13
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C3     2        e     u  ]
measure 14
B2     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 15
rest   4        q
rest   2        e
rest   4        q
G2     2        e     u
measure 16
E3     1        s     d  [[
F#3    1        s #   d  ==
G3     1        s     d  ==
A3     1        s     d  ==
B3     1        s     d  ==
C4     1        s     d  ]]
D3     2        e     d  [
C#4    2        e #   d  =
D4     2        e     d  ]
measure 17
C3     1        s     d  [[
D3     1        s     d  ==
E3     1        s     d  ==
F#3    1        s #   d  ==
G3     1        s     d  ==
A3     1        s     d  ]]
B2     2        e     d  [
A#3    2        e #   d  =
B3     2        e     d  ]
measure 18
C4     6-       q.    d        -
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 19
C#4    6-       q.#   d        -
C#4    2        e     d  [
C#4    2        e     d  =
C#4    2        e     d  ]
measure 20
C#4    6-       q.#   d        -
C#4    2        e     d  [
C#4    2        e     d  =
C#4    2        e     d  ]
measure 21
D4     6        q.    d
D4     1        s     d  [[
Ef4    1        s f   d  ==
D4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]
measure 22
D4     2        e     d
rest   2        e
rest   2        e
rest   4        q
G2     2        e     u
measure 23
G2     2        e     u
rest   2        e
G2     2        e     u
G2     2        e     u
rest   2        e
G2     1        s     u  [[
G2     1        s     u  ]]
measure 24
A2     1        s     u  [[
B2     1        s     u  ==
A2     1        s     u  ==
G2     1        s     u  ==
F#2    1        s #   u  ==
E2     1        s     u  ]]
D2     2        e     u
rest   2        e
D3     2        e     d
measure 25
D3     2        e     d
rest   2        e
D3     2        e     d
D3     2        e     d
rest   2        e
D3     1        s     d  [[
D3     1        s     d  ]]
measure 26
E3     4        q     d
rest   2        e
rest   4        q
rest   2        e
measure 27
rest  12
measure 28
rest   4        q
rest   2        e
G#3    2        e #   d  [
A3     2        e     d  =
B3     2        e     d  ]
measure 29
C4     2        e     d
rest   2        e
rest   2        e
C3     4        q     u
rest   2        e
measure 30
D3     6        q.    d
G2     2        e     u
rest   2        e
rest   2        e
measure 31
B2     4        q     u
rest   2        e
C3     4        q     u
rest   2        e
measure 32
D3     4        q     d
rest   2        e
G2     4        q     u
rest   2        e
measure 33
C3     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 34
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
G2     2        e     u  [
G3     2        e     u  ]
rest   2        e
measure 35
B2     4        q     u
rest   2        e
C3     4        q     u
rest   2        e
measure 36
D3     4        q     d
rest   2        e
G2     4        q     u
rest   2        e
measure 37
C3     4        q     u
rest   2        e
C4     4        q     d
rest   2        e
measure 38
D4     4        q     d
D3     2        e     d
G3     2        e     u  [
G2     2        e     u  ]
rest   2        e
measure 39
rest   2        e
G2     2        e     u
rest   2        e
rest   2        e
G2     2        e     u
rest   2        e
measure 40
G2     1        s     u  [[
B2     1        s     u  ==
D3     1        s     u  ==
C3     1        s     u  ==
B2     1        s     u  ==
A2     1        s     u  ]]
G2     2        e     u
rest   2        e
mheavy2                      :|
rest   2        e
measure 41
rest  12
measure 42
rest   4        q
rest   2        e
rest   4        q
Af2    2        e f   u
measure 43
Af2    2        e f   u
rest   2        e
Af2    2        e     u
Af2    2        e     u
rest   2        e
Af2    1        s     u  [[
Af2    1        s     u  ]]
measure 44
Af2    2        e f   u  [
G2     2        e     u  =
A2     2        e n   u  ]
Bf2    2        e f   u
rest   2        e
Bf2    1        s     u  [[
Bf2    1        s     u  ]]
measure 45
Bf2    2        e f   u  [
A2     2        e     u  =
B2     2        e n   u  ]
C3     2        e     u
rest   2        e
C3     1        s     u  [[
C3     1        s     u  ]]
measure 46
C3     2        e     u  [
Bf2    2        e f   u  =
A2     2        e     u  ]
G2     4        q     u
F2     2        e     u
measure 47
E2     4        q     u
D2     2        e     u
C#2    4        q #   u
C#3    2        e #   u
measure 48
D3     4        q     d
rest   2        e
rest   4        q
F4     1        s     d  [[
F4     1        s     d  ]]
measure 49
F4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  ]
C4     2        e     d  [
A3     2        e     d  =
G3     1        s     d  =[
F3     1        s     d  ]]
measure 50
E3     2        e     d  [
D3     2        e     d  =
C3     2        e     d  ]
G2     4        q     u
rest   2        e
measure 51
rest   4        q
rest   2        e
rest   4        q
C3     1        s     u  [[
C3     1        s     u  ]]
measure 52
F3     1        s     d  [[
G3     1        s     d  ==
A3     1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ]]
Bf3    1        s f   d  [[
A3     1        s     d  ==
Bf3    1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ==
B3     1        s n   d  ]]
measure 53
C4     1        s     d  [[
B3     1        s     d  ==
C4     1        s     d  ==
C3     1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ]]
E4     1        s     d  [[
D4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ==
C#4    1        s #   d  ==
A3     1        s     d  ]]
measure 54
D4     1        s     d  [[
C#4    1        s #   d  ==
D4     1        s     d  ==
D3     1        s     d  ==
E3     1        s     d  ==
F3     1        s     d  ]]
G3     1        s     d  [[
F#3    1        s #   d  ==
G3     1        s     d  ==
G2     1        s     d  ==
A2     1        s     d  ==
Bf2    1        s f   d  ]]
measure 55
C3     1        s     u  [[
B2     1        s     u  ==
C3     1        s     u  ==
C2     1        s     u  ==
E3     1        s     u  ==
C3     1        s     u  ]]
F3     1        s     d  [[
E3     1        s     d  ==
F3     1        s     d  ==
F2     1        s     d  ==
G2     1        s     d  ==
G3     1        s     d  ]]
measure 56
C3     2        e     u
rest   2        e
C4     2        e     d
C4     2        e     d
rest   2        e
C4     1        s     d  [[
C4     1        s     d  ]]
measure 57
C4     2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
G3     2        e     d
rest   2        e
D4     2        e     d
measure 58
D4     2        e     d
rest   2        e
D4     2        e     d
D4     2        e     d
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 59
D4     2        e     d  [
C4     2        e     d  =
B3     2        e     d  ]
A3     2        e     d
rest   2        e
rest   2        e
measure 60
rest   2        e
F3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d  [
F3     2        e     d  ]
measure 61
rest   2        e
F3     1        s     d  [[
F3     1        s     d  =]
F3     2        e     d  ]
E3     6        q.    d
measure 62
E3     6-       q.    d        -
E3     2        e     d
rest   2        e
rest   2        e
measure 63
rest  12
measure 64
E3     6-       q.    d        -
E3     2        e     d
rest   2        e
rest   2        e
measure 65
rest  12
measure 66
rest   4        q
rest   2        e
rest   4        q
C#4    1        s #   d  [[
D4     1        s     d  ]]
measure 67
C#4    1        s #   d  [[
D4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ==
A#3    1        s #   d  ==
B3     1        s     d  ]]
A#3    1        s     d  [[
B3     1        s     d  ==
D4     1        s     d  ==
B3     1        s     d  ==
G#3    1        s #   d  ==
A3     1        s n   d  ]]
measure 68
G#3    1        s #   d  [[
A3     1        s     d  ==
C4     1        s     d  ==
A3     1        s     d  ==
E3     1        s     d  ==
C3     1        s     d  ]]
F3     1        s     d  [[
D3     1        s     d  ==
E3     1        s     d  ==
C3     1        s     d  ==
D3     1        s     d  ==
B2     1        s     d  ]]
measure 69
A2    12        h.    u
measure 70
E2     2        e     u
rest   2        e
E2     2        e     u
E2     2        e     u
rest   2        e
E2     1        s     u  [[
E2     1        s     u  ]]
measure 71
F2     4        q     u
E2     2        e     u
F2     2        e     u  [
E2     2        e     u  =
D2     2        e     u  ]
measure 72
G2     6-       q.    u        -
G2     2        e     u
rest   2        e
rest   2        e
measure 73
rest  12
measure 74
rest   4        q
rest   2        e
rest   4        q
G2     2        e     u
measure 75
G2     4        q     u
A2     2        e     u
F2     6        q.    u
measure 76
G2     6-       q.    u        -
G2     2        e     u
rest   2        e
rest   2        e
measure 77
rest  12
measure 78
rest   4        q
rest   2        e
rest   4        q
G2     2        e     u
measure 79
G2     4        q     u
A2     2        e     u
F2     6        q.    u
measure 80
G2     6        q.    u
C2     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
measure 81
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 82
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 83
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 84
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 85
C2     2        e     u  [
C3     2        e     u  =
C2     2        e     u  ]
C3     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
measure 86
F2     4        q     u
rest   2        e
rest   4        q
rest   2        e
measure 87
rest   4        q
rest   2        e
rest   4        q
F2     2        e     u
measure 88
D3     1        s     d  [[
E3     1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ==
Bf3    1        s f   d  ]]
C3     2        e     d  [
B3     2        e n   d  =
C4     2        e     d  ]
measure 89
Bf2    1        s f   d  [[
C3     1        s     d  ==
D3     1        s     d  ==
E3     1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ]]
A2     2        e     d  [
G#3    2        e #   d  =
A3     2        e     d  ]
measure 90
G2    12-       h.    u        -
measure 91
G2     6-       q.    u        -
G2     2        e     u
rest   2        e
C3     2        e     u
measure 92
C3     2        e     u
rest   2        e
C3     2        e     u
C3     2        e     u
rest   2        e
C3     1        s     u  [[
C3     1        s     u  ]]
measure 93
D3     1        s     u  [[
E3     1        s     u  ==
D3     1        s     u  ==
C3     1        s     u  ==
B2     1        s     u  ==
A2     1        s     u  ]]
G2     2        e     u
rest   2        e
G2     2        e     u
measure 94
G2     2        e     u
rest   2        e
G2     2        e     u
G2     2        e     u
rest   2        e
G2     1        s     u  [[
G2     1        s     u  ]]
measure 95
A2     4        q     u
rest   2        e
A3     4        q     d
rest   2        e
measure 96
rest  12
measure 97
rest  12
measure 98
rest   4        q
F2     2        e     u
G2     4        q     u
G2     2        e     u
measure 99
G2    12-       h.    u        -
measure 100
G2     6        q.    u
A2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 101
G2     6        q.    u
C3     2        e     u
rest   2        e
G2     2        e     u
measure 102
G2    12-       h.    u        -
measure 103
G2     6        q.    u
A2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  ]
measure 104
G2     6        q.    u
C3     2        e     u
rest   2        e
C3     2        e     u
measure 105
C3     2        e     u
rest   2        e
C3     2        e     u
C3     2        e     u
rest   2        e
C3     1        s     u  [[
C3     1        s     u  ]]
measure 106
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
C3     2        e     u
rest   2        e
C2     2        e     u
measure 107
C2     2        e     u
rest   2        e
C2     2        e     u
C2     2        e     u
rest   2        e
C2     1        s     u  [[
C2     1        s     u  ]]
measure 108
C2     2        e     u  [
C2     2        e     u  =
C2     2        e     u  ]
C2     2        e     u
rest   2        e
rest   2        e
measure 109
C2     6-       q.    u        -
C2     2        e     u
rest   2        e
rest   2        e
measure 110
C2     6-       q.    u        -
C2     2        e     u
rest   2        e
mheavy2
/END
/eof
//
