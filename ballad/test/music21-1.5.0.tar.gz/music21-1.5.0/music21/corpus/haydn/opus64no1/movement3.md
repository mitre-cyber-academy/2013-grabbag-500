&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/03/01} [KHM:2963845698]
TIMESTAMP: DEC/26/2001 [md5sum:6513ba031c0c09557236a9b88ea3465c]
11/13/94 W Hewlett
WK#:64,1      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[Third Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-1   Q:24   T:2/4  C:4  D:Allegretto scherzando
*               D       dol.
P  C25:f33
C4    12        e     u
measure 1
F4    12        e     u  [     (
C4     6        s     u  ]\    )
rest   6        s
A4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 2
G4    12        e     d  [     (
C5    12        e     d  =     )
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 3
A4    12        e     d  [     (
D5    12        e     d  ]     )
D5    12        e     d  [
C5     3        t n   d  =[[   (
B4     3        t n   d  ===
A4     3        t     d  ===
B4     3        t     d  ]]]   )
measure 4
B4    24        q n   d        (
C5    12        e     d  [     )
C#5   12        e #   d  ]      .
measure 5
D5    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
C5    12        e n   u  [     (+
F4     6        s     u  ]\    )
rest   6        s
measure 6
E4    12        e     u  [     (
Bf4   12        e f   u  =     )+
Bf4   12        e     u  =      .
A4    12        e     u  ]      .
measure 7
F4    12        e     u  [     (
gG4    4        t     u  [[[
gF4    4        t     u  ===
gE4    4        t     u  ]]]
F4     9        s.    u  =[
G4     3        t     u  ]]\   )
A4    12        e     u  [      .
B4    12        e n   u  ]      .
measure 8
B4    24        q n   d        (
C5    12        e     d        )
mheavy4                    :|:
C5    12        e     d
measure 9
F4    12        e     u  [     (
E4     6        s     u  ]\    )
rest   6        s
G4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 10
Bf4   12        e     d  [      .
Bf4   12        e     d  =      .
Bf4   12        e     d  =      .
G5    12        e     d  ]
measure 11
Bf4   12        e     u  [     (
Af4    6        s f   u  ]\    )
rest   6        s
F5    12        e     d  [     (
Ef5    6        s f   d  ]\    )
rest   6        s
measure 12
D5    12        e     d  [      .
D5    12        e     d  =      .
D5    12        e     d  =      .
gF5    0        e     u        (
Ef5   12        e f   d  ]     )
measure 13
D5    12        e     d  [      .
D5    12        e     d  =      .
D5    12        e     d  ]      .
rest  12        e
measure 14
G4     4        s  6  d  [[     *f.
P    C34:Y86
Bf4    4        s  6  d  ==     .
Df5    4        s f6  d  ==     .
Ef5    4        s f6  d  ==     .
G5     4        s  6  d  ==     .
Bf5    4        s  6  d  ]]     !.
Df6   12        e f   d  [      .
C6    12        e     d  ]      .
measure 15
Bf5   12        e     d         .
rest  12        e
*               D       dim.
P  C25:f33  C17:Y65
G5    12        e     d         .
rest  12        e
measure 16
Af5   12        e f   d
rest  12        e
rest  12        e
C5    12        e     d         p
P    C33:Y64
measure 17
Bf4   12        e f   d  [     (+
Ef5   12        e f   d  ]     )
Ef5   12        e     d
rest  12        e
measure 18
rest  24        q
rest  12        e
Af4   12        e f   u
measure 19
G4    12        e     d  [     (
C5    12        e     d  =     )
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 20
B4    12        e n   d  [     (Z
P    C33:Y73
F5    12        e     d  =     )
F5    12        e     d  =      .
B4    12        e     d  ]     (
measure 21
C5    12        e     d        )
rest  12        e
rest  12        e
*               D       dim.
P  C25:f33  C17:Y75
F4    12        e     u        (
measure 22
E4    12        e     u        )
rest  12        e
rest  12        e
*               D +     dol.
P  C25:f33  C17:Y-10
C4    12        e     u
measure 23
F4    12        e     u  [     (p
P    C33:Y66
C4     6        s     u  ]\    )
rest   6        s
A4    12        e n   u  [     (+
F4     6        s     u  ]\    )
rest   6        s
measure 24
G4    12        e     d  [     (
C5    12        e     d  =     )
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 25
A4    12        e     d  [     (
D5    12        e     d  ]     )
D5    12        e     d  [
C5     3        t n   d  =[[   (
B4     3        t n   d  ===
A4     3        t     d  ===
B4     3        t     d  ]]]   )
measure 26
B4    24        q n   d        (
C5    12        e     d  [     )
C#5   12        e #   d  ]
measure 27
D5    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
C5    12        e n   u  [     (+
F4     6        s     u  ]\    )
rest   6        s
measure 28
E4    12        e     d  [     (
Bf5   12        e     d  =     )
Bf5   12        e     d  =      .
A5    12        e     d  ]      .
measure 29
gA5    0        e     u        (
G5    12        e     d  [     ).
F5    12        e     d  ]      .
G5     3        t     d  [[[   (
F5     3        t     d  ===
E5     3        t     d  ===
F5     3        t     d  ]]]   )
G5     9        s.    d  [[    (
E5     3        t     d  ]]\   )
measure 30
F5    12        e     d
rest  12        e
rest  12        e
F4    12        e     u
measure 31
Bf4   12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
A4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 32
D5    12        e     d  [     (
F5    12        e     d  =     )
F5    12        e     d  =      .
F5    12        e     d  ]      .
measure 33
Bf4   12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
A4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 34
D5    12        e     d  [     (
F5    12        e     d  =     )
F5    12        e     d  =      .
F5    12        e     d  ]      .
measure 35
*               D       cresc.
P  C25:f33  C17:Y63
E5    12        e     d  [     (
Bf5   12        e     d  =     )
Bf5   12        e     d  =      .
A5    12        e     d  ]      .
measure 36
G5    12        e     d  [     (
D6    12        e     d  ]     )
D6     6        s     d         .
rest   6        s               F
A4    12        e     u         p
P    C33:Y57
measure 37
G4    12        e     u  [      .
G4    12        e     u  =      .
G4    12        e     u  =     (
Bf4   12        e     u  ]     )
measure 38
A4    12        e     u  [     (
F4    12        e     u  =     )
F4    12        e     u  =      .
A4    12        e     u  ]      .
measure 39
G4    12        e     u  [      .
G4    12        e     u  =      .
G4    12        e     u  =      .
C5    12        e     u  ]      .
measure 40
A4    12        e     u
rest  12        e
rest  12        e
mheavy4                         :|:
rest  12        e
measure 41
rest  48
measure 42
*               D       sotto voce
P  C25:f33  C17:Y65
C5     6        s     d  [[     .
Df5    6        s f   d  ==     .
D5     6        s n   d  ==     .
Ef5    6        s f   d  ]]     .
E5     6        s n   d  [[     .
F5     6        s     d  ==     .
F#5    6        s #   d  ==     .
G5     6        s     d  ]]     .
measure 43
G#5    6        s #   d  [[    (
A5     6        s     d  ==
G5     6        s n   d  ==
F5     6        s n   d  ]]    )+
E5     6        s     d  [[    (
D5     6        s     d  ==
F5     6        s     d  ==
D5     6        s     d  ]]    )
measure 44
D5    24        q     d        (
C5    12        e     d        )
rest  12        e
measure 45
rest  48
measure 46
rest   6        s
D6     6        s     d  [[     .
C6     6        s     d  ==     .
Bf5    6        s     d  ]]     .
A5     6        s     d  [[     .
G5     6        s     d  ==     .
F5     6        s     d  ==     .
G5     6        s     d  ]]     .
measure 47
A5     6        s     d  [[    (
G#5    6        s #   d  ==
A5     6        s     d  ==
E5     6        s     d  ]]    )
F5     6        s     d  [[    (
D5     6        s     d  ==
B4     6        s n   d  ==
F4     6        s     d  ]]    )
measure 48
F4    24        q     u        (
E4    12        e     u        )
mheavy4                         :|:
rest  12        e
measure 49
rest   6        s
C5     6        s     d  [[    (
Df5    6        s f   d  ==
C5     6        s     d  ]]    )
rest   6        s
E5     6        s     d  [[     .
E5     6        s     d  ==    (
F5     6        s     d  ]]    )
measure 50
rest   6        s
Df6    6        s f   d  [[    (
C6     6        s     d  ==
Bf5    6        s     d  ]]    )
Af5    6        s f   d  [[    (
G5     6        s     d  ==
F5     6        s     d  ==
E5     6        s     d  ]]    )
measure 51
rest   6        s
C5     6        s     d  [[    (
Df5    6        s f   d  ==
C5     6        s     d  ]]    )
rest   6        s
F5     6        s     d         .
rest   6        s
Ef5    6        s f   d         .
measure 52
D5     6        s     d  [[    (
E5     6        s n   d  ==     +
F5     6        s     d  ==
E5     6        s     d  ]]    )
F5    12        e     d
rest  12        e
measure 53
rest   6        s
E5     6        s     d  [[    (
F5     6        s     d  ==
E5     6        s     d  ]]    )
F5    12        e     d  [
Gf5   12        e f   d  ]
measure 54
G5     3        t n   d  [[[   (+
Af5    3        t f   d  ===
Bf5    3        t     d  ===
Af5    3        t     d  ]]]
G5     3        t     d  [[[
Af5    3        t     d  ===
Bf5    3        t     d  ===
C6     3        t     d  ]]]   )
Df6   12        e f   d  [      .
C6    12        e     d  ]      .
measure 55
Bf5   12        e     d         .
rest  12        e
*               D       dim.
P  C25:f33  C17:Y65
G5    12        e     d         .
rest  12        e
measure 56
Af5   12        e f   d
rest  12        e
rest  24        q
measure 57
rest   6        s
*               D       sotto voce
P  C25:f33  C17:Y72
Ef4    6        s f   u  [[     .
G4     6        s     u  ==     .
Bf4    6        s     u  ]]     .
Ef5    6        s f   d  [[     .
G5     6        s     d  ]]     .
rest  12        e
measure 58
rest  48
measure 59
rest   6        s
C4     6        s     u  [[     .
E4     6        s n   u  ==     +.
G4     6        s     u  ]]     .
C5     6        s     d  [[     .
E5     6        s     d  ==     .
G5     6        s     d  ==     .
E5     6        s     d  ]]     .
measure 60
F5    12        e     d  [     (Z
P    C33:Y63
Af5   12        e f   d  ]     )
Af5   12        e     d  [
G5     3        t     d  =[[   (
F5     3        t     d  ===
E5     3        t     d  ===
F5     3        t     d  ]]]   )
measure 61
E5    12        e     d
rest  12        e
rest  24        q
measure 62
rest  48
measure 63
rest  48
measure 64
*               D       sotto voce
P  C25:f33  C17:Y65
C5     6        s     d  [[     .
Df5    6        s f   d  ==     .
D5     6        s n   d  ==     .
Ef5    6        s f   d  ]]     .
E5     6        s n   d  [[     .
F5     6        s     d  ==     .
F#5    6        s #   d  ==     .
G5     6        s     d  ]]     .
measure 65
G#5    6        s #   d  [[    (
A5     6        s     d  ==
G5     6        s n   d  ==
F5     6        s n   d  ]]    )+
E5     6        s     d  [[    (
D5     6        s     d  ==
F5     6        s     d  ==
D5     6        s     d  ]]    )
measure 66
D5    24        q     d        (
C5    12        e     d        )
rest  12        e
measure 67
rest  48
measure 68
rest   6        s
D6     6        s     d  [[    (
C6     6        s     d  ==
Bf5    6        s     d  ]]    )
A5     6        s     d  [[    (
G5     6        s     d  ==
Bf5    6        s     d  ==
A5     6        s     d  ]]    )
measure 69
A5     6        s     d  [[    ([
G5     6        s     d  ==    )
G5     6        s     d  ==    (
F5     6        s     d  ]]    )]
G5     3        t     d  [[[   (
F5     3        t     d  ===
E5     3        t     d  ===
F5     3        t     d  ]]]   )
G5     6        s     d  [[    (
E5     6        s     d  ]]    )
measure 70
F5    12        e     d  [
F6    12        e     d  =      .
F6    12        e     d  =      .
F6    12        e     d  ]      .
measure 71
F6    48-       h     d        -
measure 72
F6    24        q     d
F6     3        t     d  [[[   (
E6     3        t     d  ===
F6     3        t     d  ===
E6     3        t     d  ]]]
F6     3        t     d  [[[
E6     3        t     d  ===
F6     3        t     d  ===
E6     3        t     d  ]]]   )
measure 73
F6    48-       h     d        -
measure 74
F6    24-       q     d        -
F6     6        s     d  [[    (
E6     6        s     d  ==
D6     6        s     d  ==
C6     6        s     d  ]]    )
measure 75
*               E   0
P    C17:Y62
C6    12        e     d  [
Bf5   12-       e     d  ]     -
Bf5    6        s     d  [[    (
A5     6        s     d  ==
G5     6        s     d  ==
*               F   15
F5     6        s     d  ]]    )
measure 76
*               E   15
P    C17:Y63
F5    48        h     d        (
measure 77
*               F   0
E5    24        q     d        )
rest  12        e
F4     6        s     u  [[    (p
P    C33:Y73
A3     6        s     u  ]]    )
measure 78
F4     6        s     u  [[    (
G3     6        s     u  ==    )
F4     6        s     u  ==    (
G3     6        s     u  ]]    )
F4     6        s     u  [[    (
G3     6        s     u  ==    )
E4     6        s     u  ==    (
G3     6        s     u  ]]    )
measure 79
F4    24        q     u
rest  12        e
F4     6        s     u  [[    (
A3     6        s     u  ]]    )
measure 80
F4     6        s     u  [[    (
G3     6        s     u  ==    )
F4     6        s     u  ==    (
G3     6        s     u  ]]    )
F4     6        s     u  [[    (
G3     6        s     u  ==    )
E4     6        s     u  ==    (
G3     6        s     u  ]]    )
measure 81
F4    12        e     u
rest  12        e
rest  12        e
mheavy2                        :|
rest  12        e
measure 82
A3     4        s  3  u  [[    (*f
P    C34:Y101
C4     4        s  3  u  ==
F4     4        s  3  u  ]]    )!
rest  12        e
A4     4        s  3  d  [[    (*
C5     4        s  3  d  ==
F5     4        s  3  d  ]]    )!
rest  12        e
measure 83
C4     4        s  3  u  [[    (*
E4     4        s  3  u  ==
G4     4        s  3  u  ]]    )!
rest  12        e
E5     4        s  3  d  [[    (*
G5     4        s  3  d  ==
C6     4        s  3  d  ]]    )!
rest  12        e
measure 84
C4     4        s  3  u  [[    (*
F4     4        s  3  u  ==
A4     4        s  3  u  ]]    )!
rest  12        e
D5     4        s  3  d  [[    (
F5     4        s  3  d  ==
A5     4        s  3  d  ]]    )
B4     4        s n3  d  [[    (
D5     4        s  3  d  ==
F5     4        s  3  d  ]]    )
measure 85
F5    24        q     d        (
E5    12        e     d  [     )
C#6   12        e #   d  ]      .ff
P    C34:Y61
measure 86
gC#6   0        e     u        (
D6    12        e     d  [     ).
G5    12        e     d  ]
B5     3        t n   d  [[[   (
C6     3        t     d  ===
B5     3        t     d  ===
C6     3        t     d  ]]]   )
F5     6        s     d         .
rest   6        s
measure 87
E5     3        t     d  [[[   (
F5     3        t     d  ===
G5     3        t     d  ===
A5     3        t     d  ]]]   )
Bf5   24        q f   d        (+Z
P    C34:Y60
A5    12        e     d        )
measure 88
F5    12        e     d  [     (
gG5    4        t     u  [[[
gF5    4        t     u  ===
gE5    4        t     u  ]]]
F5     9        s.    d  =[
G5     3        t     d  ]]\   )
A5    12        e     d  [      .
F4    12        e     d  ]      .
measure 89
F4    24        q     u        (
E4    12        e     u        )
rest  12        e
measure 90
rest  24        q
rest  12        e
F5    12        e     d         mf
P    C33:Y60
measure 91
F5    24        q     d        (
E5    12        e     d  [     )
G5    12        e     d  ]
measure 92
G5    24        q     d        (
F5    12        e     d  [     )
A5    12        e     d  ]      .
measure 93
A5    24        q     d        (
G5    24        q     d
measure 94
F5    24        q     d
E5    24        q     d
measure 95
D5    24        q     d
C5    24        q     d        )
measure 96
F5    36        q.    d
F4    12        e     u
measure 97
F4    24        q     u        (
E4    12        e     u        )
C5    12        e     d         p
P    C33:Y64
measure 98
F4    12        e     u  [     (
E4     6        s     u  ]\    )
rest   6        s
G4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 99
Bf4   12        e     d  [      .
Bf4   12        e     d  =      .
Bf4   12        e     d  =      .
G5    12        e     d  ]
measure 100
Bf4   12        e     u  [     (
Af4    6        s f   u  ]\    )
rest   6        s
F5    12        e     d  [     (
Ef5    6        s f   d  ]\    )
rest   6        s
measure 101
D5    12        e     d  [      .
D5    12        e     d  =      .
D5    12        e     d  =      .
gF5    0        e     u        (
Ef5   12        e f   d  ]     )
measure 102
D5    12        e     d  [      .
D5    12        e     d  =      .
D5    12        e     d  ]      .
rest  12        e
measure 103
G4     4        s  6  d  [[     *f.
P    C34:Y86
Bf4    4        s  6  d  ==     .
Df5    4        s f6  d  ==     .
Ef5    4        s f6  d  ==     .
G5     4        s  6  d  ==     .
Bf5    4        s  6  d  ]]     !.
Df6   12        e f   d  [      .
C6    12        e     d  ]      .
measure 104
Bf5    4        s  3  d  [[     *.
C6     4        s  3  d  ==     .
Df6    4        s f3  d  ]]     !.
C6     4        s  3  d  [[     .
Bf5    4        s  3  d  ==     .
Af5    4        s f3  d  ]]     .
*               D       dim.
P  C25:f33  C17:Y68
G5     4        s  3  d  [[     .
F5     4        s  3  d  ==     .
Ef5    4        s f3  d  ]]     .
Df5    4        s f3  d  [[     .
C5     4        s  3  d  ==     .
Bf4    4        s  3  d  ]]     .
measure 105
Af4   24        q f   u
rest  12        e
C5    12        e     d         p
P    C33:Y64
measure 106
Bf4    6        s     d  [[    (
C5     6        s     d  ==
Df5    6        s f   d  ==
D5     6        s n   d  ]]    )
F5     6        s     d  [[    (
Ef5    6        s f   d  ]]    )
rest  12        e
measure 107
rest  24        q
rest  12        e
Af4   12        e f   u         .
measure 108
F#4    6        s #   u  [[    (
G4     6        s     u  ==
C5     6        s     u  ==
B4     6        s n   u  ]]    )
D5     6        s     d  [[    (
C5     6        s     d  ==
G5     6        s     d  ==
C5     6        s     d  ]]    )
measure 109
B4     6        s n   d  [[    (Z
P    C33:Y74
Af5    6        s f   d  ==
G5     6        s     d  ==
F5     6        s n   d  ]]     +
Ef5    6        s f   d  [[
Df5    6        s f   d  ==
C5     6        s     d  ==
B4     6        s     d  ]]    )
measure 110
C5    12        e     d         .
rest  12        e
rest  12        e
*               D       dim.
P  C25:f33  C17:Y73
F4    12        e     u        (
measure 111
E4    12        e n   u        )+
rest  12        e
rest  24        q
measure 112
A3     6        s n   u  [[    (+mf
P    C34:Y94
C4     6        s     u  ==
F4     6        s     u  ==
A4     6        s     u  ]]    )
C5    12        e     d  [
F5    12        e     d  ]
measure 113
F5    24        q     d        (
E5    12        e     d  [     )
G5    12        e     d  ]
measure 114
G5    18        e.    d  [     (
A5     3        t     d  =[[
G5     3        t     d  ]]]   )
F5    12        e     d  [
A5    12        e     d  ]
measure 115
A5    24        q     d        (
G5    24        q     d
measure 116
F5    24        q     d
E5    24        q     d
measure 117
D5    24        q     d
C5    24        q     d        )
measure 118
gC5    0        e     u        (
Bf4   12        e     u  [     )
A4    12        e     u  ]
Bf4    3        t     u  [[[   (
A4     3        t     u  ===
G4     3        t     u  ===
A4     3        t     u  ]]]   )
Bf4    9        s.    u  [[    (
G4     3        t     u  ]]\   )
measure 119
F4    12        e     u
rest  12        e
rest  12        e
F4    12        e     u         p
P    C33:Y58
measure 120
Bf4   12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
A4    12        e     u  [     (
F4     6        s     u  ]\    )
rest   6        s
measure 121
D5    12        e     d  [     (
F5    12        e     d  =     )
F5    12        e     d  =      .
F5    12        e     d  ]      .
measure 122
Bf4    3        t     d  [[[   (
C5     3        t     d  ===
Bf4    3        t     d  ===
A4     3        t     d  ]]]   )
Bf4    6        s     u  [[
F4     6        s     u  ]]
A4     3        t     u  [[[   (
Bf4    3        t     u  ===
A4     3        t     u  ===
G4     3        t     u  ]]]   )
A4     6        s     u  [[
F4     6        s     u  ]]
measure 123
D5     6        s     d  [[    (
Ef5    6        s f   d  ==
E5     6        s n   d  ==
F5     6        s     d  ]]    )
F5    12        e     d  [      .
F5    12        e     d  ]      .
measure 124
E5     3        t     d  [[[   (
C5     3        t     d  ===
E5     3        t     d  ===
G5     3        t     d  ]]]   )
Bf5   24        q     d         Z
P    C33:Y60
A5    12        e     d
measure 125
G5    24        q     d         F
D6    12        e     d         F
A4    12        e     u         .pp
P    C34:Y57
measure 126
G4    12        e     u  [      .
G4    12        e     u  ]      .
G4     6        s     u  [[    (
Af4    6        s f   u  ==
A4     6        s n   u  ==
Bf4    6        s     u  ]]    )
measure 127
A4    12        e     u  [     (
F4    12        e     u  =     )
F4    12        e     u  =      .
A4    12        e     u  ]      .
measure 128
G4    12        e     u  [      .
G4    12        e     u  =      .
G4    12        e     u  ]      .
E5    12        e     d         .f
P    C34:Y76
 Bf4  12        e     d
 G4   12        e     d
measure 129
F5    12        e     d
 A4   12        e     d
 F4   12        e     d
rest  12        e
rest  24        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/03/02} [KHM:2963845698]
TIMESTAMP: DEC/26/2001 [md5sum:bd192ee872b0b8f8be3d64e36bcab9e8]
11/13/94 W Hewlett
WK#:64,1      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[Third Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-1   Q:8   T:2/4  C:4  D:Allegretto scherzando
rest   4        e
measure 1
A3     4        e     u         .p
P    C34:Y90
rest   4        e
C4     4        e     u         .
rest   4        e
measure 2
C4     4        e     u         .
rest   4        e
rest   4        e
G4     4        e     u
measure 3
A4     4        e     u
rest   4        e
rest   4        e
F4     4        e     u
measure 4
F4     8        q     u        (
E4     4        e     u  [     )
F4     4        e     u  ]      .
measure 5
F4     4        e     u         .
rest   4        e
F4     4        e     u         .
rest   4        e
measure 6
C4    16-       h     u        -
measure 7
C4     6        e.    u  [     (
D4     1        t     u  =[[
E4     1        t     u  ]]]   )
F4     4        e     u  [      .
D4     4        e     u  ]      .
measure 8
D4     8        q     u        (
E4     4        e     u        )
mheavy4                    :|:
rest   4        e
measure 9
C4     4        e     u  [     (
Bf3    2        s     u  ]\    )
rest   2        s
Df4    4        e f   u  [     (
C4     2        s     u  ]\    )
rest   2        s
measure 10
C4     4        e     u  [      .
C4     4        e     u  =      .
C4     4        e     u  ]      .
rest   4        e
measure 11
G4     4        e     u  [     (
Af4    2        s f   u  ]\    )
rest   2        s
Af4    4        e     u  [
Af4    4        e     u  ]
measure 12
Af4   16-       h f   u        -
measure 13
Af4    4        e     u  [
Af4    4        e f   u  =      .
Af4    4        e     u  ]      .
rest   4        e
measure 14
Df5    8        q f   u         f
 Ef4   8        q f   u
Bf4    4        e     u  [
 Ef4   4        e     u         .
C5     4        e     u  ]
 Ef4   4        e     u         .
measure 15
F5     4        e     d         .
rest   4        e
*               D       dim.
P  C25:f33  C17:Y70
Bf4    4        e     d         .
rest   4        e
measure 16
C5     4        e     d
rest   4        e
rest   4        e
Ef4    4-       e f   u         p-
P    C33:Y67
measure 17
Ef4    8        q f   u
rest   8        q
measure 18
rest   8        q
rest   4        e
B3     4        e n   u
measure 19
C4     8        q     u
rest   4        e
E4     4        e n   u         +
measure 20
F4    12        q.    u         Z
P    C33:Y63
F4     4        e     u        (
measure 21
E4     4        e     u        )
rest   4        e
rest   4        e
*               D       dim.
P  C25:f33  C17:Y85
D4     4        e n   u        (+
measure 22
C4     4        e     u        )
rest   4        e
rest   8        q
measure 23
A3     4        e     u         .p
P    C34:Y89
rest   4        e
C4     4        e     u         .
rest   4        e
measure 24
C4     4        e     u         .
rest   4        e
rest   4        e
G4     4        e     u         .
measure 25
A4     4        e     u
rest   4        e
rest   4        e
F4     4        e     u
measure 26
F4     8        q     u        (
E4     4        e     u  [     )
F4     4        e     u  ]      .
measure 27
F4     4        e     u         .
rest   4        e
F4     4        e     u         .
rest   4        e
measure 28
rest   4        e
G4     4        e     u  [      .
G4     4        e     u  =      .
A4     4        e     u  ]      .
measure 29
gC5    0        e     u        (
Bf4    4        e     u  [     ).
A4     4        e     u  ]      .
Bf4    1        t     u  [[[   (
A4     1        t     u  ===
G4     1        t     u  ===
A4     1        t     u  ]]]   )
Bf4    3        s.    u  [[    (
G4     1        t     u  ]]\   )
measure 30
A4     4        e     u  [
F4     4        e     u  =      .
F4     4        e     u  =      .
F4     4        e     u  ]      .
measure 31
F4    16-       h     u        -
measure 32
F4     4        e     u  [
F4     4        e     u  =      .
F4     4        e     u  =      .
F4     4        e     u  ]      .
measure 33
F4    16-       h     u        -
measure 34
F4     4        e     u  [
F4     4        e     u  =      .
F4     4        e     u  =      .
C5     4        e     u  ]      .
measure 35
*               D       cresc.
P  C25:f33  C17:Y72
Bf4    4        e     d  [     (
G5     4        e     d  =     )
G5     4        e     d  =      .
F5     4        e     d  ]      .
measure 36
E5     4        e     d  [      .
E5     4        e     d  ]      .
E5     2        s     d         .
rest   2        s               F
F4     4        e     u         p
P    C33:Y58
measure 37
F4    12        q.    u
E4     4        e     u
measure 38
F4     8        q     u
rest   4        e
F4     4        e     u
measure 39
F4    12        q.    u
E4     4        e     u
measure 40
F4     4        e     u
rest   4        e
rest   4        e
mheavy4                         :|:
*               D +     dolce
P  C25:f33  C17:Y-10
C4     4        e     u
measure 41
F4     4        e     u  [     (
C4     2        s     u  ]\    )
rest   2        s
A4     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
measure 42
G4     4        e     d  [     (
C5     4        e     d  =     )
C5     4        e     d  =      .
C5     4        e     d  ]      .
measure 43
A4     4        e     d  [     (
D5     4        e     d  ]     )
D5     4        e     d  [
C5     1        t n   d  =[[   (
B4     1        t n   d  ===
A4     1        t     d  ===
B4     1        t     d  ]]]   )
measure 44
B4     8        q n   d        (
C5     4        e     d  [     )
C#5    4        e #   d  ]      .
measure 45
D5     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
C5     4        e n   u  [     (+
F4     2        s     u  ]\    )
rest   2        s
measure 46
E4     4        e     u  [     (
Bf4    4        e f   u  =     )+
Bf4    4        e     u  =      .
A4     4        e     u  ]      .
measure 47
F4     4        e     u  [     (
gG4    4        t     u  [[[
gF4    4        t     u  ===
gE4    4        t     u  ]]]
F4     3        s.    u  =[
G4     1        t     u  ]]\   )
A4     4        e     u  [      .
B4     4        e n   u  ]      .
measure 48
B4     8        q n   d        (
C5     4        e     d        )
mheavy4                         :|:
C5     4        e     d
measure 49
F4     4        e     u  [     (
E4     2        s     u  ]\    )
rest   2        s
G4     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
measure 50
Bf4    4        e     d  [      .
Bf4    4        e     d  =      .
Bf4    4        e     d  =      .
G5     4        e     d  ]
measure 51
Bf4    4        e     u  [     (
Af4    2        s f   u  ]\    )
rest   2        s
F5     4        e     d  [     (
Ef5    2        s f   d  ]\    )
rest   2        s
measure 52
D5     4        e     d  [      .
D5     4        e     d  =      .
D5     4        e     d  =      .
gF5    0        e     u        (
Ef5    4        e f   d  ]     )
measure 53
D5     4        e     d  [      .
D5     4        e     d  =      .
D5     4        e     d  ]      .
rest   4        e
measure 54
Df5    8        q f   u         f
 Ef4   8        q f   u
Bf4    4        e     u  [
 Ef4   4        e     u         .
C5     4        e     u  ]
 Ef4   4        e     u         .
measure 55
F5     4        e     d         .
rest   4        e
*               D       dim.
P  C25:f33  C17:Y70
Bf4    4        e     d         .
rest   4        e
measure 56
C5     4        e     d
rest   4        e
rest   4        e
C5     4        e     d         p
P    C33:Y64
measure 57
Bf4    4        e     d  [     (
Ef5    4        e f   d  ]     )
Ef5    4        e     d
rest   4        e
measure 58
rest   8        q
rest   4        e
Af4    4        e f   u
measure 59
G4     4        e     d  [     (
C5     4        e     d  =     )
C5     4        e     d  =      .
C5     4        e     d  ]      .
measure 60
B4     4        e n   d  [     (Z
P    C33:Y72
F5     4        e     d  =     )
F5     4        e     d  =      .
B4     4        e     d  ]     (
measure 61
C5     4        e     d        )
rest   4        e
rest   4        e
*               D       dim.
P  C25:f33  C17:Y75
F4     4        e     u        (
measure 62
E4     4        e     u        )
rest   4        e
rest   4        e
*               D +     dolce
P  C25:f33  C17:Y-10
C4     4        e     u
measure 63
F4     4        e     u  [     (
C4     2        s     u  ]\    )
rest   2        s
A4     4        e n   u  [     (+
F4     2        s     u  ]\    )
rest   2        s
measure 64
G4     4        e     d  [     (
C5     4        e     d  =     )
C5     4        e     d  =      .
C5     4        e     d  ]      .
measure 65
A4     4        e     d  [     (
D5     4        e     d  ]     )
D5     4        e     d  [
C5     1        t n   d  =[[   (
B4     1        t n   d  ===
A4     1        t     d  ===
B4     1        t     d  ]]]   )
measure 66
B4     8        q n   d        (
C5     4        e     d  [     )
C#5    4        e #   d  ]      .
measure 67
D5     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
C5     4        e n   u  [     (+
F4     2        s     u  ]\    )
rest   2        s
measure 68
E4     4        e     u  [     (
Bf4    2        s     u  ]\    )
rest   2        s
C4     4        e     u  [     (
A4     2        s     u  ]\    )
rest   2        s
measure 69
D4     2        s     u  [[    (
E4     2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]    )
Bf4    1        t     u  [[[   (
A4     1        t     u  ===
G4     1        t     u  ===
A4     1        t     u  ]]]   )
Bf4    2        s     u  [[    (
G4     2        s     u  ]]    )
measure 70
A4     4        e     u
rest   4        e
rest   4        e
F4     4        e     u
measure 71
Bf4    4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
A4     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
measure 72
D5     4        e     d  [     (
F5     4        e     d  =     )
F5     4        e     d  =      .
F5     4        e     d  ]      .
measure 73
Bf4    4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
A4     4        e     u  [     (
F4     2        s     u  ]\    )
rest   2        s
measure 74
D5     4        e     d  [
F5     4-       e     d  ]     -
F5     2        s     d  [[    (
E5     2        s     d  ==
D5     2        s     d  ==
C5     2        s     d  ]]    )
measure 75
*               E   0
P    C17:Y65
*     14        F   20
C5    16-       h     d        -
measure 76
*               E   15
P    C17:Y66
C5    16-       h     d        -
measure 77
*               F   0
C5     8        q     d
rest   4        e
A4     4        e     u         .p
P    C34:Y57
measure 78
G4     4        e     u  [      .
G4     4        e     u  =      .
G4     4        e     u  =     (
Bf4    4        e     u  ]     )
measure 79
A4     4        e     u  [     (
F4     4        e     u  =     )
F4     4        e     u  =      .
A4     4        e     u  ]      .
measure 80
G4     4        e     u  [      .
G4     4        e     u  =      .
G4     4        e     u  =      .
C5     4        e     u  ]      .
measure 81
A4     4        e     u
rest   4        e
rest   4        e
mheavy2                        :|
rest   4        e
measure 82
rest   4        e
A3     4        e     u         f
P    C33:Y86
rest   4        e
A3     4        e     u
measure 83
rest   4        e
G4     4        e     u
 C4    4        e     u
rest   4        e
G4     4        e     u
 C4    4        e     u
measure 84
rest   4        e
A4     4        e     u
rest   4        e
D4     4        e     u
measure 85
rest   4        e
D4     4        e     u  [     (
E4     4        e     u  =     )
C#5    4        e #   u  ]      .ff
P    C34:Y62
measure 86
gC#5   0        e     u        (
D5     4        e     d  [     ).
G4     4        e     d  ]      .
B4     1        t n   d  [[[   (
C5     1        t     d  ===
B4     1        t     d  ===
C5     1        t     d  ]]]   )
F4     2        s     u         .
rest   2        s
measure 87
C4     1        t     u  [[[   (
D4     1        t     u  ===
E4     1        t     u  ===
F4     1        t     u  ]]]   )
G4     8        q     u        (Z
P    C33:Y70
F4     4        e     u        )
measure 88
A4     8        q     u
 F4    8        q     u
rest   4        e
D4     4        e     u         .
measure 89
D4     8        q     u        (
C4     4        e     u        )
rest   4        e
measure 90
rest   8        q
rest   4        e
A4     4        e     u         mf
P    C33:Y62
measure 91
Bf4    8-       q     d        -(
Bf4    2        s     u  [[
G4     2        s     u  ==
E4     2        s     u  ==
Bf4    2        s     u  ]]    )
measure 92
C5     8-       q     d        -(
C5     2        s     d  [[
B4     2        s n   d  ==
F5     2        s     d  ==    )
F5     2        s     d  ]]     .
measure 93
F5     8        q     d
E5     8-       q     d        -
measure 94
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 95
C5     4        e     d
Bf4    8        q f   d         +
A4     4        e     u
measure 96
F4     4        e     u  [     (
gG4    4        t     u  [[[
gF4    4        t     u  ===
gE4    4        t     u  ]]]
F4     3        s.    u  =[
G4     1        t     u  ]]\   )
A4     4        e     u  [      .
B4     4        e n   u  ]      .
measure 97
B4     8        q n   d        (
C5     4        e     d        )
rest   4        e
measure 98
C4     4        e     u  [     (p
P    C33:Y77
Bf3    2        s f   u  ]\    )+
rest   2        s
Df4    4        e f   u  [     (
C4     2        s     u  ]\    )
rest   2        s
measure 99
C4     4        e     u  [      .
C4     4        e     u  =      .
C4     4        e     u  ]      .
rest   4        e
measure 100
G4     4        e     u  [     (
Af4    2        s f   u  ]\    )
rest   2        s
Af4    4        e     u  [
Af4    4        e     u  ]
measure 101
Af4    2        s f   u  [[    (
F4     2        s     u  ==
Af4    2        s     u  ==
F4     2        s     u  ]]    )
Af4    4        e     u  [
Af4    4        e     u  ]
measure 102
Af4    2        s f   u  [[    (
F4     2        s     u  ==
Af4    2        s     u  ==
F4     2        s     u  ]]    )
Af4    4        e     u
rest   4        e
measure 103
Df5    8        q f   u         f
 Ef4   8        q f   u
Bf4    4        e     u  [
 Ef4   4        e     u         .
C5     4        e     u  ]
 Ef4   4        e     u         .
measure 104
F4     4        e     u         .
rest   4        e
*               D       dim.
P  C25:f33  C17:Y89
Bf3    4        e     u         .
rest   4        e
measure 105
C4     4        e     u
rest   4        e
rest   4        e
Ef4    4        e f   u         .p
P    C34:Y70
measure 106
Ef4    4        e f   u         .
rest   4        e
rest   8        q
measure 107
rest   8        q
rest   4        e
C4     4        e     u
measure 108
C4     4        e     u         .
rest   4        e
rest   4        e
E4     4        e n   u         +.
measure 109
F4    12        q.    u         Z
P    C33:Y63
F4     4        e     u        (
measure 110
E4     4        e     u        )
rest   4        e
rest   4        e
*               D       dim.
P  C25:f33  C17:Y85
D4     4        e     u        (
measure 111
C4     4        e     u        )
rest   4        e
rest   8        q
measure 112
rest   8        q
rest   4        e
A4     4        e     u         mf
P    C33:Y62
measure 113
Bf4    8-       q     d        -(
Bf4    2        s     u  [[
G4     2        s     u  ==
E4     2        s     u  ==
Bf4    2        s     u  ]]    )
measure 114
C5     8-       q     d        -(
C5     2        s     d  [[
B4     2        s n   d  ==
F5     2        s     d  ==    )
F5     2        s     d  ]]     .
measure 115
F5     8        q     d
E5     8-       q     d        -
measure 116
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 117
C5     4        e     d
Bf4    8        q f   d         +
A4     4        e     u
measure 118
gA4    0        e     u        (
G4     4        e     u  [     )
F4     4        e     u  ]
G4     1        t     u  [[[   (
F4     1        t     u  ===
E4     1        t     u  ===
F4     1        t     u  ]]]   )
G4     3        s.    u  [[    (
E4     1        t     u  ]]\   )
measure 119
F4     4        e     u  [
*               E   15
P    C17:Y67
F4     4        e     u  =      .
F4     4        e     u  =      .
*               F   0
F4     4        e     u  ]      .
measure 120
F4    16-       h     u        -p
P    C33:Y63
measure 121
F4     4        e     u  [
F4     4        e     u  =      .
F4     4        e     u  =      .
F4     4        e     u  ]      .
measure 122
F4    16-       h     u        -
measure 123
F4     4        e     u  [
F4     4        e     u  =      .
F4     4        e     u  =      .
C5     4        e     u  ]      .
measure 124
Bf4    4        e     d
G4     8        q     u         Z
P    C33:Y62
F4     4        e     u
measure 125
E4    12        q.    u         F
 G3   12        q.    u
F4     4        e     u         pp
P    C33:Y58
measure 126
F4    12        q.    u        (
E4     4        e     u        )
measure 127
F4     4        e     u
rest   4        e
rest   4        e
F4     4        e     u
measure 128
F4    12        q.    u
Bf4    4        e     u         f
P    C33:Y85
 G4    4        e     u
 C4    4        e     u         .
measure 129
A4     4        e     u
 F4    4        e     u
 C4    4        e     u         .
rest   4        e
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/03/03} [KHM:2963845698]
TIMESTAMP: DEC/26/2001 [md5sum:d4dc006f165f0b64654661060825b292]
11/13/94 W Hewlett
WK#:64,1      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[Third Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-1   Q:24   T:2/4  C:13  D:Allegretto scherzando
rest  12        e
measure 1
C4    12        e     d         p.
P    C33:Y68
rest  12        e
C4    12        e     d         .
rest  12        e
measure 2
C4    12        e     d         .
rest  12        e
rest  12        e
C4    12        e     d         .
measure 3
C4    24        q     d
rest  12        e
D4    12        e     d
measure 4
D4    24        q     d        (
C4    12        e     u  [     )
F3    12        e     u  ]      .
measure 5
F3    12        e     u         .
rest  12        e
F3    12        e     u         .
rest  12        e
measure 6
Bf3   12        e     u  [     (
G3    12        e     u  =     )
G3    12        e     u  =      .
F3    12        e     u  ]      .
measure 7
A3    18        e.    u  [     (
G3     6        s     u  ]\    )
G3     3        t     u  [[[   (
F3     3        t     u  ===
E3     3        t     u  ===
F3     3        t     u  ]]]   )
G3     6        s     u  [[     .
F3     6        s     u  ]]     .
measure 8
F3    24        q     u        (
E3    12        e     u        )
mheavy4                    :|:
rest  12        e
measure 9
rest  48
measure 10
G4    12        e     d  [      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
rest  12        e
measure 11
E4    12        e     d  [     (
F4     6        s     d  ]\    )
rest   6        s
Df4   12        e f   d  [     (
C4     6        s     d  ]\    )
rest   6        s
measure 12
Bf3   12        e     u  [      .
Bf3   12        e     u  =      .
Bf3   12        e     u  ]      .
Cf4   12        e f   d        (
measure 13
Bf3   12        e     u  [     )
Bf3   12        e     u  =      .
Bf3   12        e     u  ]      .
rest  12        e
measure 14
Bf4   24        q     d         f
 G4   24        q     d
Bf4   12        e     d  [      .
Af4   12        e f   d  ]      .
measure 15
F4    12        e     d         .
rest  12        e
*               D       dim.
P  C25:f33  C17:Y65
Df4   12        e f   d         .
rest  12        e
measure 16
C4    24        q     d
rest  24        q
measure 17
rest  48
measure 18
rest  48
measure 19
rest  24        q
rest  12        e
C4    12        e     d
measure 20
Df4   36        q.f   d         Z
P    C33:Y65
Df4   12        e     d        (
measure 21
C4    12        e     u  [     )
*               D       dim.
P  C25:f33
C3    12        e     u  =
C3    12        e     u  =
Af3   12        e f   u  ]     (
measure 22
G3    12        e     u        )
rest  12        e
rest  24        q
measure 23
C4    12        e     d         .p
P    C34:Y68
rest  12        e
C4    12        e     d         .
rest  12        e
measure 24
C4    12        e     d         .
rest  12        e
rest  12        e
C4    12        e     d         .
measure 25
C4    24        q     d
rest  12        e
D4    12        e     d
measure 26
D4    24        q     d        (
C4    12        e     u  [     )
F3    12        e     u  ]      .
measure 27
F3    12        e     u         .
rest  12        e
F3    12        e     u         .
rest  12        e
measure 28
rest  12        e
C4    12        e     d  [      .
C4    12        e     d  =      .
C4    12        e     d  ]      .
measure 29
D4    12        e     d  [      .
D4    12        e     d  =      .
C4    12        e     d  ]      .
E3     4        s  3  u  [[    (*
G3     4        s  3  u  ==
Bf3    4        s  3  u  ]]    )!
measure 30
A3    12        e     u
rest  12        e
rest  24        q
measure 31
D4    12        e     d
rest  12        e
C4    12        e     d
rest  12        e
measure 32
Bf3   12        e     u  [     (
C4    12        e     u  =     )
C4    12        e     u  =      .
C4    12        e     u  ]      .
measure 33
D4    12        e     d
rest  12        e
C4    12        e     d
rest  12        e
measure 34
Bf3   12        e     u  [     (
C4    12        e     u  =     )
C4    12        e     u  =      .
C4    12        e     u  ]      .
measure 35
*               D       cresc.
P  C25:f33  C17:Y69
C4    12        e     d  [      .
C4    12        e     d  =      .
C4    12        e     d  =      .
C4    12        e     d  ]      .
measure 36
Bf3   12        e     d  [     (
Bf4   12        e     d  ]     )
Bf4    6        s     d         .
rest   6        s               F
C4    12        e     d         p
P    C33:Y68
measure 37
D4    24        q     d        (
C4    12        e     u  [     )
G3    12        e     u  ]
measure 38
A3    24        q     u
rest  12        e
C4    12        e     d
measure 39
D4    24        q     d        (
C4    12        e     u  [     )
G3    12        e     u  ]
measure 40
A3    12        e     u
rest  12        e
rest  12        e
mheavy4                         :|:
rest  12        e
measure 41
A3    12        e     u         .
rest  12        e
C4    12        e     d         .
rest  12        e
measure 42
C4    24        q     d
rest  12        e
C4    12        e     d
measure 43
C4    12        e     u  [     (
A3    12        e     u  ]     )
rest  12        e
F4    12        e     d
measure 44
F4    24        q     d        (
E4    12        e     d  [     )
F4    12        e     d  ]      .
measure 45
F4    12        e     d         .
rest  12        e
F4    12        e     d         .
rest  12        e
measure 46
rest  12        e
G4    12        e     d  [      .
C4    12        e     d  =      .
C4    12        e     d  ]      .
measure 47
C4    18        e.    u  [     (
Bf3    6        s     u  ]\    )
A3    12        e     u  [      .
D4    12        e     u  ]      .
measure 48
D4    24        q     d        (
C4    12        e     d        )
mheavy4                         :|:
rest  12        e
measure 49
C4    12        e     u  [     (
Bf3    6        s     u  ]\    )
rest   6        s
Df4   12        e f   d  [     (
C4     6        s     d  ]\    )
rest   6        s
measure 50
G4    12        e     d  [      .
G4    12        e     d  =      .
C4    12        e     d  ]      .
rest  12        e
measure 51
G4    12        e     d  [     (
Af4    6        s f   d  ]\    )
rest   6        s
Af4   12        e     d  [
Af4    6        s     d  ]\
rest   6        s
measure 52
Af4   48-       h f   d        -
measure 53
Af4   12        e     d  [
Af4   12        e f   d  =      .
Af4   12        e     d  ]      .
rest  12        e
measure 54
Bf4   24        q     d         f
P    C33:Y63
 G4   24        q     d
Bf4   12        e     d  [      .
Af4   12        e f   d  ]      .
measure 55
F4    12        e     d         .
rest  12        e
*               D       dim.
P  C25:f33  C17:Y65
Df4   12        e f   d         .
rest  12        e
measure 56
rest   6        s
Ef4    6        s f   d  [[     p.
P    C33:Y66
Df4    6        s f   d  ==     .
C4     6        s     d  ]]     .
Bf3    6        s     u  [[     .
Af3    6        s f   u  ==     .
G3     6        s     u  ==     .
Af3    6        s     u  ]]     .
measure 57
Ef3   12        e f   u
rest  12        e
rest  24        q
measure 58
rest   6        s
C4     6        s     u  [[     .
Bf3    6        s     u  ==     .
Af3    6        s f   u  ]]     .
G3     6        s     u  [[     .
F3     6        s     u  ==     .
E3     6        s n   u  ==     .+
F3     6        s     u  ]]     .
measure 59
C3    24        q     u
rest  12        e
C4    12        e     d
measure 60
Df4   36        q.f   d         Z
P    C33:Y65
Df4   12        e     d        (
measure 61
C4    12        e     u  [     )
*               D       dim.
P  C25:f33
C3    12        e     u  =
C3    12        e     u  =
Af3   12        e f   u  ]     (
measure 62
G3    12        e     u        )
rest  12        e
rest  24        q
measure 63
A3    12        e n   u         +.p
P    C35:Y62
rest  12        e
C4    12        e     d         .
rest  12        e
measure 64
C4    24        q     d
rest  12        e
C4    12        e     d
measure 65
C4    12        e     u  [     (
A3    12        e     u  ]     )
rest  12        e
F4    12        e     d
measure 66
F4    24        q     d        (
E4    12        e     d  [     )
F4    12        e     d  ]      .
measure 67
F4    12        e     d         .
rest  12        e
F4    12        e     d         .
rest  12        e
measure 68
rest  12        e
C4    12        e     d  [
rest  12        e
C4    12        e     d  ]
measure 69
rest  12        e
D4    12        e     d  [
C4    12        e     d  =
Bf3   12        e     d  ]
measure 70
A3    24        q     u
rest  24        q
measure 71
D4    12        e     d  [
rest  12        e
C4    12        e     d  ]
rest  12        e
measure 72
D5    12        e     d  [     (
C5    12        e     d  =     )
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 73
D4    12        e     d
rest  12        e
C4    12        e     d
rest  12        e
measure 74
rest  12        e
C4    12        e     d  [
C4    12        e     d  =
C4    12        e     d  ]
measure 75
rest  12        e
*               E   0
P    C17:Y63
G4    12        e     d  [
G4    12        e     d  =
*               F   15
A4    12        e     d  ]
measure 76
*               E   15
P    C17:Y63
Bf4   48-       h     d        -
measure 77
*               F   0
Bf4   24        q     d
rest  12        e
C4    12        e     d         p
P    C33:Y68
measure 78
D4    24        q     d        (
C4    12        e     d  [     )
C4    12        e     d  ]
measure 79
C4    24        q     d
rest  12        e
C4    12        e     d
measure 80
D4    24        q     d        (
C4    12        e     d  [     )
C4    12        e     d  ]
measure 81
C4    12        e     d
rest  12        e
rest  12        e
mheavy2                        :|
C4    12        e     d         f
P    C33:Y69
measure 82
F4    12        e     d  [     (
C4     6        s     d  ]\    )
rest   6        s
A4    12        e     d  [     (
F4     6        s     d  ]\    )
rest   6        s
measure 83
G4    12        e     d  [     (
C5    12        e     d  =     )
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 84
A4    12        e     d  [     (
D5    12        e     d  ]     )
D5    12        e     d  [
C5     3        t n   d  =[[   (
B4     3        t n   d  ===
A4     3        t     d  ===
B4     3        t     d  ]]]   )
measure 85
B4    24        q n   d        (
C5    12        e     d  [     )
C#5   12        e #   d  ]      .ff
P    C34:Y61
measure 86
gC#5   0        e     u        (
D5    12        e     d  [     ).
G4    12        e     d  ]      .
B4     3        t n   d  [[[   (
C5     3        t     d  ===
B4     3        t     d  ===
C5     3        t     d  ]]]   )
F4     6        s     d         .
rest   6        s
measure 87
E4     3        t     d  [[[   (
F4     3        t     d  ===
G4     3        t     d  ===
A4     3        t     d  ]]]   )
Bf4   24        q f   d        (+Z
P    C34:Y60
A4    12        e     d        )
measure 88
F4    12        e     d  [     (
gG4    4        t     u  [[[
gF4    4        t     u  ===
gE4    4        t     u  ]]]
F4     9        s.    d  =[
G4     3        t     d  ]]\   )
A4    12        e     d  [      .
B4    12        e n   d  ]      .
measure 89
B4    24        q n   d        (
C5    12        e     d        )
rest  12        e
measure 90
rest  48
measure 91
rest  48
measure 92
rest  48
measure 93
rest  48
measure 94
rest  48
measure 95
rest  24        q
rest  12        e
C4    12        e     d         mf
P    C33:Y69
measure 96
A4    18        e.    d  [     (
G4     6        s     d  ]\    )
F4    12        e     d  [      .
D4    12        e     d  ]      .
measure 97
D4    24        q     d        (
C4    12        e     d        )
rest  12        e
measure 98
rest  48
measure 99
G4    12        e     d  [      p.
P    C33:Y58
G4    12        e     d  =      .
G4    12        e     d  ]      .
rest  12        e
measure 100
E4    12        e     d  [     (
F4     6        s     d  ]\    )
rest   6        s
Df4   12        e f   d  [     (
C4     6        s     d  ]\    )
rest   6        s
measure 101
Bf3   12        e     u  [      .
Bf3   12        e     u  =      .
Bf3   12        e     u  =      .
Cf4   12        e f   u  ]     (
measure 102
Bf3   12        e     u  [     )
Bf3   12        e     u  =      .
Bf3   12        e     u  ]      .
rest  12        e
measure 103
Bf4   24        q     d         f
P    C33:Y63
 G4   24        q     d
Bf4   12        e     d  [      .
Af4   12        e f   d  ]      .
measure 104
Df4   12        e f   d
rest  12        e
rest  12        e
Ef3   12        e f   u
measure 105
Af3   12        e f   u  [     (p
P    C33:Y64
Ef3    6        s f   u  ]\    )
rest   6        s
C4    12        e     u  [     (
Af3    6        s     u  ]\    )
rest   6        s
measure 106
Ef4   12        e f   d
rest  12        e
rest  12        e
C3    12        e     u
measure 107
F3    12        e     u  [     (
C3     6        s     u  ]\    )
rest   6        s
Af3   12        e f   u  [     (
F3     6        s     u  ]\    )
rest   6        s
measure 108
C4    24        q     d
rest  12        e
C4    12        e     d
measure 109
Df4   36        q.f   d         Z
P    C33:Y65
Df4   12        e     d        (
measure 110
C4    12        e     u  [     )
*               D       dim.
P  C25:f33  C17:Y89
C3    12        e     u  =      .
C3    12        e     u  =      .
Af3   12        e f   u  ]     (
measure 111
G3    12        e     u        )
rest  12        e
rest  24        q
measure 112
rest  48
measure 113
rest  48
measure 114
rest  48
measure 115
rest  48
measure 116
rest  48
measure 117
rest  24        q
rest  12        e
C4    12        e     d         mf
P    C33:Y69
measure 118
D4    24        q     d        (
C4    12        e     u  [     )
Bf3   12        e     u  ]
measure 119
A3    12        e     u
rest  12        e
rest  24        q
measure 120
D4    12        e     d         p
P    C33:Y64
rest  12        e
C4    12        e     d
rest  12        e
measure 121
Bf3   12        e     u  [     (
C4    12        e     u  =     )
C4    12        e     u  =      .
C4    12        e     u  ]      .
measure 122
D4    12        e     d
rest  12        e
C4    12        e     d
rest  12        e
measure 123
Bf3   12        e     u  [     (
C4    12        e     u  =     )
C4    12        e     u  =      .
C4    12        e     u  ]      .
measure 124
C4    12        e     d
C4    24        q     d         Z
P    C33:Y69
C4    12        e     d
measure 125
C4    36        q.    d         F
C4    12        e     d         pp
P    C33:Y68
measure 126
Df4   12        e f   u  [     (
D4    12        e n   u  =
C4    12        e     u  =     )
G3    12        e     u  ]      .
measure 127
A3    12        e     u
rest  12        e
rest  12        e
C4    12        e     d
measure 128
Df4   12        e f   d  [     (
D4    12        e n   d  =
C4    12        e     d  =     )
C4    12        e     d  ]      .f
P    C34:Y69
measure 129
C4    12        e     d         .
rest  12        e
rest  24        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/03/04} [KHM:2963845698]
TIMESTAMP: DEC/26/2001 [md5sum:72c9bca584efababa9e1668f12076a35]
11/13/94 W Hewlett
WK#:64,1      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[Third Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-1   Q:8   T:2/4  C:22  D:Allegretto scherzando
rest   4        e
measure 1
F3     4        e     d         p.
P    C33:Y60
rest   4        e
F3     4        e     d         .
rest   4        e
measure 2
E3     4        e     d         .
rest   4        e
rest   4        e
E3     4        e     d         .
measure 3
F3     8        q     d
rest   4        e
G3     4        e     d
measure 4
C3    12        q.    u
A2     4        e     u         .
measure 5
Bf2    4        e     u         .
rest   4        e
A2     4        e     u         .
rest   4        e
measure 6
G2     4        e     u  [     (
E2     4        e     u  =     )
E2     4        e     u  =      .
F2     4        e     u  ]      .
measure 7
D2     4        e     u  [      .
D3     4        e     u  ]      .
rest   4        e
G2     4        e     u         .
measure 8
C2     4        e     u  [      .
C3     4        e     u  =      .
C2     4        e     u  ]      .
mheavy4                    :|:
rest   4        e
measure 9
Af3    4        e f   d  [     (
G3     2        s     d  ]\    )
rest   2        s
Bf3    4        e     d  [     (
Af3    2        s     d  ]\    )
rest   2        s
measure 10
E3     4        e     d  [      .
E3     4        e     d  =      .
E3     4        e     d  ]      .
rest   4        e
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
Ef3    8        q f   d         f
P    C33:Y66
G2     4        e     u  [      .
Af2    4        e f   u  ]      .
measure 15
Df3    8        q f   d
rest   4        e
Ef2    4        e f   u         p
P    C33:Y71
measure 16
Af2    4        e f   u  [     (
Ef2    2        s f   u  ]\    )
rest   2        s
C3     4        e     u  [     (
Af2    2        s     u  ]\    )
rest   2        s
measure 17
G2     4        e     u
rest   4        e
rest   4        e
C2     4        e     u
measure 18
F2     4        e     u  [     (
C2     2        s     u  ]\    )
rest   2        s
Af2    4        e f   u  [     (
F2     2        s     u  ]\    )
rest   2        s
measure 19
E2     8        q n   u         +
rest   8        q
measure 20
rest  16
measure 21
rest   8        q
rest   4        e
*               D       dim.
P  C25:f33  C17:Y69
B2     4        e n   u        (
measure 22
C3     4        e     u  [     )
C2     4        e     u  =      .
C2     4        e     u  ]      .
rest   4        e
measure 23
F3     4        e     d         p.
P    C33:Y60
rest   4        e
F3     4        e     d         .
rest   4        e
measure 24
E3     4        e     d         .
rest   4        e
rest   4        e
E3     4        e     d         .
measure 25
F3     8        q     d
rest   4        e
G3     4        e     d
measure 26
C3    12        q.    u
A2     4        e     u         .
measure 27
Bf2    4        e     u         .
rest   4        e
A2     4        e     u         .
rest   4        e
measure 28
G2     4        e     u  [     (
E2     4        e     u  =     )
E2     4        e     u  =      .
F2     4        e     u  ]      .
measure 29
Bf2    4        e     u  [     (
B2     4        e n   u  =     )
C3     4        e     u  =      .
C3     4        e     u  ]      .
measure 30
F2     8        q     u
rest   8        q
measure 31
rest  16
measure 32
Bf2    4        e     u  [     (
A2     4        e     u  =     )
A2     4        e     u  =      .
A2     4        e     u  ]      .
measure 33
rest  16
measure 34
Bf3    4        e     d  [     (
A3     4        e     d  =     )
A3     4        e     d  =      .
A3     4        e     d  ]      .
measure 35
*               D       cresc.
P  C25:f33  C17:Y67
G3     4        e     d  [     (
E3     4        e     d  =     )
E3     4        e     d  =      .
F3     4        e     d  ]      .
measure 36
rest   8        q
rest   4        e
A2     4        e     u         p
P    C33:Y58
measure 37
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C3     4        e     u  ]      .
measure 38
F3     8        q     d
rest   4        e
A2     4        e     u
measure 39
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C2     4        e     u  ]      .
measure 40
F2     4        e     u
rest   4        e
rest   4        e
mheavy4                         :|:
rest   4        e
measure 41
F3     4        e     d         .
rest   4        e
F3     4        e     d         .
rest   4        e
measure 42
E3     8        q     d
rest   4        e
E3     4        e     d
measure 43
F3     8        q     d
rest   4        e
G3     4        e     d
measure 44
C3     4        e     d  [      .
C4     4        e     d  ]      .
C3     4        e     u  [      .
A2     4        e     u  ]      .
measure 45
Bf2    4        e f   u         .+
rest   4        e
A2     4        e     u         .
rest   4        e
measure 46
G2     4        e     u  [     (
E2     4        e     u  =     )
E2     4        e     u  =      .
F2     4        e     u  ]      .
measure 47
D2     4        e     u  [      .
D3     4        e     u  ]      .
rest   4        e
G2     4        e     u         .
measure 48
C2     4        e     u  [      .
C3     4        e     u  =      .
C2     4        e     u  ]
mheavy4                         :|:
rest   4        e
measure 49
Af3    4        e f   d  [     (
G3     2        s     d  ]\    )
rest   2        s
Bf3    4        e     d  [     (
Af3    2        s     d  ]\    )
rest   2        s
measure 50
E3     4        e     d  [      .
E3     4        e     d  =      .
E3     4        e     d  ]      .
rest   4        e
measure 51
E4     4        e     d  [     (
F4     2        s     d  ]\    )
rest   2        s
Df4    4        e f   d  [     (
C4     2        s     d  ]\    )
rest   2        s
measure 52
Bf3    4        e     d  [      .
Bf3    4        e     d  =      .
Bf3    4        e     d  =      .
Cf4    4        e f   d  ]     (
measure 53
Bf3    4        e     d  [     )
Bf3    4        e     d  =      .
Bf3    4        e     d  ]      .
rest   4        e
measure 54
Ef3    8        q f   d         f
P    C33:Y66
G2     4        e     u  [      .
Af2    4        e f   u  ]      .
measure 55
Df3    8        q f   d
rest   4        e
Ef2    4        e f   u         p
P    C33:Y71
measure 56
Af2    4        e f   u  [     (
Ef2    2        s f   u  ]\    )
rest   2        s
C3     4        e     u  [     (
Af2    2        s     u  ]\    )
rest   2        s
measure 57
G2     4        e     u
rest   4        e
rest   4        e
C2     4        e     u
measure 58
F2     4        e     u  [     (
C2     2        s     u  ]\    )
rest   2        s
Af2    4        e f   u  [     (
F2     2        s     u  ]\    )
rest   2        s
measure 59
E2     4        e n   u         +
rest   4        e
rest   8        q
measure 60
rest  16
measure 61
rest   8        q
rest   4        e
*               D       dim.
P  C25:f33  C17:Y68
B2     4        e n   u        (
measure 62
C3     4        e     u  [     )
C2     4        e     u  =      .
C2     4        e     u  ]      .
rest   4        e
measure 63
F3     4        e     d         .p
P    C34:Y60
rest   4        e
F3     4        e     d         .
rest   4        e
measure 64
E3     8        q     d
rest   4        e
E3     4        e     d
measure 65
F3     8        q     d
rest   4        e
G3     4        e     d
measure 66
C3     4        e     d  [      .
C4     4        e     d  ]      .
C3     4        e     u  [      .
A2     4        e     u  ]      .
measure 67
Bf2    4        e     u         .
rest   4        e
A2     4        e     u         .
rest   4        e
measure 68
G2     4        e     u  [     (
E2     4        e     u  =     )
E2     4        e     u  =      .
F2     4        e     u  ]      .
measure 69
Bf2    4        e     u  [     (
B2     4        e n   u  =     )
C3     4        e     u  =      .
C3     4        e     u  ]      .
measure 70
F2     8        q     u
rest   8        q
measure 71
rest  16
measure 72
Bf2    4        e     u  [     (
A2     4        e     u  =     )
A2     4        e     u  =      .
A2     4        e     u  ]      .
measure 73
rest  16
measure 74
Bf3    4        e     d  [     (
A3     4        e     d  =     )
A3     4        e     d  =      .
A3     4        e     d  ]      .
measure 75
rest   4        e
*               E   0
P    C17:Y63
E4     4        e     d  [
E4     4        e     d  =
*               F   15
F4     4        e     d  ]
measure 76
*               E   15
P    C17:Y63
G4    16-       h     d        -
measure 77
*               F   0
G4     8        q     d
rest   4        e
A2     4        e     u         p
P    C33:Y58
measure 78
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C3     4        e     u  ]      .
measure 79
F2     8        q     u
rest   4        e
A2     4        e     u
measure 80
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C3     4        e     u  ]      .
measure 81
F2     4        e     u
rest   4        e
rest   4        e
mheavy2                        :|
rest   4        e
measure 82
rest   4        e
F3     4        e     d         f
P    C33:Y62
rest   4        e
F3     4        e     d
measure 83
rest   4        e
E3     4        e     d
rest   4        e
E3     4        e     d
measure 84
rest   4        e
F3     4        e     d
rest   4        e
G3     4        e     d
measure 85
rest   4        e
C3     4        e     u  [      .
C2     4        e     u  =      .
C#4    4        e #   u  ]      .ff
P    C34:Y61
measure 86
gC#4   0        e     u        (
D4     4        e     d  [     ).
G3     4        e     d  ]      .
B3     1        t n   d  [[[   (
C4     1        t     d  ===
B3     1        t     d  ===
C4     1        t     d  ]]]   )
F3     2        s     d         .
rest   2        s
measure 87
Bf3    1        t f   d  [[[   (+
A3     1        t     d  ===
G3     1        t     d  ===
F3     1        t     d  ]]]   )
E3     8        q     d        (Z
P    C33:Y65
F3     4        e     d        )
measure 88
D3     8        q     d
rest   4        e
G2     4        e     u         .
measure 89
C2     8        q     u
rest   4        e
C3     4        e     u         mf
P    C33:Y62
measure 90
F3     4        e     d  [     (
C3     2        s     d  ]\    )
rest   2        s
A3     4        e     d  [     (
F3     2        s     d  ]\    )
rest   2        s
measure 91
G3     4        e     d  [     (
C4     4        e     d  =     )
C4     4        e     d  =      .
C4     4        e     d  ]      .
measure 92
A3     4        e     d  [     (
D4     4        e     d  ]     )
D4     4        e     d  [
C4     1        t n   d  =[[   (
B3     1        t n   d  ===
A3     1        t     d  ===
B3     1        t     d  ]]]   )
measure 93
B3     8        q n   d        (
C4     4        e     d  [     )
C#4    4        e #   d  ]
measure 94
D4     4        e     d  [     (
F3     2        s     d  ]\    )
rest   2        s
C4     4        e n   d  [     (+
F3     2        s     d  ]\    )
rest   2        s
measure 95
Bf3    4        e f   d  [     (+
E3     2        s     d  ]\    )
rest   2        s
E3     4        e     d  [     (
F3     4        e     d  ]     )
measure 96
D3     4        e     d  [     (
gE3    4        t     u  [[[
gD3    4        t     u  ===
gC#3   4        t     u  ]]]
D3     3        s.    d  =[
E3     1        t     d  ]]\   )
F3     4        e     d  [      .
G3     4        e     d  ]      .
measure 97
C3     8        q n   u         +
rest   8        q
measure 98
Af3    4        e f   d  [     (p
P    C33:Y58
G3     2        s     d  ]\    )
rest   2        s
Bf3    4        e     d  [     (
Af3    2        s     d  ]\    )
rest   2        s
measure 99
E3     4        e     d  [      .
E3     4        e     d  =      .
E3     4        e     d  ]      .
rest   4        e
measure 100
rest  16
measure 101
rest  16
measure 102
rest  16
measure 103
Ef3    8        q f   d         f
P    C33:Y66
G2     4        e     u  [      .
Af2    4        e f   u  ]      .
measure 104
Df2    4        e f   u         .
rest   4        e
Ef2    4        e f   u         .
rest   4        e
measure 105
rest   8        q
rest   4        e
Af2    4-       e f   u        -p
P    C33:Y63
measure 106
Af2    4        e     u  [
G2     4        e     u  =
G2     4        e     u  ]
rest   4        e
measure 107
rest   8        q
rest   4        e
F2     4-       e     u        -
measure 108
F2     4        e     u  [
E2     4        e n   u  =      +
E2     4        e     u  ]
rest   4        e
measure 109
rest  16
measure 110
rest   8        q
rest   4        e
*               D       dim.
P  C25:f33  C17:Y68
B2     4        e n   u        (
measure 111
C3     4        e     u  [     )
C2     4        e     u  =      .
C2     4        e     u  =      .
C3     4        e     u  ]      mf
P    C33:Y62
measure 112
F3     4        e     d  [     (
C3     2        s     d  ]\    )
rest   2        s
A3     4        e n   d  [     (+
F3     2        s     d  ]\    )
rest   2        s
measure 113
G3     4        e     d  [     (
C4     4        e     d  =     )
C4     4        e     d  =      .
C4     4        e     d  ]      .
measure 114
A3     4        e     d  [     (
D4     4        e     d  ]     )
D4     4        e     d  [
C4     1        t n   d  =[[   (
B3     1        t n   d  ===
A3     1        t     d  ===
B3     1        t     d  ]]]   )
measure 115
B3     8        q n   d        (
C4     4        e     d  [     )
C#4    4        e #   d  ]
measure 116
D4     4        e     d  [     (
F3     2        s     d  ]\    )
rest   2        s
C4     4        e n   d  [     (+
F3     2        s     d  ]\    )
rest   2        s
measure 117
Bf3    4        e f   d  [     (+
E3     2        s     d  ]\    )
rest   2        s
E3     4        e     d  [     (
F3     4        e     d  ]     )
measure 118
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C3     4        e     u  ]      .
measure 119
F2     8        q     u
rest   8        q
measure 120
rest  16
measure 121
Bf2    4        e     u  [     (p
P    C33:Y62
A2     4        e     u  =     )
A2     4        e     u  =      .
A2     4        e     u  ]      .
measure 122
rest  16
measure 123
Bf3    4        e     d  [     (
A3     4        e     d  =     )
A3     4        e     d  =      .
A3     4        e     d  ]      .
measure 124
G3     4        e     d
E3     8        q     d         Z
P    C33:Y65
F3     4        e     d
measure 125
Bf2   12        q.    u         F
A2     4        e     u         pp
P    C33:Y58
measure 126
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C3     4        e     u  ]      .
measure 127
F2     8        q     u
rest   4        e
A2     4        e     u
measure 128
Bf2    4        e     u  [     (
B2     4        e n   u  =
C3     4        e     u  =     )
C2     4        e     u  ]      .f
P    C34:Y94
measure 129
F2     4        e     u         .
rest   4        e
rest   8        q
mheavy2
/END
/eof
//
