&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/02/01} [KHM:2270538497]
TIMESTAMP: DEC/26/2001 [md5sum:d37c2b45476619d593bcd6160f737b63]
11/13/94 W Hewlett
WK#:64,1      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Menuetto [Second Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:3/4  C:4  D:Allegretto ma non troppo
rest   4        q
measure 1
rest   4        q
G5     4        q     d         f.
P    C33:Y61
G5     4        q     d         .
measure 2
G5    12-       h.    d        -
measure 3
G5     4        q     d
A5     4        q     d
F5     4        q     d
measure 4
F5     4        q     d        (
E5     4        q     d        )
rest   4        q
measure 5
rest   4        q
D5     4        q     d         .
D5     4        q     d         .
measure 6
D5    12        h.    d
measure 7
D5     2        e     d  [     (
E5     2        e     d  =
F5     2        e     d  =     )
A5     2        e     d  =      .
G5     2        e     d  =      .
B4     2        e     d  ]      .
measure 8
C5     4        q     d         .
rest   4        q
mheavy4                      :|:
B4     2        e     d  [      .
C5     2        e     d  ]      .
measure 9
D5     2        e     d  [     (
E5     2        e     d  =
F5     2        e     d  =     )
A5     2        e     d  =      .
G5     2        e     d  =      .
B4     2        e     d  ]      .
measure 10
C5     2        e     d  [     (
D5     2        e     d  =
E5     2        e     d  =     )
A5     2        e     d  =      .
G5     2        e     d  =      .
C5     2        e     d  ]      .
measure 11
D5     2        e     d  [     (
E5     2        e     d  =
F5     2        e     d  =     )
A5     2        e     d  =      .
G5     2        e     d  =      .
D5     2        e     d  ]      .
measure 12
E5     2        e     d  [      .
F#5    2        e #   d  =      .
G5     2        e     d  =      .
A5     2        e     d  =      .
B5     2        e     d  =      .
C6     2        e     d  ]      .
measure 13
D6     8        h     d
C6     2        e     d  [     (
B5     2        e     d  ]     )
measure 14
A5     4        q     d         .
A5     4        q     d         .
A5     4        q     d         .
measure 15
A5     4        q     d        (
B5     4        q     d        )
F#5    4        q #   d
measure 16
G5     4        q     d
rest   4        q
G5     4        q     d        (p
P    C33:Y57
measure 17
B4     4        q     d        )
rest   4        q
G5     4        q     d        (
measure 18
C5     4        q     d        )
rest   4        q
G5     4        q     d         .
measure 19
F#5    2        e #   d  [     (
G5     2        e     d  =
A5     2        e     d  =
G5     2        e     d  =
F5     2        e n   d  =
E5     2        e     d  ]     )
measure 20
D5     4        q     d
rest   4        q
G4     4        q     u         f.
P    C33:Y69
measure 21
C5     4        q     d        (
E5     4        q     d        )
G5     4        q     d         .
measure 22
C6     4        q     d         .
E6     4        q     d         .
D6     1        s     d  [[    (
C6     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]    )
measure 23
G5     4        q     d         .
G5     4        q     d         .
G#5    4        q #   d         .Z
P    C34:Y60
measure 24
G#5    4        q #   d        (
A5     4        q     d        )
F#5    4        q #   d         .Z
P    C34:Y60
measure 25
F#5    4        q #   d        (
G5     4        q n   d        )+
E5     4        q     d         .Z
P    C34:Y60
measure 26
E5     4        q     d        (
F5     4        q n   d        )+
A5     4        q     d         .
measure 27
A5     4        q     d        (
E5     4        q     d        )
F5     4        q     d         .
measure 28
F5     4        q     d        (
C#5    4        q #   d        )
*               D       dim.
P  C25:f33  C17:Y65
D5     4        q     d         .
measure 29
C5    12        h.n   d         +
measure 30
*               E   0
P    C17:Y70
B4     2        e     d  [      .
C5     2        e     d  =      .
D5     2        e     d  =      .
E5     2        e     d  =      .
F5     2        e     d  =      .
*               F   15
G5     2        e     d  ]      .
measure 31
*               E   15
P    C17:Y65
F5    12        h.    d        (
measure 32
*               F   0
E5     4        q     d        )
rest   4        q
E6     4        q     d         .f
P    C34:Y60
measure 33
E6     4        q     d        (
B5     4        q     d        )
C6     4        q     d         .
measure 34
C6     4        q     d        (
G#5    4        q #   d        )
A5     4        q     d         .
measure 35
E5     4        q     d        (
F5     4        q     d        )
C#5    4        q #   d         .
measure 36
*               E   15
P    C17:Y65
D5     4        q     d        (
E5     4        q     d
*               F   0
F5     4        q     d        )
measure 37
C5    12        h.n   d         +p
P    C34:Y64
measure 38
*               GE  15  f
P   C17:Y70 C18:Y70
*     10        F   0
F4    12-       h.    u        -
measure 39
F4     4        q     u
E4     4        q     u
F4     4        q     u
measure 40
F#4   12        h.#   u        (f
P    C33:Y68
measure 41
G4     8        h     u        )
B3     4        q     u         .p
P    C34:Y83
measure 42
C4     4        q     u         .
rest   4        q
F#5    4        q #   d        (pp
P    C33:Y57
measure 43
G5     4        q     d        )
rest   4        q
B4     4        q     u         f
P    C33:Y80
 D4    4        q     u         .
measure 44
C5     4        q     u
 E4    4        q     u         .
rest   4        q
*               C +     Fine
P  C25:f33  C17:Y-15
mheavy2                    :|
$   K:-3   T:3/4    D:Trio
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
G5     4        q     d         .p
P    C34:Y57
measure 47
G5     4        q     d         .
G5     4        q     d         .
G5     4        q     d         .
measure 48
F5     4        q     d        (
Ef5    4        q f   d        )
rest   4        q
measure 49
rest  12
measure 50
rest   4        q
rest   4        q
Ef4    4        q f   u         .
measure 51
Af4    4        q f   u        (
C5     4        q     d        )
Ef5    4        q f   d         .
measure 52
F5     4        q     d        (
Ef5    4        q f   d        )
Ef4    4        q f   u         .
measure 53
Bf4    4        q f   d        (+
Af4    4        q f   u        )
Bf3    4        q f   u         .
measure 54
Af4    4        q f   u        (
G4     4        q     u        )
F4     4        q     u         .
measure 55
Ef4    4        q f   u        (
D4     4        q     u        )
F4     4        q     u         .
measure 56
Ef4    4        q f   u
rest   4        q
Bf4    4        q f   d         .
measure 57
*               D       cresc.
P  C25:f33  C17:Y73
A4     4        q     u        (
Bf4    4        q f   d        )
B4     4        q n   d         .
measure 58
D5     4        q     d        (
C5     4        q     d        )
F5     2        e     d  [      .
Ef5    2        e f   d  ]      .
measure 59
D5     2        e     u  [      .mf
P    C34:Y61
C5     2        e     u  =      .
Bf4    2        e f   u  =      +.
Af4    2        e f   u  =      +.
G4     2        e     u  =      .
F4     2        e     u  ]      .
measure 60
Ef4    4        q f   u
rest   4        q
mheavy4                     :|:
rest   4        q
measure 61
rest   4        q
rest   4        q
Af4    4        q f   u         p
P    C33:Y57
measure 62
G4     8        h     u
C5     2        e     u  [     (
Gf4    2        e f   u  ]     )
measure 63
F4     8        h     u
Bf4    2        e f   u  [     (
F4     2        e     u  ]     )
measure 64
Ef4    4        q f   u         .
Ef4    4        q     u         .
Af4    2        e f   u  [     (
Ef4    2        e     u  ]     )
measure 65
D4     8        h     u
gF4    0        e     u        (
Ef4    4        q f   u        )
measure 66
D4     4        q     u
*               D       cresc.
P  C25:f33  C17:Y70
G4     4        q     u        (
F#4    4        q #   u        )
measure 67
A4     4        q     u        (
G4     4        q     u        )
B4     4        q     d         .
measure 68
gD5    0        e     u        (
C5     4        q     d        )(>
B4     4        q     d        )
G4     4        q     u         .p
P    C34:Y63
measure 69
C5     4        q     d        (
Ef5    4        q f   d        )
G5     4        q     d         .
measure 70
Af5    4        q f   d        (
G5     4        q     d        )
D6     4        q     d         .
measure 71
D6     4        q     d         .
D6     4        q     d         .
D6     4        q     d         .
measure 72
B5     4        q     d        (
C6     4        q     d        )
rest   4        q
measure 73
F#5   12        h.#   d        (
measure 74
F5    12        h.n   d        )+
measure 75
Ef5    4        q f   d         .
Ef4    4        q f   u         .
D4     4        q     u        (t
gC4    5        s     u  [[
gD4    5        s     u  ]]    )
measure 76
C4     4        q     u         .
rest   4        q
G4     4        q     u         .
measure 77
Af4    4        q f   u        (
G4     4        q     u        )
C5     4        q     d         .
measure 78
Bf4    4        q f   d        (
Af4    4        q f   u        )
G4     4        q     u         .
measure 79
G4     4        q     u        (
F4     4        q     u        )
Ef4    4        q f   u         .
measure 80
D4     2        e n   u  [     (+
Ef4    2        e f   u  =
E4     2        e n   u  =
F4     2        e     u  =
F#4    2        e #   u  =
G4     2        e     u  ]     )
measure 81
Af4    4        q f   u        (
G4     4        q     u        )
B3     4        q     u         .
measure 82
C4     4        q     u         .
rest   4        q
*               C       Menuetto D.C.
P  C25:f33
mheavy2                    :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/02/02} [KHM:2270538497]
TIMESTAMP: DEC/26/2001 [md5sum:36c48e37c1c258772058ccb016200dc1]
11/13/94 W Hewlett
WK#:64,1      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Menuetto [Second Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:3/4  C:4  D:Allegretto ma non troppo
rest   4        q
measure 1
rest   4        q
E5     4        q     d         f.
P    C33:Y61
E5     4        q     d         .
measure 2
E5    12-       h.    d        -
measure 3
E5     4        q     d
F5     4        q     d
D5     4        q     d
measure 4
D5     4        q     d        (
C5     4        q     d        )
rest   4        q
measure 5
rest   4        q
C5     4        q     d         .
C5     4        q     d         .
measure 6
C5    12-       h.    d        -
measure 7
C5     8        h     d
B4     4        q     d
measure 8
C5     4        q     d         .
rest   4        q
mheavy4                      :|:
rest   4        q
measure 9
B4    12        h.    d
measure 10
C5    12        h.    d
measure 11
D5    12        h.    d
measure 12
E5     4        q     d        (
D5     4        q     d
C5     4        q     d        )
measure 13
B4     2        e     d  [      .
C5     2        e     d  =      .
D5     2        e     d  =      .
E5     2        e     d  =      .
F#5    2        e #   d  =      .
G5     2        e     d  ]      .
measure 14
G5     4        q     d        (
F#5    4        q #   d
E5     4        q     d        )
measure 15
D5     8        h     d        (
C5     4        q     d        )
measure 16
B4     4        q     d
rest   4        q
B3     4        q     u         .p
P    C34:Y84
measure 17
D4     4        q     u        (
F4     4        q n   u        )+
B3     4        q     u         .
measure 18
E4     4        q     u        (
G4     4        q     u        )
G4     4        q     u         .
measure 19
F#4    2        e #   u  [     (
G4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  =
F4     2        e n   u  =
E4     2        e     u  ]     )
measure 20
D4     4        q     u
rest   4        q
G3     4        q     u         .f
P    C34:Y99
measure 21
C4     4        q     u        (
E4     4        q     u        )
G4     4        q     u         .
measure 22
C5     4        q     d         .
E5     4        q     d         .
D5     1        s     d  [[    (
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]    )
measure 23
G4     4        q     u         .
G4     4        q     u         .
F4     4        q     u         .Z
P    C34:Y68
measure 24
F4     4        q     u        (
E4     4        q     u        )
Ef4    4        q f   u         .Z
P    C34:Y71
measure 25
Ef4    4        q f   u        (
D4     4        q     u        )
C4     4        q     u         .Z
P    C34:Y81
measure 26
C4     8        h     u
rest   4        q
measure 27
rest   4        q
rest   4        q
A4     4        q     u         .
measure 28
A4     4        q     u        (
G4     4        q     u
*               D       dim.
P  C25:f33  C17:Y68
F4     4        q     u        )
measure 29
E4    12        h.    u
measure 30
*               E   0
P    C17:Y78
F4     4        q     u        (
E4     4        q     u
*               F   15
D4     4        q     u        )
measure 31
*               E   15
P    C17:Y85
D4    12        h.    u        (
measure 32
*               F   0
C4     4        q     u        )
rest   4        q
E5     4        q     d         .f
P    C34:Y61
measure 33
E5     4        q     d        (
B4     4        q     d        )
C5     4        q     d         .
measure 34
C5     4        q     d        (
G#4    4        q #   u        )
A4     4        q     u         .
measure 35
E4     4        q     u        (
F4     4        q     u        )
C#4    4        q #   u         .
measure 36
*               E   15
P    C17:Y78
D4     4        q     u        (
E4     4        q     u
*               F   0
F4     4        q     u        )
measure 37
E4    12        h.    u         p
P    C33:Y62
measure 38
*               GE  15  f
*     10        F   0
D4    12-       h.    u        -
measure 39
D4     4        q     u
C#4    4        q #   u
D4     4        q     u
measure 40
C4    12-       h.n   u        -+f
P    C34:Y82
measure 41
C4     8        h     u
E4     2        e     u  [     (p
P    C33:Y69
D4     2        e     u  ]     )
measure 42
C4     4        q     u         .
rest   4        q
Ef5    4        q f   d        (pp
P    C33:Y58
measure 43
E5     4        q n   d        )+
rest   4        q
F4     4        q     u         f
P    C33:Y99
 G3    4        q     u         .
measure 44
E4     4        q     u
 G3    4        q     u         .
rest   4        q
*               C       Fine
P  C25:f33  C17:Y73
mheavy2                    :|
$   K:-3   T:3/4    D:Trio
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
B3     4        q     u         .p
P    C34:Y84
measure 47
D4     4        q     u        (
F4     4        q     u        )
G4     4        q     u         .
measure 48
B4     4        q     d        (
C5     4        q     d        )
rest   4        q
measure 49
rest  12
measure 50
rest  12
measure 51
Ef4   12-       h.f   u        -
measure 52
Ef4   12        h.    u        (
measure 53
D4    12        h.    u        )
measure 54
F4     4        q     u        (
Ef4    4        q f   u        )
C4     4        q     u         .
measure 55
Bf3    4        q f   u        (+
Af3    8        h f   u        )
measure 56
G3     4        q     u
rest   4        q
Bf3    4        q f   u         .
measure 57
*               D       cresc.
P  C25:f33  C17:Y90
A3     4        q     u        (
Bf3    4        q f   u        )
B3     4        q n   u
measure 58
D4     4        q     u        (
C4     4        q     u        )
C4     4        q     u         .
measure 59
D4    12        h.    u        (mf
P    C33:Y81
measure 60
Ef4    4        q f   u        )
rest   4        q
mheavy4                     :|:
rest   4        q
measure 61
rest   4        q
rest   4        q
F4     4-       q     u        -p
P    C33:Y63
measure 62
F4     4        q     u
E4     4        q     u
Ef4    4-       q f   u        -
measure 63
Ef4    4        q     u
D4     4        q     u
Df4    4-       q f   u        -
measure 64
Df4    4        q     u
C4     4        q     u
C4     4        q     u
measure 65
C4    12        h.    u
measure 66
B3     4        q     u
*               D       cresc.
P  C25:f33
D4     4        q n   u        (+
C4     4        q     u        )
measure 67
Ef4    4        q f   u        (
D4     4        q     u        )
G4     4        q     u         .
measure 68
F#4    4        q #   u        (>
G4     4        q     u        )
rest   4        q
measure 69
C4     4        q     u         .p
P    C34:Y79
C4     4        q     u         .
C4     4        q     u         .
measure 70
B3     8        h     u
F5     4        q     d         .
measure 71
F5     4        q     d         .
F5     4        q     d         .
F5     4        q     d         .
measure 72
Af5    4        q f   d        (
G5     4        q     d        )
rest   4        q
measure 73
C5    12        h.    d        (
measure 74
B4    12        h.    d        )
measure 75
C5     4        q     d         .
C4     4        q     u         .
B3     4        q     u         .
measure 76
C4     4        q     u         .
rest   4        q
E4     4        q     u         .
measure 77
F4     4        q     u        (
E4     4        q     u        )
C4     4        q     u         .
measure 78
Df4    4        q f   u        (
C4     4        q     u        )
C4     4        q     u         .
measure 79
B3     8        h     u        (
C4     4        q     u        )
measure 80
Af3    4        q f   u         +
rest   4        q
rest   4        q
measure 81
rest   4        q
rest   4        q
D4     4        q n   u         +.
measure 82
C4     4        q     u         .
rest   4        q
*               C       Menuetto D.C.
P  C25:f33
mheavy2                    :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/02/03} [KHM:2270538497]
TIMESTAMP: DEC/26/2001 [md5sum:b975ae5acd958f1719dd81c217418361]
11/13/94 W Hewlett
WK#:64,1      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Menuetto [Second Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:3/4  C:13  D:Allegretto ma non troppo
rest   4        q
measure 1
rest  12
measure 2
rest  12
measure 3
rest  12
measure 4
rest  12
measure 5
rest   4        q
A4     4        q     d         f.
P    C33:Y61
F4     4        q     d         .
measure 6
D4     4        q     d        (
E4     4        q     d
F#4    4        q #   d        )
measure 7
G4     8        h     d
G4     1        s     d  [[    (
F4     1        s n   d  ==     +
E4     1        s     d  ==
F4     1        s     d  ]]    )
measure 8
E4     4        q     d         .
rest   4        q
mheavy4                      :|:
rest   4        q
measure 9
G4    12-       h.    d        -
measure 10
G4    12-       h.    d        -
measure 11
G4    12        h.    d
measure 12
G4     8        h     d        (
A4     4        q     d        )
measure 13
B4     8        h     d
A4     2        e     d  [     (
G4     2        e     d  ]     )
measure 14
E4     4        q     d        (
F#4    4        q #   d
G4     4        q     d        )
measure 15
G4     4        q     d        (
F#4    4        q #   d
A4     4        q     d        )
measure 16
G4     4        q     d
rest   4        q
G3     4        q     u         .p
P    C34:Y66
measure 17
B3     4        q     u        (
D4     4        q     d        )
G3     4        q     u         .
measure 18
C4     4        q     d        (
E4     4        q     d        )
rest   4        q
measure 19
rest   4        q
D4     4        q     d         .
C4     4        q     d         .
measure 20
B3     4        q     u         .
rest   4        q
rest   4        q
measure 21
rest   4        q
rest   4        q
E4     4        q     d         f.
P    C33:Y62
measure 22
E4     4        q     d         .
E4     4        q     d         .
E4     4        q     d         .
measure 23
D4     4        q     d         .
D4     4        q     d         .
D4     4        q     d         .Z
P    C34:Y65
measure 24
D4     4        q     d        (
C#4    4        q #   d        )
C4     4        q n   d         .Z
P    C34:Y69
measure 25
C4     4        q     d        (
B3     4        q     u        )
Bf3    4        q f   u         .Z
P    C34:Y62
measure 26
Bf3    4        q f   u        (
A3     4        q     u        )
rest   4        q
measure 27
rest  12
measure 28
rest   4        q
*               D       dim.
P  C25:f33  C17:Y65
A3     4        q     u
A3     2        e     u  [     (
B3     2        e n   u  ]     )+
measure 29
C4    12        h.    d
measure 30
*               E   0
P    C17:Y72
D4     4        q     d        (
C4     4        q     d
*               F   15
B3     4        q     u        )
measure 31
*               E   15
P    C17:Y70
B3    12        h.    u        (
measure 32
*               F   0
C4     4        q     d        )
rest   4        q
rest   4        q
measure 33
rest   4        q
rest   4        q
G4     4        q     d         .f
P    C34:Y61
measure 34
G4     4        q     d        (
D4     4        q     d        )
E4     4        q     d         .
measure 35
B3     4        q     u        (
C4     4        q     d        )
G3     4        q     u         .
measure 36
*               E   15
P    C17:Y74
A3     4        q     u        (
G3     4        q     u
*               F   0
F3     4        q     u        )
measure 37
G3    12        h.    u         p
P    C33:Y58
measure 38
*               GE  15  f
P   C17:Y65 C18:Y65
*     10        F   0
B3    12        h.    u        (
measure 39
A3    12        h.    u        )
measure 40
Ef4   12        h.f   d        (f
P    C33:Y62
measure 41
E4     8        h n   d        )+
G4     2        e     d  [     (p
P    C33:Y58
F4     2        e     d  ]     )
measure 42
E4     4        q     d         .
rest   4        q
C5     2        e     d  [     (pp
P    C33:Y56
A4     2        e     d  ]     )
measure 43
G4     4        q     d
rest   4        q
G3     4        q     u         .f
P    C34:Y70
measure 44
C4     4        q     d         .
rest   4        q
*               C       Fine
P  C25:f33  C17:Y73
mheavy2                    :|
$   K:-3   T:3/4    D:Trio
G3     4        q     u         p
P    C33:Y58
measure 45
C4     4        q     d        (
Ef4    4        q f   d        )
G4     4        q     d         .
measure 46
Af4    4        q f   d        (
G4     4        q     d        )
rest   4        q
measure 47
rest  12
measure 48
rest   4        q
rest   4        q
Ef3    4        q f   u
measure 49
Af3    4        q f   u        (
C4     4        q     d        )
Ef4    4        q f   d         .
measure 50
F4     4        q     d        (
Ef4    4        q f   d        )
rest   4        q
measure 51
C4    12        h.    d        (
measure 52
Bf3   12-       h.f   u        -+)
measure 53
Bf3   12        h.    u
measure 54
Bf3    8        h f   u
Af3    4        q f   u         .
measure 55
G3     4        q     u        (
F3     4        q     u        )
D3     4        q     u         .
measure 56
Ef3    4        q f   u
rest   4        q
G3     4        q     u         .
measure 57
*               D       cresc.
P  C25:f33  C17:Y72
F#3    4        q #   u        (
G3     4        q     u        )
G3     4        q     u         .
measure 58
G3     4        q     u        (
Af3    4        q f   u        )+
Af3    4        q     u         .
measure 59
Af3   12        h.f   u        (mf
P    C33:Y73
measure 60
G3     4        q     u        )
rest   4        q
mheavy4                     :|:
rest   4        q
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest   4        q
*               D       cresc.
P  C25:f33  C17:Y67
B3     4        q     u        (
A3     4        q     u        )
measure 67
C4     4        q     d        (
B3     4        q     u        )
D4     4        q     d         .
measure 68
Ef4    4        q f   d        (>
D4     4        q     d        )
rest   4        q
measure 69
rest  12
measure 70
rest   4        q
rest   4        q
G4     4        q     d         .p
P    C34:Y57
measure 71
Af4    4        q f   d        (+
B4     4        q     d        )
D5     4        q     d         .
measure 72
F5     4        q     d        (
Ef5    4        q f   d        )
rest   4        q
measure 73
Af3   12        h.f   u        (
measure 74
G3    12        h.    u        )
measure 75
C4     4        q     d         .
G3     4        q     u         .
F3     4        q     u         .
measure 76
Ef3    4        q f   u
rest   4        q
rest   4        q
measure 77
rest   4        q
rest   4        q
E3     4        q     u
measure 78
F3     8        h     u        (
G3     4        q     u        )
measure 79
Af3    8        h f   u        (
G3     4        q     u        )
measure 80
F3     4        q     u
rest   4        q
rest   4        q
measure 81
rest   4        q
rest   4        q
F3     4        q     u         .
measure 82
Ef3    4        q f   u         +.
rest   4        q
*               C       Menuetto D.C.
P  C25:f33
mheavy2                    :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/02/04} [KHM:2270538497]
TIMESTAMP: DEC/26/2001 [md5sum:dce023c210830065958f64f10a400b1f]
11/13/94 W Hewlett
WK#:64,1      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
Menuetto [Second Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:3/4  C:22  D:Allegretto ma non troppo
G2     4        q     u         f
P    C33:Y66
measure 1
C3     4        q     u        (
E3     4        q     d        )
G3     4        q     d         .
measure 2
C4     4        q     d        (
E4     4        q     d        )
D4     1        s     d  [[    (
C4     1        s     d  ==
B3     1        s     d  ==
A3     1        s     d  ]]    )
measure 3
G3     4        q     d         .
G3     4        q     d        (
G#3    4        q #   d        )
measure 4
G#3    4        q #   d        (
A3     4        q     d        )
F2     4        q     u         .
measure 5
A2     4        q     u        (
C#3    4        q #   u
D3     4        q     d        )
measure 6
F3     4        q     d        (
G3     4        q n   d         +
A3     4        q     d        )
measure 7
G3    12        h.    d
measure 8
C3     4        q     u         .
C4     4        q     d         .
mheavy4                      :|:
rest   4        q
measure 9
F4    12        h.    d
measure 10
E4    12        h.    d
measure 11
B3    12        h.    d
measure 12
C4     4        q     d        (
B3     4        q     d
A3     4        q     d        )
measure 13
G3     2        e     d  [      .
A3     2        e     d  =      .
B3     2        e     d  =      .
C4     2        e     d  =      .
D4     2        e     d  =      .
E4     2        e     d  ]      .
measure 14
C4     8        h     d        (
C#4    4        q #   d        )
measure 15
D4     8        h     d
D3     4        q     d
measure 16
G3     4        q     d         .
G2     4        q     u         .
rest   4        q
measure 17
rest  12
measure 18
rest  12
measure 19
rest   4        q
B3     4        q     d         .p
P    C34:Y57
C4     4        q     d         .
measure 20
G3     4        q     d         .
G2     4        q     u         .
rest   4        q
measure 21
rest   4        q
rest   4        q
C4     4        q     d         .f
P    C34:Y61
measure 22
C4     4        q     d         .
C4     4        q     d         .
C4     4        q     d         .
measure 23
B3     4        q     d         .
B3     4        q     d         .
B3     4        q     d         .Z
P    C34:Y60
measure 24
A3     8        h     d
A3     4        q     d         .Z
P    C34:Y60
measure 25
G3     8        h     d
G3     4        q     d         .Z
P    C34:Y60
measure 26
F3     8        h     d
rest   4        q
measure 27
rest   4        q
C#3    4        q #   u        (
D3     4        q     d        )
measure 28
D3     4        q     d        (
E3     4        q     d
*               D       dim.
P  C25:f33  C17:Y65
F3     4        q     d        )
measure 29
G3    12-       h.    d        -
measure 30
*               E   0
P    C17:Y60
*     10        F   15
G3    12        h.    d
measure 31
*               E   15
P    C17:Y63
G#3   12        h.#   d        (
measure 32
*               F   0
A3     4        q     d        )
rest   4        q
rest   4        q
measure 33
rest   4        q
rest   4        q
E4     4        q     d         .f
P    C34:Y60
measure 34
E4     4        q     d        (
B3     4        q     d        )
C4     4        q     d         .
measure 35
G#3    4        q #   d        (
A3     4        q     d        )
E3     4        q     d         .
measure 36
*               E   15
P    C17:Y72
F3     4        q     d        (
E3     4        q     d
*               F   0
D3     4        q     d        )
measure 37
G3    12        h.n   d         +p
P    C34:Y58
measure 38
*               GE  15  f
P   C17:Y75 C18:Y75
*     10        F   0
G#2   12        h.#   u        (
measure 39
A2    12        h.    u        )
measure 40
Af2   12        h.f   u        (f
P    C33:Y68
measure 41
G2     8        h     u        )
G2     4        q     u         .p
P    C34:Y70
measure 42
C2     4        q     u         .
rest   4        q
rest   4        q
measure 43
rest   4        q
rest   4        q
G3     4        q     u         f
 G2    4        q     u         .
measure 44
C3     4        q     u
 C2    4        q     u         .
rest   4        q
*               C       Fine
P  C25:f33  C17:Y73
mheavy2                    :|
$   K:-3   T:3/4    D:Trio
rest   4        q
measure 45
C3     4        q     u         .p
P    C34:Y57
C3     4        q     u         .
C3     4        q     u         .
measure 46
B2     8        h     u
rest   4        q
measure 47
rest  12
measure 48
rest  12
measure 49
Af2    4        q f   u         .
Af2    4        q     u         .
Af2    4        q     u         .
measure 50
G2     8        h     u
rest   4        q
measure 51
Af3   12        h.f   d        (
measure 52
G3    12        h.    d
measure 53
F3    12        h.    d        )
measure 54
D3     4        q     d        (
Ef3    4        q f   d        )
Af2    4        q f   u         .
measure 55
Bf2    4        q f   u        (
Cf3    4        q f   u        )
Bf2    4        q     u         .
measure 56
Ef3    4        q f   d         .
Ef2    4        q f   u         .
Ef2    4        q     u         .
measure 57
*               D       cresc.
P  C25:f33  C17:Y85
Ef2   12-       h.f   u        -
measure 58
Ef2   12-       h.    u        -
measure 59
Ef2   12-       h.    u        -mf
P    C33:Y89
measure 60
Ef2    4        q     u
rest   4        q
mheavy4                     :|:
Bf3    4        q f   d         .p
P    C34:Y57
measure 61
A3     4        q     d
Bf3    4        q f   d
B3     4        q n   d
measure 62
D4     4        q     d        (
C4     4        q     d        )
A3     4        q     d         .
measure 63
C4     4        q     d        (
Bf3    4        q f   d        )+
G3     4        q     d         .
measure 64
Bf3    4        q f   d        (
Af3    4        q f   d        )+
F3     4        q     d         .
measure 65
Af3    4        q f   d        (
G3     4        q     d        )
F#3    4        q #   d         .
measure 66
*      4        D       cresc.
P  C25:f33  C17:Y65
G3    12-       h.    d        -
measure 67
G3    12-       h.    d        -
measure 68
G3     4        q     d         >
G2     4        q     u
rest   4        q
measure 69
rest  12
measure 70
rest  12
measure 71
rest  12
measure 72
rest   4        q
rest   4        q
Af2    4        q f   u         .p
P    C34:Y66
measure 73
C3     4        q     u        (
Ef3    4        q f   d        )
F#3    4        q #   d         .
measure 74
G3     4        q     d        (
B3     4        q     d
D4     4        q     d        )
measure 75
C4     4        q     d         .
G3     4        q     d         .
G2     4        q     u         .
measure 76
C3    12-       h.    u        -
measure 77
C3    12-       h.    u        -
measure 78
C3    12-       h.    u        -
measure 79
C3    12        h.    u
measure 80
F2     4        q     u
rest   4        q
rest   4        q
measure 81
rest   4        q
rest   4        q
G2     4        q     u         .
measure 82
C2     4        q     u         .
rest   4        q
*               C       Menuetto D.C.
P  C25:f33
mheavy2                    :|
/END
/eof
//
