&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/01/01} [KHM:537739596]
TIMESTAMP: DEC/26/2001 [md5sum:7c279490da277a0c8c2c7dec80c89277]
11/13/94 W Hewlett
WK#:64,1      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[First Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:12   T:0/0  C:4  D:Allegro moderato
G3    12        q     u         p
P    C33:Y85
measure 1
C4    24        h     u
E4     9        e.    u  [     (
C4     3        s     u  ]\    )
F4     9        e.    u  [     (
D4     3        s     u  ]\    )
measure 2
G4    21        q:    u        (Zp
P    C33:Y70
E4     3        s     u        )
C4     6        e     u
rest   6        e
E4     3        s     u  [[    (
D4     3        s     u  ==
C4     3        s     u  ==
D4     3        s     u  ]]    )
measure 3
*               D       cresc.
P  C25:f33  C17:Y70
E4     6        e     u         .
rest   6        e
F4     6        e     u         .
rest   6        e
G4     6        e     u         .
rest   6        e
A4     6        e     u         .
rest   6        e
measure 4
B4    12        q     d        (mf
C5     6        e     d        )
rest   6        e
rest  12        q
G#4   12        q #   u        (p
measure 5
A4    21        q:    u        )
E4     3        s     u        (
F4     9        e.    u  [     )
C#4    3        s #   u  ]\    (
D4     9        e.    u  [     )
F4     3        s     u  ]\
measure 6
C4    24        h n   u        (+
B3    12        q     u        )
B3     3        s     u  [[    (
A3     3        s     u  ==
G3     3        s     u  ==
A3     3        s     u  ]]    )
measure 7
G3    12        q     u         .
F4    12        q     u        (
E4    12        q     u
D4    12        q     u        )
measure 8
D#4   12        q #   u        (
E4     6        e     u        )
rest   6        e
rest  12        q
G4    12        q     u         f
measure 9
gG3    5        s     u  [[    (
gE4    5        s     u  ]]
C5    24        h     d        )
E5     9        e.    d  [     (
C5     3        s     d  ]\    )
F5     9        e.    d  [     (
D5     3        s     d  ]\    )
measure 10
G5    21        q:    d        (
E5     3        s     d        )
C5     6        e     d
rest   6        e
E5     3        s     d  [[    (
D5     3        s     d  ==
C5     3        s     d  ==
D5     3        s     d  ]]    )
measure 11
E5     6        e     d         .
rest   6        e
F5     6        e     d         .
rest   6        e
G5     6        e     d         .
rest   6        e
A5     6        e     d         .
rest   6        e
measure 12
B5    12        q     d        (
C6     6        e     d        )
rest   6        e
rest  12        q
G#5   12        q #   d        (mf
P    C33:Y60
measure 13
A5    21        q:    d        )
E5     3        s     d        (
F5     9        e.    d  [     )
C#5    3        s #   d  =\    (
D5     9        e.    d  =     )
F5     3        s     d  ]\
measure 14
C5    24        h n   d        (+
B4     6        e     d        )
rest   6        e
B4     3        s     u  [[    (
A4     3        s     u  ==
G4     3        s     u  ==
A4     3        s     u  ]]    )
measure 15
G4    12        q     u
F5    12        q     d        (
E5    12        q     d        )
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 16
C5    12        q     d
rest  24        h
C5     3        s     d  [/    (
C6     9        e.    d  ]     )
measure 17
B5     3        s     d  [/    (
G5     9        e.    d  ]     )
F5     3        s     d  [/    (
D5     9        e.    d  ]     )
B4     3        s     u  [/    (
G4     9        e.    u  ]     )
F4     3        s     u  [/    (
D4     9        e.    u  ]     )
measure 18
C4    12        q     u         .
E4    12        q     u         .
rest  12        q
C5     4        e  3  d  [     (*
E5     4        e  3  d  =
C6     4        e  3  d  ]     )!
measure 19
B5     4        e  3  d  [      .
A5     4        e  3  d  =      .
G5     4        e  3  d  ]      .
F5     4        e  3  d  [      .
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
C5     4        e  3  d  [      .
B4     4        e  3  d  =      .
A4     4        e  3  d  ]      .
G4     4        e  3  u  [      .
A4     4        e  3  u  =      .
F4     4        e  3  u  ]      .
measure 20
E4    12        q     u        (
G4    12        q     u
C5    12        q     d
E5    12        q     d        )
measure 21
F4    12        q     u        (
A4    12        q     u
D5    12        q     d
F5    12        q     d        )Z
P    C33:Y60
measure 22
E5    24        h     d        (
D5     6        e     d        )
rest   3        s
G5     3        s     d
gA5    4        t     u  [[[   (
gG5    4        t     u  ===
gF#5   4        t     u  ]]]
G5    12        q     d        )
measure 23
C6    12        q     d         .
C6    12        q     d         .
C6    12        q     d         .
rest  12        q
measure 24
A5    12        q     d         .
A5    12        q     d         .
A5    12        q     d         .
G5     3        s     d  [[    (
F5     3        s     d  ==
E5     3        s     d  ==
D5     3        s     d  ]]    )
measure 25
C5    24        h     d        (
B4    12        q     d        )
D5    12        q     d         .f
P    C34:Y60
measure 26
gD4    5        s     u  [[    (
gB4    5        s     u  ]]
G5    24        h     d        )
B5     9        e.    d  [     (
G5     3        s     d  =\    )
C6     9        e.    d  =     (
A5     3        s     d  ]\    )
measure 27
D6     6        e     d  [     (
B5     6        e     d  =     )
G5     6        e     d  =      .
D5     6        e     d  ]      .
B4     6        e     u  [     (
G4     6        e     u  =     )
D4     6        e     u  =      .
B3     6        e     u  ]      .
measure 28
C4    12        q     u        (
B3    12        q     u
A3    12        q     u        )
C4     3        s     u  [[    (
B3     3        s     u  ==
A3     3        s     u  ==
B3     3        s     u  ]]    )
measure 29
C4    12        q     u
rest   6        e
D4     6        e     u         .
F#4    6        e #   d  [      .
A4     6        e     d  =      .
D5     6        e     d  =      .
F#5    6        e #   d  ]      .
measure 30
A5    12        q     d
rest   6        e
F#4    6        e #   u         .
A4     6        e     d  [      .
C5     6        e     d  =      .
F#5    6        e #   d  =      .
A5     6        e     d  ]      .
measure 31
C6    18        q.    d
A5     6        e     d         .
F#5    6        e #   d  [      .
D5     6        e     d  =      .
C5     6        e     d  =      .
A4     6        e     d  ]      .
measure 32
F#4    6        e #   u  [     (
D4     6        e     u  =
C#4    6        e #   u  =
D4     6        e     u  ]     )
C4     6        e n   u  [     (
D4     6        e     u  =
A3     6        e     u  =
D4     6        e     u  ]     )
measure 33
G3     4        e  3  u  [      .
G4     4        e  3  u  =      .
B4     4        e  3  u  ]      .
D5     4        e  3  d  [      .
G5     4        e  3  d  =      .
B5     4        e  3  d  ]      .
D6    12        q     d
C6     3        s     d  [[    (
B5     3        s     d  ==
A5     3        s     d  ==
B5     3        s     d  ]]    )
measure 34
C6     6        e     d         .
rest   6        e
A5     6        e     d         .
rest   6        e
F#5    6        e #   d         .
rest   6        e
D5     6        e     d         .
rest   6        e
measure 35
G3     4        e  3  u  [      .
G4     4        e  3  u  =      .
Bf4    4        e f3  u  ]      .
D5     4        e  3  d  [      .
G5     4        e  3  d  =      .
Bf5    4        e f3  d  ]      .
D6    12        q     d         .
C6     3        s     d  [[    (
Bf5    3        s     d  ==
A5     3        s     d  ==
Bf5    3        s     d  ]]    )
measure 36
C6     6        e     d         .
rest   6        e
A5     6        e     d         .
rest   6        e
F#5    6        e #   d         .
rest   6        e
D5     6        e     d         .
rest   6        e
measure 37
Bf5   48        w f   d
measure 38
G6    36        h.    d        (
F6    12        q n   d        )+
measure 39
Ef6    6        e f   d  [     (
Bf5    6        e f   d  =
G5     6        e     d  =
F5     6        e     d  ]     )
Ef5   12        q f   d
D5    12        q     d
measure 40
C#5    4        e #3  d  [     (mf
P    C33:Y77
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
C#5    4        e  3  d  [     (
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
measure 41
D5     4        e  3  u  [     (
D4     4        e  3  u  =
D5     4        e  3  u  ]     )
F#5    4        e #3  u  [     (
D4     4        e  3  u  =
F#5    4        e  3  u  ]     )
D5     4        e  3  u  [     (
D4     4        e  3  u  =
D5     4        e  3  u  ]     )
F#5    4        e  3  u  [     (
D4     4        e  3  u  =
F#5    4        e  3  u  ]     )
measure 42
C#5    4        e #3  d  [     (
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
C#5    4        e  3  d  [     (
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
measure 43
D5     4        e  3  u  [     (
D4     4        e  3  u  =
D5     4        e  3  u  ]     )
F#5    4        e #3  u  [     (
D4     4        e  3  u  =
F#5    4        e  3  u  ]     )
D5     4        e  3  u  [     (
D4     4        e  3  u  =
D5     4        e  3  u  ]     )
F#5    4        e  3  u  [     (
D4     4        e  3  u  =
F#5    4        e  3  u  ]     )
measure 44
C#5    4        e #3  d  [     (p
P    C33:Y70
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
C#5    4        e  3  d  [     (
A4     4        e  3  d  =
E5     4        e  3  d  ]     )
E5     4        e  3  d  [     (
A4     4        e  3  d  =
C#5    4        e  3  d  ]     )
measure 45
D5     6        e     u  [     (
D4     6        e     u  =     )
D4     6        e     u  =     (
D4     6        e     u  ]     )0
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
measure 46
*               D +     sempre
P  C25:f33
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
measure 47
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
measure 48
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
D4     6        e     u  [     (
D4     6        e     u  =     )0
D4     6        e     u  =     (
D4     6        e     u  ]     )0
measure 49
D4    12        q     u
D4    24        h     u        (
D#4   12        q #   u        )Zp
P    C33:Y70
measure 50
E4    24        h     u
A4     9        e.    u  [     (
E4     3        s     u  =\    )
C5     9        e.    u  =     (
A4     3        s     u  ]\    )
measure 51
G4     6        e     d  [     (
F#4    6        e #   d  =     )
E5     6        e     d  =     (
D5     6        e     d  ]     )
D5    18        q.    d        (
E5     3        s     d  [[
F#5    3        s #   d  ]]    )
measure 52
G5     6        e     d         .
rest   6        e
*               D       cresc.
P  C25:f33  C17:Y65
A5     6        e     d         .
rest   6        e
B5     6        e     d         .
rest   6        e
C6     6        e     d         .
rest   6        e
measure 53
D6     6        e     d         .
rest   6        e
E6     6        e     d         .
rest   6        e
F#6    6        e #   d         .
rest   6        e
G6     6        e     d         .
rest   6        e
measure 54
D4    12        q     u         f
rest  12        q
rest  12        q
E5     4        e  3  d  [     (*p
D5     4        e  3  d  =
F#4    4        e #3  d  ]     )!
measure 55
*               E   0
P    C17:Y71
G4    12        q     u         .
A4    12        q     u         .
B4    12        q     d         .
*               F   15
C#5   12        q #   d         .
measure 56
*               GE  15  Z
P   C17:Y70 C18:Y70
C#5   24        h #   d        (
*               F   0
D5    12        q     d        )
E5     4        e  3  d  [     (*p
D5     4        e  3  d  =
F#4    4        e #3  d  ]     )!
measure 57
*               E   0
P    C17:Y70
G4    12        q     u         .
A4    12        q     u         .
B4    12        q     d         .
*               F   15
C#5   12        q #   d         .
measure 58
*               GE  15  Z
P   C17:Y70 C18:Y70
C#5   24        h #   d        (
*               F   0
D5    12        q     d        )
E5     4        e  3  d  [     (*p
D5     4        e  3  d  =
F#4    4        e #3  d  ]     )!
measure 59
G4     4        e  3  d  [     (*
B4     4        e  3  d  =
D5     4        e  3  d  ]     )!
E5     4        e  3  d  [     (*
D5     4        e  3  d  =
F#4    4        e #3  d  ]     )!
G4     4        e  3  d  [     (*
B4     4        e  3  d  =
D5     4        e  3  d  ]     )!
E5     4        e  3  d  [     (*
D5     4        e  3  d  =
F#4    4        e  3  d  ]     )!
measure 60
G4    12        q     u         .
G5    12        q     d         .
rest  12        q
mheavy2                      :|
rest  12        q
measure 61
*               D       mezzo voce
P  C25:f33
rest  12        q
B4    12        q     d         .
B4    12        q     d         .
B4    12        q     d         .
measure 62
A4    36        h.    u        (
B4    12        q     d        )
measure 63
C5    12        q     d         .
C5    12        q     d         .
C5    12        q     d         .
C5    12        q     d         .
measure 64
B4    36        h.    d
A5    12        q     d        (
measure 65
G5     6        e     d        )
rest   6        e
F5    12        q n   d        (+
E5     6        e     d        )
rest   6        e
D5    12        q     d        (
measure 66
C5     6        e     d        )
rest   6        e
rest  12        q
rest  24        h
measure 67
rest  48
measure 68
rest  48
measure 69
rest  12        q
A5     4        e  3  d  [     (*
G5     4        e  3  d  =
D5     4        e  3  d  ]     )!
rest  12        q
A5     4        e  3  d  [     (*
G5     4        e  3  d  =
E5     4        e  3  d  ]     )!
measure 70
rest  12        q
Bf5    4        e f3  d  [     (
A5     4        e  3  d  =
E5     4        e  3  d  ]     )
rest  12        q
Bf5    4        e  3  d  [     (
A5     4        e  3  d  =
F5     4        e  3  d  ]     )
measure 71
rest  12        q
D6     4        e  3  d  [     (Z
P    C33:Y60
Bf5    4        e f3  d  =     )
F5     4        e  3  d  ]      .
D5     4        e  3  d  [      .
F5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
Bf4    4        e f3  d  [      .
D5     4        e  3  d  =      .
Bf4    4        e  3  d  ]      .
measure 72
A4    12        q     u
Ef6    4        e f3  d  [     (Z
P    C33:Y60
C6     4        e  3  d  =     )
A5     4        e  3  d  ]      .
F5     4        e  3  d  [      .
Ef5    4        e f3  d  =      .
A5     4        e  3  d  ]      .
C6     4        e  3  d  [      .
A5     4        e  3  d  =      .
Ef5    4        e  3  d  ]      .
measure 73
D5    12        q     d         .
D6     4        e  3  d  [     (Z
P    C33:Y60
Bf5    4        e f3  d  =     )
F5     4        e  3  d  ]      .
D5     4        e  3  d  [      .
F5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
Bf4    4        e f3  d  [      .
D5     4        e  3  d  =      .
Bf4    4        e  3  d  ]      .
measure 74
A4     4        e  3  d  [      .
D5     4        e  3  d  =      .
F5     4        e  3  d  ]      .
A5     4        e  3  d  [      .
D6     4        e  3  d  =      .
A5     4        e  3  d  ]      .
F5     4        e  3  d  [      .
A5     4        e  3  d  =      .
F5     4        e  3  d  ]      .
D5     4        e  3  d  [      .
F5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
measure 75
G#4    4        e #3  d  [      .
D5     4        e  3  d  =      .
E5     4        e  3  d  ]      .
F5     4        e  3  d  [      .
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
D6     4        e  3  d  [      .
D4     4        e  3  d  =      .
E4     4        e  3  d  ]      .
F4     4        e  3  u  [      .
E4     4        e  3  u  =      .
D4     4        e  3  u  ]      .
measure 76
C#4    4        e #3  u  [      .
E4     4        e  3  u  =      .
G#4    4        e #3  u  ]      .
A4     4        e  3  u  [      .
E4     4        e  3  u  =      .
C#4    4        e  3  u  ]      .
A3    12        q     u         .
A4    12        q     u         p.
measure 77
C#5   12        q #   d         .
*               E   0
P    C17:Y65
D5    12        q     d         .
E5    12        q     d         .
*               F   15
F5    12        q     d         .
measure 78
G5    12        q     d        (f
P    C33:Y60
F5     6        e     d        )
rest   6        e
rest  12        q
D5    12        q     d         .p
P    C34:Y60
measure 79
*               E   0
P    C17:Y63
F#5   12        q #   d         .
G5    12        q     d         .
A5    12        q     d         .
*               F   15
Bf5   12        q f   d         .
measure 80
C6    12        q     d        (f
P    C33:Y60
Bf5    6        e f   d        )
rest   6        e
rest  12        q
G5    12        q     d         .p
P    C34:Y57
measure 81
F#5   12        q #   d        (
G5    12        q     d        )
rest  12        q
A5    12        q     d         .mf
P    C34:Y60
measure 82
C6    12        q     d        (
Bf5   12        q f   d        )
rest  12        q
A5    12        q     d         .f
P    C34:Y60
measure 83
C6    12        q     d        (
Bf5   24        h f   d        )
A5    12        q     d         .
measure 84
A5    12        q     d        (
G#5   12        q #   d        )
rest  12        q
G#5   12        q     d         .
measure 85
B5    12        q n   d        (+
A5    12        q     d        )
rest  12        q
D#5   12        q #   d         .
measure 86
F#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
G#5   12        q #   d         .mf
P    C34:Y60
measure 87
B5    12        q     d        (
A5    12        q     d        )
rest  12        q
*               D       dim.
P  C25:f33  C17:Y68
D#5   12        q #   d         .
measure 88
F#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
D#5   12        q #   d         .p
P    C34:Y60
measure 89
F#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
D#5   12        q #   d         .pp
P    C34:Y60
measure 90
F#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
D#5   12        q #   d         .
measure 91
F#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
E5    12        q     d         .
measure 92
*               E   0
P    C17:Y63
G5    24        h n   d        (+
F#5   12        q #   d
*               F   15
F5    12        q n   d        )
measure 93
A5    24        h     d        (Z
P    C33:Y60
G5    12        q     d
F5    12        q     d        )
measure 94
gF5    0        e     u        (
D6    36        h.    d        )
C6     3        s     d  [[    (
B5     3        s     d  ]]    )
rest   6        e
measure 95
*               D       decresc.
P  C25:f33  C17:Y65
A5     3        s     d  [[    (
G5     3        s     d  ]]    )
rest   6        e
F5     3        s     d  [[    (
E5     3        s     d  ]]    )
rest   6        e
D5     3        s     d  [[    (
C5     3        s     d  ]]    )
rest   6        e
B4     3        s     u  [[    (
A4     3        s     u  ]]    )
rest   6        e
measure 96
G4     6        e     u  [      .
F4     6        e     u  =      .
E4     6        e     u  =      .
D4     6        e     u  ]      .
C4    12        q     u         .
B3    12        q     u         .
measure 97
Bf3   12        q f   u         .
A3    12        q     u         .
Af3   12        q f   u         .
G3    12        q     u         .p
P    C34:Y95
measure 98
C4    24        h     u
E4     9        e.    u  [     (
C4     3        s     u  =\    )
F4     9        e.    u  =     (
D4     3        s     u  ]\    )
measure 99
G4    21        q:    u        (Zp
P    C33:Y70
E4     3        s     u        )
C4     6        e     u
rest   6        e
E4     3        s     u  [[    (
D4     3        s     u  ==
C4     3        s     u  ==
D4     3        s     u  ]]    )
measure 100
*               D       cresc.
P  C25:f33  C17:Y73
E4     6        e     u         .
rest   6        e
F4     6        e     u         .
rest   6        e
G4     6        e     u         .
rest   6        e
A4     6        e     u         .
rest   6        e
measure 101
B4    12        q     d        (mf
C5     6        e     d        )
rest   6        e
rest  12        q
G#4   12        q #   u        (p
P    C33:Y57
measure 102
A4    21        q:    u        )
E4     3        s     u        (
F4     9        e.    u  [     )
C#4    3        s #   u  =\    (
D4     9        e.    u  =     )
F4     3        s     u  ]\
measure 103
C4    24        h n   u        (+
B3    12        q     u        )
B3     3        s     u  [[    (
A3     3        s     u  ==
G3     3        s     u  ==
A3     3        s     u  ]]    )
measure 104
G3    12        q     u         .
F4    12        q     u        (
E4    12        q     u
D4    12        q     u        )
measure 105
D#4   12        q #   u        (
E4     6        e     u        )
rest   6        e
rest  12        q
G4    12        q     u         f
measure 106
gG3    5        s     u  [[    (
gE4    5        s     u  ]]
C5    24        h     d        )
E5     9        e.    d  [     (
C5     3        s     d  =\    )
F5     9        e.    d  =     (
D5     3        s     d  ]\    )
measure 107
G5    21        q:    d        (
E5     3        s     d        )
C5     6        e     d
rest   6        e
E5     3        s     d  [[    (
D5     3        s     d  ==
C5     3        s     d  ==
D5     3        s     d  ]]    )
measure 108
E5     6        e     d  [      .
E5     6        e     d  ]      .
rest   6        e
F5     6        e     d         .
rest   6        e
G5     6        e     d         .
rest   6        e
A5     6        e     d         .
measure 109
B5    12        q     d        (
C6     6        e     d        )
rest   6        e
rest  12        q
G#5   12        q #   d        (mf
P    C33:Y60
measure 110
A5    21        q:    d        )
E5     3        s     d
F5     9        e.    d  [     (
C#5    3        s #   d  =\    )
D5     9        e.    d  =
F5     3        s     d  ]\
measure 111
C5    24        h n   d        (+
B4     6        e     d        )
rest   6        e
B4     3        s     u  [[    (
A4     3        s     u  ==
G4     3        s     u  ==
A4     3        s     u  ]]    )
measure 112
G4    12        q     u
F5    12        q     d        (
E5    12        q     d        )
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 113
C5    12        q     d
rest  12        q
rest  12        q
C5     3        s     d  [/    (
C6     9        e.    d  ]     )
measure 114
B5     3        s     d  [/    (
G5     9        e.    d  ]     )
F5     3        s     d  [/    (
D5     9        e.    d  ]     )
B4     3        s     u  [/    (
G4     9        e.    u  ]     )
F4     3        s     u  [/    (
D4     9        e.    u  ]     )
measure 115
C4    12        q     u         .
E4    12        q     u         .
rest  12        q
C5     4        e  3  d  [     (*
E5     4        e  3  d  =
C6     4        e  3  d  ]     )!
measure 116
B5     4        e  3  d  [      *.
A5     4        e  3  d  =      .
G5     4        e  3  d  ]      !.
F5     4        e  3  d  [      .
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
C5     4        e  3  d  [      .
B4     4        e  3  d  =      .
A4     4        e  3  d  ]      .
G4     4        e  3  u  [      .
A4     4        e  3  u  =      .
F4     4        e  3  u  ]      .
measure 117
E4    12        q     u        (
G4    12        q     u
C5    12        q     d
E5    12        q     d        )
measure 118
F4    12        q     u        (
A4    12        q     u
D5    12        q     d
F5    12        q     d        )Z
P    C33:Y60
measure 119
E5    24        h     d        (
D5     6        e     d        )
rest   3        s
G5     3        s     d
gA5    4        t     u  [[[   (
gG5    4        t     u  ===
gF#5   4        t     u  ]]]
G5    12        q     d        )
measure 120
C6    12        q     d         .
C6    12        q     d         .
C6    12        q     d         .
rest  12        q
measure 121
Af5   12        q f   d         .
*               D       dim.
P  C25:f33  C17:Y65
Af5   12        q     d         .
Af5   12        q     d         .
rest  12        q
measure 122
E5    12        q     d         p.
P    C33:Y58
E5    12        q     d         .
E5    12        q     d         .
rest  12        q
measure 123
F5    12        q n   d         +.
F5    12        q     d         .
E5    12        q     d         .
E5    12        q     d         .
measure 124
*               D       cresc.
P  C25:f33  C17:Y65
F5    12        q     d         .
F5    12        q     d         .
F#5   12        q #   d         .
F#5   12        q     d         .
measure 125
G5    12        q     d         .
G5    12        q     d         .
A5    12        q n   d         +
C6     3        s     d  [[    (
B5     3        s     d  ==
A5     3        s     d  ==
B5     3        s     d  ]]    )
measure 126
*               D       molto cresc.
P  C25:f33  C17:Y65
C6    12        q     d
E6     3        s     d  [[    (
D6     3        s     d  ==
C6     3        s     d  ==
D6     3        s     d  ]]    )
E6    12        q     d
G6     3        s     d  [[    (
F6     3        s n   d  ==     +
E6     3        s     d  ==
F6     3        s     d  ]]    )
measure 127
G6    12        q     d         f
P    C33:Y60
rest  12        q
A6    12        q     d
rest  12        q
measure 128
G3    12        q     u         ff
rest  24        h
A4     4        e  3  u  [     (*p
G4     4        e  3  u  =
B3     4        e  3  u  ]     )!
measure 129
*               E   0
C4    12        q     u         .
D4    12        q     u         .
E4    12        q     u         .
*               F   15
F#4   12        q #   u         .
measure 130
*               GE  15  Z
P   C17:Y70 C18:Y70
F#4   24        h #   u        (
*               F   0
G4    12        q     u        )
A4     4        e  3  u  [     (*p
G4     4        e  3  u  =
B3     4        e  3  u  ]     )!
measure 131
*               E   0
P    C17:Y78
C4    12        q     u         .
D4    12        q     u         .
E4    12        q     u         .
*               F   15
F#4   12        q #   u         .
measure 132
*               GE  15  Z
P   C17:Y70 C18:Y70
F#4   24        h #   u        (
G4    12        q     u        )
*               GF  0   p
P   C17:Y70
A4     4        e  3  u  [     (*
G4     4        e  3  u  =
B3     4        e  3  u  ]     )!
measure 133
*               E   15
C4    12        q     u         .
D4    12        q     u         .
*               F   0
Ef4   12        q f   u         .
Gf4   12        q f   u         .pp
measure 134
Gf4   48        w f   u        (
measure 135
F4    36        h.    u        )
*               D       cresc.
P  C25:f33
Af4    4        e f3  u  [     (*
F4     4        e  3  u  =     )
Df4    4        e f3  u  ]      !.
measure 136
C4     4        e  3  u  [     (
Ef4    4        e f3  u  =     )
Gf4    4        e f3  u  ]      .
Af4    4        e f3  u  [     (
Gf4    4        e  3  u  =     )
Ef4    4        e  3  u  ]      .
C4     4        e  3  u  [     (
Df4    4        e f3  u  =     )
F4     4        e  3  u  ]      .
Af4    4        e  3  u  [     (
F4     4        e  3  u  =     )
Df4    4        e  3  u  ]      .
measure 137
C4     4        e  3  u  [     (
Ef4    4        e f3  u  =     )
Gf4    4        e f3  u  ]      .
Af4    4        e f3  u  [     (
Gf4    4        e  3  u  =     )
Ef4    4        e  3  u  ]      .
C4     4        e  3  u  [     (f
Df4    4        e f3  u  =     )
F4     4        e  3  u  ]      .
Af4    4        e  3  u  [     (
F4     4        e  3  u  =     )
Df4    4        e  3  u  ]      .
measure 138
C4     4        e  3  u  [     (
Ef4    4        e f3  u  =     )
Gf4    4        e f3  u  ]      .
Af4    4        e f3  u  [     (
Gf4    4        e  3  u  =     )
Ef4    4        e  3  u  ]      .
C4     4        e  3  u  [     (
Df4    4        e f3  u  =     )
F4     4        e  3  u  ]      .
Af4    4        e  3  u  [     (
F4     4        e  3  u  =     )
Df4    4        e  3  u  ]      .
measure 139
Af3   12        q f   u         p
P    C33:Y80
rest  12        q
rest  12        q
Af4   12        q f   u         p
P    C33:Y55
measure 140
Af4   12        q f   u         .
Af4   12        q     u         .
Af4   12        q     u         .
*               E   0
P    C17:Y70
Af4   12        q     u         .
measure 141
A4    12        q n   u        (+
*               F   15
Bf4   12        q f   d        )
rest  12        q
Bf4   12        q     d         .mf
measure 142
C5    12        q     d        (
Df5    6        e f   d        )
rest   6        e
rest  12        q
Bf4   12        q f   d         p
P    C33:Y69
measure 143
Bf4   12        q f   d         .
Bf4   12        q     d         .
Bf4   12        q     d         .
*               E   0
P    C17:Y73
Bf4   12        q     d         .
measure 144
B4    12        q n   d        (+
*               F   15
C5    12        q     d        )
rest  12        q
C5    12        q     d         .mf
P    C34:Y65
measure 145
D5    12        q n   d        (+
Ef5    6        e f   d        )
rest   6        e
rest  12        q
Ef5   12        q     d
measure 146
*               E   0
P    C17:Y65
Ef5   12        q f   d        (.
Ef5   12        q     d         .
Ef5   12        q     d         .
*               F   15
Ef5   12        q     d        ).
measure 147
*               E   15
P    C17:Y65
Ef5   24        h f   d        (
*               F   0
D5    12        q     d        )
G5    12        q     d         p
P    C33:Y57
measure 148
F5    12        q     d
Ef5   12        q f   d        (.
Ef5   12        q     d         .
Ef5   12        q     d        ).
measure 149
Ef5   24        h f   d        (
D5    12        q     d        )
G5    12        q     d         f
P    C33:Y60
measure 150
G5    36        h.    d        (
A5    12        q n   d        )+
measure 151
G5    12        q     d
G3    12        q     u
G3    12        q     u
rest  12        q
measure 152
rest  48
measure 153
rest  24        h
rest  12        q
G4    12        q     u         mf
measure 154
C5    24        h     d
B4     9        e.    u  [     (
G4     3        s     u  ]\    )
C5     9        e.    d  [     (
A4     3        s     d  ]\    )
measure 155
D5    24        h     d
C5     9        e.    d  [     (
A4     3        s     d  ]\    )
D5     9        e.    d  [     (
B4     3        s     d  ]\    )
measure 156
E5     9        e.    d  [     (
C5     3        s     d  ]\    )
F5     9        e.    d  [     (
D5     3        s     d  ]\    )
G5    12        q     d         .
G5    12        q     d         .
measure 157
*               D       cresc.
P  C25:f33  C17:Y65
G5    48-       w     d        -
measure 158
G5    12        q     d
G5    12        q     d         .f
P    C34:Y62
G5    12        q     d         .
G5    12        q     d         .
measure 159
G5    12        q     d
G5     9        e.    d  [     (
E5     3        s     d  ]\    )
G5     9        e.    d  [     (
E5     3        s     d  ]\    )
G5     9        e.    d  [     (
E5     3        s     d  ]\    )
measure 160
G5    48-       w     d        -
measure 161
G5    12        q     d
G5     9        e.    d  [     (
C5     3        s     d  ]\    )
C6     9        e.    d  [     (
C5     3        s     d  ]\    )
Bf5    9        e.f   d  [     (
C5     3        s     d  ]\    )
measure 162
A5     9        e.    d  [      .
G#5    3        s #   d  =\     .
A5     9        e.    d  =      .
B5     3        s n   d  ]\     +.
C6     9        e.    d  [      .
E5     3        s     d  =\     .
F5     9        e.    d  =      .
G5     3        s n   d  ]\     .
measure 163
A5     9        e.    d  [      .
C#5    3        s #   d  =\     .
D5     9        e.    d  =      .
E5     3        s     d  ]\     .
F5     9        e.    d  [      .
G5     3        s     d  =\     .
A5     9        e.    d  =      .
F5     3        s     d  ]\     .
measure 164
E5     4        e  3  d  [     (*
G5     4        e  3  d  =
C6     4        e  3  d  ]     )!
B5     4        e  3  d  [      .
A5     4        e  3  d  =      .
G5     4        e  3  d  ]      .
F5     4        e  3  d  [      .
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
C5     4        e  3  d  [      .
B4     4        e  3  d  =      .
A4     4        e  3  d  ]      .
measure 165
G4    12        q     u
rest  24        h
A5     4        e  3  d  [     (*p
P    C34:Y58
G5     4        e  3  d  =
B4     4        e  3  d  ]     )!
measure 166
*               E   0
P    C17:Y65
C5    12        q     d         .
D5    12        q     d         .
E5    12        q     d         .
*               F   15
F#5   12        q #   d         .
measure 167
*               GE  15  Z
P   C17:Y65 C18:Y65
F#5   24        h #   d        (
G5    12        q     d        )
*               GF  0   p
P   C17:Y65
A5     4        e  3  d  [     (*
G5     4        e  3  d  =
B4     4        e  3  d  ]     )!
measure 168
*               E   0
P    C17:Y65
C5    12        q     d         .
D5    12        q     d         .
E5    12        q     d         .
*               F   15
F#5   12        q #   d         .
measure 169
*               GE  15  Z
P   C17:Y65 C18:Y65
F#5   24        h #   d        (
G5    12        q     d        )
*               GF  0   p
P   C17:Y65
A5     4        e  3  d  [     (*
G5     4        e  3  d  =
B4     4        e  3  d  ]     )!
measure 170
C5    12        q     d
rest  12        q
rest  12        q
A4     4        e  3  u  [     (*
G4     4        e  3  u  =
B4     4        e  3  u  ]     )!
measure 171
C5    12        q     d
rest  12        q
rest  12        q
*               D       cresc.
P  C25:f33  C17:Y75
A4     4        e  3  d  [     (*
G4     4        e  3  d  =
F5     4        e  3  d  ]     )!
measure 172
E5    12        q     d
rest  12        q
rest  12        q
A5     4        e  3  d  [     (*f
P    C34:Y60
G5     4        e  3  d  =
B5     4        e  3  d  ]     )!
measure 173
C6    12        q     d
rest  12        q
rest  12        q
B4    12        q     u         ff
 D4   12        q     u
 G3   12        q     u         .
measure 174
C5    12        q     u
 E4   12        q     u
 G3   12        q     u         .
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/01/02} [KHM:537739596]
TIMESTAMP: DEC/26/2001 [md5sum:6d561de4af4907a09751fc93f480eba6]
11/13/94 W Hewlett
WK#:64,1      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[First Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:12   T:0/0  C:4  D:Allegro moderato
rest  12        q
measure 1
rest  48
measure 2
rest  48
measure 3
rest  48
measure 4
rest  48
measure 5
rest  48
measure 6
rest  48
measure 7
rest  48
measure 8
rest  24        h
rest  12        q
G3    12        q     u         f
measure 9
C4    24        h     u
E4     9        e.    u  [     (
C4     3        s     u  ]\    )
F4     9        e.    u  [     (
D4     3        s     u  ]\    )
measure 10
G4    21        q:    u        (
E4     3        s     u        )
C4     6        e     u
rest   6        e
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 11
C5     6        e     d         .
rest   6        e
D5     6        e     d         .
rest   6        e
E5     6        e     d         .
rest   6        e
F5     6        e     d         .
rest   6        e
measure 12
F5    12        q     d        (
E5     6        e     d        )
rest   6        e
rest  24        h
measure 13
rest  12        q
C#4   12        q #   u        (mf
P    C33:Y85
D4     9        e.    u  [     )
E4     3        s     u  =\    (
F4     9        e.    u  =     )
F4     3        s     u  ]\
measure 14
E4    24        h     u        (
D4    12        q     u        )
C4    12        q n   u         +
measure 15
D4    12        q     u
D5    12        q     d        (
C5    12        q     d
F4    12        q     u        )
measure 16
E4     6        e     u  [     (
G3     6        e     u  =
E4     6        e     u  =
G3     6        e     u  ]     )
E4     6        e     u  [     (
G3     6        e     u  =
E4     6        e     u  =
G3     6        e     u  ]     )
measure 17
F4     6        e     u  [     (
G3     6        e     u  =
F4     6        e     u  =
G3     6        e     u  ]     )
F4     6        e     u  [     (
G3     6        e     u  =
F4     6        e     u  =
G3     6        e     u  ]     )
measure 18
E4     6        e     u  [     (
G3     6        e     u  =
E4     6        e     u  =
G3     6        e     u  ]     )
E4     6        e     u  [     (
G3     6        e     u  =
E4     6        e     u  =
G3     6        e     u  ]     )
measure 19
F4     6        e     u  [     (
G3     6        e     u  =
F4     6        e     u  =
G3     6        e     u  ]     )
F4     6        e     u  [     (
G3     6        e     u  =
F4     6        e     u  =
G3     6        e     u  ]     )
measure 20
E4    12        q     u
rest  12        q
rest  12        q
G4    12        q     u        (
measure 21
A4    12        q     u        )
rest  12        q
rest  12        q
D5    12        q     d         Z
P    C33:Y63
measure 22
C5    24        h     d        (
B4     6        e     d        )
rest   3        s
G4     3        s     u
gA4    4        t     u  [[[   (
gG4    4        t     u  ===
gF#4   4        t     u  ]]]
G4    12        q     u        )
measure 23
C5    12        q     d         .
C5    12        q     d         .
C5    12        q     d         .
rest  12        q
measure 24
A4    12        q     u         .
A4    12        q     u         .
A4    12        q     u         .
B4     3        s     u  [[    (
A4     3        s     u  ==
G4     3        s     u  ==
F4     3        s     u  ]]    )
measure 25
E4    24        h     u        (
D4    12        q     u        )
rest  12        q
measure 26
D4    24        h     u         f
 B3   24        h     u
G4    12        q     u         .
A4    12        q     u         .
measure 27
B4    12        q     d
rest  12        q
rest  24        h
measure 28
D4    48        w     u
measure 29
D4    12        q     u
rest  12        q
rest  24        h
measure 30
rest  12        q
rest   6        e
D4     6        e     u         .
F#4    6        e #   d  [      .
A4     6        e     d  =      .
C5     6        e     d  =      .
F#5    6        e #   d  ]      .
measure 31
A5    12        q     d
rest  12        q
rest  24        h
measure 32
rest  12        q
D5    24        h     d        (
C5    12        q     d        )
measure 33
B4    12        q     d
rest  12        q
rest  12        q
A4     3        s     u  [[    (
G4     3        s     u  ==
F#4    3        s #   u  ==
G4     3        s     u  ]]    )
measure 34
A4     6        e     u         .
rest   6        e
F#4    6        e #   u         .
rest   6        e
D4     6        e     u         .
rest   6        e
F#4    6        e     u         .
rest   6        e
measure 35
G4    12        q     u
rest  12        q
rest  12        q
A4     3        s     u  [[    (
G4     3        s     u  ==
F#4    3        s #   u  ==
G4     3        s     u  ]]    )
measure 36
A4     6        e     u         .
rest   6        e
F#4    6        e #   u         .
rest   6        e
D4     6        e     u         .
rest   6        e
F#4    6        e     u         .
rest   6        e
measure 37
G3     4        e  3  u  [      *
Bf3    4        e f3  u  =
D4     4        e  3  u  ]      !
G4     4        e  3  d  [      *
Bf4    4        e f3  d  =
D5     4        e  3  d  ]      !
G5    12        q     d
F5    12        q n   d         +
measure 38
Ef5   36        h.f   d        (
D5    12        q     d        )
measure 39
Ef5   12        q f   d
rest  12        q
rest  24        h
measure 40
A4    12        q     u         mf
rest  12        q
A4    12        q     u
rest  12        q
measure 41
A4    12        q     u
rest  12        q
A4    12        q     u
rest  12        q
measure 42
A4    12        q     u
rest  12        q
A4    12        q     u
rest  12        q
measure 43
A4    12        q     u
rest  12        q
A4    12        q     u
rest  12        q
measure 44
A4    12        q     u         p
P    C33:Y58
rest  12        q
A4    12        q     u
rest  12        q
measure 45
A4    12        q     u         .
A4    24        h     u         Zp
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 46
C5    12        q     d        (
A4    12        q     u        )
B4    12        q     d        (
G4    12        q     u        )
measure 47
F#4   12        q #   u
A4    24        h     u         Zp
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 48
C5    12        q     d        (
A4    12        q     u        )
B4    12        q     d
A4     3        s     u  [[    (
G4     3        s     u  ==
F#4    3        s #   u  ==
G4     3        s     u  ]]    )
measure 49
F#4   12        q #   u
rest  12        q
rest  24        h
measure 50
G3    24        h     u        (
E4    12        q     u        )
E4     9        e.    u  [     (
C4     3        s     u  ]\    )
measure 51
A3    36        h.    u
D4    12        q     u
measure 52
G3    12        q     u
rest  12        q
rest  24        h
measure 53
rest  12        q
*               D       cresc.
P  C25:f33  C17:Y68
C5     6        e     d         .
rest   6        e
A4     6        e     u         .
rest   6        e
B4     6        e     d         .
rest   6        e
measure 54
G4    12        q     u         f
 B3   12        q     u
rest  12        q
rest  12        q
F#4   12        q     u         p
P    C33:Y82
 A3   12        q #   u
measure 55
G4    12        q     u
 B3   12        q     u
rest  12        q
rest  12        q
G4    12        q     u         .
measure 56
*               GE  15  Z
P   C17:Y85 C18:Y85
G4    36        h.    u        (
*               GF  0   p
P   C17:Y85
F#4   12        q #   u
 A3   12        q     u        )
measure 57
G4    12        q     u
 B3   12        q     u
rest  12        q
rest  12        q
G4    12        q     u         .
measure 58
*               GE  15  Z
P   C17:Y85 C18:Y85
G4    36        h.    u        (
*               GF  0   p
P   C17:Y85
F#4   12        q #   u
 A3   12        q     u        )
measure 59
G4    12        q     u
 B3   12        q     u         .
F#4   12        q     u
 A3   12        q #   u         .
G4    12        q     u
 B3   12        q     u         .
F#4   12        q     u
 A3   12        q     u         .
measure 60
G4    12        q     u
 B3   12        q     u         .
rest  12        q
rest  12        q
mheavy2                      :|
rest  12        q
measure 61
*               D       mezzo voce
P  C25:f33  C17:Y65
rest  12        q
G4    12        q     u         .
G4    12        q     u         .
G4    12        q     u         .
measure 62
G4    12        q     u        (
E4    12        q     u
F#4   12        q #   u        )
rest  12        q
measure 63
rest  12        q
A4    12        q     u         .
A4    12        q     u         .
A4    12        q     u         .
measure 64
A4    12        q     u        (
F#4   12        q #   u
G4    12        q n   u        )+
F#4   12        q     u        (
measure 65
E4     6        e     u        )
rest   6        e
D5    12        q     d        (
C5     6        e     d        )
rest   6        e
B4    12        q     d        (
measure 66
A4     6        e     u        )
rest   6        e
C5    12        q     d         .
C5    12        q     d         .
C5    12        q     d         .
measure 67
B4    36        h.    d        (
Bf4   12        q f   d        )
measure 68
A4    12        q     u         .
A4    12        q     u         .
A4    12        q     u         .
A4    12        q     u         .
measure 69
G4    48        w     u
measure 70
A4    48        w     u
measure 71
Bf4   48        w f   d         Z
P    C33:Y60
measure 72
A4    48        w     u         Z
 Ef4  48        w f   u
measure 73
Bf4   48        w f   u         Z
 D4   48        w     u
measure 74
F4    48        w     u         Z
measure 75
F4    48        w     u         Z
measure 76
E4    36        h.    u         Z
C#4   12        q #   u         p
P    C33:Y73
measure 77
E4    12        q     u         .
*               E   0
P    C17:Y65
F4    12        q     u         .
G4    12        q     u         .
*               F   15
A4    12        q     u         .
measure 78
Bf4   12        q f   d        (f
A4     6        e     u        )
rest   6        e
rest  12        q
F#4   12        q #   u         .p
P    C34:Y65
measure 79
*               E   0
P    C17:Y67
A4    12        q     u         .
Bf4   12        q f   d         .
C5    12        q     d         .
*               F   15
D5    12        q     d         .
measure 80
Ef5   12        q f   d        (f
D5     6        e     d        )
rest   6        e
rest  12        q
D5    12        q     d         .p
P    C34:Y62
measure 81
Ef5   12        q f   d        (
D5    12        q     d        )
rest  12        q
D5    12        q     d         mf.
P    C33:Y62
measure 82
D5    24        h     d
rest  12        q
D5    12        q     d         .f
P    C34:Y63
measure 83
D5    24        h     d
D#5   24        h #   d         Z
P    C33:Y63
measure 84
D#5   12        q #   d        (
E5    12        q     d        )
rest  12        q
G#4   12        q #   u         .
measure 85
B4    12        q n   d        (+
A4    12        q     u        )
rest  12        q
D#4   12        q #   u         .
measure 86
F#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
G#4   12        q #   u         .mf
P    C34:Y63
measure 87
B4    12        q     d        (
A4    12        q     u        )
rest  12        q
*               D       dim.
P  C25:f33
D#4   12        q #   u         .
measure 88
F#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
D#4   12        q #   u         .p
P    C34:Y79
measure 89
F#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
D#4   12        q #   u         .pp
P    C34:Y76
measure 90
F#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
D#4   12        q #   u         .
measure 91
F#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
E4    12        q     u         .
measure 92
*               E   0
P    C17:Y72
G4    24        h n   u        (+
F#4   12        q #   u
*               F   15
F4    12        q n   u        )
measure 93
F4    48-       w     u        -Z
P    C33:Y77
 D4   48-       w     u        -
measure 94
F4    48        w     u
 D4   48        w     u
measure 95
rest  48
measure 96
rest  48
measure 97
rest  48
measure 98
rest  48
measure 99
rest  48
measure 100
rest  48
measure 101
rest  48
measure 102
rest  48
measure 103
rest  48
measure 104
rest  48
measure 105
rest  24        h
rest  12        q
G3    12        q     u         f
measure 106
C4    24        h     u
E4     9        e.    u  [     (
C4     3        s     u  =\    )
F4     9        e.    u  =     (
D4     3        s     u  ]\    )
measure 107
G4    21        q:    u        (
E4     3        s     u        )
C4     6        e     u
rest   6        e
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 108
C5     6        e     d  [      .
C5     6        e     d  ]      .
rest   6        e
D5     6        e     d         .
rest   6        e
E5     6        e     d         .
rest   6        e
F5     6        e     d         .
measure 109
F5    12        q     d        (
E5     6        e     d        )
rest   6        e
rest  24        h
measure 110
rest  12        q
C#4   12        q #   u        (mf
D4     9        e.    u  [     )
E4     3        s     u  =\    (
F4     9        e.    u  =     )
F4     3        s     u  ]\
measure 111
E4    24        h     u        (
D4    12        q     u        )
C4    12        q n   u         +
measure 112
D4    12        q     u
D5    12        q     d        (
C5    12        q     d
F4    12        q     u        )
measure 113
E4     6        e     u  [     (
G3     6        e     u  =     )
E4     6        e     u  =     (
G3     6        e     u  ]     )
E4     6        e     u  [     (
G3     6        e     u  =     )
E4     6        e     u  =     (
G3     6        e     u  ]     )
measure 114
F4     6        e     u  [     (
G3     6        e     u  =     )
F4     6        e     u  =     (
G3     6        e     u  ]     )
F4     6        e     u  [     (
G3     6        e     u  =     )
F4     6        e     u  =     (
G3     6        e     u  ]     )
measure 115
E4     6        e     u  [     (
G3     6        e     u  =     )
E4     6        e     u  =     (
G3     6        e     u  ]     )
E4     6        e     u  [     (
G3     6        e     u  =     )
E4     6        e     u  =     (
G3     6        e     u  ]     )
measure 116
F4     6        e     u  [     (
G3     6        e     u  =     )
F4     6        e     u  =     (
G3     6        e     u  ]     )
F4     6        e     u  [     (
G3     6        e     u  =     )
F4     6        e     u  =     (
G3     6        e     u  ]     )
measure 117
E4    12        q     u
rest  12        q
rest  12        q
G4    12        q     u        (
measure 118
A4    12        q     u        )
rest  12        q
rest  12        q
D5    12        q     d         Z
measure 119
C5    24        h     d        (
B4     6        e     d        )
rest   3        s
G4     3        s     u
gA4    4        t     u  [[[   (
gG4    4        t     u  ===
gF#4   4        t     u  ]]]
G4    12        q     u        )
measure 120
C5    12        q     d         .
C5    12        q     d         .
C5    12        q     d         .
rest  12        q
measure 121
Af4   12        q f   u         .
*               D       dim.
P  C25:f33  C17:Y65
Af4   12        q     u         .
Af4   12        q     u         .
rest  12        q
measure 122
E4    12        q     u         p.
P    C33:Y70
E4    12        q     u         .
E4    12        q     u         .
rest  12        q
measure 123
F4    12        q n   u         +.
F4    12        q     u         .
E4    12        q     u         .
E4    12        q     u         .
measure 124
*               D       cresc.
P  C25:f33  C17:Y70
F4    12        q     u         .
F4    12        q     u         .
F#4   12        q #   u         .
F#4   12        q     u         .
measure 125
G4    12        q     u         .
G4    12        q     u         .
A4    12        q n   u         +
C5     3        s     d  [[    (
B4     3        s     d  ==
A4     3        s     d  ==
B4     3        s     d  ]]    )
measure 126
*               D       molto cresc.
P  C25:f33  C17:Y70
C5    12        q     d
E5     3        s     d  [[    (
D5     3        s     d  ==
C5     3        s     d  ==
D5     3        s     d  ]]    )
E5    12        q     d
G5     3        s     d  [[    (
F5     3        s n   d  ==     +
E5     3        s     d  ==
F5     3        s     d  ]]    )
measure 127
G5    12        q     d         f
P    C33:Y60
rest  12        q
A5    12        q     d
rest  12        q
measure 128
E4    12        q     u         ff
 C4   12        q     u
rest  12        q
rest  12        q
F4    12        q     u         p
 D4   12        q     u
measure 129
E4    12        q     u
 C4   12        q     u
rest  12        q
rest  12        q
C4    12        q     u         .
measure 130
*               GE  15  Z
P   C17:Y87 C18:Y87
C4    36        h.    u        (
*               GF  0   p
P   C17:Y87
B3    12        q     u        )
measure 131
C4    12        q     u
rest  12        q
rest  12        q
C4    12        q     u         .
measure 132
*               GE  15  Z
P   C17:Y87 C18:Y87
C4    36        h.    u        (
*               GF  0   p
P   C17:Y87
B3    12        q     u        )
measure 133
C4    12        q     u
rest  12        q
rest  12        q
C4    12        q     u         pp
P    C33:Y73
measure 134
C4    48        w     u        (
measure 135
Df4   48        w f   u        )
measure 136
*               D       cresc.
P  C25:f33
Ef4   24        h f   u        (
Df4   24        h f   u        )
measure 137
C4    24        h     u        (
Df4   24        h f   u        )f
measure 138
Ef4   24        h f   u        (
Df4   24        h f   u        )
measure 139
C4    12        q     u
rest  12        q
rest  12        q
Gf4    3        s     u  [[    (p
F4     3        s     u  ==
Ef4    3        s f   u  ==
F4     3        s     u  ]]    )
measure 140
Gf4   12        q f   u         .
F4    12        q     u         .
Ef4   12        q f   u         .
*               E   0
Df4   12        q f   u         .
measure 141
C4    12        q     u        (
*               F   15
Df4   12        q f   u        )
rest  12        q
F4    12        q     u         .mf
P    C34:Y65
measure 142
A4    12        q n   u        (+
Bf4    6        e f   d        )
rest   6        e
rest  12        q
Af4    3        s     u  [[    (p
G4     3        s n   u  ==     +
F4     3        s     u  ==
G4     3        s     u  ]]    )
measure 143
Af4   12        q f   u         .
G4    12        q     u         .
F4    12        q     u         .
*               E   0
P    C17:Y75
Ef4   12        q f   u         .
measure 144
D4    12        q     u        (
*               F   15
Ef4   12        q f   u        )
rest  12        q
G4    12        q     u         .mf
P    C34:Y63
measure 145
B4    12        q n   d        (+
C5     6        e     d        )
rest   6        e
rest  12        q
C5    12        q     d
measure 146
*               E   0
P    C17:Y68
Bf4   12        q f   d        (
Af4   12        q f   u
G4    12        q     u
*               F   15
F#4   12        q #   u        )
measure 147
*               E   15
P    C17:Y68
F#4   24        h #   u        (
*               F   0
G4    12        q     u        )
rest  12        q
measure 148
rest  12        q
Af4   12        q f   u        (p
G4    12        q     u
F#4   12        q #   u        )
measure 149
F#4   24        h #   u        (
G4    12        q     u        )
F5    12        q n   d         +f
P    C34:Y60
measure 150
F5    24        h     d        (
Ef5   12        q f   d        )
C5     6        e     d  [     (
Ef5    6        e     d  ]     )
measure 151
Ef5   24        h f   d        (
D5    12        q     d        )
rest  12        q
measure 152
rest  48
measure 153
rest  48
measure 154
rest  12        q
C4    12        q     u         .mf
P    C34:Y80
G4    24        h     u
measure 155
F4     9        e.    u  [     (
D4     3        s     u  =\    )
G4     9        e.    u  =     (
E4     3        s     u  ]\    )
A4    12        q     u         .
B4    12        q     d         .
measure 156
C5    12        q     d
rest  12        q
G4    12        q     u         .
A4    12        q     u         .
measure 157
*               D       cresc.
P  C25:f33  C17:Y73
B4    12        q     d
D5     3        s     d  [[    (
C5     3        s     d  ==
B4     3        s     d  ==
C5     3        s     d  ]]    )
D5    12        q     d
F5     3        s     d  [[    (
E5     3        s     d  ==
D5     3        s     d  ==
E5     3        s     d  ]]    )
measure 158
F5    48        w     d         f
P    C33:Y61
measure 159
E5     6        e     d         .
rest   6        e
C5     6        e     d         .
rest   6        e
G4     6        e     u         .
rest   6        e
E4     6        e     u
rest   6        e
measure 160
F4    48        w     u
measure 161
E4    36        h.    u        (
G4    12        q     u        )
measure 162
A4    12        q     u
rest  12        q
rest  24        h
measure 163
rest   6        e
rest   3        s
E4     3        s     u  [/     .
F4     9        e.    u  =      .
C#4    3        s #   u  ]\     .
D4     9        e.    u  [      .
E4     3        s     u  =\     .
F4     9        e.    u  =      .
D4     3        s     u  ]\     .
measure 164
E4    48        w     u
measure 165
F4    12        q     u
rest  12        q
rest  12        q
F4    12        q     u         p
measure 166
E4    12        q     u
rest  12        q
rest  12        q
C5    12        q     d         .
measure 167
*               GE  15  Z
P   C17:Y72 C18:Y72
C5    36        h.    d        (
*               GF  0   p
P   C17:Y72
B4    12        q     u        )
 D4   12        q     u
measure 168
C5    12        q     u
 E4   12        q     u
rest  12        q
rest  12        q
C5    12        q     d         .
measure 169
*               GE  15  Z
P   C17:Y69 C18:Y69
C5    36        h.    d        (
*               GF  0   p
P   C17:Y69
B4    12        q     u        )
 D4   12        q     u
measure 170
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
F4    12        q     u
measure 171
E4    12        q     u
rest  12        q
rest  12        q
B3    12        q     u         mf
P    C33:Y78
measure 172
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
F4    12        q     u         f
measure 173
E4    12        q     u
rest  12        q
rest  12        q
B3     4        e  3  u  [      *ff.
P    C34:Y90
D4     4        e  3  u  =      .
F4     4        e  3  u  ]      !.
measure 174
E4    12        q     u         .
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/01/03} [KHM:537739596]
TIMESTAMP: DEC/26/2001 [md5sum:2ffac1d6db7d57088faebeef37a3d5fa]
11/13/94 W Hewlett
WK#:64,1      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[First Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:12   T:0/0  C:13  D:Allegro moderato
rest  12        q
measure 1
E3    24        h     u         p
P    C33:Y68
C3    12        q     u         .
D3    12        q     u         .
measure 2
E3    24        h     u
rest  12        q
C4     3        s     u  [[    (
B3     3        s     u  ==
A3     3        s     u  ==
B3     3        s     u  ]]    )
measure 3
*               D       cresc.
P  C25:f33  C17:Y72
C4     6        e     d         .
rest   6        e
D4     6        e     d         .
rest   6        e
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
measure 4
F4    12        q     d        (mf
P    C33:Y65
 D4   12        q     d
E4     6        e     d        )
 C4    6        e     d
rest   6        e
rest  24        h
measure 5
rest  12        q
C#3   12        q #   u        (p
P    C33:Y80
D3     9        e.    u  [     )
E3     3        s     u  =\    (
F3     9        e.    u  =     )
F3     3        s     u  ]\
measure 6
E3    24        h     u        (
D3    12        q     u        )
C3    12        q n   u         +
measure 7
D3    12        q     u
D4    12        q     d        (
C4    12        q     d
B3    12        q     u        )
measure 8
B3    12        q     u        (
C4     6        e     d        )
rest   3        s
C4     3        s     d        (
B3     9        e.    u  [     )
A3     3        s     u  =\    (
G3     9        e.    u  =     )
F3     3        s     u  ]\    (
measure 9
E3    24        h     u        )f
P    C33:Y70
C4    12        q     d        (
D4    12        q     d        )
measure 10
E4    24        h     d
rest  12        q
E4     3        s     d  [[    (
D4     3        s     d  ==
C4     3        s     d  ==
D4     3        s     d  ]]    )
measure 11
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
G4     6        e     d         .
rest   6        e
A4     6        e     d         .
rest   6        e
measure 12
D5    12        q     d        (
C5     6        e     d        )
rest   6        e
rest  12        q
G#4   12        q #   d        (mf
P    C33:Y60
measure 13
A4    21        q:    d        )
E4     3        s     d        (
F4     9        e.    d  [     )
C#4    3        s #   d  =\    (
D4     9        e.    d  =     )
F4     3        s     d  ]\
measure 14
C4    24        h n   d        (+
B3    12        q     u        )
B3     3        s     u  [[    (
A3     3        s     u  ==
G3     3        s     u  ==
A3     3        s     u  ]]    )
measure 15
G3    12        q     u
F4    12        q     d        (
E4    12        q     d        )
E4     3        s     d  [[    (
D4     3        s     d  ==
C4     3        s     d  ==
D4     3        s     d  ]]    )
measure 16
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
measure 17
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
measure 18
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  =     )
C4     6        e     u  =     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
measure 19
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
measure 20
C4    12        q     d        (
G3    12        q     u
C4    12        q     d
E4    12        q     d        )
measure 21
F3    12        q     u        (
A3    12        q     u
D4    12        q     d
F4    12        q     d        )Z
P    C33:Y60
measure 22
E4    24        h     d        (
D4    12        q     d        )
rest  12        q
measure 23
E3    12        q     u        (
G3    12        q     u
C4    12        q     d
E4    12        q     d        )
measure 24
F3    12        q     u        (
A3    12        q     u
D4    12        q     d
F4    12        q     d        )Z
P    C33:Y60
measure 25
G4    12        q     d
G3    12        q     u
G3    12        q     u
rest  12        q
measure 26
rest  48
measure 27
rest  24        h
rest  12        q
G3    12        q     u         f
measure 28
A3    12        q     u        (
G3    12        q     u
F#3   12        q #   u
G3    12        q     u        )
measure 29
A3    12        q     u         .
F#3   12        q #   u         .
rest  24        h
measure 30
F#4   12        q #   d         .
F#3   12        q #   u         .
rest  24        h
measure 31
F#4   12        q #   d         .
F#3   12        q #   u         .
rest  24        h
measure 32
rest  12        q
F#3   12        q #   u        (
G3    12        q     u
A3    12        q     u        )
measure 33
B3    12        q     u
rest  12        q
rest  24        h
measure 34
D3     4        e  3  u  [      *.
F#3    4        e #3  u  =      .
A3     4        e  3  u  ]      !.
D4     4        e  3  d  [      *.
F#4    4        e #3  d  =      .
A4     4        e  3  d  ]      !.
C5    12        q     d
C5    12        q     d
measure 35
Bf4   12        q f   d
rest  12        q
rest  24        h
measure 36
F#3   36        h.#   u
D4    12        q     d
measure 37
G3    12        q     u
rest  12        q
rest  24        h
measure 38
Bf4   48-       w f   d        -
measure 39
Bf4   12        q     d
rest  12        q
rest  24        h
measure 40
E4    12        q     d         mf
P    C33:Y60
rest  12        q
E4    12        q     d
rest  12        q
measure 41
D4    12        q     d
rest  12        q
D4    12        q     d
rest  12        q
measure 42
E4    12        q     d
rest  12        q
E4    12        q     d
rest  12        q
measure 43
D4    12        q     d
rest  12        q
D4    12        q     d
rest  12        q
measure 44
E4    12        q     d         p
P    C33:Y60
rest  12        q
E4    12        q     d
rest  12        q
measure 45
D4    12        q     d         .
rest  12        q
rest  24        h
measure 46
rest  48
measure 47
rest  48
measure 48
rest  48
measure 49
rest  48
measure 50
rest  48
measure 51
D4    12        q     d
F#3   24        h #   u        (
A3    12        q     u        )
measure 52
B3    12        q     u
*               D       cresc.
P  C25:f33  C17:Y68
F#4    9        e.#   d  [     (
D4     3        s     d  ]\    )
G4     9        e.    d  [     (
D4     3        s     d  ]\    )
A4     9        e.    d  [     (
D4     3        s     d  ]\    )
measure 53
B4    12        q     d
rest  12        q
rest  24        h
measure 54
B3    12        q     u         f
rest  12        q
rest  12        q
C4    12        q     d         p
P    C33:Y69
measure 55
B3    12        q     u
rest  12        q
rest  12        q
A#3   12        q #   u         .
measure 56
*               EG  15  Z
P   C17:Y72 C18:Y72
A#3   24        h #   u        (
B3    12        q     u        )
*               FG  0   p
P   C18:Y72
C4    12        q     d         .
measure 57
B3    12        q     u
rest  12        q
rest  12        q
A#3   12        q #   u         .
measure 58
*               GE  15  Z
P   C17:Y70 C18:Y70
A#3   24        h #   u        (
B3    12        q     u        )
*               GF  0   p
P   C17:Y70
C4    12        q     d
measure 59
B3    12        q     u         .
C4    12        q     d         .
B3    12        q     u         .
C4    12        q     d         .
measure 60
B3    12        q     u         .
rest  12        q
rest  12        q
mheavy2                      :|
*               D       mezzo voce
P  C25:f33
E4     4        e  3  u  [     (*
D4     4        e  3  u  =
F#3    4        e #3  u  ]     )!
measure 61
G3    12        q     u         .
A3    12        q     u         .
B3    12        q     u         .
C4    12        q     d         .
measure 62
C#4   24        h #   d        (
D4    12        q     d        )
F4     4        e n3  d  [     (*+
E4     4        e  3  d  =
G#3    4        e #3  d  ]     )!
measure 63
A3    12        q     u         .
B3    12        q     u         .
C4    12        q n   d         +.
D4    12        q     d         .
measure 64
D#4   24        h #   d        (
E4    12        q     d        )
rest  12        q
measure 65
rest  12        q
A4     4        e  3  d  [     (*
G4     4        e n3  d  =      +
B3     4        e  3  d  ]     )!
C4    12        q     d
rest  12        q
measure 66
rest  12        q
A4    12        q     d         .
A4    12        q     d         .
A4    12        q     d         .
measure 67
A4    12        q     d        (
F#4   12        q #   d
G4    12        q     d        )
G4    12        q     d
measure 68
G4    24        h     d        (
F4    24        h n   d        )+
measure 69
F4    24        h     d        (
E4    24        h     d        )
measure 70
G4    24        h     d        (
F4    24        h     d        )
measure 71
F4    48        w     d         Z
P    C33:Y60
measure 72
F4    48        w     d         Z
P    C33:Y60
measure 73
F4    48        w     d         Z
P    C33:Y60
measure 74
D4    48        w     d         Z
P    C33:Y60
measure 75
D4    48        w     d         Z
P    C33:Y60
measure 76
C#4   36        h.#   d         Z
rest  12        q
measure 77
rest  12        q
*               E   0
P    C17:Y70
A3    12        q     u         .
G3    12        q     u         .
*               F   15
F3    12        q     u         .
measure 78
E3    12        q     u        (f
F3     6        e     u        )
rest   6        e
rest  24        h
measure 79
rest  12        q
*               E   0
P    C17:Y70
D4    12        q     d         .
C4    12        q n   d         +.
*               F   15
Bf3   12        q f   u         .
measure 80
A3    12        q     u        (f
P    C33:Y65
Bf3    6        e f   u        )
rest   6        e
rest  12        q
Bf4   12        q f   d         p
P    C33:Y57
measure 81
C5    12        q     d        (
Bf4   12        q f   d        )
rest  12        q
F#4   12        q #   d         mf.
P    C33:Y60
measure 82
A4    12        q     d        (
G4    12        q     d        )
rest  24        h
measure 83
rest  24        h
rest  12        q
A4    12        q     d         f
P    C33:Y60
measure 84
C5    12        q     d        (
B4    12        q n   d        )+
F4    24        h n   d         +
measure 85
E4    24        h     d        (
C4    24        h     d        )
measure 86
B3    24        h     u
F4    24        h     d        (mf
P    C33:Y60
measure 87
E4    24        h     d        )
C4    24        h     d
measure 88
rest  12        q
*               D       dim.
P  C25:f33  C17:Y70
B3    12        q     u         .
D4    12        q     d        (
C4    12        q     d        )
measure 89
rest  12        q
B3    12        q     u         .p
D4    12        q     d        (
C4    12        q     d        )
measure 90
rest  12        q
B3    12        q     u         .pp
D4    12        q     d        (
C4    12        q     d        )
measure 91
rest  48
measure 92
rest  48
measure 93
B3    48-       w     u        -Z
measure 94
B3    48        w     u
measure 95
rest  48
measure 96
rest  48
measure 97
rest  48
measure 98
E3    24        h     u         p
P    C33:Y68
C3    12        q     u         .
D3    12        q     u         .
measure 99
E3    24        h     u
rest  12        q
C4     3        s     u  [[    (
B3     3        s     u  ==
A3     3        s     u  ==
B3     3        s     u  ]]    )
measure 100
*               D       cresc.
P  C25:f33  C17:Y73
C4     6        e     d         .
rest   6        e
D4     6        e     d         .
rest   6        e
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
measure 101
F4    12        q     d        (mf
 D4   12        q     d        [
E4     6        e     d        )
 C4    6        e     d        ]
rest   6        e
rest  24        h
measure 102
rest  12        q
C#3   12        q #   u        (p
P    C33:Y83
D3     9        e.    u  [     )
E3     3        s     u  =\    (
F3     9        e.    u  =     )
F3     3        s     u  ]\
measure 103
E3    24        h     u        (
D3    12        q     u        )
C3    12        q n   u         +
measure 104
D3    12        q     u         .
D4    12        q     d        (
C4    12        q     d
B3    12        q     u        )
measure 105
B3    12        q     u        (
C4     6        e     d        )
rest   3        s
C4     3        s     d        (
B3     9        e.    u  [     )
A3     3        s     u  =\    (
G3     9        e.    u  =     )
F3     3        s     u  ]\    (
measure 106
E3    24        h     u        )f
P    C33:Y73
C4    12        q     d        (
D4    12        q     d        )
measure 107
E4    24        h     d
rest  12        q
E4     3        s     d  [[    (
D4     3        s     d  ==
C4     3        s     d  ==
D4     3        s     d  ]]    )
measure 108
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
G4     6        e     d         .
rest   6        e
A4     6        e     d         .
rest   6        e
measure 109
D5    12        q     d        (
C5     6        e     d        )
rest   6        e
rest  12        q
G#4   12        q #   d        (mf
P    C33:Y60
measure 110
A4    21        q:    d        )
E4     3        s     d        (
F4     9        e.    d  [     )
C#4    3        s #   d  ]\    (
D4     9        e.    d  [     )
F4     3        s     d  ]\
measure 111
C4    24        h n   d        (+
B3    12        q     u        )
B3     3        s     u  [[    (
A3     3        s     u  ==
G3     3        s     u  ==
A3     3        s     u  ]]    )
measure 112
G3    12        q     u
F4    12        q     d        (
E4    12        q     d        )
E4     3        s     d  [[    (
D4     3        s     d  ==
C4     3        s     d  ==
D4     3        s     d  ]]    )
measure 113
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
measure 114
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
measure 115
C4     6        e     u  [     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  =     )
C4     6        e     u  =     (
G3     6        e     u  =
C4     6        e     u  =
G3     6        e     u  ]     )
measure 116
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
D4     6        e     u  [     (
G3     6        e     u  =
D4     6        e     u  =
G3     6        e     u  ]     )
measure 117
C4    12        q     d        (
G3    12        q     u
C4    12        q     d
E4    12        q     d        )
measure 118
F3    12        q     u        (
A3    12        q     u
D4    12        q     d
F4    12        q     d        )Z
P    C33:Y60
measure 119
E4    24        h     d        (
D4    12        q     d        )
rest  12        q
measure 120
Ef3   12        q f   u        (
G3    12        q     u
C4    12        q     d
Ef4   12        q f   d        )
measure 121
F3    12        q n   u        (+
*               D       dim.
P  C25:f33  C17:Y68
Af3   12        q f   u
Df4   12        q f   d
F4    12        q     d        )
measure 122
G3    12        q     u        (p
Bf3   12        q f   u
Df4   12        q f   d
E4    12        q n   d        )+
measure 123
Af3   12        q f   u        (
C4    12        q     d        )
G3    12        q     u        (
C4    12        q     d        )
measure 124
*               D       cresc.
P  C25:f33  C17:Y73
Af3   12        q f   u        (
C4    12        q     d        )
A3    12        q n   u        (
C4    12        q     d        )
measure 125
B3    12        q n   u        (+
G3    12        q     u        )
F4    12        q     d         .
D4    12        q     d         .
measure 126
*               D       molto cresc.
P  C25:f33  C17:Y73
E4    12        q     d         .
B3    12        q     u         .
C4    12        q     d         .
D4    12        q     d         .
measure 127
E4    12        q     d         f
P    C33:Y63
rest  12        q
F4    12        q     d
rest  12        q
measure 128
E4    12        q     d         ff
P    C33:Y68
 C4   12        q     d
rest  12        q
rest  12        q
B3    12        q     u         p
measure 129
C4    12        q     d
rest  12        q
rest  12        q
D#3   12        q #   u         .
measure 130
*               GE  15  Z
P   C17:Y85 C18:Y85
D#3   24        h #   u        (
E3    12        q     u        )
*               GF  0   p
P   C17:Y85
F3    12        q n   u         +
measure 131
E3    12        q     u
rest  12        q
rest  12        q
D#3   12        q #   u         .
measure 132
*               GE  15  Z
P   C17:Y85 C18:Y85
D#3   24        h #   u        (
E3    12        q     u        )
*               GF  0   p
P   C17:Y85
F3    12        q n   u         +
measure 133
Ef3   12        q f   u
rest  12        q
rest  12        q
Ef3   12        q     u         pp
P    C33:Y67
measure 134
Ef3   48        w f   u        (
measure 135
F3    48        w     u        )
measure 136
*               D       cresc.
P  C25:f33  C17:Y74
Gf3   24        h f   u        (
F3    24        h     u        )
measure 137
Ef3   24        h f   u        (
F3    24        h     u        )f
measure 138
Gf3   24        h f   u        (
F3    24        h     u        )
measure 139
Ef3   12        q f   u
rest  12        q
rest  24        h
measure 140
rest  24        h
rest  12        q
*               GE  0   p
P   C17:Y67 C18:Y67
Df4   12        q f   d
measure 141
Ef4   12        q f   d        (
*               F   15
F4    12        q     d        )
rest  12        q
F4    12        q     d         .mf
measure 142
Ef4   12        q f   d        (
F4     6        e     d        )
rest   6        e
rest  24        h
measure 143
rest  24        h
rest  12        q
*               GE  0   p
P   C17:Y65 C18:Y65
Ef4   12        q f   d         .
measure 144
F4    12        q     d        (
*               F   15
G4    12        q     d        )
rest  12        q
G4    12        q     d         .mf
measure 145
F4    12        q     d        (
G4     6        e     d        )
rest   6        e
rest  24        h
measure 146
rest  12        q
*               E   0
P    C17:Y72
Ef3    6        e f   u  [     (
F3     6        e     u  ]     )
G3    12        q     u         .
*               F   15
Af3   12        q f   u         .
measure 147
*               E   15
P    C17:Y70
Af3   24        h f   u        (
*               F   0
G3    12        q     u        )
rest  12        q
measure 148
rest  12        q
Ef3    6        e f   u  [     (p
P    C33:Y71
F3     6        e     u  ]     )
G3    12        q     u         .
Af3   12        q f   u         .
measure 149
Af3   24        h f   u        (
G3    12        q     u        )
D5    12        q     d         f
P    C33:Y60
measure 150
D5    24        h     d        (
C5    12        q     d        )
Ef5    6        e f   d  [     (
C5     6        e     d  ]     )
measure 151
C5    24        h     d        (
B4    12        q     d        )
G3    12        q     u         .mf
P    C34:Y66
measure 152
C4    24        h     d
B3     9        e.    u  [     (
G3     3        s     u  ]\    )
C4     9        e.    u  [     (
A3     3        s     u  ]\    )
measure 153
D4    24        h     d
C4     9        e.    u  [     (
A3     3        s     u  ]\    )
D4     9        e.    d  [     (
B3     3        s     d  ]\    )
measure 154
E4    12        q     d         .
F#4   12        q #   d         .
G4    12        q     d         .
rest  12        q
measure 155
rest  48
measure 156
rest  48
measure 157
rest  48
measure 158
rest  12        q
B3     9        e.    u  [     (f
P    C33:Y65
G3     3        s     u  ]\    )
B3     9        e.    u  [     (
G3     3        s     u  =\    )
B3     9        e.    u  =     (
G3     3        s     u  ]\    )
measure 159
C4    48        w     d
measure 160
B3    12        q     u
B3     9        e.    u  [     (
G3     3        s     u  ]\    )
B3     9        e.    u  [     (
G3     3        s     u  =\    )
B3     9        e.    u  =     (
G3     3        s     u  ]\    )
measure 161
Bf3   36        h.f   u        (Z
C4    12        q     d        )
measure 162
C4    12        q     d
rest  12        q
rest   6        e
rest   3        s
C#4    3        s #   d  [/     .
D4     9        e.    d  =      .
E4     3        s     d  ]\     .
measure 163
F4    12        q     d
rest  12        q
rest  24        h
measure 164
C4    48        w n   d         +
measure 165
D4    12        q     d
 B3   12        q n   d         +
rest  12        q
rest  12        q
D4    12        q     d         p
P    C33:Y63
measure 166
E4    12        q     d
rest  12        q
rest  12        q
D#4   12        q #   d         .
measure 167
*               GE  15  Z
P   C17:Y65 C18:Y65
D#4   24        h #   d        (
E4    12        q     d        )
*               GF  0   p
P   C17:Y65
F4    12        q n   d         +
measure 168
E4    12        q     d
rest  12        q
rest  12        q
D#4   12        q #   d         .
measure 169
*               GE  15  Z
P   C17:Y65 C18:Y65
D#4   24        h #   d        (
E4    12        q     d        )
*               GF  0   p
P   C17:Y65
F4    12        q n   d         +
measure 170
E4    12        q     d
rest  12        q
rest  12        q
D4    12        q n   d         +
measure 171
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
*               D       cresc.
P  C25:f33  C17:Y75
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
C4     4        e  3  u  [      *.
E4     4        e  3  u  =      .
G3     4        e  3  u  ]      !.
D4    12        q     d
measure 172
E4    12        q     d
rest  12        q
rest  12        q
D4    12        q     d         f
P    C33:Y65
measure 173
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
C4     4        e  3  u  [      *
E4     4        e  3  u  =
G3     4        e  3  u  ]      !
D4    12        q     d         ff
P    C33:Y65
measure 174
E4    12        q     d         .
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op64n1/stage2/01/04} [KHM:537739596]
TIMESTAMP: DEC/26/2001 [md5sum:4e4ecab6f189dfa737b5909e66e3d74e]
11/13/94 W Hewlett
WK#:64,1      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op. 64, No. 1, in C Major
[First Movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:12   T:0/0  C:22  D:Allegro moderato
rest  12        q
measure 1
C2    12        q     u         p.
P    C33:Y89
C3    12        q     u         .
rest  24        h
measure 2
C2    12        q     u         .
C3    12        q     u         .
rest  12        q
G3    12        q     d
measure 3
C3    12        q     u
rest  12        q
rest  24        h
measure 4
G3    12        q     d        (mf
P    C33:Y60
A3     6        e     d        )
rest   6        e
rest  24        h
measure 5
F2    48        w     u        (p
P    C33:Y73
measure 6
G2    36        h.    u        )
A2    12        q     u
measure 7
B2    24        h     u
rest  12        q
G3    12        q     d
measure 8
C3    12        q     u
rest   6        e
rest   3        s
A2     3        s     u        (
G2     9        e.    u  [     )
F2     3        s     u  =\    (
E2     9        e.    u  =     )
D2     3        s     u  ]\    (
measure 9
C2    12        q     u        )f
P    C33:Y88
C3    12        q     u
rest  24        h
measure 10
rest  24        h
rest  12        q
G3    12        q     d
measure 11
C4     6        e     d         .
rest   6        e
D4     6        e     d         .
rest   6        e
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
measure 12
G4    12        q     d        (
A4     6        e     d        )
rest   6        e
rest  24        h
measure 13
F3    48        w     d        (mf
P    C33:Y60
measure 14
G3    36        h.    d        )
A3    12        q     d
measure 15
B3    12        q     d
rest  12        q
rest  12        q
G3    12        q     d
measure 16
C2     6        e     u         .
rest   6        e
E2     6        e     u         .
rest   6        e
G2     6        e     u         .
rest   6        e
C3     6        e     u         .
rest   6        e
measure 17
C2    12        q     u         .
rest  12        q
rest  24        h
measure 18
C2     6        e     u         .
rest   6        e
E2     6        e     u         .
rest   6        e
G2     6        e     u         .
rest   6        e
C3     6        e     u         .
rest   6        e
measure 19
C2    12        q     u
rest  12        q
rest  24        h
measure 20
C3    12        q     u
rest  12        q
rest  12        q
C3    12        q     u        (
measure 21
F3    12        q     d        )
rest  12        q
rest  12        q
D3    12        q     d        (Z
measure 22
G3    12        q     d        )
G2    12        q     u
G2    12        q     u
rest  12        q
measure 23
E2    12        q     u        (
G2    12        q     u
C3    12        q     u
E3    12        q     d        )
measure 24
F2    12        q     u        (
A2    12        q     u
D3    12        q     d
F3    12        q     d        )Z
P    C33:Y62
measure 25
G3    12        q     d
G2    12        q     u
G2    12        q     u
rest  12        q
measure 26
G3    12        q     d         f.
P    C33:Y60
G2    12        q     u         .
rest  24        h
measure 27
rest  48
measure 28
rest  48
measure 29
D3    12        q     d         .
D2    12        q     u         .
rest  24        h
measure 30
D3    12        q     d         .
D2    12        q     u         .
rest  24        h
measure 31
D3    12        q     d         .
D2    12        q     u         .
rest  24        h
measure 32
D2    12        q     u
D3    12        q     d        (
E3    12        q     d
F#3   12        q #   d        )
measure 33
G3    12        q     d
rest  12        q
rest  24        h
measure 34
rest  48
measure 35
rest  48
measure 36
D2     4        e  3  u  [      *.
F#2    4        e #3  u  =      .
A2     4        e  3  u  ]      !.
D3     4        e  3  d  [      *.
F#3    4        e #3  d  =      .
A3     4        e  3  d  ]      !.
C4    12        q     d
C4    12        q     d
measure 37
Bf3   12        q f   d
rest  12        q
rest  24        h
measure 38
Ef2    4        e f3  u  [      .
G2     4        e  3  u  =      .
Bf2    4        e f3  u  ]      .
Ef3    4        e f3  d  [      .
G3     4        e  3  d  =      .
Bf3    4        e f3  d  ]      .
Ef4   12        q f   d
F4    12        q n   d         +
measure 39
G4    12        q     d
rest  12        q
rest  24        h
measure 40
G3    12        q     d         mf
P    C33:Y60
rest  12        q
G3    12        q     d
rest  12        q
measure 41
F#3   12        q #   d
rest  12        q
F#3   12        q     d
rest  12        q
measure 42
G3    12        q     d
rest  12        q
G3    12        q     d
rest  12        q
measure 43
F#3   12        q #   d
rest  12        q
F#3   12        q     d
rest  12        q
measure 44
G3    12        q     d         p
P    C33:Y58
rest  12        q
G3    12        q     d
rest  12        q
measure 45
F#3   12        q #   d         .
F#3   24        h     d        (Zp
P    C33:Y62
G#3   12        q #   d        )
measure 46
A3    12        q     d        (
F#3   12        q #   d        )
G3    12        q n   d        (+
E3    12        q     d        )
measure 47
D3    12        q     d         .
F#3   24        h #   d        (Zp
P    C33:Y62
G#3   12        q #   d        )
measure 48
A3    12        q     d        (
F#3   12        q #   d        )
G3    12        q n   d         +.
E3    12        q     d         .
measure 49
D3    12        q     d         .
D3    12        q     d        (
C3    12        q     u
B2    12        q     u        )
measure 50
C3    12        q     u
C2    12        q     u
C3    12        q     u
C3    12        q     u
measure 51
C3    36        h.    u
C4    12        q     d        (
measure 52
B3    12        q     d        )
rest  12        q
rest  24        h
measure 53
rest  48
measure 54
D3    12        q     d         f
rest  12        q
rest  12        q
D3    12        q     d         p
measure 55
G3    12        q     d
rest  12        q
rest  12        q
E3    12        q     d         .
measure 56
*               GE  15  Z
D3    36        h.    d
*               GF  0   p
D2    12        q     u
measure 57
G2    12        q     u
rest  12        q
rest  12        q
E3    12        q     d         .
measure 58
*               GE  15  Z
D3    36        h.    d
*               GF  0   p
D2    12        q     u
measure 59
G2    12        q     u         .
D2    12        q     u         .
G2    12        q     u         .
D2    12        q     u         .
measure 60
G2    12        q     u         .
rest  12        q
rest  12        q
mheavy2                      :|
rest  12        q
measure 61
rest  48
measure 62
rest  48
measure 63
rest  48
measure 64
rest  24        h
rest  12        q
*               D       mezzo voce
P  C25:f33  C17:Y70
C4     4        e  3  d  [     (*
B3     4        e  3  d  =
D#3    4        e #3  d  ]     )!
measure 65
E3    12        q     d
rest  12        q
rest  12        q
F3     4        e n3  u  [     (*+
E3     4        e  3  u  =
G#2    4        e #3  u  ]     )!
measure 66
A2    12        q     u         .
B2    12        q     u         .
C3    12        q     u         .
D3    12        q n   d         .+
measure 67
D#3   24        h #   d        (
E3    12        q     d        )
D4     4        e n3  d  [     (*+
C4     4        e  3  d  =
E3     4        e  3  d  ]     )!
measure 68
F3    12        q     d         .
G3    12        q     d         .
A3    12        q     d         .
Bf3   12        q f   d         .
measure 69
B3    24        h n   d        (+
C4    24        h     d        )
measure 70
C#4   24        h #   d        (
D4    24        h     d        )
measure 71
D3    48        w     d         Z
P    C33:Y60
measure 72
C3    48        w     u         Z
measure 73
Bf2   48        w f   u         Z
measure 74
A2    48        w     u         Z
measure 75
G#2   48        w #   u         Z
measure 76
A2    36        h.    u         Z
Bf3    3        s     d  [[    (p
P    C33:Y59
A3     3        s     d  ==
G3     3        s     d  ==
A3     3        s     d  ]]    )
measure 77
G3    12        q     d         .
*               E   0
P    C17:Y73
F3    12        q     d         .
E3    12        q     d         .
*               F   15
D3    12        q     d         .
measure 78
C#3   12        q #   u        (f
D3    12        q     d        )
rest  12        q
Ef4    3        s     d  [[    (p
P    C33:Y57
D4     3        s     d  ==
C4     3        s     d  ==
D4     3        s     d  ]]    )
measure 79
*               E   0
P    C17:Y64
C4    12        q     d         .
Bf3   12        q f   d         .
A3    12        q     d         .
*               F   15
G3    12        q     d         .
measure 80
F#3   12        q #   d        (f
P    C33:Y63
G3     6        e     d        )
rest   6        e
rest  24        h
measure 81
rest  48
measure 82
rest  24        h
rest  12        q
F#4   12        q #   d         f
P    C33:Y60
measure 83
G4    24        h     d        (
F4    24        h n   d        )+
measure 84
E4    24        h     d        (
D4    24        h     d        )
measure 85
C4    24        h     d        (
A3    24        h     d        )
measure 86
G#3   24        h #   d
D4    24        h     d        (mf
P    C33:Y60
measure 87
C4    24        h     d        )
A3    24        h     d
measure 88
rest  12        q
*               D       dim.
P  C25:f33  C17:Y65
G#3   12        q #   d         .
B3    12        q     d        (
A3    12        q     d        )
measure 89
rest  12        q
G#3   12        q #   d         .p
P    C34:Y57
B3    12        q     d        (
A3    12        q     d        )
measure 90
rest  12        q
G#3   12        q #   d         .pp
P    C34:Y59
B3    12        q     d        (
A3    12        q     d        )
measure 91
rest  48
measure 92
rest  48
measure 93
G2    48-       w n   u        -+Z
P    C34:Y72
measure 94
G2    48        w     u
measure 95
rest  48
measure 96
rest  48
measure 97
rest  48
measure 98
C2    12        q     u         .
C3    12        q     u         .
rest  24        h
measure 99
C2    12        q     u         .
C3    12        q     u         .
rest  12        q
G3    12        q     d
measure 100
C3    12        q     u
rest  12        q
rest  24        h
measure 101
G3    12        q     d        (mf
P    C33:Y60
A3     6        e     d        )
rest   6        e
rest  24        h
measure 102
F2    48        w     u        (p
measure 103
G2    36        h.    u        )
A2    12        q     u
measure 104
B2    24        h     u
rest  12        q
G3    12        q     d
measure 105
C3    12        q     u
rest   6        e
rest   3        s
A2     3        s     u        (
G2     9        e.    u  [     )
F2     3        s     u  =\    (
E2     9        e.    u  =     )
D2     3        s     u  ]\    (
measure 106
C2    12        q     u        )f
P    C33:Y88
C3    12        q     u
rest  24        h
measure 107
rest  24        h
rest  12        q
G3    12        q     d
measure 108
C4     6        e     d         .
rest   6        e
D4     6        e     d         .
rest   6        e
E4     6        e     d         .
rest   6        e
F4     6        e     d         .
rest   6        e
measure 109
G4    12        q     d        (
A4     6        e     d        )
rest   6        e
rest  24        h
measure 110
F3    48        w     d        (mf
P    C33:Y60
measure 111
G3    36        h.    d        )
A3    12        q     d
measure 112
B3    12        q     d
rest  12        q
rest  12        q
G3    12        q     d
measure 113
C2     6        e     u         .
rest   6        e
E2     6        e     u         .
rest   6        e
G2     6        e     u         .
rest   6        e
C3     6        e     u         .
rest   6        e
measure 114
C2    12        q     u
rest  12        q
rest  24        h
measure 115
C2     4        e  3  u  [      *.
E2     4        e  3  u  =      .
G2     4        e  3  u  ]      !.
C3     4        e  3  d  [      *.
E3     4        e  3  d  =      .
G3     4        e  3  d  ]      !.
C4    12        q     d
C4    12        q     d
measure 116
C2    12        q     u
rest  12        q
rest  24        h
measure 117
C3    12        q     u
rest  12        q
rest  12        q
C3    12        q     u        (
measure 118
F3    12        q     d        )
rest  12        q
rest  12        q
D3    12        q     d        (Z
P    C33:Y68
measure 119
G3    12        q     d        )
G2    12        q     u
G2    12        q     u
rest  12        q
measure 120
Ef2   12        q f   u        (
G2    12        q     u
C3    12        q     u
Ef3   12        q f   d        )
measure 121
F2    12        q n   u        (+
*               D       dim.
P  C25:f33  C17:Y70
Af2   12        q f   u
Df3   12        q f   d
F3    12        q     d        )
measure 122
G2    12        q     u        (p
P    C33:Y63
Bf2   12        q f   u
Df3   12        q f   d
E3    12        q n   d        )+
measure 123
Af2   12        q f   u        (
C3    12        q     u        )
G2    12        q     u        (
C3    12        q     u        )
measure 124
*               D       cresc.
P  C25:f33  C17:Y68
Af2   12        q f   u        (
C3    12        q     u        )
A2    12        q n   u        (
C3    12        q     u        )
measure 125
B2    12        q n   u        (+
G2    12        q     u        )
rest  24        h
measure 126
rest  48
measure 127
rest  48
measure 128
G2    12        q     u         ff
rest  12        q
rest  12        q
G2    12        q     u         p
P    C33:Y62
measure 129
C3    12        q     u
rest  12        q
rest  12        q
A2    12        q     u         .
measure 130
*               GE  15  Z
P   C17:Y65 C18:Y65
G2    36        h.    u
*               GF  0   p
P   C17:Y65
G2    12        q     u
measure 131
C3    12        q     u
rest  12        q
rest  12        q
A2    12        q     u         .
measure 132
*               GE  15  Z
P   C17:Y65 C18:Y65
G2    36        h.    u
*               GF  0   p
P   C17:Y65
G2    12        q     u
measure 133
Af2   12        q f   u
rest  12        q
rest  12        q
Af2   12        q     u         pp
P    C33:Y58
measure 134
Af2   48-       w f   u        -
measure 135
Af2   48-       w     u        -
measure 136
*               D       cresc.
P  C25:f33  C17:Y70
Af2   48-       w     u        -
measure 137
Af2   48        w     u
measure 138
Af2   24        h f   u         f
Af2   24        h     u
measure 139
Af2   12        q f   u
rest  12        q
rest  24        h
measure 140
rest  24        h
rest  12        q
Gf3    3        s     d  [[    (p
P    C33:Y66
F3     3        s     d  ==
Ef3    3        s f   d  ==
F3     3        s     d  ]]    )
measure 141
*               D       cresc.
P  C25:f33  C17:Y67
Gf3   12        q f   d         .
F3    12        q     d         .
Ef3   12        q f   d         .
Df3   12        q f   d         .
measure 142
C3    12        q     u        (mf
P    C33:Y67
Bf2    6        e f   u        )
rest   6        e
rest  24        h
measure 143
rest  24        h
rest  12        q
Af3    3        s     d  [[    (p
P    C33:Y60
G3     3        s     d  ==
F3     3        s     d  ==
G3     3        s     d  ]]    )
measure 144
*               D       cresc.
P  C25:f33  C17:Y65
Af3   12        q f   d         .
G3    12        q     d         .
F3    12        q     d         .
Ef3   12        q f   d         .
measure 145
D3    12        q n   d        (+mf
C3     6        e     u        )
rest   6        e
rest  24        h
measure 146
rest  12        q
*               E   0
P    C17:Y73
C3    12        q     u        (.
C3    12        q     u         .
*               F   15
C3    12        q     u        ).
measure 147
*               E   15
P    C17:Y65
*     24        F   0
B2    48        w n   u         +
measure 148
rest  12        q
C3    12        q     u        (.p
P    C34:Y63
C3    12        q     u         .
C3    12        q     u        ).
measure 149
B2    48        w     u
measure 150
rest  12        q
B3    12        q     d        (f
P    C33:Y62
C4    12        q     d
F#4   12        q #   d        )
measure 151
G4    36        h.    d
rest  12        q
measure 152
rest  12        q
C2    12        q     u         mf.
P    C33:Y92
G2    24        h     u
measure 153
F2     9        e.    u  [     (
D2     3        s     u  =\    )
G2     9        e.    u  =     (
E2     3        s     u  ]\    )
A2    12        q     u         .
B2    12        q     u         .
measure 154
C3    12        q     u         .
A2    12        q     u         .
G2    12        q     u         .
rest  12        q
measure 155
rest  24        h
rest  12        q
G2    12        q     u         .
measure 156
C2    24        h     u
E2     9        e.    u  [     (
C2     3        s     u  =\    )
F2     9        e.    u  =     (
C2     3        s     u  ]\    )
measure 157
*               D       cresc.
P  C25:f33  C17:Y85
G2     9        e.    u  [     (
C2     3        s     u  =\    )
A2     9        e.    u  =     (
C2     3        s     u  ]\    )
B2     9        e.    u  [     (
C2     3        s     u  =\    )
C3     9        e.    u  =     (
C2     3        s     u  ]\    )
measure 158
D3    48        w     d         f
P    C33:Y60
measure 159
E3    48        w     d
measure 160
D3    48        w     d
measure 161
C3    36        h.    u        (
E3    12        q     d        )
measure 162
F3    12        q     d
rest  12        q
rest  24        h
measure 163
rest  48
measure 164
G2    48-       w     u        -
measure 165
G2    12        q     u
rest  12        q
rest  12        q
G2    12        q     u         p
P    C33:Y62
measure 166
C3    12        q     u
rest  12        q
rest  12        q
A3    12        q     d         .
measure 167
*               GE  15  Z
P   C17:Y67 C18:Y67
G3    36        h.    d
*               GF  0   p
P   C17:Y67
G2    12        q     u
measure 168
C3    12        q     u
rest  12        q
rest  12        q
A3    12        q     d         .
measure 169
*               GE  15  Z
P   C17:Y66 C18:Y66
G3    36        h.    d
*               GF  0   p
P   C17:Y66
G2    12        q     u
measure 170
C3    12        q     u
rest  12        q
rest  12        q
G2    12        q     u
measure 171
C3    12        q     u
rest  12        q
rest  12        q
*               D       cresc.
P  C25:f33  C17:Y65
G2    12        q     u
measure 172
C3    12        q     u
rest  12        q
rest  12        q
G2    12        q     u         f
measure 173
C3    12        q     u
rest  12        q
rest  12        q
G2     3        s     u  [[    (ff
P    C33:Y85
F2     3        s     u  ==
E2     3        s     u  ==
D2     3        s     u  ]]    )
measure 174
C2    12        q     u         .
rest  12        q
rest  24        h
mheavy2
/END
/eof
//
