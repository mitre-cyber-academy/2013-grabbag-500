&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/01/01} [KHM:1700317811]
TIMESTAMP: DEC/26/2001 [md5sum:974fc9511bd35965833d3574a7382031]
09/16/94 W Hewlett
WK#:55,1      MV#:1
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Allegro
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:12   T:0/0  C:4  D:Allegro
gA4    0        e     u          (
P    C34:o
A5    48        w     d         f)
measure 2
gA4    0        e     u          (
P    C34:o
C#6   48        w     d          )
measure 3
gE5    0        e     u          (
P    C34:o
E6    36        h.    d          )
D6     4        e  3  d  [       *(
B5     4        e  3  d  =
G#5    4        e  3  d  ]       !)
measure 4
A5    12        q     d
rest  12        q
rest  24        h
measure 5
F#5   18        q.    d          Z(
D5     3        s     d  [[
B4     3        s     d  ]]
G#4    6        e     u           ).
rest   6        e
rest  12        q
measure 6
E5    12        q     d
E5    24        h     d         Z.
D5     6        e     d  [      (
B4     6        e     d  ]      )
measure 7
A4    12        q     u
A4    24        h     u         Z.
B4     6        e     u  [      (
G#4    6        e     u  ]      )
measure 8
A4    12        q     u         (
C#5   12        q     d         )
B4     6        e     d  [      (
C#5    6        e     d  =
D5     6        e     d  =
E5     6        e     d  ]      )
measure 9
F#5   18        q.    d         Z(
D5     3        s     d  [[
B4     3        s     d  ]]
G#4    6        e     u          ).
rest   6        e
rest  12        q
measure 10
E5    12        q     d
E5    24        h     d         Z.
E6     4        e  3  d  [      *(
C#6    4        e  3  d  =
A5     4        e  3  d  ]      !)
measure 11
F#5    6        e     d
rest   6        e
F#5    4        e  3  d  [      *(
D5     4        e  3  d  =
B4     4        e  3  d  ]      !)
G#4    6        e     u
rest   6        e
D5     4        e  3  d  [      *(
B4     4        e  3  d  =
G#4    4        e  3  d  ]      !)
measure 12
A4    12        q     u
rest  12        q
rest  24        h
measure 13
rest  12        q
A4    12        q     u         (.p
A4    12        q     u          .
A4    12        q     u         ).
measure 14
A4     6        e     u  [      (
G#4    6        e     u  =
B4     6        e     u  =
A4     6        e     u  ]
C#5    6        e     d  [
B4     6        e     d  =
D5     6        e     d  =
C#5    6        e     d  ]      )
measure 15
E5     6        e     d  [      (
D5     6        e     d  =
F#5    6        e     d  =
E5     6        e     d  ]      )
gE5    0        e     u
D5     6        e     d  [      (
C#5    6        e     d  =
gC#5   0        e     u
B4     6        e     d  =
A4     6        e     d  ]      )
measure 16
G#4   12        q     u
D5    24        h     d
D5    12-       q     d        -
measure 17
D5    12        q     d
D5    24        h     d         (
gE5    5        s     u  [[
gD5    5        s     u  ==
gC#5   5        s     u  ==
gD5    5        s     u  ]]
E5     6        e     d  [
D5     6        e     d  ]      )
measure 18
C#5   36        h.    d
E5    12        q     d
measure 19
*               DH      cre
P    C17:f33
E5     6        e     d  [      (
G#4    6        e     d  ]      )
G#4   24        h     u
G#4   12        q     u
measure 20
G#4    6        e     u  [      (
A4     6        e     u  =
B4     6        e     u  =
A4     6        e     u  ]      )
G#4    6        e     d  [      (
A4     6        e     d  =
D5     6        e     d  =
C#5    6        e     d  ]      )
*               J
measure 21
*               DH      scen
P    C17:f33
A#4    6        e #   u  [      (
B4     6        e     u  =
A#4    6        e     u  =
B4     6        e     u  ]      )
A#4    6        e     d  [      (
B4     6        e     d  =
E5     6        e     d  =
D5     6        e     d  ]      )
measure 22
C#5   36        h.    d
E5    12        q     d
measure 23
*               DJ      do
P    C17:f33
E5     6        e     d  [      (
G#4    6        e     d  ]      )
G#4   24        h     u
G#4   12        q     u
measure 24
G#4    6        e     u  [      (f
A4     6        e     u  =
G#4    6        e     u  =
A4     6        e     u  ]      )
G#4    6        e     d  [      (
A4     6        e     d  =
D5     6        e     d  =
C#5    6        e     d  ]      )
measure 25
A#4    6        e #   u  [      (
B4     6        e     u  =
A#4    6        e     u  =
B4     6        e     u  ]      )
D5     6        e     d  [      (
C#5    6        e     d  =
D5     6        e     d  =
C#5    6        e     d  ]      )
measure 26
E5     6        e     d  [      (
D5     6        e     d  =      )
F#5    6        e     d  =      (
E5     6        e     d  ]      )
G5     6        e n   d  [      (
F#5    6        e     d  =      )
A5     6        e     d  =      (
G#5    6        e #   d  ]      )
measure 27
*               E   18
B5     6        e     d  [      (
A5     6        e     d  =
G#5    6        e     d  =
F#5    6        e     d  ]      )
F#5    6        e     d  [      (
E5     6        e     d  =
D5     6        e     d  =
*               F   0
C#5    6        e     d  ]      )
measure 28
B4     6        e     d  [      .p
E#5    6        e #   d  =      (
F#5    6        e     d  =
E#5    6        e     d  ]
F#5    6        e     d  [      ).
C#5    6        e     d  =      (
D5     6        e     d  =
C#5    6        e     d  ]
measure 29
D5     6        e     d  [      ).
A#4    6        e #   d  =      (
B4     6        e     d  =
A#4    6        e     d  ]
B4     6        e     d  [
C#5    6        e     d  =
B4     6        e     d  =
A4     6        e n   d  ]      )
measure 30
gG#4   0        e     u         (
E5    48        w     d         )f
measure 31
gG#4   0        e     u         (
G#5   48        w     d         )
measure 32
gB4    0        e     u         (
B5    24-       h     d        -)
B5    12        q     d
A5     3        s     d  [[     (
F#5    3        s     d  ==
D#5    3        s #   d  ==
B4     3        s     d  ]]     )
measure 33
A4    36        h.    u
C#5    4        e  3  d  [      *(
B4     4        e  3  d  =
A4     4        e  3  d  ]      !)
measure 34
G#4    4        e  3  d  [      .
B4     4        e  3  d  =      .
D#5    4        e #3  d  ]      .
E5     4        e  3  d  [      .
G#5    4        e  3  d  =      .
B5     4        e  3  d  ]      .
A5     4        e  3  d  [      .
G#5    4        e  3  d  =      .
F#5    4        e  3  d  ]      .
E5     4        e  3  d  [      .
D#5    4        e  3  d  =      .
C#5    4        e  3  d  ]      .
measure 35
B4     4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
F#5    4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
F#5    4        e  3  d  [
E5     4        e  3  d  =
D#5    4        e #3  d  ]
C#5    4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
measure 36
G#4    4        e  3  d  [
B4     4        e  3  d  =
D#5    4        e #3  d  ]
E5     4        e  3  d  [
G#5    4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
G#5    4        e  3  d  =
F#5    4        e  3  d  ]
E5     4        e  3  d  [
D#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 37
B4     4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
F#5    4        e  3  d  [
C#6    4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
F#6    4        e  3  d  =
F#6    4        e  3  d  ]
F#6    4        e  3  d  [
D#6    4        e #3  d  =
A5     4        e  3  d  ]
measure 38
G#5    4        e  3  d  [
B5     4        e  3  d  =
E6     4        e  3  d  ]
G#6    4        e  3  d  [
E6     4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
D#6    4        e #3  d  =
F#6    4        e  3  d  ]
A6     4        e  3  d  [
F#6    4        e  3  d  =
D#6    4        e  3  d  ]
measure 39
G#5    4        e  3  d  [
B5     4        e  3  d  =
E6     4        e  3  d  ]
G#6    4        e  3  d  [
E6     4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
D#6    4        e #3  d  =
F#6    4        e  3  d  ]
A6     4        e  3  d  [
F#6    4        e  3  d  =
D#6    4        e  3  d  ]
measure 40
G#5    4        e  3  d  [
B5     4        e  3  d  =
E6     4        e  3  d  ]
G#6    4        e  3  d  [
E6     4        e  3  d  =
B5     4        e  3  d  ]
G#5    4        e  3  d  [
B5     4        e  3  d  =
G#5    4        e  3  d  ]
E5     4        e  3  d  [
G#5    4        e  3  d  =
E5     4        e  3  d  ]
measure 41
C#5    4        e  3  d  [
E5     4        e  3  d  =
A5     4        e  3  d  ]
C#6    4        e  3  d  [
A5     4        e  3  d  =
E5     4        e  3  d  ]
C#5    4        e  3  d  [
E5     4        e  3  d  =
C#5    4        e  3  d  ]
A4     4        e  3  d  [
C#5    4        e  3  d  =
A4     4        e  3  d  ]
measure 42
F#4    4        e  3  u  [
A4     4        e  3  u  =
F#4    4        e  3  u  ]
E4     4        e  3  u  [
A4     4        e  3  u  =
E4     4        e  3  u  ]
D#4    4        e #3  u  [
A4     4        e  3  u  =
A4     4        e  3  u  ]
C4     4        e n3  u  [
A4     4        e  3  u  =
A4     4        e  3  u  ]
measure 43
B3     4        e  3  u  [
D#4    4        e #3  u  =
F#4    4        e  3  u  ]
A4     4        e  3  u  [
G#4    4        e  3  u  =
F#4    4        e  3  u  ]
E4     4        e  3  u  [
D#4    4        e  3  u  =
C#4    4        e #3  u  ]      +
B3     4        e  3  u  [
C#4    4        e  3  u  =
A3     4        e  3  u  ]
measure 44
G#3    4        e  3  u  [
B3     4        e  3  u  =
A3     4        e  3  u  ]
C#4    4        e  3  u  [
B3     4        e  3  u  =
D#4    4        e #3  u  ]
C#4    4        e  3  u  [
E4     4        e  3  u  =
D#4    4        e  3  u  ]
F#4    4        e  3  u  [
E4     4        e  3  u  =
G#4    4        e  3  u  ]
measure 45
F#4    4        e  3  u  [
A4     4        e  3  u  =
G#4    4        e  3  u  ]
B4     4        e  3  d  [
A4     4        e  3  d  =
C#5    4        e  3  d  ]
B4     4        e  3  d  [
D#5    4        e #3  d  =
C#5    4        e  3  d  ]
E5     4        e  3  d  [
D#5    4        e  3  d  =
F#5    4        e  3  d  ]
measure 46
E5     4        e  3  d  [
G#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
G#5    4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
G#5    4        e  3  d  =
F#5    4        e  3  d  ]
E5     4        e  3  d  [
D#5    4        e #3  d  =
C#5    4        e  3  d  ]
measure 47
B4    24        h     d
F#5   24        h     d         t(
P  C34:u
gE5    5        s     u  [[
gD5    5        s     u  ]]      )
measure 48
E5    12        q     d
rest  12        q
G#5   18        q.    d          Z(
A5     3        s     d  [[
G#5    3        s     d  ]]       )
measure 49
F#5   12        q     d
B5    12        q     d          p
B5     6        e     d  [       (
A5     6        e     d  =       )
A5     6        e     d  =       (
G#5    6        e     d  ]       )
measure 50
G#5   12        q     d         (
A5     6        e     d         )
rest   6        e
F#5   18        q.    d         (f
G#5    3        s     d  [[
A5     3        s     d  ]]     )
measure 51
G#5   12        q     d         Z(
F#5    6        e     d         .)
rest   6        e
A5    12        q     d         Z(
G#5    6        e     d         .)
rest   6        e
measure 52
C#6   12        q     d         Z(
B5     6        e     d         .)
rest   6        e
D#6    6        e #   d  [      (p
E6     6        e     d  =      )
E6     6        e     d  =      .
E6     6        e     d  ]      .
measure 53
E6    12        q     d         (
B#5   12        q #   d         )
B#5    6        e     d  [      (
C#6    6        e     d  =      )
C#6    6        e     d  =
C#6    6        e     d  ]
measure 54
C#6   12        q     d         (
F#5   12        q     d         )
F#5    4        e  3  d  [      (*[
G#5    4        e  3  d  =
A5     4        e  3  d  ]      )!
A5     4        e  3  d  [      (*
B5     4        e n3  d  =         +
C#6    4        e  3  d  ]      )!]
measure 55
E5    24        h     d
gG#5   0        e     u         (
F#5   18        q.    d         )t(
E5     3        s     d  [[
F#5    3        s     d  ]]       )
measure 56
F##5  12        q     d         (
G#5   12        q     d         )
D#6    4        e #3  d  [      (f
E6     4        e  3  d  =      )
E6     4        e  3  d  ]      .
E6     4        e  3  d  [      .
E6     4        e  3  d  =      .
E6     4        e  3  d  ]      .
measure 57
E6     4        e  3  d  [      (
B#5    4        e #3  d  =      )
B#5    4        e  3  d  ]      .
B#5    4        e  3  d  [      .
B#5    4        e  3  d  =      .
B#5    4        e  3  d  ]      .
B#5    4        e  3  d  [      (
C#6    4        e  3  d  =      )
C#6    4        e  3  d  ]      .
C#6    4        e  3  d  [       .
C#6    4        e  3  d  =       .
C#6    4        e  3  d  ]       .
measure 58
C#6    4        e  3  d  [       (
F#5    4        e  3  d  =       )
F#5    4        e  3  d  ]       .
F#5    4        e  3  d  [       .
F#5    4        e  3  d  =       .
F#5    4        e  3  d  ]       .
F#5    4        e  3  d  [       (*[
G#5    4        e  3  d  =
A5     4        e  3  d  ]       )!
A5     4        e  3  d  [       (*
B5     4        e n3  d  =          +
C#6    4        e  3  d  ]       )!]
measure 59
E5    24        h     d
gG#5   0        e     u         (
F#5   24        h     d         )t(
gE5    5        s     u  [[
gF#5   5        s     u  ]]       )
measure 60
E5    12        q     d
rest  12        q
B5    18        q.    d         Z(
G#5    3        s     d  [[
E5     3        s     d  ]]      )
measure 61
D#5   12        q #   d
rest  12        q
A5    18        q.    d         Z(
F#5    3        s     d  [[
D#5    3        s #   d  ]]     +)
measure 62
E5    12        q     d
rest  12        q
B5    18        q.    d         Z(
G#5    3        s     d  [[
E5     3        s     d  ]]      )
measure 63
D6    21        q:n   d         f(+
C#6    3        s     d          )
D6     9        e.    d  [      (
C#6    3        s     d  =\
D6     9        e.    d  =
C#6    3        s     d  ]\     )
measure 64
D6    12        q     d
rest  12        q
rest  24        h
mheavy2 65           :|
D6    21        q:    d         (p
C#6    3        s     d         )
D6     9        e.    d  [      (
C#6    3        s     d  =\
D6     9        e.    d  =
C#6    3        s     d  ]\     )
measure 66
D6    12        q     d
rest  12        q
rest  24        h
measure 67
D6    21        q:    d         (
C#6    3        s     d         )
D6     9        e.    d  [      (
C#6    3        s     d  =\
D6     9        e.    d  =
C#6    3        s     d  ]\     )
measure 68
*               E   0
D6    36        h.    d
*               F   18
E6    12        q     d
measure 69
F6    21        q:n   d         (f
E6     3        s     d         )
F6     9        e.    d  [      (
E6     3        s     d  =\
F6     9        e.    d  =
E6     3        s     d  ]\     )
measure 70
F6    24        h n   d
E6    24        h     d
measure 71
D#6   48        w #   d
measure 72
E6    48        w     d
measure 73
A5    24        h     d
A5     6        e     d  [      (
G5     6        e n   d  =
F#5    6        e     d  =
G5     6        e     d  ]      )
measure 74
F#5   21        q:    d         (
A#4    3        s #   u         )
B4     9        e.    u  [      (
A#4    3        s     u  =\
B4     9        e.    u  =
A#4    3        s     u  ]\     )
measure 75
B4    21        q:    d         (p
A#4    3        s #   u         )
B4     9        e.    u  [      (
A#4    3        s     u  =\
B4     9        e.    u  =
A#4    3        s     u  ]\     )
measure 76
*               E   0
B4    48        w     d
measure 77
*               F   18
B4    48        w     d
measure 78
gE4    0        e               (f
P    C33:o
C5    48        w n   d         )
measure 79
gG4    0        e n   u         (
P    C33:o
E5    48        w     d         )
measure 80
gG4    0        e n   u         (
P    C33:o
G5    36        h.n   d         )
F5     4        e n3  d  [      (*
D5     4        e  3  d  =
B4     4        e  3  d  ]      )!
measure 81
C5    12        q n   d
rest  12        q
rest  24        h
measure 82
A5    18        q.    d         Z(
F5     3        s n   d  [[
D5     3        s     d  ]]      )
B4     6        e     d         .
rest   6        e
rest  12        q
measure 83
G5    12        q n   d
G5    24        h     d         Z.
F5     6        e n   d  [       (
D5     6        e     d  ]       )
measure 84
C5    12        q n   d
C5    24        h     d         Z.
D5     6        e     d  [       (
B4     6        e     d  ]       )
measure 85
C5    12        q n   d         (
E5    12        q     d         )
D5     4        e  3  d  [      *(
E5     4        e  3  d  =
F5     4        e n3  d  ]      !
F#5    4        e #3  d  [      *
G5     4        e n3  d  =
G#5    4        e #3  d  ]      !)
measure 86
A5    18        q.    d         (Z
F5     3        s n   d  [[
D5     3        s     d  ]]     )
B4     6        e     d         .
rest   6        e
rest  12        q
measure 87
G5    12        q n   d
G5    24        h     d         Z.
C6     4        e n3  d  [      (*
G5     4        e  3  d  =
E5     4        e  3  d  ]      )!
measure 88
D5     6        e     d
rest   6        e
A5     4        e  3  d  [      (*
F5     4        e n3  d  =
D5     4        e  3  d  ]      )!
B4     6        e     d
rest   6        e
F5     4        e  3  d  [      (*
D5     4        e  3  d  =
B4     4        e  3  d  ]      )!
measure 89
C5    12        q n   d
rest  12        q
rest  24        h
measure 90
rest  48
measure 91
C#5    4        e #3  d  [      .+Z
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
F5     4        e n3  d  [      .
E5     4        e  3  d  =      .
G5     4        e n3  d  ]      .
F5     4        e  3  d  [      .
A5     4        e  3  d  =      .
G5     4        e  3  d  ]      .
Bf5    4        e f3  d  [      .
G5     4        e  3  d  =      .
E5     4        e  3  d  ]      .
measure 92
F5    12        q n   d
rest  12        q
rest  24        h
measure 93
rest  48
measure 94
D#5    4        e #3  d  [      Z
F#5    4        e #3  d  =      +
E5     4        e  3  d  ]
G5     4        e n3  d  [
F#5    4        e  3  d  =
A5     4        e  3  d  ]
G5     4        e  3  d  [
B5     4        e n3  d  =      +
A5     4        e  3  d  ]
C6     4        e n3  d  [
B5     4        e  3  d  =
A5     4        e  3  d  ]
measure 95
G5    12        q n   d
rest  12        q
rest  24        h
measure 96
E5     4        e  3  d  [      mf
*               D       cresc.
P    C17:f33
G#5    4        e #3  d  =      +
F#5    4        e  3  d  ]
E5     4        e  3  d  [
B5     4        e  3  d  =
A5     4        e  3  d  ]
G#5    4        e  3  d  [
B5     4        e  3  d  =
C#6    4        e #3  d  ]      +
D6     4        e  3  d  [
B5     4        e  3  d  =
G#5    4        e  3  d  ]
measure 97
E#5   48        w #   d
measure 98
F#5   12        q     d         f
C#6   24        h     d
C#6   12        q     d         t(
P    C34:u
gB5    5        s     u  [[
gC#6   5        s     u  ]]      )
measure 99
D6    18        q.    d         Z(
B5     3        s     d  [[
G#5    3        s     d  ]]      )
E#5    6        e #   d
rest   6        e
rest  12        q
measure 100
rest  12        q
C#6   24        h     d
C#6   12        q     d         t(
P    C34:u
gB5    5        s     u  [[
gC#6   5        s     u  ]]      )
measure 101
D6    18        q.    d         Z(
B5     3        s     d  [[
G#5    3        s     d  ]]      )
E#5    6        e #   d         .
rest   6        e
rest  12        q
measure 102
rest  12        q
A5    24        h     d
A#5   12-       q #   d        -
measure 103
A#5   12        q     d
B5    12-       q     d        -
B5     6        e     d  [
B5     6        e     d  =      t([
P    C34:u
gA5    5        s     u  [[
gB5    5        s     u  ]]      )
C#6    6        e     d  =
D6     6        e     d  ]        ]
measure 104
F#5   24        h     d
gA5    0        e n   u         +
G#5   18        q.    d         (
F#5    6        e     d         )
measure 105
F#5   12        q     d
rest  12        q
E#6    6        e #   d  [      (p
F#6    6        e     d  =      )
F#6    6        e     d  =      .
F#6    6        e     d  ]      .
measure 106
F#6   12        q     d         (
C#6   12        q     d         )
C#6    6        e     d  [      (
D6     6        e     d  =      )
D6     6        e     d  =      .
D6     6        e     d  ]      .
measure 107
D6    12        q     d         (
G#5   12        q     d         )
*               E   0
G#5    6        e     d  [      (
A5     6        e     d  =      )
A5     6        e     d  =      .
*               F   18
A5     6        e     d  ]      .
measure 108
A5    12        q     d         f
rest  12        q
E#5   12        q #   d
rest  12        q
measure 109
F#5   48-       w     d        -p
measure 110
F#5   12        q     d
*               E   0
F#5   12        q     d         .(
F#5   12        q     d         .
*               F   18
F#5   12        q     d         .)
measure 111
F#5    6        e     d  [      (mf
E5     6        e n   d  =      +
D#5    6        e #   d  =
E5     6        e     d  ]      )
D#5    6        e     d  [      (
E5     6        e     d  =
D6     6        e n   d  =      +
C#6    6        e     d  ]      )
measure 112
*               D       cresc.
P    C17:f33
B5     6        e     d  [      .
A5     6        e     d  =      .
G#5    6        e     d  =      .
F#5    6        e     d  ]      .
E5     6        e     d  [      .
D5     6        e     d  =      .
C#5    6        e     d  =      .
B4     6        e     d  ]      .
measure 113
gA4    0        e     u         (
P    C33:o
A5    48        w     d         )
measure 114
gA4    0        e     u         (
P    C33:o
C#6   48        w     d         )
measure 115
gE5    0        e     u         (
P    C33:o
E6    36        h.    d         )
D6     4        e  3  d  [      (*
B5     4        e  3  d  =
G#5    4        e  3  d  ]      )!
measure 116
A5    12        q     d
rest  12        q
rest  24        h
measure 117
F#5   18        q.    d         Z(
D5     3        s     d  [[
B4     3        s     d  ]]      )
G#4    6        e     u
rest   6        e
rest  12        q
measure 118
E5    12        q     d
E5    24        h     d         .Z
D5     6        e     d  [      (
B4     6        e     d  ]      )
measure 119
A4    12        q     u
A4    24        h     u         Z
B4     6        e     u  [      (
G#4    6        e     u  ]      )
measure 120
A4    12        q     u         (
C#5   12        q     d         )
B4     6        e     d  [      (
C#5    6        e     d  ]
D5     4        e  3  d  [       *
E5     4        e  3  d  =
E#5    4        e #3  d  ]      )!
measure 121
F#5   18        q.    d         (Z
D5     3        s     d  [[
B4     3        s     d  ]]     )
G#4    6        e     u         .
rest   6        e
rest  12        q
measure 122
E5    12        q     d
E5    24        h     d         Z.
E6     4        e  3  d  [      (*
C#6    4        e  3  d  =
A5     4        e  3  d  ]      )!
measure 123
F#5    6        e     d
rest   6        e
F#5    4        e  3  d  [      (*
D5     4        e  3  d  =
B4     4        e  3  d  ]      )!
G#4    6        e     u
rest   6        e
D5     4        e  3  d  [      (*
B4     4        e  3  d  =
G#4    4        e  3  d  ]      )!
measure 124
A4    12        q     u
rest  12        q
rest  24        h
measure 125
rest  48
measure 126
rest   6        e
D5     6        e     d  [      (p
C#5    6        e     d  =
D5     6        e     d  ]
C#5    6        e     d  [
D5     6        e     d  =
E5     6        e     d  =
D5     6        e     d  ]      )
measure 127
F#5    6        e     d  [      (
E5     6        e     d  =
B5     6        e     d  =
A5     6        e     d  ]
G#5    6        e     d  [
F#5    6        e     d  =
E5     6        e     d  =
D5     6        e     d  ]      )
measure 128
C#5   48-       w     d        -
measure 129
C#5   48        w     d
measure 130
D5     6        e     d  [      .
E#5    6        e #   d  =      (
F#5    6        e     d  =
E#5    6        e     d  ]
F#5    6        e     d  [      ).
C#5    6        e     d  =      (
D5     6        e     d  =
C#5    6        e     d  ]
measure 131
D5     6        e     d  [      ).
A#4    6        e #   d  =      (
B4     6        e     d  =
A#4    6        e     d  ]
B4     6        e     u  [      ).
A4     6        e n   u  =      (
G#4    6        e     u  =
A4     6        e     u  ]
measure 132
G#4    6        e     u  [      ).
*               E + 0
D#4    6        e #   u  =      (
E4     6        e     u  =
D#4    6        e     u  ]
E4     6        e     u  [
D4     6        e n   u  =
*               F + 18
C#4    6        e     u  =
B3     6        e     u  ]      )
measure 133
A3     4        e  3  u  [      f
C#4    4        e  3  u  =
E4     4        e  3  u  ]
A4     4        e  3  d  [      .
C#5    4        e  3  d  =      .
E5     4        e  3  d  ]      .
D5     4        e  3  d  [      .
C#5    4        e  3  d  =      .
B4     4        e  3  d  ]      .
A4     4        e  3  u  [      .
G#4    4        e  3  u  =      .
F#4    4        e  3  u  ]      .
measure 134
E4     4        e  3  u  [
D5     4        e  3  u  =
C#5    4        e  3  u  ]
B4     4        e  3  d  [
B5     4        e  3  d  =
A5     4        e  3  d  ]
G#5    4        e  3  d  [
F#5    4        e  3  d  =
E5     4        e  3  d  ]
D5     4        e  3  d  [
C#5    4        e  3  d  =
B4     4        e  3  d  ]
measure 135
A4     4        e  3  d  [
C#5    4        e  3  d  =
E5     4        e  3  d  ]
A5     4        e  3  d  [
C#6    4        e  3  d  =
E6     4        e  3  d  ]
D6     4        e  3  d  [
C#6    4        e  3  d  =
B5     4        e  3  d  ]
A5     4        e  3  d  [
G#5    4        e  3  d  =
F#5    4        e  3  d  ]
measure 136
E5     4        e  3  d  [
D6     4        e  3  d  =
C#6    4        e  3  d  ]
B5     4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
F#5    4        e  3  d  [
E5     4        e  3  d  =
D#5    4        e #3  d  ]
E5     4        e  3  d  [
F#5    4        e  3  d  =
D5     4        e n3  d  ]
measure 137
C#5    4        e  3  d  [
E5     4        e  3  d  =
A5     4        e  3  d  ]
C#6    4        e  3  d  [
B5     4        e  3  d  =
A5     4        e  3  d  ]
D5     4        e  3  d  [
G#5    4        e  3  d  =
B5     4        e  3  d  ]
D6     4        e  3  d  [
C#6    4        e  3  d  =
B5     4        e  3  d  ]
measure 138
E5     4        e  3  d  [
A5     4        e  3  d  =
C#6    4        e  3  d  ]
E6     4        e  3  d  [
C#6    4        e  3  d  =
A5     4        e  3  d  ]
E5     4        e  3  d  [
A5     4        e  3  d  =
C6     4        e n3  d  ]
E6     4        e  3  d  [
C6     4        e  3  d  =
A5     4        e  3  d  ]
measure 139
F#5    4        e  3  d  [
A5     4        e  3  d  =
B5     4        e  3  d  ]
D#6    4        e #3  d  [
B5     4        e  3  d  =
A5     4        e  3  d  ]
E5     4        e  3  d  [
G#5    4        e  3  d  =
A5     4        e  3  d  ]
B5     4        e  3  d  [
C#6    4        e  3  d  =
D6     4        e n3  d  ]
measure 140
C#6    4        e  3  d  [
E6     4        e  3  d  =
C#6    4        e  3  d  ]
A5     4        e  3  d  [
C#6    4        e  3  d  =
A5     4        e  3  d  ]
F#5    4        e  3  d  [
A5     4        e  3  d  =
F#5    4        e  3  d  ]
D5     4        e  3  d  [
F#5    4        e  3  d  =
D5     4        e  3  d  ]
measure 141
B4     4        e  3  d  [
D5     4        e  3  d  =
B4     4        e  3  d  ]
G#4    4        e  3  u  [
B4     4        e  3  u  =
G#4    4        e  3  u  ]
E4     4        e  3  u  [
G#4    4        e  3  u  =
E4     4        e  3  u  ]
D4     4        e  3  u  [
E4     4        e  3  u  =
D4     4        e  3  u  ]
measure 142
C#4    4        e  3  u  [      (
A4     4        e  3  u  =
E5     4        e  3  u  ]      )
E5    24        h     d         (
E#5   12        q #   d         )
measure 143
E#5    6        e #   d  [      (
F#5    6        e     d  ]      )
F#5   12-       q     d        -(
F#5    6        e     d  [
F#5    6        e     d  =       [
G#5    6        e     d  =
A5     6        e     d  ]      )]
measure 144
gA5    0        e     u         (
A4    36        h.    u         )
gC#5   0        e     u         (
B4     6        e     u  [      )(
A4     6        e     u  ]       )
measure 145
A4    12        q     u
rest  12        q
C#5   18        q.    d         Z(
D5     3        s     d  [[
C#5    3        s     d  ]]      )
measure 146
B4    12        q     d
E5    12        q     d         p
E5     6        e     d  [      (
D5     6        e     d  =      )
D5     6        e     d  =      (
C#5    6        e     d  ]      )
measure 147
C#5   12        q     d         (
D5     6        e     d         )
rest   6        e
B4    18        q.    d         (f
C#5    3        s     d  [[
D5     3        s     d  ]]     )
measure 148
C#5   12        q     d         Z(
B4     6        e     d         .)
rest   6        e
D5    12        q     d         Z(
C#5    6        e     d         .)
rest   6        e
measure 149
F#5   12        q     d         f(
E5     6        e     d         .)
rest   6        e
G#5    6        e     d  [      p(
A5     6        e     d  =       )
A5     6        e     d  =      .
A5     6        e     d  ]      .
measure 150
A5    12        q     d         (
E#5   12        q #   d         )
E#5    6        e     d  [      (
F#5    6        e     d  =      )
F#5    6        e     d  =      .
F#5    6        e     d  ]      .
measure 151
F#5   12        q     d         (
B4     6        e     d         )
rest   6        e
B4     4        e  3  d  [      (*[
C#5    4        e  3  d  =
D5     4        e  3  d  ]      )!
D5     4        e  3  d  [      (*
E5     4        e n3  d  =         +
F#5    4        e  3  d  ]      )!]
measure 152
A4    24        h     u
gC#5   0        e     u         (
B4    18        q.    d         )t(
A4     3        s     u  [[
B4     3        s     u  ]]       )
measure 153
B##4  12        q     d         (
C#5   12        q     d         )
G#5    6        e     d  [      (pp
A5     6        e     d  =      )
A5     6        e     d  =      .
A5     6        e     d  ]      .
measure 154
A5     6        e     d  [      (
E#5    6        e #   d  =      )
E#5    6        e     d  =      .
E#5    6        e     d  ]      .
E#5    6        e     d  [      (
F#5    6        e     d  =      )
F#5    6        e     d  =      .
F#5    6        e     d  ]      .
measure 155
*               D       poco
P   C17:f33
F#5   24-       h     d        -
F#5    6        e     d  [      (
G5     6        e n   d  =      )
*               D       a
P   C17:f33
G5     6        e     d  =      .
G5     6        e     d  ]      .
measure 156
*               D       poco
P   C17:f33
G5    24-       h n   d        -
G5     6        e     d  [      (
*               DH      cre
P   C17:f33
G#5    6        e #   d  =      )
G#5    6        e     d  =      .
*               J
G#5    6        e     d  ]      .
measure 157
*      6        DH      scen
P   C17:f33
G#5   24-       h     d        -
G#5    6        e     d  [      (
A5     6        e     d  =      )
A5     6        e     d  =      .
*               J
A5     6        e     d  ]      .
measure 158
*               D       do
P   C17:f33
A5    24        h     d          [
B5     6        e     d  [      (]
A5     6        e     d  =      )
A5     6        e     d  =      .
A5     6        e     d  ]      .
measure 159
A5     6        e     d  [      (f
C#6    6        e     d  =      )
C#6    6        e     d  =      .
C#6    6        e     d  ]      .
C#6    6        e     d  [      (
E6     6        e     d  =      )
E6     6        e     d  =      .
E6     6        e     d  ]      .
measure 160
*               D       dim.
P   C17:f33
E6     6        e     d         .
rest   6        e
C#6    6        e     d         .
rest   6        e
A5     6        e     d         .
rest   6        e
E5     6        e     d         .
rest   6        e
measure 161
C#5    6        e     d         .
rest   6        e
A4     6        e     u         .
rest   6        e
E4     6        e     u         .
rest   6        e
C#4    6        e     u         .
rest   6        e
measure 162
B3    48-       w     u        -p
measure 163
B3    24        h     u
gA#3   0        e     u         (
B3    12        q     u         )
gA#3   0        e     u         (
B3    12        q     u         )
measure 164
A3     4        e n3  u  [      f+
C#4    4        e  3  u  =
B3     4        e  3  u  ]
D4     4        e  3  u  [
C#4    4        e  3  u  =
E4     4        e  3  u  ]
D4     4        e  3  u  [
F#4    4        e  3  u  =
E4     4        e  3  u  ]
G#4    4        e  3  u  [
F#4    4        e  3  u  =
A4     4        e  3  u  ]
measure 165
G#4    4        e  3  u  [
B4     4        e  3  u  =
A4     4        e  3  u  ]
C#5    4        e  3  d  [
B4     4        e  3  d  =
D5     4        e  3  d  ]
C#5    4        e  3  d  [
E5     4        e  3  d  =
D5     4        e  3  d  ]
C#5    4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
measure 166
G#4    4        e  3  u  [
B4     4        e  3  u  =
A4     4        e  3  u  ]
C#5    4        e  3  d  [
B4     4        e  3  d  =
D5     4        e  3  d  ]
C#5    4        e  3  d  [
E5     4        e  3  d  =
D5     4        e  3  d  ]
F#5    4        e  3  d  [
E5     4        e  3  d  =
G#5    4        e  3  d  ]
measure 167
F#5    4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
A5     4        e  3  d  =
C#6    4        e  3  d  ]
B5     4        e  3  d  [
D6     4        e  3  d  =
C#6    4        e  3  d  ]
B5     4        e  3  d  [
A5     4        e  3  d  =
G#5    4        e  3  d  ]
measure 168
A5     4        e  3  d  [
C#6    4        e  3  d  =
E6     4        e  3  d  ]
E6     4        e  3  d  [
E6     4        e  3  d  =
E6     4        e  3  d  ]
F#5    4        e  3  d  [
G#5    4        e  3  d  =
A5     4        e  3  d  ]
B5     4        e  3  d  [
C#6    4        e  3  d  =
D6     4        e  3  d  ]
measure 169
E5    24        h     d
B5    24        h     d         t(
P   C34:u
gA5    5        s     u  [[
gB5    5        s     u  ]]      )
measure 170
A5    12        q     d
rest  12        q
E6    18        q.    d         Z(
C#6    3        s     d  [[
A5     3        s     d  ]]      )
measure 171
G#5   12        q     d
rest  12        q
D6    18        q.    d         Z(
B5     3        s     d  [[
G#5    3        s     d  ]]      )
measure 172
A5    12        q     d
rest  12        q
E5    18        q.    d         f(
C#5    3        s     d  [[
A4     3        s     d  ]]      )
measure 173
G#4   12        q     u
rest  12        q
G#5   12        q     d         ff
 B4   12        q     d
 E4   12        q     d
rest  12        q
measure 174
A5    12        q     d
 C#5  12        q     d
 E4   12        q     d
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/01/02} [KHM:1700317811]
TIMESTAMP: DEC/26/2001 [md5sum:40b3450a0420128ec49e610e8541582b]
09/16/94 W Hewlett
WK#:55,1      MV#:1
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Allegro
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:12   T:0/0  C:4  D:Allegro
rest  12        q
gD5    4        t     u  [[[    (
gC#5   4        t     u  ===
gB4    4        t     u  ]]]
C#5   12        q     d         )f.
E5    12        q     d           .
C#5   12        q     d           .
measure 2
rest  12        q
gB4    4        t     u  [[[    (
gA4    4        t     u  ===
gG#4   4        t     u  ]]]
A4    12        q     u         ).
C#5   12        q     d          .
A4    12        q     u          .
measure 3
rest  12        q
gA4    4        t     u  [[[    (
gG#4   4        t     u  ===
gF#4   4        t     u  ]]]
G#4   12        q     u         ).
B4    12        q     d          .
D5    12        q     d          .
measure 4
C#5   12        q     d
C#4   12        q     u         (
D4    12        q     u
E4    12        q     u         )
measure 5
F#4   24        h     u         (Z
 A3   24        h     u         [
G#4    6        e     u         )
 B3    6        e     u         ]
rest   6        e
rest  12        q
measure 6
A4    12        q     u
A4    24        h     u         Z.
F#4    6        e     u  [      (
D4     6        e     u  ]      )
measure 7
C#4   12        q     u
C#4   24        h     u         Z.
D4     6        e     u  [      (
B3     6        e     u  ]      )
measure 8
A3    12        q     u         (
A4    12        q     u         )
G#4   12        q     u
rest  12        q
measure 9
B4    24        h     u         Z
 G#4  24        h     u
rest  24        h
measure 10
A4    12        q     u
A4    24        h     u         .Z
A4    12        q     u
measure 11
A4    12        q     u
rest  12        q
D4    12        q     u
rest  12        q
measure 12
C#4   12        q     u
rest  12        q
rest  24        h
measure 13
rest  12        q
C#4   12        q     u         .(p
C#4   12        q     u         .
C#4   12        q     u         .)
measure 14
D4    24        h     u
rest  24        h
measure 15
rest  48
measure 16
rest  12        q
B4    24        h     d
B4    12-       q     d        -
measure 17
B4    12        q     d
B4    24        h     d
G#4   12        q     u
measure 18
A4     6        e     u  [      (
E4     6        e     u  =
D#4    6        e #   u  =
E4     6        e     u  ]      )
D#4    6        e     u  [      (
E4     6        e     u  =
D#4    6        e     u  =
E4     6        e     u  ]      )
measure 19
*               DH      cre
P    C17:f33
E4    48-       w     u        -
measure 20
E4    48-       w     u        -
*               J
measure 21
*               DH      scen
P    C17:f33
E4    48-       w     u        -
measure 22
E4     6        e     u  [
E4     6        e     u  =      (
D#4    6        e #   u  =
E4     6        e     u  ]      )
D#4    6        e     u  [      (
E4     6        e     u  =
D#4    6        e     u  =
E4     6        e     u  ]      )
measure 23
*               DJ      do
P    C17:f33
E4    48-       w     u        -
measure 24
E4    48        w     u         f
measure 25
F#4   24        h     u
G4    24        h n   u
measure 26
A4    12        q     u
A4    24        h     u
D4    12        q     u
measure 27
*               E   18
*     42        F   0
E4    48        w     u
measure 28
F#4   12        q     u         p
rest  12        q
rest   6        e
A#4    6        e #   u  [      (
B4     6        e     u  =
A#4    6        e     u  ]
measure 29
B4     6        e     u  [      ).
E4     6        e     u  =      (
F#4    6        e     u  =
E4     6        e     u  ]
F#4   12        q     u         ).
F#4   12        q     u          .
measure 30
E4    12        q     u         .f
gA4    4        t     u  [[[    (
gG#4   4        t     u  ===
gF#4   4        t     u  ]]]
G#4   12        q     u         ).
B4    12        q     d          .
G#4   12        q     u          .
measure 31
rest  12        q
gF#4   4        t     u  [[[    (
gE4    4        t     u  ===
gD#4   4        t     u  ]]]
E4    12        q     u         ).
G#4   12        q     u          .
E4    12        q     u          .
measure 32
rest  12        q
gG#4   4        t     u  [[[    (
gF#4   4        t     u  ===
gE4    4        t     u  ]]]
F#4   12        q     u         ).
A4    12        q     u          .
F#4   12        q     u          .
measure 33
rest  12        q
gG#4   4        t     u  [[[    (
gF#4   4        t     u  ===
gE4    4        t     u  ]]]
F#4   12        q     u         ).
A4    12        q     u          .
F#4   12        q     u          .
measure 34
G#4   24        h     u
rest  24        h
measure 35
A4    24        h     u
 B3   24        h     u
rest  24        h
measure 36
G#4   24        h     u
 B3   24        h     u
rest  24        h
measure 37
A4    24        h     u
 B3   24        h     u
rest  24        h
measure 38
G#4   12        q     u
 B3   12        q     u
rest  12        q
A4    12        q     u
 B3   12        q     u
rest  12        q
measure 39
G#4   12        q     u
 B3   12        q     u
rest  12        q
A4    12        q     u
 B3   12        q     u
rest  12        q
measure 40
G#4   12        q     u
 B3   12        q     u
rest  12        q
G#4   12        q     u         (
E4    12        q     u         )
measure 41
C#4   12        q     u
rest  12        q
rest  24        h
measure 42
A4    48-       w     u        -
measure 43
A4    36        h.    u
A3    12        q     u
measure 44
G#3   12        q     u
rest  12        q
rest  24        h
measure 45
rest  48
measure 46
E4    12        q     u
rest  12        q
F#4   12        q     u
rest  12        q
measure 47
G#4   12        q     u
G#4   12        q     u
A4    12        q     u
A4    12        q     u
measure 48
G#4   12        q     u
rest  12        q
E5    18        q.    d         (Z
F#5    3        s     d  [[
E5     3        s     d  ]]     )
measure 49
D#5   12        q #   d
G#5   12        q     d         p
G#5    6        e     d  [       (
F#5    6        e     d  =       )
F#5    6        e     d  =       (
E#5    6        e #   d  ]       )
measure 50
E#5   12        q #   d          (
F#5    6        e     d          )
rest   6        e
D#5   18        q.#   d          (f
E5     3        s n   d  [[
F#5    3        s     d  ]]      )
measure 51
E5    12        q     d          (Z
D#5    6        e #   d          ).
rest   6        e
F#5   12        q     d          (Z
E5     6        e     d          ).
rest   6        e
measure 52
D#5   12        q #   d          (Z
E5     6        e     d          ).
rest   6        e
D#5    6        e     d  [       (p
E5     6        e     d  =       )
E5     6        e     d  =       .
E5     6        e     d  ]       .
measure 53
E5    12        q     d         (
B#4   12        q #   d         )
B#4    6        e     d  [      (
C#5    6        e     d  =      )
C#5    6        e     d  =
C#5    6        e     d  ]
measure 54
C#5   12        q     d         (
F#4   12        q     u         )
F#4    4        e  3  u  [      (*[
G#4    4        e  3  u  =
A4     4        e  3  u  ]      )!
A4     4        e  3  u  [      (*
B4     4        e n3  u  =      +
C#5    4        e  3  u  ]      )!]
measure 55
G#4   24        h     u
gB4    0        e     u         (
A4    18        q.    u         )(t
G#4    3        s     u  [[
A4     3        s     u  ]]      )
measure 56
A4    12        q     u         (
G#4   12        q     u         )
D#5    4        e #3  d  [      (f
E5     4        e  3  d  =      )
E5     4        e  3  d  ]      .
E5     4        e  3  d  [      .
E5     4        e  3  d  =      .
E5     4        e  3  d  ]      .
measure 57
E5     4        e  3  d  [      (
B#4    4        e #3  d  =      )
B#4    4        e  3  d  ]      .
B#4    4        e  3  d  [      .
B#4    4        e  3  d  =      .
B#4    4        e  3  d  ]      .
B#4    4        e  3  d  [      (
C#5    4        e  3  d  =      )
C#5    4        e  3  d  ]      .
C#5    4        e  3  d  [      .
C#5    4        e  3  d  =      .
C#5    4        e  3  d  ]      .
measure 58
C#5    4        e  3  u  [      (
F#4    4        e  3  u  =      )
F#4    4        e  3  u  ]      .
F#4    4        e  3  u  [      .
F#4    4        e  3  u  =      .
F#4    4        e  3  u  ]      .
F#4    4        e  3  u  [      (*[
G#4    4        e  3  u  =
A4     4        e  3  u  ]      )!
A4     4        e  3  u  [      (*
B4     4        e n3  u  =      +
C#5    4        e  3  u  ]      )!]
measure 59
G#4   12        q     u
E5    24        h     d
D#5   12        q #   d
measure 60
E5     4        e  3  d  [      .
B4     4        e  3  d  =      .
A4     4        e  3  d  ]      .
G#4    4        e  3  u  [      .
F#4    4        e  3  u  =      .
E4     4        e  3  u  ]      .
G#3    4        e  3  u  [      .
B3     4        e  3  u  =      .
E4     4        e  3  u  ]      .
G#4    4        e  3  d  [      .
B4     4        e  3  d  =      .
E5     4        e  3  d  ]      .
measure 61
A5     4        e  3  d  [
F#5    4        e  3  d  =
E5     4        e  3  d  ]
D#5    4        e #3  d  [
C#5    4        e  3  d  =
B4     4        e  3  d  ]
D#4    4        e #3  u  [
F#4    4        e  3  u  =
B4     4        e  3  u  ]
D#5    4        e  3  d  [
F#5    4        e  3  d  =
A5     4        e  3  d  ]
measure 62
G#5    4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
G#4    4        e  3  u  [
F#4    4        e  3  u  =
E4     4        e  3  u  ]
G#3    4        e  3  u  [
B3     4        e  3  u  =
E4     4        e  3  u  ]
G#4    4        e  3  d  [
B4     4        e  3  d  =
E5     4        e  3  d  ]
measure 63
D5    21        q:n   d         f+(
C#5    3        s     d           )
D5     9        e.    d  [        (
C#5    3        s     d  =\
D5     9        e.    d  =
C#5    3        s     d  ]\       )
measure 64
D5    12        q     d
rest  12        q
rest  24        h
mheavy2 65            :|
D5    21        q:    d         p (
C#5    3        s     d           )
D5     9        e.    d  [        (
C#5    3        s     d  =\
D5     9        e.    d  =
C#5    3        s     d  ]\       )
measure 66
D5    12        q     d
rest  12        q
rest  24        h
measure 67
D5    21        q:    d           (
C#5    3        s     d           )
D5     9        e.    d  [        (
C#5    3        s     d  =\
D5     9        e.    d  =
C#5    3        s     d  ]\       )
measure 68
*               E   0
D5    36        h.    d
*               F   18
G5    12        q n   d
measure 69
F5    21        q:n   d         (f
E5     3        s     d         )
F5     9        e.    d  [      (
E5     3        s     d  =\
F5     9        e.    d  =
E5     3        s     d  ]\     )
measure 70
F5    24        h n   d
E5    24        h     d
measure 71
F#5   21        q:#   d         (+
E#5    3        s #   d         )
F#5    9        e.    d  [      (
E#5    3        s     d  =\
F#5    9        e.    d  =
G5     3        s n   d  ]\     )
measure 72
E5    21        q:n   d         +(
D#5    3        s #   d          )
E5     9        e.    d  [      (
D#5    3        s     d  =\
E5     9        e.    d  =
G5     3        s n   d  ]\     )
measure 73
F#5   24        h     d
A#4   24        h #   u
measure 74
B4    21        q:    d         (
G4     3        s n   u         )
F#4    9        e.    u  [      (
G4     3        s     u  =\
F#4    9        e.    u  =
G4     3        s     u  ]\     )
measure 75
F#4   21        q:    u         (p
G4     3        s n   u         )
F#4    9        e.    u  [      (
G4     3        s     u  =\
F#4    9        e.    u  =
G4     3        s     u  ]\     )
measure 76
*               E   0
F#4   48        w     u
measure 77
*               F   18
F4    48        w n   u
measure 78
E4    12        q n   u         f
 G3   12        q     u
gD5    4        t     u  [[[    (
gC5    4        t n   u  ===
gB4    4        t     u  ]]]
C5    12        q n   d         )+.
E5    12        q     d           .
C5    12        q     d           .
measure 79
rest  12        q
gD5    4        t     u  [[[    (
gC5    4        t n   u  ===
gB4    4        t     u  ]]]
C5    12        q n   d         )+.
E5    12        q     d           .
C5    12        q     d           .
measure 80
rest  12        q
gC5    4        t n   u  [[[    (
gB4    4        t     u  ===
gA4    4        t     u  ]]]
B4    12        q     d         ).
D5    12        q     d          .
B4    12        q     d          .
measure 81
C5    12        q n   d
E4    12        q     u         (
F4    12        q n   u
G4    12        q n   u         )
measure 82
A4    24        h     u         (Z
 C4   24        h n   u         [
B4     6        e     u         )
 D4    6        e     u         ]
rest   6        e
rest  12        q
measure 83
C5    12        q n   d
C5    24        h     d         Z.
A4     6        e     u  [      (
F4     6        e n   u  ]      )
measure 84
E4    12        q     u
E4    24        h     u         Z.
F4     6        e n   u  [      (
D4     6        e     u  ]      )
measure 85
E4    12        q     u         (
C5    12        q n   d         )
B4    12        q     d
rest  12        q
measure 86
B4    24        h     u         Z
 D4   24        h     u
rest  24        h
measure 87
C5    12        q n   d
C5    24        h     d         Z.
C5    12        q     d
measure 88
C5    12        q n   d
rest  12        q
F4    12        q n   u
rest  12        q
measure 89
E4    12        q     u
rest  12        q
rest  24        h
measure 90
C5     4        e n3  d  [      mf
E5     4        e  3  d  =
D5     4        e  3  d  ]
F5     4        e n3  d  [
E5     4        e  3  d  =
G5     4        e n3  d  ]
F5     4        e  3  d  [
A5     4        e  3  d  =
G5     4        e  3  d  ]
F5     4        e  3  d  [      .
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
measure 91
C#5   48        w #   u         +(Z
 E4   48        w     u          [
measure 92
D5    12        q     u          )
 D4   12        q     u          ]
rest  12        q
rest  24        h
measure 93
D5     4        e  3  d  [       mf
F5     4        e n3  d  =
E5     4        e  3  d  ]
G5     4        e n3  d  [
F5     4        e  3  d  =
A5     4        e  3  d  ]
G5     4        e  3  d  [
Bf5    4        e f3  d  =
A5     4        e  3  d  ]
G5     4        e  3  d  [
F5     4        e  3  d  =
E5     4        e  3  d  ]
measure 94
D#5   48        w #   d          Z(
 F#4  48        w #   d         +
measure 95
E5     4        e  3  d  [        )mf
B5     4        e  3  d  =
A5     4        e  3  d  ]
G5     4        e n3  d  [
F#5    4        e  3  d  =
E5     4        e  3  d  ]
D#5    4        e #3  d  [
C5     4        e n3  d  =
B4     4        e  3  d  ]
A4     4        e  3  u  [
G4     4        e n3  u  =
F#4    4        e  3  u  ]
measure 96
E4    12        q     u
rest  12        q
rest  24        h
measure 97
*               D       cresc.
P    C17:f33
B4     4        e  3  d  [
D5     4        e  3  d  =
C#5    4        e #3  d  ]      +
B4     4        e  3  d  [
D5     4        e  3  d  =
C#5    4        e  3  d  ]
B4     4        e  3  d  [
D5     4        e  3  d  =
C#5    4        e  3  d  ]
B4     4        e  3  u  [
A4     4        e  3  u  =
G#4    4        e #3  u  ]      +
measure 98
A4     4        e  3  d  [      f
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
A4     4        e  3  d  [
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 99
B4     4        e  3  d  [
C#5    4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
G#5    4        e  3  d  =
C#5    4        e  3  d  ]
B4     4        e  3  d  [
C#5    4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
G#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 100
A4     4        e  3  d  [
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
A4     4        e  3  d  [
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 101
B4     4        e  3  d  [
C#5    4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
G#5    4        e  3  d  =
C#5    4        e  3  d  ]
B4     4        e  3  d  [
C#5    4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
G#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 102
A4     4        e  3  d  [
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
A#4    4        e #3  d  [
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A#5    4        e #3  d  [
F#5    4        e  3  d  =
C#5    4        e  3  d  ]
measure 103
B4     4        e  3  d  [
D5     4        e  3  d  =
F#5    4        e  3  d  ]
B5     4        e  3  d  [
F#5    4        e  3  d  =
D5     4        e  3  d  ]
B4     4        e  3  d  [
D5     4        e  3  d  =
G#5    4        e  3  d  ]
B5     4        e  3  d  [
G#5    4        e  3  d  =
D5     4        e  3  d  ]
measure 104
A4     4        e n3  d  [      +
C#5    4        e  3  d  =
F#5    4        e  3  d  ]
A5     4        e  3  d  [
G#5    4        e  3  d  =
F#5    4        e  3  d  ]
B4     4        e  3  d  [
C#5    4        e  3  d  =
E#5    4        e #3  d  ]
G#5    4        e  3  d  [
F#5    4        e  3  d  =
E#5    4        e  3  d  ]
measure 105
F#5   12        q     d
rest  12        q
E#5    6        e #   d  [      (p
F#5    6        e     d  =      )
F#5    6        e     d  =      .
F#5    6        e     d  ]      .
measure 106
F#5   12        q     d         (
C#5   12        q     d         )
C#5    6        e     d  [      (
D5     6        e     d  =      )
D5     6        e     d  =      .
D5     6        e     d  ]      .
measure 107
D5    12        q     d         (
G#4   12        q     u         )
*               E   0
G#4    6        e     u  [      (
F#4    6        e     u  =      )
F#4    6        e     u  =      .
*               F   18
F#4    6        e     u  ]      .
measure 108
F#4   12        q     u         f
rest  12        q
B4    12        q     d
rest  12        q
measure 109
A4    48-       w     u        -p
measure 110
A4    12        q     u
*               E   0
A4    12        q     u         .(
A4    12        q     u         .
*               F   18
A4    12        q     u         .)
measure 111
B4    48-       w     d        -mf
measure 112
*               D       cresc.
P    C17:f33
B4    48        w     d
measure 113
C#5   12        q     d         f
gD5    4        t     u  [[[    (
gC#5   4        t     u  ===
gB4    4        t     u  ]]]
C#5   12        q     d         ) .
E5    12        q     d           .
C#5   12        q     d           .
measure 114
rest  12        q
gB4    4        t     u  [[[    (
gA4    4        t     u  ===
gG#4   4        t     u  ]]]
A4    12        q     u         ).
C#5   12        q     d          .
A4    12        q     u          .
measure 115
rest  12        q
gA4    4        t     u  [[[    (
gG#4   4        t     u  ===
gF#4   4        t     u  ]]]
G#4   12        q     u         ).
B4    12        q     d          .
D5    12        q     d          .
measure 116
C#5   12        q     d
C#4   12        q     u         (
D4    12        q     u
E4    12        q     u         )
measure 117
F#4   24        h     u         (Z
 A3   24        h     u         [
G#4    6        e     u         )
 B3    6        e     u         ]
rest   6        e
rest  12        q
measure 118
A4    12        q     u
A4    24        h     u         Z.
F#4    6        e     u  [      (
D4     6        e     u  ]      )
measure 119
C#4   12        q     u
C#4   24        h     u         Z.
D4     6        e     u  [      (
B3     6        e     u  ]      )
measure 120
A3    12        q     u         (
A4    12        q     u         )
G#4   12        q     u
rest  12        q
measure 121
B4    24        h     u         Z
 G#4  24        h     u
rest  24        h
measure 122
A4    12        q     u
A4    24        h     u         .Z
A4    12        q     u
measure 123
A4    12        q     u
rest  12        q
D4    12        q     u
rest  12        q
measure 124
C#4   12        q     u
rest  12        q
rest  24        h
measure 125
rest  12        q
A4    12        q     u         .(p
A4    12        q     u         .
A4    12        q     u         .)
measure 126
A4    48        w     u
measure 127
G#4   48        w     u
measure 128
G4     6        e n   u  [      .
G4     6        e     u  =      (
F#4    6        e     u  =
G4     6        e     u  ]
F#4    6        e     u  [
G4     6        e     u  =
A4     6        e     u  =
G4     6        e     u  ]      )
measure 129
F#4    6        e     u  [      (
G4     6        e n   u  =
E5     6        e     u  =
D5     6        e     u  ]
C#5    6        e     u  [
B4     6        e     u  =
A4     6        e     u  =
G4     6        e     u  ]      )
measure 130
F#4   12        q     u
rest  12        q
rest   6        e
A#4    6        e #   u  [      (
B4     6        e     u  =
A#4    6        e     u  ]
measure 131
B4     6        e     u  [      ).
E4     6        e     u  =      (
F#4    6        e     u  =
E4     6        e     u  ]
F#4    6        e     u  [      ).
C#4    6        e     u  =      (
B3     6        e     u  =
C#4    6        e     u  ]
measure 132
B3    12        q     u         )
rest  12        q
rest  24        h
measure 133
A4    12        q     u         f
 E4   12        q     u
 A3   12        q     u
rest  12        q
rest  24        h
measure 134
D5    24        h     u
 E4   24        h     u
rest  24        h
measure 135
C#5   24        h     u
 E4   24        h     u
rest  24        h
measure 136
D5    24        h     u
 E4   24        h     u
rest  24        h
measure 137
C#5   12        q     d
rest  12        q
D5    12        q     d
rest  12        q
measure 138
E5    48        w     d
measure 139
D#5   24        h #   d
D5    24        h n   d
measure 140
C#5   12        q     d
A5    12        q     d         (
F#5   12        q     d         )
D5    12        q     d
measure 141
B4    12        q     d         (
G#4   12        q     u
E4    12        q     u         )
D4    12        q     u
measure 142
C#4    4        e  3  u  [      .
F#4    4        e  3  u  =      .
E4     4        e  3  u  ]      .
D4     4        e  3  u  [      .
C#4    4        e  3  u  =      .
B3     4        e  3  u  ]      .
A3     4        e  3  u  [      .
C#4    4        e  3  u  =      .
E4     4        e  3  u  ]      .
A4     4        e  3  u  [      .
C#5    4        e  3  u  =      .
A4     4        e  3  u  ]      .
measure 143
F#4   12        q     u
rest  12        q
rest  24        h
measure 144
C#4   24        h     u
E4    12        q     u         (
D4    12        q     u         )
measure 145
C#4   12        q     u
rest  12        q
A4    18        q.    u         Z(
B4     3        s     u  [[
A4     3        s     u  ]]      )
measure 146
G#4   12        q     u
C#5   12        q     d          p
C#5    6        e     d  [      (
B4     6        e     d  =      )
B4     6        e     d  =      (
A#4    6        e #   d  ]      )
measure 147
A#4   12        q #   u         (
B4     6        e     d         )
rest   6        e
G#4   18        q.    u         f(
A4     3        s n   u  [[
B4     3        s     u  ]]      )
measure 148
A4    12        q     u         Z(
G#4    6        e     u         .)
rest   6        e
B4    12        q     d         Z(
A4     6        e     u         .)
rest   6        e
measure 149
G#4   12        q     u         f(
A4     6        e     u         .)
rest   6        e
G#4    6        e     u  [      p(
A4     6        e     u  =       )
A4     6        e     u  =       .
A4     6        e     u  ]       .
measure 150
A4    12        q     u         (
E#4   12        q #   u         )
E#4    6        e     u  [      (
F#4    6        e     u  =      )
F#4    6        e     u  =      .
F#4    6        e     u  ]      .
measure 151
F#4   12        q     u         (
B3     6        e     u         )
rest   6        e
B3     4        e  3  u  [      (*[
C#4    4        e  3  u  =
D4     4        e  3  u  ]      )!
D4     4        e  3  u  [      (*
E4     4        e n3  u  =        +
F#4    4        e  3  u  ]      )!]
measure 152
C#4   24        h     u
gE4    0        e     u         (
D4    18        q.    u         )t(
C#4    3        s     u  [[
D4     3        s     u  ]]       )
measure 153
D4    12        q     u         (
C#4   12        q     u         )
rest  24        h
measure 154
A3    48-       w     u        -pp
measure 155
A3     6        e     u  [      (
A#3    6        e #   u  =      )
A#3    6        e     u  =      .
A#3    6        e     u  ]      .
B3    24-       h     u        -
measure 156
B3     6        e     u  [      (
B#3    6        e #   u  =      )
B#3    6        e     u  =      .
B#3    6        e     u  ]      .
B#3   24-       h     u        -
measure 157
B#3    6        e     u  [      (
C#4    6        e     u  =      )
C#4    6        e     u  =      .
C#4    6        e     u  ]      .
C#4   24-       h     u        -
measure 158
C#4    6        e     u  [      (
D4     6        e     u  =      )
D4     6        e     u  =      .
D4     6        e     u  ]      .
D4     6        e     u  [      (
D#4    6        e #   u  =      )
D#4    6        e     u  =      .
D#4    6        e     u  ]      .
measure 159
E4     6        e     d  [      (
A5     6        e     d  =      )
A5     6        e     d  =      .
A5     6        e     d  ]      .
A5     6        e     d  [      (
C#6    6        e     d  =      )
C#6    6        e     d  =      .
C#6    6        e     d  ]      .
measure 160
*               D       dim.
P   C17:f33
C#6    6        e     d         .
rest   6        e
A5     6        e     d         .
rest   6        e
E5     6        e     d         .
rest   6        e
C#5    6        e     d         .
rest   6        e
measure 161
A4     6        e     u         .
rest   6        e
E4     6        e     u         .
rest   6        e
C#4    6        e     u         .
rest   6        e
A3     6        e     u         .
rest   6        e
measure 162
A3    48-       w     u        -p
measure 163
A3    24        h     u
G#3   12        q     u
G#3   12        q     u
measure 164
A3    12        q     u         f
rest  12        q
rest  24        h
measure 165
rest  48
measure 166
D4    48-       w     u        -
measure 167
D4    48        w     u
measure 168
C#4   12        q     u
A4    24        h     u
F#4   12        q     u
measure 169
E4    12        q     u
A5    24        h     d
G#5   12        q     d
measure 170
A5     4        e  3  d  [      .f
E5     4        e  3  d  =      .
D5     4        e  3  d  ]      .
C#5    4        e  3  d  [      .
B4     4        e  3  d  =      .
A4     4        e  3  d  ]      .
C#4    4        e  3  u  [      .
E4     4        e  3  u  =      .
G#4    4        e  3  u  ]      .
A4     4        e  3  d  [      .
C#5    4        e  3  d  =      .
E5     4        e  3  d  ]      .
measure 171
D5     4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
G#4    4        e  3  u  [
F#4    4        e  3  u  =
E4     4        e  3  u  ]
G#3    4        e  3  u  [
B3     4        e  3  u  =
E4     4        e  3  u  ]
G#4    4        e  3  d  [
B4     4        e  3  d  =
D5     4        e  3  d  ]
measure 172
C#5    4        e  3  d  [
E5     4        e  3  d  =
D5     4        e  3  d  ]
C#5    4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
C#4    4        e  3  u  [
E4     4        e  3  u  =
G#4    4        e  3  u  ]
A4     4        e  3  d  [
C#5    4        e  3  d  =
E5     4        e  3  d  ]
measure 173
D5     4        e  3  d  [
B4     4        e  3  d  =
A4     4        e  3  d  ]
G#4    4        e  3  u  [
F#4    4        e  3  u  =
E4     4        e  3  u  ]
G#3    4        e  3  u  [      ff
B3     4        e  3  u  =
E4     4        e  3  u  ]
G#4    4        e  3  d  [
B4     4        e  3  d  =
D5     4        e  3  d  ]
measure 174
C#5   12        q     d
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/01/03} [KHM:1700317811]
TIMESTAMP: DEC/26/2001 [md5sum:fd11ff696d70dbbfa2a02fedf0d78ddb]
09/16/94 W Hewlett
WK#:55,1      MV#:1
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Allegro
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:12   T:0/0  C:13  D:Allegro
rest  12        q
gB4    4        t     u  [[[    (
gA4    4        t     u  ===
gG#4   4        t     u  ]]]
A4    12        q     d         )f.
C#5   12        q     d           .
A4    12        q     d           .
measure 2
rest  12        q
gD4    4        t     u  [[[    (
gC#4   4        t     u  ===
gB3    4        t     u  ]]]
C#4   12        q     d         ).
E4    12        q     d          .
C#4   12        q     d          .
measure 3
rest  12        q
gC#4   4        t     u  [[[    (
gB3    4        t     u  ===
gA3    4        t     u  ]]]
B3    12        q     u         ).
D4    12        q     d          .
B3    12        q     u          .
measure 4
C#4   12        q     d
A3    12        q     u         (
B3    12        q     u
C#4   12        q     d         )
measure 5
D4    24        h     d         Z(
B3     6        e     u          )
rest   6        e
rest  12        q
measure 6
A3    12        q     u
E3    24        h     u         Z.
F#3   12        q     u
measure 7
E3    12        q     u
E4    24        h     d         Z.
E4    12        q     d
measure 8
E4    36        h.    d
rest  12        q
measure 9
G#4   24        h     d         Z
 B3   24        h     d
rest  24        h
measure 10
E4    12        q     d
A3    24        h     u         Z.
C#4   12        q     d
measure 11
F#4   12        q     d
rest  12        q
B3    12        q     u
rest  12        q
measure 12
A3    48-       w     u        -
measure 13
A3    12        q     u         p
C#4    6        e     u  [      (
B3     6        e     u  ]
A3     6        e     u  [
G#3    6        e     u  =
F#3    6        e     u  =
E3     6        e     u  ]      )
measure 14
D3    24        h     u
rest  24        h
measure 15
rest  48
measure 16
rest  12        q
G#4   24        h     d
G#4   12-       q     d        -
measure 17
G#4   12        q     d
G#4   24        h     d
E4    12-       q     d        -
measure 18
E4    12        q     d
C#4   12        q     d         (
A3    12        q     u
C#4   12        q     d         )
measure 19
*               DH      cre
P    C17:f33
D4     6        e     d  [      (
E4     6        e     d  =
D4     6        e     d  =
E4     6        e     d  ]      )
D4     6        e     d  [      (
E4     6        e     d  =
D4     6        e     d  =
E4     6        e     d  ]      )
measure 20
C#4   12        q     d
A3    24        h     u
A3    12        q     u
*               J
measure 21
*               DH      scen
P    C17:f33
E4    12        q     d
E4    24        h     d
B3    12        q     u
measure 22
C#4   12        q     d
C#4   12        q     d         (
A3    12        q     u
C#4   12        q     d         )
measure 23
*               DJ      do
P    C17:f33
D4     6        e     d  [      (
E4     6        e     d  =
D4     6        e     d  =
E4     6        e     d  ]      )
D4     6        e     d  [      (
E4     6        e     d  =
D4     6        e     d  =
E4     6        e     d  ]      )
measure 24
C#4   12        q     d         f
A3    24        h     u
A4    12        q     d
measure 25
F#4   24        h     d
E4    24        h     d
measure 26
D4    12        q     d
C#4   12        q     d
D4    12        q     d
B3    12        q     u
measure 27
*               E   18
A3    24        h     u
*     18        F   0
A4    24        h     d
measure 28
F#4   12        q     d         p
rest  12        q
rest  24        h
measure 29
rest   6        e
G4     6        e n   d  [      (
F#4    6        e     d  =
G4     6        e     d  ]
F#4   12        q     d         ).
D#4   12        q #   d          .
measure 30
E4    12        q     d         f.
gF#4   4        t     u  [[[    (
gE4    4        t     u  ===
gD#4   4        t     u  ]]]
E4    12        q     d         ).
G#4   12        q     d          .
E4    12        q     d          .
measure 31
rest  12        q
gA3    4        t     u  [[[    (
gG#3   4        t     u  ===
gF#3   4        t     u  ]]]
G#3   12        q     u         ).
B3    12        q     u          .
G#3   12        q     u          .
measure 32
rest  12        q
gE4    4        t     u  [[[    (
gD#4   4        t     u  ===
gC#4   4        t     u  ]]]
D#4   12        q #   d         ).+
F#4   12        q     d          .
D#4   12        q     d          .
measure 33
rest  12        q
gE4    4        t     u  [[[    (
gD#4   4        t     u  ===
gC#4   4        t     u  ]]]
D#4   12        q #   d         ).+
F#4   12        q     d          .
B3    12        q     u          .
measure 34
B3    24        h     u
rest  24        h
measure 35
F#4   24        h     d
rest  24        h
measure 36
E4    24        h     d
rest  24        h
measure 37
F#4   24        h     d
rest  24        h
measure 38
E4    12        q     d
rest  12        q
F#4   12        q     d
rest  12        q
measure 39
E4    12        q     d
rest  12        q
F#4   12        q     d
rest  12        q
measure 40
E4    12        q     d
rest  12        q
rest  24        h
measure 41
rest  24        h
C#4   12        q     d         (
A3    12        q     u         )
measure 42
F#3   12        q     u         (
E3    12        q     u
D#3   12        q #   u
E3    12        q     u         )
measure 43
F#3   48        w     u         (
measure 44
E3    12        q     u         )
rest  12        q
rest  24        h
measure 45
rest  48
measure 46
B3    12        q     u
rest  12        q
C#4   12        q     d
rest  12        q
measure 47
E4    12        q     d
E4    12        q     d
D#4   12        q #   d
D#4   12        q     d
measure 48
E4    12        q     d
rest  12        q
B3    24        h     u         Z
measure 49
D#4   24        h #   d         p
E#4   12        q #   d
B4    12        q     d
measure 50
B4    12        q     d         (
A4     6        e     d         )
rest   6        e
B3    24        h     u         f
measure 51
B3    12        q     u         Z(
D#4    6        e #   d         .)
rest   6        e
B3    12        q     u         Z(
G#4    6        e     d         .)
rest   6        e
measure 52
F#4   12        q     d         Z(
E4     6        e     d         .)
rest   6        e
rest  12        q
B4    12        q     d         p
measure 53
rest  12        q
E4    12        q     d
rest  12        q
E4    12        q     d
measure 54
rest  12        q
C#4   12        q     d
rest  24        h
measure 55
B3     6        e     d  [      (
B4     6        e     d  =
G#4    6        e     d  =
E4     6        e     d  ]      )
D#4   12        q #   d
D#4   12        q     d
measure 56
D#4   12        q     d         (
E4    12        q     d         )
rest  12        q
B4    12        q     d         f
measure 57
rest  12        q
E4    12        q     d
rest  12        q
E4    12        q     d
measure 58
rest  12        q
C#4   12        q     d
rest  24        h
measure 59
B3     6        e     d  [      (
E4     6        e     d  =
G#4    6        e     d  =
E4     6        e     d  ]      )
A4     6        e     d  [      (
F#4    6        e     d  =
D#4    6        e #   d  =
A3     6        e     d  ]      )
measure 60
G#3   24        h     u
G#4   24        h     d
measure 61
F#4   48        w     d
measure 62
G#4   48        w     d
measure 63
A4    48        w     d         (f
 A3   48        w     d         [
measure 64
G#4   12        q     d         )
 B3   12        q     d         ]
rest  12        q
rest  24        h
mheavy2 65            :|
A4    48        w     d         (p
measure 66
G#4   12        q     d         )
rest  12        q
rest  24        h
measure 67
A4    21        q:    d         (
G4     3        s n   d         )
A4     9        e.    d  [      (
G4     3        s     d  =\
A4     9        e.    d  =
G4     3        s     d  ]\     )
measure 68
*               E   0
A4    36        h.    d
*               F   18
C#5   12        q     d
measure 69
D5    12        q     d         f
A4    24        h     d
A4    12        q     d
measure 70
A4    48        w     d
measure 71
A4    21        q:    d         (
G#4    3        s #   d         )+
A4     9        e.    d  [      (
G#4    3        s     d  =\
A4     9        e.    d  =
B4     3        s     d  ]\     )
measure 72
G4    21        q n   d         (
F#4    3        s     d         )
G4     9        e.    d  [      (
F#4    3        s     d  =\
G4     9        e.    d  =
E4     3        s     d  ]\     )
measure 73
D#4   24        h #   d
F#4    6        e     d  [      (
E4     6        e     d  =
D#4    6        e     d  =
E4     6        e     d  ]      )
measure 74
D#4   21        q:#   d         (
E4     3        s     d         )
D#4    9        e.    d  [      (
E4     3        s     d  =\
D#4    9        e.    d  =
E4     3        s     d  ]\     )
measure 75
D#4   21        q:#   d         (p
E4     3        s     d         )
D#4    9        e.    d  [      (
E4     3        s     d  =\
D#4    9        e.    d  =
E4     3        s     d  ]\     )
measure 76
*               E   0
D#4   48        w #   d
measure 77
*               F   18
D4    48        w     d
measure 78
E4    12        q     u         f
 G3   12        q n   u
gF4    4        t n   u  [[[    (
gE4    4        t     u  ===
gD4    4        t     u  ]]]
E4    12        q     d         )'
G4    12        q n   d          '
E4    12        q     d          '
measure 79
rest  12        q
gF4    4        t n   u  [[[    (
gE4    4        t     u  ===
gD4    4        t     u  ]]]
E4    12        q     d         ).
G4    12        q n   d          .
E4    12        q     d          .
measure 80
rest  12        q
gE4    4        t n   u  [[[    (
gD4    4        t     u  ===
gC4    4        t n   u  ]]]
D4    12        q     d         ).
F4    12        q n   d          .
D4    12        q     d          .
measure 81
E4    12        q     d
C4    12        q n   d         (
D4    12        q     d
E4    12        q     d         )
measure 82
F4    24        h n   d         Z(
D4     6        e     d          )
rest   6        e
rest  12        q
measure 83
C4    12        q n   d
G3    24        h n   u         Z
A3    12        q     u
measure 84
G3    12        q n   u
G4    24        h n   d         Z.
G4    12        q     d
measure 85
G4    36        h.n   d
rest  12        q
measure 86
D4    24        h     u         Z
 G3   24        h n   u
rest  24        h
measure 87
C4    12        q n   d
C4    24        h     d         Z.
E4    12        q     d
measure 88
A4    12        q     d
rest  12        q
D4    12        q     d
rest  12        q
measure 89
E4    12        q n   u
 G3   12        q     u
rest  12        q
rest  24        h
measure 90
rest  48
measure 91
G4    48        w n   d         Z(
measure 92
F4    12        q n   d          )
rest  12        q
rest  24        h
measure 93
rest  48
measure 94
A4    48        w     d         Z
measure 95
G4    48        w n   d         mf(
measure 96
*               D       cresc.
P    C17:f33
G#4   48-       w     d        -  )
measure 97
G#4   36        h.    d
B4    12        q     d
measure 98
A4    48        w     d         f
measure 99
G#4   48        w     d         Z
measure 100
A4    48        w     d
measure 101
G#4   48        w     d         Z
measure 102
F#4   48-       w     d        -
measure 103
F#4   24        h     d
G#4   24        h     d
measure 104
A4    24        h     d
E#4   12        q #   d         (
B4    12        q     d         )
measure 105
A4    24        h     d
rest  24        h
measure 106
C#4   24        h     d         p
rest  24        h
measure 107
D4    24        h     d
*               E   0
D4     6        e     d  [      (
D#4    6        e #   d  =      )
D#4    6        e     d  =      .
*               F   18
D#4    6        e     d  ]      .
measure 108
C#4   12        q     d         f
rest  12        q
G#4   12        q     d
rest  12        q
measure 109
F#4   48-       w     d        -p
measure 110
F#4   12        q     d
F#4   12        q     d         .(
F#4   12        q     d         .
F#4   12        q     d         .)
measure 111
B4    12        q     d         mf
E4    24        h     d
E4    12-       q     d        -
measure 112
*               D       cresc.
P    C17:f33
E4    12        q     d
E4    24        h     d
E4    12-       q     d        -
measure 113
E4    12        q     d          f
gB4    4        t     u  [[[    (
gA4    4        t     u  ===
gG#4   4        t     u  ]]]
A4    12        q     d         ) .
C#5   12        q     d           .
A4    12        q     d           .
measure 114
rest  12        q
gD4    4        t     u  [[[    (
gC#4   4        t     u  ===
gB3    4        t     u  ]]]
C#4   12        q     d         ).
E4    12        q     d          .
C#4   12        q     d          .
measure 115
rest  12        q
gC#4   4        t     u  [[[    (
gB3    4        t     u  ===
gA3    4        t     u  ]]]
B3    12        q     u         ).
D4    12        q     d          .
B3    12        q     u          .
measure 116
C#4   12        q     d
A3    12        q     u         (
B3    12        q     u
C#4   12        q     d         )
measure 117
D4    24        h     d         Z(
B3     6        e     u          )
rest   6        e
rest  12        q
measure 118
A3    12        q     u
E3    24        h     u         Z.
F#3   12        q     u
measure 119
E3    12        q     u
E4    24        h     d         Z.
E4    12        q     d
measure 120
E4    36        h.    d
rest  12        q
measure 121
G#4   24        h     d         Z
 B3   24        h     d
rest  24        h
measure 122
E4    12        q     d
A3    24        h     u         Z.
C#4   12        q     d
measure 123
F#4   12        q     d
rest  12        q
B3    12        q     u
rest  12        q
measure 124
*               E   18
*     42        F   0
A3    48-       w     u        -
measure 125
A3    12        q     u         p
C#4    6        e     u  [      (
B3     6        e     u  ]
A3     6        e     u  [
G#3    6        e     u  =
F#3    6        e     u  =
E3     6        e     u  ]      )
measure 126
F#3   48        w     u
measure 127
E3    48        w     u
measure 128
E3     6        e     d  [      .
E4     6        e     d  =      (
D#4    6        e #   d  =
E4     6        e     d  ]
D#4    6        e     d  [
E4     6        e     d  =
F#4    6        e     d  =
E4     6        e     d  ]      )
measure 129
D#4    6        e #   d  [      (
E4     6        e     d  =
G4     6        e n   d  =
F#4    6        e     d  ]
E4     6        e     d  [
G4     6        e     d  =
F#4    6        e     d  =
E4     6        e     d  ]      )
measure 130
D4    12        q n   d         +
rest  12        q
rest  24        h
measure 131
rest   6        e
C#4    6        e     d  [      (
D4     6        e     d  =
C#4    6        e     d  ]
D4     6        e     d         ).
rest   6        e
rest  12        q
measure 132
rest   6        e
A3     6        e     u  [      (
B3     6        e     u  =
A3     6        e     u  ]
*               E   0
B3     6        e     u  [
A3     6        e     u  =
G#3    6        e     u  =
*               F   18
F#3    6        e     u  ]      )
measure 133
E3    12        q     u         f
rest  12        q
rest  24        h
measure 134
B4    24        h     d
rest  24        h
measure 135
A4    24        h     d
rest  24        h
measure 136
B4    24        h     d
rest  24        h
measure 137
A4    12        q     d
rest  12        q
G#4   12        q     d
rest  12        q
measure 138
A3    24        h     u
A4    24-       h     d        -
measure 139
A4    24        h     d
G#4   24        h     d
measure 140
A4    12        q     d
rest  24        h
D4    12        q     d
measure 141
B3    12        q     u         (
G#3   12        q     u
E3    12        q     u         )
D3    12        q     u
measure 142
C#3   12        q     u
rest  12        q
rest  24        h
measure 143
A3    36        h.    u
B3     6        e     u  [      (
C4     6        e n   u  ]      )
measure 144
C#4   12        q     d
A3    12        q     u
G#3   24        h     u
measure 145
A3    12        q     u
rest  12        q
E3    24        h     u         Z
measure 146
G#3   24        h     u         p
A#3   12        q #   u
E4    12        q     d
measure 147
E4    12        q     d         (
D4     6        e     d         )
rest   6        e
E4    24        h     d         f
measure 148
E4    12        q     d         Z(
G#4    6        e     d         .)
rest   6        e
E4    12        q     d         Z(
A4     6        e     d         .)
rest   6        e
measure 149
B4    12        q     d         f(
A4     6        e     d         .)
rest   6        e
rest  12        q
E4    12        q     d         p
measure 150
rest  12        q
A3    12        q     u
rest  12        q
A3    12        q     u
measure 151
rest  12        q
F#3   12        q     u
rest  24        h
measure 152
rest   6        e
E4     6        e     d  [      (
C#4    6        e     d  =
A3     6        e     d  ]      )
G#3   12        q     u
G#3   12        q     u
measure 153
A3    24        h     u
G#4    6        e     d  [      (pp
A4     6        e     d  =      )
A4     6        e     d  =      .
A4     6        e     d  ]      .
measure 154
A4     6        e     d  [      (
E#4    6        e #   d  =      )
E#4    6        e     d  =      .
E#4    6        e     d  ]      .
E#4    6        e     d  [      (
F#4    6        e     d  =      )
F#4    6        e     d  =      .
F#4    6        e     d  ]      .
measure 155
*               D       poco
P   C17:f33
F#4   24-       h     d        -
F#4    6        e     d  [      (
G4     6        e n   d  =      )
*               D       a
P   C17:f33
G4     6        e     d  =      .
G4     6        e     d  ]      .
measure 156
*               D       poco
P   C17:f33
G4    24-       h n   d        -
G4     6        e     d  [      (
*               DH      cre
P   C17:f33
G#4    6        e #   d  =      )
G#4    6        e     d  =      .
*               J
G#4    6        e     d  ]      .
measure 157
*      6        DH      scen
P   C17:f33
G#4   24-       h     d        -
G#4    6        e     d  [      (
A4     6        e     d  =      )
A4     6        e     d  =      .
*               J
A4     6        e     d  ]      .
measure 158
*               D       do
A4    24        h     d
B4     6        e     d  [      (
A4     6        e     d  =      )
A4     6        e     d  =      .
A4     6        e     d  ]      .
measure 159
A4    12        q     d         f
rest  12        q
rest  24        h
measure 160
rest  48
measure 161
rest  48
measure 162
F#3   48        w     u         p
measure 163
F#3    6        e     u  [      (>
E3     6        e     u  =      )
E3     6        e     u  =      .
E3     6        e     u  ]      .
E3     6        e     u  [      (>
D3     6        e     u  =      )
D3     6        e     u  =      .
D3     6        e     u  ]      .
measure 164
C#3   12        q     u         f
rest  12        q
rest  24        h
measure 165
rest  48
measure 166
B3    48-       w     u        -
measure 167
B3    48        w     u
measure 168
A3    48        w     u
measure 169
C#4   24        h     d
B3    12        q     u
D4    12        q     d
measure 170
C#4   48        w     d
measure 171
D4    24        h     d
B3    24        h     u
measure 172
C#4   48        w     d
measure 173
B3    12        q     u
rest  12        q
D5     4        e  3  d  [      ff
B4     4        e  3  d  =
G#4    4        e  3  d  ]
E4     4        e  3  d  [
D4     4        e  3  d  =
B3     4        e  3  d  ]
measure 174
A3    12        q     u
rest  12        q
rest  24        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/01/04} [KHM:1700317811]
TIMESTAMP: DEC/26/2001 [md5sum:5131cee1a2b9f9aa962dc341e8de29ad]
09/16/94 W Hewlett
WK#:55,1      MV#:1
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Allegro
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:12   T:0/0  C:22  D:Allegro
A2    24        h     u         f
rest  24        h
measure 2
A2    24        h     u
rest  24        h
measure 3
E2    24        h     u
rest  24        h
measure 4
A2    24        h     u
rest  24        h
measure 5
D2    24        h     u         Z(
D3     6        e     d          )
rest   6        e
rest  12        q
measure 6
C#3   12        q     u
C#3   24        h     u         Z.
D3    12        q     d
measure 7
E3    12        q     d
E3    24        h     d         Z.
E3    12        q     d
measure 8
C#3   12        q     u
A2    12        q     u
E3    12        q     d
rest  12        q
measure 9
D3    24        h     d         Z
rest  24        h
measure 10
C#3   12        q     u
C#3   24        h     u         Z.
C#3   12        q     u
measure 11
D3    12        q     d
rest  12        q
E3    12        q     d
rest  12        q
measure 12
rest   6        e
A2     6        e     u  [      (p
G#2    6        e     u  =
A2     6        e     u  ]
G#2    6        e     u  [
A2     6        e     u  =
D3     6        e     u  =
C#3    6        e     u  ]      )
measure 13
F#3    6        e     d  [      (
E3     6        e     d  =
A3     6        e     d  =
G#3    6        e     d  ]      )
F#3    6        e     d  [      (
E3     6        e     d  =
D3     6        e     d  =
C#3    6        e     d  ]      )
measure 14
B2    24        h     u
rest  24        h
measure 15
rest  48
measure 16
rest   6        e
E3     6        e     d  [      (
D#3    6        e #   d  =
E3     6        e     d  ]
D#3    6        e     d  [
E3     6        e     d  =
A3     6        e     d  =
G#3    6        e     d  ]      )
measure 17
C#4    6        e     d  [      (
B3     6        e     d  =
F#4    6        e     d  =
E4     6        e     d  ]      )
E4     6        e     d  [      (
D4     6        e n   d  =      +
C#4    6        e     d  =
B3     6        e     d  ]      )
measure 18
A3    48        w     d         (
measure 19
*               DH      cre
P    C17:f33
B3    48        w     d
measure 20
C#4   48        w     d         )
*               J
measure 21
*               DH      scen
P    C17:f33
G#3   48        w     d
measure 22
A3    48        w     d
measure 23
*               DJ      do
P    C17:f33
B3    48        w     d
measure 24
C#4   48        w     d         f
measure 25
D4    24        h     d
E4    24        h     d
measure 26
F#4   12        q     d
C#4   12        q     d
D4    12        q     d
B3    12        q     d
measure 27
C#4   24        h     d
rest  24        h
measure 28
D4    24        h     d         p
rest  24        h
measure 29
rest   6        e
C#3    6        e     u  [      (
D3     6        e     u  =
C#3    6        e     u  ]
D3    12        q     d         ).
D#3   12        q #   d          .
measure 30
E3    24        h     d         f
rest  12        q
E2    12        q     u
measure 31
E3    12        q     d
rest  24        h
E2    12        q     u
measure 32
D#2   24        h #   u
rest  12        q
D#2   12        q     u
measure 33
D#3   24        h #   d
rest  12        q
D#3   12        q     d
measure 34
E3    24        h     d
rest  24        h
measure 35
D#3   24        h #   d
rest  24        h
measure 36
E3    24        h     d
rest  24        h
measure 37
D#3   24        h #   d
rest  24        h
measure 38
E3    12        q     d
rest  12        q
D#3   12        q #   d
rest  12        q
measure 39
E3    12        q     d
rest  12        q
D#3   12        q #   d
rest  12        q
measure 40
E3    12        q     d
rest  12        q
rest  24        h
measure 41
rest  48
measure 42
A2    12        q     u         (
G2    12        q n   u
F#2   12        q     u
E2    12        q     u         )
measure 43
D#2   48        w #   u         (
measure 44
E2    12        q     u         )
rest  12        q
rest  24        h
measure 45
rest  48
measure 46
G#3   12        q     d
rest  12        q
A3    12        q     d
rest  12        q
measure 47
B3    12        q     d
B3    12        q     d
B2    12        q     u
B2    12        q     u
measure 48
E3    12        q     d
rest  12        q
E3    24        h     d         Z
measure 49
B3    12        q     d         p
G#3   12        q     d
C#4   12        q     d
C#4   12        q     d
measure 50
F#3   24        h     d
B3    24        h     d         f
measure 51
E3    12        q     d         Z(
B3     6        e     d         .)
rest   6        e
D#3   12        q #   d         Z(
E3     6        e     d         .)
rest   6        e
measure 52
A2    12        q     u         Z(
G#2    6        e     u         .)
rest   6        e
rest  12        q
G#3   12        q     d         p
measure 53
rest  12        q
G#3   12        q     d
rest  12        q
A3    12        q     d
measure 54
rest  12        q
A3    12        q     d
rest  24        h
measure 55
B3    12        q     d
B3    12        q     d
B2    12        q     u
B2    12        q     u
measure 56
E3    24        h     d
rest  12        q
G#3   12        q     d         f
measure 57
rest  12        q
G#3   12        q     d
rest  12        q
A3    12        q     d
measure 58
rest  12        q
A3    12        q     d
rest  24        h
measure 59
B3    12        q     d
B3    12        q     d
B2    12        q     u
B2    12        q     u
measure 60
E3    12        q     d
E3    12        q     d
E3    12        q     d
E3    12        q     d
measure 61
E3    12        q     d
E3    12        q     d
E3    12        q     d
E3    12        q     d
measure 62
E3    12        q     d
E3    12        q     d
E3    12        q     d
E3    12        q     d
measure 63
F3    48        w n   d         (f
measure 64
E3    12        q     d         )
rest  12        q
rest  24        h
mheavy2 65            :|
F4    48        w n   d         (p
measure 66
E4    12        q     d         )
rest  12        q
rest  24        h
measure 67
F4    21        q:n   d         (
E4     3        s     d         )
F4     9        e.    d  [      (
E4     3        s     d  =\
F4     9        e.    d  =
E4     3        s     d  ]\     )
measure 68
*               E   0
F4    36        h.n   d
*               F   18
E4    12        q     d
measure 69
D4    21        q:    d         (f
C#4    3        s     d         )
D4     9        e.    d  [      (
C#4    3        s     d  =\
D4     9        e.    d  =
C#4    3        s     d  ]\     )
measure 70
D4    24        h     d
C4    24        h n   d
measure 71
B3    48-       w     d        -
measure 72
B3    48-       w     d        -
measure 73
B3    48-       w     d        -
measure 74
B3    48-       w     d        -
measure 75
B3    48-       w     d        -p
measure 76
*               E   0
B3    48        w     d
measure 77
*               F   18
G3    48        w n   d
measure 78
C3    24        h n   u         f
 C2   24        h n   u
rest  24        h
measure 79
C3    24        h n   u
 C2   24        h n   u
rest  24        h
measure 80
G2    24        h n   u
rest  24        h
measure 81
C3    24        h n   u
rest  24        h
measure 82
F2    24        h n   u         (
F3     6        e n   d         )
rest   6        e
rest  12        q
measure 83
E3    12        q     d
E3    24        h     d         Z.
F3    12        q n   d
measure 84
G3    12        q n   d
G3    24        h     d         Z.
G3    12        q     d
measure 85
E3    12        q     d
C3    12        q n   u
G3    12        q n   d
rest  12        q
measure 86
F3    24        h n   d         Z
rest  24        h
measure 87
E3    12        q     d
E3    24        h     d         Z.
E3    12        q     d
measure 88
F3    12        q n   d
rest  12        q
G3    12        q n   d
rest  12        q
measure 89
C3     4        e n3  d  [      mf
E3     4        e  3  d  =
D3     4        e  3  d  ]
F3     4        e n3  d  [
E3     4        e  3  d  =
G3     4        e n3  d  ]
F3     4        e  3  d  [
A3     4        e  3  d  =
G3     4        e  3  d  ]
F3     4        e  3  d  [      .
E3     4        e  3  d  =      .
D3     4        e  3  d  ]      .
measure 90
C3    12        q n   u
rest  12        q
rest  24        h
measure 91
A2    48        w     u         Z (
measure 92
D3     4        e  3  d  [      mf)
F3     4        e n3  d  =
E3     4        e  3  d  ]
G3     4        e n3  d  [
F3     4        e  3  d  =
A3     4        e  3  d  ]
G3     4        e  3  d  [
Bf3    4        e f3  d  =
A3     4        e  3  d  ]
G3     4        e  3  d  [
F3     4        e  3  d  =
E3     4        e  3  d  ]
measure 93
D3    12        q     d
rest  12        q
rest  24        h
measure 94
B2    48        w n   u         Z+
measure 95
E3    48        w     d         mf
measure 96
*               D       cresc.
P    C17:f33
D3    48        w     d
measure 97
C#3   48        w #   u         +
measure 98
F#3   48        w     d         f
measure 99
E#3   48        w #   d         Z
measure 100
F#3   48        w     d
measure 101
E#3   48        w #   d         Z
measure 102
F#3   24        h     d         >
E3    24        h n   d         >+
measure 103
D3    24        h n   d         >+
B2    24        h     u         >
measure 104
C#3   48        w     u
measure 105
D3    24        h     d
rest  24        h
measure 106
A2    24        h     u         p
rest  24        h
measure 107
B2    24        h     u
*               E   0
B2     6        e     u  [      (
B#2    6        e #   u  =      )
B#2    6        e     u  =      .
*               F   18
B#2    6        e     u  ]      .
measure 108
C#3   12        q     u         f
rest  12        q
C#3   12        q     u
rest  12        q
measure 109
rest   6        e
F#3    6        e     d  [      (p
E#3    6        e #   d  =
F#3    6        e     d  ]
E#3    6        e     d  [
F#3    6        e     d  =
B3     6        e     d  =
A3     6        e     d  ]      )
measure 110
D4     6        e     d  [      (
*               E   0
C#4    6        e     d  =
F#4    6        e     d  =
E4     6        e n   d  ]      +
D4     6        e     d  [
C#4    6        e     d  =
*               F   18
B3     6        e     d  =
A3     6        e     d  ]      )
measure 111
G#3   48-       w     d        -mf
measure 112
*               D       cresc.
P    C17:f33
G#3   48        w     d
measure 113
A3    24        h     d         f
 E3   24        h     d
 A2   24        h     d
rest  24        h
measure 114
A2    24        h     u
rest  24        h
measure 115
E2    24        h     u
rest  24        h
measure 116
A2    24        h     u
rest  24        h
measure 117
D2    24        h     u         Z(
D3     6        e     d          )
rest   6        e
rest  12        q
measure 118
C#3   12        q     u
C#3   24        h     u         Z.
D3    12        q     d
measure 119
E3    12        q     d
E3    24        h     d         Z.
E3    12        q     d
measure 120
C#3   12        q     u
A2    12        q     u
E3    12        q     d
rest  12        q
measure 121
D3    24        h     d         Z.
rest  24        h
measure 122
C#3   12        q     u
C#3   24        h     u         Z.
C#3   12        q     u
measure 123
D3    12        q     d
rest  12        q
E3    12        q     d
rest  12        q
measure 124
rest   6        e
A2     6        e     u  [      (p
G#2    6        e     u  =
A2     6        e     u  ]
G#2    6        e     u  [
A2     6        e     u  =
D3     6        e     u  =
C#3    6        e     u  ]      )
measure 125
F#3    6        e     d  [      (
E3     6        e     d  =
A3     6        e     d  =
G#3    6        e     d  ]
F#3    6        e     d  [
E3     6        e     d  =
D3     6        e     d  =
C#3    6        e     d  ]      )
measure 126
B2    48-       w     u        -
measure 127
B2    48        w     u
measure 128
A2    48-       w     u        -
measure 129
A2    48        w     u
measure 130
D3    12        q     d
rest  12        q
rest  24        h
measure 131
rest  24        h
rest   6        e
D#3    6        e #   d  [      (
E3     6        e     d  =
D#3    6        e     d  ]
measure 132
E3     6        e     d  [      ).
F#3    6        e     d  =      (
G#3    6        e     d  =
F#3    6        e     d  ]
*               E   0
G#3    6        e     d  [
F#3    6        e     d  =
E3     6        e     d  =
*               F   18
D3     6        e n   d  ]      )+
measure 133
C#3   12        q     u         f
rest  12        q
rest  24        h
measure 134
G#2   24        h     u
rest  24        h
measure 135
A2    24        h     u
rest  24        h
measure 136
G#2   24        h     u
rest  24        h
measure 137
A2    12        q     u
rest  12        q
B2    12        q     u
rest  12        q
measure 138
C#3   24        h     u
C3    24        h n   u
measure 139
B2    24        h     u
E3    24        h     d
measure 140
A2    24        h     u
rest  12        q
D3    12        q     d
measure 141
B2    12        q     u         (
G#2   12        q     u
E2    12        q     u         )
D2    12        q     u
measure 142
C#2   12        q     u
C#3   12        q     u
C#3   12        q     u
C#3   12        q     u
measure 143
D3    12        q     d
D3    12        q     d
D3    12        q     d
D#3   12        q #   d
measure 144
E3    12        q     d
E3    12        q     d
E2    12        q     u
E2    12        q     u
measure 145
A2    12        q     u
rest  12        q
A2    24        h     u         Z
measure 146
E3    12        q     d         p
C#3   12        q     u
F#3   12        q     d
F#3   12        q     d
measure 147
B2    24        h     u
E3    24        h     d         f
measure 148
A2    12        q     u         Z(
E3     6        e     d         .)
rest   6        e
G#2   12        q     u         Z(
A2     6        e     u         .)
rest   6        e
measure 149
D2    12        q     u         f(
C#2    6        e     u         .)
rest   6        e
rest  12        q
C#3   12        q     u         p
measure 150
rest  12        q
C#3   12        q     u
rest  12        q
D3    12        q     d
measure 151
rest  12        q
D3    12        q     d
rest  24        h
measure 152
E3    12        q     d
E3    12        q     d
E2    12        q     u
E2    12        q     u
measure 153
A2    24        h     u
rest  24        h
measure 154
C#3   24-       h     u        -pp
C#3    6        e     u  [      (
D3     6        e     u  =      )
D3     6        e     u  =      .
D3     6        e     u  ]      .
measure 155
*               D       poco
P   C17:f33
D3    24        h     d
D#3    6        e #   d  [      (
E3     6        e     d  =      )
*               D       a
P   C17:f33
E3     6        e     d  =      .
E3     6        e     d  ]      .
measure 156
*               D       poco
P   C17:f33
E3    24-       h     d        -
E3     6        e     d  [      (
*               DH      cre
P   C17:f33
E#3    6        e #   d  =      )
E#3    6        e     d  =      .
*               J
E#3    6        e     d  ]      .
measure 157
*      6        DH      scen
P   C17:f33
E#3   24-       h #   d        -
E#3    6        e     d  [      (
F#3    6        e     d  =      )
F#3    6        e     d  =      .
*               J
F#3    6        e     d  ]      .
measure 158
*               D       do
P   C17:f33
F#3   24-       h     d        -
F#3    6        e     d  [      (
F3     6        e n   d  =      )
F3     6        e     d  =      .
F3     6        e     d  ]      .
measure 159
E3    12        q     d         f
rest  12        q
rest  24        h
measure 160
rest  48
measure 161
rest  48
measure 162
C#2    6        e     u  [      (>p
D2     6        e     u  =      )
D2     6        e     u  =      .
D2     6        e     u  ]      .
D2     6        e     u  [      (>
D#2    6        e #   u  =      )
D#2    6        e     u  =      .
D#2    6        e     u  ]      .
measure 163
E2    48        w     u
measure 164
A2    12        q     u         f
rest  12        q
rest  24        h
measure 165
rest  48
measure 166
E3    48-       w     d        -
measure 167
E3    48        w     d
measure 168
C#3   24        h     u
D3    24        h     d
measure 169
E3    12        q     d
E3    12        q     d
E3    12        q     d
E3    12        q     d
measure 170
A2    12        q     u
A2    12        q     u
A2    12        q     u
A2    12        q     u
measure 171
A2    12        q     u
A2    12        q     u
A2    12        q     u
A2    12        q     u
measure 172
A2    12        q     u
A2    12        q     u
A2    12        q     u
A2    12        q     u
measure 173
E3    12        q     d
rest  12        q
E2    12        q     u
rest  12        q
measure 174
A2    12        q     u
rest  12        q
rest  24        h
mheavy2
/END
/eof
//
