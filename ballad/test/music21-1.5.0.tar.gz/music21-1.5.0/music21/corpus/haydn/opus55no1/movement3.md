&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/03/01} [KHM:3131509699]
TIMESTAMP: DEC/26/2001 [md5sum:03273994f93e8c7a3a79d2db5dfca59d]
09/16/94 W Hewlett
WK#:55,1      MV#:3
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Menuetto [Third movement]
Violine I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:4   T:3/4  C:4
C#5    3        e.    d  [      tp
P    C34:Y60
D5     1        s     d  ]\
measure 1
*               E   0
P    C17:Y60
E5     4        q     d         .
E5     4        q     d         .
*               F   15
E5     4        q     d         .
measure 2
E5     2        e     d  [     (f
P    C33:Y62
D6     2        e     d  =     )
D6     2        e     d  =     (
B5     2        e     d  =     )
B5     2        e     d  =     (
G#5    2        e     d  ]     )
measure 3
E5     2        e     d  [     (
C#6    2        e     d  =     )
C#6    2        e     d  =     (
B5     2        e     d  =     )
B5     2        e     d  =     (
A5     2        e     d  ]     )
measure 4
*               E   15
P    C17:Y60
A5     2        e     d  [     (
G#5    2        e     d  =
F#5    2        e     d  =     )
E5     2        e     d  =      .
F#5    2        e     d  =      .
*               F   0
G#5    2        e     d  ]      .
measure 5
A5     2        e     d         .p
P    C34:Y57
rest   2        e
A5     2        e     d         .
rest   2        e
A5     2        e     d         .
rest   2        e
measure 6
*               E   0
P    C17:Y60
A#5    2        e #   d         .
rest   2        e
A#5    2        e     d         .
rest   2        e
*               F   15
A#5    2        e     d         .
rest   2        e
measure 7
B5     8        h     d         f
P    C33:Y60
B5     1        s     d  [[    (
A5     1        s n   d  ==     +
G#5    1        s     d  ==
F#5    1        s     d  ]]    )
measure 8
E5     4        q     d         .
rest   4        q
mheavy4                    :||:
G#4    3        e.    u  [      tf
A4     1        s     u  ]\
measure 9
B4     4        q     d         .
B4     4        q     d         .
A4     1        s     u  [[    (
G#4    1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]    )
measure 10
E5     4        q     d         .
E5     4        q     d         .
D5     1        s     d  [[    (
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]    )
measure 11
A5     4        q     d         .
A5     4        q     d         .
G#5    1        s     d  [[    (
F#5    1        s     d  ==
E5     1        s     d  ==
D#5    1        s #   d  ]]    )
measure 12
E5     8        h     d
gF#5   0        e     u        (
E5     3        e.    d  [     )p(
P    C33:Y55
D5     1        s n   d  ]\    )+
measure 13
C#5    4        q     d
C#5    4        q     d
C#5    4        q     d
measure 14
C#5    2        e     d  [     (
D5     2        e     d  =
D#5    2        e #   d  =
E5     2        e     d  =
E#5    2        e #   d  =
F#5    2        e     d  ]     )
measure 15
F#5    2        e     d  [     (
B4     2        e     d  ]     )
B4     4        q     d
B4     4        q     d
measure 16
B4     2        e     d  [     (
C5     2        e n   d  =
C#5    2        e #   d  =
D5     2        e n   d  =      +
D#5    2        e #   d  =
E5     2        e n   d  ]     )+
measure 17
E5     2        e     d  [     (
D5     2        e n   d  =     )+
D5     2        e     d  =     (
C#5    2        e     d  =     )
C#5    2        e     d  =     (
B4     2        e     d  ]     )
measure 18
A4     2        e     u  [     (
G#4    2        e     u  =
F#4    2        e     u  =
E4     2        e     u  ]     )
C#5    3        e.    d  [      t
D5     1        s     d  ]\
measure 19
*               E   0
P    C17:Y60
E5     4        q     d         .
E5     4        q     d         .
*               F   15
E5     4        q     d         .
measure 20
E5     2        e     d  [     (f
P    C33:Y60
D6     2        e     d  =     )
D6     2        e     d  =     (
B5     2        e     d  =     )
B5     2        e     d  =     (
G#5    2        e     d  ]     )
measure 21
E5     2        e     d  [     (
C#6    2        e     d  =     )
C#6    2        e     d  =     (
B5     2        e     d  =     )
B5     2        e     d  =     (
A5     2        e     d  ]     )
measure 22
A5     2        e     d  [     (
G#5    2        e     d  =
F#5    2        e     d  =     )
E5     2        e     d  =     (
F#5    2        e     d  =
G#5    2        e     d  ]     )
measure 23
A5     4        q     d         .
A5     4        q     d         .
A#5    4        q #   d        (Z
P    C33:Y60
measure 24
B5     4        q     d        )
B5     4        q     d         .
B#5    4        q #   d        (Z[
P    C33:Y60
measure 25
C#6    4-       q     d        -)
C#6    3        e.    d  [     ]
E6     1        s     d  =\
D6     3        e.    d  =
B5     1        s n   d  ]\     +
measure 26
A5     4        q     d
rest   4        q
mheavy4                    :||:
$    D:Trio
rest   4        q
measure 27
rest  12
measure 28
A5     2        e     d  [      p.
P    C33:Y55
B5     2        e     d  =      .
C#6    2        e     d  =      .
A5     2        e     d  =      .
E6     2        e     d  =      .
C#6    2        e     d  ]      .
measure 29
D6     2        e     d  [      .
B5     2        e     d  =      .
A5     2        e     d  =      .
G#5    2        e     d  =      .
F#5    2        e     d  =      .
E5     2        e     d  ]      .
measure 30
*               V
A5     2        e     d  [
C#6    2        e     d  =
E6     2        e     d  =
C#6    2        e     d  =
G6     2        e n   d  =
E6     2        e     d  ]
measure 31
F#6    2        e     d  [
D6     2        e     d  =
A5     2        e     d  =
D6     2        e     d  =
G#6    2        e #   d  =      +
E6     2        e     d  ]
measure 32
A6     2        e     d  [
E6     2        e     d  =
A6     2        e     d  =
E6     2        e     d  =
B6     2        e     d  =
E6     2        e     d  ]
measure 33
C#7    2        e     d  [
C#7    2        e     d  =
C#7    2        e     d  =
C#7    2        e     d  =
C#7    2        e     d  =
C#7    2        e     d  ]
measure 34
B6     2        e     d  [
B6     2        e     d  =
B6     2        e     d  =
B6     2        e     d  =
B6     2        e     d  =
B6     2        e     d  ]
measure 35
A6     2        e     d  [      f
P    C33:Y64
G#6    2        e     d  =
A6     2        e     d  =
F#6    2        e     d  =
B6     2        e     d  =
G#6    2        e     d  ]
measure 36
E6     4        q     d
*               W
rest   4        q
mheavy4                    :||:
rest   4        q
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
rest  12
measure 41
rest  12
measure 42
rest  12
measure 43
rest  12
measure 44
A5     2        e     d  [      p.
P    C33:Y56
B5     2        e     d  =      .
C#6    2        e     d  =      .
A5     2        e     d  =      .
E6     2        e     d  =      .
C#6    2        e     d  ]      .
measure 45
D6     2        e     d  [      .
B5     2        e     d  =      .
A5     2        e     d  =      .
G#5    2        e     d  =      .
F#5    2        e     d  =      .
E5     2        e     d  ]      .
measure 46
*               V
A5     2        e     d  [
C#6    2        e     d  =
E6     2        e     d  =
C#6    2        e     d  =
G6     2        e n   d  =
E6     2        e     d  ]
measure 47
F#6    2        e     d  [
D6     2        e     d  =
A5     2        e     d  =
D6     2        e     d  =
G#6    2        e #   d  =      +
E6     2        e     d  ]
measure 48
*               E   0
P    C17:Y60
A6     2        e     d  [
E6     2        e     d  =
A6     2        e     d  =
E6     2        e     d  =
B6     2        e     d  =
*               F   15
E6     2        e     d  ]
measure 49
C#7    4        q     d         f
P    C33:Y60
*               W
rest   4        q
rest   4        q
measure 50
*               D +     sul una corda
P  C25:f33  C25:f31
B3     2        e     u  [     (
C#4    2        e     u  =
D4     2        e     u  =
B3     2        e     u  =
F#4    2        e     u  =
D4     2        e     u  ]     )
measure 51
C#4    2        e     u  [     (
D4     2        e     u  =
E4     2        e     u  =
F#4    2        e     u  =
G#4    2        e     u  =
A4     2        e     u  ]     )
measure 52
E4     2        e     u  [     (
F#4    2        e     u  =
G#4    2        e     u  =
A4     2        e     u  =
B4     2        e     u  =
C#5    2        e     u  ]     )
measure 53
A3     8        h     u        (
C#4    2        e     u  [
B3     2        e     u  ]     )
measure 54
*               C       Menuetto D. C.
P  C25:f33  C17:Y90
A3     4        q     u
rest   4        q
mheavy2                           :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/03/02} [KHM:3131509699]
TIMESTAMP: DEC/26/2001 [md5sum:fcf13a31d013af2db4854007bac32b2e]
09/16/94 W Hewlett
WK#:55,1      MV#:3
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Menuetto [Third movement]
Violine II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:4   T:3/4  C:4
rest   4        q
measure 1
*               E   0
P    C17:x15Y78
C#4    4        q     u         p.
P    C33:Y77
C#4    4        q     u         .
C#5    2        e     d  [     (
*               F   15
A4     2        e     d  ]     )
measure 2
G#4    4        q     u         f.
G#4    4        q     u         .
G#4    4        q     u         .
measure 3
A4     4        q     u        (
F#4    4        q     u        )
F#4    4        q     u         .
measure 4
*               E   15
P    C17:Y78
*     10        F   0
B3    12        h.    u
measure 5
E4     2        e     u         .p
P    C34:Y70
rest   2        e
E4     2        e     u         .
rest   2        e
E4     2        e     u         .
rest   2        e
measure 6
*               E   0
P    C17:Y65
G4     2        e n   u         .
rest   2        e
G4     2        e     u         .
rest   2        e
*               F   15
P    C17:x25
G4     2        e     u         .
rest   2        e
measure 7
G#4    8        h #   u         +f
D#4    4        q #   u         .
measure 8
E4     4        q     u         .
rest   4        q
mheavy4                    :||:
rest   4        q
measure 9
D4     4        q n   u         +f.
P    C34:Y77
D4     4        q     u         .
rest   4        q
measure 10
C#4    4        q     u         ..
C#4    4        q     u         .
rest   4        q
measure 11
D#4    4        q #   u         .
D#4    4        q     u         .
rest   4        q
measure 12
G#4    4        q     u         .
G#4    4        q     u         .
rest   4        q
measure 13
A#4    4        q #   u         p
P    C33:Y57
A#4    4        q     u
A#4    4        q     u
measure 14
B4     4        q     d
rest   4        q
rest   4        q
measure 15
G#4    4        q     u
G#4    4        q     u
G#4    4        q     u
measure 16
A4     4        q n   u         +
rest   4        q
E4     4        q     u
measure 17
F#4   12        h.    u
measure 18
B3     8        h     u
rest   4        q
measure 19
*               E   0
P    C17:Y75
C#4    4        q     u         .
C#4    4        q     u         .
C#5    2        e     d  [     (
*               F   15
A4     2        e     d  ]     )
measure 20
G#4    4        q     u         .f
G#4    4        q     u         .
G#4    4        q     u         .
measure 21
A4     4        q     u        (
F#4    4        q     u        )
F#4    4        q     u         .
measure 22
B3    12        h.    u
measure 23
A3     4        q     u         .
A4     4        q     u         .
G4     4        q n   u        (Z
P    C33:Y72
measure 24
F#4    4        q     u        )
B4     4        q     u
A4     4-       q     u        -Z
P    C33:Y65
measure 25
A4     4-       q     u        -
A4     3        e.    u  [
C#5    1        s     u  =\
B4     3        e.    u  =
G#4    1        s #   u  ]\     +
measure 26
A4     4        q     u
rest   4        q
mheavy4                    :||:
$    D:Trio
*               D       dolce
P  C25:f33  C17:x20
C#4    2        e     u  [     (p
E4     2        e     u  ]     )
measure 27
A4     4        q     u         .
A4     4        q     u         .
E4     2        e     u  [     (
A4     2        e     u  ]     )
measure 28
C#5    4        q     d         .
C#5    4        q     d         .
C#5    4        q     d         .
measure 29
B4     6        q.    d         t
A4     2        e     u
B4     4        q     d
measure 30
A4     4        q     u
rest   4        q
A4     4        q     u
measure 31
A4     8        h     u
C#5    1        s     d  [[    (
B4     1        s     d  ==
A4     1        s     d  ==
B4     1        s     d  ]]    )
measure 32
C#5    4        q     d
rest   4        q
rest   4        q
measure 33
E5     4        q     d        (
E#5    4        q #   d        )
F#5    4-       q     d        -
measure 34
F#5    4        q     d
D#5    4        q #   d         .
E5     4        q n   d         .+
measure 35
A5     2        e     d  [      f.
P    C33:Y62
G#5    2        e     d  =      .
A5     2        e     d  =      .
F#5    2        e     d  =      .
B5     2        e     d  =      .
G#5    2        e     d  ]      .
measure 36
E5     4        q     d
rest   4        q
mheavy4                    :||:
E5     2        e     d  [      mf.
D#5    2        e #   d  ]      .
measure 37
E5     2        e     d  [      .
C#5    2        e     d  =      .
D5     2        e n   d  =      .+
B4     2        e     d  =      .
C#5    2        e     d  =      .
A#4    2        e #   d  ]      .
measure 38
B4     2        e     d  [      .
D5     2        e     d  =      .
F#5    2        e     d  =      .
B5     2        e     d  =      .
D5     2        e     d  =      .
C#5    2        e     d  ]      .
measure 39
D5     2        e     d  [      .
B4     2        e     d  =      .
C#5    2        e     d  =      .
A4     2        e n   d  =      .+
B4     2        e     d  =      .
G#4    2        e     d  ]      .
measure 40
A4     2        e     d  [      .
C#5    2        e     d  =      .
E5     2        e     d  =      .
A5     2        e     d  =      .
E5     2        e     d  =      .
C#5    2        e     d  ]      .
measure 41
B4     2        e     u  [      .
A#4    2        e #   u  =      .
B4     2        e     u  =      .
D5     2        e     u  =      .
F#4    2        e     u  =      .
B4     2        e     u  ]      .
measure 42
*               E   15
P    C17:Y70
A4     2        e n   u  [      +(
G#4    2        e     u  =
F#4    2        e     u  =
*               F   0
E4     2        e     u  =       )
F#4    2        e     u  =      .
G#4    2        e     u  ]      .
measure 43
A4     4        q     u
A4     4        q     u
E4     2        e     u  [     (
A4     2        e     u  ]     )
measure 44
C#5    4        q     d         .
C#5    4        q     d         .
C#5    4        q     d         .
measure 45
B4     6        q.    d         t
A4     2        e     u
B4     4        q     d
measure 46
A4     4        q     u
rest   4        q
A4     4        q     u
measure 47
A4     8        h     u
C#5    1        s     d  [[    (
B4     1        s     d  ==
A4     1        s     d  ==
B4     1        s     d  ]]    )
measure 48
C#5    4        q     d
rest   4        q
D5     2        e     d  [     (
B4     2        e     d  ]     )
measure 49
C#5    4        q     d         f
P    C33:Y67
rest   4        q
rest   4        q
measure 50
rest  12
measure 51
C#4    8        h     u         p
P    C33:Y72
rest   4        q
measure 52
rest  12
measure 53
A3     6        q.    u
A3     2        e     u        (
G#3    4        q     u        )
measure 54
*               C       Menuetto D.C.
P  C25:f33  C17:Y85
A3     4        q     u
rest   4        q
mheavy2                         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/03/03} [KHM:3131509699]
TIMESTAMP: DEC/26/2001 [md5sum:4702b6cbe351279c0a23b7ec1d7e2fdf]
09/16/94 W Hewlett
WK#:55,1      MV#:3
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Menuetto [Third movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:3/4  C:13
rest   2        q
measure 1
*               E   0
P    C17:x15Y70
E4     2        q     d         .p
E4     2        q     d         .
*               F   15
E4     2        q     d         .
measure 2
E4     2        q     d         f.
P    C33:Y63
E4     2        q     d         .
E4     2        q     d         .
measure 3
E4     2        q     d         .
F#4    2        q     d         .
D#4    2        q #   d         .
measure 4
*               E   15
P    C17:Y60
*      5        F   0
E4     6        h.    d
measure 5
A3     1        e     u         p.
P    C33:Y65
rest   1        e
A4     1        e     d         .
rest   1        e
A4     1        e     d         .
rest   1        e
measure 6
*               E   0
P    C17:Y65
E4     1        e     d         .
rest   1        e
E4     1        e     d         .
rest   1        e
*               F   15
E4     1        e     d         .
rest   1        e
measure 7
E4     4        h     d         f
A3     2        q     u         .
measure 8
G#3    2        q     u         .
rest   2        q
mheavy4                    :||:
rest   2        q
measure 9
G#3    2        q     u         .
G#3    2        q     u         .
rest   2        q
measure 10
A3     2        q     u         .
A3     2        q     u         .
rest   2        q
measure 11
F#4    2        q     d         .
F#4    2        q     d         .
rest   2        q
measure 12
B3     2        q     u         .
B3     2        q     u         .
rest   2        q
measure 13
G4     2        q n   d         p
P    C33:Y55
G4     2        q     d
G4     2        q     d
measure 14
F#4    2        q     d
rest   2        q
rest   2        q
measure 15
E4     2        q     d
E4     2        q     d
E4     2        q     d
measure 16
E4     2        q     d
rest   2        q
A3     2-       q     u        -
measure 17
A3     2        q     u
F#3    2        q     u
D#3    2        q #   u
measure 18
E3     4        h     u
rest   2        q
measure 19
*               E   0
P    C17:Y65
E4     2        q     d         .
E4     2        q     d         .
*               F   15
E4     2        q     d         .
measure 20
E4     2        q     d         f.
P    C33:Y60
E4     2        q     d         .
E4     2        q     d         .
measure 21
E4     2        q     d         .
F#4    2        q     d         .
D#4    2        q #   d         .
measure 22
E4     6        h.    d
measure 23
E4     4        h     d
E4     2        q     d        (Z
measure 24
F#4    4        h     d        )
F#4    2        q     d        (Z
measure 25
E4     2        q     d        )
E3     2        q     u         .
D4     2        q     d         .
measure 26
C#4    2        q     d         .
rest   2        q
mheavy4                    :||:
$    D:Trio
rest   2        q
measure 27
E4     2        q     d         p.
P    C33:Y65
 C#4   2        q     d
rest   2        q
rest   2        q
measure 28
E4     2        q     d         .
 C#4   2        q     d
A4     2        q     d         .
A4     2        q     d         .
measure 29
G#4    6        h.    d
measure 30
A4     1        e     d  [      .
E4     1        e     d  =      .
C#4    1        e     d  =      .
A3     1        e     d  =      .
E4     1        e     d  =      .
C#4    1        e     d  ]      .
measure 31
D4     2        q     d
rest   2        q
rest   2        q
measure 32
E4     1        e     d  [      .
C#4    1        e     d  =      .
A3     1        e     d  =      .
C#4    1        e     d  =      .
B3     1        e     d  =      .
D4     1        e     d  ]      .
measure 33
C#4    2        q     d
rest   2        q
rest   2        q
measure 34
rest   6
measure 35
A4     1        e     d  [      f.
P    C33:Y60
G#4    1        e     d  =      .
A4     1        e     d  =      .
F#4    1        e     d  =      .
B4     1        e     d  =      .
G#4    1        e     d  ]      .
measure 36
E4     2        q     d
rest   2        q
mheavy4                    :||:
G4     1        e n   d  [      mf.
P    C33:Y60
F#4    1        e     d  ]      .
measure 37
G4     1        e n   d  [      .
E4     1        e     d  =      .
F#4    1        e     d  =      .
D4     1        e     d  =      .
E4     1        e     d  =      .
C#4    1        e     d  ]      .
measure 38
D4     2        q     d
rest   2        q
F#3    1        e     u  [      .
E3     1        e     u  ]      .
measure 39
F#3    1        e     u  [      .
D4     1        e     u  =      .
E3     1        e     u  =      .
C#4    1        e     u  =      .
D3     1        e     u  =      .
B3     1        e     u  ]      .
measure 40
C#3    2        q     u
rest   2        q
E4     2        q     d
measure 41
F#4    6        h.    d
measure 42
B3     2        q     u
rest   2        q
rest   2        q
measure 43
E4     2        q     d         p.
 C#4   2        q     d
rest   2        q
rest   2        q
measure 44
E4     2        q     d         .
 C#4   2        q     d
A4     2        q     d         .
A4     2        q     d         .
measure 45
G#4    6        h.    d
measure 46
A4     1        e     d  [      .
E4     1        e     d  =      .
C#4    1        e     d  =      .
A3     1        e     d  =      .
E4     1        e     d  =      .
C#4    1        e     d  ]      .
measure 47
D4     2        q     d
rest   2        q
rest   2        q
measure 48
E4     1        e     d  [      .
*               E   0
P    C17:Y72
C#4    1        e     d  =      .
A3     1        e     d  =      .
C#4    1        e     d  =      .
B3     1        e     d  =      .
*               F   15
D4     1        e     d  ]      .
measure 49
C#4    2        q     d         f
rest   2        q
rest   2        q
measure 50
F#3    4        h     u         p
rest   2        q
measure 51
A3     4        h     u
rest   2        q
measure 52
rest   6
measure 53
C#3    4        h     u        (
E3     1        e     u  [
D3     1        e     u  ]     )
measure 54
*               C       Menuetto D.C.
P  C25:f33
C#3    2        q     u
rest   2        q
mheavy2                           :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/03/04} [KHM:3131509699]
TIMESTAMP: DEC/26/2001 [md5sum:286f0f3ce6df37ce455c8678d85c4bb0]
09/16/94 W Hewlett
WK#:55,1      MV#:3
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Menuetto [Third movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:3/4  C:22
rest   2        q
measure 1
*               E   0
P    C17:x15Y65
A2     2        q     u         .p
P    C34:Y67
A2     2        q     u         .
*               F   15
P    C17:x15
A2     2        q     u         .
measure 2
B2     2        q     u         .f
B2     2        q     u         .
B2     2        q     u         .
measure 3
C#3    2        q     u         .
D3     2        q     d         .
D#3    2        q #   d         .
measure 4
*               E   15
P    C17:Y70
E3     4        h     d        (
*               F   0
D3     2        q n   d        )+
measure 5
C#3    1        e     u         p.
P    C33:Y55
rest   1        e
C#3    1        e     u         .
rest   1        e
C#3    1        e     u         .
rest   1        e
measure 6
*               E   0
P    C17:Y60
C3     1        e n   u         .
rest   1        e
C3     1        e     u         .
rest   1        e
*               F   15
P    C17:x15
C3     1        e     u         .
rest   1        e
measure 7
B2     6        h.    u         f
measure 8
E3     2        q     d
E2     2        q     u
mheavy4                    :||:
rest   2        q
measure 9
E3     2        q     d         f.
P    C33:Y65
E3     2        q     d         .
rest   2        q
measure 10
E3     2        q     d         .
E3     2        q     d         .
rest   2        q
measure 11
E3     2        q     d         .
E3     2        q     d         .
rest   2        q
measure 12
E3     2        q     d         .
E3     2        q     d         .
rest   2        q
measure 13
E4     2        q     d         p
P    C33:Y55
E4     2        q     d
E4     2        q     d
measure 14
D4     4        h     d
rest   2        q
measure 15
D4     2        q     d
D4     2        q     d
D4     2        q     d
measure 16
C#4    4        h     d
C#3    2        q     u
measure 17
D3     4        h     d
D#3    2        q #   d
measure 18
E3     4        h     d
rest   2        q
measure 19
*               E   0
P    C17:Y65
A2     2        q     u         .
A2     2        q     u         .
*               F   15
P    C17:x15
A2     2        q     u         .
measure 20
B2     2        q     u         f.
P    C33:Y65
B2     2        q     u         .
B2     2        q     u         .
measure 21
C#3    2        q     u         .
D3     2        q n   d         +.
D#3    2        q #   d         .
measure 22
E3     4        h     d        (
D3     2        q n   d        )+
measure 23
C#3    4        h     u
C#3    2        q     u        (Z
measure 24
D3     4        h     d        )
D#3    2        q #   d        (Z
measure 25
E3     4        h     d        )
E2     2        q     u         .
measure 26
A2     2        q     u         .
rest   2        q
mheavy4                    :||:
$    D:Trio
rest   2        q
measure 27
A2     1        e     d  [      p.
P    C33:Y82
C#3    1        e     d  =      .
E3     1        e     d  =      .
A3     1        e     d  =      .
E3     1        e     d  =      .
C#3    1        e     d  ]      .
measure 28
A2     2        q     u         .
rest   2        q
rest   2        q
measure 29
E3     6        h.    d
measure 30
A3     4        h     d
C#4    2        q     d
measure 31
D4     3        q.    d
C#4    1        e     d
D4     2        q     d
measure 32
C#4    2        q     d
rest   2        q
G#3    2        q     d
measure 33
A3     6        h.    d
measure 34
G#3    6        h.    d
measure 35
A3     1        e     d  [      f.
P    C33:Y62
G#3    1        e     d  =      .
A3     1        e     d  =      .
F#3    1        e     d  =      .
B3     1        e     d  =      .
G#3    1        e     d  ]      .
measure 36
E3     2        q     d         .
E2     2        q     u
mheavy4                    :||:
rest   2        q
measure 37
rest   2        q
rest   2        q
F#3    2        q     d         mf
measure 38
B2     2        q     u
rest   2        q
rest   2        q
measure 39
rest   2        q
rest   2        q
E2     2        q     u
measure 40
A2     4        h     u
C#3    2        q     u
measure 41
D3     4        h     d
D#3    2        q #   d
measure 42
E3     2        q     d
rest   2        q
rest   2        q
measure 43
A2     1        e     d  [      .
C#3    1        e     d  =      .
E3     1        e     d  =      .
A3     1        e     d  =      .
E3     1        e     d  =      .
C#3    1        e     d  ]      .
measure 44
A2     2        q     u
rest   2        q
rest   2        q
measure 45
E3     6        h.    d
measure 46
A3     4        h     d
C#4    2        q     d
measure 47
D4     3        q.    d
C#4    1        e     d
D4     2        q     d
measure 48
*               E   0
P    C17:Y60
C#4    4        h     d
*               F   15
G#3    2        q     d
measure 49
A3     2        q     d         f
P    C33:Y60
rest   2        q
rest   2        q
measure 50
D2     6        h.    u        (p
P    C33:Y82
measure 51
E2     4        h     u        )
rest   2        q
measure 52
rest   6
measure 53
E2     6        h.    u
measure 54
*               C       Menuetto D.C.
P  C25:f33  C17:Y65
A2     2        q     u
rest   2        q
mheavy2                         :|
/END
/eof
//
