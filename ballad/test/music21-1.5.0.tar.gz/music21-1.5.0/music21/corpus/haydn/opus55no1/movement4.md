&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/04/01} [KHM:2565125522]
TIMESTAMP: DEC/26/2001 [md5sum:b05c602d0c42331aad7158a574718baa]
09/16/94 W Hewlett
WK#:55,1      MV#:4
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Finale [Fourth Movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:0/0  C:4  D:Vivace
B5     1        e     d  [     (p
P    C33:Y58
A5     1        e     d  ]     )
measure 1
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 2
C#5    2        q     d         .
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 3
E5     2        q     d        (f
P    C33:Y63
D#5    2        q #   d
D5     2        q n   d
C#5    2        q     d        )
measure 4
gC#5   0        e     u        (
B4     1        e     d  [     )(
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]     )
B4     2        q     d
B5     1        e     d  [     (p
P    C33:Y57
A5     1        e     d  ]     )
measure 5
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 6
*               E   0
P    C17:Y70
C#5    2        q     d
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 7
E5     2        q     d        (f
P    C33:Y62
D5     2        q     d        )
F#5    1        e     d  [     (
G#5    1        e #   d  =     )+
G#5    1        e     d  =     (
A5     1        e     d  ]     )
measure 8
A4     6        h.    u        (
C#5    1        e     d  [
B4     1        e     d  ]     )
measure 9
A4     2        q     u
rest   2        q
rest   2        q
mheavy4                  :|:
G#4    1        e     u  [     (mf
P    C33:Y65
A4     1        e     u  ]     )
measure 10
B4     1        e     d  [     (
A4     1        e     d  =     )
C#5    1        e     d  =     (
B4     1        e     d  ]     )
D5     2        q     d         .
C#5    2        q     d         .
measure 11
B4     2        q     d         .
E5     2        q     d         .
E5     2        q     d         .
E5     2        q     d         .
measure 12
D#5    1        e #   d  [     (
E5     1        e     d  =
F#5    1        e     d  =
G#5    1        e     d  ]     )
A5     2        q     d         .
A5     2        q     d         .
measure 13
A5     1        e     d  [     (
G#5    1        e     d  =
B5     1        e     d  =
G#5    1        e     d  ]     )
E5     2        q     d         .
G#5    1        e     d  [     (
A5     1        e     d  ]     )
measure 14
B5     1        e     d  [     (
A5     1        e     d  =     )
C#6    1        e     d  =     (
B5     1        e     d  ]     )
D6     2        q     d         .
D6     2        q     d         .
measure 15
C#6    6        h.    d
A5     1        e     d  [     (
F#5    1        e     d  ]     )
measure 16
E5     2        q     d         .
E5     2        q     d         .
E5     2        q     d         .
G#5    1        e     d  [     (
F#5    1        e     d  ]     )
measure 17
E5     6        h.    d
G5     1        e n   d  [     (
F#5    1        e     d  ]     )
measure 18
*               D       dim.
P  C25:f33  C17:Y65
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
C#5    2        q     d         .
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 19
D5     1        e     d  [     (
E5     1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
B4     2        q     d         .
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 20
D5     1        e     d  [     (
E5     1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
B4     2        q     d         .
rest   2        q
measure 21
rest   4        h
rest   2        q
B5     1        e     d  [     (p
P    C33:Y58
A5     1        e     d  ]     )
measure 22
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 23
C#5    2        q     d         .
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 24
E5     2        q     d        (f
P    C33:Y62
D#5    2        q #   d
D5     2        q n   d
C#5    2        q     d        )
measure 25
gC#5   0        e     u        (
B4     1        e     d  [     )(
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]     )
B4     2        q     d         .
B5     1        e     d  [     (p
P    C33:Y57
A5     1        e     d  ]     )
measure 26
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 27
*               E   0
P    C17:Y72
C#5    2        q     d
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 28
E5     2        q     d        (f
P    C33:Y63
D5     2        q     d        )
F#5    1        e     d  [     (
G#5    1        e     d  =     )
G#5    1        e     d  =     (
A5     1        e     d  ]     )
measure 29
*               E   15
P    C17:Y67
A4     6        h.    u        (
C#5    1        e     d  [
*               F   0
B4     1        e     d  ]     )
measure 30a                    start-end1
A4     2        q     u
rest   2        q
rest   2        q
mheavy2 30b                    :|   stop-end1 start-end2
A4     2        q     u
rest   2        q
rest   2        q
G#3    1        e     u  [     (f
A3     1        e     u  ]     )
measure 31                     disc-end2
B3     1        e     u  [     (
C#4    1        e     u  =     )
D4     1        e     u  =      .
E4     1        e     u  ]      .
F#4    1        e     u  [     (
G#4    1        e     u  =     )
A4     1        e     u  =      .
B4     1        e     u  ]      .
measure 32
C#5    2        q     d         .
D5     2        q     d         .
E5     2        q     d         .
B3     1        e     u  [     (
C#4    1        e     u  ]     )
measure 33
D4     1        e     u  [     (
E4     1        e     u  =     )
F#4    1        e     u  =      .
G#4    1        e     u  ]      .
A4     1        e     d  [     (
B4     1        e     d  =     )
C#5    1        e     d  =      .
D5     1        e     d  ]      .
measure 34
E5     2        q     d         .
G#5    2        q     d         .
A5     2        q     d         .
C#6    2        q     d         .
measure 35
C#6    2        q     d         .
C#6    2        q     d         .
C#6    2        q     d         .
C#6    2        q     d         .
measure 36
C#6    1        e     d  [     (
D6     1        e     d  =
C#6    1        e     d  =
B5     1        e     d  ]     )
A5     2        q     d
F#5    1        e     d  [     (
G#5    1        e     d  ]     )
measure 37
A5     1        e     d  [     (
B5     1        e     d  ]     )
C#6    2        q     d         .
C#6    2        q     d         .
C#6    2        q     d         .
measure 38
B5     1        e     d  [     (
C#6    1        e     d  =
B5     1        e     d  =
A5     1        e     d  ]     )
G#5    2        q     d         .
B5     1        e     d  [     (
A5     1        e     d  ]     )
measure 39
G#5    1        e     d  [     (
F#5    1        e     d  =     )
E5     1        e     d  =      .
D#5    1        e #   d  ]      .
C#5    1        e     u  [     (
B4     1        e     u  =     )
A4     1        e     u  =      .
G#4    1        e     u  ]      .
measure 40
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
measure 41
B4     2        q     d        (Z
A#4    2        q #   u
A4     2        q n   u
G#4    2        q     u        )
measure 42
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
measure 43
B4     2        q     d        (Z
A#4    2        q #   u
A4     2        q n   u
G#4    2        q     u        )
measure 44
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
F#4    1        e     u  [     (
G#4    1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  ]     )
measure 45
F#4    1        e     u  [     (ff
P    C33:Y70
G4     1        e n   u  =
F#4    1        e     u  =
G4     1        e     u  ]     )
G4     2        q     u        (
F#4    1        e     u  [
E4     1        e     u  ]     )
measure 46
D#4    2        q #   u
gA#4   0        e     u        (
P    C32:o
B4     2        q     d        ).
B3     2        q     u
A5     1        e n   d  [     (+
G#5    1        e #   d  ]     )+
measure 47
F#5    1        e     d  [     (
E5     1        e     d  =     )
D#5    1        e #   d  =      .
C#5    1        e     d  ]      .
B4     1        e     u  [     (
A4     1        e     u  =     )
G#4    1        e     u  =      .
F#4    1        e     u  ]      .
measure 48
E4     2        q     u
rest   2        q
rest   2        q
A5     1        e     d  [     (
G#5    1        e     d  ]     )
measure 49
F#5    1        e     d  [     (
E5     1        e     d  =     )
D#5    1        e #   d  =      .
C#5    1        e     d  ]      .
B4     1        e     u  [     (
A4     1        e     u  =     )
G#4    1        e     u  =      .
F#4    1        e     u  ]      .
measure 50
E4     2        q     u
rest   2        q
rest   2        q
A5     1        e     d  [     (
G#5    1        e     d  ]     )
measure 51
F#5    1        e     d  [     (
E5     1        e     d  =
D#5    1        e #   d  =
C#5    1        e     d  ]     )
B4     2        q     d         .
C#6    1        e     d  [     (
B5     1        e     d  ]     )
measure 52
A5     1        e     d  [     (
G#5    1        e     d  =
F#5    1        e     d  =
E5     1        e     d  ]     )
D#5    2        q #   d
E6     1        e     d  [     (
D#6    1        e #   d  ]     )
measure 53
E6     1        e     d  [     (
D#6    1        e #   d  =
E6     1        e     d  =
D#6    1        e     d  ]     )
E6     1        e     d  [     (
D#6    1        e     d  =
C#6    1        e     d  =
B#5    1        e #   d  ]     )
measure 54
C#6    1        e     d  [     (
B#5    1        e #   d  =
C#6    1        e     d  =
B#5    1        e     d  ]     )
C#6    1        e     d  [     (
A5     1        e     d  =
G#5    1        e     d  =
F#5    1        e     d  ]     )
measure 55
E5     4        h     d
G#5    1        e     d  [     (
F#5    1        e     d  =
E5     1        e     d  =
F#5    1        e     d  ]     )
measure 56
E5     6        h.    d         mf
P    C33:Y60
G5     1        e n   d  [     (
F#5    1        e     d  ]     )
measure 57
*               D       dim.
P  C25:f33  C17:Y65
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e n   d  =     (+
E5     1        e     d  ]     )
C#5    2        q     d         .
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 58
D5     1        e     d  [     (
E5     1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
B4     2        q     d         .
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 59
D5     1        e     d  [     (
E5     1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
B4     2        q     d         .
rest   2        q
measure 60
rest   4        h
rest   2        q
B5     1        e     d  [     (p
P    C33:Y55
A5     1        e     d  ]     )
measure 61
*               E   0
P    C17:Y65
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
*               F   15
E5     1        e     d  ]     )
measure 62
C#5    1        e     d  [      .mf
P    C34:Y65
D5     1        e     d  =      .
E5     1        e     d  =      .
C#5    1        e     d  ]      .
A4     1        e     d  [      .
B4     1        e     d  =      .
C#5    1        e     d  =      .
A4     1        e     d  ]      .
measure 63
F#4    1        e     u  [      .
G#4    1        e     u  =      .
A4     1        e     u  =      .
F#4    1        e     u  ]      .
B4     1        e     d  [      .
C#5    1        e     d  =      .
B4     1        e     d  =      .
A4     1        e     d  ]      .
measure 64
G#4    1        e     u  [      .
A4     1        e     u  =      .
B4     1        e     u  =      .
A4     1        e     u  ]      .
G#4    1        e     u  [      .
E4     1        e     u  =      .
F#4    1        e     u  =      .
G#4    1        e     u  ]      .
measure 65
A4     4        h     u
rest   4        h
measure 66
rest   8
measure 67
rest   8
measure 68
E5     8        w     d         mf
P    C33:Y60
measure 69
A5     4        h     d
C#6    4        h     d
measure 70
D#5    8        w #   d
measure 71
E5     6        h.    d
F#5    1        e     d  [     (
G#5    1        e     d  ]     )
measure 72
A5     4        h     d
rest   4        h
measure 73
rest   2        q
A4     2        q     u
A4     2        q     u
A4     2        q     u
measure 74
D5     4        h     d
B4     2        q     d
E5     2-       q     d        -
measure 75
E5     1        e     d  [
F#5    1        e     d  =      .
E5     1        e     d  =      .
D5     1        e     d  ]      .
C#5    2        q     d
rest   2        q
measure 76
rest   8
measure 77
rest   8
measure 78
D5     8        w     d         mf
P    C33:Y60
measure 79
G5     4        h n   d
B5     4        h     d
measure 80
C#5    8        w     d
measure 81
D5     1        e     d  [      .
B4     1        e     d  =      .
D5     1        e     d  =      .
E5     1        e     d  ]      .
F#5    1        e     d  [      .
D5     1        e     d  =      .
E5     1        e     d  =      .
F#5    1        e     d  ]      .
measure 82
G5     1        e n   d  [
E5     1        e     d  =
F#5    1        e     d  =
G5     1        e     d  ]
A5     1        e     d  [
B5     1        e     d  =
A5     1        e     d  =
G5     1        e     d  ]
measure 83
F#5    1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
F#5    1        e     d  ]
G5     1        e n   d  [
A5     1        e     d  =
G5     1        e     d  =
F#5    1        e     d  ]
measure 84
E5     1        e     d  [
C#5    1        e     d  =
D5     1        e     d  =
E5     1        e     d  ]
F#5    1        e     d  [
G5     1        e n   d  =
F#5    1        e     d  =
E5     1        e     d  ]
measure 85
D5     1        e     d  [
E5     1        e     d  =
C#5    1        e     d  =
D5     1        e     d  ]
B4     1        e     u  [
C#5    1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
measure 86
G#4    1        e #   u  [      +
A4     1        e     u  =
B4     1        e     u  =
G#4    1        e     u  ]
C#5    1        e     d  [
D5     1        e     d  =
C#5    1        e     d  =
B4     1        e     d  ]
measure 87
A4     4        h     u
rest   4        h
measure 88
rest   4        h
rest   2        q
B5     1        e     d  [     (
A5     1        e     d  ]     )
measure 89
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 90
C#5    1        e     d  [      .
D5     1        e     d  =      .
E5     1        e     d  =      .
C#5    1        e     d  ]      .
A4     1        e     d  [      .
B4     1        e     d  =      .
C#5    1        e     d  =      .
A4     1        e     d  ]      .
measure 91
F#4    1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
F#4    1        e     u  ]
D5     1        e     d  [
E5     1        e     d  =
F#5    1        e     d  =
D5     1        e     d  ]
measure 92
B4     1        e     d  [
C#5    1        e     d  =
D5     1        e     d  =
B4     1        e     d  ]
E5     1        e     d  [
F#5    1        e     d  =
E5     1        e     d  =
D5     1        e     d  ]
measure 93
C#5    1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
C#5    1        e     d  ]
A4     1        e     d  [
B4     1        e     d  =
C#5    1        e     d  =
A4     1        e     d  ]
measure 94
F#4    1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
F#4    1        e     u  ]
D5     1        e     d  [
C#5    1        e     d  =
B4     1        e     d  =
A4     1        e     d  ]
measure 95
G#4    1        e     u  [
A4     1        e     u  =
B4     1        e     u  =
G#4    1        e     u  ]
E5     1        e     d  [
D5     1        e     d  =
C#5    1        e     d  =
B4     1        e     d  ]
measure 96
A4     1        e     d  [
B4     1        e     d  =
C#5    1        e     d  =
A4     1        e     d  ]
F#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
C#5    1        e     d  ]
measure 97
B4     1        e     d  [
C#5    1        e     d  =
D5     1        e     d  =
B4     1        e     d  ]
E5     1        e     d  [
F#5    1        e     d  =
E5     1        e     d  =
D5     1        e     d  ]
measure 98
C#5    1        e     d  [
D5     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]
A4     1        e     d  [
F#5    1        e     d  =
E5     1        e     d  =
D5     1        e     d  ]
measure 99
C#5    1        e     d  [
D5     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]
A4     1        e     d  [
A5     1        e     d  =
C#6    1        e     d  =
B5     1        e     d  ]
measure 100
*               E   15
P    C17:Y60
A5     1        e     d  [
B5     1        e     d  =
A5     1        e     d  =
G#5    1        e     d  ]
F#5    1        e     d  [
G#5    1        e     d  =
F#5    1        e     d  =
*               F   0
E5     1        e     d  ]
measure 101
D#5    2        q #   d         .p
P    C34:Y60
D#5    2        q     d         .
D#5    2        q     d         .
A5     2        q     d        (
measure 102
D#5    2        q #   d        ).
D#5    2        q     d         .
D#5    2        q     d         .
F#6    2        q     d        (
measure 103
D#5    2        q #   d        ).
D#5    2        q     d         .
D#5    2        q     d         .
A5     2        q     d        (
measure 104
D#5    2        q #   d        )
D#5    2        q     d         .
D#5    2        q     d         .
F#6    2        q     d        (
measure 105
*               D       dim.
P  C25:f33  C17:Y65
D#5    2        q #   d        )
F#6    2        q     d        (
D#5    2        q     d        ).
F#6    2        q     d        (
measure 106
D#5    2        q #   d        )
rest   2        q
rest   4        h
measure 107
rest   4        h
rest   2        q
B5     1        e     d  [     (p
P    C33:Y57
A5     1        e     d  ]     )
measure 108
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e n   d  =     (+
E5     1        e     d  ]     )
measure 109
C#5    2        q     d         .
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 110
E5     2        q     d        (f
P    C33:Y60
D#5    2        q #   d
D5     2        q n   d
C#5    2        q     d        )
measure 111
gC#5   0        e     u        (
B4     1        e     d  [     )(
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]     )
B4     2        q     d         .
B5     1        e     d  [     (p
P    C33:Y57
A5     1        e     d  ]     )
measure 112
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 113
C#5    2        q     d         .
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 114
E5     2        q     d        (f
P    C33:Y60
D5     2        q     d        )
F#5    1        e     d  [     (
G#5    1        e     d  =     )
G#5    1        e     d  =     (
A5     1        e     d  ]     )
measure 115
*               E   15
P    C17:Y70
A4     6        h.    u        (
C#5    1        e     d  [
*               F   0
B4     1        e     d  ]     )
measure 116
A4     2        q     u
rest   2        q
B4     1        e     d  [     (p
P    C33:Y69
C#5    1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
measure 117
C#5    2        q     d
rest   2        q
D5     1        e     d  [     (
E5     1        e     d  =     )
E5     1        e     d  =     (
F#5    1        e     d  ]     )
measure 118
E5     2        q     d
rest   2        q
A5     1        e     d  [     (
G#5    1        e     d  =     )
A5     1        e     d  =     (
E#5    1        e #   d  ]     )
measure 119
F#5    2        q     d
rest   2        q
D5     1        e     d  [     (
C#5    1        e     d  =     )
D5     1        e     d  =     (
A#4    1        e #   d  ]     )
measure 120
B4     2        q     d
rest   2        q
D5     1        e     d  [     (
C#5    1        e     d  =     )
D5     1        e     d  =     (
B4     1        e     d  ]     )
measure 121
*               E   0
P    C17:Y60
F#5    1        e     d  [     (
G#5    1        e     d  =
A5     1        e n   d  =      +
G#5    1        e     d  ]     )
A5     1        e     d  [     (
G#5    1        e     d  =
A5     1        e     d  =
*               F   15
G#5    1        e     d  ]     )
measure 122
A5     1        e     d  [     (f
P    C33:Y60
G#5    1        e     d  =
A5     1        e     d  =
G#5    1        e     d  ]     )
A5     1        e     d  [     (
G#5    1        e     d  =
A5     1        e     d  =
G#5    1        e     d  ]     )
measure 123
A5     2        q     d         .
E5     2        q     d         .
C#6    2        q     d
A5     2        q     d
measure 124
E6     2        q     d
rest   2        q
rest   4        h
measure 125
rest   4        h
rest   2        q
F#4    1        e     u  [     (p
E4     1        e     u  ]     )
measure 126
D4     1        e     u  [     (
E4     1        e     u  =
D4     1        e     u  =
C#4    1        e     u  ]     )
B3     2        q     u
rest   2        q
measure 127
rest   4        h
rest   2        q
F#5    1        e     d  [     (f
P    C33:Y60
E5     1        e     d  ]     )
measure 128
D5     1        e     d  [     (
E5     1        e     d  =
D5     1        e     d  =
C#5    1        e     d  ]     )
B4     2        q     d
B5     1        e     d  [     (p
P    C33:Y55
A5     1        e     d  ]     )
measure 129
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 130
C#5    2        q     d
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 131
E5     2        q     d        (f
P    C33:Y60
D#5    2        q #   d
D5     2        q n   d
C#5    2        q     d        )
measure 132
gC#5   0        e     u        (
B4     1        e     d  [     )(
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  ]     )
B4     2        q     d         .
B5     1        e     d  [     (p
P    C33:Y55
A5     1        e     d  ]     )
measure 133
G#5    1        e     d  [     (
A5     1        e     d  =     )
F#5    1        e     d  =     (
G#5    1        e     d  ]     )
E5     1        e     d  [     (
F#5    1        e     d  =     )
D5     1        e     d  =     (
E5     1        e     d  ]     )
measure 134
C#5    2        q     d
*               E   0
P    C17:Y70
C#5    2        q     d        (.
C#5    2        q     d         .
*               F   15
C#5    2        q     d        ).
measure 135
E5     2        q     d        (f
P    C33:Y60
D5     2        q     d        )
F#5    1        e     d  [     (
G#5    1        e     d  =     )
G#5    1        e     d  =     (
A5     1        e     d  ]     )
measure 136
*               E   15
P    C17:Y70
A4     6        h.    u        (
*               F   0
C#5    1        e     d  [
B4     1        e     d  ]     )
measure 137
A4     2        q     u
rest   2        q
rest   2        q
G#3    1        e     u  [     (f
A3     1        e     u  ]     )
measure 138
B3     1        e     u  [     (
C#4    1        e     u  =     )
D4     1        e     u  =      .
E4     1        e     u  ]      .
F#4    1        e     u  [     (
G#4    1        e     u  =     )
A4     1        e     u  =      .
B4     1        e     u  ]      .
measure 139
C#5    2        q     d         .
D5     2        q     d         .
E5     2        q     d         .
B3     1        e     u  [     (
C#4    1        e     u  ]     )
measure 140
D4     1        e     u  [     (
E4     1        e     u  =     )
F#4    1        e     u  =      .
G#4    1        e     u  ]      .
A4     1        e     d  [     (
B4     1        e     d  =     )
C#5    1        e     d  =      .
D5     1        e     d  ]      .
measure 141
E5     2        q     d         .
G#5    2        q     d         .
A5     2        q     d         .
B5     1        e     d  [     (
D6     1        e     d  ]     )
measure 142
C#6    2        q     d         .
G#5    1        e     d  [     (
B5     1        e     d  ]     )
A5     2        q     d         .
B4     1        e     d  [     (
D5     1        e     d  ]     )
measure 143
C#5    2        q     d         .
G#4    1        e     u  [     (
B4     1        e     u  ]     )
A4     2        q     u         .
D4     1        e     u  [     (
B3     1        e     u  ]     )
measure 144
A3     2        q     u
rest   2        q
G#5    2        q     d         .
 B4    2        q     d
rest   2        q
measure 145
A5     2        q     d         .
 C#5   2        q     d
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/04/02} [KHM:2565125522]
TIMESTAMP: DEC/26/2001 [md5sum:55384390fab55e65d559cfc016c68f02]
09/16/94 W Hewlett
WK#:55,1      MV#:4
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Finale [Fourth Movement]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:0/0  C:4  D:Vivace
rest   2        q
measure 1
rest   8
measure 2
E4     2        q     u         .p
*               E   0
P    C17:Y85
E4     2        q     u        (.
E4     2        q     u         .
*               F   15
E4     2        q     u        ).
measure 3
B4     6        h.    d        (f
A4     2        q     u        )
measure 4
G#4    4        h     u
rest   4        h
measure 5
rest   8
measure 6
G4     2        q n   u         p
*               E   0
G4     2        q     u        (.
G4     2        q     u         .
*               F   15
G4     2        q     u        ).
measure 7
G4     2        q n   u        (f
P    C33:Y67
F#4    2        q     u        )
rest   4        h
measure 8
*               E   15
P    C17:Y85
C#4    4        h     u        (
E4     2        q     u
*               F   0
D4     2        q     u        )
measure 9
C#4    2        q     u
rest   2        q
rest   2        q
mheavy4                  :|:
E4     1        e     u  [     (mf
F#4    1        e     u  ]     )
measure 10
G#4    1        e #   u  [     (+
F#4    1        e     u  =     )
A4     1        e     u  =     (
G#4    1        e     u  ]     )
B4     2        q     d         .
A4     2        q     u         .
measure 11
G#4    2        q     u
E4     1        e     u  [     (
F#4    1        e     u  ]     )
G#4    2        q     u         .
E4     2        q     u         .
measure 12
F#4    2        q     u         .
D#5    1        e #   d  [     (
E5     1        e     d  ]     )
F#5    2        q     d         .
B4     2        q     d         .
measure 13
B4     4        h     d
rest   4        h
measure 14
rest   4        h
rest   2        q
E5     2        q     d         .
measure 15
E5     2        q     d        (
E#5    2        q #   d
F#5    2        q     d        )
C#5    1        e     d  [     (
A4     1        e     d  ]     )
measure 16
G#4    2        q     u         .
G#4    2        q     u         .
G#4    2        q     u         .
A4     1        e     u  [     (
D#4    1        e #   u  ]     )
measure 17
E4     1        e     u  [     (
F#4    1        e     u  =
G4     1        e n   u  =
F#4    1        e     u  ]     )
E4     1        e     u  [     (
F#4    1        e     u  =
E4     1        e     u  =
D4     1        e n   u  ]     )+
measure 18
*               D       dim.
P  C25:f33  C17:Y83
C#4    8        w     u        (
measure 19
D4     8        w     u
measure 20
B3     8        w     u        )
measure 21
rest   8
measure 22
rest   8
measure 23
E4     2        q     u         p
*               E   0
P    C17:Y85
E4     2        q     u        (.
E4     2        q     u         .
*               F   15
E4     2        q     u        ).
measure 24
B4     6        h.    d        (f
A4     2        q     u        )
measure 25
G#4    4        h     u
rest   4        h
measure 26
rest   8
measure 27
G4     2        q n   u         p
*               E   0
G4     2        q     u        (.
G4     2        q     u         .
*               F   15
G4     2        q     u        ).
measure 28
G4     2        q n   u        (f
P    C33:Y66
F#4    2        q     u        )
rest   4        h
measure 29
*               E   15
P    C17:Y85
C#4    4        h     u        (
E4     2        q     u
*               F   0
D4     2        q     u        )
measure 30a                      start-end1
C#4    2        q     u
rest   2        q
rest   2        q
mheavy2 30b                      :|   stop-end1 start-end2
C#4    2        q     u
rest   2        q
rest   4        h
measure 31                       disc-end2
rest   8
measure 32
rest   4        h
rest   2        q
G#3    1        e     u  [     (f
A3     1        e     u  ]     )
measure 33
B3     1        e     u  [     (
C#4    1        e     u  =     )
D4     1        e     u  =      .
E4     1        e     u  ]      .
F#4    1        e     u  [     (
G#4    1        e     u  =     )
A4     1        e     u  =      .
B4     1        e     u  ]      .
measure 34
C#5    2        q     d
D5     1        e     d  [     (
B4     1        e     d  ]     )
C#5    2        q     d
A4     1        e     u  [     (
B4     1        e     u  ]     )
measure 35
C#5    2        q     d         .
C#5    2        q     d         .
C#5    2        q     d         .
C#5    2        q     d         .
measure 36
C#5    4-       h     d        -
C#5    1        e     d  [
D5     1        e     d  =     (
C#5    1        e     d  =
B4     1        e     d  ]     )
measure 37
A4     1        e     u  [     (
G#4    1        e     u  =     )
A4     1        e     u  =      .
B4     1        e     u  ]      .
C#5    1        e     u  [     (
B4     1        e     u  =     )
A4     1        e     u  =      .
G#4    1        e     u  ]      .
measure 38
F#4    4        h     u        (
G#4    2        q     u        )
G#4    1        e     u  [     (
F#4    1        e     u  ]     )
measure 39
E4     2        q     u
E4     2        q     u
E4     2        q     u
E4     2        q     u
measure 40
E4     8-       w     u        -
measure 41
E4     8-       w     u        -Z
P    C33:Y70
measure 42
E4     8-       w     u        -
measure 43
E4     8-       w     u        -Z
P    C33:Y70
measure 44
E4     8-       w     u        -
measure 45
E4     8        w     u        (ff
P    C33:Y75
measure 46
D#4    4        h #   u        )
rest   2        q
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 47
D#5    1        e #   d  [     (
C#5    1        e     d  =     )
B4     1        e     d  =      .
A4     1        e     d  ]      .
G#4    1        e     u  [     (
F#4    1        e     u  =     )
E4     1        e     u  =      .
D#4    1        e #   u  ]      .
measure 48
E4     2        q     u
rest   2        q
rest   2        q
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 49
D#5    1        e #   d  [     (
C#5    1        e     d  =     )
B4     1        e     d  =      .
A4     1        e     d  ]      .
G#4    1        e     u  [     (
F#4    1        e     u  =     )
E4     1        e     u  =      .
D#4    1        e #   u  ]      .
measure 50
E4     2        q     u
rest   2        q
rest   2        q
F#5    1        e     d  [     (
E5     1        e     d  ]     )
measure 51
D#5    2        q #   d
rest   2        q
rest   4        h
measure 52
D#4    4        h #   u
rest   4        h
measure 53
E5     8-       w     d        -
measure 54
E5     4-       h     d        -
E5     1        e     d  [
C#5    1        e     d  =     (
B4     1        e     d  =
A4     1        e     d  ]     )
measure 55
*               E   15
P    C17:Y72
G#4    4        h     u        (
A4     2        q     u        )
*               F   0
D#4    2        q #   u
measure 56
E4     1        e     u  [     (mf
P    C33:Y75
F#4    1        e     u  =
G4     1        e n   u  =
F#4    1        e     u  ]     )
E4     1        e     u  [     (
F#4    1        e     u  =
E4     1        e     u  =
D4     1        e n   u  ]     )+
measure 57
*               D       dim.
P  C25:f33  C17:Y85
C#4    8        w     u        (
measure 58
D4     8        w     u
measure 59
B3     8        w     u        )
measure 60
rest   8
measure 61
rest   8
measure 62
rest   8
measure 63
rest   8
measure 64
rest   8
measure 65
A4     8        w     u         mf
measure 66
D5     4        h     d
F#5    4        h     d
measure 67
G#4    8        w     u
measure 68
A4     2        q     u
B4     2        q     d
C#5    1        e     d  [     (
D5     1        e     d  =     )
E5     1        e     d  =     (
D5     1        e     d  ]     )
measure 69
C#5    1        e     d  [     (
D5     1        e     d  =     )
B4     1        e     d  =     (
C#5    1        e     d  ]     )
A4     1        e     u  [     (
B4     1        e     u  =     )
G#4    1        e     u  =     (
A4     1        e     u  ]     )
measure 70
F#4    1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
F#4    1        e     u  ]
B4     1        e     d  [
C#5    1        e     d  =
B4     1        e     d  =
A4     1        e     d  ]
measure 71
G#4    1        e     u  [
A4     1        e     u  =
G#4    1        e     u  =
F#4    1        e     u  ]
E4     1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
measure 72
C#5    2        q     d
E4     1        e     u  [     (
D4     1        e     u  ]     )
C#4    1        e     u  [     (
D4     1        e     u  =     )
B3     1        e     u  =     (
C#4    1        e     u  ]     )
measure 73
A3     2        q     u
rest   2        q
rest   4        h
measure 74
rest   8
measure 75
rest   2        q
A4     2        q     u         .
A4     2        q     u         .
A4     2        q     u         .
measure 76
A4     4        h     u
G#4    4        h     u
measure 77
G4     4-       h n   u        -
G4     1        e     u  [
E4     1        e     u  =      .
A4     1        e     u  =      .
G4     1        e     u  ]      .
measure 78
F#4    1        e     u  [      .
G4     1        e n   u  =      .
E4     1        e     u  =      .
F#4    1        e     u  ]      .
D4     1        e     u  [      .
E4     1        e     u  =      .
C#4    1        e     u  =      .
D4     1        e     u  ]      .
measure 79
B3     2        q     u         .
D4     2        q     u         .
D4     2        q     u         .
D4     2        q     u         .
measure 80
G4     4        h n   u
E4     2        q     u         .
A4     2-       q     u        -
measure 81
A4     1        e     u  [      mf
B4     1        e     u  =      .
A4     1        e     u  =      .
G4     1        e n   u  ]      .
F#4    2        q     u
rest   2        q
measure 82
rest   2        q
E5     2        q     d
E4     2        q     u
E5     2        q     d
measure 83
rest   2        q
D5     2        q     d
D4     2        q     u
D5     2        q     d
measure 84
rest   2        q
C#5    2        q     d
C#4    2        q     u
C#5    2        q     d
measure 85
D5     2        q     d
rest   2        q
rest   4        h
measure 86
C#5    8        w     d         mf
P    C33:Y61
measure 87
F#5    4        h     d
A5     4        h     d
measure 88
D#5    8        w #   d
measure 89
E5     4        h     d
G#4    1        e     u  [     (
A4     1        e     u  =
B4     1        e     u  =
G#4    1        e     u  ]     )
measure 90
E4     4        h     u
rest   4        h
measure 91
rest   4        h
rest   2        q
F#4    2-       q     u        -
measure 92
F#4    2        q     u
B3     4        h     u
B4     2-       q     d        -
measure 93
B4     2        q     d
E4     4        h     u
A4     2-       q     u        -
measure 94
A4     2        q     u
F#4    2        q     u
F#4    1        e     u  [      .
E4     1        e     u  =      .
D4     1        e     u  =      .
C#4    1        e     u  ]      .
measure 95
B3     2        q     u
rest   2        q
rest   2        q
G#4    2        q     u
measure 96
A4     2        q     u
F#4    2        q     u
rest   2        q
A4     2        q     u
measure 97
B4     2        q     d
G#4    2        q     u
rest   2        q
E4     2        q     u
measure 98
E4     8-       w     u        -
measure 99
E4     4        h     u
rest   4        h
measure 100
*               E   15
P    C17:Y75
D#4    6        h.#   u
*               F   0
C4     2        q n   u        (
measure 101
B3     6        h.    u        )p
P    C33:Y81
C4     2        q n   u        (
measure 102
B3     6        h.    u        )
C4     2        q n   u        (
measure 103
B3     6        h.    u        )
C4     2        q n   u        (
measure 104
B3     6        h.    u        )
C4     2        q n   u        (
measure 105
*               D       dim.
P  C25:f33
B3     2        q     u        )
C4     2        q n   u        (
B3     2        q     u        ).
C4     2        q     u        (
measure 106
B3     2        q     u        ).
rest   2        q
rest   4        h
measure 107
rest   8
measure 108
D4     4        h n   u         p+
P    C33:Y67
rest   4        h
measure 109
E4     2        q     u         .
*               E   0
P    C17:Y85
E4     2        q     u        (.
E4     2        q     u         .
*               F   15
E4     2        q     u        ).
measure 110
B4     6        h.    d        (f
A4     2        q     u        )
measure 111
G#4    4        h     u
rest   4        h
measure 112
rest   8
measure 113
G4     2        q n   u         .p
*               E   0
G4     2        q     u        (.
G4     2        q     u         .
*               F   15
G4     2        q     u        ).
measure 114
G4     2        q n   u        (f
P    C33:Y68
F#4    2        q     u        )
rest   4        h
measure 115
*               E   15
P    C17:Y85
C#4    4        h     u        (
E4     2        q     u
*               F   0
D4     2        q     u        )
measure 116
C#4    2        q     u         p
A3     2        q     u
G#4    1        e     u  [     (
A4     1        e     u  =     )
A4     1        e     u  =     (
B4     1        e     u  ]     )
measure 117
A4     2        q     u
A3     2        q     u
B4     1        e     d  [     (
C#5    1        e     d  =     )
C#5    1        e     d  =     (
D5     1        e     d  ]     )
measure 118
C#5    2        q     d
A3     2        q     u
rest   4        h
measure 119
F#5    1        e     d  [     (
E#5    1        e #   d  =     )
F#5    1        e     d  =     (
C#5    1        e     d  ]     )
D5     2        q     d
rest   2        q
measure 120
B4     1        e     u  [     (
A#4    1        e #   u  =     )
B4     1        e     u  =     (
F#4    1        e     u  ]     )
D5     2        q     d
rest   2        q
measure 121
rest   2        q
*               E   0
P    C17:Y75
B4     2        q     d
B4     2        q     d
*               F   15
B4     2        q     d
measure 122
C5     2        q n   d         f
P    C33:Y65
C5     2        q     d
C5     2        q     d
C5     2        q     d
measure 123
C#5    4        h #   d         +
rest   4        h
measure 124
rest   8
measure 125
rest   4        h
rest   2        q
D4     1        e     u  [     (p
C#4    1        e     u  ]     )
measure 126
B3     1        e     u  [     (
C#4    1        e     u  =
B3     1        e     u  =
A3     1        e     u  ]     )
G#3    2        q     u
rest   2        q
measure 127
rest   4        h
rest   2        q
D5     1        e     d  [     (f
P    C33:Y65
C#5    1        e     d  ]     )
measure 128
B4     1        e     d  [     (
C#5    1        e     d  =
B4     1        e     d  =
A4     1        e     d  ]     )
G#4    2        q     u
rest   2        q
measure 129
rest   8
measure 130
F#4    2        q     u         p
*               E   0
F#4    2        q     u        (.
F#4    2        q     u         .
*               F   15
F#4    2        q     u        ).
measure 131
F#4    4        h     u        (f
P    C32:o
B4     2        q     d
A4     2        q     u        )
measure 132
G#4    4        h     u
rest   4        h
measure 133
rest   8
measure 134
B4     2        q     d         .p
*               E   0
P    C17:Y73
B4     2        q     d        (.
B4     2        q     d         .
*               F   15
B4     2        q     d        ).
measure 135
A4     8        w     u         f
measure 136
*               E   15
P    C17:Y85
C#4    4        h     u        (
E4     2        q     u
*               F   0
D4     2        q     u        )
measure 137
C#4    2        q     u
rest   2        q
rest   4        h
measure 138
rest   8
measure 139
rest   4        h
rest   2        q
G#3    1        e     u  [     (f
A3     1        e     u  ]     )
measure 140
B3     1        e     u  [     (
C#4    1        e     u  =     )
D4     1        e     u  =      .
E4     1        e     u  ]      .
F#4    1        e     u  [     (
G#4    1        e     u  =     )
A4     1        e     u  =      .
B4     1        e     u  ]      .
measure 141
C#5    2        q     d         .
D5     2        q     d         .
C#5    2        q     d         .
G#5    1        e     d  [     (
B5     1        e     d  ]     )
measure 142
A5     2        q     d         .
B4     1        e     d  [     (
D5     1        e     d  ]     )
C#5    2        q     d         .
G#4    1        e     u  [     (
B4     1        e     u  ]     )
measure 143
A4     2        q     u         .
B3     1        e     u  [     (
D4     1        e     u  ]     )
C#4    2        q     u         .
G#3    1        e     u  [     (
B3     1        e     u  ]     )
measure 144
A3     2        q     u         .
rest   2        q
D5     2        q     u
 E4    2        q     u         .
rest   2        q
measure 145
C#5    2        q     u
 E4    2        q     u         .
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/04/03} [KHM:2565125522]
TIMESTAMP: DEC/26/2001 [md5sum:83dcd19acbf4040fff4e23712acdccff]
09/16/94 W Hewlett
WK#:55,1      MV#:4
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Finale [Fourth Movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:0/0  C:13  D:Vivace
rest   2        q
measure 1
rest   8
measure 2
E4     2        q     d         .p
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 3
E4     8-       w     d        -f
P    C33:Y60
measure 4
E4     4        h     d
rest   4        h
measure 5
rest   8
measure 6
E4     2        q     d         p
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 7
D4     4        h     d         f
P    C33:Y65
rest   4        h
measure 8
E4     4        h     d        (
G#3    4        h     u        )
measure 9
A3     2        q     u
rest   2        q
rest   2        q
mheavy4                  :|:
rest   2        q
measure 10
rest   8
measure 11
rest   2        q
B4     1        e     d  [     (mf
P    C33:Y60
A4     1        e     d  ]     )
G#4    2        q     d         .
B4     2        q     d         .
measure 12
A4     2        q     d         .
F#4    1        e     d  [     (
E4     1        e     d  ]     )
D#4    2        q #   d         .
F#4    2        q     d         .
measure 13
E4     6        h.    d
E4     1        e     d  [     (
F#4    1        e     d  ]     )
measure 14
G#4    1        e     d  [     (
F#4    1        e     d  =     )
A4     1        e     d  =     (
G#4    1        e     d  ]     )
B4     2        q     d         .
B4     2        q     d         .
measure 15
A4     2        q     d         .
A3     2        q     u         .
A3     2        q     u         .
A3     2        q     u         .
measure 16
B3     2        q     u         .
B3     2        q     u         .
B3     2        q     u         .
B3     2        q     u         .
measure 17
E3     4        h     u
rest   4        h
measure 18
*               D       dim.
P  C25:f33  C17:Y68
A#3    8        w #   u        (
measure 19
B3     8        w     u
measure 20
G#3    8        w     u        )
measure 21
rest   8
measure 22
rest   8
measure 23
E4     2        q     d         p.
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 24
E4     8-       w     d        -f
P    C33:Y60
measure 25
E4     4        h     d
rest   4        h
measure 26
rest   8
measure 27
E4     2        q     d         p
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 28
D4     4        h     d         f
P    C33:Y65
rest   4        h
measure 29
*               E   15
P    C17:Y65
E4     4        h     d        (
*               F   0
G#3    4        h     u        )
measure 30a                    start-end1
A3     2        q     u
rest   2        q
rest   2        q
mheavy2 30b                    :|   stop-end1 start-end2
A3     2        q     u
rest   2        q
rest   4        h
measure 31                     disc-end2
rest   2        q
B3     1        e     u  [      .f
C#4    1        e     u  ]      .
D4     1        e     d  [     (
E4     1        e     d  =     )
F#4    1        e     d  =      .
G#4    1        e     d  ]      .
measure 32
A4     2        q     d         .
B4     2        q     d         .
C#5    2        q     d         .
rest   2        q
measure 33
rest   8
measure 34
rest   4        h
rest   2        q
C#5    1        e     d  [     (
B4     1        e     d  ]     )
measure 35
A4     1        e     d  [     (
G#4    1        e     d  =     )
F#4    1        e     d  =      .
E4     1        e     d  ]      .
D4     1        e     d  [     (
C#4    1        e     d  =     )
B3     1        e     d  =      .
A3     1        e     d  ]      .
measure 36
G#3    4        h     u        (
A3     1        e     u  [     )
B3     1        e     u  =     (
A3     1        e     u  =
G#3    1        e     u  ]     )
measure 37
F#3    8        w     u
measure 38
B3     8-       w     u        -
measure 39
B3     8        w     u
measure 40
C#4    4        h     d
B3     4        h     u
measure 41
C#4    2        q     d         Z
C#4    2        q     d
B3     2        q     u
B3     2        q     u
measure 42
C#4    4        h     d
B3     4        h     u
measure 43
C#4    2        q     d         Z
C#4    2        q     d
B3     2        q     u
B3     2        q     u
measure 44
C#4    8-       w     d        -
measure 45
C#4    8        w     d        (ff
P    C33:Y63
measure 46
B3     4        h     u        )
rest   4        h
measure 47
rest   4        h
rest   2        q
G#3    1        e     u  [     (
A3     1        e     u  ]     )
measure 48
B3     1        e     d  [     (
C#4    1        e     d  =     )
D#4    1        e #   d  =      .
E4     1        e     d  ]      .
F#4    1        e     d  [     (
G#4    1        e     d  =     )
A4     1        e     d  =      .
B4     1        e     d  ]      .
measure 49
A4     2        q     d
rest   2        q
rest   2        q
G#3    1        e     u  [     (
A3     1        e     u  ]     )
measure 50
B3     1        e     d  [     (
C#4    1        e     d  =     )
D#4    1        e #   d  =      .
E4     1        e     d  ]      .
F#4    1        e     d  [     (
G#4    1        e     d  =     )
A4     1        e     d  =      .
B4     1        e     d  ]      .
measure 51
A4     2        q     d
rest   2        q
rest   4        h
measure 52
F#4    4        h     d
rest   2        q
B3     2        q     u
measure 53
B3     6        h.    u
E4     2        q     d
measure 54
A3     1        e     u  [     (
G#3    1        e     u  =
A3     1        e     u  =
G#3    1        e     u  ]     )
A3     2        q     u         .
C#4    2        q     d         .
measure 55
*               E   15
P    C17:Y65
B3     2        q     u         .
E4     2        q     d         .
D#4    2        q #   d         .
*               F   0
B3     2        q     u         .
measure 56
E4     4        h     d
rest   4        h
measure 57
*               D       dim.
P  C25:f33  C17:Y70
A#3    8        w #   u        (
measure 58
B3     8        w     u
measure 59
G#3    8        w     u        )
measure 60
rest   8
measure 61
rest   8
measure 62
rest   2        q
E4     2        q     d         mf.
E4     2        q     d         .
E4     2        q     d         .
measure 63
A4     4        h     d
F#4    2        q     d
B4     2-       q     d        -
measure 64
B4     2        q     d
G#4    2        q     d         .
E4     2        q     d         .
E5     1        e     d  [     (
D5     1        e     d  ]     )
measure 65
C#5    1        e     d  [     (
D5     1        e     d  =     )
B4     1        e     d  =     (
C#5    1        e     d  ]     )
A4     1        e     d  [     (
B4     1        e     d  =     )
G#4    1        e     d  =     (
A4     1        e     d  ]     )
measure 66
F#4    1        e     d  [      .
G#4    1        e     d  =      .
A4     1        e     d  =      .
F#4    1        e     d  ]      .
D4     1        e     d  [      .
E4     1        e     d  =      .
F#4    1        e     d  =      .
D4     1        e     d  ]      .
measure 67
B3     1        e     d  [      .
C#4    1        e     d  =      .
D4     1        e     d  =      .
B3     1        e     d  ]      .
E4     1        e     d  [      .
F#4    1        e     d  =      .
E4     1        e     d  =      .
D4     1        e     d  ]      .
measure 68
C#4    1        e     d  [      .
D4     1        e     d  =      .
B3     1        e     d  =      .
C#4    1        e     d  ]      .
A3     2        q     u
rest   2        q
measure 69
rest   8
measure 70
rest   8
measure 71
rest   8
measure 72
A4     8        w     d         mf
P    C33:Y60
measure 73
D5     4        h     d
F#5    4        h     d
measure 74
G#4    8        w     d
measure 75
A4     2        q     d         .
B4     2        q     d         .
C#5    1        e     d  [      .
A4     1        e     d  =      .
B4     1        e     d  =      .
C#5    1        e     d  ]      .
measure 76
D5     1        e     d  [      .
B4     1        e     d  =      .
C#5    1        e     d  =      .
D5     1        e     d  ]      .
E5     1        e     d  [      .
B4     1        e     d  =      .
E5     1        e     d  =      .
D5     1        e     d  ]      .
measure 77
C#5    1        e     d  [      .
D5     1        e     d  =      .
B4     1        e     d  =      .
C#5    1        e     d  ]      .
A4     2        q     d
A4     2        q     d
measure 78
A4     1        e     d  [      .
B4     1        e     d  =      .
G4     1        e n   d  =      .
A4     1        e     d  ]      .
F#4    2        q     d
rest   2        q
measure 79
rest   8
measure 80
rest   8
measure 81
D3     4        h     u
D4     4-       h     d        -
measure 82
D4     4        h     d
C#4    4-       h     d        -
measure 83
C#4    4        h     d
B3     4-       h     u        -
measure 84
B3     4        h     u
A#3    4        h #   u
measure 85
B3     2        q     u
F#4    2        q     d         .
F#4    2        q     d         .
F#4    2        q     d         .
measure 86
G#4    2        q #   d         +
C#4    4        h     d
G#4    2        q     d
measure 87
C#5    1        e     d  [     (
D5     1        e     d  =     )
B4     1        e     d  =     (
C#5    1        e     d  ]     )
A4     1        e     d  [     (
B4     1        e     d  =     )
G#4    1        e     d  =     (
A4     1        e     d  ]     )
measure 88
F#4    1        e     d  [     (
G#4    1        e     d  =
A4     1        e     d  =
G#4    1        e     d  ]     )
F#4    1        e     d  [     (
A4     1        e     d  =
G#4    1        e     d  =
F#4    1        e     d  ]     )
measure 89
E4     8        w     d
measure 90
A4     4        h     d
C#5    4-       h     d        -
measure 91
C#5    2        q     d
F#4    1        e     d  [     (
G#4    1        e     d  ]     )
A4     2        q     d
A4     2        q     d
measure 92
B4     2        q     d
E4     2        q     d
E4     2        q     d
E4     2        q     d
measure 93
E4     4        h     d
rest   4        h
measure 94
A3     4        h     u
B3     4-       h     u        -
measure 95
B3     4        h     u
C#4    4-       h     d        -
measure 96
C#4    4        h     d
D4     4-       h     d        -
measure 97
D4     4        h     d
G#3    2        q     u
B3     2        q     u
measure 98
C#4    2        q     d
D4     2        q     d
E4     2        q     d
B3     2        q     u
measure 99
C#4    2        q     d
D4     2        q     d
E4     2        q     d
rest   2        q
measure 100
*               E   15
P    C17:Y70
*      7        F
A3     8-       w     u        -
measure 101
A3     8-       w     u        -p
P    C33:Y65
measure 102
A3     8-       w     u        -
measure 103
A3     8-       w     u        -
measure 104
A3     8        w     u
measure 105
*               D       dim.
P  C25:f33  C17:Y65
A3     4        h     u
A3     4        h     u
measure 106
A3     2        q     u
rest   2        q
rest   4        h
measure 107
rest   8
measure 108
B3     4        h     u         p
rest   4        h
measure 109
E4     2        q     d         .
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 110
E4     8-       w     d        -f
P    C33:Y60
measure 111
E4     4        h     d
rest   4        h
measure 112
rest   8
measure 113
E4     2        q     d         p.
*               E   0
P    C17:Y65
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 114
D4     4        h     d         f
P    C33:Y65
rest   4        h
measure 115
*               E   15
P    C17:Y65
E4     4        h     d        (
*               F   0
G#3    4        h     u        )
measure 116
A3     2        q     u         p
P    C33:Y55
A3     2        q     u
A3     2        q     u
A3     2        q     u
measure 117
A3     2        q     u
A3     2        q     u
A3     2        q     u
A3     2        q     u
measure 118
A3     2        q     u
A3     2        q     u
rest   2        q
A3     2        q     u
measure 119
rest   2        q
A3     2        q     u
rest   2        q
F#4    2        q     d
measure 120
rest   2        q
F#4    2        q     d
rest   2        q
F#4    2        q     d
measure 121
rest   2        q
*               E   0
P    C17:Y65
F#4    2        q     d
F#4    2        q     d
*               F   15
F#4    2        q     d
measure 122
F#4    2        q     d         f
F#4    2        q     d
F#4    2        q     d
F#4    2        q     d
measure 123
E4     4        h     d
rest   4        h
measure 124
rest   4        h
rest   2        q
D4     1        e     d  [     (p
P    C33:Y67
C#4    1        e     d  ]     )
measure 125
B3     1        e     u  [     (
C#4    1        e     u  =
B3     1        e     u  =
A3     1        e     u  ]     )
G#3    2        q     u
rest   2        q
measure 126
rest   4        h
rest   2        q
B4     1        e     d  [     (f
P    C33:Y60
A4     1        e     d  ]     )
measure 127
G#4    1        e     d  [     (
A4     1        e     d  =
G#4    1        e     d  =
F#4    1        e     d  ]     )
E4     2        q     d
rest   2        q
measure 128
rest   8
measure 129
rest   8
measure 130
E4     2        q     d         p
*               E   0
P    C17:Y68
E4     2        q     d        (.
E4     2        q     d         .
*               F   15
E4     2        q     d        ).
measure 131
B3     4        h     u        (f
E4     2        q     d        )
E4     2        q     d
measure 132
E4     4        h     d
rest   4        h
measure 133
rest   8
measure 134
G#4    2        q     d         p.
*               E   0
P    C17:Y66
G#4    2        q     d        (.
G#4    2        q     d         .
*               F   15
G#4    2        q     d        ).
measure 135
F#4    8        w     d         f
P    C33:Y62
measure 136
*               E   15
P    C17:Y65
E4     4        h     d        (
*               F   0
G#3    4        h     u        )
measure 137
A3     4        h     u
rest   4        h
measure 138
rest   2        q
B3     1        e     u  [      .
C#4    1        e     u  ]      .
D4     1        e     d  [     (
E4     1        e     d  =     )
F#4    1        e     d  =      .
G#4    1        e     d  ]      .
measure 139
A4     2        q     d         .
B4     2        q     d         .
C#5    2        q     d         .
D5     1        e     d  [     (
C#5    1        e     d  ]     )
measure 140
B4     1        e     d  [     (
A4     1        e     d  =     )
G#4    1        e     d  =      .
F#4    1        e     d  ]      .
E4     1        e     d  [     (
D4     1        e     d  =     )
C#4    1        e     d  =      .
B3     1        e     d  ]      .
measure 141
A3     2        q     u         .
B3     2        q     u         .
C#4    2        q     d         .
E4     2        q     d         .
measure 142
E4     2        q     d         .
E4     2        q     d         .
E4     2        q     d         .
E4     2        q     d         .
measure 143
E4     2        q     d         .
E4     2        q     d         .
E4     2        q     d         .
E4     2        q     d         .
measure 144
C#4    2        q     d         .
rest   2        q
E4     2        q     d         .
rest   2        q
measure 145
A4     2        q     d         .
 E4    2        q     d
 A3    2        q     d
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/04/04} [KHM:2565125522]
TIMESTAMP: DEC/26/2001 [md5sum:673d1bfb589c47efb05b31fb66005c6d]
09/16/94 W Hewlett
WK#:55,1      MV#:4
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Finale [Fourth Movement]
Violonecello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:3   Q:2   T:0/0  C:22  D:Vivace
rest   2        q
measure 1
rest   8
measure 2
A3     2        q     d         p.
*               E   0
P    C17:Y65
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 3
G#3    6        h.    d        (f
P    C33:Y62
A3     2        q     d        )
measure 4
E3     4        h     d
rest   4        h
measure 5
rest   8
measure 6
A3     2        q     d         p
*               E   0
P    C17:Y65
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 7
D3     4        h     d         f
rest   4        h
measure 8
*               E   15
P    C17:Y70
E3     4        h     d
*               F   0
E2     4        h     u
measure 9
A2     2        q     u        (mf
C#3    1        e     d  [
E3     1        e     d  ]     )
A3     2        q     d         .
mheavy4                  :|:
rest   2        q
measure 10
rest   8
measure 11
rest   2        q
G#3    1        e     d  [     (mf
F#3    1        e     d  ]     )
E3     2        q     d         .
G#3    2        q     d         .
measure 12
F#3    2        q     d         .
D#3    1        e #   u  [     (
C#3    1        e     u  ]     )
B2     2        q     u         .
D#3    2        q     d         .
measure 13
E3     4        h     d
rest   4        h
measure 14
rest   4        h
rest   2        q
G#3    2        q     d         .
measure 15
A3     2        q     d         .
A3     2        q     d         .
A3     2        q     d
A3     2        q     d
measure 16
B3     2        q     d         .
B3     2        q     d         .
B2     2        q     u
B2     2        q     u
measure 17
E3     8-       w     d        -
measure 18
*               D       dim.
P  C25:f33  C17:Y65
E3     8-       w     d        -
measure 19
E3     8-       w     d        -
measure 20
E3     8        w     d
measure 21
rest   8
measure 22
rest   8
measure 23
A3     2        q     d         p.
*               E   0
P    C17:Y65
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 24
G#3    6        h.    d        (f
P    C33:Y60
A3     2        q     d        )
measure 25
E3     4        h     d
rest   4        h
measure 26
rest   8
measure 27
A3     2        q     d         p
*               E   0
P    C17:Y65
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 28
D3     4        h     d         f
rest   4        h
measure 29
*               E   15
P    C17:Y70
E3     4        h     d
*               F   0
E2     4        h     u
measure 30a                start-end1
A2     2        q     u        (mf
C#3    1        e     d  [
E3     1        e     d  ]     )
A3     2        q     d         .
mheavy2 30b                :|   stop-end1 start-end2
*               E   0
P    C17:Y65
A2     2        q     u
A2     2        q     u
A2     2        q     u
*               F   15
A2     2        q     u
measure 31                 disc-end2
A2     2        q     u         f
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 32
A2     2        q     u
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 33
A2     2        q     u
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 34
A2     2        q     u
A2     2        q     u
A2     2        q     u
A3     1        e     d  [     (
G#3    1        e     d  ]     )
measure 35
F#3    1        e     d  [     (
E3     1        e     d  =     )
D3     1        e     d  =      .
C#3    1        e     d  ]      .
B2     1        e     u  [     (
A2     1        e     u  =     )
G#2    1        e     u  =      .
F#2    1        e     u  ]      .
measure 36
E#2    4        h #   u        (
F#2    2        q     u        )
A3     1        e     d  [     (
B3     1        e     d  ]     )
measure 37
C#4    1        e     d  [     (
D4     1        e     d  =     )
C#4    1        e     d  =      .
B3     1        e     d  ]      .
A3     1        e     d  [     (
G#3    1        e     d  =     )
F#3    1        e     d  =      .
E3     1        e n   d  ]      .+
measure 38
D#3    4        h #   d        (
E3     2        q     d        )
E3     1        e     d  [     (
F#3    1        e     d  ]     )
measure 39
G#3    2        q     d
G#3    2        q     d
G#3    2        q     d
G#3    2        q     d
measure 40
A3     2        q     d
A3     2        q     d
B3     2        q     d
B3     2        q     d
measure 41
C#4    2        q     d         Z
P    C33:Y60
C#4    2        q     d
B3     2        q     d
B3     2        q     d
measure 42
A3     2        q     d
A3     2        q     d
B3     2        q     d
B3     2        q     d
measure 43
C#4    2        q     d         Z
P    C33:Y60
C#4    2        q     d
B3     2        q     d
B3     2        q     d
measure 44
A3     2        q     d
A3     2        q     d
A3     2        q     d
A3     2        q     d
measure 45
A#3    2        q #   d         ff
P    C33:Y60
A#3    2        q     d
A#3    2        q     d
A#3    2        q     d
measure 46
B3     4        h     d
rest   4        h
measure 47
rest   4        h
rest   2        q
E2     1        e     u  [     (
F#2    1        e     u  ]     )
measure 48
G#2    1        e     u  [     (
A2     1        e n   u  =     )+
B2     1        e     u  =      .
C#3    1        e     u  ]      .
D#3    1        e #   d  [     (
E3     1        e     d  =     )
F#3    1        e     d  =      .
G#3    1        e     d  ]      .
measure 49
A3     2        q     d
rest   2        q
rest   2        q
E2     1        e     u  [     (
F#2    1        e     u  ]     )
measure 50
G#2    1        e     u  [     (
A2     1        e     u  =     )
B2     1        e     u  =      .
C#3    1        e     u  ]      .
D#3    1        e #   d  [     (
E3     1        e     d  =     )
F#3    1        e     d  =      .
G#3    1        e     d  ]      .
measure 51
A3     4        h     d
rest   4        h
measure 52
A3     4        h     d
rest   2        q
G#3    2        q     d
measure 53
G#3    1        e     d  [     (
A3     1        e     d  =
G#3    1        e     d  =
A3     1        e     d  ]     )
G#3    2        q     d         .
G#3    2        q     d         .
measure 54
A3     1        e     d  [     (
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]     )
A3     2        q     d         .
A3     2        q     d         .
measure 55
*               E   15
P    C17:Y65
B3     2        q     d         .
B3     2        q     d         .
B2     2        q     u         .
*               F   0
B2     2        q     u         .
measure 56
E2     8-       w     u        -mf
P    C33:Y86
measure 57
*               D       dim.
P  C25:f33
E2     8-       w     u        -
measure 58
E2     8-       w     u        -
measure 59
E2     8        w     u
measure 60
rest   8
measure 61
E3     8        w     d         mf
P    C33:Y60
measure 62
A3     4        h     d
C#4    4        h     d
measure 63
D#3    8        w #   d
measure 64
E3     4        h     d
rest   4        h
measure 65
rest   8
measure 66
rest   8
measure 67
rest   8
measure 68
rest   8
measure 69
rest   8
measure 70
rest   8
measure 71
rest   4        h
rest   2        q
E4     1        e     d  [     (
D4     1        e     d  ]     )
measure 72
C#4    1        e     d  [     (
D4     1        e     d  =     )
B3     1        e     d  =     (
C#4    1        e     d  ]     )
A3     1        e     d  [     (
B3     1        e     d  =     )
G#3    1        e     d  =     (
A3     1        e     d  ]     )
measure 73
F#3    1        e     d  [      .
G#3    1        e     d  =      .
A3     1        e     d  =      .
F#3    1        e     d  ]      .
D3     1        e     d  [      .
E3     1        e     d  =      .
F#3    1        e     d  =      .
D3     1        e     d  ]      .
measure 74
B2     1        e     u  [      .
C#3    1        e     u  =      .
D3     1        e     u  =      .
B2     1        e     u  ]      .
E3     1        e     d  [      .
F#3    1        e     d  =      .
E3     1        e     d  =      .
D3     1        e     d  ]      .
measure 75
C#3    1        e     u  [      .
D3     1        e     u  =      .
C#3    1        e     u  =      .
B2     1        e     u  ]      .
A2     2        q     u
rest   2        q
measure 76
rest   8
measure 77
A2     8        w     u         mf
measure 78
D3     4        h     d
F#3    4        h     d
measure 79
B3     1        e     d  [      .
C#4    1        e     d  =      .
D4     1        e     d  =      .
B3     1        e     d  ]      .
G3     1        e n   d  [      .
A3     1        e     d  =      .
B3     1        e     d  =      .
G3     1        e     d  ]      .
measure 80
E3     1        e     d  [      .
F#3    1        e     d  =      .
G3     1        e n   d  =      .
E3     1        e     d  ]      .
A3     1        e     d  [      .
B3     1        e     d  =      .
A3     1        e     d  =      .
G3     1        e     d  ]      .
measure 81
F#3    1        e     d  [      .
G3     1        e n   d  =      .
F#3    1        e     d  =      .
E3     1        e     d  ]      .
D3     2        q     d
rest   2        q
measure 82
rest   8
measure 83
rest   8
measure 84
F#3    8        w     d         mf
P    C33:Y60
measure 85
B3     4        h     d
D4     4        h     d
measure 86
E#3    8        w #   d
measure 87
F#3    8        w     d
measure 88
B3     8        w     d
measure 89
E3     4        h n   d         +
rest   4        h
measure 90
A2     8        w     u
measure 91
D3     4        h     d
F#3    4        h     d
measure 92
G2     8        w n   u
measure 93
A2     4        h     u
C#3    4        h     u
measure 94
D3     1        e     d  [      .
E3     1        e     d  =      .
F#3    1        e     d  =      .
D3     1        e     d  ]      .
B2     1        e     u  [      .
C#3    1        e     u  =      .
D3     1        e     u  =      .
B2     1        e     u  ]      .
measure 95
E3     1        e     d  [      .
F#3    1        e     d  =      .
G#3    1        e #   d  =      .+
E3     1        e     d  ]      .
C#3    1        e     d  [      .
D3     1        e     d  =      .
E3     1        e     d  =      .
C#3    1        e     d  ]      .
measure 96
F#3    1        e     d  [      .
G#3    1        e     d  =      .
A3     1        e     d  =      .
F#3    1        e     d  ]      .
D3     1        e     d  [      .
E3     1        e     d  =      .
F#3    1        e     d  =      .
D3     1        e     d  ]      .
measure 97
G#3    1        e     d  [      .
A3     1        e     d  =      .
B3     1        e     d  =      .
G#3    1        e     d  ]      .
E3     2        q     d
G#3    2        q     d
measure 98
A3     2        q     d
B3     2        q     d
C#4    2        q     d
G#3    2        q     d
measure 99
A3     2        q     d
B3     2        q     d
C#4    2        q     d
rest   2        q
measure 100
*               E   15
P    C17:Y60
*      7        F   0
F#3    8-       w     d        -
measure 101
F#3    8-       w     d        -p
P    C33:Y58
measure 102
F#3    8-       w     d        -
measure 103
F#3    8-       w     d        -
measure 104
F#3    8        w     d
measure 105
*               D       dim.
P  C25:f33  C17:Y65
F#3    4        h     d
F#3    4        h     d
measure 106
F#3    2        q     d
rest   2        q
rest   4        h
measure 107
rest   8
measure 108
E3     4        h     d         p
P    C33:Y65
rest   4        h
measure 109
A3     2        q     d         .
*               E   0
P    C17:Y60
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 110
G#3    6        h.    d        (f
P    C33:Y60
A3     2        q     d        )
measure 111
E3     4        h     d
rest   4        h
measure 112
rest   8
measure 113
A3     2        q     d         p.
*               E   0
P    C17:Y65
A3     2        q     d        (.
A3     2        q     d         .
*               F   15
A3     2        q     d        ).
measure 114
D3     4        h     d         f
rest   4        h
measure 115
*               E   15
P    C17:Y70
E3     4        h     d
*               F   0
E2     4        h     u
measure 116
A2     2        q     u         p
P    C33:Y58
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 117
A2     2        q     u
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 118
A2     2        q     u
A2     2        q     u
rest   2        q
C#3    2        q     u
measure 119
rest   2        q
D3     2        q     d
rest   2        q
D3     2        q     d
measure 120
rest   2        q
D3     2        q     d
rest   2        q
D3     2        q     d
measure 121
rest   2        q
*               E   0
P    C17:Y70
D3     2        q     d
D3     2        q     d
*               F   15
D3     2        q     d
measure 122
D#3    2        q #   d         f
D#3    2        q     d
D#3    2        q     d
D#3    2        q     d
measure 123
E3     4        h     d
rest   4        h
measure 124
rest   4        h
rest   2        q
B3     1        e     d  [     (p
P    C33:Y55
A3     1        e     d  ]     )
measure 125
G#3    1        e     d  [     (
A3     1        e     d  =
G#3    1        e     d  =
F#3    1        e     d  ]     )
E3     2        q     d
rest   2        q
measure 126
rest   4        h
rest   2        q
D4     1        e     d  [     (f
P    C33:Y60
C#4    1        e     d  ]     )
measure 127
B3     1        e     d  [     (
C#4    1        e     d  =
B3     1        e     d  =
A3     1        e     d  ]     )
G#3    2        q     d
rest   2        q
measure 128
rest   8
measure 129
rest   8
measure 130
A#3    2        q #   d         p
P    C33:Y59
*               E   0
P    C17:Y60
A#3    2        q     d        (.
A#3    2        q     d         .
*               F   15
A#3    2        q     d        ).
measure 131
B3     4        h     d        (f
P    C33:Y60
G#3    2        q     d
A3     2        q     d        )
measure 132
E3     4        h     d
rest   4        h
measure 133
rest   8
measure 134
E#4    2        q #   d         p.
P    C33:Y57
*               E   0
P    C17:Y60
E#4    2        q     d        (.
E#4    2        q     d         .
*               F   15
E#4    2        q     d        ).
measure 135
F#4    4        h     d         f
P    C33:Y60
D3     4        h     d
measure 136
*               E   15
P    C17:Y70
E3     4        h n   d        (+
*               F   0
E2     4        h     u        )
measure 137
*               E   0
P    C17:Y63
A2     2        q     u
A2     2        q     u
A2     2        q     u
*               F   15
A2     2        q     u
measure 138
A2     2        q     u         f
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 139
A2     2        q     u
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 140
A2     2        q     u
A2     2        q     u
A2     2        q     u
A2     2        q     u
measure 141
A2     2        q     u
A2     2        q     u
A2     2        q     u
E3     2        q     d         .
measure 142
A3     2        q     d         .
E3     2        q     d         .
A3     2        q     d         .
E3     2        q     d         .
measure 143
A3     2        q     d         .
E3     2        q     d         .
A3     2        q     d         .
E3     2        q     d         .
measure 144
A3     2        q     d         .
rest   2        q
E3     2        q     d         .
rest   2        q
measure 145
A2     2        q     u         .
rest   2        q
rest   4        h
mheavy2
/END
/eof
//
