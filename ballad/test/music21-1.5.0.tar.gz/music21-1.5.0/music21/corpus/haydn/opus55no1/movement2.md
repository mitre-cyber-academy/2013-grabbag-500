&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/02/01} [KHM:2170944275]
TIMESTAMP: DEC/26/2001 [md5sum:9fe25e3be9d74445d58dfed7b919f012]
09/16/94 W Hewlett
WK#:55,1      MV#:2
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Adagio cantabile [Second movement]
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:24   T:2/4  C:4  D:Adagio cantabile
rest  48
measure 2
rest  48
measure 3
rest  48
measure 4
rest  48
measure 5
rest  48
measure 6
rest  48
measure 7
rest  48
measure 8
rest  48
measure 9
*               D       dolce
P    C17:f33
A5    24        q     d
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 10
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12-       e     d  ]     -
A5     6        s     d  [[
B5     3        t     d  ==[    (
A5     3        t     d  ]]]
G5     3        t     d  [[[
F#5    3        t     d  ===
E5     3        t     d  ===
D5     3        t     d  ]]]    )
measure 11
C#5    9        s.    d  [[     (
A4     3        t     d  ==\    )
D5     9        s.    d  ==     (
A4     3        t     d  ]]\    )
G5    12        e     d  [
gG5    0        e     u         (
F#5    3        t     d  =[[    )(
E5     3        t     d  ===
F#5    3        t     d  ===
G5     3        t     d  ]]]     )
measure 12
F#5   24        q     d
E5     6        s     d  [[
F#5    6        s     d  ==      (
G5     6        s     d  ==
G#5    6        s #   d  ]]      )
measure 13
A5    24        q     d
B5    18        e.    d  [       (
C#6    3        t     d  =[[
D6     3        t     d  ]]]     )
measure 14
D6     6        s     d  [[      (
A5     6        s     d  =]      )
A5    12-       e     d  ]     -
A5     6        s     d  [[
*               E   0
B5     3        t     d  ==[     .(
C#6    3        t     d  ]]]     .
D6     3        t     d  [[[     .
E6     3        t     d  ===     .
F#6    3        t     d  ===     .
G6     3        t     d  ]]]     .)
measure 15
*               F   18
A6    12        e     d
rest   9        s.
F#6    3        t     d
D6    12        e     d  [
gF#6   0        e     u         (
E6     3        t     d  =[[    )(
D6     3        t     d  ===
E6     3        t     d  ===
F#6    3        t     d  ]]]     )
measure 16
D6    24        q     d
rest  24        q
measure 17
rest   3        t
D5     3        t     d  [[[    .(
E5     3        t     d  ===    .
F#5    3        t     d  ]]]    .
G5     3        t     d  [[[    .
A5     3        t     d  ===    .
B5     3        t     d  ===    .
C#6    3        t     d  ]]]    .)
D6    12        e     d
rest  12        e
measure 18
rest   3        t
A4     3        t     d  [[[    .(
B4     3        t     d  ===    .
C#5    3        t     d  ]]]    .
D5     3        t     d  [[[    .
E5     3        t     d  ===    .
F#5    3        t     d  ===    .
G5     3        t     d  ]]]    .)
A5    12        e     d  [
gB5    0        e     u         (
A5     3        t     d  =[[    )(
G#5    3        t #   d  ===
A5     3        t     d  ===
B5     3        t     d  ]]]     )
measure 19
A5    12        e     d
rest  12        e
A5    12        e     d  [
gB5    0        e     u         (
A5     3        t     d  =[[    )(
G#5    3        t #   d  ===
A5     3        t     d  ===
B5     3        t     d  ]]]     )
measure 20
G#5    6        s #   d  [/
D6    12        e     d  =      f
C#6   12        e     d  =      f
B5    12        e     d  =      f
A#5    6-       s #   d  ]\    -f
measure 21
A#5    6        s     d  [/
B5    12        e     d  =      f
A#5    6        s #   d  ]\
*               E   18
B5     6        s     d  [[     (
A#5    6        s     d  ==
B5     6        s     d  ==
*               F   0
A5     6        s n   d  ]]     )
measure 22
G#5    6        s #   d  [[     p
E5     6        s     d  ==     .(
E5     6        s     d  ==     .
E5     6        s     d  ]]     .
E5     6        s     d  [[     .
E5     6        s     d  ==     .
E5     6        s     d  ==     .
E5     6        s     d  ]]     .)
measure 23
E5    24        q     d
F#5   18        e.    d  [      (
G#5    3        t #   d  =[[
A5     3        t     d  ]]]    )
measure 24
A5     6        s     d  [[     (
E5     6        s     d  =]     )
E5    12-       e     d  ]     -
E5     6        s     d  [[
E#5    6        s #   d  ]]
F#5    3        t     d  [[[    ([
G#5    3        t #   d  ===    )
G#5    3        t     d  ===    (
A5     3        t     d  ]]]    )]
measure 25
A5     6        s     d  [[     (
E5     6        s n   d  =]     )+
E5    12-       e     d  ]     -
E5     6        s     d  [[
E#5    6        s #   d  ]]
F#5    3        t     d  [[[    ([
G#5    3        t #   d  ===    )
G#5    3        t     d  ===    (
A5     3        t     d  ]]]    )]
measure 26
*               DH      cre
P    C17:f33
A5    24        q     d         (
Bf5   24        q f   d         )
measure 27
*               J
*               DH      scen
P    C17:f33
A5    24        q     d         (
*     12        DJ      do
P    C17:f33
C6    24        q n   d         )
measure 28
C#6   12        e     d         f
rest   9        s.
C#6    3        t     d         mf
E6     3        t     d  [[[    (
C#6    3        t     d  ===
B5     3        t     d  ===
D6     3        t     d  ]]]    )
C#6    3        t     d  [[[    (
A5     3        t     d  ===
C#6    3        t     d  ===
B5     3        t     d  ]]]    )
measure 29
G#5    3        t #   d  [[[    (
B5     3        t     d  ===
A5     3        t     d  ===
F#5    3        t     d  ]]]    )
*     12        D       cresc.
P    C17:f33
A5     3        t     d  [[[    (
G#5    3        t     d  ===
E5     3        t     d  ===
G#5    3        t     d  ]]]    )
F#5    3        t     d  [[[    (
D5     3        t     d  ===
F#5    3        t     d  ===
E5     3        t     d  ]]]    )
C#5    3        t     d  [[[    (
E5     3        t     d  ===
D5     3        t     d  ===
B4     3        t     d  ]]]    )
measure 30
D5     3        t     d  [[[    (f
C#5    3        t     d  ===
A4     3        t     d  ===
C#5    3        t     d  ]]]    )
B4     3        t     u  [[[    (
G#4    3        t #   u  ===
B4     3        t     u  ===
A4     3        t     u  ]]]    )
F#4    3        t     u  [[[    (
A4     3        t     u  ===
G#4    3        t     u  ===
E4     3        t     u  ]]]    )
G#4    3        t     u  [[[    (
F#4    3        t     u  ===
D4     3        t     u  ===
F#4    3        t     u  ]]]    )
measure 31
E4     3        t     u  [[[    (
C#4    3        t     u  ===    )
A4     3        t     u  ===    (
C#4    3        t     u  ]]]    )
A4     3        t     u  [[[    (
D4     3        t     u  ===    )
A4     3        t     u  ===    (
D#4    3        t #   u  ]]]    )
A4     3        t     u  [[[    (
E4     3        t     u  ===    )
A4     3        t     u  ===    (
F4     3        t n   u  ]]]    )
A4     3        t     u  [[[    (
E4     3        t     u  ===    )
A4     3        t     u  ===    (
D#4    3        t     u  ]]]    )
measure 32
E4     3        t     d  [[[    (
A4     3        t     d  ===
C#5    3        t     d  ===
E5     3        t     d  ]]]
A5     3        t     d  [[[
C#6    3        t     d  ===    )
E6     3        t     d  ===    .
E6     3        t     d  ]]]    .
E6     3        t     d  [[[    .
E6     3        t     d  ===    .
E6     3        t     d  ===    .
E6     3        t     d  ]]]    .
E6     3        t     d  [[[    (
D#6    3        t #   d  ===
D6     3        t n   d  ===
C#6    3        t     d  ]]]    )
measure 33
*               GE  18  f
*     18        F   0
B5    48        h     d         t(
P  C34:u
gA5    5        s     u  [[
gB5    5        s     u  ]]      )
measure 34
*               GE  0   p
*     45        F   18
A5    48-       h     d        -
measure 35
*               E   18
A5    48-       h     d        -
P   C32:u
gA5    4        t     u  [[[
gB5    4        t     u  ===
gA5    4        t     u  ===
gB5    4        t     u  ===
gA5    4        t     u  ===
gB5    4        t     u  ===
gA5    4        t     u  ===
gB5    4        t     u  ]]]
*               F   0
measure 36
*               D       dim.
P    C17:f33
A5    24        q     d
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 37
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12-       e     d  ]     -
A5     6        s     d  [[
B5     3        t     d  ==[    (
A5     3        t     d  ]]]
G5     3        t     d  [[[
F#5    3        t     d  ===
E5     3        t     d  ===
D5     3        t     d  ]]]    )
measure 38
C#5    9        s.    d  [[     (
A4     3        t     d  ==\    )
D5     9        s.    d  ==     (
A4     3        t     d  ]]\    )
G5    12        e     d  [
gG5    0        e     u         (
F#5    3        t     d  =[[    )(
E5     3        t     d  ===
F#5    3        t     d  ===
G5     3        t     d  ]]]    )
measure 39
F#5   24        q     d         (
E5     6        s     d  [[     )
F#5    6        s     d  ==     (
G5     6        s     d  ==
G#5    6        s #   d  ]]     )
measure 40
A5    24        q     d
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 41
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12-       e     d  ]     -
*               E   0
A5     6        s     d  [[
B5     3        t     d  ==[    .(
C#6    3        t     d  ]]]    .
D6     3        t     d  [[[    .
E6     3        t     d  ===    .
F#6    3        t     d  ===    .
*               F   18
G6     3        t     d  ]]]    .)
measure 42
A6    12        e     d
rest   9        s.
F#6    3        t     d
D6    12        e     d  [
gF#6   0        e     u         (
E6     3        t     d  =[[    )(
D6     3        t     d  ===
E6     3        t     d  ===
F#6    3        t     d  ]]]     )
measure 43
*               D       cresc.
P    C17:f33
D6    24        q     d         (
Bf5   24        q f   d         )
measure 44
C#5   24        q #   d         (f+
D5    24        q     d         )
measure 45
E5    24        q     d         (
F5    12        e n   d  [      )
gG5    0        e     u         (
F5     3        t     d  =[[    )(
E5     3        t     d  ===
F5     3        t     d  ===
G5     3        t     d  ]]]     )
measure 46
E5    12        e     d  [      .
E5    12        e     d  ]      .
E5    12        e     d         .
rest  12        e
measure 47
*               D       dolce
P    C17:f33
F5    36        q.n   d         (
E5     6        s     d  [[
G5     6        s     d  ]]     )
measure 48
A5    24        q     d
G5    24-       q     d        -
measure 49
G5    12        e     d  [      (
A5    12        e     d  ]      )
gC6    0        e n   u         (
Bf5   12        e f   d  [      )(
A5    12        e     d  ]       )
measure 50
G5    12-       e     d  [     -
G5     2        t  3  d  =[[    *(
A5     2        t  3  d  ===
Bf5    2        t f3  d  ]]]    !
D6     2        t  3  d  [[[    *
Bf5    2        t  3  d  ===
G5     2        t  3  d  ]]]    !)
F5    12        e n   d  [      (
gA5    0        e     u
G5     9        s.    d  =[
F5     3        t     d  ]]\    )
measure 51
F5    24        q n   d
A5    24        q     d         (
measure 52
G5    24        q     d         )
F5    12        e n   d  [
gG5    0        e     u         (
F5     3        t     d  =[[    )(
E5     3        t     d  ===
F5     3        t     d  ===
G5     3        t     d  ]]]     )
measure 53
F5    24        q n   d         (
E5     6        s     d  [[     )
E5     6        s     d  ==     (
F#5    6        s #   d  ==
G5     6        s     d  ]]     )
measure 54
A5    24        q     d
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 55
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12-       e     d  ]     -(
A5     6        s     d  [[
B5     3        t     d  ==[     [
A5     3        t     d  ]]]
G5     3        t     d  [[[
F#5    3        t     d  ===
E5     3        t     d  ===
D5     3        t     d  ]]]    )]
measure 56
C#5    9        s.    d  [[     (
A4     3        t     d  ==\    )
D5     9        s.    d  ==     (
A4     3        t     d  ]]\    )
G5    12        e     d  [
gG5    0        e     u         (
F#5    3        t     d  =[[    )(
E5     3        t     d  ===
F#5    3        t     d  ===
G5     3        t     d  ]]]     )
measure 57
F#5   24        q     d         (
E5     6        s     d  [[     )
F#5    6        s     d  ==     (
G5     6        s     d  ==
G#5    6        s #   d  ]]     )
measure 58
A5    24        q     d
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 59
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12-       e     d  ]     -
A5     6        s     d  [[
B5     3        t     d  ==[    (.
C#6    3        t     d  ]]]     .
D6     3        t     d  [[[     .
E6     3        t     d  ===     .
F#6    3        t     d  ===     .
G6     3        t     d  ]]]    ).
measure 60
A6    12        e     d
rest  12        e
rest   6        s
*               E   0
D6     6        s     d  [[     (.
D6     6        s     d  ==      .
*               F   18
D6     6        s     d  ]]     ).
measure 61
D6    24        q     d          f
D6     3        t     d  [[[    (mf
C#6    3        t     d  ===
A5     3        t     d  ===
C#6    3        t     d  ]]]    )
B5     3        t     d  [[[    (
G5     3        t     d  ===
B5     3        t     d  ===
A5     3        t     d  ]]]    )
measure 62
F#5    3        t     d  [[[    (
A5     3        t     d  ===
G5     3        t     d  ===
E5     3        t     d  ]]]    )
G5     3        t     d  [[[    (
F#5    3        t     d  ===
D5     3        t     d  ===
F#5    3        t     d  ]]]    )
E5     3        t     d  [[[    (
C#5    3        t     d  ===
E5     3        t     d  ===
D5     3        t     d  ]]]    )
B4     3        t     d  [[[    (
D5     3        t     d  ===
C#5    3        t     d  ===
A4     3        t     d  ]]]    )
measure 63
B4     3        t     d  [[[    (
A4     3        t     d  ===
D5     3        t     d  ===
C#5    3        t     d  ]]]    )
B4     3        t     d  [[[    (
A4     3        t     d  ===
D5     3        t     d  ===
C#5    3        t     d  ]]]    )
F#5    3        t     d  [[[    (
E5     3        t     d  ===
G5     3        t     d  ===
F#5    3        t     d  ]]]    )
E5     3        t     d  [[[    (
D5     3        t     d  ===
G5     3        t     d  ===
F#5    3        t     d  ]]]    )
measure 64
E5     3        t     d  [[[    (
D5     3        t     d  ===
G5     3        t     d  ===
F#5    3        t     d  ]]]    )
B5     3        t     d  [[[    (
D5     3        t     d  ===
C#5    3        t     d  ===
D5     3        t     d  ]]]
C#5    3        t     d  [[[    ).
C5     3        t n   d  ===    (
B4     3        t     d  ===
C5     3        t     d  ]]]
*               DH      cre
P   C17:f33
B4     3        t     u  [[[    ).
Bf4    3        t f   u  ===    (
A4     3        t     u  ===
Bf4    3        t     u  ]]]
*               J
measure 65
*               DH      scen
P   C17:f33
A4     3        t     u  [[[    ).
G4     3        t     u  ===    (
F#4    3        t     u  ===
G4     3        t     u  ]]]
F#4    3        t     u  [[[    ).
D4     3        t     u  ===     .
C#4    3        t     u  ===     .
*               DJ      do
P   C17:f33
D4     3        t     u  ]]]     .
B3     3        t n   u  [[[    +.
D4     3        t     u  ===     .
A3     3        t     u  ===     .
D4     3        t     u  ]]]     .
G#3    3        t #   u  [[[     .
D4     3        t     u  ===     .
F#4    3        t     u  ===     .
D4     3        t     u  ]]]     .
measure 66
F#4    3        t     u  [[[     .f
C#4    3        t     u  ===     .
D4     3        t     u  ===     .
E4     3        t     u  ]]]     .
F#4    3        t     u  [[[     .
G4     3        t     u  ===     .
A4     3        t     u  ===     .
B4     3        t     u  ]]]     .
C#5    3        t     d  [[[     .
D5     3        t     d  ===     .
E5     3        t     d  ===     .
F#5    3        t     d  ]]]     .
G5     3        t     d  [[[     .
A5     3        t     d  ===     .
B5     3        t     d  ===     .
C#6    3        t     d  ]]]     .
measure 67
D6    12        e     d          .
rest  12        e
gD5    0        e     u         (
E5    24        q     d         )tF(
P    C36:u
gD5    5        s     u  [[
gE5    5        s     u  ]]        )
measure 68
D5    12        e     d
rest  12        e
*               D       dolce
P   C17:f33
B5    18        e.    d  [      (
C#6    3        t     d  =[[
D6     3        t     d  ]]]    )
measure 69
D6     6        s     d  [[     (
A5     6        s     d  =]     )
A5    12        e     d  ]
gA5    0        e     u         (
G5     3        t     d  [[[    )(
F#5    3        t     d  ===
G5     3        t     d  ===
B5     3        t     d  ]]]     )
A5     3        t     d  [[[     (
G5     3        t     d  ===
F#5    3        t     d  ===
G5     3        t     d  ]]]     )
measure 70
F#5   12        e     d
rest  12        e
B4    18        e.    d  [      (
C#5    3        t     d  =[[
D5     3        t     d  ]]]    )
measure 71
D5     9        s.    d  [[     (
A4     3        t     d  ==\    )
A4     9        s.    d  ==     (
D5     3        t     d  ]]\    )
C#5    3        t     d  [[[    (
D5     3        t     d  ===    )
E5     3        t     d  ===    .(
F#5    3        t     d  ]]]    .
G5     3        t     d  [[[    .
A5     3        t     d  ===    .
B5     3        t     d  ===    .
C#6    3        t     d  ]]]    .)
measure 72
D6    12        e     d
rest  12        e
G5    24        q     d  p      (
measure 73
F#5   12        e     d         )
rest  12        e
G4    24        q     u         pp(
measure 74
F#4   12        e     u  [      .)
D4    12        e     u  ]      .
D4    12        e     u
rest  12        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/02/02} [KHM:2170944275]
TIMESTAMP: DEC/26/2001 [md5sum:5601918462560c8083c3f741afa88e33]
09/16/94 W Hewlett
WK#:55,1      MV#:2
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Adagio cantabile [Second movemend]
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:16   T:2/4  C:4  D:Adagio cantabile
*               D       dolce
P    C17:f33
A4    16        q     u         p
B4    12        e.    d  [      (
C#5    2        t     d  =[[
D5     2        t     d  ]]]    )
measure 2
D5     4        s     d  [[     (
A4     4        s     d  =]     )
A4     8-       e     d  ]     -
A4     4        s     u  [[
B4     2        t     u  ==[    (
A4     2        t     u  ]]]
G4     2        t     u  [[[
F#4    2        t     u  ===
E4     2        t     u  ===
D4     2        t     u  ]]]    )
measure 3
C#4    6        s.    u  [[     (
A3     2        t     u  ==\    )
D4     6        s.    u  ==     (
A3     2        t     u  ]]\    )
G4     8        e     u  [
gG4    0        e     u         (
F#4    2        t     u  =[[    )(
E4     2        t     u  ===
F#4    2        t     u  ===
G4     2        t     u  ]]]     )
measure 4
F#4   16        q     u         (
E4     4        s     u  [[     )
F#4    4        s     u  ==     (
G4     4        s     u  ==
G#4    4        s #   u  ]]     )
measure 5
A4    16        q     u
B4    12        e.    d  [      (
C#5    2        t     d  =[[
D5     2        t     d  ]]]    )
measure 6
D5     4        s     d  [[     (
A4     4        s     d  =]     )
A4     8-       e     d  ]     -
*               E   0
A4     4        s     d  [[
B4     2        t     d  ==[    .(
C#5    2        t     d  ]]]    .
D5     2        t     d  [[[    .
E5     2        t     d  ===    .
F#5    2        t     d  ===    .
*               F   18
G5     2        t     d  ]]]    .)
measure 7
A5     8        e     d  [
rest   6        s.
F#5    2        t     d  ]\\
D5     8        e     d  [
gF#5   0        e     u         (
E5     2        t     d  =[[    )(
D5     2        t     d  ===
E5     2        t     d  ===
F#5    2        t     d  ]]]     )
measure 8
D5     4        s     d  [[     .
D5     4        s     d  ==     .
C#5    4        s     d  ==     .
B4     4        s     d  ]]     .
A4     4        s     u  [[     .
G4     4        s     u  ==     .
F#4    4        s     u  ==     .
E4     4        s     u  ]]     .
measure 9
D4     8        e     u  [      (
F#4    8        e     u  =      )
B3     8        e     u  =      (
G4     8        e     u  ]      )
measure 10
A3     8        e     u  [      (
F#4    8        e     u  =      )
D4     8        e     u  =      (
F#4    8        e     u  ]      )
measure 11
G4     8        e     u  [      (
F#4    8        e     u  ]      )
C#5    8        e     d  [
gE5    0        e     u         (
D5     2        t     d  =[[    )(
C#5    2        t     d  ===
D5     2        t     d  ===
E5     2        t     d  ]]]     )
measure 12
D5    16        q     d         (
C#5    8        e     d         )
rest   8        e
measure 13
D4     8        e     u  [      (
F#4    8        e     u  =      )
B3     8        e     u  =      (
G4     8        e     u  ]      )
measure 14
A3     8        e     u  [      (
F#4    8        e     u  ]      )
D4     8        e     u
rest   8        e
measure 15
rest  16        q
F#4    8        e     u  [
gA4    0        e               (
G4     2        t     u  =[[    )(
F#4    2        t     u  ===
G4     2        t     u  ===
A4     2        t     u  ]]]     )
measure 16
F#4    8        e     u
rest   8        e
G4     8        e     u  [
gA4    0        e     u         (
G4     2        t     u  =[[    )(
F#4    2        t     u  ===
G4     2        t     u  ===
A4     2        t     u  ]]]     )
measure 17
F#4   12        e.    u  [      (
G4     2        t     u  =[[
A4     2        t     u  ]]]    )
B4     6        s.    d  [[     (
C#5    2        t     d  ]]\
D5     2        t     d  [[[
C#5    2        t     d  ===
D5     2        t     d  ===
B4     2        t     d  ]]]    )
measure 18
A4     8        e     u
rest   8        e
rest  16        q
measure 19
A4     8        e     u  [
gB4    0        e     u         (
A4     2        t     u  =[[    )(
G#4    2        t #   u  ===
A4     2        t     u  ===
B4     2        t     u  ]]]     )
A4     8        e     u
rest   8        e
measure 20
D5     4        s     d  [/
B5     8        e     d  =      f
A5     8        e     d  =      f
F#5    8        e     d  =      f
C#5    4-       s     d  ]\    -f
measure 21
C#5    4        s     d  [/
D5     8        e     d  =      f
C#5    4        s     d  ]\
*               E   18
D5     4        s     d  [[     (
C#5    4        s     d  ==
D5     4        s     d  ==
*               F   0
F#5    4        s     d  ]]     )
measure 22
B4     8        e     d  [
rest   4        s
E5     4        s     d  ]\     (.
D5     4        s n   d  [[      .+
D5     4        s     d  ==      .
D5     4        s     d  ==      .
D5     4        s     d  ]]     ).
measure 23
C#5    8        e     d  [
A4     4        s     d  =[     (
C#5    4        s     d  ]]     )
A4     4        s     d  [[     (
D5     4        s     d  ==     )
A4     4        s     d  ==     (
D5     4        s     d  ]]     )
measure 24
A4     4        s     d  [[     (
C#5    4        s     d  ==     )
A4     4        s     d  ==     (
C#5    4        s     d  ]]     )
A4     4        s     d  [[     (
C#5    4        s     d  ==     )
A4     4        s     d  ==     (
D5     4        s     d  ]]     )
measure 25
A4     4        s     d  [[     (
C#5    4        s     d  ==     )
A4     4        s     d  ==     (
C#5    4        s     d  ]]     )
A4     4        s     d  [[     (
C#5    4        s     d  ==     )
A4     4        s     d  ==     (
D5     4        s     d  ]]     )
measure 26
*               DH      cre
P    C17:f33
C#5    4        s     d  [[
E5     4        s     d  ==
E5     4        s     d  ==
E5     4        s     d  ]]
E5     4        s     d  [[
E5     4        s     d  ==
C#5    4        s     d  ==
C#5    4        s     d  ]]
measure 27
*               J
*               DH      scen
P    C17:f33
D5     4        s     d  [[
D5     4        s     d  ==
D5     4        s     d  ==
D5     4        s     d  ]]
D#5    4        s #   d  [[
D#5    4        s     d  ==
*               DJ      do
P    C17:f33
D#5    4        s     d  ==
D#5    4        s     d  ]]
measure 28
E5    16        q     d         f
rest  16        q
measure 29
rest  32
measure 30
D5     2        t     d  [[[    (f
C#5    2        t     d  ===
A4     2        t     d  ===
C#5    2        t     d  ]]]    )
B4     2        t     u  [[[    (
G#4    2        t #   u  ===
B4     2        t     u  ===
A4     2        t     u  ]]]    )
F#4    2        t     u  [[[    (
A4     2        t     u  ===
G#4    2        t     u  ===
E4     2        t     u  ]]]    )
G#4    2        t     u  [[[    (
F#4    2        t     u  ===
D4     2        t     u  ===
F#4    2        t     u  ]]]    )
measure 31
E4     2        t     u  [[[    (
C#4    2        t     u  ===    )
A4     2        t     u  ===    (
C#4    2        t     u  ]]]    )
A4     2        t     u  [[[    (
D4     2        t     u  ===    )
A4     2        t     u  ===    (
D#4    2        t #   u  ]]]    )
A4     2        t     u  [[[    (
E4     2        t     u  ===    )
A4     2        t     u  ===    (
F4     2        t n   u  ]]]    )
A4     2        t     u  [[[    (
E4     2        t     u  ===    )
A4     2        t     u  ===    (
D#4    2        t     u  ]]]    )
measure 32
E4     2        t     d  [[[    (
A4     2        t     d  ===
C#5    2        t     d  ===
E5     2        t     d  ]]]    )
rest   8        e
rest  16        q
measure 33
D4     8        e     u
rest   8        e
D5    16        q     d         >(
measure 34
C#5    4        s     d  [[     p)
A4     4        s     d  ]]
gC#5   0        e     u         (
B4     2        t     d  [[[    )(
A4     2        t     d  ===
B4     2        t     d  ===
D5     2        t     d  ]]]     )
*               E   0
C#5    4        s     d  [[
C#5    4        s     d  ]]
gE5    0        e     u         (
D5     2        t     d  [[[    )(
C#5    2        t     d  ===
D5     2        t     d  ===
F#5    2        t     d  ]]]     )
measure 35
E5     4        s     d  [[
E5     4        s     d  ]]
gG5    0        e n   u         (+
F#5    2        t     d  [[[    )(
E5     2        t     d  ===
F#5    2        t     d  ===
*               F   18
A5     2        t     d  ]]]     )
*               E   18
G5    16        q     d
*               F   0
measure 36
D4     4        s     u  [[     (p
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
G4     4        s     u  ==
D4     4        s     u  ==
G4     4        s     u  ]]     )
measure 37
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
measure 38
A3     4        s     u  [[     (
G4     4        s     u  ==
A3     4        s     u  ==
F#4    4        s     u  ]]     )
E4     4        s     d  [[
C#5    4        s     d  ]]
gE5    0        e     u         (
D5     2        t     d  [[[    )(
C#5    2        t     d  ===
D5     2        t     d  ===
E5     2        t     d  ]]]     )
measure 39
D5    16        q     d         (
C#5    8        e     d         )
rest   8        e
measure 40
F#4    8        e     u
 A3    8        e     u
rest   8        e
rest  16        q
measure 41
rest  32
measure 42
rest  16        q
F#4    8        e     u  [
gA4    0        e     u         (
G4     2        t     u  =[[    )(
F#4    2        t     u  ===
G4     2        t     u  ===
A4     2        t     u  ]]]     )
measure 43
*               D       cresc.
P  C17:f33
D4     4        s     u  [[     (
F4     4        s n   u  ==     )
D4     4        s     u  ==     (
F4     4        s     u  ]]     )
D4     4        s     u  [[     (
G4     4        s     u  ==     )
D4     4        s     u  ==     (
G4     4        s     u  ]]     )
measure 44
E4     4        s     u  [[     (f
G4     4        s     u  ==     )
E4     4        s     u  ==     (
G4     4        s     u  ]]     )
F4     4        s n   u  [[     (
A4     4        s     u  ==     )
D4     4        s     u  ==     (
F4     4        s     u  ]]     )
measure 45
A4    16        q     u         (
G#4   16        q #   u         )
measure 46
A4     4        s     d  [[     (
C#5    4        s     d  ==
E5     4        s     d  ==
C#5    4        s     d  ]]     )
A4     8        e     u
rest   8        e
measure 47
rest  16        q
G4    16-       q n   u        -p+
measure 48
G4     8        e     d  [
F4     4        s n   d  =[     (
F5     4        s n   d  ]]     )
F5    16        q     d         (
measure 49
E5     8        e     d  [      )(
F5     8        e n   d  =       )
gA5    0        e     u         (
G5     8        e     d  =      )(
F5     8        e     d  ]       )
measure 50
D5    12        e.    d  [      (
Bf4    4        s f   d  ]\     )
A4     8        e     u  [      (
gC5    0        e n   u
Bf4    6        s.    u  =[
A4     2        t     u  ]]\    )
measure 51
A4    16        q     u
F5    16-       q n   d        -
measure 52
F5     8        e     d
E5    16        q     d
gE5    0        e     u         (
D5     2        t     d  [[[    )(
C#5    2        t #   d  ===     +
D5     2        t     d  ===
E5     2        t     d  ]]]     )
measure 53
D5    16        q     d         (
C#5    4        s     d  [[     )
C#5    4        s     d  ==     (
D5     4        s     d  ==
E5     4        s     d  ]]     )
measure 54
D5     4        s     u  [[     (
F#4    4        s #   u  ==     +
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
G4     4        s     u  ==
D4     4        s     u  ==
G4     4        s     u  ]]     )
measure 55
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
measure 56
A3     4        s     u  [[     (
G4     4        s     u  ==
A3     4        s     u  ==
F#4    4        s     u  ]]     )
E4     8        e     u  [
gE4    0        e     u         (
D4     2        t     u  =[[    )(
C#4    2        t     u  ===
D4     2        t     u  ===
E4     2        t     u  ]]]     )
measure 57
D4    16        q     u         (
C#4    8        e     u         )
rest   8        e
measure 58
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
G4     4        s     u  ==
D4     4        s     u  ==
G4     4        s     u  ]]     )
measure 59
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     8        e     u
rest   8        e
measure 60
rest   2        t
F#4    2        t     d  [[[    .(
G4     2        t     d  ===    .
A4     2        t     d  ]]]    .
B4     2        t     d  [[[    .
C#5    2        t     d  ===    .
D5     2        t     d  ===    .
E5     2        t     d  ]]]    .
F#5    4        s     d  [[     .)
*               E   0
F#5    4        s     d  ==     .(
F#5    4        s     d  ==     .
*               F   18
F#5    4        s     d  ]]     .)
measure 61
F#5   16        q     d         f
rest  16        q
measure 62
D4     2        t     u  [[[    (
D#4    2        t #   u  ===
E4     2        t     u  ===
G4     2        t     u  ]]]    )
C#4    2        t     u  [[[    (
D4     2        t n   u  ===
F#4    2        t     u  ===
B3     2        t     u  ]]]    )
C#4    2        t     u  [[[    (
E4     2        t     u  ===
A#3    2        t #   u  ===
B3     2        t     u  ]]]    )
D4     2        t     u  [[[    (
G#3    2        t #   u  ===
A3     2        t n   u  ===
C#4    2        t     u  ]]]    )
measure 63
F#4    2        t     u  [[[    (
E4     2        t     u  ===
G#4    2        t #   u  ===
A4     2        t     u  ]]]    )
F#4    2        t     u  [[[    (
E4     2        t     u  ===
G#4    2        t     u  ===
A4     2        t     u  ]]]    )
G#4    2        t     d  [[[    (
A4     2        t     d  ===
C#5    2        t     d  ===
D5     2        t     d  ]]]    )
B4     2        t     d  [[[    (
A4     2        t     d  ===
C#5    2        t     d  ===
D5     2        t     d  ]]]    )
measure 64
B4     2        t     d  [[[    (
A4     2        t     d  ===
C#5    2        t     d  ===
D5     2        t     d  ]]]    )
D4     2        t     u  [[[    (
B4     2        t     u  ===
A4     2        t     u  ===
B4     2        t     u  ]]]
A4     2        t     u  [[[    ).
A4     2        t     u  ===    (
G4     2        t     u  ===
A4     2        t     u  ]]]
*               DH      cre
P   C17:f33
G4     2        t     u  [[[    ).
G4     2        t     u  ===    (
F#4    2        t     u  ===
G4     2        t     u  ]]]
*               J
measure 65
*               DH      scen
P   C17:f33
F#4    2        t     u  [[[    ).
E4     2        t     u  ===    (
D4     2        t     u  ===
E4     2        t     u  ]]]
D4     2        t     u  [[[    ).
D4     2        t     u  ===    .
C#4    2        t     u  ===    .
*               DJ      do
P   C17:f33
D4     2        t     u  ]]]    .
B3     2        t     u  [[[    .
D4     2        t     u  ===    .
A3     2        t     u  ===    .
D4     2        t     u  ]]]    .
G#3    2        t #   u  [[[    .
D4     2        t     u  ===    .
F#4    2        t     u  ===    .
D4     2        t     u  ]]]    .
measure 66
D4     2        t     u  [[[    .f
G3     2        t n   u  ===    .+
A3     2        t     u  ===    .
B3     2        t     u  ]]]    .
C#4    2        t     u  [[[    .
D4     2        t     u  ===    .
E4     2        t     u  ===    .
F#4    2        t     u  ]]]    .
G4     2        t     u  [[[    .
A4     2        t     u  ===    .
B4     2        t     u  ===    .
C#5    2        t     u  ]]]    .
D5     2        t     d  [[[    .
E5     2        t     d  ===    .
F#5    2        t     d  ===    .
G5     2        t     d  ]]]    .
measure 67
A5     8        e     d
rest   8        e
gB4    0        e     u         (
C#5   16        q     d         )tF(
P    C36:u
gB4    5        s     u  [[
gC#5   5        s     u  ]]        )
measure 68
D5     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
D4     4        s     u  [[     (
G4     4        s     u  ==
D4     4        s     u  ==
G4     4        s     u  ]]     )
measure 69
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
E4    16        q     u         (
measure 70
D4     4        s     u  [[     )(
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]      )
D4     4        s     u  [[     (
G4     4        s     u  ==
D4     4        s     u  ==
G4     4        s     u  ]]     )
measure 71
D4     4        s     u  [[     (
F#4    4        s     u  ==
D4     4        s     u  ==
F#4    4        s     u  ]]     )
G4    16        q     u         (
measure 72
F#4    8        e     u         )
rest   8        e
C#4    2        t     u  [[[    .(
D4     2        t     u  ===    .)
E4     2        t     u  ===    .(
F#4    2        t     u  ]]]    .
G4     2        t     u  [[[    .
A4     2        t     u  ===    .
B4     2        t     u  ===    .
C#5    2        t     u  ]]]    .)
measure 73
D5     8        e     d
rest   8        e
C#4   12        e.    u  [      (pp
E4     4        s     u  ]\     )
measure 74
D4     8        e     u  [      .
A3     8        e     u  ]      .
A3     8        e     u
rest   8        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/02/03} [KHM:2170944275]
TIMESTAMP: DEC/26/2001 [md5sum:fbf084ecff29320be6b3195e6dd91efb]
09/16/94 W Hewlett
WK#:55,1      MV#:2
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Adagio cantabile [Second movement]
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:48   T:2/4  C:13  D:Adagio cantabile
D3    24        e     u  [      (p
F#4   24        e     u  ]      )
D4    24        e     d  [      (
G4    24        e     d  ]      )
measure 2
D4    24        e     d  [      (
F#4   24        e     d  ]      )
D4    24        e     d
rest  24        e
measure 3
G3    24        e     u  [      (
F#3   24        e     u  ]      )
C#4   24        e     d  [
gE4    0        e     u         (
D4     6        t     d  =[[    )(
C#4    6        t     d  ===
D4     6        t     d  ===
E4     6        t     d  ]]]     )
measure 4
D4    48        q     d         (
C#4   24        e     d         )
rest  24        e
measure 5
D3    24        e     u  [      (
F#4   24        e     u  ]      )
D4    24        e     d  [      (
G4    24        e     d  ]      )
measure 6
D4    24        e     d  [      (
F#4   24        e     d  ]      )
D4    24        e     d         .
rest  24        e
measure 7
rest  48        q
F#4   24        e     d  [
gA4    0        e     u         (
G4     6        t     d  =[[    )(
F#4    6        t     d  ===
G4     6        t     d  ===
A4     6        t     d  ]]]     )
measure 8
F#4   12        s     d  [[     .
B4    12        s     d  ==     .
A4    12        s     d  ==     .
G4    12        s     d  ]]     .
F#4   12        s     d  [[     .
B3    12        s     d  ==     .
A3    12        s     d  ==     .
G3    12        s     d  ]]     .
measure 9
F#3   24        e     u  [      (
D3    24        e     u  ]      )
G3    24        e     u  [      (
D3    24        e     u  ]      )
measure 10
F#3   24        e     u  [      (
D3    24        e     u  ]      )
F#3   24        e     u  [      (
D3    24        e     u  ]      )
measure 11
E3    24        e     u  [      (
D3    24        e     u  ]      )
E4    24        e     d  [      (
D4    24        e     d  ]      )
measure 12
A3    24        e     u
rest  24        e
rest  48        q
measure 13
F#3   24        e     u  [      (
D3    24        e     u  ]      )
G3    24        e     u  [      (
D3    24        e     u  ]      )
measure 14
F#3   24        e     u  [      (
D3    24        e     u  ]      )
F#3   24        e     u
rest  24        e
measure 15
rest  48        q
D4    24        e     d  [      (
C#4   24        e     d  ]      )
measure 16
D4    24        e     d
rest  24        e
B3    24        e     u  [      (
C#4   24        e     u  ]      )
measure 17
D4    24        e     d
rest  24        e
G4    18        s.    d  [[     (
A4     6        t     d  ]]\
B4     6        t     d  [[[
A4     6        t     d  ===
B4     6        t     d  ===
G4     6        t     d  ]]]    )
measure 18
F#4   24        e     d
rest  24        e
F#4   12        s     d  [[
F#4   12        s     d  ==
F#4   12        s     d  ==
F#4   12        s     d  ]]
measure 19
E4    12        s     d  [[
E4    12        s     d  ==
E4    12        s     d  ==
E4    12        s     d  ]]
E4    12        s     d  [[
E4    12        s     d  ==
E4    12        s     d  ==
E4    12        s     d  ]]
measure 20
D4    12        s     d  [/
E4    24        e     d  =      f
E4    24        e     d  =      f
F#4   24        e     d  =      f
G4    12-       s n   d  ]\    -f+
measure 21
G4    12        s     d  [/
F#4   24        e     d  =      f
G4    12        s     d  ]\
*               E   18
F#4   12        s     d  [[     (
G4    12        s     d  ==
F#4   12        s     d  ==     )
*               F   0
F#4   12        s     d  ]]
measure 22
E4    24        e     d
rest  24        e
rest  48        q
measure 23
C#4   12        s     u  [[     (p
A3    12        s     u  ==     )
C#4   12        s     u  ==     (
A3    12        s     u  ]]     )
D4    12        s     u  [[     (
A3    12        s     u  ==     )
D4    12        s     u  ==     (
A3    12        s     u  ]]     )
measure 24
C#4   12        s     u  [[     (
A3    12        s     u  ==     )
C#4   12        s     u  ==     (
A3    12        s     u  ]]     )
C#4   12        s     u  [[     (
A3    12        s     u  ==     )
D4    12        s     u  ==     (
A3    12        s     u  ]]     )
measure 25
C#4   12        s     u  [[     (
A3    12        s     u  ==     )
C#4   12        s     u  ==     (
A3    12        s     u  ]]     )
C#4   12        s     u  [[     (
A3    12        s     u  ==     )
D4    12        s     u  ==     (
A3    12        s     u  ]]     )
measure 26
*               DH      cre
P    C17:f33
A4    12        s     d  [[
C#5   12        s     d  ==
C#5   12        s     d  ==
C#5   12        s     d  ]]
C#5   12        s     d  [[
C#5   12        s     d  ==
E5    12        s     d  ==
E5    12        s     d  ]]
measure 27
*               J
*               DH      scen
P    C17:f33
A4    12        s     d  [[
A4    12        s     d  ==
A4    12        s     d  ==
A4    12        s     d  ]]
A4    12        s     d  [[
A4    12        s     d  ==
*               DJ      do
P    C17:f33
A4    12        s     d  ==
A4    12        s     d  ]]
measure 28
A4    48        q     d         f
rest  48        q
measure 29
rest  96
measure 30
D5     6        t     d  [[[    (
C#5    6        t     d  ===
A4     6        t     d  ===
C#5    6        t     d  ]]]    )
B4     6        t     d  [[[    (
G#4    6        t #   d  ===
B4     6        t     d  ===
A4     6        t     d  ]]]    )
F#4    6        t     d  [[[    (
A4     6        t     d  ===
G#4    6        t     d  ===
E4     6        t     d  ]]]    )
G#4    6        t     d  [[[    (
F#4    6        t     d  ===
D4     6        t     d  ===
F#4    6        t     d  ]]]    )
measure 31
E4     6        t     d  [[[    (
C#4    6        t     d  ===    )
A4     6        t     d  ===    (
C#4    6        t     d  ]]]    )
A4     6        t     d  [[[    (
D4     6        t     d  ===    )
A4     6        t     d  ===    (
D#4    6        t #   d  ]]]    )
A4     6        t     d  [[[    (
E4     6        t     d  ===    )
A4     6        t     d  ===    (
F4     6        t n   d  ]]]    )
A4     6        t     d  [[[    (
E4     6        t     d  ===    )
A4     6        t     d  ===    (
D#4    6        t     d  ]]]    )
measure 32
E4     6        t     d  [[[    (
A4     6        t     d  ===
C#5    6        t     d  ===
E5     6        t     d  ]]]    )
rest  24        e
rest  48        q
measure 33
G#3   24        e #   u
rest  24        e
G#4   48        q #   d         (>
measure 34
A4    24        e     d         )p
rest  24        e
*               GE  0   p
A3    12        s     u  [[
A3    12        s     u  ]]
gC#4   0        e     u         (
B3     6        t     u  [[[    )(
A3     6        t     u  ===
B3     6        t     u  ===
D4     6        t     u  ]]]     )
measure 35
C#4   12        s     d  [[
C#4   12        s     d  ]]
gE4    0        e     u         (
D4     6        t     d  [[[    )(
C#4    6        t     d  ===
D4     6        t     d  ===
*               F   18
F#4    6        t     d  ]]]     )
*               E   18
E4    48        q     d
*               F   0
measure 36
F#3   12        s     u  [[     (p
D3    12        s     u  ==     )
F#3   12        s     u  ==     (
D3    12        s     u  ]]     )
G3    12        s     u  [[     (
D3    12        s     u  ==     )
G3    12        s     u  ==     (
D3    12        s     u  ]]     )
measure 37
F#3   12        s     u  [[     (
D3    12        s     u  ==     )
F#3   12        s     u  ==     (
D3    12        s     u  ]]     )
F#3   12        s     u  [[     (
D3    12        s     u  ==     )
F#3   12        s     u  ==     (
F#4   12        s     u  ]]     )
measure 38
G4    12        s     d  [[     (
A3    12        s     d  ==     )
F#4   12        s     d  ==     (
A3    12        s     d  ]]     )
C#4   12        s     u  [[     (
A3    12        s     u  ==     )
D4    12        s     u  ==     (
A3    12        s     u  ]]     )
measure 39
A4    12        s     d  [[     (
A3    12        s     d  ]]     )
A4     6        t     d  [[[    (
G#4    6        t #   d  ===
B4     6        t     d  ===
G#4    6        t     d  ]]]    )
A4    24        e     d
rest  24        e
measure 40
D4    24        e     d
rest  24        e
rest  48        q
measure 41
rest  96
measure 42
rest  48        q
D4    24        e     d  [      (
C#4   24        e     d  ]      )
measure 43
*               D       cresc.
P  C17:f33
A3    48        q     u         (
Bf3   48        q f   u         )
measure 44
G4    12        s     d  [[     (f
E4    12        s     d  ==     )
G4    12        s     d  ==     (
E4    12        s     d  ]]     )
D4    12        s     d  [[     (
F4    12        s n   d  ==     )
A4    12        s     d  ==     (.
A4    12        s     d  ]]     ).
measure 45
A4    48        q     d         (
D5    24        e     d  [      )
gE5    0        e     u         (
D5     6        t     d  =[[    )(
C#5    6        t     d  ===
D5     6        t     d  ===
E5     6        t     d  ]]]     )
measure 46
C#5   24        e     d  [      .
C#5   24        e     d  ]      .
C#5   24        e     d         .
rest  24        e
measure 47
F4    12        s n   d  [[     (
C#4   12        s     d  ==     )
D4    12        s     d  ==     (
A3    12        s     d  ]]     )
Bf3   12        s f   u  [[     (
G3    12        s     u  ==     )
C4    12        s n   u  ==     (
Bf3   12        s     u  ]]     )
measure 48
A3    48        q     u
D4    48        q     d
measure 49
Bf3   24        e f   u  [      (
A3    24        e     u  =      )
E3    24        e     u  =      (
F3    24        e n   u  ]      )
measure 50
D4    48        q     d
C4    24        e n   d  [      (
E4    24        e     d  ]      )
measure 51
F4    48        q n   d
rest  12        s
E3    12        s     u  [[     (
F3    12        s n   u  ==
A3    12        s     u  ]]     )
measure 52
Bf3   12        s f   u  [[     (
B3    12        s n   u  ==
C4    12        s n   u  ==
C#4   12        s #   u  ]]     )
D4    12        s     d  [[     (
F4    12        s n   d  ==
G4    12        s     d  ==
G#4   12        s #   d  ]]     )
measure 53
A4    12        s     d  [[     (
Bf4   12        s f   d  ==
A4    12        s     d  ==
G#4   12        s #   d  ]]     )
A4    12        s     d  [[     (
G4    12        s n   d  ==
F#4   12        s #   d  ==      +
E4    12        s     d  ]]     )
measure 54
D4    48        q     d
rest  48        q
measure 55
rest  24        e
D3     4        t  6  u  [[[    *(
F#3    4        t  6  u  ===
A3     4        t  6  u  ===
D4     4        t  6  u  ===
F#4    4        t  6  u  ===
A4     4        t  6  u  ]]]    !)
D5    24        e     d
rest  24        e
measure 56
rest  96
measure 57
rest  96
measure 58
F#4   12        s     d  [[     (
D4    12        s     d  ==     )
F#4   12        s     d  ==     (
D4    12        s     d  ]]     )
G4    12        s     d  [[     (
D4    12        s     d  ==     )
G4    12        s     d  ==     (
D4    12        s     d  ]]     )
measure 59
F#4   12        s     d  [[     (
D4    12        s     d  ==     )
F#4   12        s     d  ==     (
D4    12        s     d  ]]     )
F#4   24        e     d
rest  24        e
measure 60
rest   6        t
D4     6        t     d  [[[    .(
E4     6        t     d  ===    .
F#4    6        t     d  ]]]    .
G4     6        t     d  [[[    .
A4     6        t     d  ===    .
B4     6        t     d  ===    .
C#5    6        t     d  ]]]    .
D5    12        s     d  [[     .)
*               E   0
D5    12        s     d  ==     .(
D5    12        s     d  ==     .
*               F   18
D5    12        s     d  ]]     .)
measure 61
D5    24        e     d         f
rest  24        e
rest  48        q
measure 62
rest  96
measure 63
D4     6        t     u  [[[    (mf
C#4    6        t     u  ===
B3     6        t     u  ===
A3     6        t     u  ]]]    )
D4     6        t     u  [[[    (
C#4    6        t     u  ===
B3     6        t     u  ===
A3     6        t     u  ]]]    )
D4     6        t     d  [[[    (
C#4    6        t     d  ===
E4     6        t     d  ===
D4     6        t     d  ]]]    )
G4     6        t     d  [[[    (
F#4    6        t     d  ===
E4     6        t     d  ===
D4     6        t     d  ]]]    )
measure 64
G4     6        t     d  [[[    (
F#4    6        t     d  ===
E4     6        t     d  ===
D4     6        t     d  ]]]    )
G4     6        t     d  [[[    (
F4     6        t n   d  ===
E4     6        t     d  ===
F4     6        t     d  ]]]
E4     6        t     d  [[[    ).
Ef4    6        t f   d  ===    (
D4     6        t     d  ===
Ef4    6        t     d  ]]]
*               DH      cre
P   C17:f33
D4     6        t     d  [[[    ).
C#4    6        t     d  ===    (
D4     6        t     d  ===
C#4    6        t     d  ]]]
*               J
measure 65
*               DH      scen
P   C17:f33
D4     6        t     u  [[[    ).
B3     6        t     u  ===    (
A3     6        t     u  ===
G3     6        t     u  ]]]    )
F#3    6        t     u  [[[    .
D4     6        t     u  ===    .
C#4    6        t     u  ===    .
*               DJ      do
P   C17:f33
D4     6        t     u  ]]]    .
B3     6        t     u  [[[    .
D4     6        t     u  ===    .
A3     6        t     u  ===    .
D4     6        t     u  ]]]    .
G#3    6        t #   u  [[[    .
D4     6        t     u  ===    .
F#4    6        t     u  ===    .
D4     6        t     u  ]]]    .
measure 66
A3     6        t     u  [[[    .f
E3     6        t     u  ===    .
F#3    6        t     u  ===    .
G3     6        t     u  ]]]    .
A3     6        t     u  [[[    .
B3     6        t     u  ===    .
C#4    6        t     u  ===    .
D4     6        t     u  ]]]    .
E4     6        t     d  [[[    .
F#4    6        t     d  ===    .
G4     6        t     d  ===    .
A4     6        t     d  ]]]    .
B4     6        t     d  [[[    .
C#5    6        t     d  ===    .
D5     6        t     d  ===    .
E5     6        t     d  ]]]    .
measure 67
F#5   24        e     d         .
rest  24        e
G4    48        q     d          tF(
P    C36:u
gF#4   5        s     u  [[
gG4    5        s     u  ]]        )
measure 68
F#4   12        s     u  [[     (p
D3    12        s     u  ==
F#3   12        s     u  ==
D3    12        s     u  ]]     )
G3    12        s     u  [[     (
D3    12        s     u  ==
G3    12        s     u  ==
D3    12        s     u  ]]     )
measure 69
F#3   12        s     u  [[     (
D3    12        s     u  ==
F#3   12        s     u  ==
D3    12        s     u  ]]     )
C#4   48        q     d         (
measure 70
D4    12        s     u  [[     )
D3    12        s     u  ==     (
F#3   12        s     u  ==
D3    12        s     u  ]]     )
G3    12        s     u  [[     (
D3    12        s     u  ==
G3    12        s     u  ==
D3    12        s     u  ]]     )
measure 71
F#3   12        s     u  [[     (
D3    12        s     u  ==
F#3   12        s     u  ==
D3    12        s     u  ]]     )
E4    48        q     d         (
measure 72
D4    24        e     d         )
rest  24        e
E3     6        t     u  [[[    (p
F#3    6        t     u  ===    )
G3     6        t     u  ===    .(
A3     6        t     u  ]]]    .
B3     6        t     d  [[[    .
C#4    6        t     d  ===    .
D4     6        t     d  ===    .
E4     6        t     d  ]]]    .)
measure 73
F#4   24        e     d
rest  24        e
E3     6        t     u  [[[    (pp
F#3    6        t     u  ===
G3     6        t     u  ===
G#3    6        t #   u  ]]]
A3     6        t     u  [[[
Bf3    6        t f   u  ===
B3     6        t n   u  ===
C4     3        x n   u  ===[
C#4    3        x #   u  ]]]]   )
measure 74
D4    24        e     u  [      .
F#3   24        e     u  ]      .
F#3   24        e     u
rest  24        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op55n1/stage2/02/04} [KHM:2170944275]
TIMESTAMP: DEC/26/2001 [md5sum:cd533529fdd43011fc5f72d3da13566e]
09/16/94 W Hewlett
WK#:55,1      MV#:2
T.Trautwein No.31, 779, Berlin; HV III:60
String Quartet Op. 55, No. 1, in A Major
Adagio cantabile [Second movement]
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:2   Q:48   T:2/4  C:22  D:Adagio cantabile
F#2   24        e     u  [      (p
D2    24        e     u  ]      )
G2    24        e     u  [      (
D2    24        e     u  ]      )
measure 2
F#2   24        e     u  [      (
D2    24        e     u  ]      )
F#2   24        e     u  [      (
D2    24        e     u  ]      )
measure 3
A2    96-       h     u        -
measure 4
A2    24        e     d  [
G#3   24        e #   d  ]      (
A3    24        e     d         )
rest  24        e
measure 5
F#2   24        e     u  [      (
D2    24        e     u  ]      )
G2    24        e     u  [      (
D2    24        e     u  ]      )
measure 6
F#2   24        e     u  [      (
D2    24        e     u  ]      )
F#2   24        e     u         .
rest  24        e
measure 7
rest  48        q
A2    24        e     u  [
A2    24        e     u  ]
measure 8
D2    48        q     u
rest  48        q
measure 9
D2    96-       h     u        -
measure 10
D2    96        h     u
measure 11
A2    96-       h     u        -
measure 12
A2    24        e     u
A3     6        t     d  [[[    (
G#3    6        t #   d  ===
B3     6        t     d  ===
G#3    6        t     d  ]]]    )
A3    24        e     d
rest  24        e
measure 13
D2    96-       h     u        -
measure 14
D2    48        q     u
rest  48        q
measure 15
rest  48        q
A2    24        e     u  [
A2    24        e     u  ]
measure 16
D3    12        s     d  [[
D3    12        s     d  ==
D3    12        s     d  ==
D3    12        s     d  ]]
D3    12        s     d  [[
D3    12        s     d  ==
D3    12        s     d  ==
D3    12        s     d  ]]
measure 17
D3    12        s     d  [[
D3    12        s     d  ==
D3    12        s     d  ==
D3    12        s     d  ]]
D3    12        s     d  [[
D3    12        s     d  ==
D3    12        s     d  ==
D3    12        s     d  ]]
measure 18
D3    12        s     d  [[
D3    12        s     d  ==
D3    12        s     d  ==
D3    12        s     d  ]]
D4    12        s     d  [[
D4    12        s     d  ==
D4    12        s     d  ==
D4    12        s     d  ]]
measure 19
C#4   12        s     d  [[
C#4   12        s     d  ==
C#4   12        s     d  ==
C#4   12        s     d  ]]
C#4   12        s     d  [[
C#4   12        s     d  ==
C#4   12        s     d  ==
C#4   12        s     d  ]]
measure 20
B3    12        s     d  [/
G#3   24        e #   d  =      f
A3    24        e     d  =      f
D4    24        e     d  =      f
E4    12-       s     d  ]\    -f
measure 21
E4    12        s     d  [/
D4    24        e     d  =      f
E4    12        s     d  ]\
*               E   18
D4    12        s     d  [[     (
E4    12        s     d  ==
D4    12        s     d  ==
*               F   0
D#4   12        s #   d  ]]     )
measure 22
E4    36        e.    d  [      p
E4    12        s     d  ]\
F4    12        s n   d  [[     (
F#4   12        s #   d  ==
G4    12        s n   d  ==     +
G#4   12        s #   d  ]]     )
measure 23
A4    48        q     d
rest  48        q
measure 24
rest  24        e
A2     4        t  6  d  [[[    *(
C#3    4        t  6  d  ===
E3     4        t  6  d  ===
A3     4        t  6  d  ===
C#4    4        t  6  d  ===
E4     4        t  6  d  ]]]    !)
A4    24        e     d
rest  24        e
measure 25
rest  24        e
A2     4        t  6  d  [[[    *(
C#3    4        t  6  d  ===
E3     4        t  6  d  ===
A3     4        t  6  d  ===
C#4    4        t  6  d  ===
E4     4        t  6  d  ]]]    !)
A4    24        e     d
rest  24        e
measure 26
$    C:12
*               DH      cre
P    C17:f33
A4    12        s     d  [[
A4    12        s     d  ==
A4    12        s     d  ==
A4    12        s     d  ]]
G4    12        s n   d  [[     +
G4    12        s     d  ==
G4    12        s     d  ==
G4    12        s     d  ]]
measure 27
*               J
*               DH      scen
P    C17:f33
F#4   12        s     d  [[
F#4   12        s     d  ==
F#4   12        s     d  ==
F#4   12        s     d  ]]
F4    12        s n   d  [[
F4    12        s     d  ==
*               DJ      do
P    C17:f33
F4    12        s     d  ==
F4    12        s     d  ]]
measure 28
E4    48        q     d         f
rest  48        q
measure 29
rest  96
$    C:22
measure 30
D4     6        t     d  [[[    (
C#4    6        t     d  ===
A3     6        t     d  ===
C#4    6        t     d  ]]]    )
B3     6        t     d  [[[    (
G#3    6        t #   d  ===
B3     6        t     d  ===
A3     6        t     d  ]]]    )
F#3    6        t     d  [[[    (
A3     6        t     d  ===
G#3    6        t     d  ===
E3     6        t     d  ]]]    )
G#3    6        t     d  [[[    (
F#3    6        t     d  ===
D3     6        t     d  ===
F#3    6        t     d  ]]]    )
measure 31
E3     6        t     d  [[[    (
C#3    6        t     d  ===    )
A3     6        t     d  ===    (
C#3    6        t     d  ]]]    )
A3     6        t     d  [[[    (
D3     6        t     d  ===    )
A3     6        t     d  ===    (
D#3    6        t #   d  ]]]    )
A3     6        t     d  [[[    (
E3     6        t     d  ===    )
A3     6        t     d  ===    (
F3     6        t n   d  ]]]    )
A3     6        t     d  [[[    (
E3     6        t     d  ===    )
A3     6        t     d  ===    (
D#3    6        t     d  ]]]    )
measure 32
E3     6        t     d  [[[    (
A3     6        t     d  ===
C#4    6        t     d  ===
E4     6        t     d  ]]]    )
rest  24        e
rest  48        q
measure 33
E3    24        e     d
rest  24        e
E4    48        q     d         (>
measure 34
A3    48        q     d         )p
rest  48        q
measure 35
rest  48        q
rest   6        t
*               E   18
C#2    6        t     u  [[[    .
E2     6        t     u  ===    .
A2     6        t     u  ]]]    .
C#3    6        t     d  [[[    .
E3     6        t     d  ===    .
A3     6        t     d  ===    .
*               F   0
C#4    6        t     d  ]]]    .
measure 36
D4    48        q     d         p
rest  48        q
measure 37
D2    48        q     u
rest  48        q
measure 38
A2    48        q     u
rest  48        q
measure 39
A2    48        q     u
rest  48        q
measure 40
D2     6        t     u  [[[    .
F#2    6        t     u  ===    .
A2     6        t     u  ===    .
D3     6        t     u  ]]]    .
F#3    6        t     d  [[[    .
A3     6        t     d  ===    .
D4     6        t     d  ===    .
F#4    6        t     d  ]]]    .
G4    12        s     d  [[     (
D4    12        s     d  ==
G4    12        s     d  ==
D4    12        s     d  ]]     )
measure 41
F#4   12        s     d  [[     (
D4    12        s     d  ==
F#4   12        s     d  ==
D4    12        s     d  ]]     )
F#4   24        e     d
rest  24        e
measure 42
rest  48        q
A3    24        e     d  [
A2    24        e     d  ]
measure 43
F2    12        s n   u  [[     (
D2    12        s     u  ==     )
F2    12        s     u  ==     (
D2    12        s     u  ]]     )
G2    12        s     u  [[     (
D2    12        s     u  ==     )
G2    12        s     u  ==     (
D2    12        s     u  ]]     )
measure 44
Bf2   12        s f   u  [[     (f
D2    12        s     u  ==     )
Bf2   12        s     u  ==     (
D2    12        s     u  ]]     )
A2    12        s     u  [[     (
D2    12        s     u  ==     )
F2    12        s n   u  ==     (
D3    12        s     u  ]]     )
measure 45
C#3   12        s     u  [[     (
A2    12        s     u  ==     )
C#3   12        s     u  ==     (
A2    12        s     u  ]]     )
D3    12        s     u  [[     (
A2    12        s     u  ==     )
D3    12        s     u  ==     (
A2    12        s     u  ]]     )
measure 46
A3    12        s     d  [[     (
A2    12        s     d  ==
C#3   12        s     d  ==
E3    12        s     d  ]]     )
*               D       dim.
P   C17:f33
A3    12        s     d  [[     (
Bf3   12        s f   d  ==
A3    12        s     d  ==
G3    12        s     d  ]]     )
measure 47
F3    48        q n   d         p
rest  48        q
measure 48
F3    12        s n   u  [[     (
C3    12        s n   u  ==
D3    12        s     u  ==
A2    12        s     u  ]]     )
Bf2   12        s f   u  [[     (
A2    12        s     u  ==
Bf2   12        s     u  ==
B2    12        s n   u  ]]     )
measure 49
C3    12        s n   u  [[     (
C2    12        s n   u  ==
C3    12        s     u  ==
C2    12        s     u  ]]     )
C#2   12        s #   u  [[     (
C#3   12        s #   u  ==
D2    12        s     u  ==
D3    12        s     u  ]]     )
measure 50
Bf2   12        s f   d  [[     (
D3    12        s     d  ==
G3    12        s     d  ==
Bf3   12        s f   d  ]]     )
C4    12        s n   d  [[     (
C3    12        s n   d  ==
C4    12        s     d  ==
C3    12        s     d  ]]     )
measure 51
F3    12        s n   u  [[     (
C3    12        s n   u  ==
A2    12        s     u  ==
F2    12        s n   u  ]]     )
rest  48        q
measure 52
rest  96
measure 53
rest  96
measure 54
F#2   12        s #   u  [[     (+
D2    12        s     u  ==
F#2   12        s     u  ==
D2    12        s     u  ]]     )
G2    12        s     u  [[     (
D2    12        s     u  ==
G2    12        s     u  ==
D2    12        s     u  ]]     )
measure 55
F#2   12        s     u  [[     (
D2    12        s     u  ==
F#2   12        s     u  ==
D2    12        s     u  ]]     )
F#2   12        s     u  [[     (
D2    12        s     u  ==
D3    12        s     u  ==
F#3   12        s     u  ]]     )
measure 56
G3    12        s     u  [[     (
A2    12        s     u  ==
F#3   12        s     u  ==
A2    12        s     u  ]]     )
C#3   12        s     u  [[     (
A2    12        s     u  ==
D3    12        s     u  ==
G#2   12        s #   u  ]]     )
measure 57
A2    12        s     d  [[     (
G#3   12        s #   d  ]]
A3     6        t     d  [[[
G#3    6        t     d  ===
B3     6        t     d  ===
G#3    6        t     d  ]]]    )
A3    24        e     d
rest  24        e
measure 58
rest  96
measure 59
D2     6        t     u  [[[    (
C#2    6        t     u  ===
D2     6        t     u  ===
C#2    6        t     u  ]]]
D2     6        t     u  [[[
C#2    6        t     u  ===
D2     6        t     u  ===
C#2    6        t     u  ]]]
D2    24        e     u         )
rest  24        e
measure 60
rest  48        q
rest   6        t
*               E   0
D3     6        t     u  [[[    (
C#3    6        t     u  ===
C3     6        t n   u  ]]]
B2     6        t     u  [[[
Bf2    6        t f   u  ===
A2     6        t     u  ===
*               F   18
G#2    6        t #   u  ]]]    )
measure 61
A2    48        q     u         f
rest  48        q
measure 62
rest  96
measure 63
rest  96
measure 64
rest  24        e
G3     6        t     d  [[[    (mf
G#3    6        t #   d  ===
A3     6        t     d  ===
G#3    6        t     d  ]]]
A3     6        t     d  [[[    ).
F#3    6        t     d  ===    (
G3     6        t n   d  ===
F#3    6        t     d  ]]]
G3     6        t     d  [[[    ).
E3     6        t     d  ===    (
F#3    6        t     d  ===
E3     6        t     d  ]]]
measure 65
F#3    6        t     u  [[[    ).
G2     6        t     u  ===    (
A2     6        t     u  ===
A#2    6        t #   u  ]]]
B2     6        t     u  [[[    ).
D3     6        t     u  ===    .
C#3    6        t     u  ===    .
D3     6        t     u  ]]]    .
B2     6        t     u  [[[    .
D3     6        t     u  ===    .
A2     6        t n   u  ===    .
D3     6        t     u  ]]]    .
G#2    6        t #   u  [[[    .
D3     6        t     u  ===    .
F#3    6        t     u  ===    .
D3     6        t     u  ]]]    .
measure 66
A2    48        q     u         f
rest  48        q
measure 67
rest  48        q
A2    48        q     u         F
measure 68
D2    48        q     u
rest  48        q
measure 69
*               D       dolce
P   C17:f33
D2     3        x     u  [[[[   (
C#2    3        x     u  ====
D2     3        x     u  ====
C#2    3        x     u  ]]]]
D2     3        x     u  [[[[
C#2    3        x     u  ====
D2     3        x     u  ====
C#2    3        x     u  ]]]]
D2    12        s     u  [[     )
D2    12        s     u  ]]
D2    12        s     u  [[
D2    12        s     u  ==
D2    12        s     u  ==
D2    12        s     u  ]]
measure 70
D2    24        e     u
rest  24        e
rest  48        q
measure 71
D2     3        x     u  [[[[   (
C#2    3        x     u  ====
D2     3        x     u  ====
C#2    3        x     u  ]]]]
D2     3        x     u  [[[[
C#2    3        x     u  ====
D2     3        x     u  ====
C#2    3        x     u  ]]]]
D2    12        s     u  [[     )
D2    12        s     u  ]]
D2    12        s     u  [[
D2    12        s     u  ==
D2    12        s     u  ==
D2    12        s     u  ]]
measure 72
D2    24        e     u
rest  24        e
A2    48        q     u         p(
measure 73
D2    24        e     u          )
rest  24        e
A2    48        q     u         pp(
measure 74
D2    24        e     u  [      . )
D2    24        e     u  ]      .
D2    24        e     u
rest  24        e
mheavy2
/END
/eof
//
