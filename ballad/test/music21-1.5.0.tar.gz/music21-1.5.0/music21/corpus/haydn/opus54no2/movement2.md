&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/02/01} [KHM:2870205300]
TIMESTAMP: DEC/26/2001 [md5sum:82795795f56efc8fad0527ac2b47e99d]
07/25/94 W Hewlett
WK#:54,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Adagio (Second movement)
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:24   T:3/4  C:4  D:Adagio
C4    24        q     u         p(
Ef4   24        q     u
D4    24        q     u          )
measure 2
C4    24        q     u         (
G4    24        q     u         t
S   C33:uhn18s7t95e
gF4    5        s     u  [[
gG4    5        s     u  ]]
Af4   24        q     u         )
measure 3
D4    24        q     u         (
G4    24        q     u
F4    24        q     u         )
measure 4
F4    24        q     u         (
Ef4   24        q     u         t
S   C33:uwn18s7t95f
gD4    5        s     u  [[
gEf4   5        s     u  ]]
D4    24        q     u         )
measure 5
Ef4   24        q     u         (
Af4   24        q     u
G4    24        q     u         )
measure 6
F#4   24        q #   u         (
G4    24        q     u
A4    24        q n   u         )
measure 7
Bf4   24        q     d         (
C5    24        q     d         )
A4    18        e.n   u  [      t(
S   C33:uhn10s12t91
G4     3        t     u  =[[
A4     3        t     u  ]]]     )
measure 8
G4    48        h     u
rest  24        q
measure 9
rest  24        q
rest  24        q
rest   3        t
G4     3        t     u  [[[    (
A4     3        t n   u  ===
B4     3        t n   u  ]]]
C5     3        t     d  [[[     .
D5     3        t     d  ===     .
Ef5    3        t     d  ===     .
F5     3        t     d  ]]]    ).
measure 10
*               E   0
G5    12        e     d  [      .(
G5    12        e     d  ]      .)
G5     4        s  6  d  [[     .(*
G5     4        s  6  d  ==     .
G5     4        s  6  d  ==     .
G5     4        s  6  d  ==     .
G5     4        s  6  d  ==     .
G5     4        s  6  d  ]]     .)!
*               FG  18  f
gG5    0        e     u         (
S   C1:t15
C6    12        e     d  [      )(
Bf5    3        t f   d  =[[    +
Af5    3        t f   d  ===    +
G5     3        t     d  ===
F5     3        t     d  ]]]     )
measure 11
Ef5    3        t     d  [[[    (
D5     3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  =]]
G5     3        t     d  =[[
F5     3        t     d  ===
Ef5    3        t     d  ===
D5     3        t     d  ]]]    )
*               D       dim.
P   C17:f33
C5     3        t     d  [[[
B4     3        t n   d  ===    (
D5     3        t     d  ===
C5     3        t     d  =]]
Ef5    3        t     d  =[[
D5     3        t     d  ===
C5     3        t     d  ===
B4     3        t     d  ]]]    )
A4     4        s n6  d  [[     (.
G4     4        s  6  d  ==      .
D5     4        s  6  d  =]      .
C5     4        s  6  d  =[      .
B4     4        s n6  d  ==     +.
Af4    4        s f6  d  ]]     ).
measure 12
G4     4        s  6  u  [[     (.*
Af4    4        s  6  u  ==      .
G4     4        s  6  u  ==      .
F4     4        s  6  u  ==      .
Ef4    4        s  6  u  ==      .
D4     4        s  6  u  ]]     ).!
*               E   0
C4     3        t     u  [[[    (
B3     3        t n   u  ===
C4     3        t     u  ===
*               F   12
D4     3        t     u  =]]
*               E   12
Ef4    3        t     u  =[[
F4     3        t     u  ===
G4     3        t     u  ===
*               F   0
A4     3        t n   u  ]]]    )
B4     3        t n   d  [[[    (
C5     3        t     d  ===
B4     3        t     d  ===
C5     3        t     d  =]]
B4    12        e     d  ]      )
measure 13
rest  72
measure 14
rest   3        t
Ef5    3        t     d  [[[    (
D5     3        t     d  ===
Ef5    3        t     d  =]]
D5     3        t     d  =[[
Ef5    3        t     d  ===
D5     3        t     d  ===
Ef5    3        t     d  ]]]    )
D5     3        t     d  [[[    (
Ef5    3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  =]]
D5     3        t     d  =[[
C5     3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  ]]]    )
D5     3        t     d  [[[    (
C5     3        t     d  ===
Bf5    3        t     d  ===
A5     3        t n   d  =]]
G5     3        t     d  =[[
F#5    3        t #   d  ===
Ef5    3        t f   d  ===    +
D5     3        t     d  ]]]    )
measure 15
C5     4        s  6  d  [[     .(*
Bf4    4        s  6  d  ==     .
Ef5    4        s  6  d  ==     .
D5     4        s  6  d  ==     .
C5     4        s  6  d  ==     .
Bf4    4        s  6  d  ]]     .)!
Ef5    4        s  6  d  [[     .(*
D5     4        s  6  d  ==     .
F5     4        s  6  d  ==     .
Ef5    4        s  6  d  ==     .
D5     4        s  6  d  ==     .
C5     4        s  6  d  ]]     .)!
Bf4    3        t     d  [[[    (
A4     3        t n   d  ===
G5     3        t     d  ===
F#5    3        t #   d  =]]
Ef5    3        t f   d  =[[      +
D5     3        t     d  ===
C5     3        t     d  ===    )
F#5    3-       t     d  ]]]   -(
measure 16
*               E   15
F#5    3        t     d  [[[
A5     3        t n   d  ===
F#5    3        t #   d  ===
G5     3        t     d  =]]
C#5    3        t #   d  =[[
D5     3        t     d  ===
A4     3        t n   d  ===
B4     3        t n   d  ]]]
F#4    3        t #   u  [[[
G4     3        t     u  ===
D4     3        t     u  ===
B3     3        t n   u  =]]
*               F   0
G3    12        e     u  ]      )
rest  24        q
measure 17
rest  24        q
rest  24        q
rest   4        s  3            p*
D4     4        s  3  u  [[     .
C5     4        s  3  u  ]]      !
Af4    4        s f3  u  [[     +*
F4     4        s n3  u  ==     +
D5     4-       s  3  u  ]]    - !
measure 18
D5     4        s  3  d  [[
F5     4        s n3  d  ==     (+
Ef5    4        s  3  d  ==     )
A4     4        s n3  d  ==     (
Bf4    4        s  3  d  ==     )
F#4    4        s #3  d  ]]     (
G4     4        s  3  d  [[     )*
Bf4    4        s  3  d  ==
D5     4        s  3  d  ]]      !
Ef5    6        s     d  [[     (.
Ef5    6        s     d  ]]     ).
Ef5    4        s  6  d  [[     .(*
Ef5    4        s  6  d  ==     .
Ef5    4        s  6  d  ==     .
Ef5    4        s  6  d  ==     .
Ef5    4        s  6  d  ==     .
Ef5    4        s  6  d  ]]     .)!
measure 19
F5     6        s     d  [[     (
E5     6        s n   d  ==
G5     6        s     d  ==
Bf5    6        s     d  ]]
Df6    6        s f   d  [/     )
Df6   12        e     d  =
Df6    6-       s     d  ]\    -(
Df6    4        s  6  d  [[      *
C6     4        s  6  d  ==     )
G5     4        s  6  d  ==     (
Af5    4        s  6  d  ==
E5     4        s n6  d  ==     +
F5     4-       s  6  d  ]]    -)!
measure 20
*               D       dim.
P   C17:f33
F5     6        s     d  [/
F5    12        e     d  =
F5     6-       s     d  ]\    -(
F5     3        t     d  [[[
G5     3        t     d  ===
Bf5    3        t     d  ===
Df6    3        t f   d  =]]
C6     3        t     d  =[[
Bf5    3        t     d  ===
Af5    3        t     d  ===
G5     3        t     d  ]]]    )
F5     3        t     d  [[[    (
E5     3        t n   d  ===
G5     3        t     d  ===
F5     3        t     d  =]]
E5     3        t     d  =[[
Df5    3        t f   d  ===
C5     3        t     d  ===
Bf4    3        t     d  ]]]    )
measure 21
Bf4    3        t     u  [[[    (p
C5     3        t     u  ===
G4     3        t     u  ===
Bf4    3        t     u  =]]    )
*               D       cresc.
P   C17:f33
Af4    3        t     u  =[[    (
E4     3        t n   u  ===    )
F4     3        t     u  ===    .
G4     3        t     u  ]]]    .
Af4    3        t     u  [[[    (
E4     3        t     u  ===    )
F4     3        t     u  ===    .
G4     3        t     u  =]]    .
Af4    3        t     u  =[[    (
E4     3        t     u  ===    )
F4     3        t     u  ===    .
G4     3        t     u  ]]]    .
Af4    3        t     d  [[[    .
B4     3        t n   d  ===    (
D5     3        t     d  ===
F5     3        t     d  ==]    )
Af5    6        s     d  ==     .
B4     6-       s     d  ]]    -
measure 22
B4     6        s     d  [[
B4     6-       s n   d  ]]    -
B4     4        s  3  d  [[     *
C5     4        s  3  d  ==
Ef5    4-       s  3  d  ]]    -!
Ef5    6        s     d  [[
Ef5    6        s     d  ]]     .
Ef5    3        t     d  [[[    (
D5     3        t     d  ===
F5     3        t     d  ===
Af5    3-       t     d  ]]]   -)
Af5    6        s     d  [[
G5     6        s     d  ==    .(
G5     6        s     d  ==    .
G5     6        s     d  ]]    .)
measure 23
*               E   15
G5     4        s  6  d  [[     *.
F#5    4        s #6  d  ==      .
F5     4        s n6  d  ==      .
E5     4        s n6  d  ==      .
Ef5    4        s f6  d  ==      .
*               F   0
D5     4        s  6  d  ]]     !.
*               E   15
C5     4        s  6  u  [[     *.
B4     4        s n6  u  ==      .
Af4    4        s f6  u  ==      .+
G4     4        s  6  u  ==      .
F4     4        s  6  u  ==      .
*               F   0
Ef4    4        s  6  u  ]]     !.
*               E   15
D4     4        s  6  u  [[     (*.
C4     4        s  6  u  ==       .
B3     4        s n6  u  ==       .
C4     4        s  6  u  ==       .
D4     4        s  6  u  ==       .
*               F   0
Ef4    4        s  6  u  ]]     )!.
measure 24
E4     4        s n6  u  [[     (*
F4     4        s  6  u  ==
F#4    4        s #6  u  ==
A4     4        s n6  u  ==
G4     4        s  6  u  ==
C5     4        s  6  u  ]]     )!
B4     3        t n   d  [[[    (p
D5     3        t     d  ===
C5     3        t     d  ===
Ef5    3        t f   d  =]]    +
D5     3        t     d  =[[
G5     3        t     d  ===
F#5    3        t #   d  ===
A5     3        t n   d  ]]]    )
G5    12        e     d
rest  12        e
measure 25
rest  24        q
rest   6        s
*               E   0
G4     6        s     d  [[     (
C5     6        s     d  ==
B4     6        s n   d  ]]     )
D5     3        t     d  [[[    (
C5     3        t     d  ===
Ef5    3        t     d  ===
D5     3        t     d  =]]
F5     3        t     d  =[[
Ef5    3        t     d  ===
G5     3        t     d  ===
*               F   18
F5     3        t     d  ]]]    )
measure 26
Af5    6        s     d  [[     (
G5     6        s     d  ==     )
G5     6        s     d  ==     .
G5     6        s     d  ]]     .
G5     4        s  3  d  [[     .*
G5     4        s  3  d  ==     .
G5     4        s  3  d  ]]     .!
G5     3        t     d  [[[    .(
G5     3        t     d  ===    .
G5     3        t     d  ===    .
G5     3        t     d  ]]]    .)
gG5    0        e     u          (
S   C1:t15
C6    12        e     d  [       )(f
Bf5    3        t     d  =[[
Af5    3        t     d  ===
G5     3        t     d  ===
F5     3        t     d  ]]]      )
measure 27
Ef5    3        t     d  [[[    (
D5     3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  =]]
G5     3        t     d  =[[
F5     3        t     d  ===
Ef5    3        t     d  ===
D5     3        t     d  ]]]    )
*               D       dim.
P   C17:f33
C5     3        t     d  [[[    (
B4     3        t n   d  ===
D5     3        t     d  ===
C5     3        t     d  =]]
Ef5    3        t     d  =[[
D5     3        t     d  ===
C5     3        t     d  ===
B4     3        t     d  ]]]    )
A4     4        s n6  d  [[     .(*
G4     4        s  6  d  ==     .
D5     4        s  6  d  ==     .
C5     4        s  6  d  ==     .
B4     4        s  6  d  ==     .
Af4    4        s f6  d  ]]     .)!
measure 28
G4     4        s  6  u  [[     .*
Af4    4        s  6  u  ==     .
G4     4        s  6  u  ==     .
F4     4        s  6  u  ==     .
Ef4    4        s  6  u  ==     .
D4     4        s  6  u  ]]     .!
C4     4        s  6  u  [[     .*
B3     4        s n6  u  ==     .
C4     4        s  6  u  ==     .
Ef4    4        s  6  u  ==     .
G4     4        s  6  u  ==     .
B4     4        s n6  u  ]]     .!
*               E   0
C5     3        t     d  [[[    .
D5     3        t     d  ===    .
Ef5    3        t     d  ===    .
E5     3        t n   d  =]]    .
F5     3        t     d  =[[    .
F#5    3        t #   d  ===    .
G5     3        t     d  ===    .
*               F   15
F#5    3        t     d  ]]]    .
measure 29
G5     6        s     d  [[     p
G5     6        s     d  ==
G5     6        s     d  ==
G5     6        s     d  ]]
*               E   0
G5     4        s  6  d  [[     .*
F5     4        s n6  d  ==     .+
C6     4        s  6  d  ==     .
C6     4        s  6  d  ==     .
C6     4        s  6  d  ==     .
C6     4        s  6  d  ]]     .!
C6     3        t     d  [[[    .(
C6     3        t     d  ===    .
C6     3        t     d  ===    .
*               F   15
C6     3        t     d  =]]    .
C6     3        t     d  =[[    .
C6     3        t     d  ===    .
C6     3        t     d  ===    .
C6     3        t     d  ]]]    .)
measure 30
C6     4        s  6  d  [[     (*
Bf5    4        s f6  d  ==      +
Df6    4        s f6  d  ==
C6     4        s  6  d  ==
Bf5    4        s  6  d  ==
Af5    4        s  6  d  ]]     )!
G5     4        s  6  d  [[     (*
F5     4        s  6  d  ==
Ef5    4        s f6  d  ==      +
D5     4        s n6  d  ==      +
C5     4        s  6  d  ==
B4     4        s n6  d  ]]     )!
Af4    4        s f6  u  [[     (*+p
G4     4        s  6  u  ==
F4     4        s  6  u  ==
Ef4    4        s  6  u  ==
D4     4        s  6  u  ==
C4     4        s  6  u  ]]     )!
measure 31
B3     3        t n   u  [[[    (
C4     3        t     u  ===
B3     3        t     u  ===
C4     3        t     u  =]]
B3     3        t     u  =[[
C4     3        t     u  ===
B3     3        t     u  ===
C4     3        t     u  ]]]    )
B3     3        t     u  [[[    (
C4     3        t     u  ===
Ef4    3        t     u  ===
G4     3        t     u  ]]]
C5     3        t     d  [[[
Ef5    3        t     d  ===
G5     3        t     d  ===
C6     3        t     d  ]]]    )
Ef6    6        s     d  [[     (
D6     6        s     d  ]]     )
rest   6        s
B4     6        s n   d
measure 32
rest   6        s
*               E   0
B4     6        s n   d  [[     .(
B4     6        s     d  ==     .
*               F   12
B4     6        s     d  ]]     .)
*               E   12
B4     3        t     d  [[[    (
D5     3        t     d  ===
C5     3        t     d  ===
*               F   0
Ef5    3        t     d  =]]
D5     3        t     d  =[[
F5     3        t     d  ===
Ef5    3        t     d  ===
G5     3        t     d  ]]]    )
F5     3        t     d  [[[    (
Af5    3        t     d  ===
G5     3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  ===
D5     3        t     d  ===
F5     3        t     d  ===
Ef5    3        t     d  ]]]    )
measure 33
G5     3        t     d  [[[    (
F5     3        t     d  ===
Ef5    3        t     d  ===
D5     3        t     d  =]]
C5     3        t     d  =[[
B4     3        t n   d  ===
D5     3        t     d  ===
C5     3        t     d  ]]]    )
*               D       dim.
P   C17:f33
Ef5    3        t     d  [[[    (
B4     3        t     d  ===
C5     3        t     d  ===
D5     3        t     d  =]]
Ef5    3        t     d  =[[
B4     3        t     d  ===
C5     3        t     d  ===
D5     3        t     d  ]]]    )
Ef5    6        s     u  [[     (
F#4    6        s #   u  ==     )
F#4    6        s     u  ==     .
F#4    6        s     u  ]]     .
measure 34
F#4    6        s #   u  [[     pp.
F#4    6        s     u  ==     t(
S   C33:uhn6s17t83e
gE4    5        s n   u  [[
gF#4   5        s     u  ]]
A4     6        s n   u  ==
G4     6        s     u  ]]      )
*               D       morendo
P   C17:f33
G4    18        e.    u  [       (
F#4    6        s #   u  ]\      )+
G4     6        s     u  [[      (
F#4    6        s     u  ==
G4     6        s     u  ==
F#4    6        s     u  ]]      )
measure 35
G4    72        h.    u          F
mdouble
$   K:0
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/02/02} [KHM:2870205300]
TIMESTAMP: DEC/26/2001 [md5sum:1b0deae274cee54705bc1ac0e7846b6a]
07/25/94 W Hewlett
WK#:54,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Adagio (Second movement)
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:8   T:3/4  C:4  D:Adagio
C4    16        h     u         (p
B3     8        q n   u         )
measure 2
C4    24        h.    u
measure 3
B3     8        q n   u         (
C4     8        q     u
D4     8        q     u         )
measure 4
D4     8        q     u         (
C4     8        q     u
B3     8        q n   u         )
measure 5
Ef4   24-       h.    u        -
measure 6
Ef4    8        q     u
D4     8        q     u         (
C4     8        q     u         )
measure 7
Bf3    8        q f   u         (+
Ef4    8        q     u         )
C4     8        q     u
measure 8
B3    16        h n   u
rest   8        q
measure 9
*               D       dolce
P   C17:f33
C4     8        q     u         (
Ef4    8        q     u
D4     8        q     u
 B3    8        q n   u         )
measure 10
*               E   0
C4     8        q     u
G4     8        q     u         (t
S   C34:uhn18s7t95e
gF4    5        s     u  [[
gG4    5        s     u  ]]
*               FG  18  mf
Af4    8        q     u         )
measure 11
D4     8        q     u         (
G4     8        q     u
F4     8        q     u
 G3    8        q     u         )
measure 12
*               D       decresc.
P   C17:f33
F4     8        q     u
 G3    8        q     u         (
Ef4    8        q     u         t
S   C33:uwn18s7t95f
 G3    8        q     u
gD4    5        s     u  [[
gEf4   5        s     u  ]]
D4     8        q     u
 G3    8        q     u         )
measure 13
Ef4    8        q     u          p
 G3    8        q     u         (
Af4    8        q     u
G4     8        q     u         )
measure 14
F#4    8        q #   u         (
*      4        E   0
G4     8        q     u
*      4        F   15
A4     8        q     u
 D4    8        q n   u         )
measure 15
Bf4    8        q     u         (
 D4    8        q     u
C5     8        q     d         )
*               D       dim.
P   C17:f33
A4     6        e.n   u  [      (t
S   C34:uhn10s12t91
G4     1        t     u  =[[
A4     1        t     u  ]]]    )
measure 16
G4    16        h     u
rest   8        q
measure 17
Ef4    8        q     u         (p
G4     8        q     u
F4     8        q n   u         )+
measure 18
*               E   0
Ef4    8        q     u         (
Bf4    8        q     d
*               FG  18  Z
Df5    8        q f   d         )
measure 19
C5     8        q     d         (
Bf4    8        q     d
Af4    8        q f   u         )+
measure 20
*               E   15
G4     8        q     u         (
F4     8        q     u
*               F   0
E4     8        q n   u
measure 21
F4     8        q     u         )p
*               GE  15  Z
*      6        F   0
Af4   16        h     u         (
 B3   16        h n   u
measure 22
G4     8        q     u         )p
B4     8        q n   d         (t
S   C34:uhn18s7t95e
gA4    5        s     u  [[
gB4    5        s     u  ]]
C5     8        q     d         )
measure 23
D5     8        q     d
F4     8        q     u
 G3    8        q     u         (
Ef4    6        e.    u  [      t
S   C33:uwn10s12t91
 G3    6        e.    u
D4     1        t     u  =[[
Ef4    1        t     u  ]]]    )
measure 24
D4     8        q     u
 G3    8        q     u
rest   8        q
rest   8        q
measure 25
C4     8        q     u         (
P   C33:u
Ef4    8        q     u
D4     8        q     u
 B3    8        q n   u         )
measure 26
*               E   0
C4     8        q     u         (
G4     8        q     u         t
S   C33:uhn18s7t95e
gF4    5        s     u  [[
gG4    5        s     u  ]]
*               FG  18  mf
Af4    8        q f   u         )+
measure 27
D4     8        q     u         (
G4     8        q     u
F4     8        q     u         )
measure 28
*               D       decresc.
P   C17:f33
F4     8        q     u         (
Ef4    8        q     u         t
S   C33:uwn18s7t95f
gD4    5        s     u  [[
gEf4   5        s     u  ]]
D4     8        q     u         )
measure 29
C4     8        q     u         (p
*               E   0
F4     8        q     u         )
*      6        F   15
G4     8        q     u
 Bf3   8        q f   u         +
measure 30
*               E   15
Af4    8        q f   u         +
 C4    8        q     u
*      2        F   0
B4     8        q n   u
 F4    8        q     u         (
C5     8        q     u          p
 Ef4   8        q     u         )
measure 31
Af4    8        q     u         (
G4     8        q     u         )
B3     4        e n   u  [      (
F4     4        e     u  ]      )
measure 32
Ef4   24-       h.    u        -pp
measure 33
Ef4    2        s     u  [[
F4     2        s     u  ==     .(
F#4    2        s #   u  ==     .
F#4    2        s     u  ]]     .)
F#4    8-       q     u        -
F#4    2        s     u  [[
C4     2        s     u  ==     .(
C4     2        s     u  ==     .
C4     2        s     u  ]]     .)
measure 34
C4     8        q     u         (
*               D       morendo
P   C17:f33
B3     6        e.n   u  [
C4     2        s     u  ]\     )
B3     2        s     u  [[     (
C4     2        s     u  ==
B3     2        s     u  ==
C4     2        s     u  ]]     )
measure 35
B3    24        h.n   u         F
mdouble
$   K:0
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/02/03} [KHM:2870205300]
TIMESTAMP: DEC/26/2001 [md5sum:6a2bc2d97a633fda8b6346fbb39c17e8]
07/25/94 W Hewlett
WK#:54,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Adagio (Second movement)
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:4   T:3/4  C:13  D:Adagio
Ef3    4        q     u         (p
G3     4        q     u
F3     4        q     u         )
measure 2
Ef3    4        q     u
Ef4    4        q     d         (
D4     4        q     d         )
measure 3
G3    12-       h.    u        -
measure 4
G3    12        h.    u
measure 5
G3     4        q     u         (
Ef3    4        q     u
G3     4        q     u         )
measure 6
A3     4        q n   u         (
G3     4        q     u         )
D4     4-       q     d        -
measure 7
D4     4        q     d
A4     4        q n   d         (
F#4    4        q #   d         )
measure 8
D4     8        h     d
rest   4        q
measure 9
Ef3    4        q     u         (
G3     4        q     u
F3     4        q n   u         )+
measure 10
*               E   0
Ef3    4        q     u         (
*      4        FG  18  mf
C4     8        h     d         )
measure 11
B3     4        q n   u         (
C4     4        q     d
D4     4        q     d         )
measure 12
*               D       decresc.
P   C17:f33
D4     4        q     d         (
C4     4        q     d
B3     4        q n   u         )
measure 13
C4    12        h.    d         p
measure 14
A3     4        q n   u         (
*      2        E   0
D4     4        q     d
*      2        F   15
C4     4        q     d         )
measure 15
Bf3    4        q f   u         (+
A3     4        q n   u         )
*               D       dim.
P   C17:f33
F#3    2        e #   u  [      (
C4     2        e     u  ]      )
measure 16
B3     8        h n   u
rest   4        q
measure 17
G3     4        q     u         (p
Bf3    4        q f   u         +
D4     4        q     u
 Af3   4        q f   u         )+
measure 18
*               E   0
Ef4    8        h     u         (
P   C33:o
*               FG  18  Z
Af4    4        q     d         )
back  12
G3     4        q     d
rest   4        q
irest  4        q
measure 19
G4     8        h     d         (
C4     4        q     d         )
measure 20
*               E   15
Df4    4        q f   d         (
Af3    4        q     u
*               F   0
G3     4        q     u
measure 21
Af3    4        q     u         )p
*               GE  15  Z
*      3        F   0
D4     8        h n   d         +
measure 22
C4     4        q     d         p
F4     4        q     d         (
Ef4    4        q     d         )
measure 23
F4     4        q     d
D4     4        q     d         (
C4     4        q     d         )
measure 24
B3     4        q n   u
rest   4        q
rest   4        q
measure 25
Ef3    4        q     u         (
G3     4        q     u
F3     4        q     u         )
measure 26
*               E   0
Ef3    4        q     u         (
*      4        FG  18  mf
C4     8        h     d         )
measure 27
B3     4        q n   u         (
C4     4        q     d
D4     4        q     d         )
measure 28
*               D       decresc.
P   C17:f33
D4     4        q     d         (
C4     4        q     d
B3     4        q n   u         )
measure 29
*      4        E   0
C4     8        h     d
*      2        F   15
E4     4        q n   d
measure 30
*               E   15
F4     4        q     d
*      1        F   0
Af4    4        q     d         (
G4     4        q     d         )p
measure 31
F4     4        q     d         (
Ef4    4        q f   d         )+
D4     4        q     d
measure 32
C4    12-       h.    d        -pp
measure 33
C4     8-       h     d        -
C4     1        s     u  [[
Ef3    1        s     u  ==     .(
Ef3    1        s     u  ==     .
Ef3    1        s     u  ]]     .)
measure 34
Ef3    4        q     u         (
*               D       morendo
P   C17:f33
D3     3        e.    u  [
Ef3    1        s     u  ]\     )
D3     1        s     u  [[     (
Ef3    1        s     u  ==
D3     1        s     u  ==
Ef3    1        s     u  ]]     )
measure 35
D3    12        h.    u         F
mdouble
$   K:0
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/02/04} [KHM:2870205300]
TIMESTAMP: DEC/26/2001 [md5sum:728b1d16689e23b65eb20e35501bb618]
07/25/94 W Hewlett
WK#:54,2      MV#:2
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Adagio (Second movement)
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:-3   Q:4   T:3/4  C:22  D:Adagio
C3    12-       h.    u        -p
measure 2
C3     4        q     u
Ef2    4        q     u         (
F2     4        q     u         )
measure 3
G2     4        q n   u         (+
A2     4        q n   u
B2     4        q n   u         )
measure 4
C3     4        q     u         (
Ef3    4        q     d
G3     4        q     d         )
measure 5
C3    12-       h.    u        -
measure 6
C3     4        q     u
Bf2    4        q f   u         (+
F#2    4        q #   u         )
measure 7
G2     4        q     u         (
C2     4        q     u
D2     4        q     u         )
measure 8
G2     8        h     u
rest   4        q
measure 9
C3    12-       h.    u        -
measure 10
*               E   0
C3     4        q     u
Ef2    4        q     u         (
*               FG  18  mf
F2     4        q     u         )
measure 11
G2     4        q     u         (
A2     4        q n   u
B2     4        q n   u         )
measure 12
*               D       decresc.
P   C17:f33
C3     4        q     u         (
Ef3    4        q     d
G3     4        q     d         )
measure 13
C3    12-       h.    u        -p
measure 14
C3     4        q     u
*      2        E   0
Bf2    4        q f   u         (+
*      2        F   15
F#2    4        q #   u         )
measure 15
G2     4        q     u         (
C2     4        q     u
*               D       dim.
P   C17:f33
D2     4        q     u         )
measure 16
G2     4        q     u
G3     4        q     d
G2     4        q     u
measure 17
Ef3   12-       h.    d        -p
measure 18
*               E   0
Ef3    4        q     d
G2     4        q     u         (
*               FG  18  Z
F2     4        q n   u         )+
measure 19
E2     8        h n   u         (
F2     4        q     u         )
measure 20
*               E   15
Bf2    4        q     u         (
*      4        F   0
C3     8        h     u
measure 21
F2     4        q     u         )p
*               GE  15  Z
*      3        F   0
F3     4        q     d
F3     4        q     d
measure 22
Ef3    4        q     d         p
D3     4        q     d         (
C3     4        q     u         )
measure 23
B2     8        h n   u         (
C3     4        q     u         )
measure 24
G2     4        q     u
G3     2        e     d  [      .
F3     2        e     d  =      .
Ef3    2        e     d  =      .
D3     2        e     d  ]      .
measure 25
C3    12-       h.    u        -
measure 26
C3     4        q     u
Ef2    4        q     u         (
*               G       mf
F2     4        q     u         )
measure 27
G2     4        q     u         (
A2     4        q n   u
B2     4        q n   u         )
measure 28
*               D       decresc.
P   C17:f33
C3     4        q     u         (
Ef3    4        q     d
G3     4        q     d         )
measure 29
*      4        E   0
Af3    8        h f   d         +
*      2        F   15
G3     4        q     d
measure 30
*               E   15
F3     4        q     d
*      1        F   0
D3     4        q     d         (
Ef3    4        q f   d         )+p
measure 31
F3     4        q     d         (
G3     4        q     d         )
G2     4        q     u
measure 32
Af2   12-       h.    u        -pp
measure 33
Af2    8        h     u
Af2    4        q     u
measure 34
*               D       morendo
P   C17:f33
G2    12        h.    u
measure 35
G2    12        h.    u         F
mdouble
$   K:0
/END
/eof
//
