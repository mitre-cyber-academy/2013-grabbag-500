&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/01/01} [KHM:4000451156]
TIMESTAMP: DEC/26/2001 [md5sum:11e46ba7f9e97dd0701a7e41bd52a3fa]
07/25/94 W Hewlett
WK#:54,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Vivace (First movement)
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:1/1  C:4  D:Vivace
G5     6        h.    d         f
gA5    4        t     u  [[[    (
S  C1:t17
gG5    4        t     u  ===
S  C1:t17
gF#5   4        t     u  ]]]
S  C1:t17
G5     2        q     d         )(
measure 2
C6     2        q     d         )
E5     2        q     d         .
G5     2        q     d         .
gD5    4        t     u  [[[    (
S  C1:t17
gC5    4        t     u  ===
S  C1:t17
gB4    4        t     u  ]]]
S  C1:t17
C5     2        q     d         )(
measure 3
E5     2        q     d         )
G4     2        q     u         .
C5     2        q     d         .
E4     1        e     u  [      (
 G3    1        e     u
G4     1        e     u  ]
measure 4
F4     1        e     u  [
G4     1        e     u  =
E4     1        e     u  =
F4     1        e     u  ]
D4     1        e     u  [
F4     1        e     u  =
E4     1        e     u  =
G4     1        e     u  ]      )
back   8
G3     8        w     d
measure 5
F4     2        q     u
 G3    2        q     u         .
B4     2        q     d         .p
D5     2        q     d         .
rest   2        q
measure 6
rest   8
measure 7
F5     6        h.    d         f
gG5    4        t     u  [[[    (
S  C1:t17
gF5    4        t     u  ===
S  C1:t17
gE5    4        t     u  ]]]
S  C1:t17
F5     2        q     d         )(
measure 8
A5     2        q     d         )
D5     2        q     d         .
F5     2        q     d         .
gC5    4        t     u  [[[    (
S  C1:t17
gB4    4        t     u  ===
S  C1:t17
gA4    4        t     u  ]]]
S  C1:t17
B4     2        q     d         )(
measure 9
D5     2        q     d         )
F4     2        q     u         .
A4     2        q     u         .
D4     1        e     u  [      (
 G3    1        e     u
E4     1        e     u  ]
measure 10
F4     1        e     u  [
G4     1        e     u  =
E4     1        e     u  =
G4     1        e     u  ]
F4     1        e     u  [
G4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]      )
back   8
G3     8        w     d
measure 11
E4     2        q     u
 G3    2        q     u
C5     2        q     d         .p
E5     2        q     d         .
rest   2        q
measure 12
rest   8
measure 13
C5     6        h.    d         f
gDf5   4        t     u  [[[    (
S  C1:t17
gC5    4        t     u  ===
S  C1:t17
gBf4   4        t     u  ]]]
S  C1:t17
C5     2        q     d         )(
measure 14
Ef5    2        q f   d         )
Af4    2        q f   u         .
C5     2        q     d         .
gF4    4        t     u  [[[    (
S  C1:t17
gEf4   4        t     u  ===
S  C1:t17
gD4    4        t     u  ]]]
S  C1:t17
Ef4    2        q f   u         )(
measure 15
Af4    2        q f   u         )
C4     2        q     u         .
Ef4    2        q f   u         .
C4     1        e     u  [      (
Ef4    1        e     u  ]      )
measure 16
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 17
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      (
C5     1        e     u  =      )
Af4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 18
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 19
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      (
C5     1        e     u  =      )
Af4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 20
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 21
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      (
C5     1        e     u  =      )
Af4    1        e     u  =      .
G4     1        e     u  ]      .
measure 22
F#4    2        q #   u         .
F#4    2        q     u         .(
F#4    2        q     u         .)
gG4    4        t     u  [[[    (
S  C1:t17
gF#4   4        t     u  ===
S  C1:t17
gE4    4        t n   u  ]]]     +
S  C1:t17
F#4    2        q     u         )(
measure 23
G4     2        q     u         )
A4     2        q n   u         .+(>
A4     2        q     u         .
A4     2        q     u         . )
measure 24
C4     4        h     u
gE4    0        e n   u         +
S  C1:pt30
D4     1        e     u  [      (
C4     1        e     u  =
D4     1        e     u  =
E4     1        e     u  ]      )
measure 25
C4     2        q     u
rest   2        q
rest   4        h
measure 26
rest   2        q
F#5    2        q #   d         .(p
F#5    2        q     d         .)
F#5    2        q     d         r(
S   C33:uhn4s25t75e
measure 27
G5     2        q     d          )
A5     2        q     d          .(>
A5     2        q     d          .
A5     2        q     d          .)
measure 28
C5     4        h     d
gE5    0        e     u
S  C1:pt30
D5     1        e     d  [      (
C5     1        e     d  =
D5     1        e     d  =
E5     1        e     d  ]      )
measure 29
C5     2        q     d
rest   2        q
rest   4        h
measure 30
C6     6        h.    d         f
gD6    4        t     u  [[[    (
S  C1:t17
gC6    4        t     u  ===
S  C1:t17
gB5    4        t     u  ]]]
S  C1:t17
C6     2        q     d         )(
measure 31
E6     2        q     d         ).
B5     2        q     d         (r
S   C34:uhn4s25t75e
C6     2        q     d         ).
G#5    2        q #   d         (rus
S   C34:uhn4s25t75e
measure 32
A5     2        q     d         ).
D#5    2        q #   d         (rus
S   C34:uhn4s25t75e
E5     2        q     d         ).
B4     2        q     d         (r
S   C34:uhn4s25t75e
measure 33
C5     2        q     d         ).
G#4    2        q #   u         (rus
S   C34:uhn4s25t75e
A4     2        q     u         ).
E4     2        q     u
measure 34
F4     4        h     u
E4     2        q     u         (.
D#4    2        q #   u         ).
measure 35
E4     1        e     u  [
G#4    1        e #   u  =
B4     1        e     u  =
E5     1        e     u  ]
G#5    1        e #   d  [
B5     1        e     d  =
G#5    1        e     d  =
E5     1        e     d  ]
measure 36
E4     4        h     u
D4     2        q n   u         (+.
C#4    2        q #   u         ) .
measure 37
D4     1        e     u  [
F4     1        e     u  =
A4     1        e     u  =
D5     1        e     u  ]
F5     1        e     d  [
A5     1        e     d  =
F5     1        e     d  =
D5     1        e     d  ]
measure 38
D4     4        h     u
C4     2        q n   u         (+.
B3     2        q     u         ) .
measure 39
C4     1        e     u  [
E4     1        e     u  =
G4     1        e     u  =
C5     1        e     u  ]
E5     1        e     d  [
G5     1        e     d  =
E5     1        e     d  =
C5     1        e     d  ]
measure 40
F#5    1        e #   d  [
A5     1        e     d  =
F#5    1        e     d  =
D5     1        e     d  ]
C5     1        e     u  [
A4     1        e     u  =
F#4    1        e #   u  =
C4     1        e     u  ]
measure 41
B3     1        e     u  [
D4     1        e     u  =
G4     1        e     u  =
B4     1        e     u  ]
D5     1        e     d  [
G5     1        e     d  =
B5     1        e     d  =
G5     1        e     d  ]
measure 42
E5     1        e     d  [
G5     1        e     d  =
E5     1        e     d  =
C#5    1        e #   d  ]
Bf4    1        e f   u  [
G4     1        e     u  =
E4     1        e     u  =
C#4    1        e #   u  ]
measure 43
D4     1        e     u  [      (
D5     1        e     u  =      )
E5     1        e     u  =      (
D5     1        e     u  ]      )
C#5    1        e #   d  [      .
D5     1        e     d  =      .
C5     1        e n   d  =      .
D5     1        e     d  ]      .
measure 44
B4     1        e     d  [      .
D5     1        e     d  =      .
G5     1        e     d  =      .
B5     1        e     d  ]      .
D6     1        e     d  [      .
B5     1        e     d  =      .
G5     1        e     d  =      .
D5     1        e     d  ]      .
measure 45
D4     1        e     u  [      (
D5     1        e     u  =      )
E5     1        e     u  =      (
D5     1        e     u  ]      )
C#5    1        e #   d  [      .
D5     1        e     d  =      .
C5     1        e n   d  =      .
D5     1        e     d  ]      .
measure 46
B4     1        e     d  [      .
D5     1        e     d  =      .
G5     1        e     d  =      .
B5     1        e     d  ]      .
D6     1        e     d  [      .
B5     1        e     d  =      .
G5     1        e     d  =      .
D5     1        e     d  ]      .
measure 47
D4     1        e     u  [      (
D5     1        e     u  =      )
E5     1        e     u  =      (
D5     1        e     u  ]      )
C#5    1        e #   d  [      .
D5     1        e     d  =      .
C5     1        e n   d  =      .
D5     1        e     d  ]      .
measure 48
Bf4    1        e f   d  [
D5     1        e     d  =
G5     1        e     d  =
Bf5    1        e f   d  ]
D6     1        e     d  [
Bf5    1        e     d  =
G5     1        e     d  =
D5     1        e     d  ]
measure 49
G4     1        e     d  [
Bf4    1        e f   d  =
D5     1        e     d  =
G5     1        e     d  ]
Bf5    1        e f   d  [
G5     1        e     d  =
D5     1        e     d  =
Bf4    1        e     d  ]
measure 50
Ef4    1        e f   d  [
G4     1        e     d  =
Bf4    1        e f   d  =
Ef5    1        e f   d  ]
G5     1        e     d  [
Ef5    1        e     d  =
Bf4    1        e     d  =
G4     1        e     d  ]
measure 51
Ef4    1        e f   u  [      (
G4     1        e     u  =      )
Bf4    1        e f   u  =      .
G4     1        e     u  ]      .
D4     1        e     u  [      (
G4     1        e     u  =      )
Bf4    1        e     u  =      .
G4     1        e     u  ]      .
measure 52
C#4    1        e #   u  [      (
G4     1        e     u  =      )
Bf4    1        e f   u  =
G4     1        e     u  ]
E6     1        e n   d  [      .+
G4     1        e     d  =      (
Bf4    1        e     d  =      )
G4     1        e     d  ]      .
measure 53
C#4    1        e #   u  [      (
G4     1        e     u  =      )
Bf4    1        e f   u  =      .
G4     1        e     u  ]      .
E6     1        e     d  [      .
G4     1        e     d  =      (
Bf4    1        e     d  =      )
G4     1        e     d  ]      .
measure 54
F#4    1        e #   u  [      (
D4     1        e     u  =      )
F#4    1        e     u  =      .
A4     1        e     u  ]      .
D5     1        e     d  [      .
F#5    1        e #   d  =      .
A5     1        e     d  =      .
C#6    1        e #   d  ]      .
measure 55
*      2        E   15
D6     6        h.    d         (
*               F   0
C6     2        q n   d         )+
measure 56
*               D       !1p !33dolce
B5     4-       h     d        -(
B5     1        e     d  [
D6     1        e     d  =
C6     1        e     d  =
E6     1        e     d  ]      )
measure 57
D6     1        e     d         .
rest   1        e
D6     2        q     d         (
B5     1        e     d         ).
rest   1        e
C6     2        q     d         (
measure 58
A5     1        e     d         ).
rest   1        e
B5     2        q     d         (
G5     1        e     d         ).
rest   1        e
B5     1        e     d  [      (
A5     1        e     d  ]      )
measure 59
D5     2        q     d         .
D5     2        q     d         .
D5     2        q     d         .
B5     1        e     d  [      (
A5     1        e     d  ]      )
measure 60
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
A5     2        q     d         (
measure 61
B4     1        e     d         ).
rest   1        e
G5     2        q     d         (
A4     1        e     u         ).
rest   1        e
E5     2        q     d         (
measure 62
G4     4        h     u         )
gB4    0        e     u         (
S  C1:pt10
A4     3        q.    u         )(
G4     1        e     u          )
measure 63
*               E   0
G4     1        e     d  [      .
B4     1        e     d  =      .
D5     1        e     d  =      .
F#5    1        e #   d  ]      .
G5     1        e     d  [      .
A5     1        e     d  =      .
B5     1        e     d  =      .
*               F   18
C6     1        e     d  ]      .
measure 64
D6     8-       w     d        -
measure 65
D6     8-       w     d        -
measure 66
D6     8-       w     d        -
measure 67
D6     1        e     d         .
rest   1        e
D6     2        q     d         (
B5     1        e     d         ).
rest   1        e
C6     2        q     d         (
measure 68
A5     1        e     d         ).
rest   1        e
B5     2        q     d         (
G5     1        e     d         ).
rest   1        e
B5     1        e     d  [      (
A5     1        e     d  ]      )
measure 69
D5     2        q     d         .
D5     2        q     d         .
D5     2        q     d         .
B5     1        e     d  [      (
A5     1        e     d  ]      )
measure 70
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
B5     1        e     d  [      (
A5     1        e     d  ]      )
measure 71
B4     1        e     d
rest   1        e
A5     1        e     d  [      (
G5     1        e     d  ]      )
A4     1        e     u         .
rest   1        e
D#5    1        e #   d  [      (
E5     1        e     d  ]      )
measure 72
G4     4        h     u
gB4    0        e     u         (
S  C1:pt10
A4     3        q.    u         )(
G4     1        e     u          )
measure 73
G4     1        e     u  [      (
D4     1        e     u  =      )
D5     1        e     u  =      .
B4     1        e     u  ]      .
G4     1        e     u  [      (
D4     1        e     u  =      )
G5     1        e     u  =      .
D5     1        e     u  ]      .
measure 74
*               D       cresc.
P  C17:f33
B4     1        e     d  [      (
G4     1        e     d  =      )
B5     1        e     d  =      .
G5     1        e     d  ]      .
D5     1        e     d  [      (
B4     1        e     d  =      )
D6     1        e     d  =      .
B5     1        e     d  ]      .
measure 75
G5     1        e     d  [      (
D5     1        e     d  =      )
G6     1        e     d  =      .
G6     1        e     d  ]      .
G6     1        e     d  [      .
G6     1        e     d  =      .
G6     1        e     d  =      .
G6     1        e     d  ]      .
measure 76
G6     1        e     d  [      (f
D6     1        e     d  =      )
B6     1        e     d  =      .
B6     1        e     d  ]      .
B6     1        e     d  [      .
B6     1        e     d  =      .
B6     1        e     d  =      .
B6     1        e     d  ]      .
measure 77
B6     1        e     d  [      (
G6     1        e     d  =      )
D7     1        e     d  =      .
D7     1        e     d  ]      .
D7     1        e     d  [      .
D7     1        e     d  =      .
D7     1        e     d  =      .
D7     1        e     d  ]      .
measure 78
D7     2        q     d
B3     1        e     u  [      .
G3     1        e     u  ]      .
C4     1        e     u  [      .
G3     1        e     u  =      .
D4     1        e     u  =      .
G3     1        e     u  ]      .
measure 79
E4     2        q     u         .
E4     2        q     u         (rsp
S   C34:uwn4s25t75e
F#4    2        q #   u
G4     2        q     u         )
measure 80
G3     4        h     u
gB3    0        e     u         (
S  C1:pt10
A3     3        q.    u         )(
G3     1        e     u          )
measure 81
G3     1        e     u
rest   1        e
G4     2        q     u         mf(
F#4    1        e #   u           ).
rest   1        e
A4     2        q     u         (
measure 82
G4     1        e     u         ).
rest   1        e
B4     2        q     d         (
A4     1        e     u         ).
rest   1        e
C5     2        q     d         (
measure 83
B4     1        e     d         ).
rest   1        e
D5     2        q     d         (
C5     1        e     d         ).
rest   1        e
E5     2        q     d         (
measure 84
D5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
C#5    2        q #   d         (
measure 85
D5     1        e     d         ).
rest   1        e
C#5    2        q #   d         (
D5     1        e     d         ).
rest   1        e
E5     2        q     d         (
measure 86
F5     1        e n   d         ).+
rest   1        e
rest   2        q
rest   2        q
E5     2        q     d         (p
measure 87a     start-end1
F5     1        e     d         ).
rest   1        e
E5     2        q     d         (
F5     1        e     d         ).
rest   1        e
F#5    2        q #   d
mheavy2 87b     stop-end1  start-end2  :|
F5     1        e     d
rest   1        e
F#5    2        q #   d         (
G5     1        e     d         ).
rest   1        e
A5     2        q     d
mheavy3 88                 disc-end2  |:
Bf5    6        h.f   d         f
gC6    4        t     u  [[[    (
S  C1:t17
gBf5   4        t     u  ===
S  C1:t17
gA5    4        t     u  ]]]
S  C1:t17
Bf5    2        q     d         )(
measure 89
D6     2        q     d          )
G5     2        q     d         .
Bf5    2        q f   d
gF5    4        t     u  [[[    (
S  C1:t17
gE5    4        t     u  ===
S  C1:t17
gD5    4        t     u  ]]]
S  C1:t17
E5     2        q     d         )(
measure 90
G5     2        q     d          )
Bf4    2        q f   d         .
D5     2        q     d         .
G4     2        q     u         (r
S   C34:uwn4s25t75e
measure 91
Bf4    2        q f   d         )
E4     2        q     u         .
G4     2        q     u         .
Bf3    2        q f   u         (r
S   C34:uwn4s25t75f
measure 92
A3     2        q     u         )
C4     2        q     u         .
F4     2        q     u         .
Bf4    2        q f   d         (r
S   C34:uwn4s25t75f
measure 93
A4     2        q     u         )
C5     2        q     d         .
F5     2        q     d         .
G5     2        q     d         (rp
S   C34:uwn4s25t75e
measure 94
A5     2        q     d         )
F5     2        q     d         .
C5     2        q     d         .
rest   2        q
measure 95
rest   4        h
rest   2        q
gBf5   4        t     u  [[[    (
S  C1:t17
gA5    4        t     u  ===
S  C1:t17
gG5    4        t     u  ]]]
S  C1:t17
A5     2        q     d         )(
measure 96
Bf5    2        q f   d          )
G5     2        q     d         .
D5     2        q     d         .
rest   2        q
measure 97
rest   4        h
rest   2        q
Bf5    2        q f   d         (rmf
S   C34:uwn4s25t75f
measure 98
Ef6    2        q f   d         )
Bf5    2        q f   d         .
G5     2        q     d         .
Ef5    2        q f   d         .
measure 99
*               D       cresc.
P   C17:f33
D5     2        q     d         .
F4     2        q     u         (
E4     2        q n   u         +
D4     2        q     u         )
measure 100
A4     1        e     d  [      (
A5     1        e     d  =      )
Bf5    1        e f   d  =      (
A5     1        e     d  ]      )
G#5    1        e #   d  [      .
A5     1        e     d  =      .
G5     1        e n   d  =      .
A5     1        e     d  ]      .
measure 101
F5     1        e     d  [      .
D5     1        e     d  =      .
F5     1        e     d  =      .
A5     1        e     d  ]      .
D6     1        e     d  [      .
A5     1        e     d  =      .
F5     1        e     d  =      .
D5     1        e     d  ]      .
measure 102
A4     1        e     d  [      (
A5     1        e     d  =      )
Bf5    1        e f   d  =      (
A5     1        e     d  ]      )
G#5    1        e #   d  [      .
A5     1        e     d  =      .
G5     1        e n   d  =      .
A5     1        e     d  ]      .
measure 103
F5     1        e     d  [      .
D5     1        e     d  =      .
F5     1        e     d  =      .
A5     1        e     d  ]      .
D6     1        e     d  [      .
A5     1        e     d  =      .
F5     1        e     d  =      .
D5     1        e     d  ]      .
measure 104
A4     1        e     d  [      (
A5     1        e     d  =      )
Bf5    1        e f   d  =      (
A5     1        e     d  ]      )
G#5    1        e #   d  [      .
A5     1        e     d  =      .
G5     1        e n   d  =      .
A5     1        e     d  ]      .
measure 105
F5     2        q     d
F#5    4        h #   d         >
A5     2        q     d
measure 106
G5     2        q     d
A5     2        q     d         (rb
S   C34:uhn4s25t75e
Bf5    2        q f   d         )
D6     2        q     d
measure 107
C6     2        q     d
E5     4        h     d         >
G5     2        q     d
measure 108
F5     2        q     d
G5     2        q     d         (r
S   C34:uwn4s25t75e
A5     2        q     d
C6     2        q     d         )
measure 109
Bf5    2        q f   d
D5     4        h     d         >
F5     2        q     d
measure 110
E5     2        q     d
F5     2        q     d         (r
S   C34:uwn4s25t75f
G5     2        q     d         )
Bf5    2        q f   d
measure 111
A5     2        q     d
C#5    4        h #   d         >
E5     2        q     d
measure 112
D5     2        q     d
E5     2        q     d         (r
S   C34:uhn4s25t75e
F5     2        q     d         )
F#5    2        q #   d
measure 113
G5     2        q     d
A5     2        q     d         (rb
S   C34:uhn4s25t75e
Bf5    2        q f   d         )
D6     2        q     d
measure 114
C6     6        h.n   d         +
Bf5    2        q f   d         (
measure 115
A5     1        e     d         ).
rest   1        e
F5     2        q     d         (
C5     1        e     d         ).
rest   1        e
A5     2        q     d         (
measure 116
Bf5    1        e f   d         ).
rest   1        e
G5     2        q     d         (
C5     1        e     d         ).
rest   1        e
Bf5    2        q     d         (
measure 117
A5     1        e     d         ).
rest   1        e
F5     2        q     d         (
C5     1        e     d         ).
rest   1        e
A5     2        q     d         (
measure 118
Bf5    1        e f   d         ).
rest   1        e
G5     2        q     d         (
C5     1        e     d         ).
rest   1        e
Bf5    2        q     d         (
measure 119
A5     1        e     d         ).
rest   1        e
E5     2        q     d         (
F5     1        e     d         ).
rest   1        e
C#5    2        q #   d         (
measure 120
D5     1        e     d         ).
rest   1        e
A4     2        q     u         (
B4     1        e n   d         ).+
rest   1        e
C5     2        q n   d         (+
measure 121
B4     1        e     d         ).
rest   1        e
*               D       decresc.
P   C17:f33
C5     2        q     d         (
D5     1        e     d         ).
rest   1        e
E5     2        q     d         (
measure 122
F5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
E5     2        q     d         (p
measure 123
F5     1        e     d         ).
rest   1        e
E5     2        q     d         (
F5     1        e     d         ).
rest   1        e
E5     2        q     d         (
measure 124
F5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
E5     2        q     d         (
measure 125
F5     1        e     d         ).
rest   1        e
E5     2        q     d         (
F5     1        e     d         ).
rest   1        e
F#5    2        q #   d
measure 126
G5     6        h.    d         f
gA5    4        t     u  [[[    (
S  C1:t17
gG5    4        t     u  ===
S  C1:t17
gF#5   4        t     u  ]]]
S  C1:t17
G5     2        q     d         )(
measure 127
C6     2        q     d          )
E5     2        q     d         .
G5     2        q     d         .
gD5    4        t     u  [[[    (
S  C1:t17
gC5    4        t     u  ===
S  C1:t17
gB4    4        t     u  ]]]
S  C1:t17
C5     2        q     d         )(
measure 128
E5     2        q     d          )
G4     2        q     u         .
C5     2        q     d         .
E4     1        e     u  [      (
 G3    1        e     u
G4     1        e     u  ]
measure 129
F4     1        e     u  [
G4     1        e     u  =
E4     1        e     u  =
F4     1        e     u  ]
D4     1        e     u  [
F4     1        e     u  =
E4     1        e     u  =
G4     1        e     u  ]      )
back   8
G3     8        w     d
measure 130
F4     2        q     u
 G3    2        q     u         .
B4     2        q     d         .
D5     2        q     d         .
rest   2        q
measure 131
F5     2        q     d         .pp
B5     2        q     d         .
D6     2        q     d         .
rest   2        q
measure 132
F5     6        h.    d         f
gG5    4        t     u  [[[    (
S  C1:t17
gF5    4        t     u  ===
S  C1:t17
gE5    4        t     u  ]]]
S  C1:t17
F5     2        q     d         )(
measure 133
A5     2        q     d          )
D5     2        q     d         .
F5     2        q     d         .
gC5    4        t     u  [[[    (
S  C1:t17
gB4    4        t     u  ===
S  C1:t17
gA4    4        t     u  ]]]
S  C1:t17
B4     2        q     d         )(
measure 134
D5     2        q     d          )
F4     2        q     u         .
A4     2        q     u         .
D4     1        e     u  [      (
 G3    1        e     u
E4     1        e     u  ]
measure 135
F4     1        e     u  [
G4     1        e     u  =
E4     1        e     u  =
G4     1        e     u  ]
F4     1        e     u  [
G4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]      )
back   8
G3     8        w     d
measure 136
E4     2        q     u
 G3    2        q     u         .
C5     2        q     d         .
E5     2        q     d         .
rest   2        q
measure 137
G5     2        q     d         .pp
C6     2        q     d         .
E6     2        q     d         .
rest   2        q
measure 138
C5     6        h.    d         f
gDf5   4        t     u  [[[    (
S  C1:t17
gC5    4        t     u  ===
S  C1:t17
gBf4   4        t     u  ]]]
S  C1:t17
C5     2        q     d         )(
measure 139
Ef5    2        q f   d          )
Af4    2        q f   u         .
C5     2        q     d         .
Ef4    2        q f   u         (r
S   C34:uwn4s25t75f
measure 140
Af4    2        q f   u         )
C4     2        q     u         .
Ef4    2        q f   u         .
C4     1        e     u  [      (p
Ef4    1        e     u  ]      )
measure 141
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 142
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      (
C5     1        e     u  =      )
Af4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 143
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 144
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      (
C5     1        e     u  =      )
Af4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 145
Df4    1        e f   u  [      .
Ef4    1        e f   u  =      .
C4     1        e     u  =      .
Ef4    1        e     u  ]      .
Bf3    1        e f   u  [      .
Ef4    1        e     u  =      .
Df4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 146
*               D       poco cresc.
P   C17:f33
C4     1        e     u  [      (
Ef4    1        e f   u  =      )
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   d  [      (
Df5    1        e f   d  =      )
C5     1        e     d  =      .
Bf4    1        e f   d  ]      .
measure 147
A4     1        e n   u  [      .+
C5     1        e     u  =      .
Gf4    1        e f   u  =      .
C5     1        e     u  ]      .
F4     1        e     u  [      .
C5     1        e     u  =      .
Ef4    1        e f   u  =      .
C5     1        e     u  ]      .
measure 148
D4     1        e n   u  [      (+
F4     1        e     u  =      )
Bf4    1        e f   u  =      .
D5     1        e     u  ]      .
F5     1        e     d  [      (
Ef5    1        e f   d  =      )
D5     1        e     d  =      .
C5     1        e     d  ]      .
measure 149
B4     1        e n   d  [      .+
D5     1        e     d  =      .
Af4    1        e f   d  =      .
D5     1        e     d  ]      .
G4     1        e     u  [      .
D5     1        e     u  =      .
F4     1        e     u  =      .
D5     1        e     u  ]      .
measure 150
*               D       pi\8u cresc.
P   C17:f33
Ef4    1        e f   u  [      (
G4     1        e     u  =      )
C5     1        e     u  =      .
Ef5    1        e f   u  ]      .
G5     1        e     d  [      (
Ef5    1        e     d  =      )
D5     1        e     d  =      .
C5     1        e     d  ]      .
measure 151
Af5    1        e f   d  [      .
G5     1        e     d  =      .
F5     1        e     d  =      .
Ef5    1        e f   d  ]      .
D5     1        e     d  [      .
C5     1        e     d  =      .
B4     1        e n   d  =      .+
C5     1        e     d  ]      .
measure 152
B4     2        q     d         f.
G5     4        h     d         >
B4     2        q     d         r
S   C33:uhn4s25t75e
measure 153
C5     2        q     d         .
D5     2        q     d         .
Ef5    2        q f   d         .
F#5    2        q #   d         r
S   C33:uhn4s25t75e
measure 154
G5     2        q     d
G5     4        h     d         >
B4     2        q n   d         +r
S   C34:uhn4s25t75e
measure 155
C5     2        q     d         .
D5     2        q     d         .
Ef5    2        q f   d         .
F#5    2        q #   d         .
measure 156
G5     1        e     d  [      fp.
G5     1        e     d  =      (
A5     1        e n   d  =      +
G5     1        e     d  ]
F#5    1        e #   d  [
G5     1        e     d  =
A5     1        e     d  =
G5     1        e     d  ]      )
measure 157
rest   1        e
*               D       cresc.
P   C17:f33
A5     1        e     d  [      (
B5     1        e n   d  =      +
A5     1        e     d  ]
G#5    1        e #   d  [
A5     1        e     d  =
B5     1        e     d  =
A5     1        e     d  ]      )
measure 158
rest   1        e
B5     1        e     d  [      (
C6     1        e     d  =
B5     1        e     d  ]
A5     1        e     d  [
B5     1        e     d  =
C6     1        e     d  =
B5     1        e     d  ]      )
measure 159
rest   1        e
C6     1        e     d  [      (f
D6     1        e     d  =
C6     1        e     d  ]
B5     1        e     d  [
C6     1        e     d  =
D6     1        e     d  =
C6     1        e     d  ]      )
measure 160
rest   1        e
D6     1        e     d  [      (
E6     1        e     d  =
D6     1        e     d  ]
C#6    1        e #   d  [
D6     1        e     d  =
E6     1        e n   d  =      +
D6     1        e     d  ]      )
measure 161
F6     2        q     d         .
D6     2        q     d         .
B5     2        q     d         .
G5     2        q     d         .
measure 162
F5     8        w     d         F
measure 163
*               D       !1p !33dolce
E5     4-       h     d        -(
E5     1        e     d  [
G5     1        e     d  =
F5     1        e     d  =
A5     1        e     d  ]      )
measure 164
G5     1        e     d         .
rest   1        e
G5     2        q     d         (
E5     1        e     d         ).
rest   1        e
F5     2        q     d         (
measure 165
D5     1        e     d         ).
rest   1        e
E5     2        q     d         (
C5     1        e     d         ).
rest   1        e
E5     1        e     d  [      (
D5     1        e     d  ]      )
measure 166
G4     2        q     u         .
G4     2        q     u         .
G4     2        q     u         .
E5     1        e     d  [      (
D5     1        e     d  ]      )
measure 167
F4     2        q     u         .
F4     2        q     u         .
F4     2        q     u         .
D5     2        q     d         (
measure 168
E4     1        e     u         ).
rest   1        e
C5     2        q     d         (
D4     1        e     u         ).
rest   1        e
A4     2        q     u         (
measure 169
C4     4        h     u         )
gE4    0        e     u         (
S  C1:pt10
D4     3        q.    u         )(
C4     1        e     u          )
measure 170
C4     1        e     u  [      .
E4     1        e     u  =      .
G4     1        e     u  =      .
B4     1        e     u  ]      .
*               E   0
C5     1        e     d  [      .
D5     1        e     d  =      .
E5     1        e     d  =      .
*               F   13
F5     1        e     d  ]      .
measure 171
G5     8-       w     d        -
measure 172
G5     8-       w     d        -
measure 173
G5     8-       w     d        -
measure 174
G5     1        e     d         .
rest   1        e
G5     2        q     d         (
E5     1        e     d         ).
rest   1        e
F5     2        q     d         (
measure 175
D5     1        e     d         ).
rest   1        e
E5     2        q     d         (
C5     1        e     d         ).
rest   1        e
E5     1        e     d  [      (
D5     1        e     d  ]      )
measure 176
G4     2        q     u         .
G4     2        q     u         .
G4     2        q     u         .
E5     1        e     d  [      (
D5     1        e     d  ]      )
measure 177
F4     2        q     u         .
F4     2        q     u         .
F4     2        q     u         .
D5     2        q     d         (
measure 178
E4     1        e     u         ).
rest   1        e
rest   2        q
rest   2        q
G5     2        q     d         (
measure 179
Bf4    1        e f   d         ).pp
rest   1        e
rest   2        q
rest   2        q
Bf5    2        q f   d         (
measure 180
C#5    1        e #   d         ).
rest   1        e
rest   2        q
rest   2        q
D6     2        q     d         (f
measure 181
D5     1        e     d         ).
rest   1        e
A5     2        q     d         (
A4     1        e     u         ).
rest   1        e
F5     2        q     d         (
measure 182
F4     1        e     u         ).
rest   1        e
D5     2        q     d         (
D4     1        e     u         ).
rest   1        e
B4     2        q n   d         (+
measure 183
B3     1        e     u         ).
rest   1        e
G4     2        q     u         (
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
measure 184
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
measure 185
Af3    6        h.f   u         )Z
B3     2        q     u         (
measure 186
C4     1        e     u         ).
rest   1        e
E4     2        q     u         (
F4     1        e     u         ).
rest   1        e
G4     2        q     u         (
measure 187
Af4    1        e f   u         ).
rest   1        e
B4     2        q     d         (
C5     1        e     d         ).
rest   1        e
E5     2        q     d         (
measure 188
F5     1        e     d         ).
rest   1        e
G5     2        q     d         (
Af5    1        e f   d         ).
rest   1        e
B5     2        q     d         (
measure 189
C6     1        e     d         ).
rest   1        e
D6     2        q     d         (
Ef6    1        e f   d         ).
rest   1        e
Ef6    2        q     d
measure 190
Ef6    4-       h f   d        -
Ef6    1        e     d  [
B5     1        e     d  =      .
C6     1        e     d  =      .
D6     1        e     d  ]      .
measure 191
Ef6    1        e f   d  [      .
B5     1        e     d  =      .
C6     1        e     d  =      .
D6     1        e     d  ]      .
Ef6    1        e     d  [      .
B5     1        e     d  =      .
C6     1        e     d  =      .
D6     1        e     d  ]      .
measure 192
Ef6    1        e f   d  [      .
B5     1        e     d  =      .
C6     1        e     d  =      .
D6     1        e     d  ]      .
Ef6    1        e     d  [      .
B5     1        e     d  =      .
C6     1        e     d  =      .
D6     1        e     d  ]      .
measure 193
E6     1        e n   d  [      (ff+
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
measure 194
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
measure 195
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
measure 196
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
measure 197
E6     1        e     d  [      (
F6     1        e     d  =      )
E6     1        e     d  =      .
D6     1        e     d  ]      .
E6     2        q     d
E6     2        q     d         (r
S   C34:uhn4s25t75e
measure 198
F6     2        q     d         )
D6     2        q     d         .
E6     2        q     d         .
C6     2        q     d         (r
S   C34:uwn4s25t75f
measure 199
D6     2        q     d         )
B5     2        q     d         .
C6     2        q     d         .
G5     2        q     d         (r
S   C34:uwn4s25t75e
measure 200
A5     2        q     d         )
F#5    2        q #   d         .
G5     2        q     d         .
E5     2        q     d         (rh
S   C34:uhn4s25t75e
measure 201
F5     2        q n   d         )+
D#5    2        q #   d         .
E5     2        q     d         .
C#5    2        q #   d         (rh
S   C34:uhn4s25t75e
measure 202
D5     2        q n   d         )+
B4     2        q     d         .
C5     2        q n   d         .+
C#5    2        q #   d         .
measure 203
*               E   0
D5     1        e     d  [      (
C#5    1        e #   d  =
E5     1        e     d  =
D5     1        e     d  ]
F5     1        e     d  [
E5     1        e     d  =
G5     1        e     d  =
*               F   15
F5     1        e     d  ]      )
measure 204
*               E   15
A5     1        e     d  [      (
G5     1        e     d  =
Bf5    1        e f   d  =
A5     1        e     d  ]
G5     1        e     d  [
F5     1        e     d  =
E5     1        e     d  =
*               F   0
D5     1        e     d  ]      )
measure 205
C5     4        h     d
gE5    0        e     u         (
S  C1:pt10
D5     3        q.    d         )(Z
C5     1        e     d          )
measure 206
C5     2        q     d
F#5    2        q #   d         .(mf>
F#5    2        q     d         .)
F#5    2        q     d         (r
S   C34:uhn4s25t75e
measure 207
G5     2        q     d         )
A5     2        q     d         .(>
A5     2        q     d         .
A5     2        q     d         .)
measure 208
C5     4        h     d
gE5    0        e     u         (
S  C1:pt30
D5     1        e     d  [      )(
C5     1        e     d  =
D5     1        e     d  =
E5     1        e     d  ]       )
measure 209
C5     2        q     d
rest   2        q
rest   4        h
measure 210
rest   2        q
F#4    2        q #   u         .(p
F#4    2        q     u         .)
F#4    2        q     u         (
measure 211
G4     2        q     u         )
A4     2        q     u         .(>
A4     2        q     u         .
A4     2        q     u         .)
measure 212
C4     4        h     u
gE4    0        e     u         (
S  C1:pt8
D4     4        h     u         )
measure 213
C4     1        e     u  [      (
G3     1        e     u  =      )
G4     1        e     u  =      .
E4     1        e     u  ]      .
C4     1        e     u  [      (
G3     1        e     u  =      )
C5     1        e     u  =      .
G4     1        e     u  ]      .
measure 214
*               D       cresc.
P   C17:f33
E4     1        e     u  [      (
C4     1        e     u  =      )
E5     1        e     u  =      .
C5     1        e     u  ]      .
G4     1        e     u  [      (
E4     1        e     u  =      )
G5     1        e     u  =      .
E5     1        e     u  ]      .
measure 215
C5     1        e     d  [      (
G4     1        e     d  =      )
C6     1        e     d  =      .
C6     1        e     d  ]      .
C6     1        e     d  [
C6     1        e     d  =
C6     1        e     d  =
C6     1        e     d  ]
measure 216
C6     1        e     d  [      (
G5     1        e     d  =      )
E6     1        e     d  =      .
E6     1        e     d  ]      .
E6     1        e     d  [
E6     1        e     d  =
E6     1        e     d  =
E6     1        e     d  ]
measure 217
E6     1        e     d  [      (
C6     1        e     d  =      )
G6     1        e     d  =      .
G6     1        e     d  ]      .
G6     1        e     d  [
G6     1        e     d  =
G6     1        e     d  =
G6     1        e     d  ]
measure 218
G6     1        e     d  [      (f
E6     1        e     d  =      )
C7     1        e     d  =      .
C7     1        e     d  ]      .
C7     1        e     d  [
C7     1        e     d  =
C7     1        e     d  =
C7     1        e     d  ]
measure 219
C7     2        q     d
E4     1        e     u  [      (
G4     1        e     u  ]      )
F4     1        e n   u  [      (+
A4     1        e     u  =      )
G4     1        e     u  =      (
Bf4    1        e f   u  ]      )
measure 220
A4     2        q     u         .
A4     2        q     u         (pr
S   C35:uwn4s25t75e
B4     2        q n   d         +
C5     2        q     d         )
measure 221
C4     4        h     u
gE4    0        e     u         (
S  C1:pt10
D4     3        q.    u         )(
C4     1        e     u          )
measure 222
C4     1        e     u
rest   1        e
C5     2        q     d         (mf
B4     1        e     d         ).
rest   1        e
D5     2        q     d         (
measure 223
C5     1        e     d         ).
rest   1        e
E5     2        q     d         (
D5     1        e     d         ).
rest   1        e
F5     2        q     d         (
measure 224
E5     1        e     d         ).
rest   1        e
G5     2        q     d         (
F5     1        e     d         ).
rest   1        e
A5     2        q     d         (
measure 225
G5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
C6     2        q     d         (
measure 226
A5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
F5     2        q     d         (
measure 227
E5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
A4     2        q     u         (
measure 228
G4     1        e     u         ).
rest   1        e
rest   2        q
rest   2        q
D4     1        e     u  [      (
 G3    1        e     u
F4     1        e     u  ]
measure 229
E4     1        e     u  [
F4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]
E4     1        e     u  [
F4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]      )
back   8
G3     8        w     d
measure 230
E4     2        q     u
 G3    2        q     u         .
C5     2        q     d         .
E5     2        q     d         .
D4     1        e     u  [      (
 G3    1        e     u
F4     1        e     u  ]
measure 231
E4     1        e     u  [
F4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]
E4     1        e     u  [
F4     1        e     u  =
D4     1        e     u  =
F4     1        e     u  ]      )
back   8
G3     8        w     d
measure 232
E4     4        h     u
 G3    4        h     u
E5     4        h     d         f
 C5    4        h     d
measure 233
E4     4        h     u
 C4    4        h     u
rest   4        h
mheavy2                       :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/01/02} [KHM:4000451156]
TIMESTAMP: DEC/26/2001 [md5sum:82515b6cd4b62858a10382c46e6c3aac]
07/25/94 W Hewlett
WK#:54,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Vivace (First movement)
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:1/1  C:4  D:Vivace
E4     8-       w     u        -f
measure 2
E4     8-       w     u        -
measure 3
E4     6        h.    u
C4     2        q     u         .
measure 4
D4     2        q     u         .
C4     2        q     u         .
B3     2        q     u         .
C4     2        q     u         .
measure 5
D4     2        q     u         .
rest   2        q
rest   4        h
measure 6
rest   8
measure 7
B4     8-       w     u        -f
 D4    8-       w     u        -
measure 8
B4     8-       w     u        -
 D4    8-       w     u        -
measure 9
B4     4        h     u
 D4    4        h     u
rest   4        h
measure 10
rest   8
measure 11
rest   8
measure 12
rest   8
measure 13
Ef4    8-       w f   u        -f
measure 14
Ef4    8-       w     u        -
measure 15
Ef4    6        h.    u
Af3    2        q f   u         .
measure 16
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 17
Af3    2        q f   u         .
rest   2        q
rest   2        q
C4     2        q     u         .
measure 18
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 19
Af3    2        q f   u         .
rest   2        q
rest   2        q
C4     2        q     u         .
measure 20
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 21
Af3    2        q f   u         .
rest   2        q
rest   4        h
measure 22
rest   2        q
Ef4    2        q f   u         .(
Ef4    2        q     u         .)
Ef4    2        q     u         (
measure 23
E4     2        q n   u         )+
F4     2        q     u         .(
F4     2        q     u         .
F4     2        q     u         .)
measure 24
C4     4        h     u         (
B3     4        h n   u         )+
measure 25
C4     2        q     u
rest   2        q
rest   4        h
measure 26
rest   2        q
D5     2        q     d         .(p
D5     2        q     d         .)
D5     2        q     d         (
measure 27
E5     2        q     d         )
F5     2        q     d         .(>
F5     2        q     d         .
F5     2        q     d         .)
measure 28
C5     4        h     d         (
B4     4        h     d         )
measure 29
C5     2        q     d
rest   2        q
rest   4        h
measure 30
C5     8-       w     u        -f
 E4    8-       w     u        -
measure 31
C5     8-       w     u        -
 E4    8-       w     u        -
measure 32
C5     8-       w     u        -
 E4    8-       w     u        -
measure 33
C5     8        w     u
 E4    8        w     u
measure 34
C4     8        w     u         (
measure 35
B3     2        q     u         )
rest   2        q
rest   4        h
measure 36
Bf3    8        w f   u         (
measure 37
A3     2        q     u         )
rest   2        q
rest   4        h
measure 38
B3     4        h n   u          +
C4     2        q     u         .(
D4     2        q     u         .)
measure 39
C4     8-       w     u        -
measure 40
C4     8        w     u
measure 41
B3     8        w     u
measure 42
E4     8        w #   u
 C#4   8        w     u
measure 43
D4     2        q     u
rest   2        q
rest   2        q
A4     2        q     u         (
measure 44
B4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
B4     2        q     d         (
measure 45
C5     1        e n   d         )+
rest   1        e
rest   2        q
rest   2        q
C5     2        q     d         (
measure 46
B4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
B4     2        q     d         (
measure 47
C5     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
C5     2        q     d
measure 48
Bf4    8-       w f   d        -
measure 49
Bf4    8-       w     d        -
measure 50
Bf4    8-       w     d        -
measure 51
Bf4    8-       w     d        -
measure 52
Bf4    8-       w     d        -
measure 53
Bf4    8        w     d
measure 54
A4     4        h     u
D4     1        e     u  [
F#4    1        e #   u  =
A4     1        e     u  =
C#5    1        e #   u  ]
measure 55
D5     2        q     d
*               E   15
F#4    2        q #   u         (
G4     2        q     u
*               F   0
A4     2        q     u         )
measure 56
*               G       p
B4     2        q n   d         +
rest   2        q
rest   4        h
measure 57
rest   2        q
D5     2        q     d         .
rest   2        q
D5     2        q     d         .
measure 58
rest   2        q
D5     2        q     d         .
rest   2        q
E4     2        q     u         .
measure 59
D4     2        q     u         .
rest   2        q
rest   4        h
measure 60
D4     2        q     u         .
D4     2        q     u         .
D4     2        q     u         .
rest   2        q
measure 61
D4     2        q     u         .
rest   2        q
E4     2        q     u         .
rest   2        q
measure 62
B3     4        h     u         (
D4     2        q     u
C4     2        q     u         )
measure 63
B3     2        q     u
rest   2        q
rest   4        h
measure 64
*               D       dolce
P   C17:f33
B4     4-       h     d        -(
B4     1        e     d  [
D5     1        e     d  =
C5     1        e     d  =
E5     1        e     d  ]      )
measure 65
D5     1        e     d         .
rest   1        e
D5     2        q     d         (
B4     1        e     d         ).
rest   1        e
C5     2        q     d         (
measure 66
A4     1        e     u         ).
rest   1        e
B4     2        q     d         (
G4     1        e     u         ).
rest   1        e
B4     1        e     u  [      (
A4     1        e     u  ]      )
measure 67
D4     1        e     u         .
rest   1        e
D5     2        q     d         (
D4     1        e     u         ).
rest   1        e
D5     2        q     d         (
measure 68
D4     1        e     u         ).
rest   1        e
D5     2        q     d         (
D4     1        e     u         ).
rest   1        e
D5     2        q     d         (
measure 69
D4     2        q     u         ).
rest   2        q
rest   4        h
measure 70
A4     2        q     u         .
A4     2        q     u         .
A4     2        q     u         .
rest   2        q
measure 71
D4     2        q     u         .
rest   2        q
E4     2        q     u         .
rest   2        q
measure 72
B3     4        h     u         (
D4     2        q     u
C4     2        q     u         )
measure 73
B3     2        q     u
rest   2        q
rest   4        h
measure 74
B4     2        q     u
 D4    2        q     u
rest   2        q
rest   4        h
measure 75
*               D       cresc.
P   C17:f33
B4     2        q     u
 D4    2        q     u
B3     1        e     u  [      .
D4     1        e     u  ]      .
G4     1        e     u  [      (
B4     1        e     u  =      )
B3     1        e     u  =      .
D4     1        e     u  ]      .
measure 76
G4     1        e     u  [      (f
B4     1        e     u  =      )
D4     1        e     u  =      .
G4     1        e     u  ]      .
B4     1        e     u  [      (
D5     1        e     u  =      )
D4     1        e     u  =      .
G4     1        e     u  ]      .
measure 77
B4     1        e     d  [      (
D5     1        e     d  =      )
B4     1        e     d  =      .
D5     1        e     d  ]      .
G5     1        e     d  [      (
B5     1        e     d  =      )
B4     1        e     d  =      .
D5     1        e     d  ]      .
measure 78
G5     1        e     d  [      (
B5     1        e     d  ]      )
rest   2        q
rest   4        h
measure 79
rest   8
measure 80
B3     4        h     u         (p
D4     2        q     u
C4     2        q     u         )
measure 81
B3     1        e     u
rest   1        e
B3     2        q     u         (mf
A3     1        e     u         ).
rest   1        e
C4     2        q     u         (
measure 82
B3     1        e     u         ).
rest   1        e
G4     2        q     u         (
F#4    1        e #   u         ).
rest   1        e
A4     2        q     u         (
measure 83
G4     1        e     u         ).
rest   1        e
B4     2        q     d         (
A4     1        e     u         ).
rest   1        e
C5     2        q     d         (
measure 84
B4     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
A#4    2        q #   u         (
measure 85
B4     1        e     d         ).
rest   1        e
A#4    2        q #   u         (
B4     1        e     d         ).
rest   1        e
C#5    2        q #   d         (
measure 86
D5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
C#4    2        q #   u         (p
measure 87a     start-end1
D4     1        e     u         ).
rest   1        e
C#4    2        q #   u         (
D4     1        e     u         ).
rest   1        e
D#4    2        q #   u
mheavy2 87b     stop-end1   start-end2  :|
D4     1        e     u
rest   1        e
D#4    2        q #   u         (
E4     1        e     u         ).
rest   1        e
F#4    2        q #   u
mheavy3 88                  disc-end2  |:
G4     8        w     u         f
measure 89
E4     8-       w     u        -
 G3    8-       w     u        -
measure 90
E4     6        h.    u
 G3    6        h.    u
G4     2        q     u         (r
S   C34:uwn4s25t75e
measure 91
Bf4    2        q f   d         )
E4     2        q     u         .
G4     2        q     u         .
Bf3    2        q f   u         (r
S   C34:uwn4s25t75f
measure 92
A3     2        q     u         )
C4     2        q     u         .
F4     2        q     u         .
G4     2        q     u         (r
S   C34:uwn4s25t75e
measure 93
F4     2        q     u         )
rest   2        q
rest   2        q
E5     2        q     d         (rp
S   C34:uhn4s25t75e
measure 94
F5     2        q     d         )
rest   2        q
rest   2        q
G4     2        q     u         (r
S   C34:uwn4s25t75e
measure 95
A4     2        q     u         )
F4     2        q     u         .
C4     2        q     u         .
F#5    2        q #   d         (r
S   C34:uhn4s25t75e
measure 96
G5     2        q     d         )
rest   2        q
rest   2        q
gBf4   4        t     u  [[[    (
S  C1:t17
gA4    4        t     u  ===
S  C1:t17
gG4    4        t     u  ]]]
S  C1:t17
A4     2        q     u         )(
measure 97
Bf4    2        q f   d          )
G4     2        q     u         .
D4     2        q     u         .
rest   2        q
measure 98
rest   2        q
Ef4    4        h f   u          (mf
Bf3    2        q f   u          )
measure 99
*               D       cresc.
P   C17:f33
D4     2        q     u          .
rest   2        q
rest   2        q
D5     2        q     d          (
measure 100
C#5    2        q #   d          )f
rest   2        q
rest   2        q
E5     2        q     d          (
measure 101
F5     1        e     d          )
rest   1        e
rest   2        q
rest   2        q
F5     2        q     d          (
measure 102
E5     1        e     d          )
rest   1        e
rest   2        q
rest   2        q
E5     2        q     d          (r
S   C34:uhn4s25t75e
measure 103
F5     1        e     d          )
rest   1        e
rest   2        q
rest   2        q
F5     2        q     d          (r
S   C33:uwn4s25t75f
measure 104
E5     1        e     d          )
rest   1        e
rest   2        q
rest   2        q
A3     2        q     u
measure 105
D4     1        e     u  [       (
D5     1        e     u  =       )
Ef5    1        e f   u  =       (
D5     1        e     u  ]       )
C#5    1        e #   d  [       .
D5     1        e     d  =       .
C5     1        e n   d  =       .
D5     1        e     d  ]       .
measure 106
Bf4    1        e f   d  [       .
D5     1        e     d  =       .
A4     1        e     d  =       .
D5     1        e     d  ]       .
G4     1        e     u  [       .
D5     1        e     u  =       .
F4     1        e     u  =       .
D5     1        e     u  ]       .
measure 107
E4     1        e n   u  [       (+
C5     1        e     u  =       )
D5     1        e     u  =       (
C5     1        e     u  ]       )
B4     1        e n   d  [       .+
C5     1        e     d  =       .
Bf4    1        e f   d  =       .
C5     1        e     d  ]       .
measure 108
A4     1        e     u  [       .
C5     1        e     u  =       .
G4     1        e     u  =       .
C5     1        e     u  ]       .
F4     1        e     u  [       .
C5     1        e     u  =       .
E4     1        e     u  =       .
C5     1        e     u  ]       .
measure 109
D4     1        e     u  [       (
Bf4    1        e f   u  =       )
C5     1        e     u  =       (
Bf4    1        e     u  ]       )
C5     1        e     u  [       .
Bf4    1        e     u  =       .
A4     1        e     u  =       .
Bf4    1        e     u  ]       .
measure 110
G4     1        e     u  [       .
Bf4    1        e f   u  =       .
F4     1        e     u  =       .
Bf4    1        e     u  ]       .
E4     1        e n   u  [       .+
Bf4    1        e     u  =       .
D4     1        e     u  =       .
Bf4    1        e     u  ]       .
measure 111
C#4    2        q #   u
E4     4        h     u          >
C#4    2        q     u
measure 112
D4     2        q     u
rest   2        q
rest   2        q
D4     2        q     u
measure 113
D5     1        e     d  [       .
Ef5    1        e f   d  =       .
C5     1        e n   d  =       .+
D5     1        e     d  ]       .
Bf4    1        e f   d  [       .
C5     1        e     d  =       .
A4     1        e     d  =       .
Bf4    1        e     d  ]       .
measure 114
G4     1        e     u  [       .
A4     1        e     u  =       .
F4     1        e     u  =       .
G4     1        e     u  ]       .
E4     1        e     u  [       .
Bf4    1        e f   u  =       .
A4     1        e     u  =       .
G4     1        e     u  ]       .
measure 115
F4     1        e     u  [       (
C5     1        e     u  =       )
D5     1        e     u  =       (
C5     1        e     u  ]       )
B4     1        e n   u  [       .+
C5     1        e     u  =       .
F4     1        e     u  =       .
C5     1        e     u  ]       .
measure 116
E4     1        e     u  [       (
C5     1        e     u  =       )
D5     1        e     u  =       (
C5     1        e     u  ]       )
B4     1        e n   u  [       .+
C5     1        e     u  =       .
E4     1        e     u  =       .
C5     1        e     u  ]       .
measure 117
F4     1        e     u  [       (
C5     1        e     u  =       )
D5     1        e     u  =       (
C5     1        e     u  ]       )
B4     1        e     u  [       .
C5     1        e     u  =       .
F4     1        e     u  =       .
C5     1        e     u  ]       .
measure 118
E4     1        e     u  [       (
C5     1        e     u  =       )
D5     1        e     u  =       (
C5     1        e     u  ]       )
B4     1        e n   u  [       .+
C5     1        e     u  =       .
E4     1        e     u  =       .
C5     1        e     u  ]       .
measure 119
F4     2        q     u
rest   2        q
rest   4        h
measure 120
rest   8
measure 121
rest   2        q
*               D       decresc.
P   C17:f33
A4     2        q     u          (
B4     1        e     d          ).
rest   1        e
C#5    2        q #   d          (
measure 122
D5     1        e     d          ).
rest   1        e
rest   2        q
rest   2        q
C#5    2        q #   d          (p
measure 123
D5     1        e     d          ).
rest   1        e
C#5    2        q #   d          (
D5     1        e     d          ).
rest   1        e
C#5    2        q     d          (
measure 124
D5     1        e     d          ).
rest   1        e
rest   2        q
rest   2        q
C#4    2        q #   u          (
measure 125
D4     1        e     u          ).
rest   1        e
C#4    2        q #   u          (
D4     1        e     u          ).
rest   1        e
D#4    2        q #   u
measure 126
E4     8-       w     u        -f
 G3    8-       w     u        -
measure 127
E4     8-       w     u        -
 G3    8-       w     u        -
measure 128
E4     6        h.    u
 G3    6        h.    u
C4     2        q     u         .
measure 129
D4     2        q     u         .
C4     2        q     u         .
B3     2        q     u         .
C4     2        q     u         .
measure 130
D4     2        q     u         .
rest   2        q
rest   4        h
measure 131
rest   8
measure 132
B4     8-       w     u        -f
 D4    8-       w     u        -
measure 133
B4     8-       w     u        -
 D4    8-       w     u        -
measure 134
B4     4        h     u
 D4    4        h     u
rest   4        h
measure 135
rest   8
measure 136
rest   8
measure 137
rest   8
measure 138
C4     1        e     u  [      .f
Ef4    1        e f   u  =      .
Af4    1        e f   u  =      .
C5     1        e     u  ]      .
Ef5    1        e f   u  [      .
C5     1        e     u  =      .
Af4    1        e     u  =      .
Ef4    1        e     u  ]      .
measure 139
C4     2        q     u
Ef4    4        h f   u
Ef4    2        q     u
measure 140
Ef4    6        h.f   u
Af3    2        q f   u         .p
measure 141
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 142
Af3    2        q f   u
rest   2        q
rest   2        q
C4     2        q     u         .
measure 143
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 144
Af3    2        q f   u         .
rest   2        q
rest   2        q
C4     2        q     u         .
measure 145
Bf3    2        q f   u         .
Af3    2        q f   u         .
G3     2        q     u         .
Bf3    2        q     u         .
measure 146
*               D       poco cresc.
P   C17:f33
C4     2        q     u
Ef4    4        h f   u
E4     2        q n   u         r
S   C33:uhn4s25t75e
measure 147
F4     2        q     u         .
Ef4    2        q f   u         .
Df4    2        q f   u         .
C4     2        q     u         .
measure 148
Bf3    2        q f   u         .
F4     4        h     u         >
F#4    2        q #   u         r
S   C33:uhn4s25t75e
measure 149
G4     2        q     u         .
F4     2        q n   u         .+
Ef4    2        q f   u         .
D4     2        q     u         .
measure 150
*               D       pi\u8 cresc.
P   C17:f33
Ef4    2        q f   u
G4     4        h     u         >
C5     2-       q     d        -
measure 151
C5     2        q     d
Af4    1        e f   u  [      .
G4     1        e     u  ]      .
F4     1        e     u  [      .
Ef4    1        e f   u  =      .
D4     1        e     u  =      .
Ef4    1        e     u  ]      .
measure 152
D4     2        q     u         f
rest   2        q
rest   4        h
measure 153
rest   2        q
B3     2        q     u         r.
S   C33:uhn4s25t75e
C4     2        q     u          .
C5     2        q     d          .
measure 154
B4     2        q     d
rest   2        q
rest   4        h
measure 155
rest   8
measure 156
G5     8        w     d         fp
measure 157
*               D       cresc.
P    C17:f33
F#5    8        w #   d
measure 158
F5     8        w n   d         +
measure 159
E5     8        w n   d         +f
measure 160
B4     8        w     d
measure 161
B4     8-       w     d        -
measure 162
B4     8        w     d         F
measure 163
C5     2        q     d         p
rest   2        q
rest   4        h
measure 164
rest   2        q
G4     2        q     u         .
rest   2        q
G4     2        q     u         .
measure 165
rest   2        q
G4     2        q     u         .
rest   2        q
A3     2        q     u         .
measure 166
G3     2        q     u         .
rest   2        q
rest   4        h
measure 167
D4     2        q     u         .
D4     2        q     u         .
D4     2        q     u         .
rest   2        q
measure 168
E4     2        q     u         .
rest   2        q
D4     2        q     u         .
rest   2        q
measure 169
C4     4        h     u         (
B3     4        h     u         )
measure 170
C4     2        q     u
rest   2        q
rest   4        h
measure 171
*               D       dolce
P    C17:f33
E5     4-       h     d        -(
E5     1        e     d  [
G5     1        e     d  =
F5     1        e     d  =
A5     1        e     d  ]      )
measure 172
G5     1        e     d         .
rest   1        e
G5     2        q     d         (
E5     1        e     d         ).
rest   1        e
F5     2        q     d         (
measure 173
D5     1        e     d         ).
rest   1        e
E5     2        q     d         (
C5     1        e     d         ).
rest   1        e
E5     1        e     d  [      (
D5     1        e     d  ]      )
measure 174
G4     2        q     u         .
G4     2        q     u         .
rest   2        q
G4     2        q     u         .
measure 175
rest   2        q
G4     2        q     u         .
rest   2        q
A4     2        q     u         (
measure 176
G4     2        q     u         ).
rest   2        q
rest   4        h
measure 177
D4     2        q     u         .
D4     2        q     u         .
D4     2        q     u         .
rest   2        q
measure 178
C4     2        q     u         .
rest   2        q
rest   4        h
measure 179
G4     2        q     u         .pp
rest   2        q
rest   4        h
measure 180
Bf4    2        q f   d         .
rest   2        q
rest   4        h
measure 181
A4     2        q     u         f
rest   2        q
rest   2        q
F5     2        q     d         (
measure 182
F4     1        e     u         ).
rest   1        e
D5     2        q     d         (
D4     1        e     u         ).
rest   1        e
B4     2        q     d         (
measure 183
B3     1        e     u         ).
rest   1        e
G4     2        q     u         (
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
measure 184
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
G3     1        e     u         ).
rest   1        e
G4     2        q     u         (
measure 185
Af3    6        h.f   u         )Z
B3     2        q     u         (
measure 186
C4     6        h.    u         )
E4     2        q     u
measure 187
F4     8-       w     u        -
measure 188
F4     8-       w     u        -
measure 189
F4     8        w     u
measure 190
F#4    8        w #   u
measure 191
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
measure 192
F#5    2        q #   d         .
F#5    2        q     d         .
F#5    2        q     d         .
F#5    2        q     d         .
measure 193
C6     1        e     d  [      (ff
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
measure 194
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
measure 195
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
measure 196
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
measure 197
C6     1        e     d  [      (
D6     1        e     d  =      )
C6     1        e     d  =      .
B5     1        e     d  ]      .
C6     2        q     d
C6     2        q     d         (r
S   C34:uwn4s25t75f
measure 198
D6     2        q     d         )
B5     2        q     d         .
C6     2        q     d         .
G5     2        q     d         (r
S   C34:uwn4s25t75e
measure 199
A5     2        q     d         )
F5     2        q     d         .
G5     2        q     d         .
D5     2        q     d         (r
S   C34:uwn4s25t75e
measure 200
E5     2        q     d         )
C5     2        q     d         .
D5     2        q     d         .
B4     2        q     d         (r
S   C34:uhn4s25t75e
measure 201
C5     2        q     d         )
A4     2        q     u         .
B4     2        q     d         .
G4     2        q     u         (r
S   C33:uwn4s25t75e
measure 202
A4     2        q     u         )
F4     2        q     u         .
G4     2        q     u         .
Bf4    2        q f   d         .
measure 203
A4     2        q     u
rest   2        q
rest   4        h
measure 204
rest   8
measure 205
E4     4        h     u         (
G4     2        q     u
F4     2        q     u         )
measure 206
E4     2        q     u
D5     2        q     d         .(mf>
D5     2        q     d         .)
D5     2        q     d         (
measure 207
E5     2        q     d         )
F5     2        q     d         .(>
F5     2        q     d         .
F5     2        q     d         .)
measure 208
E4     4        h     u
gG4    0        e     u         (
F4     1        e     u  [      )(
E4     1        e     u  =
F4     1        e     u  =
G4     1        e     u  ]       )
measure 209
E4     2        q     u
rest   2        q
rest   4        h
measure 210
rest   2        q
Ef4    2        q f   u         .(p
Ef4    2        q     u         .)
Ef4    2        q     u         (
measure 211
E4     2        q n   u         )+
F4     2        q     u         .(>
F4     2        q     u         .
F4     2        q     u         .)
measure 212
C4     4        h     u         (
B3     4        h     u         )
measure 213
C4     2        q     u
rest   2        q
rest   4        h
measure 214
E4     2        q     u
 G3    2        q     u
rest   2        q
rest   4        h
measure 215
*               D       cresc.
P   C17:f33
E4     2        q     u
E4     1        e     u  [      .
G4     1        e     u  ]      .
C5     1        e     u  [      (
E5     1        e     u  =      )
E4     1        e     u  =      .
G4     1        e     u  ]      .
measure 216
C5     1        e     d  [      (
E5     1        e     d  =      )
G4     1        e     d  =      .
C5     1        e     d  ]      .
E5     1        e     d  [      (
G5     1        e     d  =      )
G4     1        e     d  =      .
C5     1        e     d  ]      .
measure 217
E5     1        e     d  [      (
G5     1        e     d  =      )
C5     1        e     d  =      .
E5     1        e     d  ]      .
G5     1        e     d  [      (
C6     1        e     d  =      )
C5     1        e     d  =      .
E5     1        e     d  ]      .
measure 218
G5     1        e     d  [      (f
C6     1        e     d  =      )
C6     1        e     d  =      .
G5     1        e     d  ]      .
E5     1        e     d  [      (
C5     1        e     d  =      )
C6     1        e     d  =      .
G5     1        e     d  ]      .
measure 219
E5     1        e     d  [      (
C5     1        e     d  ]      )
rest   2        q
rest   4        h
measure 220
rest   8
measure 221
C4     4        h     u         (p
B3     4        h     u         )
measure 222
C4     1        e     u
rest   1        e
E4     2        q     u         (mf
D4     1        e     u         ).
rest   1        e
F4     2        q     u         (
measure 223
E4     1        e     u         ).
rest   1        e
C5     2        q     d         (
B4     1        e     d         ).
rest   1        e
D5     2        q     d         (
measure 224
C5     1        e     d         ).
rest   1        e
E5     2        q     d         (
D5     1        e     d         ).
rest   1        e
F5     2        q     d         (
measure 225
E5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
C5     2        q     d         (
measure 226
A5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
D5     2        q     d         (
measure 227
C5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
F4     2        q     u         (
measure 228
E4     1        e     u         ).
rest   1        e
rest   2        q
rest   2        q
B3     2        q     u         .
measure 229
C4     2        q     u         .
B3     2        q     u         .
C4     2        q     u         .
B3     2        q     u         .
measure 230
C4     2        q     u         .
rest   2        q
rest   2        q
B3     2        q     u         .
measure 231
C4     2        q     u         .
B3     2        q     u         .
C4     2        q     u         .
B3     2        q     u         .
measure 232
C4     4        h     u
C5     4        h     u         f
 E4    4        h     u
measure 233
C5     4        h     u
 E4    4        h     u
rest   4        h
mheavy2                         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/01/03} [KHM:4000451156]
TIMESTAMP: DEC/26/2001 [md5sum:25034f57e8cc28a52d50265018a257d7]
07/25/94 W Hewlett
WK#:54,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Vivace (First movement)
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:1/1  C:13  D:Vivace
G3     8-       w     u        -f
measure 2
G3     8-       w     u        -
measure 3
G3     4        h     u
rest   4        h
measure 4
rest   8
measure 5
rest   8
measure 6
rest   8
measure 7
F4     8-       w     d        -f
measure 8
F4     8-       w     d        -
measure 9
F4     6        h.    d
B3     1        e     u  [      (
C4     1        e     u  ]      )
measure 10
D4     2        q     d         .
C4     2        q     d         .
D4     2        q     d         .
B3     2        q     u         .
measure 11
C4     2        q     d         .
rest   2        q
rest   4        h
measure 12
rest   8
measure 13
C4     8-       w     d        -f
measure 14
C4     8-       w     d        -
measure 15
C4     4        h     d
rest   4        h
measure 16
rest   4        h
rest   2        q
G3     2        q     u         .
measure 17
Af3    2        q f   u         .
C4     2        q     d         .
rest   4        h
measure 18
rest   4        h
rest   2        q
G3     2        q     u         .
measure 19
Af3    2        q f   u         .
C4     2        q     d         .
rest   4        h
measure 20
rest   4        h
rest   2        q
G3     2        q     u         .
measure 21
Af3    2        q f   u         .
C4     2        q     d         .
rest   4        h
measure 22
rest   2        q
C4     2        q     d         .(
C4     2        q     d         .)
C4     2-       q     d        -
measure 23
C4     2        q     d
C4     2        q     d         .(>
C4     2        q     d         .
C4     2        q     d         .)
measure 24
E3     4        h     u          (
G3     2        q     u
F3     2        q     u          )
measure 25
E3     2        q     u
rest   2        q
rest   4        h
measure 26
rest   2        q
C5     2        q     d         p.(
C5     2        q     d          .)
C5     2-       q     d        -
measure 27
C5     2        q     d
C5     2        q     d         .(>
C5     2        q     d         .
C5     2        q     d         .)
measure 28
E4     4        h     d          (
G4     2        q     d
F4     2        q     d          )
measure 29
E4     2        q     d
rest   2        q
rest   4        h
measure 30
E4     8-       w     d        -f
 A3    8-       w     d        -
measure 31
E4     8-       w     d        -
 A3    8-       w     d        -
measure 32
E4     8-       w     d        -
 A3    8-       w     d        -
measure 33
E4     8        w     d
 A3    8        w     d
measure 34
F4     4        h     d
rest   4        h
measure 35
rest   2        q
G#3    2        q #   u         .
B3     2        q     u         .
E4     2        q     d         .
measure 36
rest   8
measure 37
rest   2        q
F3     2        q     u         .
A3     2        q     u         .
D4     2        q     d         .
measure 38
G3     8        w     u
measure 39
G3     8        w     u
measure 40
A3     4        h     u
F#4    4        h #   d
measure 41
G4     8        w     d
measure 42
G4     8        w f   d
 Bf3   8        w     d
measure 43
F#4    2        q     d
 A3    2        q #   d
rest   2        q
rest   2        q
D4     2-       q     d        -
measure 44
D4     1        e     d
rest   1        e
rest   2        q
rest   2        q
G4     2        q     d         (
measure 45
A4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d         (
measure 46
G4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
G4     2        q     d         (
measure 47
A4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d
measure 48
D4     8-       w     d        -
measure 49
D4     8        w     d
measure 50
G4     8-       w     d        -
measure 51
G4     8-       w     d        -
measure 52
G4     8-       w     d        -
measure 53
G4     8        w     d
measure 54
F#4    4        h #   d
D4     1        e     d  [
F#4    1        e     d  =
A4     1        e     d  =
C#5    1        e #   d  ]
measure 55
D5     2        q     d
*               E   15
D4     2        q     d         (
E4     2        q     d
*               F   0
F#4    2        q #   d         )
measure 56
*               D       !1p !33dolce
G4     4-       h     d        -(
G4     1        e     d  [
B4     1        e     d  =
A4     1        e     d  =
C5     1        e n   d  ]      )+
measure 57
B4     1        e     d         .
rest   1        e
B4     2        q     d         (
G4     1        e     d         ).
rest   1        e
A4     2        q     d         (
measure 58
F#4    1        e #   d         ).
rest   1        e
G4     2        q     d         (
B3     1        e     u         ).
rest   1        e
C4     2        q     d         (
measure 59
D4     2        q     d         ).
rest   2        q
rest   4        h
measure 60
A3     2        q     u         .
A3     2        q     u         .
A3     2        q     u         .
rest   2        q
measure 61
G3     2        q     u         .
rest   2        q
G3     2        q     u         .
rest   2        q
measure 62
G3     4        h     u         (
F#3    4        h #   u         )
measure 63
G3     2        q     u
rest   2        q
rest   4        h
measure 64
*               D       dolce
P   C17:f33
G4     4-       h     d        -(
G4     1        e     d  [
B4     1        e     d  =
A4     1        e     d  =
C5     1        e     d  ]      )
measure 65
B4     1        e     d         .
rest   1        e
B4     2        q     d         (
G4     1        e     d         ).
rest   1        e
A4     2        q     d         (
measure 66
F#4    1        e #   d         ).
rest   1        e
G4     2        q     d         (
B3     1        e     u         ).
rest   1        e
C4     2        q     d         (
measure 67
D4     2        q     d         ).
rest   2        q
rest   4        h
measure 68
rest   8
measure 69
rest   8
measure 70
D4     2        q     d         .
D4     2        q     d         .
D4     2        q     d         .
rest   2        q
measure 71
G4     2        q     d         .
rest   2        q
C4     2        q     d         .
rest   2        q
measure 72
G3     4        h     u         (
F#3    4        h #   u         )
measure 73
G3     4        h     u
rest   4        h
measure 74
G3     4        h     u
rest   4        h
measure 75
*               D       cresc.
P   C17:f33
G3     2        q     u
G3     1        e     u  [      .
B3     1        e     u  ]      .
D4     1        e     d  [      (
G4     1        e     d  =      )
G3     1        e     d  =      .
B3     1        e     d  ]      .
measure 76
D4     1        e     d  [      (f
G4     1        e     d  =      )
B3     1        e     d  =      .
D4     1        e     d  ]      .
G4     1        e     d  [      (
B4     1        e     d  =      )
B3     1        e     d  =      .
D4     1        e     d  ]      .
measure 77
G4     1        e     d  [      (
B4     1        e     d  =      )
D5     1        e     d  =      .
B4     1        e     d  ]      .
G4     1        e     d  [      (
D4     1        e     d  =      )
D5     1        e     d  =      .
B4     1        e     d  ]      .
measure 78
G4     1        e     d  [      (
D4     1        e     d  ]      )
rest   2        q
rest   4        h
measure 79
rest   8
measure 80
G3     4        h     u         (p
F#3    4        h #   u         )
measure 81
G3     2        q     u
rest   2        q
rest   4        h
measure 82
rest   2        q
G4     2        q     d         (mf
G3     1        e     u         ).
rest   1        e
G4     2        q     d         (
measure 83
G3     1        e     u         ).
rest   1        e
rest   2        q
rest   4        h
measure 84
rest   8
measure 85
rest   8
measure 86
rest   8
measure 87a     start-end1
rest   8
mheavy2 87b     stop-end1  start-end2  :|
rest   8
mheavy3 88                 disc-end2  |:
E4     8        w f   d         f
 Bf3   8        w     d
measure 89
Bf3    8-       w f   u        -
measure 90
Bf3    6        h.    u
G4     2        q     d         (r
S   C34:uwn4s25t75e
measure 91
Bf4    2        q f   d         )
E4     2        q     d         .
G4     2        q     d         .
Bf3    2        q f   u         (r
S   C34:uwn4s25t75f
measure 92
A3     2        q     u         )
C4     2        q     d         .
F4     2        q     d         .
E4     2        q     d         (
measure 93
F4     2        q     d         )
rest   2        q
rest   2        q
Bf3    1        e f   u  [      .p
C4     1        e     u  ]      .
measure 94
A3     1        e     d  [      .
C4     1        e     d  =      .
F4     1        e     d  =      .
C4     1        e     d  ]      .
A3     1        e     u  [      .
C4     1        e     u  =      .
Bf3    1        e f   u  =      .
C4     1        e     u  ]      .
measure 95
A3     1        e     d  [
C4     1        e     d  =
F4     1        e     d  =
C4     1        e     d  ]
A3     1        e     d  [
F4     1        e     d  =
C4     1        e     d  =
D4     1        e     d  ]
measure 96
Bf3    1        e f   d  [
D4     1        e     d  =
G4     1        e     d  =
D4     1        e     d  ]
Bf3    1        e     d  [
D4     1        e     d  =
C4     1        e     d  =
D4     1        e     d  ]
measure 97
Bf3    1        e f   d  [
D4     1        e     d  =
G4     1        e     d  =
D4     1        e     d  ]
Bf3    1        e     d  [
D4     1        e     d  =
G4     1        e     d  =      mf
D4     1        e     d  ]
measure 98
Bf3    1        e f   d  [
Ef4    1        e f   d  =
G4     1        e     d  =
Ef4    1        e     d  ]
Bf3    1        e     d  [
Ef4    1        e     d  =
G4     1        e     d  =
Ef4    1        e     d  ]
measure 99
F4     2        q     d         .
*               D       cresc.
P   C17:f33
D3     2        q     u         (
E3     2        q n   u         +
F3     2        q     u         )
measure 100
E3     2        q     u         f
rest   2        q
rest   2        q
A4     2        q     d         (
measure 101
A3     1        e     u         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d         (
measure 102
A3     1        e     u         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d         (
measure 103
A3     1        e     u         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d         (
measure 104
A3     1        e     u         )
rest   1        e
rest   2        q
rest   2        q
A4     2        q     d         (
measure 105
A3     1        e     u         )
rest   1        e
rest   2        q
rest   4        h
measure 106
rest   8
measure 107
rest   8
measure 108
rest   8
measure 109
rest   8
measure 110
rest   8
measure 111
rest   4        h
rest   2        q
A3     2        q     u
measure 112
A4     1        e     d  [      .
Bf4    1        e f   d  =      .
G4     1        e     d  =      .
A4     1        e     d  ]      .
F4     1        e     d  [      .
G4     1        e     d  =      .
A4     1        e     d  =      .
F#4    1        e #   d  ]      .
measure 113
E4     2        q     d
F#4    2        q #   d
G4     2        q     d
rest   2        q
measure 114
rest   4        h
rest   2        q
G3     2        q     u         (
measure 115
A3     2        q     u         )
rest   2        q
rest   2        q
F4     2        q     d         (
measure 116
G4     2        q     d         )
rest   2        q
rest   2        q
G4     2        q     d         (
measure 117
A4     2        q     d         )
rest   2        q
rest   2        q
F4     2        q     d         (
measure 118
G4     2        q     d         )
rest   2        q
rest   2        q
E4     2        q     d
measure 119
F4     1        e     d  [      .
A4     1        e     d  =      .
F4     1        e     d  =      .
A4     1        e     d  ]      .
F4     1        e     d  [
A4     1        e     d  =
F4     1        e     d  =
A4     1        e     d  ]
measure 120
F#4    1        e #   d  [
A4     1        e     d  =
F#4    1        e     d  =
A4     1        e     d  ]
F#4    1        e     d  [
A4     1        e     d  =
F#4    1        e     d  =
A4     1        e     d  ]
measure 121
G4     2        q     d
rest   2        q
rest   4        h
measure 122
rest   2        q
*               D       decresc.
P   C17:f33
G4     2        q     d         (
G3     1        e     u         )
rest   1        e
rest   2        q
measure 123
rest   8
measure 124
rest   2        q
G4     2        q     d         (p
G3     1        e     u         ).
rest   1        e
rest   2        q
measure 125
rest   8
measure 126
C4     8-       w     d        -f
measure 127
C4     8-       w     d        -
measure 128
C4     4        h     d
rest   4        h
measure 129
rest   8
measure 130
rest   8
measure 131
rest   8
measure 132
F4     8-       w     d        -f
measure 133
F4     8-       w     d        -
measure 134
F4     6        h.    d
B3     1        e     u  [      (
C4     1        e     u  ]      )
measure 135
D4     2        q     d         .
C4     2        q     d         .
D4     2        q     d         .
B3     2        q     u         .
measure 136
C4     2        q     d         .
rest   2        q
rest   4        h
measure 137
rest   8
measure 138
Af3    1        e f   d  [      .f
C4     1        e     d  =      .
Ef4    1        e f   d  =      .
Af4    1        e f   d  ]      .
C5     1        e     d  [      .
Af4    1        e     d  =      .
Ef4    1        e     d  =      .
C4     1        e     d  ]      .
measure 139
Af3    2        q f   u
C4     4        h     d
C4     2        q     d
measure 140
C4     4        h     d
rest   4        h
measure 141
rest   4        h
rest   2        q
G3     2        q     u         p(
measure 142
Af3    2        q f   u          )
C4     2        q     d          .
rest   4        h
measure 143
rest   4        h
rest   2        q
G3     2        q     u         (
measure 144
Af3    2        q f   u         )
C4     2        q     d         .
rest   4        h
measure 145
rest   4        h
rest   2        q
G3     2        q     u         (
measure 146
*               D       poco cresc.
P   C17:f33
Af3    2        q f   u         )
C4     2        q     d         .
rest   4        h
measure 147
rest   2        q
F3     2        q     u         .
G3     2        q     u         .
A3     2        q n   u         .+
measure 148
Bf3    2        q f   u         .
D4     2        q n   d         .+
rest   4        h
measure 149
rest   2        q
G3     2        q     u         .
A3     2        q n   u         .+
B3     2        q n   u         .+
measure 150
*               D       pi\8u cresc.
P   C17:f33
C4     2        q     d
Ef4    4        h f   d         >
Ef3    2        q f   u
measure 151
F3     6        h.    u
F#3    2        q #   u
measure 152
G3     1        e     d  [      (
G4     1        e     d  =      )
Af4    1        e f   d  =      .
G4     1        e     d  ]      .
F#4    1        e #   d  [      .
G4     1        e     d  =      .
F4     1        e n   d  =      .
G4     1        e     d  ]      .
measure 153
Ef4    1        e f   d  [      .
G4     1        e     d  =      .
D4     1        e     d  =      .
G4     1        e     d  ]      .
C4     1        e     d  [      .
G4     1        e     d  =      .
Af3    1        e f   d  =      .
G4     1        e     d  ]      .
measure 154
G3     2        q     u
rest   2        q
rest   2        q
D4     2        q     d         .
measure 155
G4     2        q     d
B3     2        q     u         (r
S   C34:uhn4s25t75e
C4     2        q     d         )
C5     2        q     d         .
measure 156
B4     8        w     d         fp
measure 157
*               D       cresc.
P   C17:f33
C5     8        w     d
measure 158
D5     8        w     d
measure 159
C5     8        w     d         f
measure 160
F4     8        w     d
measure 161
D4     8-       w     d        -
measure 162
D4     8        w     d         F
measure 163
*               D       !1p !33dolce
C4     4-       h     d        -(
C4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  =
F4     1        e     d  ]      )
measure 164
E4     1        e     d         .
rest   1        e
E4     2        q     d         (
C4     1        e     d         ).
rest   1        e
D4     2        q     d         (
measure 165
B3     1        e     u         ).
rest   1        e
C4     2        q     d         (
E3     1        e     u         ).
rest   1        e
F3     2        q     u         (
measure 166
G3     1        e     u         ).
rest   1        e
rest   2        q
rest   4        h
measure 167
G3     2        q     u         .
G3     2        q     u         .
G3     2        q     u         .
rest   2        q
measure 168
G3     2        q     u         .
rest   2        q
A3     2        q     u         .
rest   2        q
measure 169
E3     4        h     u         (
G3     2        q     u
F3     2        q     u         )
measure 170
E3     2        q     u
rest   2        q
rest   4        h
measure 171
*               D       dolce
P    C17:f33
C5     4-       h     d        -(
C5     1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
F5     1        e     d  ]      )
measure 172
E5     1        e     d         .
rest   1        e
E5     2        q     d         (
C5     1        e     d         ).
rest   1        e
D5     2        q     d         (
measure 173
B4     1        e     d         ).
rest   1        e
C5     2        q     d         (
E4     1        e     d         ).
rest   1        e
F4     2        q     d         (
measure 174
G4     1        e     d         ).
rest   1        e
rest   2        q
rest   4        h
measure 175
rest   8
measure 176
rest   8
measure 177
B3     2        q     u         .
B3     2        q     u         .
B3     2        q     u         .
rest   2        q
measure 178
C4     2        q     d         .
rest   2        q
rest   4        h
measure 179
E4     2        q     d         .pp
rest   2        q
rest   4        h
measure 180
G4     2        q     d         .
rest   2        q
rest   4        h
measure 181
F4     2        q     d         .f
rest   2        q
rest   2        q
F5     2        q     d         (
measure 182
F4     1        e     d         ).
rest   1        e
D5     2        q     d         (
D4     1        e     d         ).
rest   1        e
B4     2        q n   d         (+
measure 183
B3     1        e     u         ).
rest   1        e
G4     2        q     d         (
G3     1        e     u         ).
rest   1        e
G4     2        q     d         (
measure 184
G3     1        e     u         ).
rest   1        e
G4     2        q     d         (
G3     1        e     u         ).
rest   1        e
G4     2        q     d         (
measure 185
Af3    6        h.f   u         )Z
B3     2        q     u         (
P   C33:u
measure 186
C4     8-       w     d        -)
measure 187
C4     8-       w     d        -
measure 188
C4     8-       w     d        -
measure 189
C4     8-       w     d        -
measure 190
C4     8        w     d
measure 191
F#4    2        q #   d         .
F#4    2        q     d         .
F#4    2        q     d         .
F#4    2        q     d         .
measure 192
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
C5     2        q     d         .
measure 193
E4     6        h.n   d         ff+
gA4    4        t     u  [[[    (
S  C1:t17
gG4    4        t     u  ===
S  C1:t17
gF#4   4        t     u  ]]]
S  C1:t17
G4     2        q     d         )(
measure 194
C5     2        q     d          )
E4     2        q     d          .
G4     2        q     d          .
rest   2        q
measure 195
rest   8
measure 196
rest   8
measure 197
rest   8
measure 198
rest   4        h
rest   2        q
E5     2        q     d         (r
S   C34:uhn4s25t75e
measure 199
F5     2        q     d         )
D5     2        q     d         .
E5     2        q     d         .
B4     2        q     d         (r
S   C34:uhn4s25t75e
measure 200
C5     2        q     d         )
A4     2        q     d         .
B4     2        q     d         .
G4     2        q     d         (rus
S   C34:uwn4s25t75f
measure 201
A4     2        q     d         )
F#4    2        q #   d         .
G4     2        q     d         .
E4     2        q     d         (rh
S   C34:uhn4s25t75e
measure 202
F4     2        q n   d         )+
D4     2        q     d         .
E4     2        q     d         .
E4     2        q     d         .
measure 203
F4     2        q     d
rest   2        q
rest   4        h
measure 204
rest   8
measure 205
C4     4        h     d         (
B3     4        h     u         )
measure 206
C4     2        q     d
C5     2        q     d         .(mf
C5     2        q     d         .)
C5     2-       q     d        -
measure 207
C5     2        q     d
C5     2        q     d         .(>
C5     2        q     d         .
C5     2        q     d         .)
measure 208
G4     4        h     d
B3     4        h     u
measure 209
C4     2        q     d
rest   2        q
rest   4        h
measure 210
rest   2        q
C4     2        q     d         .(
C4     2        q     d         .)
C4     2-       q     d        -
measure 211
C4     2        q     d
C4     2        q     d         .(>
C4     2        q     d         .
C4     2        q     d         .)
measure 212
E3     4        h     u         (
F3     4        h     u         )
measure 213
E3     2        q     u
rest   2        q
rest   4        h
measure 214
G3     2        q     u
rest   2        q
rest   4        h
measure 215
*               D       cresc.
P   C17:f33
E3     2        q     u
C3     1        e     u  [      .
E3     1        e     u  ]      .
G3     1        e     u  [      (
C4     1        e     u  =      )
C3     1        e     u  =      .
E3     1        e     u  ]      .
measure 216
G3     1        e     u  [      (
C4     1        e     u  =      )
E3     1        e     u  =      .
G3     1        e     u  ]      .
C4     1        e     u  [      (
E4     1        e     u  =      )
E3     1        e     u  =      .
G3     1        e     u  ]      .
measure 217
C4     1        e     u  [      (
E4     1        e     u  =      )
G3     1        e     u  =      .
C4     1        e     u  ]      .
E4     1        e     d  [      (
G4     1        e     d  =      )
G3     1        e     d  =      .
C4     1        e     d  ]      .
measure 218
E4     1        e     d  [      (f
G4     1        e     d  =      )
E4     1        e     d  =      .
G4     1        e     d  ]      .
C5     1        e     d  [      (
E5     1        e     d  =      )
E4     1        e     d  =      .
G4     1        e     d  ]      .
measure 219
C5     1        e     d  [      (
E5     1        e     d  ]      )
rest   2        q
rest   4        h
measure 220
rest   8
measure 221
E3     4        h     u         (p
G3     2        q     u
F3     2        q     u         )
measure 222
E3     2        q     u
rest   2        q
rest   4        h
measure 223
rest   2        q
C4     2        q     d         (mf
C3     1        e     u         ).
rest   1        e
C4     2        q     d         (
measure 224
C3     1        e     u         ).
rest   1        e
rest   2        q
rest   4        h
measure 225
rest   4        h
rest   2        q
G4     2        q     d         (
measure 226
C4     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
B4     2        q     d         (
measure 227
C5     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
C4     2        q     d         (
measure 228
C4     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
G3     2        q     u         .
measure 229
G3     2        q     u         .
G3     2        q     u         .
G3     2        q     u         .
G3     2        q     u         .
measure 230
G3     2        q     u         .
rest   2        q
rest   2        q
G3     2        q     u         .
measure 231
G3     2        q     u         .
G3     2        q     u         .
G3     2        q     u         .
G3     2        q     u         .
measure 232
G3     4        h     u
E4     4        h     u         f
 G3    4        h     u
measure 233
E4     4        h     u
 G3    4        h     u
rest   4        h
mheavy2                       :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/01/04} [KHM:4000451156]
TIMESTAMP: DEC/26/2001 [md5sum:7a50df56a9e1173680ebd6442b320670]
07/25/94 W Hewlett
WK#:54,2      MV#:1
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Vivace (First movement)
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:1/1  C:22  D:Vivace
C3     8-       w     u        -f
measure 2
C3     8-       w     u        -
measure 3
C3     4        h     u
rest   4        h
measure 4
rest   8
measure 5
rest   8
measure 6
rest   8
measure 7
G2     8-       w     u        -f
measure 8
G2     8-       w     u        -
measure 9
G2     4        h     u
rest   4        h
measure 10
rest   8
measure 11
rest   8
measure 12
rest   8
measure 13
Af2    8-       w f   u        -f
measure 14
Af2    8-       w     u        -
measure 15
Af2    4        h     u
rest   4        h
measure 16
rest   4        h
rest   2        q
Ef3    2        q f   d         .
measure 17
Af3    2        q f   d         .
Af2    2        q f   u         .
rest   4        h
measure 18
rest   4        h
rest   2        q
Ef3    2        q f   d         .
measure 19
Af3    2        q f   d         .
Af2    2        q f   u         .
rest   4        h
measure 20
rest   4        h
rest   2        q
Ef3    2        q f   d         .
measure 21
Af3    2        q f   d         .
Af2    2        q f   u         .
rest   4        h
measure 22
rest   2        q
Af3    2        q f   d         .(
Af3    2        q     d         .)
Af3    2        q     d
measure 23
G3     2        q     d
F3     2        q     d         .(>
F3     2        q     d         .
F3     2        q     d         .)
measure 24
gG3    0        e     u         (
S  C1:pt4
G2     8        w     u         )
measure 25
C3     2        q     u
rest   2        q
rest   4        h
measure 26
rest   2        q
$    C:12
A4     2        q n   d         .(p+
A4     2        q     d         .)
A4     2        q     d         (
measure 27
G4     2        q     d         )
F4     2        q     d         .(>
F4     2        q     d         .
F4     2        q     d         .)
$    C:22
measure 28
G3     8        w     d
measure 29
C4     2        q     d
rest   2        q
rest   4        h
measure 30
A2     8-       w     u        -f
measure 31
A2     8-       w     u        -
measure 32
A2     8-       w     u        -
measure 33
A2     8        w     u
measure 34
A3     8        w     d         (
measure 35
G#3    2        q #   d         )
rest   2        q
rest   4        h
measure 36
G3     8        w n   d         (+
measure 37
F3     2        q     d         )
rest   2        q
rest   4        h
measure 38
F3     8        w     d
measure 39
E3     8        w     d
measure 40
D3     8-       w     d        -
measure 41
D3     8-       w     d        -
measure 42
D3     8        w     d
measure 43
D3     2        q     d
rest   2        q
rest   2        q
F#3    2        q #   d         (
measure 44
G3     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
G3     2        q     d         (
measure 45
F#3    1        e #   d         )
rest   1        e
rest   2        q
rest   2        q
F#3    2        q     d         (
measure 46
G3     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
G3     2        q     d         (
measure 47
F#3    1        e #   d         )
rest   1        e
rest   2        q
rest   4        h
measure 48
*               E   15
*      5        F   0
G3     8-       w     d        -
measure 49
G3     8        w     d
measure 50
Ef3    8-       w f   d        -
measure 51
Ef3    4        h     d
D3     4        h     d
measure 52
C#3    8-       w #   u        -
measure 53
C#3    8        w     u
measure 54
D3     4        h     d
D3     1        e     d  [
F#3    1        e #   d  =
A3     1        e     d  =
C#4    1        e #   d  ]
measure 55
D4     2        q     d
rest   2        q
rest   4        h
measure 56
G3     2        q     d         p
rest   2        q
rest   4        h
measure 57
rest   8
measure 58
rest   8
measure 59
rest   8
measure 60
F#3    2        q #   d         .
F#3    2        q     d         .
F#3    2        q     d         .
rest   2        q
measure 61
G3     2        q     d         .
rest   2        q
C3     2        q n   u         .+
rest   2        q
measure 62
D3     8        w     d
measure 63
G2     4        h     u
rest   4        h
measure 64
rest   8
measure 65
rest   8
measure 66
rest   8
measure 67
rest   2        q
B3     2        q     d         (
G3     1        e     d         ).
rest   1        e
A3     2        q     d         (
measure 68
F#3    1        e #   d         ).
rest   1        e
G3     2        q     d         (
B2     1        e     u         ).
rest   1        e
C3     2        q     u         (
measure 69
D3     2        q     d         ).
rest   2        q
rest   4        h
measure 70
F#3    2        q #   d         .
F#3    2        q     d         .
F#3    2        q     d         .
rest   2        q
measure 71
G3     2        q     d         .
rest   2        q
C3     2        q     u         .
rest   2        q
measure 72
D3     8        w     d
measure 73
G3     4        h     d
rest   4        h
measure 74
G3     4        h     d
rest   4        h
measure 75
*               D       cresc.
P   C17:f33
G3     4        h     d
rest   4        h
measure 76
G3     4        h     d
rest   4        h
measure 77
G3     2        q     d         f
G2     1        e     u  [      .
B2     1        e     u  ]      .
D3     1        e     u  [      (
G3     1        e     u  =      )
G2     1        e     u  =      .
B2     1        e     u  ]      .
measure 78
D3     1        e     d  [      (
G3     1        e     d  ]      )
G2     2        q     u         .
A2     2        q     u         .
B2     2        q     u         .
measure 79
C3     2        q     u         .
rest   2        q
rest   4        h
measure 80
D3     4        h     d         (p
D2     4        h     u         )
measure 81
G2     2        q     u
rest   2        q
rest   4        h
measure 82
rest   8
measure 83
rest   2        q
G3     2        q     d         (mf
G2     1        e     u         ).
rest   1        e
G3     2        q     d         (
measure 84
G2     1        e     u         ).
rest   1        e
rest   2        q
rest   4        h
measure 85
rest   8
measure 86
rest   8
measure 87a     start-end1
rest   8
mheavy2 87b     stop-end1  start-end2  :|
rest   8
mheavy3 88                 disc-end2  |:
C3     8-       w     u        -f
measure 89
C3     8-       w     u        -
measure 90
C3     6        h.    u
G3     2        q     d         (r
S   C34:uwn4s25t75e
measure 91
Bf3    2        q f   d         )
E3     2        q     d         .
G3     2        q     d         .
Bf2    2        q f   u         (r
S   C34:uwn4s25t75f
measure 92
A2     2        q     u         )
C3     2        q     u         .
F3     2        q     d         .
rest   2        q
measure 93
rest   4        h
rest   2        q
C3     2        q     u         (rp
S   C34:uwn4s25t75f
measure 94
F3     2        q     d         )
rest   2        q
rest   2        q
E4     2        q     d         (r
S   C34:uhn4s25t75e
measure 95
F4     2        q     d         )
rest   2        q
rest   2        q
D3     2        q     d         (
measure 96
G2     2        q     u         )
rest   2        q
rest   2        q
$    C:12
F#4    2        q #   d         (r
S   C34:uhn4s25t75e
measure 97
G4     2        q     d         )
rest   2        q
rest   4        h
$    C:22
measure 98
G2     8        w     u         mf
measure 99
*               D       cresc.
P   C17:f33
G#2    8        w #   u
measure 100
A2     4        h     u         f
rest   2        q
C#4    2        q #   d         (
measure 101
D4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
D4     2        q     d         (
measure 102
C#4    1        e #   d         )
rest   1        e
rest   2        q
rest   2        q
C#4    2        q     d         (r
S   C34:uhn4s25t75e
measure 103
D4     1        e     d         )
rest   1        e
rest   2        q
rest   2        q
D4     2        q     d         (rus
S   C34:uwn4s25t75f
measure 104
C#4    1        e #   d         )
rest   1        e
rest   2        q
rest   2        q
C#4    2        q     d         (
measure 105
D4     1        e n   d         )+
rest   1        e
rest   2        q
rest   4        h
measure 106
rest   8
measure 107
rest   8
measure 108
rest   8
measure 109
rest   8
measure 110
rest   8
measure 111
A2     1        e     d  [      (
A3     1        e     d  =      )
Bf3    1        e f   d  =      (
A3     1        e     d  ]      )
G#3    1        e #   d  [      .
A3     1        e     d  =      .
G3     1        e n   d  =      .
A3     1        e     d  ]      .
measure 112
F3     1        e     d  [      .
G3     1        e     d  =      .
E3     1        e     d  =      .
F3     1        e     d  ]      .
D3     1        e     d  [      .
E3     1        e     d  =      .
C3     1        e     d  =      .
D3     1        e     d  ]      .
measure 113
Bf2    1        e f   u  [
C3     1        e     u  =
A2     1        e     u  =
Bf2    1        e     u  ]
G2     1        e     u  [
A2     1        e     u  =
F2     1        e     u  =
G2     1        e     u  ]
measure 114
E2     1        e     u  [
F2     1        e     u  =
D2     1        e     u  =
E2     1        e     u  ]
C2     1        e     u  [
C3     1        e     u  =
E2     1        e     u  =
C3     1        e     u  ]
measure 115
F2     2        q     u
rest   2        q
rest   2        q
F3     2        q     d         (
measure 116
C3     2        q     u         )
rest   2        q
rest   2        q
C3     2        q     u         (
measure 117
F3     2        q     d         )
rest   2        q
rest   2        q
F3     2        q     d         (
measure 118
C3     2        q     u         )
rest   2        q
rest   2        q
C3     2        q     u         (
measure 119
F3     2        q     d         )
rest   2        q
rest   4        h
measure 120
rest   8
measure 121
rest   8
measure 122
rest   8
measure 123
rest   8
measure 124
rest   8
measure 125
rest   8
measure 126
C2     1        e     u  [      .f
E2     1        e     u  =      .
G2     1        e     u  =      .
C3     1        e     u  ]      .
E3     1        e     u  [      .
C3     1        e     u  =      .
G2     1        e     u  =      .
E2     1        e     u  ]      .
measure 127
C2     8-       w     u        -
measure 128
C2     4        h     u
rest   4        h
measure 129
rest   8
measure 130
rest   8
measure 131
rest   8
measure 132
G2     1        e     u  [      .f
B2     1        e     u  =      .
D3     1        e     u  =      .
G3     1        e     u  ]      .
B3     1        e     d  [      .
G3     1        e     d  =      .
D3     1        e     d  =      .
B2     1        e     d  ]      .
measure 133
G2     8-       w     u        -
measure 134
G2     4        h     u
rest   4        h
measure 135
rest   8
measure 136
rest   8
measure 137
rest   8
measure 138
Af2    8-       w f   u        -f
measure 139
Af2    8-       w     u        -
measure 140
Af2    4        h     u
rest   4        h
measure 141
rest   4        h
rest   2        q
Ef3    2        q f   d         (rp
S   C34:uwn4s25t75f
measure 142
Af3    2        q f   d         )
Af2    2        q f   u
rest   4        h
measure 143
rest   4        h
rest   2        q
Ef3    2        q f   d         (r
S   C34:uwn4s25t75f
measure 144
Af3    2        q f   d         ).
Af2    2        q f   u
rest   4        h
measure 145
rest   4        h
rest   2        q
Ef3    2        q f   d
measure 146
*               D       poco cresc.
P   C17:f33
Af2    6        h.f   u
Gf2    2        q f   u
measure 147
F2     8        w     u
measure 148
Bf2    6        h.f   u
Af2    2        q f   u
measure 149
G2     8        w n   u         +
measure 150
*               D       pi\8u cresc.
P   C17:f33
C3     8        w     u
measure 151
F3     6        h.    d
F#3    2        q #   d
measure 152
G3     2        q     d         f
rest   2        q
rest   4        h
measure 153
rest   8
measure 154
G2     1        e     d  [      (
G3     1        e     d  =      )
Af3    1        e f   d  =      (
G3     1        e     d  ]      )
F#3    1        e #   d  [      .
G3     1        e     d  =      .
F3     1        e n   d  =      .
G3     1        e     d  ]      .
measure 155
Ef3    1        e f   d  [      .
G3     1        e     d  =      .
D3     1        e     d  =      .
G3     1        e     d  ]      .
C3     1        e     d  [      .
G3     1        e     d  =      .
Af2    1        e f   d  =      .
G3     1        e     d  ]      .
measure 156
G2     8-       w     u        -fp
measure 157
*               D       cresc.
P   C17:f33
G2     8-       w     u        -
measure 158
G2     8-       w     u        -
measure 159
G2     8-       w     u        -f
measure 160
G2     8-       w     u        -
measure 161
G2     8-       w     u        -
measure 162
G2     8        w     u         F
measure 163
C3     2        q     u         p
rest   2        q
rest   4        h
measure 164
rest   8
measure 165
rest   8
measure 166
rest   8
measure 167
B2     2        q     u         .
B2     2        q     u         .
B2     2        q     u         .
rest   2        q
measure 168
C3     2        q     u         .
rest   2        q
F2     2        q     u         .
rest   2        q
measure 169
G2     8        w     u
measure 170
C3     4        h     u
rest   4        h
measure 171
rest   8
measure 172
rest   8
measure 173
rest   8
measure 174
rest   2        q
E4     2        q     d         (
C4     1        e     d         ).
rest   1        e
D4     2        q     d         (
measure 175
B3     1        e     d         ).
rest   1        e
C4     2        q     d         (
E3     1        e     d         ).
rest   1        e
F3     2        q     d         (
measure 176
G3     2        q     d         ).
rest   2        q
rest   4        h
measure 177
rest   8
measure 178
rest   8
measure 179
rest   8
measure 180
rest   8
measure 181
rest   4        h
rest   2        q
F4     2        q     d         (f
measure 182
F3     1        e     d         ).
rest   1        e
D4     2        q     d         (
D3     1        e     d         ).
rest   1        e
B3     2        q n   d         (+
measure 183
B2     1        e     u         ).
rest   1        e
G3     2        q     d         (
G2     1        e     u         ).
rest   1        e
G3     2        q     d         (
measure 184
G2     1        e     u         ).
rest   1        e
G3     2        q     d         (
G2     1        e     u         ).
rest   1        e
G3     2        q     d         (
measure 185
Af2    8-       w f   u        -)Z
measure 186
Af2    8-       w     u        -
measure 187
Af2    8-       w     u        -
measure 188
Af2    8-       w     u        -
measure 189
Af2    8        w     u
measure 190
A2     8        w n   u         +
measure 191
A2     2        q     u         .
A2     2        q     u         .
A2     2        q     u         .
A2     2        q     u         .
measure 192
A2     2        q     u         .
A2     2        q     u         .
A2     2        q     u         .
A2     2        q     u         .
measure 193
G2     4        h     u         ff
rest   4        h
measure 194
rest   4        h
rest   2        q
gD4    4        t     u  [[[    (
S  C1:t17
gC4    4        t     u  ===
S  C1:t17
gB3    4        t     u  ]]]
S  C1:t17
C4     2        q     d         )(
measure 195
E4     2        q     d          )
G3     2        q     d         .
C4     2        q     d         .
E3     2        q     d         (r
S   C34:uhn4s25t75e
measure 196
G3     2        q     d         )
C3     2        q     u         .
E3     2        q     d         .
F#2    2        q #   u         .
measure 197
G2     1        e     u  [      .
G3     1        e     u  =      .
G2     1        e     u  =      .
G3     1        e     u  ]      .
G2     1        e     u  [      .
G3     1        e     u  =      .
G2     1        e     u  =      .
G3     1        e     u  ]      .
measure 198
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
measure 199
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
measure 200
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
measure 201
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
measure 202
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
G2     1        e     u  [
G3     1        e     u  =
G2     1        e     u  =
G3     1        e     u  ]
measure 203
F3     2        q     d
rest   2        q
rest   4        h
measure 204
rest   8
measure 205
G3     4        h     d         (
G2     4        h     u         )
measure 206
C3     2        q     u
$    C:12
A4     2        q     d         .(mf
A4     2        q     d         .)
A4     2        q     d         (
measure 207
G4     2        q     d         )
F4     2        q     d         .(>
F4     2        q     d         .
F4     2        q     d         .)
$    C:22
measure 208
G3     8        w     d         Z
measure 209
A3     2        q     d
rest   2        q
rest   4        h
measure 210
rest   2        q
A3     2        q     d         .(p
A3     2        q     d         .)
A3     2        q     d         (
measure 211
G3     2        q     d         )
F3     2        q     d         .(>
F3     2        q     d         .
F3     2        q     d         .)
measure 212
G2     8        w     u
measure 213
C3     2        q     u
rest   2        q
rest   4        h
measure 214
C3     2        q     u
rest   2        q
rest   4        h
measure 215
*               D       cresc.
P   C17:f33
C3     2        q     u
rest   2        q
rest   4        h
measure 216
C3     2        q     u
rest   2        q
rest   4        h
measure 217
C3     2        q     u
rest   2        q
rest   4        h
measure 218
rest   2        q
C2     1        e     u  [      .f
E2     1        e     u  ]      .
G2     1        e     u  [      (
C3     1        e     u  =      )
C2     1        e     u  =      .
E2     1        e     u  ]      .
measure 219
G2     1        e     u  [      (
C3     1        e     u  ]      )
C2     2        q     u         .
D2     2        q     u         .
E2     2        q     u         .
measure 220
F2     4        h     u
rest   4        h
measure 221
G2     8        w     u         p
measure 222
C3     2        q     u
rest   2        q
rest   4        h
measure 223
rest   8
measure 224
rest   2        q
C3     2        q     u         (mf
C2     1        e     u         ).
rest   1        e
C3     2        q     u         (
measure 225
C2     1        e     u         ).
rest   1        e
rest   2        q
rest   2        q
E3     2        q     d         (
measure 226
F3     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
G3     2        q     d         (
measure 227
A3     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
F3     2        q     d         (
measure 228
G3     1        e     d         ).
rest   1        e
rest   2        q
rest   2        q
G2     2        q     u         .
measure 229
C2     2        q     u         .
G2     2        q     u         .
C2     2        q     u         .
G2     2        q     u         .
measure 230
C2     2        q     u         .
rest   2        q
rest   2        q
G2     2        q     u         .
measure 231
C2     2        q     u         .
G2     2        q     u         .
C2     2        q     u         .
G2     2        q     u         .
measure 232
C2     4        h     u
C3     4        h     u         f
 C2    4        h     u
measure 233
C3     4        h     u
 C2    4        h     u
rest   4        h
mheavy2                       :|
/END
/eof
//
