&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/03/01} [KHM:28807015]
TIMESTAMP: DEC/26/2001 [md5sum:5943a9e450e3ccda6656218667976b20]
07/25/94 W Hewlett
WK#:54,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Menuetto
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:8   T:3/4  C:4  D:Allegretto
E4     8        q     u         p
measure 1
E4     8        q     u         (
C4     4        e     u         ).
rest   4        e
G4     8        q     u         .
measure 2
G4     8        q     u         (
E4     4        e     u         ).
rest   4        e
C5     8        q     d         .
measure 3
C5    16        h     d         Z
B4     8        q     d         .
measure 4
gB4    0        e     u         (
S   C1:pt25
A4     8        q     u         )
G4     8        q     u         .
Bf4    8        q f   d         .
measure 5
Bf4   16        h f   d         Z
A4     8        q     u
measure 6
gA4    0        e     u         (
S   C1:pt25
G4     8        q     u         ).
F4     8        q     u         .
A4     8        q     u         .
measure 7
C4    16        h     u
D4     4        e     u  [      (
B3     4        e     u  ]      )
measure 8
C4     8        q     u         .
rest   8        q
mheavy4         :|:
D4     8        q     u         .p
measure 9
D4     8        q     u         (
G4     4        e     u         ).
rest   4        e
F#4    8        q #   u         .
measure 10
F#4    8        q #   u         (
C5     4        e     d         ).
rest   4        e
B4     8        q     d         .
measure 11
*               E   0
B4     8        q     d         (
E5     8        q     d         )
*               F   18
E5     8        q     d         .
measure 12
D5    16        h     d         f
C5     8        q     d         .
measure 13
gB4    4        t     u  [[[    (
S   C1:pt8
gC5    4        t     u  ===
S   C1:pt8
gD5    4        t     u  ]]]
S   C1:pt8
C5    16        h     d         )
B4     8        q     d         .
measure 14
gB4    0        e     u         (
A4     8        q     u         )
G4     8        q     u         .
G5     8        q     d         .
measure 15
gF#5   4        t     u  [[[    (
S   C1:pt8
gG5    4        t     u  ===
S   C1:pt8
gA5    4        t     u  ]]]
S   C1:pt8
G5    16        h     d         )Z
F#5    8        q #   d         .
measure 16
gF#5   0        e     u         (
S   C1:pt25
E5     8        q     d         ).
D5     8        q     d         .
C#5    8        q #   d         .
measure 17
C#5   16        h #   d         Z
D5     8        q     d         .
measure 18
gD5    0        e     u         (
S   C1:pt25
C5     8        q n   d         )+.
B4     8        q     d         .
A4     8        q     u         .
measure 19
G4    16        h     u
A4     4        e     u  [      (
F#4    4        e #   u  ]      )
measure 20
G4     8        q     u         .
rest   8        q
B4     8        q     d         p.
measure 21
B4     8        q     d         (
G4     4        e     u         ).
rest   4        e
D5     8        q     d         .
measure 22
D5     8        q     d         (
B4     4        e     d         ).
rest   4        e
F5     8        q n   d         .+
measure 23
F5     8-       q     d        -(
F5     6        e.    d  [
G5     2        s     d  =\     ).
A5     6        e.    d  =
G5     2        s     d  ]\
measure 24
F5     8        q     d         .
rest   8        q
E4     8        q     u         .
measure 25
E4     8        q     u         (
C4     4        e     u         ).
rest   4        e
G4     8        q     u         .
measure 26
G4     8        q     u         (
E4     4        e     u         ).
rest   4        e
C5     8        q     d         .
measure 27
C5    16        h     d         Z
B4     8        q     d         .
measure 28
gB4    0        e     u         (
S   C1:pt25
A4     8        q     u         ).
G4     8        q     u         .
Bf4    8        q f   d         .
measure 29
Bf4   16        h f   d         Z
A4     8        q     u         .
measure 30
gA4    0        e     u         (
S   C1:pt25
G4     8        q     u         )
F4     8        q     u         .
A4     8        q     u         .
measure 31
C4    16        h     u
D4     4        e     u  [      (
B3     4        e     u  ]      )
measure 32
C4     8        q     u
rest   8        q
C6     8        q     d         p.
measure 33
C6    16        h     d         >
B5     8        q     d         .
measure 34
gB5    0        e     u         (
S   C1:pt25
A5     8        q     d         ).
G5     8        q     d         .
Bf5    8        q f   d         .
measure 35
Bf5   16        h f   d         >
A5     8        q     d         .
measure 36
gA5    0        e     u         (
S   C1:pt25
G5     8        q     d         ).
F5     8        q     d         .
A5     8        q     d         .
measure 37
C5    16        h n   d         +
D5     4        e     d  [      (
B4     4        e     d  ]      )
measure 38
C5     4        e     d  [      .
D5     4        e     d  =      .
Ef5    4        e f   d  =      .
E5     4        e n   d  =      .
F5     4        e     d  =      .
F#5    4        e #   d  ]      .
measure 39
G5     8        q     d         .
rest   8        q
B4     8        q     d         .
measure 40
C5     4        e     d  [      .
E5     4        e     d  =      .
F5     4        e     d  =      .
F#5    4        e #   d  =      .
G5     4        e     d  =      .
G#5    4        e #   d  ]      .
measure 41
A5     8        q     d         .
rest   8        q
B4     8        q     d         f.
measure 42
*               E   0
C5     4        e     d  [      .
E5     4        e     d  =      .
F5     4        e     d  =      .
G5     4        e     d  =      .
A5     4        e     d  =      .
B5     4        e     d  ]      .
measure 43
C6     4        e     d  [      .
D6     4        e     d  =      .
E6     4        e     d  =      .
F6     4        e     d  =      .
G6     4        e     d  =      .
G#6    4        e #   d  ]      .
measure 44
A6     8        q     d         .
B6     8        q     d         .
C7     8        q     d         .
measure 45
*               FG  18  ff
G3     8        q n   u         +.
C5     8        q     u
 E4    8        q     u         .
B4     8        q     u
 D4    8        q     u         .
measure 46
C5     8        q     u
 E4    8        q     u
rest   8        q
S   C8:F8
*               B       Fine
P   C17:f39
mheavy4         :|:
$    K:-3   D:Trio
C4     8        q     u         f.
measure 47
C4     8        q     u
G3     4        e     u  [      .
C4     4        e     u  ]      .
Ef4    8        q     u         .
measure 48
Ef4    8        q     u
C4     4        e     u  [      .
Ef4    4        e     u  ]      .
G4     8        q     u         .
measure 49
G4     8        q     u
Ef4    4        e     u  [      (
G4     4        e     u  =
B4     4        e n   u  =
C5     4        e     u  ]      )
measure 50
G4     8        q     u
rest   8        q
Af5    8        q     d         f.
measure 51
*               E   18
Af5    8        q     d         (
G5     8        q     d         )
G5     8        q     d         .
measure 52
*               F   0
G5     8        q     d         (
F5     8        q     d         )
Af5    8        q     d         f.
measure 53
Af5    8        q     d         (
G5     8        q     d         )
G5     8        q     d         .
measure 54
G5     8        q     d         (
F5     8        q     d         )
F5     8        q     d         .p
measure 55
F5     8        q     d         (
Ef5    8        q f   d         )
Ef5    8        q     d         .
measure 56
D5     8        q     d         .
rest   8        q
mheavy4         :|:
E5     8        q n   d         f
measure 57
*               E   18
*     16        F   0
E5    24-       h.n   d        -
measure 58
E5    16        h     d
E5     8        q n   d         p.
measure 59
E5     8        q n   d         (
F5     8        q     d         )
F5     8        q     d         .
measure 60
F5     8        q     d         .
rest   8        q
F#5    8        q #   d         .f
measure 61
*               E   18
*     16        F   0
F#5   24-       h.#   d        -
measure 62
F#5   16        h     d
F#5    8        q #   d         p.
measure 63
F#5    8        q #   d         (
G5     8        q     d         )
G5     8        q     d         .
measure 64
G5     8        q     d         .
rest   8        q
Af5    8        q f   d         f.+
measure 65
*               E   18
Af5    8        q     d         (
G5     8        q     d         )
*               F   0
G5     8        q     d         .
measure 66
G5     8        q     d         (
F5     8        q     d         )
Af5    8        q     d         f.
measure 67
*               E   18
Af5    8        q     d         (
G5     8        q     d         )
*               F   0
G5     8        q     d         .
measure 68
G5     8        q     d         (
F5     8        q     d         )
Af5    8        q     d         f.
measure 69
*               E   18
Af5    8        q     d         (
G5     8        q     d         )
*               F   0
G5     8        q     d         .
measure 70
G5     8        q     d         (
F#5    8        q #   d         )
F#5    8        q     d         p.
measure 71
G5     8        q     d         .
Ef5    8        q f   d         .
D5     8        q     d         t(
S   C33:uhn6s17t83e
gC5    5        s     u  [[
gD5    5        s     u  ]]      )
measure 72
C5     8        q     d         .
rest   8        q
*               B       Menuetto D.C.
P    C17:f39
mheavy2         :|
$   K:0
S  C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/03/02} [KHM:28807015]
TIMESTAMP: DEC/26/2001 [md5sum:08ba58dface520db371c6e568820cedd]
07/25/94 W Hewlett
WK#:54,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Menuetto
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:4   T:3/4  C:4  D:Allegretto
rest   4        q
measure 1
rest   4        q
rest   4        q
E4     4        q     u         p.
measure 2
E4     4        q     u         (
C4     2        e     u         ).
rest   2        e
F#4    4        q #   u         .
measure 3
F#4    8        h #   u         Z
G4     4        q     u         .
measure 4
F#4    4        q #   u         .
G4     4        q     u         .
E4     4        q     u         .
measure 5
E4     8        h     u         Z
F4     4        q n   u         +
measure 6
E4     4        q     u         .
F4     4        q     u         .
C4     4        q     u         .
measure 7
E4     8        h     u
F4     2        e     u  [      (
D4     2        e     u  ]      )
measure 8
C4     4        q     u         .
rest   4        q
mheavy4         :|:
B3     4        q     u         .
measure 9
B3     4        q     u         (
G3     2        e     u         ).
rest   2        e
C4     4        q     u         .
measure 10
C4     4        q     u         (
A3     2        e     u         ).
rest   2        e
G4     4        q     u         .
measure 11
*               E   0
G4     4        q     u         (
B4     4        q     d         )
*               F   18
B4     4        q     d         .
measure 12
A4     8        h     u         f
G4     4        q     u         .
measure 13
G4     8        h     u
F#4    4        q #   u         .
measure 14
gF#4   0        e     u         (
S   C1:pt25
E4     4        q     u         ).
D4     4        q     u         .
G4     4        q     u         .
measure 15
gF#4   4        t     u  [[[    (
S   C1:pt8
gG4    4        t     u  ===
S   C1:pt8
gA4    4        t     u  ]]]
S   C1:pt8
G4     8        h     u         )Z
F#4    4        q #   u         .
measure 16
gF#4   0        e     u         (
S   C1:pt25
E4     4        q     u         ).
D4     4        q     u         .
Bf4    4        q f   d         .
measure 17
Bf4    8        h f   d         Z
A4     4        q     u         .
measure 18
G4     4        q     u         .
F#4    4        q #   u         .
E4     4        q     u         .
measure 19
D4     8        h     u         (
C4     4        q     u         )
measure 20
B3     4        q     u         .
rest   4        q
D4     4        q     u         p.
measure 21
D4     4        q     u         (
B3     2        e     u         ).
rest   2        e
B4     4        q     d         .
measure 22
B4     4        q     d         (
G4     2        e     u         ).
rest   2        e
D5     4        q     d         .
measure 23
D5     4-       q     d        -(
D5     3        e.    d  [
E5     1        s     d  =\     ).
F5     3        e.    d  =
E5     1        s     d  ]\
measure 24
D5     4        q     d         .
rest   4        q
rest   4        q
measure 25
rest   4        q
rest   4        q
E4     4        q     u         .
measure 26
E4     4        q     u         (
C4     2        e     u         ).
rest   2        e
F#4    4        q #   u         .
measure 27
F#4    8        h #   u         Z
G4     4        q     u         .
measure 28
F#4    4        q #   u         .
G4     4        q     u         .
E4     4        q     u         .
measure 29
E4     8        h     u         Z
F4     4        q n   u         .+
measure 30
E4     4        q     u         .
F4     4        q     u         .
C4     4        q     u         .
measure 31
E4     8        h     u
F4     2        e     u  [      (
D4     2        e     u  ]      )
measure 32
C4     4        q     u         .
rest   4        q
F#5    4        q #   d         .p
measure 33
F#5    8        h #   d         >
G5     4        q     d         .
measure 34
gG5    0        e     u         (
S   C1:pt25
F#5    4        q #   d         ).
E5     4        q     d         .
E5     4        q     d         .
measure 35
E5     8        h     d         >
F5     4        q n   d         .+
measure 36
gF5    0        e     u         (
S   C1:pt25
E5     4        q     d         ).
D5     4        q     d         .
D5     4        q     d         .
measure 37
E4     8        h     u
F4     2        e     u  [      (
D4     2        e     u  ]      )
measure 38
E4     4        q     u         .
rest   4        q
rest   4        q
measure 39
rest   4        q
rest   4        q
F4     4        q     u         .
measure 40
E4     4        q     u         .
rest   4        q
rest   4        q
measure 41
rest   4        q
rest   4        q
D4     4        q     u         .f
measure 42
*               E   0
C4     2        e     u  [      .
E4     2        e     u  =      .
F4     2        e     u  =      .
G4     2        e     u  =      .
A4     2        e     u  =      .
B4     2        e     u  ]      .
measure 43
C5     2        e     d  [      .
D5     2        e     d  =      .
E5     2        e     d  =      .
F5     2        e     d  =      .
G5     2        e     d  =      .
G#5    2        e #   d  ]      .
measure 44
A5     4        q     d         .
B5     4        q     d         .
C6     4        q     d         .
measure 45
*               FG  18  ff
G3     4        q n   u         .+
C5     4        q     u
 E4    4        q     u         .
B4     4        q     u
 D4    4        q     u         .
measure 46
C5     4        q     u
 E4    4        q     u         .
rest   4        q
S   C8:F4
*               B       Fine
P   C17:f39
mheavy4         :|:
$    K:-3   D:Trio
C4     4        q     u         f.
measure 47
C4     4        q     u
G3     2        e     u  [      .
C4     2        e     u  ]      .
Ef4    4        q     u         .
measure 48
Ef4    4        q     u
C4     2        e     u  [      .
Ef4    2        e     u  ]      .
G4     4        q     u         .
measure 49
G4     4        q     u
Ef4    2        e     u  [      (
G4     2        e     u  =
B4     2        e n   u  =
C5     2        e     u  ]      )
measure 50
G4     4        q     u
rest   4        q
Ef5    4        q     d         f.
measure 51
*               E   18
Ef5   12-       h.    d        -
measure 52
*               F   0
Ef5    8        h     d
Ef5    4        q     d         f.
measure 53
Ef5   12-       h.    d        -
measure 54
Ef5    8        h     d
D5     4        q     d         p.
measure 55
D5     4        q     d         (
C5     4        q     d         )
C5     4        q     d         .
measure 56
B4     4        q n   d         .
rest   4        q
mheavy4         :|:
Bf4    4        q f   d         +.f
measure 57
*               E   18
Bf4    4        q f   d         (
C5     4        q     d         )
*               F   0
C5     4        q     d         .
measure 58
C5     4        q     d         (
Df5    4        q f   d         )
Df4    4        q f   u         p.
measure 59
Df4    4        q f   u         (
C4     4        q     u         )
C4     4        q     u         .
measure 60
C4     4        q     u         .
rest   4        q
C5     4        q     d         f.
measure 61
*               E   18
C5     4        q     d         (
D5     4        q n   d         ).+
*               F   0
D5     4        q     d         .
measure 62
D5     4        q     d         (
Ef5    4        q     d         )
Ef4    4        q     u         p
measure 63
Ef4    4        q     u         (
D4     4        q     u         )
D4     4        q     u         .
measure 64
D4     4        q     u         .
rest   4        q
Ef5    4        q     d         f.
measure 65
*               E   18
*      8        F   0
Ef5   12-       h.    d        -
measure 66
Ef5    8        h     d
Ef5    4        q     d         f.
measure 67
*               E   18
*      8        F   0
Ef5   12-       h.    d        -
measure 68
Ef5    8        h     d
D5     4        q     d         f.
measure 69
*               E   18
D5     4        q     d         (
Ef5    4        q     d         )
*               F   0
Ef5    4        q     d         .
measure 70
Ef5    4        q     d
Ef5    4        q     d
Ef5    4        q     d         p.
measure 71
Ef5    4        q     d         .
C5     4        q     d         .
B4     4        q n   d         t(
S   C33:uhn6s17t83e
gA4    5        s     u  [[
gB4    5        s     u  ]]      )
measure 72
C5     4        q     d         .
rest   4        q
*               B       Menuetto D.C.
P    C17:f39
mheavy2         :|
$   K:0
S  C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/03/03} [KHM:28807015]
TIMESTAMP: DEC/26/2001 [md5sum:c1c51ed109da1286734fa6308c1b8fa3]
07/25/94 W Hewlett
WK#:54,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Menuetto
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:3/4  C:13  D:Allegretto
G3     2        q     u         p
measure 1
G3     2        q     u         (
E3     1        e     u         ).
rest   1        e
rest   2        q
measure 2
C3     2        q     u
rest   2        q
D4     2        q     d         .
measure 3
D4     6        h.    d         Z
measure 4
D4     2        q     d         .
D4     2        q     d         .
C4     2        q     d         .
measure 5
C4     6        h.    d         Z
measure 6
C4     2        q     d         .
C4     2        q     d         .
A3     2        q     u         .
measure 7
G3     4        h     u         (
F3     2        q     u         )
measure 8
E3     2        q     u         .
rest   2        q
mheavy4         :|:
rest   2        q
measure 9
G3     2        q     u         p
rest   2        q
A3     2        q     u         .
measure 10
A3     2        q     u         (
F#3    1        e #   u         ).
rest   1        e
G4     2        q     d         .
measure 11
*               E   0
G3     2        q     u         (
G4     2        q     d         )
*               F   18
G4     2        q     d         .
measure 12
F#4    4        h #   d         f
E4     2        q     d         .
measure 13
E4     4        h     d
D4     2        q     d         .
measure 14
gD4    0        e     u         (
S   C1:pt25
C4     2        q     d         ).
B3     2        q     u         .
D4     2        q     d         .
measure 15
D4     4        h     d         Z
C4     2        q     d         .
measure 16
gC4    0        e     u         (
S   C1:pt25
B3     2        q     u         ).
A3     2        q     u         .
E4     2        q     d         .
measure 17
E4     4        h     d         Z
F#4    2        q #   d         .
measure 18
G4     2        q     d         .
rest   2        q
C4     2        q     d         .
measure 19
B3     4        h     u
F#3    1        e #   u  [      (
A3     1        e     u  ]      )
measure 20
G3     2        q     u         .
rest   2        q
rest   2        q
measure 21
G3     2        q     u         p
rest   2        q
rest   2        q
measure 22
G3     2        q     u
rest   2        q
rest   2        q
measure 23
rest   6
measure 24
rest   2        q
rest   2        q
G3     2        q     u         .
measure 25
G3     2        q     u         (
E3     1        e     u         ).
rest   1        e
rest   2        q
measure 26
C3     2        q     u
rest   2        q
D4     2        q     d         .
measure 27
D4     6        h.    d         Z
measure 28
D4     2        q     d         .
D4     2        q     d         .
C4     2        q     d         .
measure 29
C4     6        h.    d         Z
measure 30
C4     2        q     d         .
C4     2        q     d         .
A3     2        q     u         .
measure 31
G3     4        h     u         (
F3     2        q     u         )
measure 32
E3     2        q     u         .
rest   2        q
D#5    2        q #   d         p.
measure 33
D#5    4        h #   d         >
E5     2        q     d         .
measure 34
B4     2        q     d         .
B4     2        q     d         .
C#5    2        q #   d         .
measure 35
C#5    4        h #   d         >
D5     2        q     d         .
measure 36
A4     2        q     d         .
A4     2        q     d         .
F4     2        q     d         .
measure 37
G4     4        h     d         (
F4     2        q     d         )
measure 38
E4     2        q     d         .
rest   2        q
rest   2        q
measure 39
rest   2        q
rest   2        q
D4     2        q     d         .
measure 40
E4     2        q     d         .
rest   2        q
rest   2        q
measure 41
rest   2        q
rest   2        q
F3     2        q     u         .f
measure 42
*               E   0
C3     1        e     u  [      .
E3     1        e     u  =      .
F3     1        e     u  =      .
G3     1        e     u  =      .
A3     1        e     u  =      .
B3     1        e     u  ]      .
measure 43
C4     1        e     d  [      .
D4     1        e     d  =      .
E4     1        e     d  =      .
F4     1        e     d  =      .
G4     1        e     d  =      .
G#4    1        e #   d  ]      .
measure 44
A4     2        q     d         .
B4     2        q     d         .
C5     2        q     d         .
measure 45
*               FG  18  ff
G3     2        q n   u         .+
G4     2        q     d         .
 G3    2        q     d
F4     2        q     u
 G3    2        q     u         .
measure 46
E4     2        q     u
 G3    2        q     u         .
rest   2        q
S   C8:F2
*               B       Fine
P   C17:f39
mheavy4         :|:
$    K:-3   D:Trio
C4     2        q     d         f.
measure 47
C4     2        q     d
G3     1        e     u  [      .
C4     1        e     u  ]      .
Ef4    2        q     d
measure 48
Ef4    2        q     d
C4     1        e     d  [      .
Ef4    1        e     d  ]      .
G4     2        q     d         .
measure 49
G4     2        q     d
Ef4    1        e     d  [      (
G4     1        e     d  =
B4     1        e n   d  =
C5     1        e     d  ]      )
measure 50
G4     2        q     d
rest   2        q
B4     2        q n   d         f.
measure 51
*               E   18
B4     6-       h.n   d        -
measure 52
*               F   0
B4     4        h     d
B4     2        q n   d         f.
measure 53
B4     6-       h.n   d        -
measure 54
B4     4        h     d
G4     2        q     d         p.
measure 55
G4     2        q     d         .
C5     2        q     d         .
F#4    2        q #   d         .
measure 56
G4     2        q     d         .
rest   2        q
mheavy4         :|:
G4     2        q     d         f.
measure 57
*               E   18
*      4        F   0
G4     6-       h.    d        -
measure 58
G4     4        h     d
G4     2        q     d         p.
measure 59
G4     2        q     d         (
F4     2        q     d         )
F4     2        q     d         .
measure 60
F4     2        q     d         .
rest   2        q
A4     2        q n   d         f.
measure 61
*               E   18
*      4        F   0
A4     6-       h.n   d        -
measure 62
A4     4        h     d
A4     2        q n   d         .p
measure 63
A4     2        q n   d         (
G4     2        q     d         )
G4     2        q     d         .
measure 64
G4     2        q     d         .
rest   2        q
B4     2        q n   d         .f
measure 65
*               E   18
*      4        F   0
B4     6-       h.n   d        -
measure 66
B4     4        h     d
B4     2        q n   d         f.
measure 67
*               E   18
*      4        F   0
B4     6-       h.n   d        -
measure 68
B4     4        h     d
B4     2        q n   d         f.
measure 69
*               E   18
B4     2        q n   d         (
C5     2        q     d         )
*               F   0
C5     2        q     d         .
measure 70
C5     2        q     d
C5     2        q     d
C5     2        q     d         p.
measure 71
C5     2        q     d         .
G4     2        q     d         .
G4     2        q     d
measure 72
C4     2        q     d         .
rest   2        q
*               B       Menuetto D.C.
P    C17:f39
mheavy2         :|
$   K:0
S  C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/03/04} [KHM:28807015]
TIMESTAMP: DEC/26/2001 [md5sum:9f455252a6d147551f542befe10cd196]
07/25/94 W Hewlett
WK#:54,2      MV#:3
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Menuetto
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:2   T:3/4  C:22  D:Allegretto
rest   2        q
measure 1
C3     2        q     u         p
rest   2        q
rest   2        q
measure 2
C3     2        q     u         p
rest   2        q
A3     2        q     d         .
measure 3
A3     4        h     d         Z
G3     2        q     d         .
measure 4
C4     2        q     d         .
B3     2        q     d         .
G3     2        q     d         .
measure 5
G3     4        h     d         Z
F3     2        q     d
measure 6
Bf3    2        q f   d         .
A3     2        q     d         .
F3     2        q     d         .
measure 7
G2     6        h.    u
measure 8
C2     2        q     u
C3     2        q     u         .
mheavy4         :|:
rest   2        q
measure 9
G2     2        q     u         p
rest   2        q
rest   2        q
measure 10
G2     2        q     u
rest   2        q
rest   2        q
measure 11
G2     2        q     u
rest   2        q
rest   2        q
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
rest   2        q
B3     2        q     d         .
measure 15
B3     4        h     d         Z
A3     2        q     d         .
measure 16
gA3    0        e     u         (
S   C1:pt25
G3     2        q     d         ).
F#3    2        q #   d         .
G3     2        q     d         .
measure 17
G3     4        h     d         Z
F#3    2        q #   d         .
measure 18
E3     2        q     d         .
D3     2        q     d         .
C3     2        q     u         .
measure 19
D3     6        h.    d
measure 20
G3     2        q     d         .
G2     2        q     u         .
rest   2        q
measure 21
G2     2        q     u         p
rest   2        q
rest   2        q
measure 22
G2     2        q     u
rest   2        q
rest   2        q
measure 23
rest   6
measure 24
rest   6
measure 25
C3     2        q     u
rest   2        q
rest   2        q
measure 26
C3     2        q     u
rest   2        q
A3     2        q     d         .
measure 27
A3     4        h     d         Z
G3     2        q     d         .
measure 28
C4     2        q     d         .
B3     2        q     d         .
G3     2        q     d         .
measure 29
G3     4        h     d         Z
F3     2        q     d         .
measure 30
Bf3    2        q f   d         .
A3     2        q     d         .
F3     2        q     d         .
measure 31
G2     6        h.    u
measure 32
C3     2        q     u         .
rest   2        q
$    C:12
A4     2        q     d         .p
measure 33
A4     4        h     d         >
G4     2        q     d         .
measure 34
D#4    2        q #   d         .
E4     2        q     d         .
G4     2        q     d         .
measure 35
G4     4        h     d         >
F4     2        q n   d         .+
$    C:22
measure 36
C#4    2        q #   d         .
D4     2        q     d         .
F3     2        q     d         .
measure 37
G3     4        h     d
G2     2        q     u         .
measure 38
C3     2        q n   u         .+
rest   2        q
rest   2        q
measure 39
rest   4        h
G3     2        q     d         .
measure 40
C3     2        q     u         .
rest   2        q
rest   2        q
measure 41
rest   4        h
G2     2        q     u         .f
measure 42
*               E   0
C2     1        e     u  [      .
E2     1        e     u  =      .
F2     1        e     u  =      .
G2     1        e     u  =      .
A2     1        e     u  =      .
B2     1        e     u  ]      .
measure 43
C3     1        e     d  [      .
D3     1        e     d  =      .
E3     1        e     d  =      .
F3     1        e     d  =      .
G3     1        e     d  =      .
G#3    1        e #   d  ]      .
measure 44
A3     2        q     d         .
B3     2        q     d         .
C4     2        q     d         .
measure 45
*               FG  18  ff
G2     2        q n   u         .+
G2     2        q     u         .
G2     2        q     u         .
measure 46
C2     2        q     u         .
rest   2        q
S   C8:F2
*               B       Fine
P   C17:f39
mheavy4         :|:
$    K:-3   D:Trio
C3     2        q     u         .f
measure 47
C3     2        q     u
G2     1        e     u  [      .
C3     1        e     u  ]      .
Ef3    2        q     d
measure 48
Ef3    2        q     d
C3     1        e     d  [      .
Ef3    1        e     d  ]      .
G3     2        q     d         .
measure 49
G3     2        q     d
Ef3    1        e     d  [      (
G3     1        e     d  =
B3     1        e     d  =
C4     1        e     d  ]      )
measure 50
G3     2        q     d
rest   2        q
rest   2        q
measure 51
rest   6
measure 52
rest   6
measure 53
rest   6
measure 54
rest   2        q
rest   2        q
B3     2        q     d         p
measure 55
C4     2        q     d         .
Af3    2        q     d         .
F#3    2        q #   d         .
measure 56
G3     2        q     d         .
G2     2        q     u
mheavy4         :|:
Df4    2        q f   d         .f
measure 57
*               E   18
Df4    2        q f   d         (
C4     2        q     d         )
*               F   0
C4     2        q     d         .
measure 58
C4     2        q     d         (
Bf3    2        q     d         )
Bf3    2        q     d         .p
measure 59
Bf3    2        q     d         (
Af3    2        q     d         )
Af3    2        q     d         .
measure 60
Af3    2        q     d         .
rest   2        q
Ef4    2        q     d         .f
measure 61
*               E   18
Ef4    2        q     d         (
D4     2        q n   d         )+
*               F   0
D4     2        q     d         .
measure 62
D4     2        q     d         (
C4     2        q     d         )
C4     2        q     d         .p
measure 63
C4     2        q     d         (
B3     2        q     d         )
B3     2        q     d         .
measure 64
B3     2        q     d         .
rest   2        q
rest   2        q
measure 65
rest   6
measure 66
rest   2        q
rest   2        q
F4     2        q     d         .f
measure 67
*               E   18
F4     2        q     d         (
G4     2        q     d         )
*               F   0
G4     2        q     d         .
measure 68
G4     2        q     d         (
Af4    2        q f   d         )+
F4     2        q     d         .f
measure 69
*               E   18
F4     2        q     d         (
Ef4    2        q     d         )
*               F   0
Ef4    2        q     d         .
measure 70
Ef4    2        q     d         (
Af3    2        q     d         )
Af3    2        q     d         .p
measure 71
G3     6        h.    d
measure 72
C3     2        q     u         .
rest   2        q
*               B       Menuetto D.C.
P    C17:f39
mheavy2         :|
$   K:0
S  C0:d
/END
/eof
//
