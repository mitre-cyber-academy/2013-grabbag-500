&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/04/01} [KHM:2579732696]
TIMESTAMP: DEC/26/2001 [md5sum:1d3648a734c8f54bb6b571c63057f418]
08/31/94 W Hewlett
WK#:54,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Finale
Violino I
0 0
Group memberships: score
score: part 1 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:48   T:2/4  C:4  D:Adagio
G3    18        s.    u  [[     (.f
G3     6        t     u  ]]\    ).
measure 1
C4    48        q     u
rest  48        q
measure 2
rest  48        q
rest  24        e
G5    24        e     d         p
measure 3
G5    36        e.    d  [      (
A5     6        t     d  =[[
F5     6        t     d  ]]]    )
E5    24        e     d  [      (
F5    18        s.    d  =[
D5     6        t     d  ]]\    )
measure 4
C5    48        q     d         (
B4    24        e     d         )
rest  24        e
measure 5
rest  48        q
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 6
*               E   18
A5    36        e.    d  [      (
C6     4        t  3  d  =[[     *
B5     4        t  3  d  ===
*               F   0
A5     4        t  3  d  ]]]    )!
G5    12        s     d  [[     .(
F5    12        s     d  ==     .
E5    12        s     d  ==     .
D5    12        s     d  ]]     .)
measure 7
C5    24        e     d
rest  24        e
G4    36        e.    u  [      pp(
A4     6        t     u  =[[
F4     6        t     u  ]]]      )
measure 8             start-end1
E4    24        e     u
rest  24        e
rest  24        e
mheavy2         :|     stop-end1  start-end2
E4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 9                          disc-end2
C5    48-       q     d        -
C5    12        s     d  [[
B4     6        t     d  ==[    (
C5     6        t     d  =]]
B4     6        t     d  =[[
C5     6        t     d  ===
E5     6        t     d  ===
C5     6        t     d  ]]]    )
measure 10
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 11
D5    48-       q     d        -
D5    12        s     d  [[
C#5    6        t #   d  ==[    (
D5     6        t     d  =]]
C#5    6        t     d  =[[
D5     6        t     d  ===
F5     6        t     d  ===
D5     6        t     d  ]]]    )
measure 12
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 13
E5    48-       q     d        -
E5    12        s     d  [[
D#5    6        t #   d  ==[    (
E5     6        t     d  =]]
D#5    6        t     d  =[[
E5     6        t     d  ===
F5     6        t n   d  ===     +
D5     6        t n   d  ]]]    )
measure 14
D5     6        t     d  [[[    (
C5     6        t n   d  ===     +
B4     6        t     d  ===
C5     6        t     d  =]]    )
B4     6        t     d  =[[    (
C5     6        t     d  ===
E5     6        t     d  ===
C5     6        t     d  ]]]    )
C5     6        t     d  [[[    (
B4     6        t     d  ===
D5     6        t     d  ===
C5     6        t     d  =]]    )
E5     6        t     d  =[[    (
D5     6        t     d  ===
F#5    6        t #   d  ===
G5     6        t     d  ]]]    )
measure 15
G5     6        t     d  [[[    ([
D#5    6        t #   d  ===    )
D#5    6        t     d  ===    (
E5     6        t     d  =]]    )]
E5     6        t     d  =[[    (
B4     6        t     d  ===
C5     6        t     d  ===
A4     6        t     d  ]]]    )
G4    24        e     u  [
gB4    0        e     u          [
S   C1:pt15
A4    18        s.    u  =[     (]
G4     6        t     u  ]]\    )
measure 16
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 17
C5    48-       q     d        -
C5    12        s     d  [[
B4     6        t     d  ==[    (
C5     6        t     d  =]]
B4     6        t     d  =[[
C5     6        t     d  ===
E5     6        t     d  ===
C5     6        t     d  ]]]    )
measure 18
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 19
D5    48-       q n   d        -+
D5    12        s     d  [[
C#5    6        t #   d  ==[    (
D5     6        t     d  =]]
C#5    6        t     d  =[[
D5     6        t     d  ===
F5     6        t     d  ===
D5     6        t     d  ]]]    )
measure 20
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 21
E5    48-       q     d        -
E5    12        s     d  [[
D#5    6        t #   d  ==[    (
E5     6        t     d  =]]
D#5    6        t     d  =[[
E5     6        t     d  ===
F5     6        t n   d  ===     +
D5     6        t n   d  ]]]    )
measure 22
D5     6        t     d  [[[    (
C5     6        t     d  ===
B4     6        t     d  ===
C5     6        t     d  =]]    )
B4     6        t     d  =[[    (
C5     6        t     d  ===
E5     6        t     d  ===
C5     6        t     d  ]]]    )
C5     6        t     d  [[[    (
B4     6        t     d  ===
D5     6        t     d  ===
C5     6        t     d  =]]    )
E5     6        t     d  =[[    (
D5     6        t     d  ===
F#5    6        t #   d  ===
G5     6        t     d  ]]]    )
measure 23
G5     6        t     d  [[[    ([
D#5    6        t #   d  ===    )
D#5    6        t     d  ===    (
E5     6        t     d  =]]    )]
E5     6        t     d  =[[    (
B4     6        t     d  ===
C5     6        t     d  ===
A4     6        t     d  ]]]    )
G4    24        e     u  [
gB4    0        e     u          [
S   C1:pt15
A4    18        s.    u  =[     (]
G4     6        t     u  ]]\    )
measure 24
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 25
F5    48-       q n   d        -+
F5    12        s     d  [[
E5     6        t     d  ==[    (
F5     6        t     d  =]]
E5     6        t     d  =[[
F5     6        t     d  ===
A5     6        t     d  ===
F5     6        t     d  ]]]    )
measure 26
E5    24        e     d
rest  24        e
rest  24        e
C5    18        s.    d  [[     (.
C5     6        t     d  ]]\    ).
measure 27
Bf5   48-       q f   d        -
Bf5   12        s     d  [[
A5     6        t     d  ==[    (
Bf5    6        t     d  =]]
A5     6        t     d  =[[
Bf5    6        t     d  ===
D6     6        t     d  ===
Bf5    6        t     d  ]]]    )
measure 28
A5    24        e     d
rest  24        e
rest  24        e
A4    18        s.    u  [[
A4     6        t     u  ]]\
measure 29
A5    48-       q     d        -
A5    12        s     d  [[
G#5    6        t #   d  ==[    (
A5     6        t     d  =]]
G#5    6        t     d  =[[
A5     6        t     d  ===
Bf5    6        t f   d  ===
G5     6        t n   d  ]]]    )
measure 30
G5     6        t     d  [[[    (
F5     6        t     d  ===
E5     6        t     d  ===
F5     6        t     d  =]]    )
E5     6        t     d  =[[    (
F5     6        t     d  ===
A5     6        t     d  ===
F5     6        t     d  ]]]    )
F5     6        t     d  [[[    (
E5     6        t     d  ===
G5     6        t     d  ===
F5     6        t     d  =]]    )
A5     6        t     d  =[[    (
G5     6        t     d  ===
B5     6        t n   d  ===     +
C6     6        t     d  ]]]    )
measure 31
C6     6        t     d  [[[    ([
G#5    6        t #   d  ===    )
G#5    6        t     d  ===    (
A5     6        t     d  =]]    )]
A5     6        t     d  =[[    ([
E5     6        t     d  ===    )
E5     6        t     d  ===    (
F5     6        t     d  ]]]    )]
F5     6        t     d  [[[    ([
C#5    6        t #   d  ===    )
C#5    6        t     d  ===    (
D5     6        t     d  =]]    )]
D5     6        t     d  =[[     [
A4     6        t     d  ===
D5     6        t     d  ===
C5     6        t n   d  ]]]     ]
measure 32
C5     6        t     u  [[[    (
B4     6        t     u  ===
A4     6        t     u  ===
G4     6        t     u  =]]    )
G3    24        e     u  ]
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 33
C5    48-       q     d        -
C5    12        s     d  [[
B4     6        t     d  ==[    (
C5     6        t     d  =]]
B4     6        t     d  =[[
C5     6        t     d  ===
E5     6        t     d  ===
C5     6        t     d  ]]]    )
measure 34
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 35
D5    48-       q     d        -
D5    12        s     d  [[
C#5    6        t #   d  ==[    (
D5     6        t     d  =]]
C#5    6        t     d  =[[
D5     6        t     d  ===
F5     6        t     d  ===
D5     6        t     d  ]]]    )
measure 36
D5    24        e     d
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 37
E5    36        e.    d  [      (
F5    12        s     d  ]\     )
F5    36        e.    d  [      (t
S   C34:uwn14s8t93
E5     6        t     d  =[[
F5     6        t     d  ]]]    )
measure 38
G5     6        t     d  [[[    (
F5     6        t     d  ===
E5     6        t     d  ===
F5     6        t     d  =]]
G5     6        t     d  =[[
A5     6        t     d  ===
B5     6        t     d  ===
C6     6        t     d  ]]]    )
C6     6        t     d  [[[    (
G#5    6        t #   d  ===    )
G#5    6        t     d  ===    (
A5     6        t     d  =]]    )
A5     6        t     d  =[[    (
E5     6        t     d  ===
F5     6        t     d  ===
D5     6        t     d  ]]]    )
measure 39
C5    24-       e     d  [     -(
C5     6        t     d  =[[
E5     6        t     d  ===
G5     6        t     d  ===
E5     6        t     d  ]]]
G5     6        t     d  [[[
E5     6        t     d  ===
G5     6        t     d  ===
E5     6        t     d  ]]]    )
F5    12        s     d  [[     (.
B4    12        s     d  ]]     ).
mdouble 40
$   K:-3
C5    24        e     d
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 41
C5    48-       q     d        -
C5    12        s     d  [[
B4     6        t     d  ==[    (
C5     6        t     d  =]]
B4     6        t n   d  =[[
C5     6        t     d  ===
Ef5    6        t     d  ===
C5     6        t     d  ]]]    )
measure 42
G4    24        e     u
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 43
Af4   48-       q     u        -
Af4   12        s     d  [[
Bf4    6        t f   d  ==[    (+
C5     6        t     d  =]]
Df5    6        t f   d  =[[
Ef5    6        t     d  ===
F5     6        t     d  ===
Df5    6        t     d  ]]]    )
measure 44
Bf4   48-       q f   d        -
Bf4   12        s     d  [[
C5     6        t     d  ==[    (
Df5    6        t f   d  =]]
Ef5    6        t     d  =[[
Df5    6        t     d  ===
C5     6        t     d  ===
Df5    6        t     d  ]]]    )
measure 45
C5    18        s.    d  [[     (
D5     6        t n   d  =]\    )+
D5    18        s.    d  =[     (t
S  C34:uhn8s13t87
C5     3        x     d  ==[[
D5     3        x     d  ]]]]   )
Ef5   18        s.    d  [[     (
F5     6        t     d  =]\    )
F5    18        s.    d  =[     (t
S  C34:uwn8s13t87
Ef5    3        x     d  ==[[
F5     3        x     d  ]]]]   )
measure 46
G5    24        e     d  [      (
Bf5    6        t f   d  =[[
Af5    6        t f   d  ===
G5     6        t     d  ===
Af5    6        t     d  ]]]    )
Bf5   12        s     d  [[     (
Af5    6        t     d  ==[
G5     6        t     d  =]]
F5     6        t     d  =[[
Ef5    6        t f   d  ===
D5     6        t     d  ===
Ef5    6        t     d  ]]]    )
measure 47
D5     6        t     d  [[[    (
C5     6        t     d  ===
B4     6        t n   d  ===
C5     6        t     d  =]]
D5     6        t     d  =[[
Ef5    6        t     d  ===
C5     6        t     d  ===
Af4    6        t     d  ]]]    )
G4    24        e     u  [      (
F4    24        e     u  ]       t
S   C34:uwn10s13t91e
gEf4   5        s     u  [[
gF4    5        s     u  ]]     )
measure 48
Ef4   48        q     u
rest  24        e
Bf4   18        s.f   d  [[     (.+
Bf4    6        t     d  ]]\    ).
measure 49
Af5   48-       q f   d        -
Af5   12        s     d  [[
G5     6        t     d  ==[    (
Af5    6        t     d  =]]
G5     6        t     d  =[[
Af5    6        t     d  ===
Bf5    6        t f   d  ===
Af5    6        t     d  ]]]    )
measure 50
G5    24        e     d
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 51
G5    48-       q     d        -
G5    12        s     d  [[
F#5    6        t #   d  ==[    (
G5     6        t     d  =]]
F#5    6        t     d  =[[
G5     6        t     d  ===
Af5    6        t     d  ===
F5     6        t n   d  ]]]    )
measure 52
Ef5   24        e     d
rest  24        e
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 53
Ef5   48-       q f   d        -
Ef5   12        s     d  [[
D5     6        t     d  ==[    (
C5     6        t     d  =]]
B4     6        t n   d  =[[
C5     6        t     d  ===
D5     6        t     d  ===
C5     6        t     d  ]]]    )
measure 54
G5    24        e     d
rest  24        e
F5     6        t     d  [[[    (
Ef5    6        t     d  ===
D5     6        t     d  ===
C5     6        t     d  =]]
B4     6        t n   d  =[[
C5     6        t     d  ===
D5     6        t     d  ===
C5     6        t     d  ]]]    )
measure 55
B4    24        e n   d
rest  24        e
F4     6        t     u  [[[    (pp
Ef4    6        t     u  ===
D4     6        t     u  ===
C4     6        t     u  =]]
B3     6        t n   u  =[[
C4     6        t     u  ===
D4     6        t     u  ===
C4     6        t     u  ]]]    )
measure 56
B3    24        e n   u
rest  24        e               F
mheavy3         |:
P    C0:q16
S   C0:W0
$   K:0    D:Presto
E4    24        e     u  [      .mf
F4    24        e     u  ]      .
measure 57
F#4   24        e #   u  [      (
G4    24        e     u  ]      )
A4    24        e     u  [      .
B4    24        e     u  ]      .
measure 58
D5    24        e     d  [      (
C5    24        e     d  ]      )
B4    24        e     d  [      .
C5    24        e     d  ]      .
measure 59
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
F5    24        e     d  [      .
E5    24        e     d  ]      .
measure 60
E5    24        e     d  [      (
D5    24        e     d  ]      )
C6    24        e n   d  [      .+f
C6    24        e     d  ]      .
measure 61
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 62
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 63
A5    24        e     d  [      .
A5    24        e     d  ]      .
G5    12        s     d  [[     (
F#5   12        s #   d  ==
E5    12        s     d  ==
F#5   12        s     d  ]]     )
measure 64
G5    48        q     d
mheavy2         :|
B4    24        e     d  [      .mf
C5    24        e     d  ]      .
measure 65
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
F5    24        e     d  [      .
E5    24        e     d  ]      .
measure 66
E5    24        e     d  [      (
D5    24        e     d  ]      )
E5    24        e     d  [      .
F5    24        e     d  ]      .
measure 67
F#5   24        e #   d  [      (
G5    24        e     d  ]      )
C6    24        e n   d  [      .+
Bf5   24        e f   d  ]      .
measure 68
Bf5   24        e f   d  [      (
A5    24        e     d  ]      )
A5    24        e     d  [      .
E5    24        e     d  ]      .
measure 69
G5    24        e     d  [      (
F5    24        e     d  ]      )
A5    24        e     d  [      .
D5    24        e     d  ]      .
measure 70
F5    24        e     d  [      (
E5    24        e     d  ]      )
G5    24        e     d  [      .
E5    24        e     d  ]      .
measure 71
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
A4    24        e     d  [      .
D5    24        e     d  ]      .
measure 72
C5    24        e n   d  [      (+
B4    24        e     d  ]      )
B4    24        e     d  [      .p
C5    24        e     d  ]      .
measure 73
E5    24        e     d  [      (
D5    24        e     d  ]      )
D5    24        e     d  [      .
E5    24        e     d  ]      .
measure 74
G5    24        e     d  [      (
F5    24        e     d  ]      )
rest  48        q
measure 75
rest  96
measure 76
rest  48        q
D5    24        e     d  [      .pp
E5    24        e     d  ]      .
measure 77
G5    24        e     d  [      (
F5    24        e     d  ]      )
rest  48        q
measure 78
rest  96
measure 79
rest  96
measure 80
rest  48        q
E4    24        e     u  [      .mf
F4    24        e     u  ]      .
measure 81
F#4   24        e #   u  [      (
G4    24        e     u  ]      )
A4    24        e     u  [      .
B4    24        e     u  ]      .
measure 82
D5    24        e     d  [      (
C5    24        e     d  ]      )
B4    24        e     d  [      .
C5    24        e     d  ]      .
measure 83
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
F5    24        e     d  [      .
E5    24        e     d  ]      .
measure 84
E5    24        e     d  [      (
D5    24        e     d  ]      )
C6    24        e n   d  [      .+f
C6    24        e     d  ]      .
measure 85
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 86
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 87
A5    24        e     d  [      .
A5    24        e     d  ]      .
C5    12        s     d  [[     (
B4    12        s     d  ==
A4    12        s     d  ==
B4    12        s     d  ]]     )
measure 88
C5    24        e     d         .
rest  24        e
B4    24        e     d  [      .mf
C5    24        e     d  ]      .
measure 89
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
F5    24        e     d  [      .
E5    24        e     d  ]      .
measure 90
E5    24        e     d  [      (
D5    24        e     d  ]      )
E5    24        e     d  [      .
F5    24        e     d  ]      .
measure 91
F#5   24        e #   d  [      (
G5    24        e     d  ]      )
C6    24        e n   d  [      .+
Bf5   24        e f   d  ]      .
measure 92
Bf5   24        e f   d  [      (
A5    24        e     d  ]      )
A5    24        e     d  [      .
E5    24        e     d  ]      .
measure 93
G5    24        e     d  [      (
F5    24        e     d  ]      )
A5    24        e     d  [      .
D5    24        e     d  ]      .
measure 94
F5    24        e     d  [      (
E5    24        e     d  ]      )
G5    24        e     d  [      .
E5    24        e     d  ]      .
measure 95
C#5   24        e #   d  [      (
D5    24        e     d  =      )
A4    24        e     d  =      .
D5    24        e     d  ]      .
measure 96
C5    24        e n   d  [      (+
B4    24        e     d  ]      )
B4    24        e     d  [      .p
C5    24        e     d  ]      .
measure 97
E5    24        e     d  [      (
D5    24        e     d  ]      )
D5    24        e     d  [      .
E5    24        e     d  ]      .
measure 98
G5    24        e     d  [      (
F5    24        e     d  ]      )
rest  48        q
measure 99
rest  96
measure 100
rest  48        q
D5    24        e     d  [      .pp
E5    24        e     d  ]      .
measure 101
G5    24        e     d  [      (
F5    24        e     d  ]      )
rest  48        q
measure 102
rest  96
measure 103
rest  96
measure 104
rest  48        q
E4    24        e     u  [      .p
F4    24        e     u  ]      .
measure 105
F#4   24        e #   u  [      (
G4    24        e     u  ]      )
A4    24        e     u  [      .
B4    24        e     u  ]      .
measure 106
D5    24        e     d  [      (
C5    24        e     d  ]      )
B4    24        e     d  [      .
C5    24        e     d  ]      .
measure 107
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
F5    24        e     d  [      .
E5    24        e     d  ]      .
measure 108
E5    24        e     d  [      (
D5    24        e     d  ]      )
C6    24        e n   d  [      .+
C6    24        e     d  ]      .
measure 109
*               D       cresc.
P    C17:33
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 110
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 111
A5    24        e     d  [      .mf
A5    24        e     d  ]      .
C5    12        s     d  [[     (
B4    12        s     d  ==
A4    12        s     d  ==
B4    12        s     d  ]]     )
measure 112
C5    24        e     d  [      .
C5    24        e     d  ]      .
F5    24        e     d  [      .p
F5    24        e     d  ]      .
measure 113
F5    24        e     d  [      (
E5    24        e     d  ]      )
D#5   24        e #   d  [      .
D#5   24        e     d  ]      .
measure 114
D#5   24        e #   d  [      (
E5    24        e     d  =      )
E5    24        e     d  =      .
E5    24        e     d  ]      .
measure 115
E5    24        e     d  [      (
D5    24        e n   d  =      )+
C#5   24        e #   d  =      .
C#5   24        e     d  ]      .
measure 116
C#5   24        e #   d  [      (
D5    24        e     d  ]      )
A5    24        e     d  [      .mf
A5    24        e     d  ]      .
measure 117
*               D       cresc.
P     C17:f33
A5    24        e     d  [      (
G5    24        e     d  ]      )
C6    24        e n   d  [      .+
C6    24        e     d  ]      .
measure 118
C6    24        e     d  [      (>
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 119
C6    24        e     d  [      (Z
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 120
C6    24        e     d  [      (Z
B5    24        e     d  ]      )
C6    24        e     d  [      .
C6    24        e     d  ]      .
measure 121
F6    96-       h     d        -f
measure 122
S   C0:W0
F6    48        q     d         F
rest  24        e
P   C0:q32
$   D:Adagio
G3    18        s.    u  [[     (.f
G3     6        t     u  ]]\    ).
measure 123
C4    48        q     u
rest  48        q
measure 124
rest  48        q
rest  24        e               p
G5    24        e     d
measure 125
G5    36        e.    d  [      (
A5     6        t     d  =[[
F5     6        t     d  ]]]    )
E5    24        e     d  [      (
F5    18        s.    d  =[
D5     6        t     d  ]]\    )
measure 126
C5    48        q     d         (
B4    24        e     d         )
rest  24        e
measure 127
rest  48        q
rest  24        e
G4    18        s.    u  [[     (.
G4     6        t     u  ]]\    ).
measure 128
*               E   15
A5    36        e.    d  [      (
*               F   0
C6     4        t  3  d  =[[     *
B5     4        t  3  d  ===
A5     4        t  3  d  ]]]    )!
G5    12        s     d  [[     (.
F5    12        s     d  ==      .
E5    12        s     d  ==      .
D5    12        s     d  ]]     ).
measure 129
C5    24        e     d
rest  24        e
G4    36        e.    u  [      (pp
A4     6        t     u  =[[
F4     6        t     u  ]]]
measure 130
E4    24        e     u         )
rest  24        e
rest  24        e
C5    18        s.    d  [[     (.
C5     6        t     d  ]]\    ).
measure 131
Bf5   48-       q f   d        -
Bf5   12        s     d  [[
A5     6        t     d  ==[    (
Bf5    6        t     d  =]]
A5     6        t     d  =[[
Bf5    6        t     d  ===
C6     6        t     d  ===
Bf5    6        t     d  ]]]    )
measure 132
A5    24        e     d
rest  24        e
rest  24        e
A5    18        s.    d  [[     (.
A5     6        t     d  ]]\    ).
measure 133
F6    48-       q     d        -
F6    12        s     d  [[
E6     6        t     d  ==[    (
D6     6        t     d  =]]
E6     6        t     d  =[[
D6     6        t     d  ===
C6     6        t     d  ===
B5     6        t n   d  ]]]    )+
measure 134
C6    24        e     d
rest  24        e
rest  24        e
C5    18        s.    d  [[     (.
C5     6        t     d  ]]\    ).
measure 135
Bf5   48-       q f   d        -
Bf5   12        s     d  [[
A5     6        t     d  ==[    (
Bf5    6        t     d  =]]
A5     6        t     d  =[[
Bf5    6        t     d  ===
C6     6        t     d  ===
Bf5    6        t     d  ]]]    )
measure 136
A5    24        e     d
rest  24        e
rest  24        e
A5    18        s.    d  [[     (.
A5     6        t     d  ]]\    ).
measure 137
G5    24        e     d  [      (
F5    24        e     d  ]      )
G5     6        t     d  [[[    (
F5     6        t     d  ===
E5     6        t     d  ===
D5     6        t     d  =]]
E5     6        t     d  =[[
D5     6        t     d  ===
C5     6        t     d  ===
B4     6        t     d  ]]]    )
measure 138
C5    24        e     d
rest  24        e
G4     6        t     u  [[[    (pp
F4     6        t     u  ===
E4     6        t     u  ===
D4     6        t     u  =]]
E4     6        t     u  =[[
D4     6        t     u  ===
C4     6        t     u  ===
B3     6        t     u  ]]]    )
measure 139
C4    24        e     u
rest  24        e
E4    24        e     u  [
rest  12        s
P   C1:y10
E4    12        s     u  ]\
measure 140
C4    24        e     u
rest  24        e
rest  48        q
*               B       Fine
P    C17:f33
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/04/02} [KHM:2579732696]
TIMESTAMP: DEC/26/2001 [md5sum:2813b9e70b1458b5605e1029d8f27335]
08/31/94 W Hewlett
WK#:54,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Finale
Violino II
0 0
Group memberships: score
score: part 2 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:24   T:2/4  C:4  D:Adagio
G3     9        s.    u  [[     (.f
G3     3        t     u  ]]\    ).
measure 1
C4    24        q     u
rest  24        q
measure 2
rest  24        q
rest  12        e
G4    12        e     u         p
measure 3
G4    18        e.    u  [      (
A4     3        t     u  =[[
F4     3        t     u  ]]]    )
E4    12        e     u  [      (
A4     9        s.    u  =[
F4     3        t     u  ]]\    )
measure 4
E4    24        q     u         (
D4    12        e     u         )
rest  12        e
measure 5
rest  24        q
rest  12        e
G4     9        s.    u  [[     (.
G4     3        t     u  ]]\    ).
measure 6
*               E   18
F5    18        e.    d  [      (
A5     2        t  3  d  =[[     *
G5     2        t  3  d  ===
*               F   0
F5     2        t  3  d  ]]]    )!
E5     6        s     d  [[     (.
D5     6        s     d  ==      .
C5     6        s     d  ==      .
A4     6        s     d  ]]     ).
measure 7
E4    12        e     u
rest  12        e
B3    24        q     u         (pp
measure 8             start-end1
C4    12        e     u         )
rest  12        e
rest  12        e
mheavy2         :|     stop-end1  start-end2
C4     6        s     u  [[      (
S    C0:V60
E4     6        s     u  ==      )
E4     6        s     u  ==     .(
E4     6        s     u  ]]     .
E4     6        s     u  [[     .
E4     6        s     u  ==     .
E4     6        s     u  ==     .
E4     6        s     u  ]]     .)
measure 9                         disc-end2
E4     6        s     u  [[     (.
E4     6        s     u  ==      .
E4     6        s     u  ==      .
E4     6        s     u  ]]     ).
E4     6        s     u  [[     (.
E4     6        s     u  ==      .
E4     6        s     u  ==      .
E4     6        s     u  ]]     ).
measure 10
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
measure 11
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 12
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 13
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 B3    6        s     u
E4     6        s     u  ==
 B3    6        s     u
E4     6        s     u  ==
 B3    6        s     u
E4     6        s     u  ]]
 B3    6        s     u
measure 14
E4     6        s     u  [[
 C4    6        s     u
E4     6        s     u  ==
 C4    6        s     u
D4     6        s     u  ==
 A3    6        s     u
D4     6        s     u  ]]
 A3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
G4     6        s     u  ==
G4     6        s     u  ]]
measure 15
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
G4     6        s     u  [[
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
F#4    6        s #   u  ==
 A3    6        s     u
F#4    6        s     u  ]]
 A3    6        s     u
measure 16
G4     6        s     u  [[
 G3    6        s     u
G4     6        s     u  ==
 G3    6        s     u
G4     6        s     u  ==
 G3    6        s     u
G4     6        s     u  ]]
 G3    6        s     u
G4     6        s     u  [[
 A3    6        s     u
G4     6        s     u  ==
 A3    6        s     u
F4     6        s n   u  ==     +
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 17
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
measure 18
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
measure 19
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 20
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 21
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 B3    6        s     u
E4     6        s     u  ==
 B3    6        s     u
E4     6        s     u  ==
 B3    6        s     u
E4     6        s     u  ]]
 B3    6        s     u
measure 22
E4     6        s     u  [[
 C4    6        s     u
E4     6        s     u  ==
 C4    6        s     u
D4     6        s     u  ==
 A3    6        s     u
D4     6        s     u  ]]
 A3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
G4     6        s     u  ==
G4     6        s     u  ]]
measure 23
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
G4     6        s     u  [[
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
F#4    6        s #   u  ==
 A3    6        s     u
F#4    6        s     u  ]]
 A3    6        s     u
measure 24
G4     6        s     u  [[
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ]]
 B3    6        s     u
G4     6        s     u  [[
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ]]
 B3    6        s     u
measure 25
F4     6        s     u  [[
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ]]
 G3    6        s     u
F4     6        s n   u  [[     +
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ]]
 G3    6        s     u
measure 26
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
measure 27
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
measure 28
F4     6        s     u  [[
 A3    6        s     u
F4     6        s     u  ==
 A3    6        s     u
F4     6        s     u  ==
 A3    6        s     u
F4     6        s     u  ]]
 A3    6        s     u
F4     6        s     u  [[
 A3    6        s     u
F4     6        s     u  ==
 A3    6        s     u
F4     6        s     u  ==
 A3    6        s     u
F4     6        s     u  ]]
 A3    6        s     u
measure 29
E4     6        s     u  [[
 A3    6        s     u
E4     6        s     u  ==
 A3    6        s     u
E4     6        s     u  ==
 A3    6        s     u
E4     6        s     u  ]]
 A3    6        s     u
E4     6        s     u  [[
 A3    6        s     u
E4     6        s     u  ==
 A3    6        s     u
E4     6        s     u  ==
 A3    6        s     u
E4     6        s     u  ]]
 A3    6        s     u
measure 30
D4     6        s     u  [[
D4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
measure 31
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
measure 32
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
 G3    6        s     u
G4     6        s     u  ]]
 G3    6        s     u
G4     6        s     u  [[
 A3    6        s     u
G4     6        s     u  ==
 A3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ]]
 B3    6        s     u
measure 33
E4     6        s     u  [[
 C4    6        s     u
E4     6        s     u  ==
 C4    6        s     u
E4     6        s     u  ==
 C4    6        s     u
E4     6        s     u  ]]
 C4    6        s     u
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
measure 34
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
measure 35
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 36
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
F4     6        s     u  [[
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ==
 B3    6        s     u
F4     6        s     u  ]]
 B3    6        s     u
measure 37
E4     6        s     d  [[
C5     6        s     d  ==
C5     6        s     d  ==
C5     6        s     d  ]]
C5     6        s     d  [[
C5     6        s     d  ==
C5     6        s     d  ==
C5     6        s     d  ]]
measure 38
C5     6        s     d  [[
C5     6        s     d  ==
C5     6        s     d  ==
C5     6        s     d  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
measure 39
E4     6        s     d  [[
C5     6        s     d  ==
C5     6        s     d  ==
C5     6        s     d  ]]
C5     6        s     d  [[
C5     6        s     d  ==
B4     6        s     d  ==
B4     6        s     d  ]]
mdouble 40
$   K:-3
C5     6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
measure 41
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
measure 42
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
measure 43
F4     6        s     u  [[
F4     6        s     u  ==
F4     6        s     u  ==
F4     6        s     u  ]]
F4     6        s     u  [[
F4     6        s     u  ==
F4     6        s     u  ==
F4     6        s     u  ]]
measure 44
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
measure 45
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Af4    6        s     u  ==
Af4    6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
F4     6        s     u  ==
F4     6        s     u  ]]
measure 46
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
measure 47
Ef4    6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     u  [[
Ef4    6        s     u  ==
D4     6        s     u  ==
D4     6        s     u  ]]
measure 48
Ef4    6        s     u  [[
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ]]
 Bf3   6        s     u
G4     6        s     u  [[
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ]]
 Bf3   6        s     u
measure 49
F4     6        s     u  [[
 Bf3   6        s     u
F4     6        s     u  ==
 Bf3   6        s     u
F4     6        s     u  ==
 Bf3   6        s     u
F4     6        s     u  ]]
 Bf3   6        s     u
F4     6        s     u  [[
 Bf3   6        s     u
F4     6        s     u  ==
 Bf3   6        s     u
F4     6        s     u  ==
 Bf3   6        s     u
F4     6        s     u  ]]
 Bf3   6        s     u
measure 50
G4     6        s     u  [[
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ]]
 Bf3   6        s     u
G4     6        s     u  [[
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ==
 Bf3   6        s     u
G4     6        s     u  ]]
 Bf3   6        s     u
measure 51
F4     6        s     u  [[
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 52
Ef4    6        s     u  [[
 G3    6        s     u
Ef4    6        s     u  ==
 G3    6        s     u
Ef4    6        s     u  ==
 G3    6        s     u
Ef4    6        s     u  ]]
 G3    6        s     u
Ef4    6        s     u  [[
 G3    6        s     u
Ef4    6        s     u  ==
 G3    6        s     u
Ef4    6        s     u  ==
 G3    6        s     u
Ef4    6        s     u  ]]
 G3    6        s     u
measure 53
F#4    6        s #   u  [[
F#4    6        s     u  ==
F#4    6        s     u  ==
F#4    6        s     u  ]]
F#4    6        s     u  [[
F#4    6        s     u  ==
F#4    6        s     u  ==
F#4    6        s     u  ]]
measure 54
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
F#4    6        s #   u  [[
 C4    6        s     u
F#4    6        s     u  ==
 C4    6        s     u
F#4    6        s     u  ==
 C4    6        s     u
F#4    6        s     u  ]]
 C4    6        s     u
measure 55
G4     6        s     u  [[
 B3    6        s n   u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ==
 B3    6        s     u
G4     6        s     u  ]]
 B3    6        s     u
F#4    6        s #   u  [[     pp
F#4    6        s     u  ==
F#4    6        s     u  ==
F#4    6        s     u  ]]
measure 56
G4    12        e     u
rest  12        e               F
mheavy3         |:
S    C0:V100
P    C0:q16
$   K:0    D:Presto
C4    12        e     u  [      .
D4    12        e     u  ]      .
measure 57
D#4   12        e #   u  [      (
E4    12        e n   u  ]      )+
F4    12        e     u  [      .
D4    12        e n   u  ]      .
measure 58
F4    12        e     u  [      (
E4    12        e     u  =      )
G4    12        e     u  =      .
A4    12        e     u  ]      .
measure 59
A#4   12        e #   u  [      (
B4    12        e     u  ]      )
D5    12        e     d  [      .
C5    12        e n   d  ]      .+
measure 60
C5    12        e     d  [      (
B4    12        e     d  ]      )
C5    12        e     d  [      .f
C5    12        e     d  ]      .
measure 61
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 62
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 63
E5    12        e     d  [      .
E5    12        e     d  =      .
A4    12        e     d  =      .
A4    12        e     d  ]      .
measure 64
B4    24        q     d
mheavy2         :|
G4    12        e     u  [      .mf
A4    12        e     u  ]      .
measure 65
A#4   12        e #   u  [      (
B4    12        e     u  ]      )
D5    12        e     d  [      .
C5    12        e n   d  ]      .+
measure 66
C5    12        e     d  [      (
B4    12        e     d  ]      )
C5    12        e     d  [      .
D5    12        e     d  ]      .
measure 67
D#5   12        e #   d  [      (
E5    12        e     d  ]      )
A5    12        e     d  [      .
G5    12        e     d  ]      .
measure 68
G5    12        e     d  [      (
F5    12        e     d  ]      )
F5    12        e     d  [      .
C#5   12        e #   d  ]      .
measure 69
F5    12        e     d  [      (
D5    12        e     d  ]      )
F5    12        e     d  [      .
B4    12        e     d  ]      .
measure 70
D5    12        e     d  [      (
C5    12        e     d  ]      )
E5    12        e     d  [      .
G4    12        e     d  ]      .
measure 71
Bf4   12        e f   u  [      (
A4    12        e     u  ]      )
F4    12        e     u  [      .
A4    12        e     u  ]      .
measure 72
E4    12        e     u  [      (
D4    12        e     u  ]      )
G4    12        e     u  [      .p
A4    12        e     u  ]      .
measure 73
C5    12        e     d  [      (
B4    12        e     d  ]      )
B4    12        e     d  [      .
C#5   12        e #   d  ]      .
measure 74
E5    12        e     d  [      (
D5    12        e     d  ]      )
rest  24        q
measure 75
rest  48
measure 76
rest  24        q
B4    12        e     d  [      .pp
C#5   12        e #   d  ]      .
measure 77
E5    12        e     d  [      (
D5    12        e     d  ]      )
rest  24        q
measure 78
rest  48
measure 79
rest  48
measure 80
rest  24        q
C4    12        e     u  [      .mf
D4    12        e     u  ]      .
measure 81
D#4   12        e #   u  [      (
E4    12        e     u  ]      )
F4    12        e     u  [      .
D4    12        e n   u  ]      .
measure 82
F4    12        e     u  [      (
E4    12        e     u  ]      )
G4    12        e     u  [      .
A4    12        e     u  ]      .
measure 83
A#4   12        e #   u  [      (
B4    12        e     u  ]      )
D5    12        e     d  [      .
C5    12        e n   d  ]      .+
measure 84
C5    12        e     d  [      (
B4    12        e     d  ]      )
C5    12        e     d  [      .f
C5    12        e     d  ]      .
measure 85
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 86
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 87
C5    12        e     u  [      .
C5    12        e     u  =      .
F4    12        e     u  =      .
F4    12        e     u  ]      .
measure 88
E4    12        e     u
rest  12        e
G4    12        e     u  [      .mf
A4    12        e     u  ]      .
measure 89
A#4   12        e #   u  [      (
B4    12        e     u  ]      )
D5    12        e     d  [      .
C5    12        e n   d  ]      .+
measure 90
C5    12        e     d  [      (
B4    12        e     d  =      )
C5    12        e     d  =      .
D5    12        e     d  ]      .
measure 91
D#5   12        e #   d  [      (
E5    12        e     d  ]      )
A5    12        e     d  [      .
G5    12        e     d  ]      .
measure 92
G5    12        e     d  [      (
F5    12        e     d  =      )
F5    12        e     d  =      .
C#5   12        e #   d  ]      .
measure 93
F5    12        e     d  [      (
D5    12        e n   d  =      )+
F5    12        e     d  =      .
B4    12        e     d  ]      .
measure 94
D5    12        e     d  [      (
C5    12        e     d  ]      )
E5    12        e     d  [      .
A4    12        e     d  ]      .
measure 95
Bf4   12        e f   u  [      (
A4    12        e     u  ]      )
F4    12        e     u  [      .
A4    12        e     u  ]      .
measure 96
E4    12        e     u  [      (
D4    12        e     u  =      )
G4    12        e     u  =      .p
A4    12        e     u  ]      .
measure 97
C5    12        e     d  [      (
B4    12        e     d  =      )
B4    12        e     d  =      .
C#5   12        e #   d  ]      .
measure 98
E5    12        e     d  [      (
D5    12        e     d  ]      )
rest  24        q
measure 99
rest  48
measure 100
rest  24        q
B4    12        e     d  [      .pp
C#5   12        e #   d  ]      .
measure 101
E5    12        e     d  [      (
D5    12        e     d  ]      )
rest  24        q
measure 102
rest  48
measure 103
rest  48
measure 104
rest  24        q
C4    12        e n   u  [      .+p
D4    12        e     u  ]      .
measure 105
D#4   12        e #   u  [      (
E4    12        e     u  =      )
F4    12        e     u  =      .
D4    12        e n   u  ]      .
measure 106
F4    12        e     u  [      (
E4    12        e     u  ]      )
G4    12        e     u  [      .
A4    12        e     u  ]      .
measure 107
A#4   12        e #   u  [      (
B4    12        e     u  ]      )
D5    12        e     d  [      .
C5    12        e n   d  ]      .+
measure 108
C5    12        e     d  [      (
B4    12        e     d  ]      )
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 109
*               D       cresc.
P    C17:33
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 110
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 111
C5    12        e     u  [      .mf
C5    12        e     u  =      .
F4    12        e     u  =      .
F4    12        e     u  ]      .
measure 112
E4    24        q     u
C5    12        e     d  [      .p
C5    12        e     d  ]      .
measure 113
B4    12        e     d  [      .
B4    12        e     d  =      .
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 114
B4    12        e     d  [      .
B4    12        e     d  =      .
Bf4   12        e f   d  =      .
Bf4   12        e     d  ]      .
measure 115
A4    12        e     u  [      .
A4    12        e     u  =      .
Bf4   12        e f   u  =      .
Bf4   12        e     u  ]      .
measure 116
A4    12        e     u  [      .
A4    12        e     u  =      .
D5    12        e     u  =      .mf
D5    12        e     u  ]      .
measure 117
*               D       cresc.
P     C17:f33
D5    12        e     d  [      (
E5    12        e     d  =      )
C5    12        e n   d  =      .+
C5    12        e     d  ]      .
measure 118
D5    24        q     d         >
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 119
D5    24        q     d         Z
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 120
D5    24        q     d         Z
C5    12        e     d  [      .
C5    12        e     d  ]      .
measure 121
D5    48-       h     d        -f
measure 122
D5    24        q     d         F
rest  12        e
P   C0:q32
$   D:Adagio
G3     9        s.    u  [[     (.f
G3     3        t     u  ]]\    ).
measure 123
C4    24        q     u
rest  24        q
measure 124
rest  24        q
rest  12        e
G4    12        e     u         p
measure 125
G4    18        e.    u  [      (
A4     3        t     u  =[[
F4     3        t     u  ]]]    )
E4    12        e     u  [      (
A4     9        s.    u  =[
F4     3        t     u  ]]\    )
measure 126
E4    24        q     u         (
D4    12        e     u         )
rest  12        e
measure 127
rest  24        q
rest  12        e
G4     9        s.    u  [[     (.
G4     3        t     u  ]]\    ).
measure 128
*               E   15
F5    18        e.    d  [      (
*               F   0
A5     2        t  3  d  =[[     *
G5     2        t  3  d  ===
F5     2        t  3  d  ]]]    )!
E5     6        s     u  [[     (.
D5     6        s     u  ==      .
C5     6        s     u  ==      .
A4     6        s     u  ]]     ).
measure 129
E4    12        e     u
rest  12        e
B3    24        q     u         (
measure 130
C4     6        s     u  [[     )
S    C0:V60
E4     6        s     u  ==     (.
E4     6        s     u  ==      .
E4     6        s     u  ]]     ).
E4     6        s     u  [[     (.
E4     6        s     u  ==      .
E4     6        s     u  ==      .
E4     6        s     u  ]]     ).
measure 131
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
measure 132
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
measure 133
B4     6        s n   u  [[     +
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ]]
 D4    6        s     u
B4     6        s     u  [[
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
D5     6        s     u  ==
D5     6        s     u  ]]
measure 134
C5     6        s     u  [[
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
measure 135
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
measure 136
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
measure 137
B4     6        s n   u  [[     +
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ]]
 D4    6        s     u
B4     6        s     u  [[
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ==
 D4    6        s     u
B4     6        s     u  ]]
 D4    6        s     u
measure 138
C5     6        s     u  [[
 E4    6        s     u
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
F4     6        s     u  [[     pp
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ==
 G3    6        s     u
F4     6        s     u  ]]
 G3    6        s     u
measure 139
E4    12        e     u
 G3   12        e     u
rest  12        e
E4    12        e     u
 G3   12        e     u
rest  12        e
measure 140
E4    12        e     u
 G3   12        e     u
rest  12        e
rest  24        q
*               B       Fine
P    C17:f33
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/04/03} [KHM:2579732696]
TIMESTAMP: DEC/26/2001 [md5sum:4020fd8aac567b48a8d97b0715136544]
08/31/94 W Hewlett
WK#:54,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Finale
Viola
0 0
Group memberships: score
score: part 3 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:24   T:2/4  C:13  D:Adagio
G3     9        s.    u  [[     (.f
G3     3        t     u  ]]\    ).
measure 1
C4    24        q     d
E4    12        e     d  [      (p
F4    12        e     d  ]      )
measure 2
G4    18        e.    d  [      (
A4     3        t     d  =[[
G4     3        t     d  ]]]    )
F4    12        e     d  [      (
E4    12        e     d  ]      )
measure 3
D4    12        e     u  [      (
B3    12        e     u  =      )
C4    12        e     u  =      .
F3    12        e     u  ]      .
measure 4
G3    12        e     d  [      .
G4    12        e     d  =      .
G3    12        e     d  ]      .
G3     9        s.    u  [[     (.
G3     3        t     u  ]]\    ).
measure 5
F4    18        e.    d  [      (
G4     3        t     d  =[[
F4     3        t     d  ]]]    )
E4    12        e     d  [      (
F4    12        e     d  ]      )
measure 6
D4    24        q     d         (
E4     6        s     u  [[     )
B3     6        s     u  ==     (.
C4     6        s     u  ==      .
F3     6        s     u  ]]     ).
measure 7
G3    12        e     u
rest  12        e
F3    18        e.    u  [      (pp
D3     6        s     u  ]\     )
measure 8             start-end1
C3    12        e     u
rest  12        e
rest  12        e
mheavy2         :|     stop-end1  start-end2
C3     6        s     u  [[     (
S    C0:V60
C4     6        s     u  ==     ).
C4     6        s     u  ==     (.
C4     6        s     u  ]]      .
C4     6        s     u  [[      .
C4     6        s     u  ==      .
C4     6        s     u  ==      .
C4     6        s     u  ]]     ).
measure 9                         disc-end2
C4     6        s     d  [[     (.
C4     6        s     d  ==      .
C4     6        s     d  ==      .
C4     6        s     d  ]]     ).
C4     6        s     d  [[     (.
C4     6        s     d  ==      .
C4     6        s     d  ==      .
C4     6        s     d  ]]     ).
measure 10
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 11
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 12
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 13
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 14
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
B3     6        s     d  [[
B3     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 15
E4     6        s     d  [[
E4     6        s     d  ==
A3     6        s     d  ==
A3     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 16
B3     6        s     u  [[
B3     6        s     u  ==
B3     6        s     u  ==
B3     6        s     u  ]]
C4     6        s     d  [[
C4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 17
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 18
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 19
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 20
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 21
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 22
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
B3     6        s     d  [[
B3     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 23
E4     6        s     d  [[
E4     6        s     d  ==
A3     6        s     d  ==
A3     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 24
B3     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 25
D4     6        s     d  [[
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ]]
 B3    6        s     d
D4     6        s     d  [[
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ]]
 B3    6        s     d
measure 26
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 27
G4     6        s     d  [[
 Bf3   6        s f   d
G4     6        s     d  ==
 Bf3   6        s     d
G4     6        s     d  ==
 Bf3   6        s     d
G4     6        s     d  ]]
 Bf3   6        s     d
G4     6        s     d  [[
 Bf3   6        s     d
G4     6        s     d  ==
 Bf3   6        s     d
G4     6        s     d  ==
 Bf3   6        s     d
G4     6        s     d  ]]
 Bf3   6        s     d
measure 28
F4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 29
C#4    6        s #   d  [[
C#4    6        s     d  ==
C#4    6        s     d  ==
C#4    6        s     d  ]]
C#4    6        s     d  [[
C#4    6        s     d  ==
C#4    6        s     d  ==
C#4    6        s     d  ]]
measure 30
F4     6        s     d  [[
F4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
E4     6        s     d  [[
E4     6        s     d  ==
C4     6        s n   d  ==     +
C4     6        s     d  ]]
measure 31
C4     6        s     d  [[
C4     6        s     d  ==
C#4    6        s #   d  ==
C#4    6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 32
D4     6        s     d  [[
D4     6        s     d  ==
B3     6        s     d  ==
B3     6        s     d  ]]
C4     6        s n   d  [[     +
C4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 33
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 34
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 35
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 36
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
D4     6        s     u  [[
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ==
 G3    6        s     u
D4     6        s     u  ]]
 G3    6        s     u
measure 37
E4     6        s     u  [[
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ==
 G3    6        s     u
E4     6        s     u  ]]
 G3    6        s     u
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 38
G3     6        s     u  [[
G3     6        s     u  ==
G3     6        s     u  ==
G3     6        s     u  ]]
A3     6        s     d  [[
A3     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
measure 39
E4     6        s     d  [[
E4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
E4     6        s     d  [[
G4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
mdouble 40
$   K:-3
Ef4    6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 41
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 42
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 43
Af3    6        s     u  [[
Af3    6        s     u  ==
Af3    6        s     u  ==
Af3    6        s     u  ]]
Af3    6        s     u  [[
Af3    6        s     u  ==
Af3    6        s     u  ==
Af3    6        s     u  ]]
measure 44
G3     6        s     u  [[
G3     6        s     u  ==
Af3    6        s     u  ==
Af3    6        s     u  ]]
Bf3    6        s     u  [[
Bf3    6        s     u  ==
G3     6        s     u  ==
G3     6        s     u  ]]
measure 45
C4     6        s     u  [[
C4     6        s     u  ==
Bf3    6        s     u  ==
Bf3    6        s     u  ]]
Bf3    6        s     u  [[
Bf3    6        s     u  ==
Bf3    6        s     u  ==
Bf3    6        s     u  ]]
measure 46
Bf3    6        s     d  [[
Bf3    6        s     d  ==
Ef4    6        s     d  ==
Ef4    6        s     d  ]]
Bf3    6        s     u  [[
Bf3    6        s     u  ==
Bf3    6        s     u  ==
Bf3    6        s     u  ]]
measure 47
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
Bf3    6        s     u  [[
Bf3    6        s     u  ==
Af3    6        s     u  ==
Af3    6        s     u  ]]
measure 48
G3     6        s     u  [[
Ef4    6        s     u  ==
Ef4    6        s     u  ==
Ef4    6        s     u  ]]
Ef4    6        s     d  [[
Ef4    6        s     d  ==
Ef4    6        s     d  ==
Ef4    6        s     d  ]]
measure 49
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
measure 50
Ef4    6        s     d  [[
Ef4    6        s     d  ==
Ef4    6        s     d  ==
Ef4    6        s     d  ]]
Ef4    6        s     d  [[
Ef4    6        s     d  ==
Ef4    6        s     d  ==
Ef4    6        s     d  ]]
measure 51
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
B3     6        s n   u  [[
B3     6        s     u  ==
B3     6        s     u  ==
B3     6        s     u  ]]
measure 52
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 53
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
Af3    6        s     u  [[
Af3    6        s     u  ==
C4     6        s     u  ==
C4     6        s     u  ]]
measure 54
B3     6        s n   u  [[
B3     6        s     u  ==
B3     6        s     u  ==
B3     6        s     u  ]]
Ef4    6        s f   d  [[     +
Ef4    6        s     d  ==
Ef4    6        s     d  ==
Ef4    6        s     d  ]]
measure 55
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
Ef4    6        s     u  [[     pp
Ef4    6        s     u  ==
Ef3    6        s     u  ==
Ef3    6        s     u  ]]
measure 56
D3    12        e     u
rest  12        e
mheavy3         |:
P    C0:q16
$   K:0    D:Presto
rest  24        q
measure 57
rest  48
measure 58
rest  48
measure 59
rest  12        e
S    C0:V100
G4    12        e     d  [      .mf
B3    12        e     d  =      .
C4    12        e n   d  ]      .+
measure 60
G3    12        e     d  [      .
G4    12        e     d  =      .
G4    12        e     d  =      .f
G4    12        e     d  ]      .
measure 61
G4    24        q     d         >
G4    12        e     d  [      .
G4    12        e     d  ]      .
measure 62
G4    24        q     d         >
G4    12        e     d  [      .
G4    12        e     d  ]      .
measure 63
C5    12        e     d  [      .
C5    12        e     d  =      .
C5    12        e     d  =      .
C5    12        e     d  ]      .
measure 64
B4    24        q     d
mheavy2         :|
rest  24        q
measure 65
rest  12        e
G4    12        e     d  [      .mf
B3    12        e     d  =      .
C4    12        e n   d  ]      .+
measure 66
G3    12        e     d  [      .
G4    12        e     d  ]      .
rest  24        q
measure 67
rest  48
measure 68
rest  24        q
rest  12        e
A4    12        e     d         .
measure 69
D4    12        e     d  [      .
D5    12        e     d  ]      .
rest  24        q
measure 70
rest  24        q
rest  12        e
G4    12        e     d         .
measure 71
E4    12        e     d  [      .
A4    12        e     d  ]      .
rest  12        e
F#4   12        e #   d         .
measure 72
G4    12        e     d  [      .
G3    12        e     d  ]      .
rest  24        q
measure 73
rest  48
measure 74
rest  24        q
B3    12        e     u  [      .p
C4    12        e n   u  ]      .+
measure 75
E4    12        e     d  [      (
D4    12        e     d  =      )
D4    12        e     d  =      .
E4    12        e     d  ]      .
measure 76
G4    12        e     d  [      (
F4    12        e     d  ]      )
rest  24        q
measure 77
rest  24        q
D3    12        e     u  [      .pp
E3    12        e     u  ]      .
measure 78
G3    12        e     u  [      (
F3    12        e     u  ]      )
rest  24        q
measure 79
rest  48
measure 80
rest  48
measure 81
rest  48
measure 82
rest  48
measure 83
rest  12        e
G4    12        e     d  [      .mf
B3    12        e     d  =      .
C4    12        e n   d  ]      .+
measure 84
G3    12        e     d  [      .
G4    12        e     d  =      .
G4    12        e     d  =      .f
G4    12        e     d  ]      .
measure 85
G3    12        e     d  [      >
G4    12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 86
G3    12        e     d  [      >
G4    12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 87
A4    12        e     d  [      .
A4    12        e     d  =      .
D4    12        e     d  =      .
D4    12        e     d  ]      .
measure 88
E4    12        e     d         .
rest  12        e
rest  24        q
measure 89
rest  12        e
G4    12        e     d  [      .mf
B3    12        e     d  =      .
C4    12        e n   d  ]      .+
measure 90
G3    12        e     d  [      .
G4    12        e     d  ]      .
rest  24        q
measure 91
rest  48
measure 92
rest  24        q
rest  12        e
A4    12        e     d         .
measure 93
D4    12        e     d  [      .
D5    12        e     d  ]      .
rest  24        q
measure 94
rest  24        q
rest  12        e
G4    12        e     d         .
measure 95
E4    12        e     d  [      .
A4    12        e     d  ]      .
rest  12        e
F#4   12        e #   d         .
measure 96
G4    12        e     d  [      .
G3    12        e     d  ]      .
rest  24        q
measure 97
rest  48
measure 98
rest  24        q
B3    12        e     u  [      .p
C3    12        e n   u  ]      .+
measure 99
E4    12        e     d  [      (
D4    12        e     d  =      )
D4    12        e     d  =      .
E4    12        e     d  ]      .
measure 100
G4    12        e     d  [      (
F4    12        e     d  ]      )
rest  24        q
measure 101
rest  24        q
D3    12        e     u  [      .pp
E3    12        e     u  ]      .
measure 102
G3    12        e     u  [      (
F3    12        e     u  ]      )
rest  24        q
measure 103
rest  48
measure 104
rest  48
measure 105
rest  48
measure 106
rest  48
measure 107
rest  12        e
G4    12        e     d  [      .p
B3    12        e     d  =      .
C4    12        e n   d  ]      .+
measure 108
G3    12        e     d  [      .
G4    12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 109
*               D       cresc.
P    C17:33
G3    12        e     d  [      >
G4    12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 110
G3    12        e     d  [      >
G4    12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 111
A4    12        e     d  [      .mf
A4    12        e     d  ]      .
D4    12        e     d  [      .
D4    12        e     d  ]      .
measure 112
C4    24        q     d
A4    12        e     d  [      .p
A4    12        e     d  ]      .
measure 113
G#4   12        e #   d  [      .
G#4   12        e     d  =      .
A4    12        e     d  =      .
A4    12        e     d  ]      .
measure 114
G#4   12        e #   d  [      .
G#4   12        e     d  =      .
G4    12        e n   d  =      .
G4    12        e     d  ]      .
measure 115
F#4   12        e #   d  [      .
F#4   12        e     d  =      .
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 116
F#4   12        e #   d  [      .
F#4   12        e     d  =      .
B4    12        e n   d  =      .mf+
B4    12        e     d  ]      .
measure 117
*               D       cresc.
P     C17:f33
B4    12        e     d  [      (
C5    12        e n   d  =      )+
G4    12        e     d  =      .
G4    12        e     d  ]      .
measure 118
G4    24        q     d         >
G4    12        e     d  [      .
G4    12        e     d  ]      .
measure 119
G4    24        q     d         Z
G4    12        e     d  [      .
G4    12        e     d  ]      .
measure 120
G4    24        q     d         Z
G4    12        e     d  [      .
G4    12        e     d  ]      .
measure 121
G4    48-       h     d        -f
measure 122
G4    24        q     d         F
rest  12        e
P   C0:q32
$   D:Adagio
G3     9        s.    u  [[     (.f
G3     3        t     u  ]]\    ).
measure 123
C4    24        q     u
 E3   24        q     u
E4    12        e     d  [      (p
F4    12        e     d  ]      )
measure 124
G4    18        e.    d  [      (
A4     3        t     d  =[[
G4     3        t     d  ]]]    )
F4    12        e     d  [      (
E4    12        e     d  ]      )
measure 125
D4    12        e     u  [      (
B3    12        e     u  =      )
C4    12        e     u  =      .
F3    12        e     u  ]      .
measure 126
G3    12        e     d  [      .
G4    12        e     d  =      .
G3    12        e     d  ]      .
G3     9        s.    u  [[     (.
G3     3        t     u  ]]\    ).
measure 127
F4    18        e.    d  [      (
G4     3        t     d  =[[
F4     3        t     d  ]]]    )
E4    12        e     d  [      (
F4    12        e     d  ]      )
measure 128
D4    24        q     d         (
E4     6        s     u  [[     )
B3     6        s     u  ==     .(
C4     6        s     u  ==     .
F3     6        s     u  ]]     .)
measure 129
G3    12        e     u
rest  12        e
F3    18        e.    u  [      (pp
D3     6        s     u  ]\     )
measure 130
C3     6        s     u  [[     .
S    C0:V60
C4     6        s     u  ==     .(
C4     6        s     u  ==     .
C4     6        s     u  ]]     .)
C4     6        s     u  [[     .(
C4     6        s     u  ==     .
C4     6        s     u  ==     .
C4     6        s     u  ]]     .)
measure 131
C4     6        s     d  [[
C4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
E4     6        s     d  [[
E4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
measure 132
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
measure 133
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
measure 134
E4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 135
C4     6        s     d  [[
C4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
E4     6        s     d  [[
E4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
measure 136
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
measure 137
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
F4     6        s     d  [[
F4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
measure 138
E4     6        s     u  [[
G3     6        s     u  ==
G3     6        s     u  ==
G3     6        s     u  ]]
D4     6        s     d  [[     pp
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ==
 B3    6        s     d
D4     6        s     d  ]]
 B3    6        s     d
measure 139
E4    12        e     d
 C4   12        e     d
rest  12        e
G3    12        e     u  [
rest   6        s
G3     6        s     u  ]\
measure 140
E3    12        e     u
rest  12        e
rest  24        q
*               B       Fine
P    C17:f33
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {haydn/dover/quart/op54n2/stage2/04/04} [KHM:2579732696]
TIMESTAMP: DEC/26/2001 [md5sum:c2a759812adbf405b268a0acb97fd39e]
08/31/94 W Hewlett
WK#:54,2      MV#:4
Dover reprint of Eulenburg Edition
String Quartet Op.54, No.2, in C Major
Finale
Violoncello
0 0
Group memberships: score
score: part 4 of 4
&
Initial conversion from stage 1 to stage 2
&
$  K:0   Q:24   T:2/4  C:22  D:Adagio
G2     9        s.    u  [[     (.f
G2     3        t     u  ]]\    ).
measure 1
C3    24        q     u
C4    12        e     d  [      (
D4    12        e     d  ]      )
measure 2
E4    18        e.    d  [      (
F4     3        t     d  =[[
E4     3        t     d  ]]]    )
D4    12        e     d  [      (
C4    12        e     d  ]      )
measure 3
B3    12        e     d  [      (
G3    12        e     d  =      )
C4    12        e     d  =      .
F3    12        e     d  ]      .
measure 4
G3    12        e     u  [      .
G2    12        e     u  =      .
G2    12        e     u  ]      .
G2     9        s.    u  [[     (.
G2     3        t     u  ]]\    ).
measure 5
D4    18        e.    d  [      (
E4     3        t     d  =[[
D4     3        t     d  ]]]    )
C#4   12        e #   d  [      (
D4    12        e     d  ]      )
measure 6
B3    24        q     d         (
C4     6        s n   d  [[     )+
G3     6        s     d  ==     (.
A3     6        s     d  ==      .
F3     6        s     d  ]]     ).
measure 7
G3    24        q     d
rest  12        e
G2    12        e     u         (pp
measure 8             start-end1
C3    12        e     u         )
rest  12        e
rest  12        e
mheavy2         :|     stop-end1  start-end2
C2    12        e     u  [      (
E2    12        e     u  =
G2    12        e     u  =
C3    12        e     u  ]      )
measure 9                         disc-end2
E3    12        e     d  [      (
G3    12        e     d  =
C4    12        e     d  =
E4    12        e     d  ]      )
$  C:4
measure 10
G4    12        e     d  [      (
C5    12        e     d  =
E5    12        e     d  =
C5    12        e     d  ]      )
$  C:22
measure 11
G2    12        e     d  [      (
G3    12        e     d  =
B3    12        e     d  =
D4    12        e     d  ]      )
$  C:4
measure 12
G4    12        e     d  [      (
B4    12        e     d  =
D5    12        e     d  =
F5    12        e     d  ]      )
$  C:22
measure 13
C2    12        e     u  [      (
C3    12        e     u  =      )
G#2   12        e #   u  =      (
G#3   12        e #   u  ]      )
measure 14
A3    12        e     d  [      (
F#3   12        e #   d  =      )
G3    12        e n   d  =      +
B2    12        e     d  ]
measure 15
C3    12        e     u  [
C3    12        e     u  =
D3    12        e     u  =
D3    12        e     u  ]
measure 16
G2    12        e     u  [
G3    12        e     u  ]
rest  24        q
measure 17
C2    12        e     u  [      (
E2    12        e     u  =
G2    12        e     u  =
C3    12        e     u  ]      )
measure 18
E3    12        e     d  [      (
G3    12        e     d  =
C4    12        e     d  =
E4    12        e     d  ]      )
measure 19
G2    12        e     d  [      (
G3    12        e     d  =
B3    12        e     d  =
D4    12        e     d  ]      )
$  C:4
measure 20
G4    12        e     d  [      (
B4    12        e     d  =
D5    12        e     d  =
F5    12        e     d  ]      )
$  C:22
measure 21
C2    12        e     u  [      (
C3    12        e     u  =      )
G#2   12        e #   u  =      (
G#3   12        e #   u  ]      )
measure 22
A3    12        e     d  [      (
F#3   12        e #   d  =      )
G3    12        e n   d  =      +
B2    12        e     d  ]
measure 23
C3    12        e     u  [
C3    12        e     u  =
D3    12        e     u  =
D3    12        e     u  ]
measure 24
G2    12        e     u  [      (
B2    12        e     u  =
D3    12        e     u  =
G3    12        e     u  ]      )
measure 25
G2    12        e     u  [      (
B2    12        e     u  =
D3    12        e     u  =
G3    12        e     u  ]      )
measure 26
C3    12        e     d  [      (
E3    12        e     d  =
G3    12        e     d  =
C4    12        e     d  ]      )
measure 27
C3    12        e     d  [      (
E3    12        e     d  =
G3    12        e     d  =
C4    12        e     d  ]      )
measure 28
F2    12        e     u  [      (
A2    12        e     u  =
C3    12        e     u  =
F3    12        e     u  ]      )
measure 29
C#3   12        e #   d  [      (
E3    12        e     d  =
A3    12        e     d  =
C#4   12        e #   d  ]      )
measure 30
D3    12        e     u  [
B2    12        e     u  =
C3    12        e n   u  =      +
E2    12        e     u  ]
measure 31
F2    36        q.    u
F#2   12        e #   u
measure 32
G2    12        e     u  [
G3    12        e     u  ]
rest  24        q
measure 33
C2    12        e     u  [      (
C3    12        e     u  =
E3    12        e     u  =
G3    12        e     u  ]      )
measure 34
C4    12        e     d  [      (
$  C:4
E4    12        e     d  =
G4    12        e     d  =
C5    12        e     d  ]      )
$  C:22
measure 35
G2    12        e     d  [      (
G3    12        e     d  =
B3    12        e     d  =
D4    12        e     d  ]      )
$  C:4
measure 36
G4    12        e     d  [      (
B4    12        e     d  =
D5    12        e     d  =
F5    12        e     d  ]      )
$  C:22
measure 37
C2    12        e     u  [      (
C3    12        e     u  =      )
A2    12        e     u  =      (
A3    12        e     u  ]      )
measure 38
E2    12        e     u  [      (
E3    12        e     u  =      )
F2    12        e     u  =      (
F3    12        e     u  ]      )
measure 39
G2    12        e     u  [      (
G3    12        e     u  =      )
G2    12        e     u  =      (
G3    12        e     u  ]      )
mdouble 40
$   K:-3
C2    12        e     u  [      (
Ef2   12        e     u  =
G2    12        e     u  =
C3    12        e     u  ]      )
measure 41
Ef3   12        e     d  [      (
G3    12        e     d  =
C4    12        e     d  =
Ef4   12        e     d  ]      )
$  C:4
measure 42
G4    12        e     d  [      (
C5    12        e     d  =
Ef5   12        e     d  =
$  C:22
C3    12        e     d  ]      )
measure 43
Df2   12        e f   u  [      (
F2    12        e     u  =
Af2   12        e     u  =
Df3   12        e f   u  ]      )
measure 44
Ef3   12        e     d  [      (
F3    12        e     d  =
G3    12        e     d  =
Ef3   12        e     d  ]      )
measure 45
Af3   12        e     d  [      (
F3    12        e     d  =
G3    12        e     d  =
D3    12        e n   d  ]      )+
measure 46
Ef3   12        e     u  [      (
C3    12        e     u  =      )
G2    12        e     u  =      (
G3    12        e     u  ]      )
measure 47
Af3   12        e     d  [      (
Af2   12        e     d  =      )
Bf2   12        e     d  =
Bf2   12        e     d  ]
measure 48
Ef2   12        e     u  [      (
G2    12        e     u  =
Bf2   12        e     u  =
Ef3   12        e     u  ]      )
measure 49
D3    12        e     d  [      (
F3    12        e     d  =
Bf3   12        e     d  =
D4    12        e     d  ]      )
measure 50
Ef2   12        e     u  [      (
G2    12        e     u  =
Bf2   12        e     u  =
Ef3   12        e     u  ]      )
measure 51
B2    12        e n   d  [      (
D3    12        e     d  =
G3    12        e     d  =
B3    12        e n   d  ]      )
measure 52
C3    12        e     d  [      (
Ef3   12        e     d  =
G3    12        e     d  =
C4    12        e     d  ]      )
measure 53
Af2   12        e     d  [      (
C3    12        e     d  =
Ef3   12        e     d  =
Af3   12        e     d  ]      )
measure 54
G2    12        e     u  [
G3    12        e     u  =
G2    12        e     u  =
G3    12        e     u  ]
measure 55
G2    12        e     u  [
G3    12        e     u  =
G2    12        e     u  =      pp
G3    12        e     u  ]
measure 56
G2    12        e     u
rest  12        e               F
mheavy3         |:
P    C0:q16
$   K:0    D:Presto
rest  24        q
measure 57
rest  12        e
C3    12        e     u  [      .mf
C2    12        e     u  =      .
C3    12        e     u  ]      .
measure 58
C2    12        e     u  [      .
C3    12        e     u  ]      .
rest  24        q
measure 59
rest  48
measure 60
rest  24        q
E4    12        e     d  [      .f
E4    12        e     d  ]      .
measure 61
F4    24        q     d         >
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 62
F4    24        q     d         >
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 63
C4    12        e     d  [      .
C4    12        e     d  =      .
D4    12        e     d  =      .
D4    12        e     d  ]      .
measure 64
G3    24        q     d
mheavy2         :|
rest  24        q
measure 65
rest  48
measure 66
rest  48
measure 67
rest  12        e
C4    12        e     d  [      .mf
C3    12        e     d  =      .
E3    12        e     d  ]      .
measure 68
F2    12        e     u  [      .
F3    12        e     u  ]      .
rest  24        q
measure 69
rest  24        q
rest  12        e
G3    12        e     d         .
measure 70
C3    12        e     d  [      .
C4    12        e     d  ]      .
rest  12        e
C3    12        e     u         .
measure 71
F3    12        e     u  [      .
F2    12        e     u  ]      .
rest  12        e
F#3   12        e #   d         .
measure 72
G3    12        e     u  [      .
G2    12        e     u  ]      .
rest  24        q
measure 73
rest  48
measure 74
rest  24        q
G3    12        e     d  [      .p
A3    12        e     d  ]      .
measure 75
C4    12        e     d  [      (
B3    12        e     d  =      )
B3    12        e     d  =      .
C#4   12        e #   d  ]      .
measure 76
E4    12        e     d  [      (
D4    12        e     d  ]      )
rest  24        q
measure 77
rest  24        q
B2    12        e     u  [      .pp
C#3   12        e #   u  ]      .
measure 78
E3    12        e     d  [      (
D3    12        e     d  ]      )
rest  24        q
measure 79
rest  48
measure 80
rest  48
measure 81
rest  12        e
C3    12        e n   u  [      .f+
C2    12        e     u  =      .
C3    12        e     u  ]      .
measure 82
C2    12        e     u  [      .
C3    12        e     u  ]      .
rest  24        q
measure 83
rest  48
measure 84
rest  24        q
E4    12        e     d  [      .f
E4    12        e     d  ]      .
measure 85
F4    24        q     d         >
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 86
F4    24        q     d         >
E3    12        e     d  [      .
E3    12        e     d  ]      .
measure 87
F3    12        e     d  [      .
F3    12        e     d  =      .
G3    12        e     d  =      .
G3    12        e     d  ]      .
measure 88
C3    12        e     d  [      .
C4    12        e     d  ]      .
rest  24        q
measure 89
rest  48
measure 90
rest  48
measure 91
rest  12        e
C4    12        e     d  [      .mf
C3    12        e     d  =      .
E3    12        e     d  ]      .
measure 92
F2    12        e     u  [      .
F3    12        e     u  ]      .
rest  24        q
measure 93
rest  24        q
rest  12        e
G3    12        e     d         .
measure 94
C3    12        e     d  [      .
C4    12        e     d  ]      .
rest  12        e
C3    12        e     u         .
measure 95
F3    12        e     u  [      .
F2    12        e     u  ]      .
rest  12        e
F#3   12        e #   d         .
measure 96
G3    12        e     u  [      .
G2    12        e     u  ]      .
rest  24        q
measure 97
rest  48
measure 98
rest  24        q
G3    12        e     d  [      .p
A3    12        e     d  ]      .
measure 99
C4    12        e     d  [      (
B3    12        e     d  ]      )
B3    12        e     d  [      .
C#4   12        e #   d  ]      .
measure 100
E4    12        e     d  [      (
D4    12        e     d  ]      )
rest  24        q
measure 101
rest  24        q
B2    12        e     u  [      .pp
C#3   12        e #   u  ]      .
measure 102
E3    12        e     d  [      (
D3    12        e     d  ]      )
rest  24        q
measure 103
rest  48
measure 104
rest  48
measure 105
rest  12        e
C3    12        e n   u  [      .p+
C2    12        e     u  =      .
C3    12        e     u  ]      .
measure 106
C2    12        e     u  [      .
C3    12        e     u  ]      .
rest  24        q
measure 107
rest  48
measure 108
rest  24        q
E4    12        e     d  [      .p
E4    12        e     d  ]      .
measure 109
*               D       cresc.
P    C17:33
F4    24        q     d         >
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 110
F4    24        q     d         >
E3    12        e     d  [      .
E3    12        e     d  ]      .
measure 111
F3    12        e     d  [      .mf
F3    12        e     d  =      .
G3    12        e     d  =      .
G3    12        e     d  ]      .
measure 112
A3    24        q     d
rest  24        q
measure 113
rest  48
measure 114
rest  48
measure 115
rest  48
measure 116
rest  24        q
F4    12        e n   d  [      .mf+
F4    12        e     d  ]      .
measure 117
*               D       cresc.
P     C17:f33
F4    12        e     d  [      (
E4    12        e     d  =      )
E4    12        e     d  =      .
E4    12        e     d  ]      .
measure 118
F4    24        q     d         >
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 119
F4    24        q     d         Z
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 120
F4    24        q     d         Z
E4    12        e     d  [      .
E4    12        e     d  ]      .
measure 121
B3    48-       h     d        -f
measure 122
B3    24        q     d         F
rest  12        e
P   C0:q32
$   D:Adagio
G2     9        s.    u  [[     (.f
G2     3        t     u  ]]\    ).
measure 123
C3    24        q     u
C4    12        e     d  [      (p
D4    12        e     d  ]      )
measure 124
E4    18        e.    d  [      (
F4     3        t     d  =[[
E4     3        t     d  ]]]    )
D4    12        e     d  [      (
C4    12        e     d  ]      )
measure 125
B3    12        e     d  [      (
G3    12        e     d  =      )
C4    12        e     d  =      .
F3    12        e     d  ]      .
measure 126
G3    12        e     u  [      .
G2    12        e     u  =      .
G2    12        e     u  ]      .
G2     9        s.    u  [[     (.
G2     3        t     u  ]]\    ).
measure 127
D4    18        e.    d  [      (
E4     3        t     d  =[[
D4     3        t     d  ]]]    )
C#4   12        e #   d  [      (
D4    12        e     d  ]      )
measure 128
B3    24        q     d         (
C4     6        s n   d  [[     )+
G3     6        s     d  ==     (.
A3     6        s     d  ==      .
F3     6        s     d  ]]     ).
measure 129
G3    24        q     d
rest  12        e
G2    12        e     u         pp
measure 130
C2    12        e     u  [      (
E2    12        e     u  =
G2    12        e     u  =
C3    12        e     u  ]      )
measure 131
E3    12        e     d  [      (
G3    12        e     d  =
C4    12        e     d  =
E4    12        e     d  ]      )
measure 132
C2    12        e     u  [      (
F2    12        e     u  =
A2    12        e     u  =
C3    12        e     u  ]      )
measure 133
C2    12        e     d  [      (
B3    12        e n   d  =      +
D4    12        e     d  =
F4    12        e     d  ]      )
measure 134
C2    12        e     u  [      (
E2    12        e     u  =
G2    12        e     u  =
C3    12        e     u  ]      )
measure 135
E3    12        e     d  [      (
G3    12        e     d  =
C4    12        e     d  =
E4    12        e     d  ]      )
measure 136
C2    12        e     u  [      (
F2    12        e     u  =
A2    12        e     u  =
C3    12        e     u  ]      )
measure 137
C2    12        e     d  [      (
B3    12        e     d  =
D4    12        e     d  =
F4    12        e     d  ]      )
measure 138
C2    12        e     u  [
C3    12        e     u  =
C2    12        e     u  =      pp
C3    12        e     u  ]
measure 139
C2    12        e     u
rest  12        e
C2    12        e     u
rest  12        e
measure 140
C2    12        e     u
rest  12        e
rest  24        q
*               B       Fine
P    C17:f33
mheavy2
/END
/eof
//
