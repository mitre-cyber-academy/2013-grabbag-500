&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/1} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:39802f07f029fc36cc0ecb3d7ec4ba77]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
0 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
rest   2        e
G4     2        e     u
G5     3        e.    d  [
F5     1        s     d  =\
Ef5    3        e.    d  =      t
D5     1        s     d  ]\
measure 2
D5     4        q     d
C5     3        e.    d  [      t
Bf4    1        s     d  ]\
Bf4    3        e.    u  [
A4     1        s     u  =\
G4     3        e.    u  =      t
F#4    1        s     u  ]\
measure 3
F#4    4        q     u
G4     8        h     u
F#4    3        e.    u  [      t
G4     1        s     u  ]\
measure 4
G4     4        q     u
Bf4    8        h     u
rest   2        e
G4     2        e     u
measure 5
G5     3        e.    d  [
F5     1        s     d  =\
Ef5    3        e.    d  =      t
D5     1        s     d  ]\
D5     4        q     d
C5     4        q     d
measure 6
A5     4        q     d
rest   2        e
D5     2        e     d
D6     3        e.    d  [
C6     1        s     d  =\
Bf5    3        e.    d  =      t
A5     1        s     d  ]\
measure 7
A5     4        q     d
rest   2        e
D5     2        e     d
C5     4        q     d
Bf4    3        e.    u  [
A4     1        s     u  ]\
measure 8
Bf4    3        e.    u  [
A4     1        s     u  =\
G4     3        e.    u  =
F#4    1        s     u  ]\
G4     6        q.    u
A4     2        e     u
measure 9
Bf4    3        e.    d  [
C5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
F5     8-       h     d        -
measure 10
F5     6        q.    d
F5     2        e     d
F5     3        e.    d  [
Ef5    1        s     d  =\     +
D5     3        e.    d  =      &t
C5     1        s     d  ]\
measure 11
C5     4        q     d
Bf4    3        e.    u  [      &t
A4     1        s     u  ]\
A4     4        q     u
B4     4        q     u
measure 12
C5     3        e.    d  [
Bf4    1        s     d  ]\     +
A4     4        q     u         &t
G4     4        q     u
rest   2        e
C5     2        e     d
measure 13
F4     3        e.    u  [
G4     1        s     u  =\
A4     3        e.    u  =
Bf4    1        s     u  ]\
C5     4        q     d
rest   2        e
C5     2        e     d
measure 14
Bf4    3        e.    d  [
C5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
F5     4        q     d
F5     4-       q     d        -
measure 15
F5     4        q     d
E5     4        q     d
F5     4        q     d
rest   2        e
D5     2        e     d
measure 16
Bf4    3        e.    d  [
D5     1        s     d  =\
C5     3        e.    d  =      &t
D5     1        s     d  ]\
D5     4        q     d
rest   2        e
D5     2        e     d
measure 17
G5     3        e.    d  [
F5     1        s     d  =\
Ef5    3        e.    d  =      &t
D5     1        s     d  ]\
D5     4        q     d
Bf4    4        q     u
measure 18
Bf4    4        q     u
Bf4    4        q     u
Bf4    8-       h     u        -
measure 19
Bf4   16-       w     u        -
measure 20
Bf4   16-       w     u        -
measure 21
Bf4    8        h     u
rest   4        q
D5     4        q     d
measure 22
Bf4    4        q     u
A4     3        e.    u  [
G4     1        s     u  ]\
D5     8-       h     d        -
measure 23
D5    16-       w     d        -
measure 24
D5    16-       w     d        -
measure 25
D5    16-       w     d        -
measure 26
D5     6        q.    d
C5     2        e     d
Bf4    4        q     u
A4     2        e     u  [
Bf4    2        e     u  ]
measure 27
A4     2        e     u  [
D4     2        e     u  ]
D5     8        h     d
C5     4-       q     d        -
measure 28
C5     4        q     d
Bf4    4        q     u
A4     6        q.    u         &t
G4     2        e     u
measure 29
G4     4        q     u
rest   2        e
G4     2        e     u
G5     3        e.    d  [
F5     1        s     d  =\
Ef5    3        e.    d  =      &t
D5     1        s     d  ]\
measure 30
D5     4        q     d
C5     3        e.    d  [      &t
Bf4    1        s     d  ]\
Bf4    3        e.    u  [
A4     1        s     u  =\
G4     3        e.    u  =      &t
F#4    1        s     u  ]\
measure 31
F#4    4        q     u
G4     8        h     u         &(
F#4    3        e.    u  [      &)t
G4     1        s     u  ]\
measure 32
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/2} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:1604644340492c090a3550ebfcd660b0]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
0 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Largo
Bf4    4        q     u
rest   4        q
rest   4        q
rest   2        e
G3     2        e     u
measure 2
G4     3        e.    u  [
F4     1        s     u  =\
Ef4    3        e.    u  =      t
D4     1        s     u  ]\
D4     4        q     u
C5     4-       q     d        -
measure 3
C5     2        e     d  [
D5     2        e     d  =
Bf4    3        e.    d  =      t
A4     1        s     d  ]\
Bf4    4        q     u
A4     3        e.    u  [      t
G4     1        s     u  ]\
measure 4
G4     4        q     u
D5     8        h     d
C5     4        q     d
measure 5
Bf4    4        q     u
rest   4        q
rest   4        q
rest   2        e
G4     2        e     u
measure 6
D5     3        e.    d  [
C5     1        s     d  =\
Bf4    3        e.    d  =      &t
A4     1        s     d  ]\
A4     3        e.    d  [
A5     1        s     d  =\
G5     3        e.    d  =      t
F#5    1        s     d  ]\
measure 7
F#5    4        q     d
G4     8        h     u
F#4    3        e.    u  [
F#4    1        s     u  ]\
measure 8
G4     4        q     u
rest   4        q
rest   2        e
D4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  ]
measure 9
G4     3        e.    u  [
A4     1        s     u  =\
Bf4    3        e.    u  =
Bf4    1        s     u  ]\
A4     4        q     u
rest   2        e
F5     2        e     d
measure 10
F5     3        e.    d  [
Ef5    1        s     d  =\
D5     3        e.    d  =      &t
C5     1        s     d  ]\
C5     4        q     d
rest   2        e
F4     2        e     u
measure 11
F4     3        e.    u  [
Ef4    1        s     u  =\
D4     3        e.    u  =      &t
C4     1        s     u  ]\
C4     4        q     u
F4     3        e.    u  [
E4     1        s     u  ]\
measure 12
E4     4        q     u
C4     4-       q     u        -
C4     3        e.    u  [
Bf3    1        s     u  =\
A3     3        e.    u  =
G3     1        s     u  ]\
measure 13
F4     4-       q     u        -
F4     3        e.    u  [
G4     1        s     u  ]\
A4     3        e.    u  [
G4     1        s     u  =\
F4     3        e.    u  =
E4     1        s     u  ]\
measure 14
D4     4        q     u
rest   2        e
Bf4    2        e     u
C5     3        e.    u  [
Bf4    1        s     u  =\
A4     3        e.    u  =
G4     1        s     u  ]\
measure 15
A4     4        q     u
G4     4        q     u
A4     4        q     u
rest   2        e
A4     2        e     u
measure 16
G4     3        e.    u  [
A4     1        s     u  =\
G4     3        e.    u  =      &t
F#4    1        s     u  ]\
F#4    4        q     u
rest   2        e
G4     2        e     u
measure 17
G4     4        q     u
C5     3        e.    d  [      &t
Bf4    1        s     d  ]\
Bf4    4        q     u
rest   4        q
measure 18
rest   4        q
rest   2        e
Bf3    2        e     u
Ef4    3        e.    u  [
G4     1        s     u  =\
F4     3        e.    u  =
Af4    1        s     u  ]\
measure 19
G4     3        e.    u  [
Ef4    1        s     u  =\
D4     3        e.    u  =
F4     1        s     u  ]\
Ef4    3        e.    u  [
G4     1        s     u  =\
F4     3        e.    u  =
Af4    1        s     u  ]\
measure 20
G4     3        e.    u  [
Ef4    1        s     u  =\
D4     3        e.    u  =
F4     1        s     u  ]\
Ef4    3        e.    u  [
G4     1        s     u  =\
F4     2        e     u  =
F4     2        e     u  ]
measure 21
G4     4        q     u
F4     3        e.    u  [
Ef4    1        s     u  ]\
D4     4        q     u
rest   4        q
measure 22
rest   8        h
rest   4        q
rest   2        e
D4     2        e     u
measure 23
G4     3        e.    u  [
Bf4    1        s     u  =\
A4     3        e.    u  =
C5     1        s     u  ]\
Bf4    3        e.    u  [
G4     1        s     u  =\
F#4    3        e.    u  =
A4     1        s     u  ]\
measure 24
G4     3        e.    u  [
Bf4    1        s     u  =\
A4     3        e.    u  =
C5     1        s     u  ]\
Bf4    3        e.    u  [
G4     1        s     u  =\
F#4    3        e.    u  =
A4     1        s     u  ]\
measure 25
G4     3        e.    u  [
Bf4    1        s     u  =\
A4     2        e     u  =
F#4    2        e     u  ]
G4     4        q     u
A4     2        e     u  [
Bf4    2        e     u  ]
measure 26
A4     6        q.    u
A4     2        e     u
G4     4        q     u
F#4    2        e     u  [
G4     2        e     u  ]
measure 27
F#4    4        q     u
rest   2        e
D4     2        e     u
E4     6        q.    u
E4     2        e     u
measure 28
F#4    4        q     u
D4     2        e     u  [
G4     2        e     u  ]
G4     4        q     u
F#4    3        e.    u  [
C4     1        s     u  ]\
measure 29
Bf3   12        h.    u
rest   2        e
G3     2        e     u
measure 30
G4     3        e.    u  [
F4     1        s     u  =\
Ef4    3        e.    u  =      &t
D4     1        s     u  ]\
D4     4        q     u
C5     4-       q     d        -
measure 31
C5     3        e.    d  [
D5     1        s     d  =\
Bf4    3        e.    d  =      &t
A4     1        s     d  ]\
Bf4    4        q     u
A4     3        e.    u  [      &t
G4     1        s     u  ]\
measure 32
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/3} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:1cc7dced0fd64c7ee19d8c4c64394741]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
0 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:13   D:Largo
D4     4        q     d
rest   4        q
rest   8        h
measure 2
rest   8        h
rest   4        q
rest   2        e
G3     2        e     u
measure 3
D4     4        q     d
D4     3        e.    d  [
Ef4    1        s     d  ]\
D4     4        q     d
C4     3        e.    u  [
Bf3    1        s     u  ]\
measure 4
Bf3    4        q     u
rest   2        e
G3     2        e     u
G4     3        e.    d  [
F4     1        s     d  =\
Ef4    3        e.    d  =      t
D4     1        s     d  ]\
measure 5
D4     4        q     d
C4     3        e.    u  [      &t
Bf3    1        s     u  ]\
Bf3    3        e.    d  [
D4     1        s     d  =\
G4     3        e.    d  =      &t
F#4    1        s     d  ]\
measure 6
F#4    3        e.    d  [
A4     1        s     d  =\
G4     3        e.    d  =      &t
F#4    1        s     d  ]\
F#4    3        e.    d  [
F#4    1        s     d  =\
D4     3        e.    d  =
D4     1        s     d  ]\
measure 7
D4     4        q     d
rest   4        q
rest   4        q
rest   2        e
D4     2        e     d
measure 8
D4     3        e.    u  [
C4     1        s     u  =\
Bf3    3        e.    u  =
C4     1        s     u  ]\
D4     6        q.    d
C4     2        e     u
measure 9
D4     3        e.    u  [
C4     1        s     u  =\
Bf3    3        e.    u  =
Bf3    1        s     u  ]\
C4     4        q     u
rest   2        e
D5     2        e     d
measure 10
D5     3        e.    d  [
C5     1        s     d  =\
Bf4    3        e.    d  =      &t
A4     1        s     d  ]\
A4     3        e.    d  [
F4     1        s     d  =\
Bf4    3        e.    d  =
A4     1        s     d  ]\
measure 11
A4     4        q     d
rest   2        e
F4     2        e     d
A4     3        e.    d  [
G4     1        s     d  =\
F4     3        e.    d  =
G4     1        s     d  ]\
measure 12
G4     3        e.    d  [
G4     1        s     d  =\
F4     3        e.    d  =
E4     1        s     d  ]\
E4     4        q     d
rest   2        e
E4     2        e     d
measure 13
A3     4        q     u
F4     4-       q     d        -
F4     3        e.    d  [
E4     1        s     d  =\
D4     3        e.    d  =
C4     1        s     d  ]\
measure 14
F4     6        q.    d
Bf4    2        e     d
A4     3        e.    d  [
G4     1        s     d  =\
F4     2        e     d  =
D4     2        e     d  ]
measure 15
C4     4        q     u
C4     4        q     u
C4     4        q     u
rest   2        e
D4     2        e     d
measure 16
D4     3        e.    d  [
D4     1        s     d  =\
Ef4    3        e.    d  =
A3     1        s     d  ]\
A3     4        q     u
rest   2        e
Bf3    2        e     u
measure 17
C4     4        q     u
G4     4        q     d
G4     4        q     d
rest   4        q
measure 18
rest   8        h
rest   4        q
rest   2        e
D4     2        e     d
measure 19
Bf3    3        e.    u  [
Bf3    1        s     u  =\
Af3    3        e.    u  =
D4     1        s     u  ]\
Ef4    6        q.    d
D4     2        e     d
measure 20
Ef4    3        e.    d  [
Bf3    1        s     d  =\
Af3    3        e.    d  =
D4     1        s     d  ]\
Ef4    4        q     d
D4     2        e     d  [
D4     2        e     d  ]
measure 21
Ef4    4        q     d
Bf3    3        e.    u  [
C4     1        s     u  ]\
F3     4        q     u
rest   4        q
measure 22
rest  16
measure 23
rest   4        q
rest   2        e
F#4    2        e     d
D4     4        q     d
C4     3        e.    d  [
Ef4    1        s     d  ]\
measure 24
D4     3        e.    d  [
G4     1        s     d  =\
F#4    3        e.    d  =
A4     1        s     d  ]\
G4     3        e.    d  [
D4     1        s     d  =\
C4     3        e.    d  =
Ef4    1        s     d  ]\
measure 25
D4     3        e.    d  [
G4     1        s     d  =\
F#4    2        e     d  =
A4     2        e     d  ]
D4     4        q     d
D4     2        e     d  [
G4     2        e     d  ]
measure 26
F#4    6        q.    d
F#4    2        e     d
D4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
measure 27
D4     4        q     d
rest   2        e
G3     2        e     u
G3     6        q.    u
C4     2        e     u
measure 28
A3     4        q     u
Bf3    3        e.    u  [
C4     1        s     u  ]\
D4     4        q     d
D4     4        q     d
measure 29
D4    12        h.    d
C4     4        q     u
measure 30
Bf3    4        q     u
G4     8        h     d
G3     4        q     u
measure 31
A3     2        e     d  [
D4     2        e     d  ]
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 32
D4    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/4} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:d5508192c1d202a566ed770dfa0de9f4]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
0 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Largo
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest   8        h
rest   4        q
rest   2        e
G4     2        e     u                    Be-
measure 5
G5     3        e.    d                    hold
F5     1        s     d                    the
Ef5    3        e.    d                    Lamb
D5     1        s     d                    of
D5     4        q     d                    God!
rest   4        q
measure 6
rest   4        q
rest   2        e
D4     2        e     u                    be-
D5     3        e.    d                    hold
C5     1        s     d                    the
Bf4    3        e.    u                    Lamb
A4     1        s     u                    of
measure 7
A4     4        q     u                    God!
rest   2        e
D5     2        e     d                    that
C5     4        q     d                    tak-
Bf4    3        e.    u                    eth,
A4     1        s     u                    that
measure 8
Bf4    3        e.    u  [                 tak-
A4     1        s     u  ]\                -
G4     3        e.    u                    eth
F#4    1        s     u                    a-
G4     6        q.    u                    way
A4     2        e     u                    the
measure 9
Bf4    3        e.    d  [                 sin_
C5     1        s     d  ]\                _
D5     3        e.    d                    of
E5     1        s     d                    the
F5     8-       h     d        -           world,_
measure 10
F5     4        q     d                    _
rest   2        e
F5     2        e     d                    be-
F5     3        e.    d                    hold
Ef5    1        s     d         +          the
D5     3        e.    d                    Lamb
C5     1        s     d                    of
measure 11
C5     3        e.    d                    God,
C5     1        s     d                    the
Bf4    3        e.    u                    Lamb
A4     1        s     u                    of
A4     4        q     u                    God,
B4     4        q     u                    of
measure 12
C5     3        e.    d                    God,
Bf4    1        s     u         +          the
A4     3        e.    u                    Lamb
G4     1        s     u                    of
G4     4        q     u                    God!
rest   2        e
C5     2        e     d                    that
measure 13
F4     3        e.    u  [                 tak-
G4     1        s     u  ]\                -
A4     3        e.    u                    eth
Bf4    1        s     u                    a-
C5     4        q     d                    way
rest   2        e
C5     2        e     d                    the
measure 14
Bf4    3        e.    d  [                 sin_
C5     1        s     d  ]\                _
D5     3        e.    d                    of
E5     1        s     d                    the
F5     4        q     d                    world,
F5     4-       q     d        -           of_
measure 15
F5     4        q     d                    _
E5     4        q     d                    the
F5     4        q     d                    world,
rest   2        e
D5     2        e     d                    be-
measure 16
Bf4    3        e.    u                    hold
D5     1        s     d                    the
C5     3        e.    d                    Lamb
D5     1        s     d                    of
D5     4        q     d                    God!
rest   2        e
D5     2        e     d                    be-
measure 17
G5     3        e.    d                    hold
F5     1        s     d                    the
Ef5    3        e.    d                    Lamb
D5     1        s     d                    of
D5     4        q     d                    God!
Bf4    4        q     u                    that
measure 18
Bf4    4        q     u                    tak-
Bf4    2        e     u                    eth
Bf4    2        e     u                    a-
Bf4    6        q.    u                    way
Bf4    2        e     u                    the
measure 19
Bf4    4        q     u                    sin
Bf4    3        e.    u                    of
Bf4    1        s     u                    the
Bf4    8-       h     u        -           world,_
measure 20
Bf4   16-       w     u        -           _
measure 21
Bf4    8        h     u                    _
rest   4        q
D5     4        q     d                    that
measure 22
Bf4    4        q     u                    tak-
A4     3        e.    u                    eth
G4     1        s     u                    a-
D5     8-       h     d        -           way_
measure 23
D5     6        q.    d                    _
D5     2        e     d                    the
D5     8        h     d                    sin
measure 24
D5     4        q     d                    of
D5     4        q     d                    the
D5     8-       h     d        -           world,_
measure 25
D5    16-       w     d        -           _
measure 26
D5     6        q.    d                    _
C5     2        e     d                    the
Bf4    4        q     u                    sin
A4     2        e     u                    of
Bf4    2        e     u                    the
measure 27
A4     2        e     u                    world,
D4     2        e     u                    that
D5     8        h     d                    tak-
C5     2        e     d                    eth
C5     2        e     d                    a-
measure 28
C5     4        q     d                    way
Bf4    4        q     u                    the
A4     4        q     u                    sin
A4     3        e.    u                    of
G4     1        s     u                    the
measure 29
G4     8        h     u                    world.
rest   8        h
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/5} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:6f4ca4820cb067ca9d4eb3216df27668]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
0 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Largo
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest   4        q
rest   2        e
G3     2        e     u                    Be-
G4     3        e.    u                    hold
F4     1        s     u                    the
Ef4    3        e.    u                    Lamb
D4     1        s     u                    of
measure 5
D4     4        q     u                    God!
C4     3        e.    u  [                 be-
Bf3    1        s     u  ]\                -
Bf3    3        e.    u                    hold
D4     1        s     u                    the
G4     3        e.    u                    Lamb
F#4    1        s     u                    of
measure 6
F#4    3        e.    u                    God,
A4     1        s     u                    the
G4     3        e.    u                    Lamb
F#4    1        s     u                    of
F#4    4        q     u                    God!
rest   4        q
measure 7
rest   4        q
G4     4        q     u                    that
G4     4        q     u                    tak-
F#4    3        e.    u                    eth
F#4    1        s     u                    a-
measure 8
G4     4        q     u                    way
rest   4        q
rest   4        q
rest   2        e
D4     2        e     u                    the
measure 9
G4     3        e.    u  [                 sin_
A4     1        s     u  ]\                _
Bf4    3        e.    u                    of
Bf4    1        s     u                    the
A4     4        q     u                    world,
rest   2        e
F4     2        e     u                    be-
measure 10
F4     3        e.    u                    hold
Ef4    1        s     u                    the
D4     3        e.    u                    Lamb
C4     1        s     u                    of
C4     3        e.    u                    God,
F4     1        s     u                    the
Bf4    3        e.    u                    Lamb
A4     1        s     u                    of
measure 11
A4     4        q     u                    God!
rest   2        e
F4     2        e     u                    be-
A4     3        e.    u                    hold
G4     1        s     u                    the
F4     3        e.    u                    Lamb
E4     1        s     u                    of
measure 12
E4     3        e.    u                    God,
G4     1        s     u                    the
F4     3        e.    u                    Lamb
E4     1        s     u                    of
E4     4        q     u                    God!
rest   2        e
E4     2        e     u                    that
measure 13
D4     3        e.    u  [                 tak-
E4     1        s     u  ]\                -
F4     3        e.    u                    eth
G4     1        s     u                    a-
A4     4        q     u                    way
rest   2        e
F4     2        e     u                    the
measure 14
F4     4        q     u                    sin
F4     3        e.    u                    of
G4     1        s     u                    the
F4     4        q     u                    world,
rest   2        e
G4     2        e     u                    the
measure 15
A4     4        q     u                    sin
G4     2        e     u                    of
G4     2        e     u                    the
A4     4        q     u                    world,
rest   2        e
A4     2        e     u                    be-
measure 16
G4     3        e.    u                    hold
A4     1        s     u                    the
G4     3        e.    u                    Lamb
F#4    1        s     u                    of
F#4    4        q     u                    God,
rest   2        e
G4     2        e     u                    the
measure 17
G4     4        q     u                    Lamb
G4     4        q     u                    of
G4     4        q     u                    God!
rest   4        q
measure 18
rest   4        q
rest   2        e
Bf3    2        e     u                    that
Ef4    3        e.    u  [                 tak-
G4     1        s     u  ]\                -
F4     3        e.    u                    eth
Af4    1        s     u                    a-
measure 19
G4     3        e.    u  [                 way_
Ef4    1        s     u  =\                _
D4     3        e.    u  ]                 _
F4     1        s     u                    the
Ef4    3        e.    u  [                 sin,_
G4     1        s     u  =\                _
F4     3        e.    u  ]                 _
Af4    1        s     u                    the
measure 20
G4     3        e.    u  [                 sin_
Ef4    1        s     u  ]\                _
D4     3        e.    u                    of
F4     1        s     u                    the
Ef4    3        e.    u  [                 world,_
G4     1        s     u  =\                _
F4     2        e     u  ]                 _
F4     2        e     u                    the
measure 21
G4     4        q     u                    sin
F4     3        e.    u                    of
Ef4    1        s     u                    the
F4     4        q     u                    world,
rest   4        q
measure 22
rest   8        h
rest   4        q
rest   2        e
D4     2        e     u                    that
measure 23
G4     3        e.    u  [                 tak-
Bf4    1        s     u  ]\                -
A4     3        e.    u                    eth
C5     1        s     d                    a-
Bf4    3        e.    u  [                 way_
G4     1        s     u  =\                _
F#4    3        e.    u  ]                 _
A4     1        s     u                    the
measure 24
G4     3        e.    u  [                 sin,_
Bf4    1        s     u  ]\                _
A4     3        e.    d  [                 the_
C5     1        s     d  ]\                _
Bf4    3        e.    u  [                 sin_
G4     1        s     u  ]\                _
F#4    3        e.    u                    of
A4     1        s     u                    the
measure 25
G4     3        e.    u  [                 world,_
Bf4    1        s     u  =\                _
A4     2        e     u  ]                 _
A4     2        e     u                    the
G4     4        q     u                    sin
A4     2        e     u                    of
Bf4    2        e     u                    the
measure 26
A4     6        q.    u                    world,
A4     2        e     u                    the
G4     4        q     u                    sin
F#4    2        e     u                    of
G4     2        e     u                    the
measure 27
F#4    4        q     u                    world,
rest   2        e
D4     2        e     u                    that
E4     4        q     u                    tak-
E4     2        e     u                    eth
E4     2        e     u                    a-
measure 28
F#4    4        q     u                    way
D4     2        e     u  [                 the_
G4     2        e     u  ]                 _
G4     4        q     u                    sin
F#4    3        e.    u                    of
G4     1        s     u                    the
measure 29
G4     8        h     u                    world.
rest   8        h
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/6} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:0d51572c0d3ad5d361e691c895b99f7a]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
0 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:34   D:Largo
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
rest   2        e
G3     2        e     u                    Be-
measure 6
D4     3        e.    d                    hold
C4     1        s     d                    the
Bf3    3        e.    u                    Lamb
A3     1        s     u                    of
A3     3        e.    u                    God,
A3     1        s     u                    the
G3     2        e     u                    Lamb
G4     2        e     d                    of
measure 7
F#4    4        q     d                    God!
rest   4        q
rest   4        q
rest   2        e
D4     2        e     d                    that
measure 8
D4     3        e.    d  [                 tak-
C4     1        s     d  ]\                -
Bf3    3        e.    d                    eth
C4     1        s     d                    a-
D4     6        q.    d                    way
C4     2        e     d                    the
measure 9
D4     3        e.    d  [                 sin_
C4     1        s     d  ]\                _
Bf3    2        e     d                    of
Bf3    2        e     d                    the
C4     4        q     d                    world,
rest   2        e
D4     2        e     d                    be-
measure 10
D4     3        e.    d                    hold
C4     1        s     d                    the
Bf3    3        e.    u                    Lamb
A3     1        s     u                    of
A3     4        q     u                    God!
rest   2        e
F4     2        e     d                    be-
measure 11
F4     3        e.    d                    hold
Ef4    1        s     d                    the
D4     3        e.    d                    Lamb
C4     1        s     d                    of
C4     4        q     d                    God!
D4     4        q     d                    be-
measure 12
G3     3        e.    u                    hold
E3     1        s     u                    the
C4     3        e.    d                    Lamb
C4     1        s     d                    of
C4     4        q     d                    God!
rest   2        e
C4     2        e     d                    that
measure 13
A3     4        q     u                    tak-
A3     3        e.    u                    eth
G3     1        s     u                    a-
F3     4        q     u                    way
rest   2        e
C4     2        e     d                    the
measure 14
D4     4        q     d                    sin
C4     3        e.    d                    of
Bf3    1        s     d                    the
C4     4        q     d                    world,
rest   2        e
D4     2        e     d                    the
measure 15
C4     4        q     d                    sin
C4     2        e     d                    of
C4     2        e     d                    the
C4     4        q     d                    world,
rest   2        e
D4     2        e     d                    be-
measure 16
D4     3        e.    d                    hold
D4     1        s     d                    the
Ef4    3        e.    d                    Lamb
A3     1        s     u                    of
A3     4        q     u                    God,
rest   2        e
Bf3    2        e     d                    the
measure 17
C4     4        q     d                    Lamb
C4     4        q     d                    of
Bf3    4        q     d                    God!
rest   4        q
measure 18
rest   8        h
rest   4        q
rest   2        e
F3     2        e     u                    that
measure 19
G3     3        e.    u  [                 tak-
Bf3    1        s     u  ]\                -
Af3    3        e.    u                    eth
D4     1        s     d                    a-
Ef4    6        q.    d                    way
D4     2        e     d                    the
measure 20
Ef4    3        e.    d  [                 sin_
Bf3    1        s     d  ]\                _
Af3    3        e.    u                    of
D4     1        s     d                    the
Ef4    4        q     d         (          world,_
D4     2        e     d         )          _
D4     2        e     d                    the
measure 21
Ef4    4        q     d                    sin
Bf3    3        e.    d                    of
C4     1        s     d                    the
D4     4        q     d                    world,
rest   4        q
measure 22
rest  16
measure 23
rest   4        q
rest   2        e
F#3    2        e     u                    that
D4     4        q     d                    tak-
C4     3        e.    d                    eth
Ef4    1        s     d                    a-
measure 24
D4     3        e.    d  [                 way_
G4     1        s     d  =\                _
F#4    2        e     d  ]                 _
F#4    2        e     d                    the
G4     3        e.    d  [                 sin_
D4     1        s     d  ]\                _
C4     3        e.    d                    of
Ef4    1        s     d                    the
measure 25
D4     3        e.    d  [                 world,_
G4     1        s     d  =\                _
F#4    2        e     d  ]                 _
F#4    2        e     d                    the
D4     4        q     d                    sin
D4     2        e     d                    of
G4     2        e     d                    the
measure 26
F#4    6        q.    d                    world,
F#4    2        e     d                    the
D4     4        q     d                    sin
D4     2        e     d                    of
D4     2        e     d                    the
measure 27
A3     4        q     u                    world,
rest   2        e
Bf3    2        e     u                    that
G3     4        q     u                    tak-
G3     2        e     u                    eth
C4     2        e     d                    a-
measure 28
A3     4        q     u                    way
Bf3    2        e     d  [                 the_
C4     2        e     d  ]                 _
D4     4        q     d                    sin
D4     3        e.    d                    of
D4     1        s     d                    the
measure 29
D4     8        h     d                    world.
rest   8        h
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/7} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:ec01273dbe549696aef78a13513e4081]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
0 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Largo
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   4        q
rest   2        e
G2     2        e     u                    Be-
G3     3        e.    d                    hold
F3     1        s     d                    the
Ef3    3        e.    d                    Lamb
D3     1        s     u                    of
measure 6
D3     8-       h     u        -           God!_
D3     4        q     u                    _
rest   2        e
D3     2        e     u                    be-
measure 7
D4     3        e.    d                    hold
C4     1        s     d                    the
Bf3    3        e.    d                    Lamb
A3     1        s     d                    of
A3     4        q     d                    God!
rest   2        e
D3     2        e     u                    that
measure 8
G3     4        q     d                    tak-
G3     3        e.    d                    eth
A3     1        s     d                    a-
Bf3    6        q.    d                    way
A3     2        e     d                    the
measure 9
G3     4        q     d                    sin
G3     2        e     d                    of
G3     2        e     d                    the
F3     8-       h     d        -           world,_
measure 10
F3    16-       w     d        -           _
measure 11
F3     4        q     d                    _
rest   2        e
F3     2        e     d                    be-
F3     3        e.    d                    hold
E3     1        s     d                    the
D3     3        e.    u                    Lamb
C3     1        s     u                    of
measure 12
C3     8-       h     u        -           God!_
C3     4        q     u                    _
rest   2        e
C3     2        e     u                    that
measure 13
D3     4        q     u                    tak-
C3     3        e.    u                    eth
Bf2    1        s     u                    a-
A2     4        q     u                    way
rest   2        e
A3     2        e     d                    the
measure 14
Bf3    4        q     d                    sin
A3     3        e.    d                    of
G3     1        s     d                    the
A3     4        q     d                    world,
rest   2        e
Bf3    2        e     d                    the
measure 15
C4     4        q     d                    sin
C3     2        e     u                    of
C3     2        e     u                    the
F3     4        q     d                    world,
rest   2        e
F#3    2        e     d                    be-
measure 16
G3     3        e.    d                    hold
F3     1        s     d         +          the
Ef3    3        e.    d                    Lamb
D3     1        s     u                    of
D3     4        q     u                    God,
rest   2        e
G3     2        e     d                    the
measure 17
Ef3    4        q     d                    Lamb
C3     4        q     u                    of
G3     4        q     d                    God!
rest   4        q
measure 18
rest   8        h
rest   4        q
rest   2        e
Bf2    2        e     u                    that
measure 19
Ef3    3        e.    d  [                 tak-
G3     1        s     d  ]\                -
F3     3        e.    d                    eth
Af3    1        s     d                    a-
G3     2        e     d         (          way_
Bf3    4        q     d         )          _
Bf2    2        e     u                    the
measure 20
Ef3    3        e.    d  [                 sin_
G3     1        s     d  ]\                _
F3     3        e.    d                    of
Af3    1        s     d                    the
G3     2        e     d         (          world,_
Bf3    4        q     d         )          _
Af3    2        e     d                    the
measure 21
G3     4        q     d                    sin
D3     3        e.    u                    of
Ef3    1        s     d                    the
Bf2    4        q     u                    world,
rest   4        q
measure 22
rest  16
measure 23
rest   4        q
rest   2        e
D3     2        e     u                    that
G3     3        e.    d  [                 tak-
Bf3    1        s     d  ]\                -
A3     3        e.    d                    eth
C4     1        s     d                    a-
measure 24
Bf3    2        e     d         (          way_
D4     4        q     d         )          _
D3     2        e     u                    the
G3     3        e.    d  [                 sin_
Bf3    1        s     d  ]\                _
A3     3        e.    d                    of
C4     1        s     d                    the
measure 25
Bf3    2        e     d         (          world,_
D4     4        q     d         )          _
C4     2        e     d                    the
Bf3    4        q     d                    sin
F#3    2        e     d                    of
G3     2        e     d                    the
measure 26
D3    16-       w     u        -           world,_
measure 27
D3     4        q     u                    _
rest   2        e
Bf2    2        e     u                    that
C3     4        q     u                    tak-
C3     2        e     u                    eth
C3     2        e     u                    a-
measure 28
D3     4        q     u                    way
G3     4        q     d                    the
D3     4        q     u                    sin
D3     3        e.    u                    of
D3     1        s     u                    the
measure 29
G2     8        h     u                    world.
rest   8        h
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-01/8} [KHM:727587427]
TIMESTAMP: DEC/26/2001 [md5sum:d8b57ccc46c1f0209ebe224f9cc4e1c2]
04/11/90 E. Correia
WK#:56        MV#:2,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
0 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Largo
G3     4        q     d
G2     4        q     u
rest   8        h
measure 2
rest   4        q
rest   2        e
G2     2        e     u
G3     3        e.    d  [
F3     1        s     d  =\
Ef3    3        e.    d  =
D3     1        s     d  ]\
measure 3
D3     4        q     u
G3     3        e.    d  [
C3     1        s     d  ]\
D3     4        q     u
D2     4        q     u
measure 4
G2    16-       w     u        -
measure 5
G2     6        q.    u
G2     2        e     u
G3     3        e.    d  [
F3     1        s     d  =\
f1              6
Ef3    3        e.    d  =
D3     1        s     d  ]\
measure 6
D3     8-       h     u        -
D3     6        q.    u
D3     2        e     u
measure 7
f1              #
D4     3        e.    d  [
C4     1        s     d  =\
f1              6
Bf3    3        e.    d  =
A3     1        s     d  ]\
f1     4        7
f1              6+
A3     6        q.    d
D3     2        e     u
measure 8
G3     4        q     d
G3     3        e.    d  [
A3     1        s     d  ]\
Bf3    6        q.    d
A3     2        e     d
measure 9
G3     6        q.    d
G3     2        e     d
F3     8-       h     d        -
measure 10
F3    16-       w     d        -
measure 11
F3     6        q.    d
F3     2        e     d
F3     3        e.    d  [
E3     1        s     d  =\
D3     3        e.    d  =
C3     1        s     d  ]\
measure 12
C3     8-       h     u        -
C3     6        q.    u
C3     2        e     u
measure 13
D3     4        q     u
C3     3        e.    u  [
Bf2    1        s     u  ]\
A2     4        q     u
rest   2        e
A3     2        e     d
measure 14
Bf3    4        q     d
A3     3        e.    d  [
G3     1        s     d  ]\
f1              6
A3     4        q     d
rest   2        e
Bf3    2        e     d
measure 15
C4     4        q     d
C3     4        q     u
F3     4        q     d
rest   2        e
F#3    2        e     d
measure 16
G3     3        e.    d  [
F3     1        s     d  =\     +
Ef3    3        e.    d  =
D3     1        s     d  ]\
D3     4        q     u
rest   2        e
G3     2        e     d
measure 17
Ef3    4        q     d
C3     4        q     u
G3     4        q     d
$ C:15
Bf4    4        q     d
measure 18
Bf4    8        h     u
Ef4    3        e.    u  [
G4     1        s     u  =\
F4     2        e     u  =
$ C:22
Bf2    2        e     u  ]
measure 19
Ef3    3        e.    d  [
G3     1        s     d  =\
F3     3        e.    d  =
Af3    1        s     d  ]\
G3     2        e     d
Bf3    4        q     d
Bf2    2        e     u
measure 20
Ef3    3        e.    d  [
G3     1        s     d  =\
F3     3        e.    d  =
Af3    1        s     d  ]\
G3     2        e     d
Bf3    4        q     d
Af3    2        e     d
measure 21
G3     4        q     d
D3     3        e.    d  [
Ef3    1        s     d  ]\
Bf2    4        q     u
$ C:15
D5     4        q     d
measure 22
Bf4    4        q     d
A4     3        e.    d  [
G4     1        s     d  ]\
D5     8        h     u
measure 23
G4     3        e.    d  [
Bf4    1        s     d  =\
A4     2        e     d  =
$ C:22
f1              #
D3     2        e     d  ]
G3     3        e.    d  [
Bf3    1        s     d  =\
A3     3        e.    d  =
C4     1        s     d  ]\
measure 24
Bf3    2        e     d
D4     4        q     d
D3     2        e     u
G3     3        e.    d  [
Bf3    1        s     d  =\
A3     3        e.    d  =
C4     1        s     d  ]\
measure 25
Bf3    2        e     d
D4     4        q     d
C4     2        e     d
Bf3    4        q     d
F#3    2        e     d  [
G3     2        e     d  ]
measure 26
D3    16-       w     u        -
measure 27
D3     4        q     u
rest   2        e
Bf2    2        e     u
C3     4        q     u
C3     2        e     u  [
C3     2        e     u  ]
measure 28
D3     4        q     u
G2     4        q     u
D3     4        q     u
D2     4        q     u
measure 29
G2    16-       w     u        -
measure 30
G2     6        q.    u
G2     2        e     u
G3     3        e.    d  [
F3     1        s     d  =\
Ef3    3        e.    d  =
D3     1        s     d  ]\
measure 31
D3     4        q     u
G2     4        q     u
D3     4        q     u
D2     4        q     u
measure 32
G2    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
