&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/1} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:ae8bcaae2af98543692838313fa230cf]
04/11/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:4  D:Allegro moderato
rest  16
measure 2
rest   4        q
rest   2        e
C5     2        e     d
F5     4        q     d
D5     4        q     d
measure 3
C5     4        q     d
rest   2        e
C4     2        e     u
F4     4        q     u
D4     4        q     u
measure 4
C4     4        q     u
rest   2        e
C4     2        e     u
D4     2        e     u  [
C4     2        e     u  =
F4     2        e     u  =
E4     2        e     u  ]
measure 5
A4     2        e     u  [
G4     2        e     u  =
Bf4    2        e     u  =
A4     2        e     u  ]
D5     2        e     d  [
C5     2        e     d  =
E5     2        e     d  =
F5     2        e     d  ]
measure 6
G5     4        q     d
rest   4        q
rest   8        h
measure 7
rest   4        q
rest   2        e
G5     2        e     d
C6     4        q     d
A5     4        q     d
measure 8
G5     4        q     d
rest   2        e
C5     2        e     d
F5     4        q     d
D5     4        q     d
measure 9
C5     4        q     d
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
rest   4        q
G4     2        e     u  [
Bf4    2        e     u  ]
A4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
F4     1        s     u  ==
E4     1        s     u  ==
G4     1        s     u  ]]
measure 12
A4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
G4     1        s     u  ]]
measure 13
A4     2        e     u  [
F4     2        e     u  =
C5     2        e     u  =
C5     2        e     u  ]
C5     4        q     d
C5     4        q     d
measure 14
C5     4        q     d
C5     4        q     d
C5     8        h     d
measure 15
rest   4        q
C5     2        e     d  [
D5     2        e     d  ]
E5     2        e     d  [
C5     2        e     d  =
F5     2        e     d  =
G5     2        e     d  ]
measure 16
A5     2        e     d  [
E5     2        e     d  =
F5     2        e     d  =
G5     2        e     d  ]
A5     2        e     d  [
Bf5    1        s     d  =[
A5     1        s     d  ]]
G5     2        e     d  [
F5     2        e     d  ]
measure 17
E5     4        q     d
rest   4        q
rest   8        h
measure 18
rest   4        q
rest   2        e
G5     2        e     d
C6     4        q     d
A5     4        q     d
measure 19
G5     4        q     d
rest   4        q
rest   8        h
measure 20
rest  16
measure 21
rest   4        q
rest   2        e
G4     2        e     u
A4     2        e     u  [
G4     2        e     u  =
C5     2        e     u  =
B4     2        e     u  ]
measure 22
E5     2        e     d  [
D5     2        e     d  =
F5     2        e     d  =
E5     2        e     d  ]
A5     2        e     d  [
G5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
measure 23
D5     4        q     d
rest   4        q
rest   4        q
G5     2        e     d  [
G5     2        e     d  ]
measure 24
G5     4        q     d
G4     4        q     u
rest   8        h
measure 25
rest   4        q
D5     2        e     d  [
F5     2        e     d  ]
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
D5     1        s     d  ]]
measure 26
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
measure 27
E5     2        e     d  [
C5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
G5     4        q     d
G5     4        q     d
measure 28
G5     4        q     d
G5     4        q     d
G5     2        e     d  [
F5     2        e     d  =
E5     2        e     d  =
C6     2        e     d  ]
measure 29
B5     6        q.    d         &t
B5     2        e     d
C6     4        q     d
C5     2        e     d  [
C5     2        e     d  ]
measure 30
C5     4        q     d
C4     4        q     u
rest   8        h
measure 31
rest   8        h
rest   4        q
F5     2        e     d  [
E5     2        e     d  ]
measure 32
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  ]
G4     4        q     u
rest   4        q
measure 33
rest  16
measure 34
rest   8        h
rest   4        q
rest   2        e
G5     2        e     d
measure 35
C6     4        q     d
A5     4        q     d
G5     4        q     d
rest   4        q
measure 36
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u
measure 37
G4     2        e     u  [
F4     2        e     u  =
Bf4    2        e     u  =
A4     2        e     u  ]
D5     2        e     d  [
C5     2        e     d  ]
rest   4        q
measure 38
rest  16
measure 39
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u
measure 40
G4     2        e     u  [
F4     2        e     u  =
Bf4    2        e     u  =
A4     2        e     u  ]
D5     2        e     d  [
C5     2        e     d  =
Ef5    2        e     d  =
D5     2        e     d  ]
measure 41
G5     2        e     d  [
F5     2        e     d  =
A4     2        e     d  =
Bf4    2        e     d  ]
C5     4        q     d
rest   4        q
measure 42
rest   4        q
F5     2        e     d  [
F5     2        e     d  ]
F5     4        q     d
F4     4        q     u
measure 43
rest  16
measure 44
rest  16
measure 45
rest   8        h
rest   4        q
F5     2        e     d  [
F5     2        e     d  ]
measure 46
F5     4        q     d
F4     4        q     u
rest   4        q
D5     2        e     d  [
Ef5    2        e     d  ]
measure 47
F5     2        e     d  [
Bf4    2        e     d  =
F5     2        e     d  =
G5     2        e     d  ]
A5     4        q     d         i
Bf5    4        q     d         i
measure 48
Bf5    4        q     d         i
A5     4        q     d         i
Bf5    4        q     d         i
rest   4        q
measure 49
rest  16
measure 50
rest   4        q
A4     2        e     u  [
Bf4    2        e     u  ]
C5     2        e     d  [
A4     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 51
E5     2        e     d  [
C5     2        e     d  =
E5     2        e     d  =
F5     2        e     d  ]
G5     8-       h     d        -
measure 52
G5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
C5     2        e     d  ]
A4     2        e     u  [      (
F4     2        e     u  =      )
A4     2        e     u  =      (
F4     2        e     u  ]      )
measure 53
A4     2        e     u  [      (
F4     2        e     u  =      )
Bf4    2        e     u  =      (
F4     2        e     u  ]      )
A4     2        e     u  [      (
F4     2        e     u  ]      )
rest   2        e
C5     2        e     d
measure 54
F5     4        q     d
D5     4        q     d
C5     4        q     d
rest   2        e
C5     2        e     d
measure 55
C6     4        q     d
A5     4        q     d
G5     4        q     d
rest   4        q
measure 56
rest  16
measure 57
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d
measure 58
D5     2        e     d  [
C5     2        e     d  =
F5     2        e     d  =
E5     2        e     d  ]
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  ]
measure 59
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  ]
G5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
G5     1        s     d  ]]
measure 60
A5     2        e     d  [
C5     2        e     d  =
F5     2        e     d  =
F5     2        e     d  ]
F5     4        q     d
F4     4        q     u
measure 61
rest   4        q
G5     2        e     d  [
G5     2        e     d  ]
G5     4        q     d
G4     2        e     u  [
E4     2        e     u  ]
measure 62
A4     1        s     d  [[
Bf4    1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
E4     1        s     u  ]]
F4     1        s     u  [[
E4     1        s     u  ==
D4     1        s     u  ==
E4     1        s     u  ]]
F4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
F4     1        s     u  ]]
measure 63
Bf4    1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
measure 64
G5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==     +
D5     1        s     d  ]]
C5     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
C5     1        s     u  ==
D5     1        s     u  ==
E5     1        s     u  ]]
F5     1        s     d  [[
E5     1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
measure 65
E5     4        q     d
rest   4        q
rest   4        q
C5     2        e     d  [
Bf4    2        e     d  ]
measure 66
A4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
F4     1        s     u  ==
E4     1        s     u  ==
G4     1        s     u  ]]
F4     2        e     u  [
C4     2        e     u  ]
rest   4        q
measure 67
rest   4        q
F5     2        e     d  [
Ef5    2        e     d  ]
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
measure 68
Bf4    4        q     u
rest   4        q
rest   4        q
F5     2        e     d  [
C6     2        e     d  ]
measure 69
D6     1        s     d  [[
C6     1        s     d  ==
Bf5    1        s     d  ==
D6     1        s     d  ]]
C6     1        s     d  [[
Bf5    1        s     d  ==
A5     1        s     d  ==
C6     1        s     d  ]]
Bf5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
Bf5    1        s     d  ==
C6     1        s     d  ==
A5     1        s     d  ]]
measure 70
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
Bf5    1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
A5     1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
rest   4        q
measure 71
rest   4        q
F4     2        e     u  [
G4     2        e     u  ]
A4     2        e     u  [
F4     2        e     u  ]
rest   4        q
measure 72
rest   4        q
C5     2        e     d  [
D5     2        e     d  ]
E5     4        q     d         &i
F5     4        q     d         i
measure 73
F5     4        q     d         i
E5     4        q     d         i
F5     4        q     d         i
C6     2        e     d  [
C6     2        e     d  ]
measure 74
C6     2        e     d  [
C6     2        e     d  =
C6     2        e     d  =
C6     2        e     d  ]
B5     4        q     d
C6     4        q     d
measure 75
C6     8        h     d
B5     8        h     d
measure 76
C6     8        h     d
$ D:Adagio
rest   8        h
measure 77
rest   8        h
G4     6        q.    u
G4     2        e     u
measure 78
C5     8        h     d
Bf4    8        h     u
measure 79
Af4    8        h     u
A4     8        h     u
measure 80
Bf4    8        h     u
A4     6        q.    u         +
A4     2        e     u
measure 81
F5     8        h     d
Ef5    8        h     d
measure 82
Df5    8        h     d
C5     8        h     d
measure 83
Bf4    8        h     u
A4     8        h     u         +
measure 84
Bf4    8        h     u
C5     8        h     d
measure 85
Df5   16-       w     d        -
measure 86
Df5    8        h     d
Df5    8        h     d
measure 87
C5    16-       w     d        -
measure 88
C5     8        h     d
C5     4        q     d
C5     4        q     d
measure 89
C5     4        q     d
C5     4        q     d
Bf4    8        h     u
measure 90
Af4   16        w     u
measure 91
G4    12        h.    u
F4     4        q     u
measure 92
F4    16        b     u
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/2} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:36dd2b384d408c4e6de1e1d55bc82b5d]
04/11/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:4  D:Allegro moderato
rest  16
measure 2
rest   4        q
rest   2        e
A4     2        e     u
C5     4        q     d
Bf4    4        q     u
measure 3
A4     4        q     u
rest   2        e
A3     2        e     u
C4     4        q     u
Bf3    4        q     u
measure 4
A3     4        q     u
rest   2        e
A3     2        e     u
Bf3    2        e     u  [
A3     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
measure 5
F4     2        e     u  [
E4     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
Bf3    2        e     u  [
A3     2        e     u  =
G3     2        e     u  =
F4     2        e     u  ]
measure 6
C4     4        q     u
rest   4        q
rest   8        h
measure 7
rest   4        q
rest   2        e
E5     2        e     d
G5     4        q     d
F5     4        q     d
measure 8
E5     4        q     d
rest   2        e
G4     2        e     u
C5     4        q     d
Bf4    4        q     u
measure 9
A4     4        q     u
rest   2        e
C4     2        e     u
D4     2        e     u  [
C4     2        e     u  =
F4     2        e     u  =
E4     2        e     u  ]
measure 10
A4     2        e     u  [
G4     2        e     u  =
Bf4    2        e     u  =
A4     2        e     u  ]
D4     2        e     u  [
C4     2        e     u  =
E4     2        e     u  =
F4     2        e     u  ]
measure 11
G4     4        q     u
rest   4        q
rest   4        q
C5     2        e     d  [
C5     2        e     d  ]
measure 12
C5     4        q     d
C4     4        q     u
rest   8        h
measure 13
rest   4        q
G5     2        e     d  [
Bf5    2        e     d  ]
A5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
measure 14
A5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
G5     1        s     d  ]]
measure 15
A5     2        e     d  [
F5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
C5     4        q     d
C5     4        q     d
measure 16
C5     4        q     d
C5     4        q     d
C5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ]]
Bf4    2        e     u  [
A4     2        e     u  ]
measure 17
G4     4        q     u
rest   4        q
rest   8        h
measure 18
rest   4        q
rest   2        e
E5     2        e     d
G5     4        q     d
F5     4        q     d
measure 19
E5     4        q     d
rest   4        q
rest   8        h
measure 20
rest  16
measure 21
rest   4        q
rest   2        e
E4     2        e     u
F4     2        e     u  [
E4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 22
C4     2        e     u  [
B3     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
F4     2        e     u  [
E4     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
measure 23
B3     4        q     u
D4     2        e     u  [
F4     2        e     u  ]
E4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
E4     1        s     u  ]]
D4     1        s     u  [[
C4     1        s     u  ==
B3     1        s     u  ==
D4     1        s     u  ]]
measure 24
E4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
E4     1        s     u  ]]
D4     1        s     u  [[
E4     1        s     u  ==
F4     1        s     u  ==
D4     1        s     u  ]]
E4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
E4     1        s     u  ]]
D4     1        s     u  [[
E4     1        s     u  ==
F4     1        s     u  ==
D4     1        s     u  ]]
measure 25
E4     2        e     u  [
C4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
G4     4        q     u
G4     4        q     u
measure 26
G4     4        q     u
G4     4        q     u
G4     8        h     u
measure 27
rest   4        q
B4     2        e     d  [
C5     2        e     d  ]
D5     2        e     d  [
B4     2        e     d  =
E5     2        e     d  =
F5     2        e     d  ]
measure 28
G5     2        e     d  [
E5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
B5     2        e     d
G5     4        q     d
A5     2        e     d
measure 29
D5     6        q.    d
D5     2        e     d
E5     4        q     d
rest   4        q
measure 30
rest   8        h
rest   4        q
C6     2        e     d  [
C6     2        e     d  ]
measure 31
C6     4        q     d
C5     4        q     d
rest   4        q
F4     2        e     u  [
A4     2        e     u  ]
measure 32
Bf4    2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
F4     2        e     u  ]
E4     4        q     u
rest   4        q
measure 33
rest  16
measure 34
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d
measure 35
F5     4        q     d
F5     4        q     d
E5     4        q     d
rest   2        e
C4     2        e     u
measure 36
D4     2        e     u  [
C4     2        e     u  =
F4     2        e     u  =
E4     2        e     u  ]
A4     2        e     u  [
G4     2        e     u  ]
rest   4        q
measure 37
rest  16
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest   8        h
rest   4        q
C5     2        e     d  [
Ef5    2        e     d  ]
measure 42
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]
measure 43
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]
D5     2        e     d  [
Bf4    2        e     d  =
F5     2        e     d  =
F5     2        e     d  ]
measure 44
F5     4        q     d
F5     4        q     d
F5     4        q     d
F5     4        q     d
measure 45
F5     8-       h     d        -
F5     4        q     d
A4     2        e     u  [
Bf4    2        e     u  ]
measure 46
C5     2        e     u  [
A4     2        e     u  =
F4     2        e     u  =
A4     2        e     u  ]
Bf4    4        q     u
F4     4        q     u
measure 47
rest   4        q
Bf4    2        e     d  [
Ef5    2        e     d  ]
Ef5    4        q     d         i
D5     4        q     d         i
measure 48
C5     4        q     d         i
C5     4        q     d         i
D5     4        q     d         i
rest   4        q
measure 49
rest   4        q
D4     2        e     u  [
Ef4    2        e     u  ]
F4     2        e     u  [
D4     2        e     u  =
F4     2        e     u  =
G4     2        e     u  ]
measure 50
C4     4        q     u
rest   4        q
rest   8        h
measure 51
rest   8        h
rest   4        q
E4     2        e     u  [
F4     2        e     u  ]
measure 52
G4     2        e     u  [
E4     2        e     u  =
F4     2        e     u  =
G4     2        e     u  ]
C4     2        e     u  [
F4     2        e     u  =
A4     2        e     u  =      (
F4     2        e     u  ]      )
measure 53
A4     2        e     u  [      (
F4     2        e     u  =      )
Bf4    2        e     u  =      (
F4     2        e     u  ]      )
A4     2        e     u  [      (
F4     2        e     u  =      )
C5     2        e     u  =      (
A4     2        e     u  ]      )
measure 54
C5     2        e     u  [      (
A4     2        e     u  =      )
D5     2        e     u  =      (
F4     2        e     u  ]      )
F5     2        e     u  [      (
F4     2        e     u  =      )
A4     2        e     u  =      (
F4     2        e     u  ]      )
measure 55
A4     2        e     u  [      (
F4     2        e     u  =      )
F5     2        e     u  =
F4     2        e     u  ]
E5     4        q     d
rest   4        q
measure 56
rest  16
measure 57
rest  16
measure 58
rest   2        e
C4     2        e     u  [
D4     2        e     u  =
C4     2        e     u  ]
F4     2        e     u  [
E4     2        e     u  =
G4     2        e     u  =
F4     2        e     u  ]
measure 59
Bf4    2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
F4     2        e     u  ]
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
measure 60
C5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
measure 61
G5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
measure 62
C5     2        e     d  [
E5     2        e     d  =
A5     2        e     d  =
A5     2        e     d  ]
A5     4        q     d
A4     4        q     u
measure 63
rest   4        q
Bf5    2        e     d  [
Bf5    2        e     d  ]
Bf5    4        q     d
Bf4    4        q     u
measure 64
rest   4        q
C6     2        e     d  [
C6     2        e     d  ]
C6     4        q     d
C5     4        q     d
measure 65
rest   4        q
C5     2        e     d  [
C5     2        e     d  ]
C5     4        q     d
C4     4        q     u
measure 66
rest   8        h
rest   4        q
F5     2        e     d  [
Ef5    2        e     d  ]
measure 67
D5     1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    4        q     u
F4     2        e     u  [
Ef4    2        e     u  ]
measure 68
D4     1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
D4     1        s     u  ]]
C4     1        s     u  [[
Bf3    1        s     u  ==
A3     1        s     u  ==
C4     1        s     u  ]]
Bf3    2        e     u  [
D4     2        e     u  =
C5     2        e     u  =
C6     2        e     u  ]
measure 69
Bf5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
F5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
F5     1        s     d  ]]
measure 70
Bf5    1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     2        e     u  [
E5     2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
measure 71
E4     2        e     u  [
C4     2        e     u  ]
rest   4        q
rest   4        q
A4     2        e     u  [
Bf4    2        e     u  ]
measure 72
C5     2        e     u  [
A4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  ]
G4     4        q     u         i
A4     4        q     u         i
measure 73
G4     4        q     u         i
G4     4        q     u         i
A4     4        q     u         i
A5     2        e     d  [
A5     2        e     d  ]
measure 74
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
F5     4        q     d
E5     4        q     d
measure 75
D5     8        h     d
D5     8        h     d
measure 76
E5     8        h     d
$ D:Adagio
rest   8        h
measure 77
rest  16
measure 78
rest  16
measure 79
rest   8        h
C4     6        q.    u
C4     2        e     u
measure 80
F4     8        h     u
Ef4    8        h     u
measure 81
Df4    8        h     u
C4     8        h     u
measure 82
Bf3    8        h     u
A3     8        h     u         +
measure 83
F4    16        w     u
measure 84
rest  16
measure 85
rest   8        h
Af4    8        h     u
measure 86
G4     8        h     u
F4     8        h     u
measure 87
E4    16-       w     u        -+
measure 88
E4     8        h     u
E4     4        q     u
E4     4        q     u
measure 89
F4     4        q     u
F4     4        q     u
F4     8        h     u
measure 90
F4    16        w     u
measure 91
E4    16        w     u         +
measure 92
F4    16        b     u
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/3} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:994802f73be429d59b138c1eb9f5d8a2]
04/11/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:13  D:Allegro moderato
rest  16
measure 2
rest   4        q
rest   2        e
F4     2        e     d
F4     4        q     d
F4     4        q     d
measure 3
F4     4        q     d
rest   2        e
C4     2        e     u
A3     4        q     u
F3     4        q     u
measure 4
F3     4        q     u
rest   2        e
A3     2        e     u
Bf3    2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 5
F4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
Bf3    2        e     u  [
A3     2        e     u  =
G3     2        e     u  =
F3     2        e     u  ]
measure 6
E3     4        q     u
rest   4        q
rest   8        h
measure 7
rest   4        q
rest   2        e
C5     2        e     d
C5     4        q     d
C5     4        q     d
measure 8
C5     4        q     d
rest   2        e
E4     2        e     d
F4     4        q     d
F4     4        q     d
measure 9
F4     4        q     d
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest   4        q
rest   2        e
C5     2        e     d
C5     4        q     d
C5     4        q     d
measure 19
C5     4        q     d
rest   2        e
G3     2        e     u
A3     2        e     u  [
G3     2        e     u  =
C4     2        e     u  =
B3     2        e     u  ]
measure 20
E4     2        e     d  [
D4     2        e     d  =
F4     2        e     d  =
E4     2        e     d  ]
A3     2        e     u  [
G3     2        e     u  =
B3     2        e     u  =
C4     2        e     u  ]
measure 21
D4     4        q     d
rest   4        q
rest   8        h
measure 22
rest  16
measure 23
rest   4        q
G4     2        e     d  [
G4     2        e     d  ]
G4     4        q     d
G3     4        q     u
measure 24
rest   4        q
G4     2        e     d  [
G4     2        e     d  ]
G4     4        q     d
G3     4        q     u
measure 25
rest  16
measure 26
rest  16
measure 27
rest   4        q
G3     2        e     u  [
A3     2        e     u  ]
B3     2        e     u  [
G3     2        e     u  =
C4     2        e     u  =
B3     2        e     u  ]
measure 28
C4     2        e     u
C5     4        q     d
B4     1        s     d  [[
A4     1        s     d  ]]
D4     4        q     d
C4     2        e     d  [
C5     2        e     d  ]
measure 29
G4     6        q.    d
G4     2        e     d
G4     4        q     d
rest   4        q
measure 30
rest   4        q
C5     2        e     d  [
C5     2        e     d  ]
C5     4        q     d
C4     4        q     u
measure 31
rest   4        q
C4     2        e     u  [
C4     2        e     u  ]
C4     4        q     u
C3     4        q     u
measure 32
rest   8        h
rest   4        q
F4     2        e     d  [
E4     2        e     d  ]
measure 33
D4     2        e     u  [
C4     2        e     u  =
Bf3    2        e     u  =
A3     2        e     u  ]
G3     4        q     u
rest   4        q
measure 34
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d
measure 35
C5     4        q     d
C5     4        q     d
C5     4        q     d
rest   4        q
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
rest   2        e
F3     2        e     u
measure 38
G3     2        e     u  [
F3     2        e     u  =
Bf3    2        e     u  =
A3     2        e     u  ]
D4     2        e     d  [
C4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  ]
measure 39
G4     2        e     d  [
F4     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
C4     4        q     u
rest   4        q
measure 40
rest  16
measure 41
rest  16
measure 42
rest   8        h
rest   4        q
F4     2        e     d  [
F4     2        e     d  ]
measure 43
F4     4        q     d
C4     2        e     u  [
A3     2        e     u  ]
F3     4        q     u
C4     2        e     d  [
Ef4    2        e     d  ]
measure 44
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
D4     1        s     d  ]]
C4     1        s     u  [[
Bf3    1        s     u  ==
A3     1        s     u  ==
C4     1        s     u  ]]
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
D4     1        s     d  ]]
C4     1        s     d  [[
D4     1        s     d  ==
Ef4    1        s     d  ==
C4     1        s     d  ]]
measure 45
D4     1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
D4     1        s     d  ]]
C4     1        s     u  [[
Bf3    1        s     u  ==
A3     1        s     u  ==
C4     1        s     u  ]]
D4     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  =
Bf3    2        e     u  ]
measure 46
F4     2        e     d  [
C4     2        e     d  =
D4     2        e     d  =
Ef4    2        e     d  ]
F4     4        q     d
D4     4        q     d
measure 47
rest   4        q
D4     2        e     d  [
C4     2        e     d  ]
C4     4        q     u         &i
Bf3    4        q     u         &i
measure 48
G4     4        q     d         &i
F4     4        q     d         &i
F4     4        q     d         &i
Bf3    2        e     u  [
C4     2        e     u  ]
measure 49
D4     2        e     d  [
Bf3    2        e     d  =
F4     2        e     d  =
A3     2        e     d  ]
Bf3    2        e     u  [
F3     2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 50
A3     4        q     u
C4     2        e     d  [
E4     2        e     d  ]
F4     4        q     d
rest   4        q
measure 51
rest   4        q
C4     2        e     d  [
D4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  =
G4     2        e     d  =
B3     2        e     d  ]
measure 52
C4     2        e     d  [
G4     2        e     d  =
F4     2        e     d  =
C4     2        e     d  ]
F4     2        e     u  [
F3     2        e     u  =
A3     2        e     u  =      (
F3     2        e     u  ]      )
measure 53
A3     2        e     u  [      (
F3     2        e     u  =      )
Bf3    2        e     u  =      (
F3     2        e     u  ]      )
A3     2        e     u  [      (
F3     2        e     u  =      )
A3     2        e     u  =      (
F3     2        e     u  ]      )
measure 54
A4     2        e     d  [      (
F4     2        e     d  =      )
Bf4    2        e     d  =      (
F4     2        e     d  ]      )
A4     2        e     d  [      (
F4     2        e     d  =      )
A4     2        e     d  =      (
F4     2        e     d  ]      )
measure 55
A4     2        e     d  [
F4     2        e     d  =
C5     2        e     d  =
F4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  =
E4     2        e     d  =
C4     2        e     d  ]
measure 56
D4     2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
E4     2        e     d  ]
D4     2        e     u  [
C4     2        e     u  =
Bf3    2        e     u  =
A3     2        e     u  ]
measure 57
D4     2        e     u  [
C4     2        e     u  =
Bf3    2        e     u  =
A3     2        e     u  ]
G3     4        q     u
rest   4        q
measure 58
rest  16
measure 59
rest   8        h
rest   4        q
C5     2        e     d  [
C5     2        e     d  ]
measure 60
C5     4        q     d
C4     4        q     u
rest   4        q
D5     2        e     d  [
D5     2        e     d  ]
measure 61
D5     4        q     d
D4     4        q     d
rest   4        q
E4     2        e     d  [
E4     2        e     d  ]
measure 62
E4     4        q     d
E3     4        q     u
rest   4        q
F4     2        e     d  [
F4     2        e     d  ]
measure 63
F4     4        q     d
F3     4        q     u
rest   4        q
G4     2        e     d  [
G4     2        e     d  ]
measure 64
G4     4        q     d
G4     2        e     d  [
E4     2        e     d  ]
A4     2        e     d  [
G4     2        e     d  =
A4     3        e.    d  =
Bf4    1        s     d  ]\
measure 65
G4     4        q     d
C4     2        e     u  [
Bf3    2        e     u  ]
A3     1        s     u  [[
G3     1        s     u  ==
F3     1        s     u  ==
A3     1        s     u  ]]
G3     1        s     u  [[
F3     1        s     u  ==
E3     1        s     u  ==
G3     1        s     u  ]]
measure 66
F3     2        e     u  [
C4     2        e     u  =
E4     2        e     u  =
C4     2        e     u  ]
C4     4        q     u
F4     2        e     d  [
A4     2        e     d  ]
measure 67
Bf4    4        q     d
A4     4        q     d
F4     4        q     d
F4     4        q     d
measure 68
F4     4        q     d
A3     2        e     u  [
C4     2        e     u  ]
F3     4        q     u
F4     2        e     d  [
F4     2        e     d  ]
measure 69
F4     4        q     d
F3     2        e     d  [
F4     2        e     d  ]
D4     2        e     d  [
E4     2        e     d  =
C4     2        e     d  =
F4     2        e     d  ]
measure 70
F4     2        e     d  [
F4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
C4     4        q     u
C4     2        e     d  [
D4     2        e     d  ]
measure 71
E4     2        e     d  [
C4     2        e     d  ]
rest   8        h
A4     2        e     d  [
Bf4    2        e     d  ]
measure 72
C5     2        e     d  [
A4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
E4     4        q     d         i
C4     4        q     u         i
measure 73
C4     4        q     u         i
C4     4        q     u         i
C4     4        q     u         i
F4     2        e     d  [
F4     2        e     d  ]
measure 74
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
F4     4        q     d
G4     4        q     d
measure 75
G4     8        h     d
G4     8        h     d
measure 76
G4     8        h     d
$ D:Adagio
rest   8        h
measure 77
rest  16
measure 78
rest   8        h
E4     6        q.    d         +
E4     2        e     d
measure 79
F4     8        h     d
Ef4    8        h     d
measure 80
Df4    8        h     d
C4     8        h     u
measure 81
Bf3    8        h     u
A3     8        h     u         +
measure 82
F4    16        w     d
measure 83
rest  16
measure 84
rest  16
measure 85
rest   8        h
C4     8        h     u
measure 86
Bf3    8        h     u
Af3    8        h     u
measure 87
G3    16-       w     u        -
measure 88
G3     8        h     u
G3     4        q     u
G3     4        q     u
measure 89
C4     4        q     u
C4     4        q     u
Df4    8        h     d
measure 90
C4    16-       w     u        -
measure 91
C4     8        h     u
C4     8        h     u
measure 92
Af3   16        b     u
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/4} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:1da8451530e6ce5bf1c0513db18508e0]
04/11/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:4  D:Allegro moderato
rest   4        q
rest   2        e
C5     2        e     d                    All
F5     4        q     d                    we,
D5     4        q     d                    like
measure 2
C5     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 3
rest   4        q
rest   2        e
C4     2        e     u                    all
F4     4        q     u                    we,
D4     4        q     u                    like
measure 4
C4     4        q     u                    sheep,
rest   2        e
C4     2        e     u                    have
D4     2        e     u                    gone
C4     2        e     u                    a-
F4     2        e     u  [                 stray,_
E4     2        e     u  ]                 _
measure 5
A4     2        e     u  [                 _
G4     2        e     u  =                 _
Bf4    2        e     u  =                 _
A4     2        e     u  ]                 _
D5     2        e     d  [                 _
C5     2        e     d  =                 _
E5     2        e     d  =                 _
F5     2        e     d  ]                 _
measure 6
G5     4        q     d                    _
rest   2        e
G4     2        e     u                    all
C5     4        q     d                    we,
A4     4        q     u                    like
measure 7
G4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 8
rest   4        q
rest   2        e
C5     2        e     d                    all
F5     4        q     d                    we,
D5     4        q     d                    like
measure 9
C5     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
rest   4        q
G4     2        e     u                    we
Bf4    2        e     u                    have
A4     1        s     u  [[                tur-
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
F4     1        s     u  ==                -
E4     1        s     u  ==                -
G4     1        s     u  ]]                -
measure 12
A4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
G4     1        s     u  ]]                -
A4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
G4     1        s     u  =]                -
measure 13
A4     2        e     u  ]                 -
F4     2        e     u                    ned
C5     2        e     d                    ev'-
C5     2        e     d                    ry
C5     4        q     d                    one
C5     4        q     d                    to
measure 14
C5     4        q     d                    his
C5     4        q     d                    own
C5     8        h     d                    way.
measure 15
rest  16
measure 16
rest  16
measure 17
rest   4        q
rest   2        e
G4     2        e     u                    All
C5     4        q     d                    we,
A4     4        q     u                    like
measure 18
G4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest   4        q
rest   2        e
G4     2        e     u                    have
A4     2        e     u                    gone
G4     2        e     u                    a-
C5     2        e     d  [                 stray;_
B4     2        e     d  ]                 _
measure 22
E5     2        e     d  [                 _
D5     2        e     d  =                 _
F5     2        e     d  =                 _
E5     2        e     d  ]                 _
A5     2        e     d  [                 _
G5     2        e     d  =                 _
B4     2        e     d  =                 _
C5     2        e     d  ]                 _
measure 23
D5     4        q     d                    _
rest   4        q
rest   4        q
G5     2        e     d                    we
G5     2        e     d                    have
measure 24
G5     4        q     d                    tur-
G4     4        q     u                    ned,
rest   8        h
measure 25
rest   4        q
D5     2        e     d                    we
F5     2        e     d                    have
E5     1        s     d  [[                tur-
D5     1        s     d  ==                -
C5     1        s     d  ==                -
E5     1        s     d  ]]                -
D5     1        s     d  [[                -
C5     1        s     d  ==                -
B4     1        s     d  ==                -
D5     1        s     d  ]]                -
measure 26
E5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
E5     1        s     d  ]]                -
D5     1        s     d  [[                -
E5     1        s     d  ==                -
F5     1        s     d  ==                -
D5     1        s     d  ]]                -
E5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
E5     1        s     d  ]]                -
D5     1        s     d  [[                -
E5     1        s     d  ==                -
F5     1        s     d  ==                -
D5     1        s     d  =]                -
measure 27
E5     2        e     d  ]                 -
C5     2        e     d                    ned
G5     2        e     d                    ev'-
G5     2        e     d                    ry
G5     4        q     d                    one
G5     4        q     d                    to
measure 28
G5     4        q     d                    his
G5     4        q     d                    own
G5     2        e     d  [                 way,_
F5     2        e     d  =                 _
E5     2        e     d  ]                 _
D5     1        s     d  [[                to_
C5     1        s     d  ]]                _
measure 29
B4     6        q.    u                    his
B4     2        e     u                    own
C5     4        q     d                    way,
C5     2        e     d                    we
C5     2        e     d                    have
measure 30
C5     4        q     d                    tur-
C4     4        q     u                    ned
rest   8        h
measure 31
rest   8        h
rest   4        q
F5     2        e     d                    ev'-
E5     2        e     d                    ry
measure 32
D5     2        e     d                    one
C5     2        e     d                    to
Bf4    2        e     u                    his
A4     2        e     u                    own
G4     4        q     u                    way.
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
G4     2        e     u                    All
measure 34
C5     4        q     d                    we,
A4     4        q     u                    like
G4     4        q     u                    sheep,
rest   4        q
measure 35
rest  16
measure 36
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    have
measure 37
G4     2        e     u                    gone
F4     2        e     u                    a-
Bf4    2        e     u  [                 stray;_
A4     2        e     u  ]                 _
D5     2        e     d  [                 _
C5     2        e     d  ]                 _
rest   4        q
measure 38
rest  16
measure 39
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    have
measure 40
G4     2        e     u                    gone
F4     2        e     u                    a-
Bf4    2        e     u  [                 stray;_
A4     2        e     u  ]                 _
D5     2        e     d  [                 _
C5     2        e     d  =                 _
Ef5    2        e     d  =                 _
D5     2        e     d  ]                 _
measure 41
G5     2        e     d  [                 _
F5     2        e     d  =                 _
A4     2        e     d  =                 _
Bf4    2        e     d  ]                 _
C5     4        q     d                    _
rest   4        q
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest   8        h
rest   4        q
F5     2        e     d                    we
F5     2        e     d                    have
measure 46
F5     4        q     d                    tur-
F4     4        q     u                    ned,
rest   4        q
D5     2        e     d                    we
Ef5    2        e     d                    have
measure 47
F5     2        e     d                    tur-
Bf4    2        e     u                    ned
F4     2        e     u                    ev'-
G4     2        e     u                    ry
A4     4        q     u                    one
Bf4    4        q     u                    to
measure 48
Bf4    4        q     u                    his
A4     4        q     u                    own
Bf4    4        q     u                    way,
rest   4        q
measure 49
rest  16
measure 50
rest   4        q
A4     2        e     u                    we
Bf4    2        e     u                    have
C5     2        e     d                    tur-
A4     2        e     u                    ned
C5     2        e     d                    ev'-
D5     2        e     d                    ry
measure 51
E5     2        e     d                    one
C5     2        e     d                    to
E5     2        e     d                    his
F5     2        e     d                    own
G5     8-       h     d        -           way,_
measure 52
G5     2        e     d                    _
C5     2        e     d                    to
Bf4    2        e     u                    his
C5     2        e     d                    own
A4     4        q     u                    way.
rest   2        e
C5     2        e     d                    All
measure 53
F5     4        q     d                    we,
D5     4        q     d                    like
C5     4        q     d                    sheep,
rest   4        q
measure 54
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    all
measure 55
C5     4        q     d                    we,
A4     4        q     u                    like
G4     4        q     u                    sheep,
rest   4        q
measure 56
rest  16
measure 57
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    have
measure 58
D5     2        e     d                    gone
C5     2        e     d                    a-
F5     2        e     d  [                 stray;_
E5     2        e     d  ]                 _
D5     2        e     d  [                 _
C5     2        e     d  =                 _
Bf4    2        e     d  =                 _
A4     2        e     d  ]                 _
measure 59
D5     2        e     d  [                 _
C5     2        e     d  =                 _
Bf4    2        e     d  =                 _
A4     2        e     d  ]                 _
G4     4        q     u                    _
rest   4        q
measure 60
rest   4        q
F5     2        e     d                    we
F5     2        e     d                    have
F5     4        q     d                    tur-
F4     4        q     u                    ned,
measure 61
rest   4        q
G5     2        e     d                    we
G5     2        e     d                    have
G5     4        q     d                    tur-
G4     4        q     u                    ned
measure 62
rest  16
measure 63
rest  16
measure 64
rest   4        q
C5     2        e     d                    ev'-
Bf4    2        e     u                    ry
A4     2        e     u                    one
G4     2        e     u                    to
A4     2        e     u                    his
Bf4    2        e     u                    own
measure 65
G4     4        q     u                    way,
rest   4        q
rest   8        h
measure 66
rest   8        h
rest   4        q
F5     2        e     d                    we
Ef5    2        e     d                    have
measure 67
D5     1        s     d  [[                tur-
C5     1        s     d  ==                -
Bf4    1        s     d  ==                -
D5     1        s     d  ]]                -
C5     1        s     d  [[                -
Bf4    1        s     d  ==                -
A4     1        s     d  ==                -
C5     1        s     d  ]]                -
Bf4    4        q     u                    -
F4     4        q     u                    ned,
measure 68
rest   8        h
rest   4        q
F5     2        e     d                    we
Ef5    2        e     d                    have
measure 69
D5     1        s     d  [[                tur-
C5     1        s     d  ==                -
Bf4    1        s     d  ==                -
D5     1        s     d  ]]                -
C5     1        s     d  [[                -
Bf4    1        s     d  ==                -
A4     1        s     d  ==                -
C5     1        s     d  ]]                -
Bf4    1        s     u  [[                -
A4     1        s     u  ==                -
G4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
A4     1        s     d  [[                -
Bf4    1        s     d  ==                -
C5     1        s     d  ==                -
A4     1        s     d  ]]                -
measure 70
D5     1        s     d  [[                -
C5     1        s     d  ==                -
D5     1        s     d  ==                -
C5     1        s     d  ]]                -
Bf4    1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
A4     1        s     u  =]                -
G4     2        e     u  ]                 -
G4     2        e     u                    ned,
rest   4        q
measure 71
rest   8        h
rest   4        q
A4     2        e     u                    we
Bf4    2        e     u                    have
measure 72
C5     2        e     d                    tur-
A4     2        e     u                    ned
C5     2        e     d                    ev'-
D5     2        e     d                    ry
E5     4        q     d                    one
F5     4        q     d                    to
measure 73
F5     4        q     d                    his
E5     4        q     d                    own
F5     4        q     d                    way,
C5     2        e     d                    we
C5     2        e     d                    have
measure 74
C5     2        e     d                    tur-
C5     2        e     d                    ned
C5     2        e     d                    ev'-
C5     2        e     d                    ry
B4     4        q     u                    one
C5     4        q     d                    to
measure 75
C5     8        h     d                    his
B4     8        h     u                    own
measure 76
C5     8        h     d                    way.
$ D:Adagio
rest   8        h
measure 77
rest   8        h
G4     6        q.    u                    And
G4     2        e     u                    the
measure 78
C5     8        h     d                    Lord
Bf4    8        h     u                    hath
measure 79
Af4    8        h     u                    laid
A4     8        h     u                    on
measure 80
Bf4    8        h     u                    him,
A4     6        q.    u         +          and
A4     2        e     u                    the
measure 81
F5     8        h     d                    Lord
Ef5    8        h     d                    hath
measure 82
Df5    8        h     d                    laid
C5     8        h     d                    on
measure 83
Bf4    8        h     u                    him,
A4     8        h     u         +          hath
measure 84
Bf4    8        h     u                    laid
C5     8        h     d                    on
measure 85
Df5   16-       w     d        -           him,_
measure 86
Df5    8        h     d                    _
Df5    8        h     d                    on
measure 87
C5    16-       w     d        -           him_
measure 88
C5     8        h     d                    _
C5     4        q     d                    the
C5     4        q     d                    i-
measure 89
C5     4        q     d                    ni-
C5     4        q     d                    qui-
Bf4    8        h     u                    ty
measure 90
Af4   16        w     u                    of
measure 91
G4    12        h.    u         (          us_
F4     4        q     u         )          _
measure 92
F4    16        b     u                    all.
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/5} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:154f40639a99881709fbd177744acd79]
04/11/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:4  D:Allegro moderato
rest   4        q
rest   2        e
F4     2        e     u                    All
F4     4        q     u                    we,
F4     4        q     u                    like
measure 2
A4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 3
rest   4        q
rest   2        e
C4     2        e     u                    all
F4     4        q     u                    we,
D4     4        q     u                    like
measure 4
C4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest   4        q
rest   2        e
E4     2        e     u                    all
F4     4        q     u                    we,
F4     4        q     u                    like
measure 7
E4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 8
rest   4        q
rest   2        e
G4     2        e     u                    all
F4     4        q     u                    we,
F4     4        q     u                    like
measure 9
A4     4        q     u                    sheep,
rest   2        e
C4     2        e     u                    have
D4     2        e     u                    gone
C4     2        e     u                    a-
F4     2        e     u  [                 stray,_
E4     2        e     u  ]                 _
measure 10
A4     2        e     u  [                 _
G4     2        e     u  =                 _
Bf4    2        e     u  =                 _
A4     2        e     u  ]                 _
D4     2        e     u  [                 _
C4     2        e     u  =                 _
E4     2        e     u  =                 _
F4     2        e     u  ]                 _
measure 11
G4     4        q     u                    _
rest   4        q
rest   8        h
measure 12
rest  16
measure 13
rest   4        q
G4     2        e     u                    we
Bf4    2        e     u                    have
A4     1        s     u  [[                tur-
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
F4     1        s     u  ==                -
E4     1        s     u  ==                -
G4     1        s     u  ]]                -
measure 14
A4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
G4     1        s     u  ]]                -
A4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
G4     1        s     u  =]                -
measure 15
A4     2        e     u  ]                 -
F4     2        e     u                    ned
C4     2        e     u                    ev'-
D4     2        e     u                    ry
E4     2        e     u                    one
C4     2        e     u                    to
F4     2        e     u                    his
G4     2        e     u                    own
measure 16
A4     2        e     u  [                 way,_
E4     2        e     u  ]                 _
F4     2        e     u                    ev'-
G4     2        e     u                    ry
A4     2        e     u                    one
Bf4    1        s     u  [[                to_
A4     1        s     u  ]]                _
G4     2        e     u                    his
F4     2        e     u                    own
measure 17
E4     4        q     u                    way.
rest   2        e
E4     2        e     u                    All
G4     4        q     u                    we,
F4     4        q     u                    like
measure 18
E4     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest   4        q
rest   2        e
E4     2        e     u                    have
F4     2        e     u                    gone
E4     2        e     u                    a-
A4     2        e     u  [                 stray;_
G4     2        e     u  ]                 _
measure 22
C4     2        e     u  [                 _
B3     2        e     u  =                 _
D4     2        e     u  =                 _
C4     2        e     u  ]                 _
F4     2        e     u  [                 _
E4     2        e     u  =                 _
D4     2        e     u  =                 _
C4     2        e     u  ]                 _
measure 23
B3     4        q     u                    _
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   4        q
B3     2        e     u                    we
C4     2        e     u                    have
D4     2        e     u                    tur-
B3     2        e     u                    ned,
E4     2        e     u                    we
F4     2        e     u                    have
measure 28
G4     2        e     u                    tur-
E4     2        e     u                    ned
G4     2        e     u                    ev'-
A4     2        e     u                    ry
D4     2        e     u         (          one_
G4     4        q     u         )          _
A4     2        e     u                    to
measure 29
G4     6        q.    u                    his
G4     2        e     u                    own
G4     4        q     u                    way,
rest   4        q
measure 30
rest   8        h
rest   4        q
C5     2        e     d                    we
C5     2        e     d                    have
measure 31
C5     4        q     d                    tur-
C4     4        q     u                    ned
rest   4        q
F4     2        e     u                    ev'-
A4     2        e     u                    ry
measure 32
Bf4    2        e     u                    one
A4     2        e     u                    to
G4     2        e     u                    his
F4     2        e     u                    own
E4     4        q     u                    way.
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u                    All
measure 34
F4     4        q     u                    we,
F4     4        q     u                    like
E4     4        q     u                    sheep,
rest   4        q
measure 35
rest   8        h
rest   4        q
rest   2        e
C4     2        e     u                    have
measure 36
D4     2        e     u                    gone
C4     2        e     u                    a-
F4     2        e     u  [                 stray;_
E4     2        e     u  ]                 _
A4     2        e     u  [                 _
G4     2        e     u  ]                 _
rest   4        q
measure 37
rest  16
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest   4        q
F4     2        e     u                    we
F4     2        e     u                    have
F4     4        q     u                    tur-
F4     4        q     u                    ned,
measure 43
rest   8        h
rest   4        q
F4     2        e     u                    ev'-
F4     2        e     u                    ry
measure 44
F4     4        q     u                    one
F4     4        q     u                    to
F4     4        q     u                    his
F4     4        q     u                    own
measure 45
F4     8        h     u                    way,
rest   8        h
measure 46
rest   4        q
D4     2        e     u                    we
Ef4    2        e     u                    have
F4     4        q     u                    tur-
D4     4        q     u                    ned
measure 47
rest   4        q
Bf3    2        e     u                    ev'-
Ef4    2        e     u                    ry
Ef4    4        q     u                    one
D4     4        q     u                    to
measure 48
G4     4        q     u                    his
F4     4        q     u                    own
F4     4        q     u                    way,
rest   4        q
measure 49
rest   4        q
D4     2        e     u                    we
Ef4    2        e     u                    have
F4     2        e     u                    tur-
D4     2        e     u                    ned
F4     2        e     u                    ev'-
G4     2        e     u                    ry
measure 50
A4     2        e     u                    one
F4     2        e     u                    to
C4     2        e     u                    his
E4     2        e     u         +          own
F4     4        q     u                    way,
rest   4        q
measure 51
rest   8        h
rest   4        q
E4     2        e     u                    ev'-
F4     2        e     u                    ry
measure 52
G4     2        e     u                    one
E4     2        e     u                    to
F4     2        e     u                    his
G4     2        e     u                    own
A4     4        q     u                    way.
rest   2        e
A4     2        e     u                    All
measure 53
F4     4        q     u                    we,
F4     4        q     u                    like
A4     4        q     u                    sheep,
rest   4        q
measure 54
rest   8        h
rest   4        q
rest   2        e
C4     2        e     u                    all
measure 55
F4     4        q     u                    we,
F4     4        q     u                    like
E4     4        q     u                    sheep,
rest   4        q
measure 56
rest  16
measure 57
rest  16
measure 58
rest   2        e
C4     2        e     u                    have
D4     2        e     u                    gone
C4     2        e     u                    a-
F4     2        e     u  [                 stray;_
E4     2        e     u  =                 _
G4     2        e     u  =                 _
F4     2        e     u  ]                 _
measure 59
Bf4    2        e     u  [                 _
A4     2        e     u  =                 _
G4     2        e     u  =                 _
F4     2        e     u  ]                 _
E4     4        q     u                    _
rest   4        q
measure 60
rest  16
measure 61
rest  16
measure 62
rest   4        q
A4     2        e     u                    we
A4     2        e     u                    have
A4     4        q     u                    tur-
A3     4        q     u                    ned,
measure 63
rest   4        q
Bf4    2        e     u                    we
Bf4    2        e     u                    have
Bf4    4        q     u                    tur-
Bf3    4        q     u                    ned
measure 64
rest   4        q
G4     2        e     u                    ev'-
G4     2        e     u                    ry
F4     2        e     u                    one
E4     2        e     d                    to
F4     2        e     u                    his
G4     2        e     u                    own
measure 65
E4     4        q     u                    way,
rest   4        q
rest   4        q
C5     2        e     u                    we
&
 C4    2        e     d
&
Bf4    2        e     u                    have
&
 G4    2        e     d
&
measure 66
A4     1        s     u  [[                tur-
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
F4     1        s     u  ==                -
E4     1        s     u  ==                -
G4     1        s     u  =]                -
F4     2        e     u  ]                 -
C4     2        e     u                    ned,
F4     2        e     u                    we
A4     2        e     u                    have
measure 67
Bf4    4        q     u                    tur-
A4     4        q     u                    ned,
rest   4        q
F4     2        e     u                    we
Ef4    2        e     u                    have
measure 68
D4     1        s     u  [[                tur-
C4     1        s     u  ==                -
Bf3    1        s     u  ==                -
D4     1        s     u  ]]                -
C4     1        s     u  [[                -
Bf3    1        s     u  ==                -
A3     1        s     u  ==                -
C4     1        s     u  =]                -
Bf3    2        e     u  ]                 -
D4     2        e     u                    ned,
F4     2        e     u                    we
C4     2        e     u                    have
measure 69
Bf4    1        s     u  [[                tur-
A4     1        s     u  ==                -
G4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
A4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
F4     1        s     u  ==                -
E4     1        s     u  ==                -
G4     1        s     u  ]]                -
F4     1        s     u  [[                -
G4     1        s     u  ==                -
A4     1        s     u  ==                -
F4     1        s     u  ]]                -
measure 70
Bf4    1        s     u  [[                -
A4     1        s     u  ==                -
Bf4    1        s     u  ==                -
A4     1        s     u  ]]                -
G4     1        s     u  [[                -
F4     1        s     u  ==                -
G4     1        s     u  ==                -
F4     1        s     u  =]                -
E4     2        e     u  ]                 -
E4     2        e     u                    ned,
rest   4        q
measure 71
rest   4        q
F4     2        e     u                    we
G4     2        e     u                    have
A4     2        e     u                    tur-
F4     2        e     u                    ned
rest   4        q
measure 72
rest   4        q
A4     2        e     u                    ev'-
A4     2        e     u                    ry
G4     4        q     u                    one
A4     4        q     u                    to
measure 73
G4     4        q     u                    his
G4     4        q     u                    own
A4     4        q     u                    way,
A4     2        e     u                    we
A4     2        e     u                    have
measure 74
G4     2        e     u                    tur-
G4     2        e     u                    ned
G4     2        e     u                    ev'-
G4     2        e     u                    ry
F4     4        q     u                    one
G4     4        q     u                    to
measure 75
G4     8        h     u                    his
G4     8        h     u                    own
measure 76
G4     8        h     u                    way.
$ D:Adagio
rest   8        h
measure 77
rest  16
measure 78
rest  16
measure 79
rest   8        h
C4     6        q.    u                    And
C4     2        e     u                    the
measure 80
F4     8        h     u                    Lord
Ef4    8        h     u                    hath
measure 81
Df4    8        h     u                    laid
C4     8        h     u                    on
measure 82
Bf3    8        h     u                    him,
A3     8        h     u         +          on
measure 83
F4    16        w     u                    him,
measure 84
rest  16
measure 85
rest   8        h
Af4    8        h     u                    hath
measure 86
G4     8        h     u                    laid
F4     8        h     u                    on
measure 87
E4    16-       w     u        -+          him_
measure 88
E4     8        h     u                    _
E4     4        q     u                    the
E4     4        q     u                    i-
measure 89
F4     4        q     u                    ni-
F4     4        q     u                    qui-
F4     8        h     u                    ty
measure 90
F4    16        w     u                    of
measure 91
E4    16        w     u         +          us
measure 92
F4    16        b     u                    all.
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/6} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:e2fd2f1c038c7a1712e2182103e9c937]
04/12/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:34  D:Allegro moderato
rest   4        q
rest   2        e
A3     2        e     u                    All
C4     4        q     d                    we,
D4     4        q     d                    like
measure 2
F4     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 3
rest   4        q
rest   2        e
A3     2        e     u                    all
C4     4        q     d                    we,
Bf3    4        q     u                    like
measure 4
A3     4        q     u                    sheep,
rest   2        e
A3     2        e     u                    have
Bf3    2        e     u                    gone
A3     2        e     u                    a-
D4     2        e     d  [                 stray,_
C4     2        e     d  ]                 _
measure 5
F4     2        e     d  [                 _
E4     2        e     d  =                 _
D4     2        e     d  =                 _
C4     2        e     d  ]                 _
Bf3    2        e     u  [                 _
A3     2        e     u  =                 _
G3     2        e     u  =                 _
F3     2        e     u  ]                 _
measure 6
E3     4        q     u                    _
rest   2        e
C4     2        e     d                    all
C4     4        q     d                    we,
C4     4        q     d                    like
measure 7
C4     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 8
rest   4        q
rest   2        e
C4     2        e     d                    all
C4     4        q     d                    we,
D4     2        e     d  [                 like_
E4     2        e     d  ]                 _
measure 9
F4     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
rest   8        h
rest   4        q
C4     2        e     d                    we
C4     2        e     d                    have
measure 12
C4     4        q     d                    tur-
C3     4        q     u                    ned
rest   8        h
measure 13
rest  16
measure 14
rest  16
measure 15
rest   4        q
C4     2        e     d                    ev'-
C4     2        e     d                    ry
C4     4        q     d                    one
C4     4        q     d                    to
measure 16
C4     4        q     d                    his
C4     4        q     d                    own
C4     2        e     d  [                 way._
D4     1        s     d  =[                _
C4     1        s     d  ]]                _
Bf3    2        e     u  [                 _
A3     2        e     u  ]                 _
measure 17
G3     4        q     u                    _
rest   2        e
C4     2        e     d                    All
C4     4        q     d                    we,
C4     4        q     d                    like
measure 18
C4     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 19
rest   4        q
rest   2        e
G3     2        e     u                    have
A3     2        e     u                    gone
G3     2        e     u                    a-
C4     2        e     d  [                 stray;_
B3     2        e     d  ]                 _
measure 20
E4     2        e     d  [                 _
D4     2        e     d  =                 _
F4     2        e     d  =                 _
E4     2        e     d  ]                 _
A3     2        e     u  [                 _
G3     2        e     u  =                 _
B3     2        e     u  =                 _
C4     2        e     u  ]                 _
measure 21
D4     4        q     d                    _
rest   4        q
rest   8        h
measure 22
rest  16
measure 23
rest   4        q
D4     2        e     d                    we
F4     2        e     d                    have
E4     1        s     d  [[                tur-
D4     1        s     d  ==                -
C4     1        s     d  ==                -
E4     1        s     d  ]]                -
D4     1        s     d  [[                -
C4     1        s     d  ==                -
B3     1        s     d  ==                -
D4     1        s     d  ]]                -
measure 24
E4     1        s     d  [[                -
D4     1        s     d  ==                -
C4     1        s     d  ==                -
E4     1        s     d  ]]                -
D4     1        s     d  [[                -
E4     1        s     d  ==                -
F4     1        s     d  ==                -
D4     1        s     d  ]]                -
E4     1        s     d  [[                -
D4     1        s     d  ==                -
C4     1        s     d  ==                -
E4     1        s     d  ]]                -
D4     1        s     d  [[                -
E4     1        s     d  ==                -
F4     1        s     d  ==                -
D4     1        s     d  =]                -
measure 25
E4     2        e     d  ]                 -
C4     2        e     d                    ned
G3     2        e     u                    ev'-
G3     2        e     u                    ry
G3     4        q     u                    one
G3     4        q     u                    to
measure 26
G3     4        q     u                    his
G3     4        q     u                    own
G3     8        h     u                    way,
measure 27
rest   4        q
G3     2        e     u                    we
A3     2        e     u                    have
B3     2        e     u                    tur-
G3     2        e     u                    ned
C4     2        e     d                    ev'-
B3     2        e     d                    ry
measure 28
C4     6        q.    d                    one_
B3     1        s     u  [[                _
A3     1        s     u  ]]                _
B3     2        e     d  [                 _
D4     2        e     d  =                 _
E4     2        e     d  ]                 _
F4     2        e     d                    to
measure 29
D4     6        q.    d                    his
D4     2        e     d                    own
E4     4        q     d                    way,
rest   4        q
measure 30
rest   4        q
C4     2        e     d                    we
C4     2        e     d                    have
C4     4        q     d                    tur-
C3     4        q     u                    ned
measure 31
rest  16
measure 32
rest   8        h
rest   4        q
F4     2        e     d                    ev'-
E4     2        e     d                    ry
measure 33
D4     2        e     d                    one
C4     2        e     d                    to
Bf3    2        e     u                    his
A3     2        e     u                    own
G3     4        q     u                    way.
rest   2        e
C4     2        e     d                    All
measure 34
C4     4        q     d                    we,
C4     4        q     d                    like
C4     4        q     d                    sheep,
rest   4        q
measure 35
rest  16
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
rest   2        e
F3     2        e     u                    have
measure 38
G3     2        e     u                    gone
F3     2        e     u                    a-
Bf3    2        e     u  [                 stray;_
A3     2        e     u  ]                 _
D4     2        e     d  [                 _
C4     2        e     d  =                 _
Ef4    2        e     d  =                 _
D4     2        e     d  ]                 _
measure 39
G4     2        e     d  [                 _
F4     2        e     d  =                 _
A3     2        e     d  =                 _
Bf3    2        e     d  ]                 _
C4     4        q     d                    _
rest   4        q
measure 40
rest  16
measure 41
rest   8        h
rest   4        q
C4     2        e     d                    we
Ef4    2        e     d                    have
measure 42
D4     1        s     d  [[                tur-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
D4     1        s     d  ==                -
Ef4    1        s     d  ==                -
C4     1        s     d  ]]                -
measure 43
D4     1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
D4     1        s     d  ==                -
Ef4    1        s     d  ==                -
C4     1        s     d  =]                -
D4     2        e     d  ]                 -
Bf3    2        e     d                    ned,
rest   4        q
measure 44
rest  16
measure 45
rest   8        h
rest   4        q
A3     2        e     u                    we
Bf3    2        e     u                    have
measure 46
C4     2        e     d                    tur-
A3     2        e     u                    ned,
Bf3    2        e     u                    we
C4     2        e     d                    have
D4     4        q     d                    tur-
Bf3    4        q     d                    ned
measure 47
rest   4        q
D4     2        e     d                    ev'-
C4     2        e     d                    ry
C4     4        q     d                    one
Bf3    4        q     d                    to
measure 48
C4     4        q     d                    his
C4     4        q     d                    own
D4     4        q     d                    way,
Bf3    2        e     d                    we
C4     2        e     d                    have
measure 49
D4     2        e     d                    tur-
Bf3    2        e     d                    ned
F4     2        e     d                    ev'-
A3     2        e     u                    ry
Bf3    2        e     u                    one
F3     2        e     u                    to
F3     2        e     u                    his
C4     2        e     d                    own
measure 50
C4     4        q     d                    way,
rest   4        q
rest   8        h
measure 51
rest   4        q
C4     2        e     d                    we
D4     2        e     d                    have
E4     2        e     d                    tur-
C4     2        e     d                    ned
G4     2        e     d                    ev'-
B3     2        e     d                    ry
measure 52
C4     2        e     d                    one
G3     2        e     u                    to
F3     2        e     u                    his
C4     2        e     d                    own
C4     4        q     d                    way.
rest   2        e
F4     2        e     d                    All
measure 53
C4     4        q     d                    we,
D4     4        q     d                    like
F4     4        q     d                    sheep,
rest   4        q
measure 54
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    all
measure 55
C4     4        q     d                    we,
C4     4        q     d                    like
C4     4        q     d                    sheep,
rest   2        e
C4     2        e     d                    have
measure 56
D4     2        e     d                    gone
C4     2        e     d                    a-
F4     2        e     d  [                 stray;_
E4     2        e     d  ]                 _
D4     2        e     d  [                 _
C4     2        e     d  =                 _
Bf3    2        e     d  =                 _
A3     2        e     d  ]                 _
measure 57
D4     2        e     d  [                 _
C4     2        e     d  =                 _
Bf3    2        e     d  =                 _
A3     2        e     d  ]                 _
G3     4        q     u                    _
rest   4        q
measure 58
rest  16
measure 59
rest  16
measure 60
rest  16
measure 61
rest   8        h
rest   4        q
E4     2        e     d                    we
E4     2        e     d                    have
measure 62
E4     4        q     d                    tur-
E3     4        q     u                    ned,
rest   4        q
F4     2        e     d                    we
F4     2        e     d                    have
measure 63
F4     4        q     d                    tur-
F3     4        q     u                    ned
rest   8        h
measure 64
rest   4        q
E4     2        e     d                    ev'-
E4     2        e     d                    ry
C4     2        e     d                    one
C4     2        e     d                    to
C4     2        e     d                    his
D4     2        e     d                    own
measure 65
E4     4        q     d                    way,
rest   4        q
rest   8        h
measure 66
rest  16
measure 67
rest   4        q
F4     2        e     d                    we
Ef4    2        e     d                    have
D4     1        s     d  [[                tur-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
C4     1        s     d  ]]                -
measure 68
Bf3    4        q     u                    -
F3     4        q     u                    ned
rest   8        h
measure 69
rest   8        h
rest   4        q
C4     2        e     d                    ev'-
F4     2        e     d                    ry
measure 70
F4     2        e     d                    one
F4     2        e     d                    to
D4     2        e     d                    his
C4     2        e     d                    own
C4     4        q     d                    way,
C4     2        e     d                    we
D4     2        e     d                    have
measure 71
E4     2        e     d                    tur-
C4     2        e     d                    ned
rest   4        q
rest   8        h
measure 72
rest   4        q
F4     2        e     d                    ev'-
F4     2        e     d                    ry
E4     4        q     d                    one
C4     4        q     d                    to
measure 73
C4     4        q     d                    his
C4     4        q     d                    own
C4     4        q     d                    way,
F4     2        e     d                    we
F4     2        e     d                    have
measure 74
C4     2        e     d                    tur-
C4     2        e     d                    ned
C4     2        e     d                    ev'-
C4     2        e     d                    ry
D4     4        q     d                    one
E4     4        q     d                    to
measure 75
D4     8        h     d                    his
D4     8        h     d                    own
measure 76
E4     8        h     d                    way.
$ D:Adagio
rest   8        h
measure 77
rest  16
measure 78
rest   8        h
E4     6        q.    d         +          And
E4     2        e     d                    the
measure 79
F4     8        h     d                    Lord
Ef4    8        h     d                    hath
measure 80
Df4    8        h     d                    laid
C4     8        h     d                    on
measure 81
Bf3    8        h     u                    him,
A3     8        h     u         +          on
measure 82
F4    16        w     d                    him,
measure 83
rest  16
measure 84
rest  16
measure 85
rest   8        h
C4     8        h     d                    hath
measure 86
Bf3    8        h     u                    laid
Af3    8        h     u                    on
measure 87
G3    16-       w     u        -           him_
measure 88
G3     8        h     u                    _
G3     4        q     u                    the
G3     4        q     u                    i-
measure 89
C4     4        q     d                    ni-
C4     4        q     d                    qui-
Df4    8        h     d                    ty
measure 90
C4    16-       w     d        -           of_
measure 91
C4     8        h     d                    _
C4     8        h     d                    us
measure 92
Af3   16        b     u                    all.
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/7} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:b876f5561d6f7d514aef5cb6f7ddf052]
04/12/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:22  D:Allegro moderato
rest   4        q
rest   2        e
F3     2        e     d                    All
A3     4        q     d                    we,
Bf3    4        q     d                    like
measure 2
F3     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 3
rest   4        q
rest   2        e
F3     2        e     d                    all
A2     4        q     u                    we,
Bf2    4        q     u                    like
measure 4
F3     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest   4        q
rest   2        e
C4     2        e     d                    all
A3     4        q     d                    we,
F3     4        q     d                    like
measure 7
C4     4        q     d                    sheep,
rest   4        q
rest   8        h
measure 8
rest   4        q
rest   2        e
C4     2        e     d                    all
A3     4        q     d                    we,
Bf3    4        q     d                    like
measure 9
F3     4        q     d                    sheep,
rest   2        e
F3     2        e     d                    have
Bf2    2        e     u                    gone
A2     2        e     u                    a-
D3     2        e     u  [                 stray,_
C3     2        e     u  ]                 _
measure 10
F3     2        e     d  [                 _
E3     2        e     d  =                 _
G3     2        e     d  =                 _
F3     2        e     d  ]                 _
Bf3    2        e     d  [                 _
A3     2        e     d  =                 _
G3     2        e     d  =                 _
F3     2        e     d  ]                 _
measure 11
C4     4        q     d                    _
rest   4        q
rest   8        h
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest   4        q
rest   2        e
C3     2        e     u                    All
E3     4        q     d                    we,
F3     4        q     d                    like
measure 18
C3     4        q     u                    sheep,
rest   4        q
rest   8        h
measure 19
rest   4        q
rest   2        e
C3     2        e     u                    have
F3     2        e     d                    gone
E3     2        e     d                    a-
A3     2        e     d  [                 stray;_
G3     2        e     d  ]                 _
measure 20
C4     2        e     d  [                 _
B3     2        e     d  =                 _
A3     2        e     d  =                 _
G3     2        e     d  ]                 _
F3     2        e     d  [                 _
E3     2        e     d  =                 _
D3     2        e     d  =                 _
C3     2        e     d  ]                 _
measure 21
G3     4        q     d                    _
rest   4        q
rest   8        h
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   8        h
rest   4        q
C3     2        e     u                    we
D3     2        e     u                    have
measure 28
E3     2        e     d                    tur-
C3     2        e     u                    ned
E3     2        e     d                    ev'-
F3     2        e     d                    ry
G3     2        e     d  [                 one_
B3     2        e     d  =                 _
C4     2        e     d  ]                 _
F3     2        e     d                    to
measure 29
G3     6        q.    d                    his
G3     2        e     d                    own
C3     4        q     u                    way,
rest   4        q
measure 30
rest  16
measure 31
rest   4        q
C4     2        e     d                    we
C4     2        e     d                    have
C4     4        q     d                    tur-
C3     4        q     u                    ned
measure 32
rest   8        h
rest   4        q
A3     2        e     d                    ev'-
F3     2        e     d                    ry
measure 33
Bf3    2        e     d                    one
A3     2        e     d                    to
G3     2        e     d                    his
F3     2        e     d                    own
C3     4        q     u                    way.
rest   2        e
C3     2        e     u                    All
measure 34
A3     4        q     d                    we,
F3     4        q     d                    like
C3     4        q     u                    sheep,
rest   4        q
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
measure 38
rest  16
measure 39
rest   8        h
rest   4        q
rest   2        e
D4     2        e     d                    have
measure 40
Ef4    2        e     d  [                 gone_
D4     2        e     d  ]                 _
rest   2        e
C4     2        e     d                    a-
Bf3    2        e     d  [                 stray;_
A3     2        e     d  =                 _
G3     2        e     d  =                 _
F3     2        e     d  ]                 _
measure 41
Ef3    2        e     d  [                 _
D3     2        e     d  =                 _
C3     2        e     d  =                 _
Bf2    2        e     d  ]                 _
F3     4        q     d                    _
rest   4        q
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
C4     2        e     d                    we
Ef4    2        e     d                    have
measure 44
D4     1        s     d  [[                tur-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
D4     1        s     d  ==                -
Ef4    1        s     d  ==                -
C4     1        s     d  ]]                -
measure 45
D4     1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
D4     1        s     d  ]]                -
C4     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
C4     1        s     d  =]                -
D4     2        e     d  ]                 -
Bf3    2        e     d                    ned,
F3     2        e     d                    we
G3     2        e     d                    have
measure 46
A3     2        e     d                    tur-
F3     2        e     d                    ned,
rest   4        q
rest   4        q
Bf2    2        e     u                    we
C3     2        e     u                    have
measure 47
D3     2        e     u                    tur-
Bf2    2        e     u                    ned
D3     2        e     u                    ev'-
Ef3    2        e     d                    ry
F3     4        q     d                    one
G3     4        q     d                    to
measure 48
Ef3    4        q     d                    his
F3     4        q     d                    own
Bf2    4        q     u                    way,
rest   4        q
measure 49
rest   4        q
Bf2    2        e     u                    we
C3     2        e     u                    have
D3     2        e     u                    tur-
Bf2    2        e     u                    ned
D3     2        e     u                    ev'-
E3     2        e     d                    ry
measure 50
F3     4        q     d                    one,
F3     2        e     d                    ev'-
G3     2        e     d                    ry
A3     2        e     d                    one
F3     2        e     d                    to
A3     2        e     d                    his
Bf3    2        e     d                    own
measure 51
C4     4        q     d                    way,
rest   4        q
rest   4        q
C3     2        e     u                    ev'-
D3     2        e     u                    ry
measure 52
E3     2        e     d                    one
C3     2        e     u                    to
D3     2        e     u                    his
E3     2        e     d                    own
F3     4        q     d                    way.
rest   2        e
F3     2        e     d                    All
measure 53
A3     4        q     d                    we,
Bf3    4        q     d                    like
F3     4        q     d                    sheep,
rest   4        q
measure 54
rest   8        h
rest   4        q
rest   2        e
F3     2        e     d                    all
measure 55
A3     4        q     d                    we,
F3     4        q     d                    like
C3     4        q     u                    sheep,
rest   4        q
measure 56
rest   2        e
C3     2        e     u                    have
D3     2        e     u                    gone
C3     2        e     u                    a-
F3     2        e     d  [                 stray;_
E3     2        e     d  =                 _
G3     2        e     d  =                 _
F3     2        e     d  ]                 _
measure 57
Bf3    2        e     d  [                 _
A3     2        e     d  =                 _
G3     2        e     d  =                 _
F3     2        e     d  ]                 _
C3     4        q     u                    _
rest   4        q
measure 58
rest  16
measure 59
rest   8        h
rest   4        q
C4     2        e     d                    we
C4     2        e     d                    have
measure 60
C4     4        q     d                    tur-
C3     4        q     u                    ned,
rest   4        q
D4     2        e     d                    we
D4     2        e     d                    have
measure 61
D4     4        q     d                    tur-
D3     4        q     u                    ned
rest   8        h
measure 62
rest  16
measure 63
rest  16
measure 64
rest   4        q
E3     2        e     d                    ev'-
C3     2        e     u                    ry
F3     2        e     d                    one
C3     2        e     u                    to
F3     2        e     d                    his
Bf2    2        e     u                    own
measure 65
C3     4        q     u                    way,
C4     2        e     d                    we
Bf3    2        e     d                    have
A3     1        s     d  [[                tur-
G3     1        s     d  ==                -
F3     1        s     d  ==                -
A3     1        s     d  ]]                -
G3     1        s     d  [[                -
F3     1        s     d  ==                -
E3     1        s     d  ==                -
G3     1        s     d  =]                -
measure 66
F3     2        e     d  ]                 -
C3     2        e     u                    ned,
C4     2        e     d                    we
Bf3    2        e     d                    have
A3     4        q     d                    tur-
F3     4        q     d                    ned,
measure 67
rest  16
measure 68
rest   4        q
F3     2        e     d                    we
Ef3    2        e     d                    have
D3     1        s     d  [[                tur-
C3     1        s     d  ==                -
Bf2    1        s     d  ==                -
Bf3    1        s     d  ]]                -
A3     1        s     d  [[                -
G3     1        s     d  ==                -
F3     1        s     d  ==                -
A3     1        s     d  ]]                -
measure 69
Bf3    4        q     d                    -
F3     4        q     d                    ned
rest   4        q
F3     2        e     d                    ev'-
F3     2        e     d                    ry
measure 70
D3     2        e     u                    one
F3     2        e     d                    to
Bf3    2        e     d                    his
F3     2        e     d                    own
C3     4        q     u                    way,
rest   4        q
measure 71
rest   8        h
rest   4        q
F3     2        e     d                    we
G3     2        e     d                    have
measure 72
A3     2        e     d                    tur-
F3     2        e     d                    ned
A3     2        e     d                    ev'-
Bf3    2        e     d                    ry
C4     4        q     d                    one
F3     4        q     d                    to
measure 73
C4     4        q     d                    his
C4     4        q     d                    own
F3     4        q     d                    way,
F3     2        e     d                    we
F3     2        e     d                    have
measure 74
E3     2        e     d                    tur-
E3     2        e     d                    ned
E3     2        e     d                    ev'-
E3     2        e     d                    ry
D3     4        q     u                    one
C3     4        q     u                    to
measure 75
G3     8        h     d                    his
G2     8        h     u                    own
measure 76
C3     8        h     u                    way.
$ D:Adagio
C3     6        q.    u                    And
C3     2        e     u                    the
measure 77
C4     8        h     d                    Lord
Bf3    8        h     d                    hath
measure 78
Af3    8        h     d                    laid
G3     8        h     d                    on
measure 79
F3    16-       w     d        -           him,_
measure 80
F3    16-       w     d        -           _
measure 81
F3    16-       w     d        -           _
measure 82
F3     8        h     d                    _
Ef3    8        h     d                    the
measure 83
Df3    8        h     u                    Lord
Ef3    8        h     d                    hath
measure 84
Df3    8        h     u                    laid
C3     8        h     u                    on
measure 85
Bf2   16-       w     u        -           him_
measure 86
Bf2   16-       w     u        -           _
measure 87
Bf2   16-       w     u        -           _
measure 88
Bf2    8        h     u                    _
Bf2    4        q     u                    the
Bf2    4        q     u                    i-
measure 89
Af2    4        q     u                    ni-
Af2    4        q     u                    qui-
Bf2    8        h     u                    ty
measure 90
C3    16-       w     u        -           of_
measure 91
C3     8        h     u                    _
C3     8        h     u                    us
measure 92
F3    16        b     d                    all.
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-04/8} [KHM:874681587]
TIMESTAMP: DEC/26/2001 [md5sum:fc7cc5185cfa87e84ef824047f275060]
04/12/90 E. Correia
WK#:56        MV#:2,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-1  Q:4  T:1/1  C:22  D:Allegro moderato
F2     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
measure 2
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
measure 3
A3     2        e     u  [
F3     2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
A2     2        e     u  [
F2     2        e     u  =
Bf2    2        e     u  =
F2     2        e     u  ]
measure 4
A2     2        e     u  [
F2     2        e     u  ]
$ C:12
A3     2        e     d  [
F3     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 5
F4     2        e     d  [
E4     2        e     d  =
f1              6
D4     2        e     d  =
C4     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
$ C:22
measure 6
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 7
C4     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
E3     2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 8
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
measure 9
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
Bf2    2        e     u  [
A2     2        e     u  =
D3     2        e     u  =
C3     2        e     u  ]
measure 10
F3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
measure 11
E3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F2     2        e     u  [
F3     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]
measure 12
F3     2        e     u  [
F2     2        e     u  =
E3     2        e     u  =
G3     2        e     u  ]
F3     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  ]
measure 13
F3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F2     2        e     u  [
F3     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]
measure 14
F2     2        e     u  [
F3     2        e     u  =
E3     2        e     u  =
G3     2        e     u  ]
F3     2        e     d  [
A3     2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
measure 15
F2     2        e     u  [
F3     2        e     u  =
E3     2        e     u  =
D3     2        e     u  ]
C3     2        e     u  [
Bf2    2        e     u  =
A2     2        e     u  =
G2     2        e     u  ]
measure 16
F2     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
E3     2        e     u  ]
F3     2        e     u  [
A2     2        e     u  =
Bf2    2        e     u  =
F2     2        e     u  ]
measure 17
C3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
E3     2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 18
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
E3     2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 19
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F3     2        e     d  [
E3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
measure 20
C4     2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
F3     2        e     d  [
E3     2        e     d  =
D3     2        e     d  =
C3     2        e     d  ]
measure 21
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
C4     2        e     d  ]
$ C:13
F4     2        e     d  [
E4     2        e     d  =
A4     2        e     d  =
G4     2        e     d  ]
measure 22
C4     2        e     d  [
B3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
F4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
$ C:22
measure 23
f1              n
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
C3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
measure 24
C3     2        e     d  [
C4     2        e     d  =
B3     2        e     d  =
D4     2        e     d  ]
C4     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
B3     2        e     d  ]
measure 25
C4     2        e     d  [
C3     2        e     d  =
B2     2        e     d  =
G2     2        e     d  ]
C3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
measure 26
C3     2        e     u  [
E2     2        e     u  =
G2     2        e     u  =
B2     2        e     u  ]
C3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
measure 27
C3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
B3     2        e     d  [
G3     2        e     d  ]
C3     2        e     d  [
D3     2        e     d  ]
measure 28
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  ]
G3     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
F3     2        e     d  ]
measure 29
G3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
C3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 30
F3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
C4     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 31
F3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
E3     2        e     u  [
C3     2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
measure 32
Bf2    2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
Bf2    2        e     d  ]
C3     2        e     u  [
Bf2    2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
measure 33
Bf2    2        e     u  [
A2     2        e     u  =
G2     2        e     u  =
F2     2        e     u  ]
C3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 34
A2     2        e     u  [
F2     2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
C3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 35
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
C4     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
A3     2        e     d  ]
measure 36
Bf3    2        e     d  [
A3     2        e     d  ]
rest   2        e
G3     2        e     d
F3     2        e     d  [
C4     2        e     d  =
Bf3    2        e     d  =
A3     2        e     d  ]
measure 37
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
Bf2    2        e     u  [
F2     2        e     u  =
G2     2        e     u  =
A2     2        e     u  ]
measure 38
Bf2    2        e     u  [
A2     2        e     u  =
G2     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     u  [
A2     2        e     u  =
G2     2        e     u  =
F2     2        e     u  ]
measure 39
Ef3    2        e     u  [
D3     2        e     u  =
C3     2        e     u  =
Bf2    2        e     u  ]
F3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
measure 40
Ef4    2        e     d  [
D4     2        e     d  ]
rest   2        e
C4     2        e     d
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
measure 41
Ef3    2        e     d  [
D3     2        e     d  =
C3     2        e     d  =
Bf2    2        e     d  ]
F3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 42
Bf3    2        e     d  [
Bf2    2        e     d  =
A2     2        e     d  =
F2     2        e     d  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
measure 43
Bf2    2        e     d  [
D3     2        e     d  =
Ef3    2        e     d  =
F3     2        e     d  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 44
Bf3    2        e     d  [
D3     2        e     d  =
F3     2        e     d  =
F2     2        e     d  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
measure 45
Bf2    2        e     u  [
D3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     d  [
D3     2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
measure 46
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  ]
D4     2        e     d  [
Bf3    2        e     d  =
Bf2    2        e     d  =
C3     2        e     d  ]
measure 47
D3     2        e     u  [
Bf2    2        e     u  =
D3     2        e     u  =
Ef3    2        e     u  ]
F3     2        e     u  [
F2     2        e     u  =
G2     2        e     u  =
G3     2        e     u  ]
measure 48
Ef3    2        e     u  [
C3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
measure 49
Bf3    4        q     d
Bf2    2        e     u  [
C3     2        e     u  ]
D3     2        e     d  [
Bf2    2        e     d  =
D3     2        e     d  =
E3     2        e     d  ]
measure 50
F3     4        q     d
F3     2        e     d  [
G3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
measure 51
C4     4        q     d
$ C:12
C4     2        e     d  [
D4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  ]
$ C:22
C3     2        e     d  [
D3     2        e     d  ]
measure 52
E3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
E3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 53
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 54
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 55
A2     2        e     u  [
F2     2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
C3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 56
F3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
C3     2        e     d  ]
F3     2        e     d  [
E3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
measure 57
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
C3     2        e     d  [
E3     2        e     d  =
F3     2        e     d  =
A3     2        e     d  ]
$ C:13
measure 58
Bf3    2        e     u  [
A3     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
F4     2        e     d  [
E4     2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
measure 59
Bf4    2        e     d  [
A4     2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
$ C:22
C4     2        e     d  [
G3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
measure 60
F3     2        e     u  [
F2     2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  =
A3     2        e     d  ]
measure 61
G3     2        e     u  [
G2     2        e     u  =
Bf2    2        e     u  =
G2     2        e     u  ]
C3     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 62
A3     2        e     d  [
A2     2        e     d  =
C3     2        e     d  =
A2     2        e     d  ]
D3     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 63
Bf3    2        e     d  [
Bf2    2        e     d  =
D3     2        e     d  =
Bf2    2        e     d  ]
G2     2        e     d  [
D3     2        e     d  =
G3     2        e     d  =
D3     2        e     d  ]
measure 64
E3     2        e     d  [
G3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F3     2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
Bf2    2        e     d  ]
measure 65
C3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F2     2        e     u  [
F3     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]
measure 66
F3     2        e     d  [
A3     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
A3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 67
Bf2    2        e     u  [
D3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 68
Bf3    2        e     d  [
Bf2    2        e     d  =
F3     2        e     d  =
Ef3    2        e     d  ]
D3     2        e     d  [
Bf2    2        e     d  =
A2     2        e     d  =
A3     2        e     d  ]
measure 69
Bf3    2        e     d  [
Bf2    2        e     d  =
F3     2        e     d  =
F2     2        e     d  ]
Bf2    2        e     u  [
C3     2        e     u  =
F2     2        e     u  =
F3     2        e     u  ]
measure 70
D3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  ]
C3     2        e     u  [
Bf2    2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
measure 71
C3     2        e     u  [
A2     2        e     u  =
D3     2        e     u  =
E3     2        e     u  ]
F3     2        e     u  [
F2     2        e     u  =
F3     2        e     u  =
G3     2        e     u  ]
measure 72
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
C4     4        q     d
F3     4        q     d
measure 73
C3     8        h     u
F3     4        q     d
F3     2        e     d  [
F3     2        e     d  ]
measure 74
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
D3     4        q     u
C3     4        q     u
measure 75
G3     8        h     d
G2     8        h     u
measure 76
C3     8        h     u
$ D:Adagio
C3     6        q.    u
C3     2        e     u
measure 77
C4     8        h     d
Bf3    8        h     d
measure 78
Af3    8        h     d
G3     8        h     d
measure 79
F3    16-       w     d        -
measure 80
F3    16-       w     d        -
measure 81
F3    16-       w     d        -
measure 82
F3     8        h     d
f2              4n 2
Ef3    8        h     d
measure 83
Df3    8        h     u
Ef3    8        h     d
measure 84
Df3    8        h     u
C3     8        h     u
measure 85
Bf2   16-       w     u        -
measure 86
Bf2   16-       w     u        -
measure 87
Bf2   16-       w     u        -
measure 88
Bf2    8        h     u
Bf2    4        q     u
Bf2    4        q     u
measure 89
Af2    4        q     u
Af2    4        q     u
Bf2    8        h     u
measure 90
f1              4
C3    16-       w     u        -
measure 91
f1              n
C3     8        h     u
C3     8        h     u
measure 92
f1              f
F2    16        b     u
mheavy2 93
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
