&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/01} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:0ddd905d9823264f3d1317070d423af1]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba I
1 23
Group memberships: score
score: part 1 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:4   D:Allegro moderato
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest   8
measure 7
rest   8
measure 8
rest   8
measure 9
rest   8
measure 10
rest   8
measure 11
rest   8
measure 12
rest   8
measure 13
rest   8
measure 14
rest   8
measure 15
rest   8
measure 16
rest   8
measure 17
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest   8
measure 23
rest   8
measure 24
rest   8
measure 25
rest   8
measure 26
rest   8
measure 27
rest   8
measure 28
rest   8
measure 29
rest   8
measure 30
rest   8
measure 31
F#5    2        q     d         i
rest   1        e
G5     1        e     d
A5     2        q     d
A5     2        q     d
measure 32
A5     2        q     d
rest   2        q
rest   2        q
F#5    2        q     d
measure 33
D5     2        q     d
rest   2        q
rest   2        q
A5     2-       q     d        -
measure 34
A5     2        q     d
G5     4        h     d
F#5    2        q     d
measure 35
E5     4        h     d
D5     2        q     d
rest   2        q
measure 36
rest   8
measure 37
rest   8
measure 38
E5     2        q     d
rest   1        e
E5     1        e     d
A5     2        q     d
G#5    2        q     d
measure 39
A5     2        q     d
rest   2        q
rest   4        h
measure 40
rest   8
measure 41
rest   4        h
rest   2        q
A5     2        q     d
measure 42
B5     2        q     d
E5     2        q     d
E5     2        q     d
rest   2        q
measure 43
rest   8
measure 44
rest   8
measure 45
A5     2        q     d
E5     2        q     d
F#5    2        q     d
rest   2        q
measure 46
rest   8
measure 47
rest   8
measure 48
rest   8
measure 49
rest   8
measure 50
rest   8
measure 51
rest   8
measure 52
rest   8
measure 53
rest   8
measure 54
rest   8
measure 55
rest   8
measure 56
rest   8
measure 57
rest   8
measure 58
rest   8
measure 59
rest   8
measure 60
rest   8
measure 61
rest   8
measure 62
rest   8
measure 63
rest   8
measure 64
rest   8
measure 65
rest   8
measure 66
rest   8
measure 67
rest   8
measure 68
rest   8
measure 69
rest   8
measure 70
rest   8
measure 71
rest   8
measure 72
rest   8
measure 73
rest   8
measure 74
rest   8
measure 75
D5     3        q.    d
E5     1        e     d
F#5    1        e     d  [
G5     1        e     d  =
A5     1        e     d  =
E5     1        e     d  ]
measure 76
F#5    4        h     d
E5     2        q     d
A5     2        q     d
measure 77
G5     4        h     d
F#5    4        h     d
measure 78
E5     2        q     d
E5     2        q     d
A4     2        q     u
A5     2        q     d
measure 79
G5     2        q     d
F#5    1        e     d  [
G5     1        e     d  ]
A5     3        q.    d
G5     1        e     d
measure 80
F#5    2        q     d
A5     2-       q     d        -
A5     1        e     d  [
G5     1        e     d  =
F#5    1        e     d  =
E5     1        e     d  ]
measure 81
D5     2        q     d
A5     2-       q     d        -
A5     1        e     d  [
G5     1        e     d  =
F#5    1        e     d  =
E5     1        e     d  ]
measure 82
D5     2        q     d
E5     1        e     d  [
F#5    1        e     d  ]
G5     2        q     d
A5     2        q     d
measure 83
B5     3        q.    d
A5     1        e     d
G5     1        e     d  [
F#5    1        e     d  =
E5     1        e     d  =
D5     1        e     d  ]
measure 84
E5     4        h     d
E5     4        h     d
measure 85
rest   8                        F
measure 86
$ D:Adagio
D5     4        h     d
F#5    3        q.    d
D5     1        e     d
measure 87
E5     8        w     d
measure 88
D5    16        b     d
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/02} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:1b6739b9059bd344ca8fe22798c5a88b]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba II
1 23
Group memberships: score
score: part 2 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:4   D:Allegro moderato
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest   8
measure 7
rest   8
measure 8
rest   8
measure 9
rest   8
measure 10
rest   8
measure 11
rest   8
measure 12
rest   8
measure 13
rest   8
measure 14
rest   8
measure 15
rest   8
measure 16
rest   8
measure 17
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest   8
measure 23
rest   8
measure 24
rest   8
measure 25
rest   8
measure 26
rest   8
measure 27
rest   8
measure 28
rest   8
measure 29
rest   8
measure 30
rest   8
measure 31
D5     2        q     d         i
rest   1        e
E5     1        e     d
F#5    2        q     d
E5     2        q     d
measure 32
F#5    2        q     d
rest   2        q
rest   2        q
F#4    2        q     u
measure 33
F#4    2        q     u
rest   2        q
rest   2        q
A4     2        q     u
measure 34
F#4    2        q     u
D4     2        q     u
A4     2        q     u
A5     2        q     d
measure 35
G5     4        h     d
F#5    2        q     d
rest   2        q
measure 36
rest   8
measure 37
rest   8
measure 38
A4     2        q     u
rest   1        e
A4     1        e     u
E5     2        q     d
E5     2        q     d
measure 39
E5     2        q     d
rest   2        q
rest   4        h
measure 40
rest   8
measure 41
rest   4        h
rest   2        q
E5     2        q     d
measure 42
D5     3        q.    d
D4     1        e     u
A4     2        q     u
rest   2        q
measure 43
rest   8
measure 44
rest   8
measure 45
E5     2        q     d
A4     2        q     u
D4     2        q     u
rest   2        q
measure 46
rest   8
measure 47
rest   8
measure 48
rest   8
measure 49
rest   8
measure 50
rest   8
measure 51
rest   8
measure 52
rest   8
measure 53
rest   8
measure 54
rest   8
measure 55
rest   8
measure 56
rest   8
measure 57
rest   8
measure 58
rest   8
measure 59
rest   8
measure 60
rest   8
measure 61
rest   8
measure 62
rest   8
measure 63
rest   8
measure 64
rest   8
measure 65
rest   8
measure 66
rest   8
measure 67
rest   8
measure 68
rest   8
measure 69
rest   8
measure 70
rest   8
measure 71
rest   8
measure 72
rest   8
measure 73
rest   8
measure 74
rest   8
measure 75
F#4    2        q     u
D4     2        q     u
A4     2        q     u
rest   1        e
A4     1        e     u
measure 76
A4     2        q     u
D4     2        q     u
A4     2        q     u
A4     2        q     u
measure 77
E5     4        h     d
D5     4        h     d
measure 78
A4     2        q     u
A4     2        q     u
F#4    2        q     u
F#5    2        q     d
measure 79
E5     2        q     d
D5     2        q     d
E5     4        h     d
measure 80
D5     2        q     d
rest   2        q
A4     4-       h     u        -
measure 81
A4     1        e     u  [
A4     1        e     u  =
F#4    1        e     u  =
F#4    1        e     u  ]
D4     2        q     u
A4     2        q     u
measure 82
D4     3        q.    u
D4     1        e     u
D5     2        q     d
D5     2        q     d
measure 83
D5     2        q     d
E5     2        q     d
E5     2        q     d
rest   1        e
A4     1        e     u
measure 84
A4     4        h     u
A4     4        h     u
measure 85
rest   8                        F
measure 86
$ D:Adagio
A4     4        h     u
D5     2        q     d
D4     1        e     u  [
F#4    1        e     u  ]
measure 87
A4     6        h.    u
A4     2        q     u
measure 88
F#4   16        b     u
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/03} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:bf3fdc6510aab49e67b737eaf6a0344e]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Timpani
1 23
Group memberships: score
score: part 3 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:22   D:Allegro moderato
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest   8
measure 7
rest   8
measure 8
rest   8
measure 9
rest   8
measure 10
rest   8
measure 11
rest   8
measure 12
rest   8
measure 13
rest   8
measure 14
rest   8
measure 15
rest   8
measure 16
rest   8
measure 17
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest   8
measure 23
rest   8
measure 24
rest   8
measure 25
rest   8
measure 26
rest   8
measure 27
rest   8
measure 28
rest   8
measure 29
rest   8
measure 30
rest   8
measure 31
D3     2        q     u
rest   1        e
A2     1        e     u
D3     2        q     u
A2     2        q     u
measure 32
D3     2        q     u
rest   2        q
rest   2        q
A2     2        q     u
measure 33
D3     2        q     u
rest   2        q
rest   2        q
A2     2        q     u
measure 34
D3     3        q.    u
D3     1        e     u
A2     2        q     u
D3     2        q     u
measure 35
D3     2        q     u
A2     2        q     u
D3     2        q     u
rest   2        q
measure 36
rest   8
measure 37
rest   8
measure 38
A2     2        q     u
rest   1        e
A2     1        e     u
A2     2        q     u
D3     2        q     u
measure 39
A2     2        q     u
rest   2        q
rest   4        h
measure 40
rest   8
measure 41
rest   4        h
rest   2        q
A2     2        q     u
measure 42
D3     3        q.    u
D3     1        e     u
A2     2        q     u
rest   2        q
measure 43
rest   8
measure 44
rest   8
measure 45
A2     2        q     u
A2     2        q     u
D3     2        q     u
rest   2        q
measure 46
rest   8
measure 47
rest   8
measure 48
rest   8
measure 49
rest   8
measure 50
rest   8
measure 51
rest   8
measure 52
rest   8
measure 53
rest   8
measure 54
rest   8
measure 55
rest   8
measure 56
rest   8
measure 57
rest   8
measure 58
rest   8
measure 59
rest   8
measure 60
rest   8
measure 61
rest   8
measure 62
rest   8
measure 63
rest   8
measure 64
rest   8
measure 65
rest   8
measure 66
rest   8
measure 67
rest   8
measure 68
rest   8
measure 69
rest   8
measure 70
rest   8
measure 71
rest   8
measure 72
rest   8
measure 73
rest   8
measure 74
rest   8
measure 75
D3     2        q     u
rest   1        e
D3     1        e     u
A2     2        q     u
rest   1        e
A2     1        e     u
measure 76
D3     2        q     u
D3     2        q     u
A2     2        q     u
rest   2        q
measure 77
A2     2        q     u
rest   2        q
A2     2        q     u
rest   2        q
measure 78
A2     2        q     u
rest   2        q
A2     2        q     u
rest   2        q
measure 79
A2     2        q     u
D3     2        q     u
A2     3        q.    u
A2     1        e     u
measure 80
D3     2        q     u
rest   2        q
D3     2        q     u
rest   2        q
measure 81
D3     2        q     u
rest   2        q
D3     2        q     u
rest   2        q
measure 82
D3     3        q.    u
D3     1        e     u
D3     2        q     u
D3     2        q     u
measure 83
D3     3        q.    u
D3     1        e     u
D3     2        q     u
D3     2        q     u
measure 84
A2     4        h     u
A2     4        h     u
measure 85
rest   8                        F
measure 86
$ D:Adagio
D3     4        h     u
D3     4        h     u
measure 87
A2     8        w     u
measure 88
D3    16        b     u
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/04} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:e0fe4e9723874414e4768719950772f8]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 4 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
D5     6        q.    d
E5     2        e     d
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
measure 22
F#5    2        e     d  [
D5     2        e     d  ]
B5     8        h     d
A5     4        q     d
measure 23
D5     4        q     d
G5     8        h     d
F#5    4        q     d
measure 24
B5     6        q.    d
C#6    1        s     d  [[
B5     1        s     d  ]]
C#6    2        e     d  [
A5     2        e     d  =
D6     2        e     d  =
F#5    2        e     d  ]
measure 25
G5     2        e     d  [
E5     2        e     d  =
A5     2        e     d  =
G5     2        e     d  ]
F#5    2        e     d  [
D5     2        e     d  =
F#5    2        e     d  =
G#5    2        e     d  ]
measure 26
A5     2        e     d  [
E5     2        e     d  ]
A5     8        h     d
G#5    4        q     d
measure 27
A5     4        q     d
rest   2        e
A5     2        e     d
G#5    4        q     d         i
C#6    4        q     d         i
measure 28
rest   2        e
C#6    2        e     d  [
B5     2        e     d  =
A5     2        e     d  ]
G#5    2        e     d  [
B5     2        e     d  ]
E5     4        q     d
measure 29
rest   2        e
A5     2        e     d
D6     8        h     d
C#6    4        q     d
measure 30
B5     8        h     d
A5     8        h     d
measure 31
D6     4        q     d
rest   2        e
C#6    2        e     d
D6     4        q     d
A5     4-       q     d        -
measure 32
A5     2        e     d  [
F#5    2        e     d  ]
D6     4        q     d
C#6    4        q     d
F#5    4        q     d
measure 33
rest   4        q
E5     4        q     d
A4     4        q     u
A5     4        q     d
measure 34
D5     4        q     d
G5     8        h     d
F#5    4        q     d
measure 35
E5     8        h     d
A4     4        q     u
rest   2        e
F#5    2        e     d
measure 36
G5     2        e     d  [
E5     2        e     d  =
A5     2        e     d  =
G5     2        e     d  ]
F#5    2        e     d  [
D5     2        e     d  ]
A5     4-       q     d        -
measure 37
A5     4        q     d
G#5    4        q     d
A5     2        e     d  [
C#6    2        e     d  =
D6     2        e     d  =
B5     2        e     d  ]
measure 38
C#6    4        q     d
rest   2        e
B5     2        e     d
A5     4        q     d
G#5    4        q     d
measure 39
A5     4        q     d
rest   4        q
rest   4        q
G#5    4        q     d
measure 40
F#5    4        q     d
B5     4        q     d
rest   4        q
E5     4-       q     d        -
measure 41
E5     4        q     d
D5     8        h     d
C#5    4        q     d
measure 42
B4     8        h     u
A4     6        q.    u
B4     2        e     u
measure 43
C#5    2        e     d  [
D5     2        e     d  ]
E5     4-       q     d        -
E5     2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
B4     2        e     d  [
C#5    2        e     d  ]
measure 44
D5     2        e     d  [
E5     2        e     d  ]
F#5    4-       q     d        -
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
D5     2        e     d  ]
measure 45
E5     4        q     d
A4     4        q     u
D5     6        q.    d
E5     2        e     d
measure 46
F#5    2        e     d  [
G5     2        e     d  ]
A5     4-       q     d        -
A5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
F#5    2        e     d  ]
measure 47
G5     2        e     d  [
A5     2        e     d  ]
B5     4-       q     d        -
B5     2        e     d  [
A5     1        s     d  =[
G5     1        s     d  ]]
F#5    2        e     d  [
G5     2        e     d  ]
measure 48
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
B5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
measure 49
E5     4        q     d
rest   4        q
rest   8        h
measure 50
rest  16
measure 51
D5     6        q.    d
E5     2        e     d
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
measure 52
F#5    4        q     d
rest   4        q
rest   8        h
measure 53
rest   8        h
rest   4        q
F#5    4        q     d
measure 54
B4     4        q     d
E5     8        h     d
D5     4-       q     d        -
measure 55
D5     4        q     d
C#5    4        q     d
B4     8        h     d
measure 56
A4     8        h     u
rest   8        h
measure 57
rest  16
measure 58
rest   8        h
F#5    6        q.    d
G#5    2        e     d
measure 59
A#5    2        e     d  [
B5     2        e     d  ]
C#6    8        h     d
B5     4-       q     d        -
measure 60
B5     4        q     d
A5     4        q     d         +
G#5    8        h     d
measure 61
F#5    6        q.    d
E5     2        e     d
D#5    2        e     d  [
C#5    2        e     d  ]
B4     4-       q     u        -
measure 62
B4     2        e     u  [
A4     2        e     u  =
G#4    2        e     u  =
F#4    2        e     u  ]
E4     2        e     u  [
D4     2        e     u  =
C#4    2        e     u  =
B3     2        e     u  ]
measure 63
A3     4        q     u
rest   4        q
D5     6        q.    d
C#5    2        e     d
measure 64
B4     4        q     d
E5     4-       q     d        -
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
measure 65
A4     2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
D5     4-       q     d        -
D5     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
A4     2        e     d  ]
measure 66
G4     2        e     u  [
A4     1        s     u  =[
B4     1        s     u  ]]
C5     8        h     d
C5     4-       q     d        -
measure 67
C5     4        q     d
B4     4        q     d
A4     8        h     u
measure 68
G4     6        q.    u
A4     2        e     u
B4     2        e     d  [
C#5    2        e     d  ]      +
D5     4-       q     d        -
measure 69
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     u  [
B4     2        e     u  ]
C#5    2        e     d  [
D5     2        e     d  ]
E5     4-       q     d        -
measure 70
E5     2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
B4     2        e     d  [
C#5    2        e     d  ]
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
measure 71
A5     4        q     d
E5     4        q     d
D5     8        h     d
measure 72
C#5    4        q     d
E5     4-       q     d        -
E5     2        e     d  [
D5     2        e     d  ]
C#5    4        q     d
measure 73
F#5    6        q.    d
E5     2        e     d
D5     2        e     d  [
C#5    2        e     d  ]
B4     2        e     d  [
C#5    1        s     d  =[
D5     1        s     d  ]]
measure 74
E5     6        q.    d
D5     2        e     d
C#5    2        e     d  [
B4     2        e     d  ]
A4     2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
measure 75
D5     6        q.    d
E5     2        e     d
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
measure 76
F#5    8        h     d
E5     4        q     d
rest   4        q
measure 77
rest  16
measure 78
rest   4        q
E5     4        q     d
A4     4        q     u
D6     4        q     d
measure 79
C#6    4        q     d
D6     8        h     d
C#6    4        q     d
measure 80
D6     4        q     d
A5     4-       q     d        -
A5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 81
D5     6        q.    d
E5     2        e     d
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
measure 82
G5     6        q.    d
A5     2        e     d
B5     2        e     d  [
C#6    2        e     d  =
D6     2        e     d  =
A5     2        e     d  ]
measure 83
B5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
E5     2        e     d  [
D6     2        e     d  =
C#6    2        e     d  =
B5     2        e     d  ]
measure 84
C#6    8        h     d
C#6    8        h     d
measure 85
rest  16                        F
measure 86
$ D:Adagio
D6     8        h     d
D6     8        h     d
measure 87
D6     8        h     d
C#6    8        h     d
measure 88
D6    32        b     d
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 05
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/05} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:95603c5bd05e6f2707972daeab0ea152]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 5 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
A4     6        q.    u
B4     2        e     d
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  ]
measure 27
C#5    2        e     u  [
A4     2        e     u  ]
F#5    8        h     d
E5     4        q     d         i
measure 28
A4     4        q     u         i
D5     8        h     d
C#5    4        q     d
measure 29
F#5    6        q.    d
G#5    1        s     d  [[
F#5    1        s     d  ]]
G#5    2        e     d  [
E5     2        e     d  ]
A5     4-       q     d        -
measure 30
A5     2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -+
G5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 31
F#5    4        q     d
rest   2        e
G5     2        e     d
A5     4        q     d
C#5    4        q     d
measure 32
D5     4        q     d
F#5    4        q     d
E5     4        q     d
A4     4        q     u
measure 33
F#4    4        q     u
B4     4        q     d
C#4    4        q     u
C#5    4-       q     d        -
measure 34
C#5    4        q     d
B4     4        q     d
A5     8        h     d
measure 35
G5     8        h     d
F#5    4        q     d
rest   4        q
measure 36
rest   8        h
rest   4        q
rest   2        e
C#5    2        e     d
measure 37
D5     2        e     d  [
B4     2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
C#5    2        e     d  [
A4     2        e     d  =
F#5    2        e     d  =
G#5    2        e     d  ]
measure 38
A5     4        q     d
rest   2        e
G#5    2        e     d
A5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 39
C#5    4        q     d
A4     4        q     u
G#4    4        q     u
C#5    4        q     d
measure 40
rest   4        q
F#4    4        q     u
E4     4        q     u
G#4    4        q     u
measure 41
A4     6        q.    u
A4     2        e     u
E5     6        q.    d
E5     2        e     d
measure 42
D5     8        h     d
C#5    4        q     d
rest   4        q
measure 43
E4     6        q.    u
F#4    2        e     u
G4     2        e     u  [
A4     2        e     u  ]
B4     4-       q     u        -
measure 44
B4     2        e     u  [
A4     1        s     u  =[
G4     1        s     u  ]]
F#4    2        e     u  [
G4     2        e     u  ]
A4     8-       h     u        -
measure 45
A4     6        q.    u
G4     2        e     u
F#4    4        q     u
rest   4        q
measure 46
A4     6        q.    u
B4     2        e     d
C#5    2        e     d  [
D5     2        e     d  ]
E5     4-       q     d        -
measure 47
E5     2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
B4     2        e     d  [
C#5    2        e     d  ]
D5     6        q.    d
D5     2        e     d
measure 48
C#5    2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
D5     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
measure 49
C#5    4        q     d
A5     8        h     d
G5     4-       q     d        -
measure 50
G5     4        q     d
F#5    4        q     d
E5     8        h     d
measure 51
A4     4        q     u
D4     4-       q     u        -
D4     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
measure 52
A4     2        e     u  [
F#4    2        e     u  ]
B4     8        h     u
A4     4        q     u
measure 53
D4     4        q     u
G4     8        h     u
F#4    4        q     u
measure 54
G#4    6        q.    u
F#4    1        s     u  [[
E4     1        s     u  ]]
A4     6        q.    u
G#4    1        s     u  [[
F#4    1        s     u  ]]
measure 55
E4     8        h     u
rest   4        q
E5     4-       q     d        -
measure 56
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
A4     4        q     u
rest   4        q
measure 57
F#5    6        q.    d
E5     2        e     d
D5     2        e     d  [
C#5    2        e     d  =
B4     2        e     d  =
F#5    2-       e     d  ]     -
measure 58
F#5    4        q     d
E5     4        q     d
F#5    4        q     d
C#5    4-       q     d        -
measure 59
C#5    2        e     u  [
B4     2        e     u  =
A#4    2        e     u  =
G#4    2        e     u  ]
F#4    6        q.    u
F#5    2        e     d
measure 60
E#5    4        q     d
F#5    8        h     d
E#5    4        q     d
measure 61
F#5    4        q     d
rest   4        q
rest   8        h
measure 62
E4     6        q.    u
D4     2        e     u
C#4    2        e     u  [
B3     2        e     u  ]
A3     4        q     u
measure 63
A4     6        q.    u
G4     2        e     u
F#4    4        q     u
B4     4-       q     u        -
measure 64
B4     2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
E4     2        e     u  [
F#4    1        s     u  =[
G4     1        s     u  ]]
A4     4-       q     u        -
measure 65
A4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
E4     2        e     u  ]
D4     4        q     u
D5     4        q     d
measure 66
E5     6        q.    d
F#5    1        s     d  [[
G5     1        s     d  ]]
A5     6        q.    d
G5     2        e     d
measure 67
F#5    4        q     d
G5     8        h     d
F#5    4        q     d
measure 68
G5     4        q     d
rest   4        q
D4     6        q.    u
E4     2        e     u
measure 69
F#4    2        e     u  [
G4     2        e     u  ]
A4     4-       q     u        -
A4     2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
E4     2        e     u  [
F#4    2        e     u  ]
measure 70
G4     2        e     u  [
A4     2        e     u  ]
B4     8        h     u
A4     4-       q     u        -
measure 71
A4     4        q     u
A5     8        h     d
G#5    4        q     d
measure 72
A5     4        q     d
rest   4        q
rest   4        q
A4     4-       q     u        -
measure 73
A4     2        e     u  [
G4     2        e     u  ]
F#4    4        q     u
B4     6        q.    u
A4     2        e     u
measure 74
G4     2        e     u  [
F#4    2        e     u  ]
E4     2        e     u  [
F#4    1        s     u  =[
G4     1        s     u  ]]
A4     6        q.    u
G4     2        e     u
measure 75
F#4    4        q     u
G4     4        q     u
A4     8-       h     u        -
measure 76
A4    12        h.    u
E5     4-       q     d        -
measure 77
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
A4     4        q     u
D5     4-       q     d        -
measure 78
D5     4        q     d
C#5    4        q     d
F#5    8        h     d
measure 79
E5     4        q     d
F#5    4        q     d
E5     8        h     d
measure 80
F#5    8        h     d
A5     8-       h     d        -
measure 81
A5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
D5     4        q     d
D5     4        q     d
measure 82
D5     4        q     d
E5     2        e     d  [
F#5    2        e     d  ]
G5     4        q     d
A5     2        e     d  [
D5     2        e     d  ]
measure 83
D5     4        q     d
B5     2        e     d  [
A5     2        e     d  ]
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 84
E5     8        h     d
E5     8        h     d
measure 85
rest  16                        F
measure 86
$ D:Adagio
A5     8        h     d
F#5    8        h     d
measure 87
E5    16        w     d
measure 88
F#5   32        b     d
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 06
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/06} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:8b046e35c7656d780a4ca596ebac88b2]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 6 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
A4     4        q     d
rest   2        e
G4     2        e     d
F#4    4        q     d
E4     4        q     d
measure 32
D4     2        e     d  [
A4     2        e     d  =
F#4    2        e     d  =
D4     2        e     d  ]
G4     4        q     d
C#4    4        q     d
measure 33
D4     2        e     d  [
C#4    2        e     d  ]
B3     4        q     u
E4     4        q     d
F#4    4        q     d
measure 34
F#4    2        e     d  [
E4     2        e     d  ]
D4     4        q     d
E4     4        q     d
F#4    4        q     d
measure 35
B4     4        q     d
A4     4        q     d
D5     4        q     d
rest   4        q
measure 36
rest  16
measure 37
rest  16
measure 38
E4     6        q.    d
D4     2        e     d
C#4    2        e     d  [
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]
measure 39
E4     2        e     d  [
C#4    2        e     d  ]
C#4    8        h     d
C#5    4-       q     d        -
measure 40
C#5    4        q     d
B4     2        e     d  [
A4     2        e     d  ]
G#4    6        q.    d
C#4    2        e     d
measure 41
C#4    4        q     d
D4     4        q     d
B4     4        q     d
A4     4        q     d
measure 42
F#4    4        q     d
E4     4        q     d
E4     4        q     d
A3     4-       q     u        -
measure 43
A3     2        e     u  [
B3     2        e     u  =
C#4    2        e     u  =
D4     2        e     u  ]
E4     6        q.    d
D4     1        s     d  [[
C#4    1        s     d  ]]
measure 44
B3     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
F#4    6        q.    d
E4     1        s     d  [[
D4     1        s     d  ]]
measure 45
C#4    2        e     d  [
D4     2        e     d  ]
E4     4        q     d
rest   4        q
D4     4-       q     d        -
measure 46
D4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
G4     2        e     d  ]
A4     6        q.    d
G4     1        s     d  [[
F#4    1        s     d  ]]
measure 47
E4     2        e     d  [
F#4    2        e     d  =
G4     2        e     d  =
A4     2        e     d  ]
B4     6        q.    d
B4     2        e     d
measure 48
A4     2        e     d  [
G4     2        e     d  ]
F#4    2        e     d  [
G4     1        s     d  =[
A4     1        s     d  ]]
B4     6        q.    d
B4     2        e     d
measure 49
C#5    6        q.    d
D5     1        s     d  [[
C#5    1        s     d  ]]
B4     8        h     d
measure 50
C#5    4        q     d
D5     8        h     d
C#5    4        q     d
measure 51
D5     4        q     d
F#4    4        q     d
rest   8        h
measure 52
D3     6        q.    u
E3     2        e     u
F#3    2        e     u  [
G3     2        e     u  =
A3     2        e     u  =
F#3    2        e     u  ]
measure 53
B3     6        q.    u
C#4    1        s     u  [[
B3     1        s     u  ]]
C#4    2        e     u  [
A3     2        e     u  ]
D4     4-       q     d        -
measure 54
D4     4        q     d
C#4    8        h     d
B3     4-       q     u        -
measure 55
B3     4        q     u
A3     8        h     u
G#3    4        q     u
measure 56
A3     6        q.    u
B3     2        e     u
C#4    2        e     d  [
D4     2        e     d  ]
E4     4-       q     d        -
measure 57
E4     4        q     d
D4     2        e     d  [
C#4    2        e     d  ]
B3     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
measure 58
B3     4        q     u
B4     8        h     d
A#4    4-       q     d        -
measure 59
A#4    4        q     d
F#4    8        h     d
B4     2        e     d  [
F#4    2        e     d  ]
measure 60
G#4    4        q     d
rest   4        q
C#4    6        q.    u
B3     2        e     u
measure 61
A#3    2        e     u  [
G#3    2        e     u  ]
F#3    4        q     u
rest   8        h
measure 62
E4     6        q.    d
D4     2        e     d
C#4    2        e     u  [
B3     2        e     u  ]
A3     4        q     u
measure 63
rest   4        q
D4     4-       q     d        -
D4     2        e     d  [
C#4    2        e     d  ]
B3     4        q     u
measure 64
E4     6        q.    d
D4     2        e     d
C#4    2        e     u  [
B3     2        e     u  ]
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
measure 65
D4     6        q.    d
C4     2        e     d
B3     4        q     u
B3     4        q     u
measure 66
E4     6        q.    d
D4     2        e     d
C4     2        e     u  [
B3     2        e     u  ]
A3     4-       q     u        -
measure 67
A3     4        q     u
B3     2        e     u  [
C4     2        e     u  ]
D4     8        h     d
measure 68
D4     4        q     d
G3     4-       q     u        -
G3     2        e     u  [
A3     2        e     u  =
B3     2        e     u  =
C#4    2        e     u  ]      +
measure 69
D4     4-       q     d        -
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
A3     2        e     u  [
B3     2        e     u  =
C#4    2        e     u  =
D4     2        e     u  ]
measure 70
E4     4-       q     d        -
E4     2        e     d  [
D4     1        s     d  =[
C#4    1        s     d  ]]
B3     4        q     u
F#4    4        q     d
measure 71
E4     8        h     d
rest   8        h
measure 72
E4     6        q.    d
D4     2        e     d
C#4    4        q     d
F#4    4-       q     d        -
measure 73
F#4    2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
B3     4        q     u
E4     4-       q     d        -
measure 74
E4     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  ]
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
D4     4        q     d
measure 75
D4    12        h.    d
C#4    4        q     d
measure 76
D4     8        h     d
C#4    4        q     d
A4     4        q     d
measure 77
G4     8        h     d
F#4    8        h     d
measure 78
E4     8        h     d
D4     8        h     d
measure 79
A4     4        q     d
A4     4        q     d
A4     8        h     d
measure 80
A4     4        q     d
rest   4        q
F#4    4        q     d
rest   4        q
measure 81
D4     4        q     d
A4     4-       q     d        -
A4     2        e     d  [
G4     2        e     d  =
F#4    2        e     d  =
E4     2        e     d  ]
measure 82
D4     4        q     d
G4     4        q     d
D4     4        q     d
D4     4        q     d
measure 83
G4     4        q     d
D4     4        q     d
B4     4        q     d
E4     4        q     d
measure 84
A4     8        h     d
A4     8        h     d
measure 85
rest  16                        F
measure 86
$ D:Adagio
A4     8        h     d
A4     8        h     d
measure 87
A4    16        w     d
measure 88
A4    32        b     d
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 07
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/07} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:6c4d13a861b92e94c64322c296c58185]
06/26/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 7 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
A4     6        q.    u                    A-
B4     2        e     d                    -
C#5    2        e     d  [                 -
D5     2        e     d  =                 -
E5     2        e     d  =                 -
B4     2        e     d  =                 -
measure 17
C#5    2        e     d  ]                 -
A4     2        e     u                    men,
F#5    8        h     d                    A-
E5     4        q     d                    -
measure 18
A4     4        q     u                    -
D5     8        h     d                    -
C#5    4        q     d                    men,
measure 19
F#5    8        h     d                    A-
E5     8        h     d                    -
measure 20
D5     8        h     d                    -
C#5    8        h     d                    men,
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
D5     6        q.    d                    A-
C#5    2        e     d                    -
D5     4        q     d                    -
A4     4        q     u                    men,
measure 32
D5     2        e     d                    A-
A4     2        e     u                    men,
D5     4        q     d         i          A-
C#5    4        q     d         i          -
F#5    4        q     d         i          men,
measure 33
rest   4        q
E5     4        q     d                    A-
A4     4        q     u                    -
A5     4        q     d                    -
measure 34
D5     4        q     d                    -
G5     8        h     d                    -
F#5    4        q     d                    -
measure 35
E5     8        h     d                    -
D5     8        h     d                    men,
measure 36
rest  16
measure 37
rest  16
measure 38
E5     6        q.    d                    A-
D5     2        e     d                    -
C#5    4        q     d                    -
B4     4        q     d                    -
measure 39
A4     4        q     u                    men,
rest   4        q
rest   4        q
G#4    4        q     u                    A-
measure 40
F#4    4        q     u                    -
B4     4        q     d                    men,
rest   4        q
E5     4-       q     d        -           A-
measure 41
E5     4        q     d                    -
D5     8        h     d                    -
C#5    4        q     d                    -
measure 42
B4     8        h     u                    men,
A4     6        q.    u                    A-
B4     2        e     u                    -
measure 43
C#5    2        e     d  [                 -
D5     2        e     d  ]                 -
E5     4-       q     d        -           -
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C#5    1        s     d  ]]                -
B4     2        e     d  [                 -
C#5    2        e     d  ]                 -
measure 44
D5     2        e     d  [                 -
E5     2        e     d  ]                 -
F#5    4-       q     d        -           -
F#5    2        e     d  [                 -
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
C#5    2        e     d  [                 -
D5     2        e     d  ]                 -
measure 45
E5     4        q     d                    -
A4     4        q     u                    men,
D4     6        q.    u                    A-
E4     2        e     u                    -
measure 46
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
A4     4-       q     u        -           -
A4     2        e     u  [                 -
G4     1        s     u  =[                -
F#4    1        s     u  ]]                -
E4     2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 47
G4     2        e     u  [                 -
A4     2        e     u  ]                 -
B4     4-       q     u        -           -
B4     2        e     u  [                 -
A4     1        s     u  =[                -
G4     1        s     u  ]]                -
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
measure 48
A4     2        e     d  [                 -
B4     1        s     d  =[                -
C#5    1        s     d  ]]                -
D5     2        e     d  [                 -
C#5    2        e     d  ]                 -
B4     2        e     d  [                 -
C#5    1        s     d  =[                -
D5     1        s     d  ]]                -
E5     2        e     d  [                 -
D5     2        e     d  ]                 -
measure 49
C#5    2        e     d  [                 -
B4     2        e     d  ]                 -
A4     4        q     u                    men,
rest   8        h
measure 50
rest  16
measure 51
D5     6        q.    d                    A-
E5     2        e     d                    -
F#5    2        e     d  [                 -
G5     2        e     d  =                 -
A5     2        e     d  =                 -
E5     2        e     d  ]                 -
measure 52
F#5    4        q     d                    -
F#4    4        q     u                    men,
rest   8        h
measure 53
rest   8        h
rest   4        q
F#5    4        q     d                    A-
measure 54
B4     4        q     d                    -
E5     8        h     d                    -
D5     4-       q     d        -           -
measure 55
D5     4        q     d                    -
C#5    4        q     d                    men,
B4     8        h     d                    A-
measure 56
A4     8        h     u                    men,
rest   8        h
measure 57
rest  16
measure 58
rest   8        h
F#4    6        q.    u                    A-
G#4    2        e     u                    -
measure 59
A#4    2        e     u  [                 -
B4     2        e     u  ]                 -
C#5    8        h     d                    -
B4     4-       q     d        -           -
measure 60
B4     4        q     d                    -
A4     4        q     u         +          -
G#4    8        h     u                    -
measure 61
F#4    8        h     u                    men,
rest   8        h
measure 62
rest  16
measure 63
rest   8        h
D5     6        q.    d                    A-
C#5    2        e     d                    -
measure 64
B4     4        q     d                    -
E5     4-       q     d        -           -
E5     2        e     d  [                 -
D5     2        e     d  =                 -
C#5    2        e     d  =                 -
B4     2        e     d  ]                 -
measure 65
A4     2        e     d  [                 -
B4     1        s     d  =[                -
C#5    1        s     d  ]]                -
D5     4-       q     d        -           -
D5     2        e     d  [                 -
C5     2        e     d  =                 -
B4     2        e     d  =                 -
A4     2        e     d  ]                 -
measure 66
G4     2        e     u  [                 -
A4     1        s     u  =[                -
B4     1        s     u  ]]                -
C5     8        h     d                    -
C5     4        q     d                    men,
measure 67
C5     4        q     d         (          A-
B4     4        q     d         )          -
A4     8        h     u                    men,
measure 68
G4     6        q.    u                    A-
A4     2        e     u                    -
B4     2        e     d  [                 -
C#5    2        e     d  ]      +          -
D5     4-       q     d        -           -
measure 69
D5     2        e     d  [                 -
C#5    1        s     d  =[                -
B4     1        s     d  ]]                -
A4     2        e     u  [                 -
B4     2        e     u  ]                 -
C#5    2        e     d  [                 -
D5     2        e     d  ]                 -
E5     4-       q     d        -           -
measure 70
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C#5    1        s     d  ]]                -
B4     2        e     d  [                 -
C#5    2        e     d  ]                 -
D5     2        e     d  [                 -
E5     2        e     d  =                 -
F#5    2        e     d  =                 -
G5     2        e     d  ]                 -
measure 71
A5     4        q     d                    -
E5     4        q     d                    men,
D5     8        h     d                    A-
measure 72
C#5    4        q     d                    men,
E5     4-       q     d        -           A-
E5     2        e     d  [                 -
D5     2        e     d  ]                 -
C#5    4        q     d                    -
measure 73
F#5    6        q.    d                    -
E5     2        e     d                    -
D5     2        e     d  [                 -
C#5    2        e     d  ]                 -
B4     2        e     d  [                 -
C#5    1        s     d  =[                -
D5     1        s     d  ]]                -
measure 74
E5     6        q.    d                    -
D5     2        e     d                    -
C#5    2        e     d  [                 -
B4     2        e     d  ]                 -
A4     2        e     d  [                 -
B4     1        s     d  =[                -
C#5    1        s     d  ]]                -
measure 75
D5     6        q.    d                    -
E5     2        e     d                    -
F#5    2        e     d  [                 -
G5     2        e     d  =                 -
A5     2        e     d  =                 -
E5     2        e     d  ]                 -
measure 76
F#5    8        h     d                    -
E5     4        q     d                    men,
rest   4        q
measure 77
rest  16
measure 78
rest   4        q
E5     4        q     d                    A-
A4     4        q     u                    -
D5     4        q     d                    -
measure 79
C#5    4        q     d                    -
D5     8        h     d                    -
C#5    4        q     d                    -
measure 80
D5     4        q     d                    men,
A5     4-       q     d        -           A-
A5     2        e     d  [                 -
G5     2        e     d  =                 -
F#5    2        e     d  =                 -
E5     2        e     d  ]                 -
measure 81
D5     4        q     d                    -
D4     2        e     u  [                 -
E4     2        e     u  ]                 -
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
A4     4        q     u                    men,
measure 82
G4     6        q.    u                    A-
A4     2        e     u                    -
B4     2        e     d  [                 -
C#5    2        e     d  =                 -
D5     2        e     d  =                 -
A4     2        e     d  ]                 -
measure 83
B4     4        q     d                    -
G5     4-       q     d        -           -
G5     2        e     d  [                 -
F#5    2        e     d  =                 -
E5     2        e     d  =                 -
D5     2        e     d  ]                 -
measure 84
C#5    8        h     d                    -
C#5    8        h     d                    men,
measure 85
rest  16                        F
measure 86
$ D:Adagio
D5     8        h     d                    A-
D5     8        h     d                    men,
measure 87
D5     8        h     d         (          A-
C#5    8        h     d         )          -
measure 88
D5    32        b     d                    men.
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 08
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/08} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:90a82c07df95d4d5f3c1e41952246014]
06/27/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 8 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
D4     6        q.    u                    A-
E4     2        e     u                    -
F#4    2        e     u  [                 -
G4     2        e     u  =                 -
A4     2        e     u  =                 -
E4     2        e     u  =                 -
measure 12
F#4    2        e     u  ]                 -
D4     2        e     u                    men,
B4     8        h     u                    A-
A4     4        q     u                    -
measure 13
D4     4        q     u                    -
G4     8        h     u                    -
F#4    4        q     u                    -
measure 14
B3     6        q.    u                    -
B3     2        e     u                    men,
C#4    2        e     u  [                 A-
A3     2        e     u  ]                 -
A4     4        q     u                    -
measure 15
G4     8        h     u                    -
F#4    4        q     u                    men,
F#4    2        e     u  [                 A-
E4     2        e     u  ]                 -
measure 16
D4     2        e     u  [                 -
E4     2        e     u  =                 -
F#4    2        e     u  =                 -
G4     2        e     u  ]                 -
E4     2        e     u  [                 -
D4     2        e     u  =                 -
C#4    2        e     u  =                 -
D4     2        e     u  ]                 -
measure 17
E4     4        q     u                    -
C#4    4        q     u                    men,
rest   8        h
measure 18
rest   4        q
F#4    4        q     u         i          A-
E4     4        q     u         i          -
A4     4        q     u                    men,
measure 19
rest   4        q
A4     4        q     u                    A-
B4     4        q     u                    -
A4     4        q     u                    men,
measure 20
A4     4        q     u         (          A-
G#4    4        q     u         )          -
A4     8        h     u                    men,
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
A4     6        q.    u                    A-
G4     2        e     u                    -
A4     4        q     u                    -
E4     4        q     u                    men,
measure 32
A4     2        e     u                    A-
F#4    2        e     u                    men,
B4     4        q     u                    A-
E4     4        q     u                    -
A4     4-       q     u        -           -
measure 33
A4     4        q     u                    -
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
E4     4        q     u                    -
A4     4-       q     u        -           -
measure 34
A4     4        q     u                    -
G4     4        q     u                    -
A4     8        h     u                    -
measure 35
B4     4        q     u                    -
A4     4        q     u                    -
A4     8        h     u                    men,
measure 36
rest  16
measure 37
rest  16
measure 38
A4     6        q.    u                    A-
G#4    2        e     u                    -
A4     4        q     u                    -
G#4    2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 39
E4     4        q     u                    men,
rest   4        q
rest   8        h
measure 40
rest   4        q
F#4    4        q     u                    A-
E4     4        q     u                    -
G#4    4        q     u                    -
measure 41
A4     6        q.    u                    -
G#4    1        s     u  [[                -
F#4    1        s     u  ]]                -
E4     6        q.    u                    -
E4     2        e     u                    men,
measure 42
F#4    4        q     u                    A-
E4     4        q     u                    -
E4     4        q     u                    men,
rest   4        q
measure 43
E4     6        q.    u                    A-
F#4    2        e     u                    -
G4     2        e     u  [      +          -
A4     2        e     u  ]                 -
B4     4-       q     u        -           -
measure 44
B4     2        e     u  [                 -
A4     1        s     u  =[                -
G4     1        s     u  ]]                -
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
A4     8-       h     u        -           -
measure 45
A4     6        q.    u                    -
G4     2        e     u                    -
F#4    4        q     u                    men,
rest   4        q
measure 46
A3     6        q.    u                    A-
B3     2        e     u                    -
C#4    2        e     u  [                 -
D4     2        e     u  ]                 -
E4     4-       q     u        -           -
measure 47
E4     2        e     u  [                 -
D4     1        s     u  =[                -
C#4    1        s     u  ]]                -
B3     2        e     u  [                 -
C#4    2        e     u  ]                 -
D4     6        q.    u                    -
D4     2        e     u                    -
measure 48
C#4    2        e     u  [                 -
D4     1        s     u  =[                -
E4     1        s     u  ]]                -
F#4    2        e     u  [                 -
E4     2        e     u  ]                 -
D4     2        e     u  [                 -
E4     1        s     u  =[                -
F#4    1        s     u  ]]                -
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 49
E4     4        q     u                    -
A4     8        h     u                    -
G4     4-       q     u        -           -
measure 50
G4     4        q     u                    -
F#4    4        q     u                    -
E4     8        h     u                    -
measure 51
A3     4        q     u                    men,
D4     4-       q     u        -           A-
D4     2        e     u  [                 -
E4     2        e     u  =                 -
F#4    2        e     u  =                 -
G4     2        e     u  =                 -
measure 52
A4     2        e     u  ]                 -
F#4    2        e     u                    men,
B4     8        h     u                    A-
A4     4        q     u                    -
measure 53
D4     4        q     u                    -
G4     8        h     u                    -
F#4    4        q     u                    -
measure 54
G#4    6        q.    u                    -
F#4    1        s     u  [[                -
E4     1        s     u  ]]                -
A4     6        q.    u                    -
G#4    1        s     u  [[                -
F#4    1        s     u  ]]                -
measure 55
E4     4        q     u                    -
E4     4        q     u                    men,
rest   4        q
E4     4-       q     u        -           A-
measure 56
E4     2        e     u  [                 -
D4     2        e     u  =                 -
C#4    2        e     u  =                 -
B3     2        e     u  ]                 -
A3     4        q     u                    men,
rest   4        q
measure 57
F#4    6        q.    u                    A-
E4     2        e     u                    -
D4     2        e     u  [                 -
C#4    2        e     u  ]                 -
B3     4        q     u                    men,
measure 58
B4    12        h.    u                    A-
A#4    4        q     u                    men,
measure 59
C#4    8        h     u                    A-
F#4    8        h     u                    -
measure 60
E#4    4        q     u                    -
F#4    8        h     u                    -
E#4    4        q     u                    -
measure 61
F#4    8        h     u                    men,
rest   8        h
measure 62
rest  16
measure 63
A4     6        q.    u                    A-
G4     2        e     u                    -
F#4    4        q     u                    -
B4     4-       q     u        -           -
measure 64
B4     2        e     u  [                 -
A4     2        e     u  =                 -
G4     2        e     u  =                 -
F#4    2        e     u  ]                 -
E4     2        e     u  [                 -
F#4    1        s     u  =[                -
G4     1        s     u  ]]                -
A4     4-       q     u        -           -
measure 65
A4     2        e     u  [                 -
G4     2        e     u  =                 -
F#4    2        e     u  =                 -
E4     2        e     u  ]                 -
D4     4        q     u                    -
D4     4        q     u                    men,
measure 66
E4     6        q.    u                    A-
F#4    1        s     u  [[                -
G4     1        s     u  ]]                -
A4     6        q.    u                    -
G4     2        e     u                    -
measure 67
F#4    4        q     u                    -
G4     4        q     u                    men,
G4     4        q     u                    A-
F#4    4        q     u                    -
measure 68
G4     4        q     u                    men,
rest   4        q
D4     6        q.    u                    A-
E4     2        e     u                    -
measure 69
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
A4     4-       q     u        -           -
A4     2        e     u  [                 -
G4     1        s     u  =[                -
F#4    1        s     u  ]]                -
E4     2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 70
G4     2        e     u  [                 -
A4     2        e     u  ]                 -
B4     8        h     u                    -
A4     4-       q     u        -           -
measure 71
A4     4        q     u                    -
A4     4        q     u                    men,
A4     4        q     u         (          A-
G#4    4        q     u         )          -
measure 72
A4     4        q     u                    men,
rest   4        q
rest   4        q
A4     4-       q     u        -           A-
measure 73
A4     2        e     u  [                 -
G4     2        e     u  ]                 -
F#4    4        q     u                    -
B4     6        q.    u                    -
A4     2        e     u                    -
measure 74
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
E4     2        e     u  [                 -
F#4    1        s     u  =[                -
G4     1        s     u  ]]                -
A4     6        q.    u                    -
G4     2        e     u                    -
measure 75
F#4    4        q     u                    -
G4     4        q     u                    men,
A4     8-       h     u        -           A-
measure 76
A4     8        h     u                    -
A4     8        h     u                    men,
measure 77
G4     8        h     u                    A-
F#4    8        h     u                    -
measure 78
E4     8        h     u                    men,
rest   4        q
A4     4        q     u                    A-
measure 79
G4     4        q     u                    -
F#4    2        e     u  [                 -
G4     2        e     u  ]                 -
A4     8        h     u                    -
measure 80
A4     8        h     u                    men,
A4     8-       h     u        -           A-
measure 81
A4     2        e     u  [                 -
G4     2        e     u  =                 -
F#4    2        e     u  =                 -
E4     2        e     u  ]                 -
D4     4        q     u                    -
D4     4        q     u                    men,
measure 82
rest   4        q
G4     8        h     u                    A-
A4     4        q     u                    men,
measure 83
G4     4        q     u                    A-
B4     8        h     u                    -
B4     4        q     u                    men,
measure 84
A4     8        h     u                    A-
A4     8        h     u                    men,
measure 85
rest  16                        F
measure 86
$ D:Adagio
A4     8        h     u                    A-
A4     8        h     u                    men,
measure 87
A4    16        w     u                    A-
measure 88
A4    32        b     u                    men.
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 09
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/09} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:ecf70943dafabd4af368811136c30f51]
06/27/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 9 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:34   D:Allegro moderato
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
A3     6        q.    u                    A-
B3     2        e     u                    -
C#4    2        e     d  [                 -
D4     2        e     d  =                 -
E4     2        e     d  =                 -
B3     2        e     d  =                 -
measure 7
C#4    2        e     d  ]                 -
A3     2        e     u                    men,
F#4    8        h     d                    A-
E4     4        q     d                    -
measure 8
A3     4        q     u                    -
D4     8        h     d                    -
C#4    4        q     d                    -
measure 9
F#3    6        q.    u                    -
F#3    2        e     u                    -
G#3    2        e     u  [                 -
E3     2        e     u  ]                 -
A3     4-       q     u        -           -
measure 10
A3     2        e     u  [                 -
G#3    2        e     u  =                 -
A3     2        e     u  =                 -
B3     2        e     u  ]                 -
C#4    2        e     d  [                 -
D4     2        e     d  =                 -
E4     2        e     d  =                 -
G3     2        e     d  ]                 -
measure 11
F#3    2        e     u  [                 -
B3     2        e     u  =                 -
A3     2        e     u  =                 -
G3     2        e     u  ]                 -
D4     4        q     d                    -
C#4    4        q     d                    men,
measure 12
D4     4        q     d                    A-
D3     4        q     u                    men,
rest   8        h
measure 13
rest   4        q
B3     4        q     u         i          A-
A3     4        q     u         i          -
D4     4        q     d         i          men,
measure 14
rest   8        h
rest   4        q
D4     4-       q     d        -           A-
measure 15
D4     4        q     d                    -
C#4    4        q     d                    -
D4     8        h     d                    men,
measure 16
rest  16
measure 17
rest   4        q
A3     4        q     u         i          A-
G#3    4        q     u         i          -
C#4    4        q     d                    men,
measure 18
rest  16
measure 19
rest   4        q
F#4    4        q     d                    A-
G#4    4        q     d                    -
E4     4        q     d                    men,
measure 20
F#4    4        q     d                    A-
E4     2        e     d  [                 -
D4     2        e     d  ]                 -
E4     8        h     d                    men,
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
F#4    6        q.    d                    A-
E4     2        e     d                    -
D4     4        q     d                    -
C#4    4        q     d                    men,
measure 32
D4     4        q     d                    A-
F#4    4        q     d                    men,
rest   4        q
C#4    4        q     d                    A-
measure 33
F#3    4        q     u                    -
B3     4        q     d                    -
C#4    6        q.    d                    -
C#4    2        e     d                    -
measure 34
D4     8        h     d                    -
E4     4        q     d                    -
F#4    4        q     d                    -
measure 35
G4     8        h     d                    -
F#4    8        h     d                    men,
measure 36
rest  16
measure 37
rest  16
measure 38
C#4    6        q.    d                    A-
D4     2        e     d                    -
E4     6        q.    d                    -
D4     2        e     d                    -
measure 39
E4     2        e     d                    -
C#4    2        e     d                    men,
A3     4        q     u         i          A-
G#3    4        q     u         i          -
C#4    4-       q     d        -           -
measure 40
C#4    4        q     d                    -
B3     2        e     u  [                 -
A3     2        e     u  ]                 -
G#3    2        e     u  [                 -
F#3    2        e     u  ]                 -
E3     4        q     u                    men,
measure 41
rest   4        q
A3     4        q     u                    A-
B3     4        q     u                    -
C#4    4        q     d                    men,
measure 42
D4     8        h     d                    A-
C#4    4        q     d                    men,
A3     4-       q     u        -           A-
measure 43
A3     2        e     d  [                 -
B3     2        e     d  =                 -
C#4    2        e     d  =                 -
D4     2        e     d  ]                 -
E4     6        q.    d                    -
D4     1        s     d  [[                -
C#4    1        s     d  ]]                -
measure 44
B3     2        e     d  [                 -
C#4    2        e     d  =                 -
D4     2        e     d  =                 -
E4     2        e     d  ]                 -
F#4    6        q.    d                    -
E4     1        s     d  [[                -
D4     1        s     d  ]]                -
measure 45
C#4    2        e     d  [                 -
D4     2        e     d  ]                 -
E4     4        q     d                    men,
rest   4        q
D3     4-       q     u        -           A-
measure 46
D3     2        e     u  [                 -
E3     2        e     u  =                 -
F#3    2        e     u  =                 -
G3     2        e     u  ]                 -
A3     6        q.    u                    -
G3     1        s     u  [[                -
F#3    1        s     u  ]]                -
measure 47
E3     2        e     u  [                 -
F#3    2        e     u  =                 -
G3     2        e     u  =                 -
A3     2        e     u  ]                 -
B3     6        q.    u                    -
B3     2        e     u                    -
measure 48
A3     2        e     u  [                 -
G3     2        e     u  ]                 -
F#3    2        e     u  [                 -
G3     1        s     u  =[                -
A3     1        s     u  ]]                -
B3     6        q.    u                    -
B3     2        e     u                    men,
measure 49
C#4    6        q.    d                    A-
D4     1        s     d  [[                -
C#4    1        s     d  ]]                -
B3     8        h     d                    -
measure 50
C#4    4        q     d                    -
D4     8        h     d                    -
C#4    4        q     d                    -
measure 51
D4     4        q     d                    -
A3     4        q     u                    men,
rest   8        h
measure 52
D3     6        q.    u                    A-
E3     2        e     u                    -
F#3    2        e     u  [                 -
G3     2        e     u  =                 -
A3     2        e     u  =                 -
F#3    2        e     u  ]                 -
measure 53
B3     6        q.    d                    -
C#4    1        s     d  [[                -
B3     1        s     d  ]]                -
C#4    2        e     d  [                 -
A3     2        e     d  ]                 -
D4     4-       q     d        -           -
measure 54
D4     4        q     d                    -
C#4    8        h     d                    -
B3     4-       q     d        -           -
measure 55
B3     4        q     d                    -
A3     8        h     u                    -
G#3    4        q     u                    men,
measure 56
A3     6        q.    u                    A-
B3     2        e     u                    -
C#4    2        e     d  [                 -
D4     2        e     d  ]                 -
E4     4-       q     d        -           -
measure 57
E4     4        q     d                    -
D4     2        e     d  [                 -
C#4    2        e     d  ]                 -
B3     4        q     d                    -
F#4    4-       q     d        -           -
measure 58
F#4    4        q     d                    -
E4     4        q     d                    -
F#4    4        q     d                    men,
C#4    4-       q     d        -           A-
measure 59
C#4    2        e     u  [                 -
B3     2        e     u  =                 -
A#3    2        e     u  =                 -
G#3    2        e     u  ]                 -
F#3    8        h     u                    -
measure 60
C#4    4        q     d                    men,
rest   4        q
rest   8        h
measure 61
F#4    6        q.    d                    A-
E4     2        e     d                    -
D#4    2        e     d  [                 -
C#4    2        e     d  ]                 -
B3     4        q     d                    -
measure 62
E4     6        q.    d                    -
D4     2        e     d         +          -
C#4    2        e     d  [                 -
B3     2        e     d  ]                 -
A3     4        q     u                    men,
measure 63
rest   4        q
D4     4-       q     d        -           A-
D4     2        e     d  [                 -
C#4    2        e     d  ]                 -
B3     4        q     d                    -
measure 64
E4     6        q.    d                    -
D4     2        e     d                    -
C#4    2        e     d  [                 -
B3     2        e     d  ]                 -
A3     2        e     d  [                 -
B3     1        s     d  =[                -
C#4    1        s     d  ]]                -
measure 65
D4     6        q.    d                    -
C4     2        e     d                    -
B3     4        q     d                    -
B3     4        q     d                    men,
measure 66
E4     6        q.    d                    A-
D4     2        e     d                    -
C4     2        e     d  [                 -
B3     2        e     d  ]                 -
A3     4-       q     u        -           -
measure 67
A3     4        q     u                    -
B3     2        e     d  [                 -
C4     2        e     d  ]                 -
D4     4        q     d                    men,
rest   4        q
measure 68
rest   4        q
G3     4-       q     u        -           A-
G3     2        e     u  [                 -
A3     2        e     u  =                 -
B3     2        e     u  =                 -
C#4    2        e     u  ]      +          -
measure 69
D4     6        q.    d                    -
C#4    1        s     d  [[                -
B3     1        s     d  ]]                -
A3     2        e     d  [                 -
B3     2        e     d  =                 -
C#4    2        e     d  =                 -
D4     2        e     d  ]                 -
measure 70
E4     6        q.    d                    -
D4     1        s     d  [[                -
C#4    1        s     d  ]]                -
B3     4        q     d                    -
F#4    4        q     d                    -
measure 71
E4     8        h     d                    men,
rest   8        h
measure 72
E4     6        q.    d                    A-
D4     2        e     d                    -
C#4    4        q     d                    -
F#4    4-       q     d        -           -
measure 73
F#4    2        e     d  [                 -
E4     2        e     d  =                 -
D4     2        e     d  =                 -
C#4    2        e     d  ]                 -
B3     4        q     d                    -
E4     4-       q     d        -           -
measure 74
E4     2        e     d  [                 -
D4     2        e     d  =                 -
C#4    2        e     d  =                 -
B3     2        e     d  ]                 -
A3     2        e     d  [                 -
B3     1        s     d  =[                -
C#4    1        s     d  ]]                -
D4     4        q     d                    men,
measure 75
D4    12        h.    d                    A-
C#4    4        q     d                    men,
measure 76
D4     8        h     d                    A-
C#4    4        q     d                    men,
E4     4-       q     d        -           A-
measure 77
E4     2        e     d  [                 -
D4     2        e     d  =                 -
C#4    2        e     d  =                 -
B3     2        e     d  ]                 -
A3     4        q     u                    -
D4     4-       q     d        -           -
measure 78
D4     4        q     d                    -
C#4    4        q     d                    -
F#4    8        h     d                    -
measure 79
E4     4        q     d                    -
D4     4        q     d                    -
E4     8        h     d                    -
measure 80
F#4    8        h     d                    men,
rest   8        h
measure 81
rest   4        q
A4     4-       q     d        -           A-
A4     2        e     d  [                 -
G4     2        e     d  ]                 -
F#4    2        e     d  [                 men,_
E4     2        e     d  ]                 _
measure 82
D4    12        h.    d                    A-
D4     4        q     d                    men,
measure 83
D4     4        q     d                    A-
E4     8        h     d                    -
E4     4        q     d                    men,
measure 84
E4     8        h     d                    A-
E4     8        h     d                    men,
measure 85
rest  16                        F
measure 86
$ D:Adagio
D4     8        h     d                    A-
F#4    8        h     d                    men,
measure 87
E4    16        w     d                    A-
measure 88
F#4   32        b     d                    men.
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 10
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/10} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:bf7f245da81f3e43f366e3233c94a74d]
06/27/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 10 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro moderato
D3     6        q.    d                    A-
E3     2        e     d                    -
F#3    2        e     d  [                 -
G3     2        e     d  =                 -
A3     2        e     d  =                 -
E3     2        e     d  =                 -
measure 2
F#3    2        e     d  ]                 -
D3     2        e     d                    men,
B3     8        h     d                    A-
A3     4        q     d                    -
measure 3
D3     4        q     d                    -
G3     8        h     d                    -
F#3    4        q     d                    -
measure 4
B3     6        q.    d                    -
B3     2        e     d                    men,
C#4    2        e     d  [                 A-
A3     2        e     d  ]                 -
D4     4-       q     d        -           -
measure 5
D4     4        q     d                    -
C#4    4        q     d                    -
D4     4        q     d                    -
F#3    2        e     d  [                 -
E3     2        e     d  ]                 -
measure 6
D3     2        e     d  [                 -
E3     2        e     d  =                 -
F#3    2        e     d  =                 -
G#3    2        e     d  ]                 -
A3     4        q     d                    -
A2     4        q     u                    men,
measure 7
rest   4        q
A3     4        q     d         i          A-
G#3    4        q     d         i          -
C#4    4        q     d         i          -
measure 8
rest   4        q
F#3    4        q     d         i          -
E3     4        q     d         i          -
A3     4        q     d         i          -
measure 9
rest   4        q
D3     8        h     u                    -
C#3    4        q     u                    men,
measure 10
B2     8        h     u                    A-
A2     4        q     u                    men,
rest   4        q
measure 11
rest  16
measure 12
rest   4        q
D3     4        q     d                    A-
C#3    4        q     u                    -
F#3    4        q     d                    men,
measure 13
rest  16
measure 14
rest   4        q
G3     8        h     d                    A-
F#3    4        q     d                    men,
measure 15
E3     8        h     d                    A-
D3     4        q     d                    men,
D3     2        e     d  [                 A-
E3     2        e     d  ]                 -
measure 16
F#3    4        q     d                    -
D3     4        q     d                    men,
A3     4        q     d                    A-
A2     4        q     u                    men,
measure 17
rest  16
measure 18
rest  16
measure 19
rest   4        q
D4     8        h     d                    A-
C#4    4        q     d                    men,
measure 20
B3     8        h     d                    A-
A3     8        h     d                    men,
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
D3     6        q.    d                    A-
E3     2        e     d                    -
F#3    2        e     d  [                 -
G3     2        e     d  =                 -
A3     2        e     d  =                 -
E3     2        e     d  =                 -
measure 32
F#3    2        e     d  ]                 -
D3     2        e     d                    men,
B3     8        h     d                    A-
A3     4        q     d                    -
measure 33
D3     4        q     d                    -
G3     8        h     d                    -
F#3    4        q     d                    -
measure 34
B3     6        q.    d                    -
B3     2        e     d                    men,
C#4    2        e     d  [                 A-
A3     2        e     d  ]                 -
D4     4-       q     d        -           -
measure 35
D4     4        q     d                    -
C#4    4        q     d                    -
D4     8        h     d                    men,
measure 36
rest  16
measure 37
rest  16
measure 38
A2     6        q.    u                    A-
B2     2        e     u                    -
C#3    2        e     u  [                 -
D3     2        e     u  =                 -
E3     2        e     u  =                 -
B2     2        e     u  =                 -
measure 39
C#3    2        e     u  ]                 -
A2     2        e     u                    men,
F#3    8        h     d                    A-
E3     4        q     d                    -
measure 40
A2     4        q     u                    -
D3     8        h     u                    -
C#3    4        q     u                    -
measure 41
F#3    6        q.    d                    -
F#3    2        e     d                    men,
G#3    2        e     d  [                 A-
E3     2        e     d  ]                 -
A3     4-       q     d        -           -
measure 42
A3     4        q     d                    -
G#3    4        q     d                    -
A3     4        q     d                    men,
rest   4        q
measure 43
rest   4        q
E3     4-       q     d        -           A-
E3     2        e     d  [                 -
F#3    2        e     d  =                 -
G3     2        e     d  =      +          -
A3     2        e     d  ]                 -
measure 44
B3     6        q.    d                    -
A3     1        s     d  [[                -
G3     1        s     d  ]]                -
F#3    2        e     d  [                 -
G3     2        e     d  ]                 -
A3     4-       q     d        -           -
measure 45
A3     2        e     d  [                 -
B3     2        e     d  ]                 -
C#4    4        q     d                    -
D4     4        q     d                    men,
rest   4        q
measure 46
rest   4        q
A2     4-       q     u        -           A-
A2     2        e     u  [                 -
B2     2        e     u  =                 -
C#3    2        e     u  =                 -
D3     2        e     u  ]                 -
measure 47
E3     6        q.    d                    -
D3     1        s     u  [[                -
C#3    1        s     u  ]]                -
B2     2        e     u  [                 -
C#3    2        e     u  =                 -
D3     2        e     u  =                 -
E3     2        e     u  ]                 -
measure 48
F#3    2        e     d  [                 -
E3     2        e     d  ]                 -
D3     2        e     d  [                 -
E3     1        s     d  =[                -
F#3    1        s     d  ]]                -
G3     2        e     d  [                 -
F#3    2        e     d  ]                 -
E3     2        e     d  [                 -
F#3    1        s     d  =[                -
G3     1        s     d  ]]                -
measure 49
A3     2        e     d  [                 -
G3     2        e     d  =                 -
F#3    2        e     d  =                 -
E3     2        e     d  ]                 -
D3     4        q     d                    -
E3     4        q     d                    -
measure 50
A2     2        e     d  [                 -
A3     2        e     d  =                 -
B3     2        e     d  =                 -
A3     2        e     d  ]                 -
G3     2        e     d  [                 -
E3     2        e     d  =                 -
A3     2        e     d  =                 -
G3     2        e     d  ]                 -
measure 51
F#3    2        e     d  [                 -
E3     2        e     d  ]                 -
D3     4        q     d                    men,
rest   8        h
measure 52
rest  16
measure 53
rest  16
measure 54
rest   4        q
C#4    4        q     d         i          A-
F#3    4        q     d         i          -
B3     4        q     d         i          -
measure 55
G#3    4        q     d                    -
A3     4        q     d                    men,
E3     6        q.    d                    A-
D3     2        e     d                    -
measure 56
C#3    2        e     u  [                 -
B2     2        e     u  ]                 -
A2     4        q     u                    men,
A3     6        q.    d                    A-
G3     2        e     d                    -
measure 57
F#3    4        q     d                    -
A#3    4        q     d                    -
B3     6        q.    d                    -
A3     2        e     d                    -
measure 58
G3     8        h     d                    -
F#3    4        q     d                    men,
rest   4        q
measure 59
F#3    6        q.    d                    A-
E3     2        e     d                    -
D3     8        h     d                    -
measure 60
C#3    4        q     u                    men,
rest   4        q
C#4    6        q.    d                    A-
B3     2        e     d                    -
measure 61
A#3    2        e     d  [                 -
G#3    2        e     d  ]                 -
F#3    4        q     d                    -
B3     6        q.    d                    -
A3     2        e     d                    -
measure 62
G#3    2        e     d  [                 -
F#3    2        e     d  ]                 -
E3     4        q     d                    -
A3     6        q.    d                    -
G3     2        e     d                    -
measure 63
F#3    2        e     d  [                 -
E3     2        e     d  ]                 -
D3     4        q     d                    men,
rest   8        h
measure 64
rest   8        h
A3     6        q.    d                    A-
G3     2        e     d                    -
measure 65
F#3    4        q     d                    -
B3     4-       q     d        -           -
B3     2        e     d  [                 -
A3     2        e     d  =                 -
G3     2        e     d  =                 -
F#3    2        e     d  ]                 -
measure 66
E3     4        q     d                    -
A3     4-       q     d        -           -
A3     2        e     d  [                 -
G3     2        e     d  =                 -
F#3    2        e     d  =                 -
E3     2        e     d  ]                 -
measure 67
D3     4        q     d                    men,
rest   4        q
D4     6        q.    d                    A-
C4     2        e     d                    men,
measure 68
B3     2        e     d  [                 A-
A3     2        e     d  ]                 -
G3     4        q     d                    men,
rest   4        q
D3     4-       q     d        -           A-
measure 69
D3     2        e     d  [                 -
E3     2        e     d  =                 -
F#3    2        e     d  =                 -
G3     2        e     d  ]                 -
A3     6        q.    d                    -
G3     1        s     d  [[                -
F#3    1        s     d  ]]                -
measure 70
E3     2        e     d  [                 -
F#3    2        e     d  =                 -
G3     2        e     d  =                 -
A3     2        e     d  ]                 -
B3     2        e     d  [                 -
C#4    2        e     d  ]                 -
D4     4-       q     d        -           -
measure 71
D4     4        q     d                    -
C#4    4        q     d                    men,
B3     8        h     d                    A-
measure 72
A3     4        q     d                    men,
rest   4        q
A3     6        q.    d                    A-
G3     2        e     d                    -
measure 73
F#3    4        q     d                    -
B3     4-       q     d        -           -
B3     2        e     d  [                 -
A3     2        e     d  =                 -
G3     2        e     d  =                 -
F#3    2        e     d  ]                 -
measure 74
E3     2        e     d  [                 -
F#3    1        s     d  =[                -
G3     1        s     d  ]]                -
A3     4-       q     d        -           -
A3     2        e     d  [                 -
G3     2        e     d  =                 -
F#3    2        e     d  =                 -
E3     2        e     d  ]                 -
measure 75
D3     2        e     u  [                 -
C#3    2        e     u  ]                 -
B2     4        q     u                    -
A2     8        h     u                    men,
measure 76
D3     2        e     d  [                 A-
E3     2        e     d  =                 -
F#3    2        e     d  =                 -
G3     2        e     d  ]                 -
A3     8-       h     d        -           -
measure 77
A3    16-       w     d        -           -
measure 78
A3    16-       w     d        -           -
measure 79
A3     4        q     d                    -
D3     4        q     d                    -
A3     8        h     d                    -
measure 80
D3     8        h     d                    men,
D4     8-       h     d        -           A-
measure 81
D4     8        h     d                    -
C4     8        h     d                    men,
measure 82
B3    12        h.    d                    A-
F#3    4        q     d                    men,
measure 83
G3    12        h.    d                    A-
G3     4        q     d                    men,
measure 84
G3     8        h     d                    A-
G3     8        h     d                    men,
measure 85
rest  16                        F
measure 86
$ D:Adagio
F#3    8        h     d                    A-
D3     8        h     d                    men,
measure 87
A3    16        w     d                    A-
measure 88
D3    32        b     d                    men.
mheavy4 89
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 11
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-10/11} [KHM:3020451825]
TIMESTAMP: DEC/26/2001 [md5sum:4bf2d8eb2611ec05c9a398e380b91786]
06/27/90 E. Correia
WK#:56        MV#:3,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 11 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro moderato
*               D       Tasto solo
D3     6        q.    d
E3     2        e     d
F#3    2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  ]
measure 2
F#3    2        e     d  [
D3     2        e     d  ]
B3     8        h     d
A3     4        q     d
measure 3
D3     4        q     d
G3     8        h     d
F#3    4        q     d
measure 4
B3     6        q.    d
B3     2        e     d
C#4    2        e     d  [
A3     2        e     d  ]
D4     4-       q     d        -
measure 5
D4     4        q     d
C#4    4        q     d
D4     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 6
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G#3    2        e     d  ]
A3     4        q     d
A2     4        q     u
measure 7
rest   4        q
f1              6
A2     4        q     u
f1              7
G#2    4        q     u
C#3    4        q     u
measure 8
rest   4        q
F#3    4        q     d
E3     4        q     d
A3     4        q     d
measure 9
rest   4        q
D3     8        h     d
C#3    4        q     u
measure 10
B2     8        h     u
A2     4        q     u
rest   4        q
$ C:13
measure 11
F#3    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
D4     4        q     d
C#4    4        q     d
measure 12
D4     4        q     d
$ C:22
f1              6
D3     4        q     d
f1              7
C#3    4        q     u
F#3    4        q     d
$ C:12
measure 13
rest   4        q
B3     4        q     d
A3     4        q     d
D4     4        q     d
measure 14
G3     4        q     u
$ C:22
f1     4        3
f2              4 2
G3     8        h     d
f1              6
F#3    4        q     d
measure 15
f1     4        7
f1              6
E3     8        h     d
D3     6        q.    d
E3     2        e     d
measure 16
F#3    4        q     d
D3     4        q     d
A3     4        q     d
A2     4        q     u
$ C:15
measure 17
E4     4        q     d
$ C:12
A3     4        q     u
f1              7
G#3    4        q     u
f1              7
C#4    4        q     u
$ C:15
measure 18
rest   4        q
F#4    4        q     d
E4     4        q     d
A4     4        q     d
measure 19
F#4    4        q     u
$ C:22
D3     8        h     u
C#3    4        q     u
measure 20
f1     4        7
f1              6+
B2     8        h     u
A2     8        h     u
$ C:4
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
A4     6        q.    d
B4     2        e     d
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  ]
measure 27
C#5    2        e     d  [
A4     2        e     d  ]
F#5    8        h     d
E5     4        q     d
measure 28
A4     4        q     d
D5     8        h     d
C#5    4        q     d
measure 29
F#5    6        q.    d
G#5    1        s     d  [[
F#5    1        s     d  ]]
G#5    2        e     d  [
E5     2        e     d  ]
A5     4-       q     d        -
measure 30
A5     2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -+
G5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
$ C:22
measure 31
D3     6        q.    d
E3     2        e     d
F#3    2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  ]
measure 32
F#3    2        e     d  [
D3     2        e     d  ]
f1     4        3
f2              4 2
B3     8        h     d
f1              6
A3     4        q     d
measure 33
D3     4        q     d
f1     4        3
f2              4 2
G3     8        h     d
f1              5
F#3    4        q     d
measure 34
f2     4        9 7
f2              8 6
B3     6        q.    d
B3     2        e     d
f2              6 5
C#4    2        e     d  [
A3     2        e     d  ]
f1              3
D4     4-       q     d        -
measure 35
f2              4 2
D4     4        q     d
f1              6
C#4    4        q     d
D4     6        q.    d
$ C:4
rest   2        e
measure 36
rest   8        h
rest   4        q
rest   2        e
C#5    2        e     d
measure 37
D5     2        e     d  [
B4     2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
C#5    2        e     d  [
A4     2        e     d  =
F#5    2        e     d  =
G#5    2        e     d  ]
$ C:22
measure 38
A2     6        q.    u
B2     2        e     u
C#3    2        e     u  [
D3     2        e     u  =
E3     2        e     u  =
B2     2        e     u  ]
measure 39
C#3    2        e     u  [
A2     2        e     u  ]
F#3    8        h     d
E3     4        q     d
measure 40
A2     4        q     u
D3     8        h     u
C#3    4        q     u
measure 41
F#3    6        q.    d
F#3    2        e     d
G#3    2        e     d  [
E3     2        e     d  ]
A3     4-       q     d        -
measure 42
A3     4        q     d
G#3    4        q     d
A3     4        q     d
$ C:12
A3     4-       q     d        -
measure 43
A3     2        e     d  [
B3     2        e     d  ]
$ C:22
E3     4-       q     d        -
E3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  =      +
A3     2        e     d  ]
measure 44
B3     6        q.    d
A3     1        s     d  [[
G3     1        s     d  ]]
F#3    2        e     d  [
G3     2        e     d  ]
A3     4-       q     d        -
measure 45
A3     2        e     d  [
B3     2        e     d  ]
C#4    4        q     d
D4     4        q     d
D3     4-       q     d        -
measure 46
D3     2        e     d  [
E3     2        e     d  ]
A2     4-       q     u        -
A2     2        e     u  [
B2     2        e     u  =
C#3    2        e     u  =
D3     2        e     u  ]
measure 47
E3     6        q.    d
D3     1        s     u  [[
C#3    1        s     u  ]]
B2     2        e     u  [
C#3    2        e     u  =
D3     2        e     u  =
E3     2        e     u  ]
measure 48
F#3    2        e     d  [
E3     2        e     d  ]
D3     2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
G3     2        e     d  [
F#3    2        e     d  ]
E3     2        e     d  [
F#3    1        s     d  =[
G3     1        s     d  ]]
measure 49
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  ]
D3     4        q     d
E3     4        q     d
measure 50
A2     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
G3     2        e     d  [
E3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
measure 51
F#3    2        e     d  [
E3     2        e     d  ]
D3     4        q     d
$ C:13
D4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
G4     2        e     d  ]
$ C:12
measure 52
f1     4        5
f1              6
D3     6        q.    u
E3     2        e     u
f1              4
F#3    2        e     u  [
G3     2        e     u  =
f1              8
A3     2        e     u  =
F#3    2        e     u  ]
measure 53
f1     4        7
f1              6
B3     6        q.    d
C#4    1        s     d  [[
B3     1        s     d  ]]
C#4    2        e     d  [
A3     2        e     d  ]
D4     4-       q     d        -
measure 54
D4     4        q     d
$ C:22
C#4    4        q     d
F#3    4        q     d
B3     4        q     d
measure 55
G#3    4        q     d
A3     4        q     d
E3     6        q.    d
D3     2        e     d
measure 56
C#3    2        e     u  [
B2     2        e     u  ]
A2     4        q     u
A3     6        q.    d
G3     2        e     d
measure 57
F#3    4        q     d
A#3    4        q     d
B3     6        q.    d
A3     2        e     d
measure 58
f1     4        7
f1              6
G3     8        h     d
f1     4        4
f1              #
F#3    8        h     d
measure 59
F#3    6        q.    d
E3     2        e     d
D3     8        h     d
measure 60
f2              7 #
C#3    4        q     u
f3              7 5 3
B2     4        q     u
f1     4        4
f1              #
C#3    8        h     u
measure 61
f1              #
F#2    4        q     u
F#3    4        q     d
f1              #
B3     6        q.    d
A3     2        e     d         +
measure 62
G#3    2        e     d  [
F#3    2        e     d  ]
E3     4        q     d
A3     6        q.    d
G3     2        e     d
measure 63
F#3    2        e     d  [
E3     2        e     d  ]
D3     4        q     d
$ C:12
D4     2        e     d  [
C#4    2        e     d  ]
B3     4        q     d
measure 64
E4     6        q.    d
D4     2        e     d
$ C:22
A3     6        q.    d
G3     2        e     d
measure 65
F#3    4        q     d
B3     4-       q     d        -
B3     2        e     d  [
f1              n
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 66
E3     4        q     d
f1              n
A3     4-       q     d        -
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  ]
measure 67
D3     8        h     d
D4     6        q.    d
C4     2        e     d
measure 68
B3     2        e     d  [
A3     2        e     d  ]
G3     8        h     d
D3     4-       q     d        -
measure 69
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G3     2        e     d  ]
A3     6        q.    d
G3     1        s     d  [[
F#3    1        s     d  ]]
measure 70
E3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
B3     2        e     d  [
C#4    2        e     d  ]
D4     4-       q     d        -
measure 71
D4     4        q     d
C#4    4        q     d
B3     8        h     d
measure 72
A3     8        h     d
A3     6        q.    d
G3     2        e     d
measure 73
F#3    4        q     d
B3     4-       q     d        -
B3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 74
E3     2        e     d  [
F#3    1        s     d  =[
G3     1        s     d  ]]
A3     4-       q     d        -
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  ]
measure 75
D3     2        e     u  [
C#3    2        e     u  ]
B2     4        q     u
f2     4        6 4
f2              5 3
A2     8        h     u
measure 76
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G3     2        e     d  ]
A3     8-       h     d        -
measure 77
A3    16-       w     d        -
measure 78
A3    16-       w     d        -
measure 79
A3     4        q     d
D3     4        q     d
A3     8        h     d
measure 80
D3    16-       w     u        -
measure 81
D3     8        h     u
C3     8        h     u
measure 82
B2     4        q     u
B3     8        h     d
F#3    4        q     d
measure 83
G3    16        w     d
measure 84
f2              4 2
G3    16        w     d
measure 85
rest  16                        F
measure 86
$ D:Adagio
F#3    8        h     d
D3     8        h     d
measure 87
f1              4
A3     8        h     d
f1              3
A2     8        h     u
measure 88
D2    32        b     u
mheavy4 89
/END
/eof
