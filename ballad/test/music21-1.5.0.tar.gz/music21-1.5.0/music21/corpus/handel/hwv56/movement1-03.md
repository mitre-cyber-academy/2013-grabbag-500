&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-03/1} [KHM:1572633547]
TIMESTAMP: DEC/26/2001 [md5sum:801309b42e49edddcb2a4bdb2bc23d4d]
04/04/90 E. Correia
WK#:56        MV#:1,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino I
1 19
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:4   D:Andante
E5     4        q     d
F#5    4        q     d
G#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4-       q     d        -
measure 2
B5     2        e     d  [
A5     1        s     d  =[
G#5    1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
D#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4-       q     d        -
measure 3
B5     2        e     d  [
A5     1        s     d  =[
G#5    1        s     d  ]]
F#5    3        e.    d  [
E5     1        s     d  ]\
D#5    1        s     d  [[
C#5    1        s     d  =]
B4     2        e     d  ]
rest   2        e
E5     2        e     d
measure 4
F#5    2        e     d  [      t&(
E5     2        e     d  =      &)
F#5    2        e     d  =      t&(
E5     2        e     d  ]      &)
F#5    2        e     d  [      t&(
E5     2        e     d  ]      &)
rest   2        e
G#5    2        e     d
measure 5
A5     2        e     d  [      t&(
G#5    2        e     d  =      &)
A5     2        e     d  =      t&(
G#5    2        e     d  ]      &)
A5     2        e     d  [      t&(
G#5    2        e     d  ]      &)
rest   2        e
B5     2        e     d         p
measure 6
C#6    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
C#6    2        e     d  [      (
B5     2        e     d  =
C#6    2        e     d  =      )
F#5    2        e     d  ]      fi
measure 7
G#5    3        e.    d  [
A5     1        s     d  ]\
F#5    4        q     d         t
E5     4        q     d
rest   2        e
B4     2        e     u         p
measure 8
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
C#5    2        e     d  [      (
B4     2        e     d  =
C#5    2        e     d  =      )
F#4    2        e     u  ]      fi
measure 9
G#4    3        e.    u  [
A4     1        s     u  ]\
F#4    4        q     u         t
E4     4        q     u
rest   4        q
measure 10
rest  16
measure 11
E5     4        q     d         &f
F#5    4        q     d
G#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4        q     d
measure 12
rest  16
measure 13
rest   8        h
rest   2        e
B4     2        e     u         p
E5     4-       q     d        -
measure 14
E5     2        e     d  [
D#5    1        s     d  =[
C#5    1        s     d  ]]
B4     2        e     d  [
F#5    2        e     d  ]
G#5    1        s     d  [[
F#5    1        s     d  =]
E5     2        e     d  ]
rest   4        q
measure 15
rest   8        h
rest   2        e
B4     2        e     u
E5     4        q     d
measure 16
rest   2        e
D#5    2        e     d
F#5    4        q     d
rest   2        e
E5     2        e     d
G#5    4        q     d
measure 17
rest   2        e
F#5    2        e     d
A5     4        q     d
rest   2        e
F#5    2        e     d
B5     4        q     d
measure 18
rest   2        e
B4     2        e     u
A4     4        q     u
rest   2        e
B4     2        e     u
F#5    4        q     d
measure 19
E5     4        q     d
F#5    4        q     d
G#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4        q     d
measure 20
rest   8        h
rest   2        e
F#5    2        e     d  [
G#5    2        e     d  =      (
F#5    2        e     d  ]      )
measure 21
G#5    2        e     d  [      (
F#5    2        e     d  ]      )
rest   4        q
rest   2        e
G#4    2        e     u
C#5    4        q     d
measure 22
rest   2        e
C#5    2        e     d
D#5    4        q     d
rest   2        e
D#5    2        e     d
E5     4        q     d
measure 23
rest   2        e
C#5    2        e     d
F#5    4        q     d
rest   8        h
measure 24
B4     4        q     u
C#5    4        q     d
D#5    3        e.    d  [      (
F#5    1        s     d  ]\     )
F#5    4        q     d
measure 25
rest  16
measure 26
rest   2        e
C#5    2        e     d  [
D#5    2        e     d  =      (
C#5    2        e     d  ]      )
D#5    2        e     d  [      (
C#5    2        e     d  =      )
D#5    2        e     d  =      (
C#5    2        e     d  ]      )
measure 27
D#5    2        e     d  [      (
C#5    2        e     d  ]      )
rest   4        q
rest   8        h
measure 28
rest   4        q
rest   2        e
B5     2        e     d
C#6    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
measure 29
B5     6        q.    d
F#5    2        e     d
G#5    2        e     d  [      (
F#5    2        e     d  =      )
G#5    2        e     d  =      (
F#5    2        e     d  ]      )
measure 30
G#5    2        e     d  [      (
F#5    2        e     d  =      )
G#5    2        e     d  =      (
F#5    2        e     d  ]      )
E5     2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      (
D#5    2        e     d  ]      )
measure 31
C#5    4        q     d
rest   4        q
A#5    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
measure 32
A#5    4        q     d
rest   4        q
A#4    2        e     u  [      (
B4     2        e     u  =      )
C#5    2        e     u  =      (
B4     2        e     u  ]      )
measure 33
A#4    2        e     u  [      (
B4     2        e     u  =
C#5    2        e     u  =      )
F#4    2        e     u  ]
D#4    4        q     u
rest   2        e
C#5    2        e     d
measure 34
D#5    2        e     d  [      (
G#5    2        e     d  =
F#5    2        e     d  =      )
A#4    2        e     d  ]
B4     4        q     u
rest   2        e
C#4    2        e     u
measure 35
B3     4        q     u
B4     4-       q     u        -
B4     2        e     d  [
B4     2        e     d  =
A#4    2        e     d  =
E5     2        e     d  ]
measure 36
D#5    2        e     d  [      (
D#5    2        e     d  =
D#5    2        e     d  =
D#5    2        e     d  ]      )
G#5    2        e     d  [      (
G#5    2        e     d  =
G#5    2        e     d  =
G#5    2        e     d  ]      )
measure 37
G#5    2        e     d  [      (
G#5    2        e     d  =
G#5    2        e     d  =
G#5    2        e     d  ]      )
F#5    2        e     d  [      (
F#5    2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]      )
measure 38
F#5    2        e     d  [      (
F#5    2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]      )
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
measure 39
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
measure 40
E5     4        q     d
D#5    4        q     d
rest   8        h
measure 41
rest   2        e
F#4    2        e     u  [      p
G#4    2        e     u  =      (
F#4    2        e     u  ]      )
G#4    2        e     u  [      (
F#4    2        e     u  =      )
G#4    2        e     u  =      (
F#4    2        e     u  ]      )
measure 42
G#5    2        e     d  [      (
F#5    2        e     d  =      )
G#5    2        e     d  =      (
F#5    2        e     d  ]      )
G#5    2        e     d  [      (
F#5    2        e     d  =
G#5    2        e     d  =      )
C#5    2        e     d  ]      i&f
measure 43
D#5    3        e.    d  [
E5     1        s     d  ]\
C#5    4        q     d         &t
B4     4        q     u
rest   4        q
measure 44
rest  16
measure 45
E5     4        q     d         f
G#5    4        q     d         &t
A5     4        q     d
A4     4        q     u
measure 46
rest   8        h
rest   4        q
rest   2        e
G#5    2        e     d
measure 47
A5     4        q     d
rest   4        q
rest   4        q
rest   2        e
G#5    2        e     d
measure 48
A5     4        q     d
rest   4        q
rest   4        q
rest   2        e
G#5    2        e     d
measure 49
A5     4        q     d
rest   4        q
rest   2        e
B4     2        e     u
E5     4        q     d
measure 50
rest   2        e
A4     2        e     u
D5     4        q     d
rest   2        e
B4     2        e     d
E5     4        q     d
measure 51
rest  16
measure 52
A4     4        q     u
B4     4        q     u
C#5    3        e.    d  [      (
E5     1        s     d  ]\     )
E5     4        q     d
measure 53
rest  16
measure 54
E5     4        q     d
F#5    4        q     d
G#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4        q     d
measure 55
rest  16
measure 56
B4     4        q     u
rest   4        q
E5     4        q     d
rest   4        q
measure 57
rest  16
measure 58
C#5    4        q     d
rest   4        q
rest   2        e
F#5    2        e     d  [
B5     2        e     d  =
D#5    2        e     d  ]
measure 59
E5     4        q     d
E4     4        q     u
F#5    4        q     d
B4     4        q     u
measure 60
rest   8        h
rest   4        q
rest   2        e
B4     2        e     u         p
measure 61
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
C#5    2        e     d  [      (
B4     2        e     d  ]      )
rest   4        q
measure 62
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d
measure 63
F#5    2        e     d  [      (
E5     2        e     d  =      )
F#5    2        e     d  =      (
E5     2        e     d  ]      )
E5     8-       h     d        -
measure 64
E5     6        q.    d
E5     2        e     d
D#5    2        e     d  [      (
F#5    2        e     d  ]      )
A4     4        q     u
measure 65
G#4    4        q     u
G#4    8        h     u
F#4    2        e     u  [
E4     2        e     u  ]
measure 66
F#4    2        e     u  [
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
D#5    2        e     d  [      (
E5     2        e     d  =      )
F#5    2        e     d  =      (
E5     2        e     d  ]      )
measure 67
D#5    2        e     d  [      (
E5     2        e     d  =      )
F#5    2        e     d  =      (
E5     2        e     d  ]      )
D#5    2        e     d  [      (
E5     2        e     d  =      )
F#5    2        e     d  =      (
E5     2        e     d  ]      )
measure 68
D#5    4        q     d
E5     4        q     d
rest   8        h
measure 69
rest  16
measure 70
rest   2        e
B5     2        e     d  [      p
C#6    2        e     d  =      (
B5     2        e     d  ]      )
C#6    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
measure 71
C#6    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
C#6    2        e     d  [      (
B5     2        e     d  =
C#6    2        e     d  =      )
F#5    2        e     d  ]      fi
measure 72
G#5    3        e.    d  [
A5     1        s     d  ]\
F#5    4        q     d         &t
E5     4        q     d
rest   4        q
measure 73
A#5    4        q     d
rest   4        q
F#5    4        q     d         F
rest   4        q
measure 74
rest  16
measure 75
rest  16
measure 76
E5     4        q     d         f
F#5    4        q     d
G#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4-       q     d        -
measure 77
B5     2        e     d  [
A5     1        s     d  =[
G#5    1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
D#5    3        e.    d  [      (
B5     1        s     d  ]\     )
B5     4-       q     d        -
measure 78
B5     2        e     d  [
A5     1        s     d  =[
G#5    1        s     d  ]]
F#5    3        e.    d  [
E5     1        s     d  ]\
D#5    1        s     d  [[
C#5    1        s     d  =]
B4     2        e     d  ]
rest   2        e
E5     2        e     d
measure 79
F#5    2        e     d  [      t&(
E5     2        e     d  =      &)
F#5    2        e     d  =      t&(
E5     2        e     d  ]      &)
F#5    2        e     d  [      t&(
E5     2        e     d  ]      &)
rest   2        e
G#5    2        e     d
measure 80
A5     2        e     d  [      t&(
G#5    2        e     d  =      &)
A5     2        e     d  =      t&(
G#5    2        e     d  ]      &)
A5     2        e     d  [      t&(
G#5    2        e     d  ]      &)
rest   2        e
B5     2        e     d         p
measure 81
C#6    2        e     d  [      (
B5     2        e     d  =      )
C#6    2        e     d  =      (
B5     2        e     d  ]      )
C#6    2        e     d  [      (
B5     2        e     d  =
C#6    2        e     d  =      )
F#5    2        e     d  ]      fi
measure 82
G#5    3        e.    d  [
A5     1        s     d  ]\
F#5    4        q     d         t
E5     4        q     d
rest   2        e
B4     2        e     u         p
measure 83
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
C#5    2        e     u  [      (
B4     2        e     u  =
C#5    2        e     u  =      )
F#4    2        e     u  ]      fi
measure 84
G#4    3        e.    u  [
A4     1        s     u  ]\
F#4    4        q     u         t
E4     4        q     u         F
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-03/2} [KHM:1572633547]
TIMESTAMP: DEC/26/2001 [md5sum:1de4627140a7121db567d5cad12772a2]
04/04/90 E. Correia
WK#:56        MV#:1,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino II
1 19
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:4   D:Andante
B4     2        e     u
E5     4        q     d
D#5    2        e     d
E5     3        e.    d  [      (
G#5    1        s     d  ]\     )
G#5    4-       q     d        -
measure 2
G#5    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
E5     2        e     d  ]
F#4    3        e.    u  [      (
D#5    1        s     u  ]\     )
D#5    2        e     d  [
F#5    2        e     d  ]
measure 3
B4     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     u  [
G#4    2        e     u  ]
F#4    4        q     u
rest   2        e
B4     2        e     u
measure 4
C#5    2        e     d  [      t&(
B4     2        e     d  =      &)
C#5    2        e     d  =      t&(
B4     2        e     d  ]      &)
C#5    2        e     d  [      t&(
B4     2        e     d  ]      &)
rest   2        e
E5     2        e     d
measure 5
D#5    2        e     d  [      (
E5     2        e     d  =      )
D#5    2        e     d  =      (
E5     2        e     d  ]      )
D#5    2        e     d  [      (
E5     2        e     d  ]      )
rest   2        e
G#5    2        e     d         p
measure 6
A5     2        e     d  [      (
G#5    2        e     d  =      )
A5     2        e     d  =      (
G#5    2        e     d  ]      )
A5     2        e     d  [      (
G#5    2        e     d  =
A5     2        e     d  =      )
D#5    2        e     d  ]      fi
measure 7
E5     2        e     d
E5     4        q     d
D#5    2        e     d
E5     4        q     d
rest   2        e
G#4    2        e     u         p
measure 8
A4     2        e     u  [      (
G#4    2        e     u  =      )
A4     2        e     u  =      (
G#4    2        e     u  ]      )
A4     2        e     u  [      (
G#4    2        e     u  =
A4     2        e     u  =      )
D#4    2        e     u  ]      fi
measure 9
E4     2        e     u
E4     4        q     u
D#4    2        e     u
E4     4        q     u
rest   4        q
measure 10
rest  16
measure 11
B4     2        e     u         &f
E5     4        q     d
D#5    2        e     d
E5     3        e.    d  [      (
G#5    1        s     d  ]\     )
G#5    4        q     d
measure 12
rest  16
measure 13
rest   8        h
rest   4        q
rest   2        e
B4     2        e     u         &p
measure 14
F#5    6        q.    d
E5     1        s     d  [[
D#5    1        s     d  ]]
E5     2        e     d  [
B4     2        e     d  ]
rest   4        q
measure 15
rest   8        h
rest   2        e
G#4    2        e     u
B4     4        q     u
measure 16
rest   2        e
A4     2        e     u
D#5    4        q     d
rest   2        e
B4     2        e     u
E5     4        q     d
measure 17
rest   2        e
C#5    2        e     d
F#5    4        q     d
rest   2        e
D#5    2        e     d
F#5    4        q     d
measure 18
rest   2        e
G#4    2        e     u
E4     4        q     u
rest   2        e
F#4    2        e     u
B4     4        q     u
measure 19
B4     2        e     u
E5     4        q     d
D#5    2        e     d
E5     3        e.    d  [      (
G#5    1        s     d  ]\     )
G#5    4        q     d
measure 20
rest   8        h
rest   2        e
D#5    2        e     d  [
E5     2        e     d  =      (
D#5    2        e     d  ]      )
measure 21
E5     2        e     d  [      (
D#5    2        e     d  ]      )
rest   4        q
rest   2        e
E4     2        e     u
G#4    4        q     u
measure 22
rest   2        e
A#4    2        e     u
F#4    4        q     u
rest   2        e
B4     2        e     u
G#4    4        q     u
measure 23
rest   2        e
C#5    2        e     d
A#4    4        q     u
rest   8        h
measure 24
B3     2        e     u
B4     4        q     u
A#4    2        e     u
B4     3        e.    d  [      (
D#5    1        s     d  ]\     )
D#5    4        q     d
measure 25
rest  16
measure 26
rest   2        e
A#4    2        e     u  [
B4     2        e     u  =      (
A#4    2        e     u  ]      )
B4     2        e     u  [      (
A#4    2        e     u  =      )
B4     2        e     u  =      (
A#4    2        e     u  ]      )
measure 27
B4     2        e     u  [      (
A#4    2        e     u  ]      )
rest   4        q
rest   8        h
measure 28
rest   4        q
rest   2        e
D#5    2        e     d
E5     2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      (
D#5    2        e     d  ]      )
measure 29
G#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
D#5    2        e     d
E5     2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      (
D#5    2        e     d  ]      )
measure 30
E5     2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      (
D#5    2        e     d  ]      )
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
measure 31
A#4    4        q     u
rest   4        q
C#5    2        e     u  [      (
B4     2        e     u  =      )
A#4    2        e     u  =      (
B4     2        e     u  ]      )
measure 32
C#5    4        q     d
rest   4        q
C#4    2        e     u  [      (
B3     2        e     u  =      )
A#3    2        e     u  =      (
B3     2        e     u  ]      )
measure 33
C#4    2        e     u  [
B3     2        e     u  =
F#4    2        e     u  =
F#4    2        e     u  ]
F#4    4        q     u
rest   2        e
A#4    2        e     u
measure 34
F#4    2        e     u  [
E4     2        e     u  =
B4     2        e     u  =
C#4    2        e     u  ]
D#4    2        e     u  [
G#4    2        e     u  =
F#4    2        e     u  =
A#3    2        e     u  ]
measure 35
B3     2        e     u  [
E4     2        e     u  =
D#4    2        e     u  =
G#4    2        e     u  ]
F#4    2        e     u  [
F#4    2        e     u  =
E4     2        e     u  =
A#4    2        e     u  ]
measure 36
B4     2        e     u  [
B4     2        e     u  =
F#4    2        e     u  =
F#4    2        e     u  ]
G#4    2        e     u  [
G#4    2        e     u  =
G#4    2        e     u  =
G#4    2        e     u  ]
measure 37
C#5    2        e     d  [
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]
C#5    2        e     u  [
C#5    2        e     u  =
F#4    2        e     u  =
F#4    2        e     u  ]
measure 38
B4     2        e     u  [
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]
B4     2        e     u  [
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]
measure 39
C#5    2        e     u  [
B4     2        e     u  =
A#4    2        e     u  =
B4     2        e     u  ]
C#5    2        e     u  [
B4     2        e     u  =
A#4    2        e     u  =
B4     2        e     u  ]
measure 40
C#5    4        q     d
B4     4        q     d
rest   8        h
measure 41
rest   2        e
D#4    2        e     u  [      p
E4     2        e     u  =      (
D#4    2        e     u  ]      )
E4     2        e     u  [      (
D#4    2        e     u  =      )
E4     2        e     u  =      (
D#4    2        e     u  ]      )
measure 42
E5     2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      (
D#5    2        e     d  ]      )
E5     2        e     d  [      (
D#5    2        e     d  =
E5     2        e     d  =      )
A#4    2        e     d  ]      if
measure 43
B4     2        e     u
B4     4        q     u
A#4    2        e     u
B4     4        q     u
rest   4        q
measure 44
rest  16
measure 45
G#4    4        q     u         &f
B4     4        q     u
E5     4        q     d
rest   4        q
measure 46
rest   8        h
rest   4        q
rest   2        e
D5     2        e     d
measure 47
E5     4        q     d
rest   4        q
rest   4        q
rest   2        e
B4     2        e     u
measure 48
C#5    4        q     d
rest   4        q
rest   4        q
rest   2        e
B4     2        e     u
measure 49
C#5    4        q     d
rest   4        q
rest   2        e
G#4    2        e     u
B4     4        q     u
measure 50
rest   2        e
D4     2        e     u
F#4    4        q     u
rest   2        e
E4     2        e     u
G#4    4        q     u
measure 51
rest  16
measure 52
E4     2        e     u
A4     4        q     u
G#4    2        e     u
A4     3        e.    d  [      (
C#5    1        s     d  ]\     )
C#5    4        q     d
measure 53
rest  16
measure 54
B4     4        q     d
D#5    4        q     d
E5     3        e.    d  [      (
G#5    1        s     d  ]\     )
G#5    4        q     d
measure 55
rest  16
measure 56
F#4    4        q     u
rest   4        q
B4     4        q     u
rest   4        q
measure 57
rest  16
measure 58
F#4    4        q     u
rest   4        q
rest   2        e
D#5    2        e     d  [
F#5    2        e     d  =
B4     2        e     d  ]
measure 59
A#4    4        q     u
A#4    4        q     u
D#5    4        q     d
F#4    4        q     u
measure 60
rest   8        h
rest   4        q
rest   2        e
G#4    2        e     u         &p
measure 61
A4     2        e     u  [      (
G#4    2        e     u  =      )
A4     2        e     u  =      (
G#4    2        e     u  ]      )
A4     2        e     u  [      (
G#4    2        e     u  ]      )
rest   4        q
measure 62
rest   8        h
rest   4        q
rest   2        e
B4     2        e     u
measure 63
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
C#5    2        e     d  [      (
B4     2        e     d  =      )
C#5    2        e     d  =      (
B4     2        e     d  ]      )
measure 64
C#5    2        e     d  [
E5     2        e     d  ]
F#4    4        q     u
F#4    4        q     u
rest   2        e
D#5    2        e     d
measure 65
E5     2        e     d  [
G#5    2        e     d  ]
B4     4        q     u
A4     6        q.    u
A4     2        e     u
measure 66
A4     6        q.    u
A4     2        e     u
A4     2        e     u  [      (
G#4    2        e     u  =      )
F#4    2        e     u  =      (
G#4    2        e     u  ]      )
measure 67
A4     2        e     u  [      (
G#4    2        e     u  =      )
F#4    2        e     u  =      (
G#4    2        e     u  ]      )
A4     2        e     u  [      (
G#4    2        e     u  =      )
F#4    2        e     u  =      (
G#4    2        e     u  ]      )
measure 68
A4     4        q     u
B4     4        q     u
rest   8        h
measure 69
rest  16
measure 70
rest   2        e
G#5    2        e     d  [      &p
A5     2        e     d  =      (
G#5    2        e     d  ]      )
A5     2        e     d  [      (
G#5    2        e     d  =      )
A5     2        e     d  =      (
G#5    2        e     d  ]      )
measure 71
A5     2        e     d  [      (
G#5    2        e     d  =      )
A5     2        e     d  =      (
G#5    2        e     d  ]      )
A5     2        e     d  [      (
G#5    2        e     d  =
A5     2        e     d  =      )
D#5    2        e     d  ]      i&f
measure 72
E5     2        e     d
E5     4        q     d
D#5    2        e     d
E5     4        q     d
rest   4        q
measure 73
E5     4        q     d
rest   4        q
D#5    4        q     d         F
rest   4        q
measure 74
rest  16
measure 75
rest  16
measure 76
B4     2        e     u         &f
E5     4        q     d
D#5    2        e     d
E5     3        e.    d  [      (
G#5    1        s     d  ]\     )
G#5    4-       q     d        -
measure 77
G#5    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
E5     2        e     d  ]
F#4    3        e.    u  [      (
D#5    1        s     u  ]\     )
D#5    2        e     d  [
F#5    2        e     d  ]
measure 78
B4     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     u  [
G#4    2        e     u  ]
F#4    4        q     u
rest   2        e
B4     2        e     u
measure 79
C#5    2        e     d  [      t&(
B4     2        e     d  =      &)
C#5    2        e     d  =      t&(
B4     2        e     d  ]      &)
C#5    2        e     d  [      t&(
B4     2        e     d  ]      &)
rest   2        e
E5     2        e     d
measure 80
D#5    2        e     d  [      (
E5     2        e     d  =      )
D#5    2        e     d  =      (
E5     2        e     d  ]      )
D#5    2        e     d  [      (
E5     2        e     d  ]      )
rest   2        e
G#5    2        e     d         &p
measure 81
A5     2        e     d  [      (
G#5    2        e     d  =      )
A5     2        e     d  =      (
G#5    2        e     d  ]      )
A5     2        e     d  [      (
G#5    2        e     d  =
A5     2        e     d  =      )
D#5    2        e     d  ]      i&f
measure 82
E5     2        e     d
E5     4        q     d
D#5    2        e     d
E5     4        q     d
rest   2        e
G#4    2        e     u         &p
measure 83
A4     2        e     u  [      (
G#4    2        e     u  =      )
A4     2        e     u  =      (
G#4    2        e     u  ]      )
A4     2        e     u  [      (
G#4    2        e     u  =
A4     2        e     u  =      )
D#4    2        e     u  ]      i&f
measure 84
E4     2        e     u
E4     4        q     u
D#4    2        e     u
E4     4        q     u         F
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-03/3} [KHM:1572633547]
TIMESTAMP: DEC/26/2001 [md5sum:fba6ba89168b20544a9bcdbac9174415]
04/04/90 E. Correia
WK#:56        MV#:1,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Viola
1 19
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:13   D:Andante
G#4    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
B4     4        q     d
rest   2        e
D#4    2        e     d
measure 2
E4     2        e     d  [
G#4    2        e     d  =
A4     2        e     d  =
G#4    2        e     d  ]
B4     4        q     d
rest   2        e
D#4    2        e     d
measure 3
E4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
C#5    2        e     d  ]
B4     2        e     d  [
D#4    2        e     d  ]
rest   2        e
E4     2        e     d
measure 4
C#4    2        e     d  [
E4     2        e     d  ]
rest   2        e
E4     2        e     d
C#4    2        e     d  [
E4     2        e     d  ]
rest   2        e
B4     2        e     d
measure 5
A4     2        e     d  [      (
B4     2        e     d  =      )
A4     2        e     d  =      (
B4     2        e     d  ]      )
A4     2        e     d  [      (
B4     2        e     d  ]      )
rest   4        q
measure 6
rest   8        h
rest   4        q
rest   2        e
B4     2        e     d         &f
measure 7
B4     2        e     d  [
C#5    2        e     d  =
F#4    2        e     d  =
B4     2        e     d  ]
G#4    4        q     d
rest   4        q
measure 8
rest   8        h
rest   4        q
rest   2        e
B3     2        e     u         &f
measure 9
B3     2        e     u  [
C#4    2        e     u  =
F#3    2        e     u  =
B3     2        e     u  ]
G#3    4        q     u
rest   4        q
measure 10
rest  16
measure 11
G#4    2        e     d  [      &f
B4     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
B4     3        e.    d  [      (
E5     1        s     d  ]\     )
E5     4        q     d
measure 12
rest  16
measure 13
rest   8        h
rest   4        q
rest   2        e
G#4    2        e     d         &p
measure 14
C#5    2        e     d  [
C#4    2        e     d  =
D#4    2        e     d  =
B4     2        e     d  ]
B4     1        s     d  [[
A4     1        s     d  =]
G#4    2        e     d  ]
rest   4        q
measure 15
rest   8        h
rest   2        e
E4     2        e     d
G#4    4        q     d
measure 16
rest   2        e
F#4    2        e     d
A4     4        q     d
rest   2        e
G#4    2        e     d
B4     4        q     d
measure 17
rest   2        e
A4     2        e     d
C#5    4        q     d
rest   2        e
B4     2        e     d
D#4    4        q     d
measure 18
rest   2        e
E4     2        e     d
C#4    4        q     u
rest   2        e
D#4    2        e     d
D#4    4        q     d
measure 19
G#4    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
B4     4        q     d
rest   4        q
measure 20
rest   8        h
rest   2        e
B4     2        e     d  [
B4     2        e     d  =
B4     2        e     d  ]
measure 21
B4     2        e     d  [
B3     2        e     d  ]
rest   4        q
rest   2        e
B3     2        e     u
E4     4        q     d
measure 22
rest   2        e
F#4    2        e     d
A#4    4        q     d
rest   2        e
B4     2        e     d
B3     4        q     u
measure 23
rest   2        e
F#4    2        e     d
C#5    4        q     d
rest   8        h
measure 24
F#4    4        q     d
G#4    2        e     d  [
F#4    2        e     d  ]
F#4    4        q     d
rest   4        q
measure 25
rest  16
measure 26
rest   2        e
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  ]      )
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
measure 27
F#4    2        e     d  [
F#4    2        e     d  ]
rest   4        q
rest   8        h
measure 28
rest   8        h
rest   4        q
rest   2        e
B3     2        e     u
measure 29
E4     2        e     d  [
D#4    2        e     d  ]
rest   2        e
B4     2        e     d
B4     2        e     d  [
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]
measure 30
B4     2        e     d  [
B4     2        e     d  ]
rest   2        e
B4     2        e     d
G#4    2        e     d  [
G#4    2        e     d  =
G#4    2        e     d  =
G#4    2        e     d  ]
measure 31
C#4    4        q     u
rest   4        q
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 32
E4     4        q     d
rest   4        q
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 33
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
C#4    2        e     d  ]
B3     4        q     u
rest   2        e
C#4    2        e     u
measure 34
B3     6        q.    u
F#4    2        e     d
F#4    4        q     d
rest   2        e
F#3    2        e     u
measure 35
F#3    2        e     u  [
E3     2        e     u  ]
B3     4-       q     u        -
B3     2        e     u  [
B3     2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
measure 36
F#4    2        e     d  [
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
D#4    2        e     d  [
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]
measure 37
A#3    2        e     u  [
A#3    2        e     u  =
A#3    2        e     u  =
A#3    2        e     u  ]
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
measure 38
D#4    2        e     d  [
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]
B3     2        e     d  [
B3     2        e     d  =
G#4    2        e     d  =
G#4    2        e     d  ]
measure 39
A#4    2        e     d  [
G#4    2        e     d  =
F#4    2        e     d  =
G#4    2        e     d  ]
A#4    2        e     d  [
G#4    2        e     d  =
F#4    2        e     d  =
G#4    2        e     d  ]
measure 40
A#4    4        q     d
B4     4        q     d
rest   8        h
measure 41
rest   2        e
B3     2        e     u  [      (&p
B3     2        e     u  =
B3     2        e     u  ]      )
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 42
B3     4        q     u
rest   4        q
rest   4        q
rest   2        e
F#4    2        e     d         &f
measure 43
F#4    2        e     d  [
G#4    2        e     d  =
C#4    2        e     d  =
F#4    2        e     d  ]
D#4    4        q     d
rest   4        q
measure 44
rest  16
measure 45
B3     4        q     u         &f
E4     4        q     d
E4     4        q     d
rest   4        q
measure 46
rest   8        h
rest   4        q
rest   2        e
B4     2        e     d
measure 47
A4     4        q     d
rest   4        q
rest   4        q
rest   2        e
E4     2        e     d
measure 48
E4     4        q     d
rest   4        q
rest   4        q
rest   2        e
E4     2        e     d
measure 49
E4     4        q     d
rest   4        q
rest   2        e
E4     2        e     d
G#4    4        q     d
measure 50
rest   2        e
F#4    2        e     d
A4     4        q     d
rest   2        e
G#4    2        e     d
B4     4        q     d
measure 51
rest  16
measure 52
E4     4        q     d
E4     4        q     d
E4     3        e.    d  [      (
A4     1        s     d  ]\     )
A4     4        q     d
measure 53
rest  16
measure 54
G#3    4        q     u
B3     4        q     u
E4     4        q     d
rest   4        q
measure 55
rest  16
measure 56
B3     4        q     u
rest   4        q
G#4    4        q     d
rest   4        q
measure 57
rest  16
measure 58
C#4    4        q     u
rest   4        q
rest   2        e
B3     2        e     d  [
B3     2        e     d  =
F#4    2        e     d  ]
measure 59
E4     4        q     d
C#4    4        q     u
B4     4        q     d
B3     4        q     u
measure 60
rest   8        h
rest   4        q
rest   2        e
E4     2        e     d         &p
measure 61
E4     2        e     d  [      (
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]      )
E4     4        q     d
rest   4        q
measure 62
rest   8        h
rest   4        q
rest   2        e
B3     2        e     u
measure 63
A3     2        e     u  [      (
B3     2        e     u  =      )
A3     2        e     u  =      (
B3     2        e     u  ]      )
A3     2        e     u  [
E4     2        e     u  =
A3     2        e     u  =
E4     2        e     u  ]
measure 64
C#4    6        q.    u
C#4    2        e     u
B3     4        q     u
rest   2        e
F#4    2        e     d
measure 65
E4     2        e     d  [
B3     2        e     d  ]
E4     4        q     d
C#4    4        q     u
rest   2        e
C#4    2        e     u
measure 66
D#4    2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
C#4    2        e     d  ]
F#4    2        e     d  [
E4     2        e     d  =
B3     2        e     d  =
E4     2        e     d  ]
measure 67
F#4    2        e     d  [
E4     2        e     d  =
B3     2        e     d  =
E4     2        e     d  ]
F#4    2        e     d  [
E4     2        e     d  =
B3     2        e     d  =
E4     2        e     d  ]
measure 68
F#4    4        q     d
G#4    4        q     d
rest   8        h
measure 69
rest  16
measure 70
rest  16
measure 71
rest   8        h
rest   4        q
rest   2        e
B4     2        e     d         &f
measure 72
B4     2        e     d  [
C#5    2        e     d  =
F#4    2        e     d  =
B4     2        e     d  ]
G#4    4        q     d
rest   4        q
measure 73
C#5    4        q     d
rest   4        q
B4     4        q     d         F
rest   4        q
measure 74
rest  16
measure 75
rest  16
measure 76
G#4    2        e     d  [      &f
B4     2        e     d  =
C#5    2        e     d  =
B4     2        e     d  ]
B4     4        q     d
rest   2        e
D#4    2        e     d
measure 77
E4     2        e     d  [
G#4    2        e     d  =
A4     2        e     d  =
G#4    2        e     d  ]
B4     4        q     d
rest   2        e
D#4    2        e     d
measure 78
E4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
C#5    2        e     d  ]
B4     2        e     d  [
D#4    2        e     d  ]
rest   2        e
E4     2        e     d
measure 79
C#4    2        e     d  [
E4     2        e     d  ]
rest   2        e
E4     2        e     d
C#4    2        e     d  [
E4     2        e     d  ]
rest   2        e
B4     2        e     d
measure 80
A4     2        e     d  [      (
B4     2        e     d  =      )
A4     2        e     d  =      (
B4     2        e     d  ]      )
A4     2        e     d  [      (
B4     2        e     d  ]      )
rest   4        q
measure 81
rest   8        h
rest   4        q
rest   2        e
B4     2        e     d         &f
measure 82
B4     2        e     d  [
C#5    2        e     d  =
F#4    2        e     d  =
B4     2        e     d  ]
G#4    4        q     d
rest   4        q
measure 83
rest   8        h
rest   4        q
rest   2        e
B3     2        e     u         &f
measure 84
B3     2        e     u  [
C#4    2        e     u  =
F#3    2        e     u  =
B3     2        e     u  ]
G#3    4        q     u         F
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-03/4} [KHM:1572633547]
TIMESTAMP: DEC/26/2001 [md5sum:577b466707cebd792e2ce2c25b983d59]
04/04/90 E. Correia
WK#:56        MV#:1,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Tenore
1 19 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:34   D:Andante
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
E4     4        q     u                    Ev'-
F#4    4        q     u                    ry
G#4    3        e.    u  [                 val-
B4     1        s     u  ]\                -
B4     4        q     u                    ley,
measure 11
rest  16
measure 12
G#4    4        q     u                    ev'-
A4     4        q     u                    ry
B4     3        e.    d  [                 val-
E5     1        s     d  ]\                -
E5     4-       q     d        -           ley_
measure 13
E5     2        e     d                    _
D#5    1        s     d  [[                shall_
C#5    1        s     d  ]]                _
B4     2        e     u                    be
A4     2        e     u                    ex-
G#4    1        s     u  [[                al-
F#4    1        s     u  ]]                -
E4     2        e     u                    ted,
rest   4        q
measure 14
rest   8        h
rest   2        e
B4     2        e     u                    shall
E5     4-       q     d        -           be_
measure 15
E5     2        e     d  [                 _
D#5    1        s     d  =[                _
C#5    1        s     d  =]                _
B4     2        e     d  ]                 _
A4     2        e     u                    ex-
G#4    1        s     u  [[                al-
F#4    1        s     u  =]                -
E4     2-       e     u  ]     -           -
E4     1        s     u  [[                -
G#4    1        s     u  ==                -
F#4    1        s     u  ==                -
G#4    1        s     u  ]]                -
measure 16
A4     1        s     u  [[                -
G#4    1        s     u  =]                -
F#4    2-       e     u  ]     -           -
F#4    1        s     u  [[                -
A4     1        s     u  ==                -
G#4    1        s     u  ==                -
A4     1        s     u  ]]                -
B4     1        s     u  [[                -
A4     1        s     u  =]                -
G#4    2-       e     u  ]     -           -
G#4    1        s     u  [[                -
B4     1        s     u  ==                -
A4     1        s     u  ==                -
B4     1        s     u  ]]                -
measure 17
C#5    1        s     d  [[                -
B4     1        s     d  =]                -
A4     2-       e     d  ]     -           -
A4     1        s     d  [[                -
C#5    1        s     d  ==                -
B4     1        s     d  ==                -
C#5    1        s     d  ]]                -
D#5    1        s     d  [[                -
C#5    1        s     d  =]                -
B4     2-       e     d  ]     -           -
B4     1        s     d  [[                -
D#5    1        s     d  ==                -
C#5    1        s     d  ==                -
D#5    1        s     d  ]]                -
measure 18
E5     1        s     d  [[                -
D#5    1        s     d  =]                -
C#5    2-       e     d  ]     -           -
C#5    1        s     d  [[                -
E5     1        s     d  ==                -
D#5    1        s     d  ==                -
E5     1        s     d  ]]                -
F#5    1        s     d  [[                -
E5     1        s     d  ==                -
D#5    1        s     d  ==                -
C#5    1        s     d  ]]                -
B4     1        s     d  [[                -
F#5    1        s     d  ==                -
E5     1        s     d  ==                -
F#5    1        s     d  ]]                -
measure 19
G#5    1        s     d  [[                -
F#5    1        s     d  ]]                -
E5     2        e     d                    ted,
rest   4        q
rest   2        e
E4     2        e     u                    shall
G#4    2        e     u                    be
B4     2        e     u                    ex-
measure 20
E5     6        q.    d                    al-
F#5    1        s     d  [[                -
E5     1        s     d  ]]                -
D#5    1        s     d  [[                -
C#5    1        s     d  ]]                -
B4     2        e     u                    ted,
rest   4        q
measure 21
rest   2        e
F#4    2        e     u                    shall
B4     2        e     u                    be
F#4    2        e     u                    ex-
G#4    1        s     u  [[                al-
F#4    1        s     u  =]                -
E4     2-       e     u  ]     -           -
E4     1        s     u  [[                -
G#4    1        s     u  ==                -
A#4    1        s     u  ==                -
B4     1        s     u  ]]                -
measure 22
A#4    1        s     u  [[                -
G#4    1        s     u  =]                -
F#4    2-       e     u  ]     -           -
F#4    1        s     u  [[                -
A#4    1        s     u  ==                -
B4     1        s     u  ==                -
C#5    1        s     u  ]]                -
B4     1        s     u  [[                -
A#4    1        s     u  =]                -
G#4    2-       e     u  ]     -           -
G#4    1        s     d  [[                -
B4     1        s     d  ==                -
C#5    1        s     d  ==                -
D#5    1        s     d  ]]                -
measure 23
C#5    1        s     d  [[                -
B4     1        s     d  =]                -
A#4    2-       e     d  ]     -           -
A#4    1        s     d  [[                -
C#5    1        s     d  ==                -
D#5    1        s     d  ==                -
E5     1        s     d  ]]                -
D#5    1        s     d  [[                -
C#5    1        s     d  ==                -
B4     1        s     d  ==                -
D#5    1        s     d  ]]                -
E5     1        s     d  [[                -
D#5    1        s     d  ==                -
C#5    1        s     d  ==                -
E5     1        s     d  ]]                -
measure 24
F#5    2        e     d                    -
B4     2        e     u                    ted,
rest   4        q
rest   2        e
F#4    2        e     u                    and
B4     2        e     u                    ev'-
D#5    2        e     d                    ry
measure 25
F#5    4        q     d                    moun-
F#4    2        e     u                    tain
E5     2        e     d                    and
D#5    2        e     d  [                 hill_
E5     1        s     d  =[                _
D#5    1        s     d  =]                _
C#5    2        e     d  ]                 _
B4     2        e     u                    made
measure 26
F#4    8        h     u                    low,
rest   8        h
measure 27
rest   4        q
rest   2        e
B4     2        e     u                    the
C#5    2        e     d  [                 croo-
B4     2        e     d  ]                 -
C#5    2        e     d  [                 ked_
B4     2        e     d  ]                 _
measure 28
B4     8        h     u                    straight,
rest   8        h
measure 29
rest   4        q
B4     2        e     u                    and
B4     2        e     u                    the
B4     4        q     u                    rough
B4     2        e     u                    pla-
B4     2        e     u                    ces
measure 30
B4     8        h     u                    plain,_
E5     8-       h     d        -           _
measure 31
E5     2        e     d  [                 _
D#5    2        e     d  =                 _
E5     2        e     d  =                 _
D#5    2        e     d  ]                 _
E5     8-       h     d        -           _
measure 32
E5     2        e     d  [                 _
D#5    2        e     d  =                 _
E5     2        e     d  =                 _
D#5    2        e     d  ]                 _
E5     8-       h     d        -           _
measure 33
E5     4        q     d                    _
rest   2        e
C#5    2        e     d                    the
D#5    2        e     d  [                 croo-
G#5    2        e     d  =                 -
F#5    2        e     d  ]                 -
A#4    2        e     u                    ked
measure 34
B4     4        q     u                    straight,
rest   2        e
C#5    2        e     d                    the
D#5    2        e     d  [                 croo-
G#5    2        e     d  =                 -
F#5    2        e     d  ]                 -
A#4    2        e     u                    ked
measure 35
B4     2        e     u  [                 straight,_
E4     2        e     u  ]                 _
D#4    2        e     u                    and
G#4    2        e     u                    the
F#4    2        e     u  [                 rough_
B4     2        e     u  ]                 _
A#4    2        e     u                    pla-
E5     2        e     d                    ces
measure 36
D#5    8-       h     d        -           plain,_
D#5    6        q.    d                    _
E5     1        s     d  [[                _
D#5    1        s     d  ]]                _
measure 37
C#5    8-       h     d        -           _
C#5    6        q.    d                    _
D#5    1        s     d  [[                _
C#5    1        s     d  ]]                _
measure 38
B4     8-       h     u        -           _
B4     6        q.    u                    _
C#5    1        s     d  [[                _
B4     1        s     d  ]]                _
measure 39
A#4    2        e     u  [                 _
B4     2        e     u  =                 _
C#5    2        e     u  =                 _
B4     2        e     u  ]                 _
A#4    2        e     u  [                 _
B4     2        e     u  =                 _
C#5    2        e     u  =                 _
B4     2        e     u  ]                 _
measure 40
A#4    4        q     u                    _
B4     2        e     u                    and
E5     2        e     d                    the
D#5    4        q     d                    rough
C#5    2        e     d                    pla-
B4     2        e     u                    ces
measure 41
B4    16        w     d                    plain.
measure 42
rest  16
measure 43
rest  16
measure 44
B4     4        q     u                    Ev'-
D#5    4        q     d                    ry
E5     4        q     d                    val-
E4     4        q     u                    ley,
measure 45
rest  16
measure 46
A4     4        q     u                    ev'-
B4     4        q     u                    ry
C#5    3        e.    d  [                 val-
E5     1        s     d  ]\                -
E5     4-       q     d        -           ley_
measure 47
E5     2        e     d                    _
D5     1        s     d  [[                shall_
C#5    1        s     d  ]]                _
B4     2        e     u                    be
A4     2        e     u                    ex-
G#4    2        e     d  [                 al-
E5     2        e     d  ]                 -
E5     4-       q     d        -           -
measure 48
E5     2        e     d  [                 -
F#5    1        s     d  =[                -
E5     1        s     d  ]]                -
D5     1        s     d  [[                -
C#5    1        s     d  ==                -
B4     1        s     d  ==                -
A4     1        s     d  ]]                -
G#4    2        e     d  [                 -
E5     2        e     d  ]                 -
E5     4-       q     d        -           -
measure 49
E5     2        e     d  [                 -
F#5    1        s     d  =[                -
E5     1        s     d  ]]                -
D5     1        s     d  [[                -
C#5    1        s     d  ==                -
B4     1        s     d  ==                -
A4     1        s     d  ]]                -
G#4    1        s     u  [[                -
F#4    1        s     u  =]                -
E4     2-       e     u  ]     -           -
E4     1        s     u  [[                -
G#4    1        s     u  ==                -
A4     1        s     u  ==                -
B4     1        s     u  ]]                -
measure 50
A4     1        s     u  [[                -
G#4    1        s     u  =]                -
F#4    2-       e     u  ]     -           -
F#4    1        s     u  [[                -
A4     1        s     u  ==                -
B4     1        s     u  ==                -
C#5    1        s     u  ]]                -
B4     1        s     u  [[                -
A4     1        s     u  =]                -
G#4    2-       e     u  ]     -           -
G#4    1        s     u  [[                -
B4     1        s     u  ==                -
C#5    1        s     u  ==                -
D5     1        s     u  ]]                -
measure 51
C#5    1        s     d  [[                -
B4     1        s     d  ==                -
A4     1        s     d  ==                -
C#5    1        s     d  ]]                -
D5     1        s     d  [[                -
C#5    1        s     d  ==                -
B4     1        s     d  ==                -
D5     1        s     d  ]]                -
E5     4        q     d                    -
A4     4        q     u                    ted,
measure 52
rest  16
measure 53
E4     4        q     u                    ev'-
F#4    4        q     u                    ry
G#4    3        e.    u  [                 val-
B4     1        s     u  ]\                -
B4     4        q     u                    ley,
measure 54
rest  16
measure 55
B4     4        q     u                    ev'-
C#5    4        q     d                    ry
D#5    3        e.    d  [                 val-
F#5    1        s     d  ]\                -
F#5    4-       q     d        -           ley_
measure 56
F#5    1        s     d                    _
E5     1        s     d  [[                shall_
D#5    1        s     d  ==                _
C#5    1        s     d  ]]                _
B4     2        e     u                    be
A4     2        e     u                    ex-
G#4    1        s     u  [[                al-
F#4    1        s     u  =]                -
E4     2        e     u  ]                 -
E5     4        q     d                    -
measure 57
A4     1        s     u  [[                -
G#4    1        s     u  =]                -
F#4    2        e     u  ]                 -
E5     4        q     d                    -
B4     1        s     u  [[                -
A4     1        s     u  =]                -
G#4    2        e     u  ]                 -
E5     4-       q     d        -           -
measure 58
E5     1        s     d  [[                -
D#5    1        s     d  =]                -
C#5    2        e     d  ]                 -
F#5    2        e     d  [                 -
E5     2        e     d  ]                 -
D#5    3        e.    d  [                 -
C#5    1        s     d  ]\                -
B4     4        q     d                    ted,
measure 59
rest   2        e
A#4    2        e     u                    and
A#4    2        e     u                    ev'-
A#4    2        e     u                    ry
B4     4        q     u                    moun-
F#4    2        e     u                    tain
G#4    2        e     u                    and
measure 60
A4     6        q.    u         +          hill
G#4    2        e     u                    made
G#4    4        q     u                    low,
rest   4        q
measure 61
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d                    the
measure 62
F#5    2        e     d  [                 croo-
E5     2        e     d  ]                 -
F#5    2        e     d  [                 ked_
E5     2        e     d  ]                 _
E5     8        h     d                    straight,
measure 63
rest   8        h
rest   4        q
rest   2        e
B4     2        e     u                    the
measure 64
C#5    2        e     d  [                 croo-
E5     2        e     d  ]                 -
F#4    4        q     u                    ked
F#4    4        q     u                    straight,
rest   2        e
D#5    2        e     d                    the
measure 65
E5     2        e     d  [                 croo-
G#5    2        e     d  ]                 -
B4     4        q     u                    ked
A4     4        q     u                    straight,
A4     2        e     u                    and
A4     2        e     u                    the
measure 66
A4     4        q     u                    rough
A4     2        e     u                    pla-
A4     2        e     u                    ces
A4     8-       h     u        -           plain,_
measure 67
A4    16-       w     u        -           _
measure 68
A4     4        q     u                    _
G#4    2        e     u                    and
F#4    2        e     u                    the
G#4    4        q     u                    rough
F#4    2        e     u                    pla-
E4     2        e     u                    ces
measure 69
E4     4        q     u                    plain,
B4     2        e     u                    and
G#4    2        e     u                    the
C#5    4        q     d                    rough
D#5    2        e     d                    pla-
D#5    2        e     d                    ces
measure 70
E5    16-       w     d        -           plain,_
measure 71
E5     8        h     d                    _
rest   8        h
measure 72
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u                    the
measure 73
E5     4        q     d                    croo-
A#4    4        q     u                    ked
B4     4        q     u         F          straight,
rest   4        q
measure 74
rest   4        q
B4     4        q     u                    and
C#5    4        q     d                    the
E5     4        q     d                    rough
measure 75
G#4    8        h     u         (          pla-
F#4    6        q.    u         )          -
E4     2        e     u                    ces
measure 76
E4     8        h     u                    plain.
rest   8        h
measure 77
rest  16
measure 78
rest  16
measure 79
rest  16
measure 80
rest  16
measure 81
rest  16
measure 82
rest  16
measure 83
rest  16
measure 84
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-03/5} [KHM:1572633547]
TIMESTAMP: DEC/26/2001 [md5sum:497b2b7e7999c337728764017fe9d2d7]
04/04/90 E. Correia
WK#:56        MV#:1,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
1 19
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:2   T:1/1   C:22   D:Andante
E3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
B3     1        e     d  ]
E3     2        q     d
rest   1        e
F#3    1        e     d
measure 2
G#3    1        e     d  [
E3     1        e     d  =
A3     1        e     d  =
C#4    1        e     d  ]
B3     2        q     d
rest   1        e
A3     1        e     d
measure 3
G#3    1        e     u  [
E3     1        e     u  =
A3     1        e     u  =
A2     1        e     u  ]
B2     2        q     u
rest   1        e
G#3    1        e     d
measure 4
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  ]
rest   1        e
E3     1        e     d
measure 5
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  ]
rest   2        q
measure 6
rest   4        h
rest   2        q
rest   1        e
B3     1        e     d         &f
measure 7
E4     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
E3     2        q     d
rest   2        q
measure 8
rest   4        h
rest   2        q
rest   1        e
B2     1        e     u         &f
measure 9
E3     1        e     u  [
A2     1        e     u  ]
B2     2        q     u
E2     2        q     u
rest   2        q
measure 10
rest   8
measure 11
E3     1        e     d  [      &f
G#3    1        e     d  =
A3     1        e     d  =
B3     1        e     d  ]
E3     2        q     d
rest   2        q
measure 12
E3     2        q     d         p
F#3    2        q     d
G#3    2        q     d
rest   1        e
G#2    1        e     u
measure 13
A2     2        q     u
B2     2        q     u
E3     2        q     d
rest   1        e
G#3    1        e     d
measure 14
A3     1        e     d  [
A2     1        e     d  =
B2     1        e     d  =
B3     1        e     d  ]
E3     2        q     d
rest   1        e
G#3    1        e     d
measure 15
A3     1        e     d  [
A2     1        e     d  =
B2     1        e     d  =
D#3    1        e     d  ]
E3     2        q     d
rest   1        e
E3     1        e     d
measure 16
F#3    2        q     d
rest   1        e
F#3    1        e     d
G#3    2        q     d
rest   1        e
G#3    1        e     d
measure 17
A3     2        q     d
rest   1        e
A3     1        e     d
B3     2        q     d
rest   1        e
B3     1        e     d
measure 18
C#4    2        q     d
rest   1        e
C#3    1        e     u
D#3    2        q     u
rest   1        e
D#3    1        e     u
measure 19
E3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
B3     1        e     d  ]
E3     2        q     d
rest   2        q
measure 20
rest   1        e
C#4    1        e     d  [
A#3    1        e     d  =
F#3    1        e     d  ]
B3     1        e     d  [
B2     1        e     d  ]
rest   2        q
measure 21
rest   1        e
B2     1        e     u  [
D#3    1        e     u  =
B2     1        e     u  ]
E3     2        q     d
rest   1        e
E3     1        e     d
measure 22
F#3    2        q     d
rest   1        e
F#3    1        e     d
G#3    2        q     d
rest   1        e
G#3    1        e     d
measure 23
A#3    2        q     d
rest   1        e
A#3    1        e     d
B3     1        e     d  [
D#3    1        e     d  =
C#3    1        e     d  =
F#3    1        e     d  ]
measure 24
D#3    2        q     d
E3     1        e     d  [
F#3    1        e     d  ]
B2     2        q     u
rest   1        e
B3     1        e     d
measure 25
A#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
F#3    1        e     d  ]
B3     1        e     d  [
B2     1        e     d  =
C#3    1        e     d  =
E3     1        e     d  ]
measure 26
F#2    4        h     u
rest   4        h
measure 27
rest   2        q
rest   1        e
D#3    1        e     u
E3     1        e     d  [
D#3    1        e     d  =
E3     1        e     d  =
D#3    1        e     d  ]
measure 28
E3     1        e     d  [
D#3    1        e     d  ]
rest   2        q
rest   4        h
measure 29
rest   2        q
rest   1        e
B2     1        e     u
E3     1        e     u  [
B2     1        e     u  =
E3     1        e     u  =
B2     1        e     u  ]
measure 30
E3     1        e     u  [
B2     1        e     u  ]
rest   1        e
B2     1        e     u
C#3    1        e     u  [
G#2    1        e     u  =
C#3    1        e     u  =
E3     1        e     u  ]
measure 31
F#3    2        q     d
rest   2        q
F#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
G#3    1        e     d  ]
measure 32
F#3    2        q     d
rest   2        q
F#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
G#3    1        e     d  ]
measure 33
F#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
A#2    1        e     d  ]
B2     1        e     d  [
E3     1        e     d  =
D#3    1        e     d  =
F#3    1        e     d  ]
measure 34
B2     1        e     d  [
E3     1        e     d  =
D#3    1        e     d  =
F#3    1        e     d  ]
B2     1        e     d  [
E3     1        e     d  =
D#3    1        e     d  =
F#3    1        e     d  ]
measure 35
G#2    2        q     u
F#2    1        e     u  [
E2     1        e     u  ]
D#2    1        e     u  [
D#3    1        e     u  =
C#3    1        e     u  =
C#3    1        e     u  ]
measure 36
B2     1        e     u  [
B2     1        e     u  =
B2     1        e     u  =
B2     1        e     u  ]
B3     1        e     d  [
B3     1        e     d  =
B3     1        e     d  =
B3     1        e     d  ]
measure 37
A#3    1        e     d  [
A#3    1        e     d  =
A#3    1        e     d  =
A#3    1        e     d  ]
A#3    1        e     d  [
A#3    1        e     d  =
A#3    1        e     d  =
A#3    1        e     d  ]
measure 38
G#3    1        e     d  [
G#3    1        e     d  =
G#3    1        e     d  =
G#3    1        e     d  ]
G#3    1        e     d  [
G#3    1        e     d  =
G#3    1        e     d  =
G#3    1        e     d  ]
measure 39
F#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
G#3    1        e     d  ]
F#3    1        e     d  [
G#3    1        e     d  =
A#3    1        e     d  =
G#3    1        e     d  ]
measure 40
F#3    2        q     d
G#3    2        q     d
F#3    2        q     d
F#2    2        q     u
measure 41
B2     8        w     u
measure 42
rest   4        h
rest   2        q
rest   1        e
F#3    1        e     d         f
measure 43
B3     1        e     u  [
E3     1        e     u  =
F#3    1        e     u  =
F#2    1        e     u  ]
B2     2        q     u
rest   2        q
measure 44
B3     2        q     d
A3     2        q     d
G#3    2        q     d
rest   2        q
measure 45
E3     2        q     d         &f
D3     2        q     u
C#3    2        q     u
rest   2        q
measure 46
C#3    2        q     u
E3     2        q     d
A3     2        q     d
rest   1        e
B2     1        e     u
measure 47
C#3    2        q     u
D3     2        q     u
E3     2        q     d
rest   1        e
D3     1        e     u
measure 48
C#3    2        q     u
D3     2        q     u
E3     2        q     d
rest   1        e
D3     1        e     u
measure 49
C#3    2        q     u
D3     2        q     u
E3     2        q     d
rest   1        e
E3     1        e     d
measure 50
F#3    2        q     d
rest   1        e
F#3    1        e     d
G#3    2        q     d
rest   1        e
G#3    1        e     d
measure 51
A3     2        q     d
B3     2        q     d
C#4    2        q     d
rest   2        q
measure 52
C#3    2        q     u
E3     2        q     d
A2     2        q     u
rest   2        q
measure 53
G#2    2        q     u
B2     2        q     u
E3     2        q     d
rest   2        q
$ C:12
measure 54
*               D       Violonc.
G#3    2        q     u
B3     2        q     d
E4     2        q     d
rest   2        q
$ C:22
measure 55
*               D       Tutti
G#3    1        e     d  [
E3     1        e     d  =
A3     1        e     d  =
F#3    1        e     d  ]
B3     2        q     d
B2     1        e     u  [
C#3    1        e     u  ]
measure 56
D#3    2        q     u
rest   2        q
E3     2        q     d
rest   2        q
measure 57
F#3    2        q     d
rest   2        q
G#3    2        q     d
rest   2        q
measure 58
A#3    2        q     d
rest   2        q
B3     1        e     d  [
B2     1        e     d  =
B2     1        e     d  =
B2     1        e     d  ]
measure 59
C#3    1        e     u  [
C#3    1        e     u  =
C#3    1        e     u  =
C#3    1        e     u  ]
D#3    1        e     d  [
D#3    1        e     d  =
D#3    1        e     d  =
E3     1        e     d  ]
measure 60
F#3    2        q     d
B2     2        q     u
E3     2        q     d
rest   2        q
measure 61
rest   4        h
rest   2        q
rest   1        e
G#3    1        e     d
measure 62
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
measure 63
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
measure 64
A3     2        q     d
A2     2        q     u
B2     2        q     u
rest   1        e
B2     1        e     u
measure 65
E3     2        q     d
G#3    2        q     d
F#3    2        q     d
rest   1        e
C#3    1        e     u
measure 66
F#3    1        e     d  [
E3     1        e     d  =
D#3    1        e     d  =
C#3    1        e     d  ]
B2     1        e     u  [
C#3    1        e     u  =
D#3    1        e     u  =
C#3    1        e     u  ]
measure 67
B2     1        e     u  [
C#3    1        e     u  =
D#3    1        e     u  =
C#3    1        e     u  ]
B2     1        e     u  [
C#3    1        e     u  =
D#3    1        e     u  =
C#3    1        e     u  ]
measure 68
B2     2        q     u
E3     1        e     u  [
A2     1        e     u  ]
B2     4        h     u
measure 69
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
E3     1        e     d  ]
A3     1        e     d  [
F#3    1        e     d  =
B3     1        e     d  =
A3     1        e     d  ]
measure 70
G#3    1        e     d  [
E3     1        e     d  ]
rest   2        q
rest   4        h
measure 71
rest   4        h
rest   2        q
rest   1        e
B3     1        e     d         f
measure 72
E4     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
C#3    2        q     u
rest   2        q
measure 73
C#4    2        q     d
rest   2        q
D#3    2        q     u         F
rest   2        q
measure 74
E3     4        h     d
A2     4        h     u
measure 75
B2     8        w     u
measure 76
E3     1        e     d  [      &f
G#3    1        e     d  =
A3     1        e     d  =
B3     1        e     d  ]
E3     2        q     d
rest   1        e
F#3    1        e     d
measure 77
G#3    1        e     d  [
E3     1        e     d  =
A3     1        e     d  =
C#4    1        e     d  ]
B3     2        q     d
rest   1        e
A3     1        e     d
measure 78
G#3    1        e     d  [
E3     1        e     d  =
A3     1        e     d  =
A2     1        e     d  ]
B2     2        q     u
rest   1        e
G#3    1        e     d
measure 79
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  ]
rest   1        e
E3     1        e     d
measure 80
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  ]
rest   2        q
measure 81
rest   4        h
rest   2        q
rest   1        e
B3     1        e     d         &f
measure 82
E4     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
E3     2        q     d
rest   2        q
measure 83
rest   4        h
rest   2        q
rest   1        e
B2     1        e     u         &f
measure 84
E3     1        e     u  [
A2     1        e     u  ]
B2     2        q     u
E2     2        q     u         F
rest   2        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
