&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-08/1} [KHM:1851446760]
TIMESTAMP: DEC/26/2001 [md5sum:dad3f33644be2594d3cca703b15da54a]
06/10/90 E. Correia
WK#:56        MV#:2,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino I
0 19
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Largo e piano
rest   2        e
measure 1
rest   2        e
B4     2        e     u
E5     4        q     d
rest   2        e
A4     2        e     u
F#5    4        q     d
measure 2
rest   2        e
A4     2        e     u
F#5    4        q     d
rest   2        e
B4     2        e     u
E5     4        q     d
measure 3
rest   8        h
rest   2        e
F#4    2        e     u
B4     4-       q     d        -
measure 4
B4     4        q     d
A4     2        e     d  [
E5     2        e     d  ]
D#5    4        q     d
rest   2        e
B4     2        e     d
measure 5
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
C5     2        e     d  [
B4     2        e     d  ]
rest   2        e
B4     2-       e     d        -
measure 6
B4     2        e     d  [
E5     2        e     d  =
A4     3        e.    d  =      &t
B4     1        s     d  ]\
B4     4        q     d
rest   4        q
measure 7
rest   2        e
D5     2        e     d         p
G5     4        q     d
rest   2        e
F#5    2        e     d
A5     4        q     d
measure 8
rest   2        e
G#5    2        e     d
B5     4        q     d
rest   2        e
A4     2        e     u
A5     4        q     d
measure 9
rest   2        e
C5     2        e     d
A5     4        q     d
rest   2        e
G4     2        e     u
G5     4        q     d
measure 10
rest   2        e
B4     2        e     d
E5     4        q     d
rest   2        e
A4     2        e     u
G5     4        q     d
measure 11
rest   2        e
A4     2        e     u
F#5    4        q     d
rest   2        e
G4     2        e     u
E5     4        q     d
measure 12
rest   2        e
E4     2        e     u  [
D4     2        e     u  =
E4     2        e     u  ]
B3     4        q     u
rest   4        q
measure 13
rest   2        e
C4     2        e     u  [
B3     2        e     u  =
C4     2        e     u  ]
G3     4        q     u
rest   2        e
B4     2        e     d
measure 14
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
C5     2        e     d  [
B4     2        e     d  ]
rest   2        e
B4     2-       e     d        -
measure 15
B4     2        e     d  [
E5     2        e     d  =
A4     3        e.    d  =      &t
B4     1        s     d  ]\
B4     4        q     d
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-08/2} [KHM:1851446760]
TIMESTAMP: DEC/26/2001 [md5sum:a079c53125408bef20f98793f3380453]
06/10/90 E. Correia
WK#:56        MV#:2,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino II
0 19
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:8   T:1/1   C:4   D:Largo e piano
rest   4        e
measure 1
rest   4        e
G4     4        e     u
B4     8        q     d
rest   4        e
F#4    3        s.    u  [[
E4     1        t     u  ]]\
F#4    8        q     u
measure 2
rest   4        e
F#4    4        e     u
D#5    8        q     d
rest   4        e
B3     4        e     u
B4     8        q     d
measure 3
rest  16        h
rest   8        q
rest   4        e
F#4    4        e     u
measure 4
E4    16        h     u
F#4    8        q     u
rest   8        q
measure 5
rest   4        e
D#4    4        e     u  [
B4     4        e     u  =
A4     4        e     u  ]
G4     4        e     u  [
F#4    4        e     u  ]
rest   4        e
G4     4        e     u
measure 6
E4    16        h     u
D#4    8        q     u
rest   8        q
measure 7
rest   4        e
D5     4        e     d         p
G5     8        q     d
rest   4        e
F#5    4        e     d
A5     8        q     d
measure 8
rest   4        e
G#5    4        e     d
B5     8        q     d
rest   4        e
A4     4        e     u
A5     8        q     d
measure 9
rest   4        e
C5     4        e     d
A5     8        q     d
rest   4        e
G4     4        e     u
G5     8        q     d
measure 10
rest   4        e
B4     4        e     d
E5     8        q     d
rest   4        e
A4     4        e     u
G5     8        q     d
measure 11
rest   4        e
A4     4        e     u
F#5    8        q     d
rest   4        e
G4     4        e     u
E5     8        q     d
measure 12
rest   4        e
E4     4        e     u  [
D4     4        e     u  =
E4     4        e     u  ]
B3     8        q     u
rest   8        q
measure 13
rest   4        e
C4     4        e     u  [
B3     4        e     u  =
C4     4        e     u  ]
G3     8        q     u
rest   8        q
measure 14
rest   4        e
D#4    4        e     u  [
B4     4        e     u  =
A4     4        e     u  ]
G4     4        e     u  [
F#4    4        e     u  ]
rest   4        e
G4     4        e     u
measure 15
E4    16        h     u
D#4    8        q     u
rest   8        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-08/3} [KHM:1851446760]
TIMESTAMP: DEC/26/2001 [md5sum:995e0c5685c10da2fde193668e2951c5]
06/10/90 E. Correia
WK#:56        MV#:2,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Viola
0 19
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:8   T:1/1   C:13   D:Largo e piano
rest   4        e
measure 1
rest   4        e
B3     4        e     u
G4     8        q     d
rest   4        e
A4     4        e     d
C4     8        q     d
measure 2
rest   4        e
B3     4        e     u
A4     8        q     d
rest   4        e
G4     3        s.    d  [[
F#4    1        t     d  ]]\
E4     8        q     d
measure 3
rest  16        h
rest   8        q
rest   4        e
B3     4        e     u
measure 4
C4    16        h     d
F#3    8        q     u
rest   8        q
measure 5
rest   8        q
rest   4        e
A3     4        e     u
E4     4        e     d  [
B3     4        e     d  ]
rest   4        e
B3     4        e     u
measure 6
C4    16        h     d
F#3    8        q     u
rest   8        q
measure 7
rest  32
measure 8
rest  32
measure 9
rest  32
measure 10
rest  32
measure 11
rest  32
measure 12
rest  32
measure 13
rest  32
measure 14
rest   8        q
rest   4        e
D4     4        e     d
E4     4        e     d  [
B3     4        e     d  ]
rest   4        e
B3     4        e     u
measure 15
C4    16        h     u
F#3    8        q     u
rest   8        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-08/4} [KHM:1851446760]
TIMESTAMP: DEC/26/2001 [md5sum:78497979bb8dfb8262d802f6a9714e33]
06/10/90 E. Correia
WK#:56        MV#:2,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Tenore
0 19 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:34   D:Largo e piano
E4     2        e     u                    Be-
measure 1
B4     4        q     d                    hold
rest   2        e
E5     1        s     d  [[                and_
C5     1        s     d  ]]                _
A4     4        q     u                    see,
rest   2        e
A4     2        e     u                    be-
measure 2
F#5    6        q.    d                    hold
D#5    1        s     d  [[                and_
B4     1        s     d  ]]                _
gA4    6        e     u
G4     4        q     u                    see,
rest   2        e
B4     2        e     d                    if
measure 3
G4     2        e     u                    there
E4     2        e     u                    be
E5     2        e     d                    a-
D5     2        e     d                    ny
C5     2        e     d                    sor-
B4     2        e     d                    row
rest   4        q
measure 4
E5     2        e     d                    like
G4     2        e     u                    un-
A4     3        e.    u                    to
A4     1        s     u                    his
B4     2        e     d                    sor-
B4     2        e     d                    row!
rest   4        q
measure 5
rest  16
measure 6
rest   8        h
rest   4        q
rest   2        e
G4     2        e     u                    Be-
measure 7
B4     4        q     d                    hold
rest   2        e
C5     2        e     d                    and
A4     4        q     u                    see,
rest   2        e
D5     2        e     d                    if
measure 8
D5     2        e     d                    there
D5     2        e     d                    be
E5     2        e     d                    a-
B4     2        e     d                    ny
C5     2        e     d                    sor-
C5     2        e     d                    row
rest   4        q
measure 9
C5     3        e.    d                    like
C5     1        s     d                    un-
D5     2        e     d                    to
A4     2        e     u                    his
B4     2        e     d                    sor-
B4     2        e     d                    row!
rest   2        e
B4     2        e     d                    Be-
measure 10
G5     4        q     d                    hold
rest   2        e
B4     1        s     u  [[                and_
A4     1        s     u  ]]                _
A4     4        q     u                    see,
rest   2        e
A4     1        s     u                    if
A4     1        s     u                    there
measure 11
F#5    4        q     d                    be
D#5    2        e     d                    a-
B4     2        e     d                    ny
G4     1        s     u  [[                sor-
F#4    1        s     u  ]]                -
E4     2        e     u                    row
rest   4        q
measure 12
G4     8-       h     u        -           like_
G4     2        e     u                    _
E4     2        e     u                    un-
E4     2        e     u                    to
E4     2        e     u                    his
measure 13
E4     1        s     u  [[                sor-
D#4    1        s     u  ]]                -
E4     6        q.    u                    row!
rest   8        h
measure 14
rest  16
measure 15
rest  16
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-08/5} [KHM:1851446760]
TIMESTAMP: DEC/26/2001 [md5sum:2b958eb0accd7b0ccb607aac6a775fd6]
06/10/90 E. Correia
WK#:56        MV#:2,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
0 19
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:2   T:1/1   C:22   D:Largo e piano
rest   1        e
measure 1
rest   1        e
E3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  ]
rest   1        e
F#3    1        e     d  [
A3     1        e     d  =
F#3    1        e     d  ]
measure 2
rest   1        e
D#3    1        e     u  [
B2     1        e     u  =
D#3    1        e     u  ]
rest   1        e
E3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  ]
measure 3
rest   1        e
E3     1        e     d  [
f1              6
G3     1        e     d  =
f1              6
F#3    1        e     d  ]
f1              6
E3     1        e     d  [
f1              6
D3     1        e     d  ]
rest   1        e
D3     1        e     d
measure 4
f1     2        7
f1              6
C3     4        h     u
B2     2        q     u
rest   2        q
measure 5
rest   1        e
B2     1        e     d  [
G3     1        e     d  =
F#3    1        e     d  ]
E3     1        e     d  [
D3     1        e     d  ]
rest   1        e
E3     1        e     d
measure 6
f1     2        7
f1              6
C3     4        h     u
f1              #
B2     2        q     u
rest   2        q
measure 7
rest   1        e
G3     1        e     d  [
B3     1        e     d  =
G3     1        e     d  ]
rest   1        e
D3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
measure 8
rest   1        e
B3     1        e     d  [
G#3    1        e     d  =
E3     1        e     d  ]
rest   1        e
A3     1        e     d  [
C4     1        e     d  =
A3     1        e     d  ]
measure 9
rest   1        e
A3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
rest   1        e
G3     1        e     d  [
B3     1        e     d  =
G3     1        e     d  ]
measure 10
rest   1        e
E3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  ]
rest   1        e
C#3    1        e     d  [
E3     1        e     d  =
C#3    1        e     d  ]
measure 11
rest   1        e
D#3    1        e     d  [
F#3    1        e     d  =
D#3    1        e     d  ]
rest   1        e
E3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  ]
measure 12
rest   1        e
C3     1        e     u  [
B2     1        e     u  =
C3     1        e     u  ]
G2     2        q     u
rest   2        q
measure 13
rest   1        e
A2     1        e     u  [
G2     1        e     u  =
A2     1        e     u  ]
E2     2        q     u
rest   2        q
measure 14
rest   1        e
f1              #
B2     1        e     d  [
f1              6
G3     1        e     d  =
f1              6
F#3    1        e     d  ]
f1              6
E3     1        e     d  [
f1              6
D3     1        e     d  ]
rest   1        e
E3     1        e     d
measure 15
f1     2        7
f1              6
C3     4        h     u
f1              #
B2     2        q     u
rest   2        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
