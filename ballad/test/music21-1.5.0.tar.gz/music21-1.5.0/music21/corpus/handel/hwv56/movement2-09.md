&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-09/1} [KHM:1263839512]
TIMESTAMP: DEC/26/2001 [md5sum:631d99b96ae03840dbc775aee9527275]
06/10/90 E. Correia
WK#:56        MV#:2,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
1 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:1   T:1/1   C:4
D5     2        h     d         +
C#5    2-       h     d        -
measure 2
C#5    2        h     d
B4     2        h     d
measure 3
D#5    4        w     d
measure 4
B4     1        q     d
E5     1-       q     d        -
E5     2        h     d
measure 5
D#5    1        q     d
E5     1        q     d
rest   2        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-09/2} [KHM:1263839512]
TIMESTAMP: DEC/26/2001 [md5sum:4d980cf960c18b8ba4877fcd9c44a855]
06/10/90 E. Correia
WK#:56        MV#:2,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
1 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:1   T:1/1   C:4
B4     2        h     u
A#4    2-       h     u        -
measure 2
A#4    2        h     u
F#4    2        h     u
measure 3
B4     4-       w     d        -
measure 4
B4     2        h     d
C#5    2        h     d
measure 5
F#4    1        q     u
G#4    1        q     u
rest   2        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-09/3} [KHM:1263839512]
TIMESTAMP: DEC/26/2001 [md5sum:0bb880fc114cad32284043018d4921d6]
06/10/90 E. Correia
WK#:56        MV#:2,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
1 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:1   T:1/1   C:13
F#4    2        h     d
E4     2-       h     d        -
measure 2
E4     2        h     d
D4     2        h     d
measure 3
F#4    4        w     d
measure 4
E4     1        q     d
G#4    1        q     d
F#4    2        h     d
measure 5
B4     1        q     d
B3     1        q     u
rest   2        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-09/4} [KHM:1263839512]
TIMESTAMP: DEC/26/2001 [md5sum:bd9964a3d61cde41951e21bd0466de3e]
06/10/90 E. Correia
WK#:56        MV#:2,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Tenore
1 72 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:34    D:Largo e piano
rest   2        e
F#4    2        e     u                    He
F#4    2        e     u                    was
F#4    2        e     u                    cut
A#4    4        q     u                    off
rest   1        s
A#4    1        s     u                    out
A#4    1        s     u                    of
B4     1        s     u                    the
measure 2
C#5    4        q     d                    land
E5     2        e     d                    of
C#5    2        e     d                    the
D5     2        e     d                    liv-
D5     2        e     d                    ing;
rest   4        q
measure 3
rest   2        e
B4     2        e     d                    for
B4     2        e     d                    the
C#5    2        e     d                    trans-
D#5    2        e     d                    gress-
D#5    2        e     d                    ions
C#5    2        e     d                    of
B4     2        e     d                    thy
measure 4
E5     2        e     d                    peo-
E5     2        e     d                    ple
rest   4        q
rest   4        q
C#5    2        e     d                    was
E5     2        e     d                    he
measure 5
B4     2        e     d                    stri-
B4     2        e     d                    cken.
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-09/5} [KHM:1263839512]
TIMESTAMP: DEC/26/2001 [md5sum:54b999392ec5d2184faa874285a9c11d]
06/10/90 E. Correia
WK#:56        MV#:2,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
1 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:1   T:1/1   C:22
f1     2        b
f3              7# 4 2+
B2     4-       w     u        -
measure 2
f1     2        b
f2              5 3
B2     4        w     u
measure 3
f2              4+ 2
A2     4        w     u
measure 4
G#2    2        h     u
f1              #
A2     2        h     u
measure 5
f1              #
B2     1        q     u
f1              #
E2     1        q     u
rest   2        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
