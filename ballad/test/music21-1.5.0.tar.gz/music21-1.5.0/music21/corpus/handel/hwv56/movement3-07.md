&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/1} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:f6429f112f837bb2707e272654a86a97]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
Ef5    2        e     d
Ef5    2        e     d  [      &(
D5     2        e     d  ]      &)
rest   2        e
D5     2        e     d
measure 2
Ef5    4        q     d
C5     4        q     d
rest   2        e
Ef5    2        e     d  [
D5     2        e     d  =
Ef5    2        e     d  ]
measure 3
F5     4        q     d
rest   2        e
Bf4    2        e     d
C5     4        q     d
rest   2        e
C5     2        e     d
measure 4
D5     4        q     d
Ef5    4        q     d
rest   2        e
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  ]
measure 5
F5     4        q     d
rest   2        e
Bf4    2        e     d
D5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 6
F4     4        q     u
F4     2        e     u  [
G4     2        e     u  ]
A4     6        q.    u
Bf4    2        e     d
measure 7
C5     2        e     d  [      (
D5     2        e     d  =      )
Ef5    2        e     d  =      (
D5     2        e     d  ]      )
C5     6        q.    d
C5     2        e     d
measure 8
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  ]
Bf4    4        q     d
C5     4        q     d
measure 9
F#4    6        q.    u
F#4    2        e     u
G4     2        e     u  [
F4     1        s     u  =[
Ef4    1        s     u  ]]
D4     2        e     u  [
C4     2        e     u  ]
measure 10
B3     3        e.    u  [
B3     1        s     u  =\
B3     2        e     u  =
D5     2        e     d  ]
Ef5    2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ]]
Bf4    2        e     u  [      +
Af4    2        e     u  ]
measure 11
G4     3        e.    u  [
G4     1        s     u  =\
G4     2        e     u  =
A4     2        e     u  ]
B4     4        q     d
C5     4        q     d
measure 12
C5     4        q     d
B4     4        q     d
C5     4        q     d
rest   4        q
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
Ef5    2        e     d
measure 16
F5     4        q     d
rest   2        e
F5     2        e     d
G5     4        q     d
rest   2        e
G4     2        e     u
measure 17
Af4    4        q     u
rest   2        e
Af4    2        e     u
Bf4    4        q     d
rest   4        q
measure 18
rest   2        e
Bf4    2        e     d  [
C5     2        e     d  =
D5     2        e     d  ]
Ef5    4        q     d
rest   4        q
measure 19
rest   2        e
F5     2        e     d  [
G5     2        e     d  =
A5     2        e     d  ]
Bf5    4        q     d
rest   4        q
measure 20
rest   8        h
rest   4        q
rest   2        e
Bf4    2        e     d
measure 21
C5     4        q     d
rest   2        e
C5     2        e     d
D5     4        q     d
Ef5    4-       q     d        -
measure 22
Ef5    4        q     d
D5     4        q     d
rest   2        e
D5     2        e     d  [
C5     2        e     d  =
F5     2        e     d  ]
measure 23
Bf4    4        q     d
Ef5    4        q     d
rest   2        e
Ef5    2        e     d  [
D5     2        e     d  =
G5     2        e     d  ]
measure 24
C5     4        q     d
C5     4-       q     d        -
C5     2        e     d  [
Bf4    1        s     d  =[
Af4    1        s     d  ]]
G4     2        e     u  [
F4     2        e     u  ]
measure 25
E4     8        h     u
rest   8        h
measure 26
rest   8        h
rest   4        q
rest   2        e
G5     2        e     d
measure 27
Af5    2        e     d  [
G5     1        s     d  =[
F5     1        s     d  ]]
Ef5    2        e     d  [
Df5    2        e     d  ]
C5     3        e.    d  [
C5     1        s     d  =\
C5     2        e     d  =
Bf4    2        e     d  ]
measure 28
Bf4    3        e.    d  [
Bf4    1        s     d  =\
Bf4    2        e     d  =
C5     2        e     d  ]
Af4    4        q     u
G4     4        q     u
measure 29
G4     6        q.    u         &t
G4     2        e     u
F4     4        q     u
rest   2        e
C5     2        e     d
measure 30
Bf4    4        q     u
Bf4    2        e     u  [
Bf4    2        e     u  ]
Bf4    2        e     u  [
F4     2        e     u  ]
Bf4    4        q     u
measure 31
rest   2        e
Bf4    2        e     d
C5     4        q     d
rest   4        q
D5     4-       q     d        -
measure 32
D5     4        q     d
C5     2        e     d  [
Bf4    2        e     d  ]
Ef5    6        q.    d
Ef5    2        e     d
measure 33
D5     4        q     d
rest   2        e
Bf4    2        e     d
D5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 34
F4     3        e.    u  [
F4     1        s     u  =\
F4     2        e     u  =
F4     2        e     u  ]
F5     2        e     d  [
Ef5    1        s     d  =[
D5     1        s     d  ]]
C5     2        e     d  [
Bf4    2        e     d  ]
measure 35
A4     3        e.    u  [
A4     1        s     u  =\
A4     2        e     u  =
Bf4    2        e     u  ]
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 36
Ef5    3        e.    d  [
Ef5    1        s     d  =\
Ef5    2        e     d  =
F5     2        e     d  ]
D5     6        q.    d
C5     2        e     d
measure 37
C5     6        q.    d         &t
Bf4    2        e     d
Bf4    4        q     d
rest   2        e
Ef5    2        e     d
measure 38
F5     4        q     d
rest   2        e
F5     2        e     d
G5     4        q     d
Af5    4        q     d
measure 39
rest   2        e
Af5    2        e     d  [
G5     2        e     d  =
C6     2        e     d  ]
F5     4        q     d
Bf5    4        q     d
measure 40
rest   2        e
Ef5    2        e     d  [
Af5    2        e     d  =
Af5    2        e     d  ]
F5     2        e     d  [
Bf4    2        e     d  ]
Ef5    4        q     d
measure 41
rest   4        q
F5     4        q     d
rest   2        e
F5     2        e     d  [
Ef5    2        e     d  =
D5     2        e     d  ]
measure 42
G5     4        q     d
rest   4        q
rest   2        e
G5     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  ]
measure 43
Af5    6        q.    d
Af5    2        e     d
G5     4        q     d
rest   2        e
Ef5    2        e     d
measure 44
G5     2        e     d  [
F5     1        s     d  =[
Ef5    1        s     d  ]]
D5     2        e     d  [
C5     2        e     d  ]
Bf4    6        q.    d
Bf4    2        e     d
measure 45
Bf4    6        q.    d
Ef5    2        e     d
Bf5    2        e     d  [
Af5    1        s     d  =[
G5     1        s     d  ]]
F5     2        e     d  [
Ef5    2        e     d  ]
measure 46
D5     3        e.    d  [
Ef5    1        s     d  =\
F5     2        e     d  =
G5     2        e     d  ]
Af5    6        q.    d
G5     2        e     d
measure 47
C6     3        e.    d  [
C5     1        s     d  =\
D5     2        e     d  =
Ef5    2        e     d  ]
D5     3        e.    d  [
C5     1        s     d  ]\
Bf4    4        q     d
measure 48
rest   4        q
$ D:Adagio
Ef5    4        q     d
D5     4        q     d
Ef5    4        q     d
measure 49
Ef5    8        h     d
D5     8        h     d
measure 50
Ef5   16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/2} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:ca83c0b52daf3664862d2586edc44e82]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
G4     2        e     u
Af4    4        q     u
rest   2        e
Af4    2        e     u
measure 2
Bf4    4        q     u
Af4    4        q     u
rest   2        e
Bf4    2        e     u  [
Af4    2        e     u  =
G4     2        e     u  ]
measure 3
D5     2        e     d  [
Bf4    2        e     d  ]
Bf5    4-       q     d        -
Bf5    2        e     d  [
Bf5    2        e     d  =
A5     3        e.    d  =
A5     1        s     d  ]\
measure 4
Bf5    2        e     d  [
F4     2        e     u  =
Bf4    2        e     u  =
G4     2        e     u  ]
A4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  =
G4     2        e     u  ]
measure 5
A4     4        q     u
rest   4        q
rest   4        q
rest   2        e
D4     2        e     u
measure 6
F4     2        e     u  [
Ef4    1        s     u  =[
D4     1        s     u  ]]
C4     2        e     u  [
Bf3    2        e     u  ]
C4     3        e.    u  [
C4     1        s     u  =\
C4     2        e     u  =
Bf4    2        e     u  ]
measure 7
A4     2        e     u
G4     4        q     u
F#4    2        e     u
G4     6        q.    u
G4     2        e     u
measure 8
F#4    2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
G4     2        e     u  [
A4     1        s     u  =[
Bf4    1        s     u  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 9
D5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     u  [
A4     2        e     u  ]
D4     3        e.    u  [
G3     1        s     u  =\
G3     2        e     u  =
C5     2        e     d  ]
measure 10
G5     2        e     d  [
F5     1        s     d  =[
Ef5    1        s     d  ]]
D5     2        e     d  [
C5     1        s     d  =[
B4     1        s     d  ]]
C5     2        e     u  [
G4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
measure 11
G4     3        e.    u  [
F4     1        s     u  =\
Ef4    2        e     u  =
Ef4    2        e     u  ]
D4     4        q     u
C4     4        q     u
measure 12
G4     6        q.    u
F4     2        e     u
Ef4    4        q     u
rest   2        e
Ef4    2        e     u
measure 13
F4     4        q     u
rest   2        e
F4     2        e     u
G4     4        q     u
Af4    4        q     u
measure 14
rest   2        e
G4     2        e     u  [
F4     2        e     u  =
Ef4    2        e     u  ]
Bf4    2        e     u  [
F4     2        e     u  ]
Bf4    4-       q     u        -
measure 15
Bf4    2        e     u  [
Bf4    2        e     u  =
A4     3        e.    u  =
A4     1        s     u  ]\
Bf4    4        q     u
rest   4        q
measure 16
rest  16
measure 17
rest   2        e
D4     2        e     u  [
Ef4    2        e     u  =
F4     2        e     u  ]
Bf3    4        q     u
rest   4        q
measure 18
rest   2        e
Ef4    2        e     u
Af4    4        q     u
rest   2        e
G4     2        e     u  [
Af4    2        e     u  =
Bf4    2        e     u  ]
measure 19
Ef4    4        q     u
rest   2        e
Ef5    2        e     d
D5     4        q     d
rest   4        q
measure 20
rest   8        h
rest   2        e
F4     2        e     u
Bf4    4-       q     u        -
measure 21
Bf4    4        q     u
A4     2        e     u  [
A4     2        e     u  ]
Bf4    4        q     u
rest   2        e
Ef4    2        e     u
measure 22
F4     4        q     u
rest   2        e
F4     2        e     u
G4     4        q     u
Af4    4        q     u
measure 23
rest   2        e
Af4    2        e     u  [
G4     2        e     u  =
C5     2        e     u  ]
F4     4        q     u
Bf4    4-       q     u        -
measure 24
Bf4    4        q     u
Af4    2        e     u  [
F4     2        e     u  ]
Df5    6        q.    d
Bf4    2        e     d
measure 25
C5     4        q     d
rest   2        e
G4     2        e     u
Af4    2        e     u  [
G4     1        s     u  =[
F4     1        s     u  ]]
Ef4    2        e     u  [
Df4    2        e     u  ]
measure 26
C4     4        q     u
rest   4        q
rest   8        h
measure 27
rest   4        q
rest   2        e
Bf4    2        e     d
Af4    3        e.    u  [
Af4    1        s     u  =\
G4     2        e     u  =
F4     2        e     u  ]
measure 28
E4     3        e.    u  [
E4     1        s     u  =\
E4     2        e     u  =
G4     2        e     u  ]
F4     4        q     u
F4     4        q     u
measure 29
F4     4        q     u
E4     4        q     u
F4     2        e     u  [
G4     2        e     u  ]
Af4    4        q     u
measure 30
Af4    4        q     u
G4     2        e     u  [
G4     2        e     u  ]
F4     4        q     u
rest   2        e
F4     2        e     u
measure 31
G4     4        q     u
rest   2        e
G4     2        e     u
A4     4        q     u
rest   4        q
measure 32
D4     8        h     u
G4     6        q.    u
G4     2        e     u
measure 33
F4     4        q     u
rest   4        q
rest   8        h
measure 34
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u
measure 35
F5     2        e     d  [
Ef5    1        s     d  =[
D5     1        s     d  ]]
C5     2        e     d  [
Bf4    2        e     d  ]
A4     3        e.    u  [
A4     1        s     u  =\
A4     2        e     u  =
Bf4    2        e     u  ]
measure 36
F4     3        e.    u  [
G4     1        s     u  =\
A4     2        e     u  =
F4     2        e     u  ]
Bf4    4        q     u
Bf4    4        q     u
measure 37
Bf4    4        q     u
A4     3        e.    u  [
Ef4    1        s     u  ]\
D4     2        e     u  [
Bf4    2        e     u  ]
Ef5    4        q     d
measure 38
rest   4        q
D5     4        q     d
rest   2        e
D5     2        e     d  [
C5     2        e     d  =
F5     2        e     d  ]
measure 39
Bf4    4        q     d
Ef5    4        q     d
rest   2        e
Ef5    2        e     d  [
D5     2        e     d  =
G5     2        e     d  ]
measure 40
C5     4        q     d
rest   2        e
F5     2        e     d
D5     4        q     d
rest   2        e
Bf4    2        e     d
measure 41
C5     4        q     d
rest   4        q
D5     4        q     d
rest   4        q
measure 42
rest   2        e
D5     2        e     d  [
C5     2        e     d  =
Bf4    2        e     d  ]
Ef5    4        q     d
rest   4        q
measure 43
rest   2        e
D5     2        e     d  [
Ef5    2        e     d  =
F5     2        e     d  ]
Bf4    4        q     d
rest   4        q
measure 44
rest   8        h
rest   4        q
rest   2        e
G4     2        e     u
measure 45
Bf4    2        e     u  [
Af4    1        s     u  =[
G4     1        s     u  ]]
F4     2        e     u  [
Ef4    2        e     u  ]
F4     6        q.    u
G4     2        e     u
measure 46
Bf4    3        e.    d  [
C5     1        s     d  =\
D5     2        e     d  =
Ef5    2        e     d  ]
F5     6        q.    d
Ef5    2        e     d
measure 47
Ef5    3        e.    d  [
Ef5    1        s     d  =\
D5     2        e     d  =
C5     2        e     d  ]
Bf4    3        e.    u  [
F4     1        s     u  ]\
F4     4        q     u
measure 48
rest   4        q
$ D:Adagio
Bf4    4        q     u
Af4    4        q     u
G4     4        q     u
measure 49
F4    12        h.    u
Af4    2        e     u  [
G4     2        e     u  ]
measure 50
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/3} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:ea5a0b8a9f60f4c22ca7d26a09c822b8]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:13
rest   4        q
rest   2        e
Bf3    2        e     u
F4     4        q     d
rest   2        e
F4     2        e     d
measure 2
Ef4    4        q     d
Ef4    4        q     d
rest   2        e
Bf3    2        e     d  [
F4     2        e     d  =
Bf4    2        e     d  ]
measure 3
Bf4    2        e     d  [
D4     2        e     d  =
D5     2        e     d  =
D4     2        e     d  ]
G4     4        q     d
rest   2        e
F4     2        e     d
measure 4
F4     2        e     u  [
Bf3    2        e     u  =
G3     2        e     u  =
C4     2        e     u  ]
F3     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  =
E4     2        e     u  ]
measure 5
C4     4        q     d
rest   4        q
rest   4        q
rest   2        e
Bf3    2        e     u
measure 6
D4     2        e     u  [
C4     1        s     u  =[
Bf3    1        s     u  ]]
A3     2        e     u  [
G3     2        e     u  ]
F3     3        e.    u  [
F3     1        s     u  =\
F3     2        e     u  =
G3     2        e     u  ]
measure 7
A3     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
Ef4    6        q.    d
Ef4    2        e     d
measure 8
D4     6        q.    d
D4     2        e     d
D4     4        q     d
A3     4        q     u
measure 9
A3     2        e     d  [
A4     1        s     d  =[
G4     1        s     d  ]]
F#4    2        e     d  [
A3     2        e     d  ]
Bf3    6        q.    u
F4     2        e     d
measure 10
D4     6        q.    d
G4     2        e     d
G4     2        e     d  [
F4     1        s     d  =[
Ef4    1        s     d  ]]
D4     2        e     d  [
Bf3    2        e     d  ]
measure 11
Bf3    2        e     u  [
G3     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
G3     4        q     u
F4     4        q     d
measure 12
Ef4    4        q     d
D4     2        e     u  [
G3     2        e     u  ]
G3     4        q     u
rest   4        q
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
rest   2        e
Bf3    2        e     u
measure 15
C4     4        q     d
rest   2        e
C4     2        e     d
D4     4        q     d
Ef4    4        q     d
measure 16
rest   2        e
Ef4    2        e     d  [
D4     2        e     d  =
F4     2        e     d  ]
Bf3    2        e     u  [
Bf3    2        e     u  ]
Ef4    4        q     d
measure 17
rest   8        h
rest   2        e
Ef4    2        e     d  [
F4     2        e     d  =
G4     2        e     d  ]
measure 18
C4     4        q     d
rest   2        e
Bf3    2        e     u
Bf3    4        q     u
rest   4        q
measure 19
rest   8        h
rest   2        e
F3     2        e     u
Bf3    4-       q     u        -
measure 20
Bf3    4        q     u
A3     2        e     u  [
A3     2        e     u  ]
Bf3    4        q     u
rest   4        q
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest   8        h
rest   4        q
rest   2        e
G4     2        e     d
measure 26
C5     2        e     d  [
Bf4    1        s     d  =[
Af4    1        s     d  ]]
G4     2        e     d  [
F4     2        e     d  ]
E4     3        e.    d  [
D4     1        s     d  ]\
C4     4        q     d
measure 27
rest   4        q
rest   2        e
Ef4    2        e     d         +
Ef4    3        e.    u  [
F4     1        s     u  =\
C4     2        e     u  =
F3     2        e     u  ]
measure 28
G3     3        e.    u  [
G3     1        s     u  =\
G3     2        e     u  =
C4     2        e     u  ]
C4     4        q     d
Df4    4        q     d
measure 29
C4     6        q.    d
Bf3    2        e     u
Af3    4        q     u
rest   2        e
F4     2        e     d
measure 30
F4     4        q     d
Ef4    2        e     d  [
Ef4    2        e     d  ]
D4     4        q     d
rest   2        e
D4     2        e     d
measure 31
Bf3    4        q     u
rest   2        e
Ef4    2        e     d
C4     4        q     d
rest   4        q
measure 32
Bf3   12        h.    u
C4     4        q     d
measure 33
D4     4        q     d
rest   4        q
rest   4        q
rest   2        e
D4     2        e     d
measure 34
F4     2        e     d  [
Ef4    1        s     d  =[
D4     1        s     d  ]]
C4     2        e     u  [
Bf3    2        e     u  ]
A3     3        e.    u  [
A3     1        s     u  =\
A3     2        e     u  =
D4     2        e     u  ]
measure 35
C4     3        e.    d  [
F4     1        s     d  =\
F4     2        e     d  =
D4     2        e     d  ]
C4     3        e.    d  [
D4     1        s     d  =\
Ef4    2        e     d  =
F4     2        e     d  ]
measure 36
C5     3        e.    d  [
Bf4    1        s     d  =\
C5     2        e     d  =
C5     2        e     d  ]
F4     4        q     d
G4     4        q     d
measure 37
F4     4        q     d
F4     4        q     d
F4     4        q     d
rest   4        q
measure 38
rest  16
measure 39
rest  16
measure 40
rest   8        h
rest   4        q
rest   2        e
G4     2        e     d
measure 41
Ef4    4        q     d
rest   4        q
Bf4    4        q     d
rest   4        q
measure 42
rest   4        q
rest   2        e
Bf4    2        e     d
G4     4        q     d
rest   2        e
G4     2        e     d
measure 43
C5     6        q.    d
Bf4    2        e     d
Ef5    4        q     d
rest   4        q
measure 44
rest   4        q
rest   2        e
Ef4    2        e     d
G4     2        e     d  [
F4     1        s     d  =[
Ef4    1        s     d  ]]
D4     2        e     d  [
C4     2        e     d  ]
measure 45
Bf3    3        e.    u  [
Bf3    1        s     u  =\
Bf3    2        e     u  =
C4     2        e     u  ]
D4     6        q.    d
Ef4    2        e     d
measure 46
F4     3        e.    d  [
G4     1        s     d  =\
Af4    2        e     d  =
G4     2        e     d  ]
Bf4    3        e.    d  [
Bf4    1        s     d  =\
Bf4    2        e     d  =
Bf4    2        e     d  ]
measure 47
F4     3        e.    d  [
F4     1        s     d  =\
F4     2        e     d  =
F4     2        e     d  ]
F4     3        e.    d  [
Ef4    1        s     d  ]\
D4     4        q     d
measure 48
rest   4        q
$ D:Adagio
Ef4    4        q     d
F4     4        q     d
Bf3    4        q     u
measure 49
Bf3   12        h.    u
Bf3    4        q     u
measure 50
Bf3   16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/4} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:a72255bc3688f640fd8f149566d62ea4]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
Ef5    2        e     d                    But
Ef5    2        e     d  [                 thanks,_
D5     2        e     d  ]                 _
rest   2        e
D5     2        e     d                    but
measure 2
Ef5    4        q     d                    thanks,
C5     4        q     d                    thanks,
rest   2        e
Ef5    2        e     d                    thanks
D5     2        e     d                    be
Ef5    2        e     d                    to
measure 3
F5     4        q     d                    God,
rest   2        e
Bf4    2        e     d                    but
C5     4        q     d                    thanks,
rest   2        e
C5     2        e     d                    but
measure 4
D5     4        q     d                    thanks,
Ef5    4        q     d                    thanks,
rest   2        e
D5     2        e     d                    thanks
C5     2        e     d                    be
Bf4    2        e     d                    to
measure 5
F5     4        q     d                    God,
rest   2        e
Bf4    2        e     d                    who
D5     2        e     d                    giv-
C5     1        s     d  [[                eth_
Bf4    1        s     d  ]]                _
A4     2        e     u                    us
G4     2        e     u                    the
measure 6
F4     3        e.    u                    vic-
F4     1        s     u                    to-
F4     2        e     u                    ry,
G4     2        e     u                    the
A4     3        e.    u                    vic-
A4     1        s     u                    to-
A4     2        e     u                    ry,
Bf4    2        e     d                    through
measure 7
C5     2        e     d  [                 our_
D5     2        e     d  ]                 _
Ef5    2        e     d  [                 Lord_
D5     2        e     d  ]                 _
C5     6        q.    d                    Je-
C5     2        e     d                    sus
measure 8
D5     8        h     d                    Christ,
rest   8        h
measure 9
rest  16
measure 10
rest   4        q
rest   2        e
D5     2        e     d                    who
Ef5    2        e     d                    giv-
D5     1        s     d  [[                eth_
C5     1        s     d  ]]                _
Bf4    2        e     d                    us
Af4    2        e     u                    the
measure 11
G4     3        e.    u                    vic-
G4     1        s     u                    to-
G4     2        e     u                    ry,
A4     2        e     u                    through
B4     4        q     d                    our
C5     4        q     d                    Lord
measure 12
C5     4        q     d                    Je-
B4     4        q     d                    sus
C5     4        q     d                    Christ;
rest   4        q
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
Ef5    2        e     d                    but
measure 16
F5     4        q     d                    thanks,
rest   2        e
F5     2        e     d                    but
G5     4        q     d                    thanks,
rest   2        e
G4     2        e     u                    but
measure 17
Af4    4        q     u                    thanks,
rest   2        e
Af4    2        e     u                    but
Bf4    4        q     d                    thanks,
rest   4        q
measure 18
rest   2        e
Bf4    2        e     d                    thanks
C5     2        e     d                    be
D5     2        e     d                    to
Ef5    4        q     d                    God,
rest   4        q
measure 19
rest   2        e
F4     2        e     u                    thanks
G4     2        e     u                    be
A4     2        e     u                    to
Bf4    4        q     d                    God,
rest   4        q
measure 20
rest   8        h
rest   4        q
rest   2        e
Bf4    2        e     d                    but
measure 21
C5     4        q     d                    thanks,
rest   2        e
C5     2        e     d                    but
D5     4        q     d                    thanks,
Ef5    4-       q     d        -           thanks,_
measure 22
Ef5    4        q     d                    _
D5     4        q     d                    thanks,
rest   2        e
D5     2        e     d                    thanks
C5     2        e     d                    be
F5     2        e     d                    to
measure 23
Bf4    4        q     d                    God,
Ef5    4        q     d                    thanks,
rest   2        e
Ef5    2        e     d                    thanks
D5     2        e     d                    be
G5     2        e     d                    to
measure 24
C5     4        q     d                    God,
C5     4-       q     d        -           thanks_
C5     2        e     d                    _
Bf4    1        s     u  [[                be_
Af4    1        s     u  =]                _
G4     2        e     u  ]                 _
F4     2        e     u                    to
measure 25
E4     8        h     u                    God,
rest   8        h
measure 26
rest   8        h
rest   4        q
rest   2        e
G5     2        e     d                    who
measure 27
Af5    2        e     d                    giv-
G5     1        s     d  [[                eth_
F5     1        s     d  ]]                _
Ef5    2        e     d                    us
Df5    2        e     d                    the
C5     3        e.    d                    vic-
C5     1        s     d                    to-
C5     2        e     d                    ry,
Bf4    2        e     d                    the
measure 28
Bf4    3        e.    d                    vic-
Bf4    1        s     d                    to-
Bf4    2        e     d                    ry,
C5     2        e     d                    through
Af4    4        q     u                    our
G4     4        q     u                    Lord
measure 29
G4     6        q.    u                    Je-
G4     2        e     u                    sus
F4     4        q     u                    Christ;
rest   2        e
C5     2        e     d                    but
measure 30
Bf4    4        q     d                    thanks
Bf4    2        e     d                    be
Bf4    2        e     d                    to
Bf4    2        e     d                    God,
F4     2        e     u                    but
Bf4    4        q     d                    thanks,
measure 31
rest   2        e
Bf4    2        e     d                    but
C5     4        q     d                    thanks,
rest   4        q
D5     4-       q     d        -           thanks_
measure 32
D5     4        q     d                    _
C5     2        e     d                    be
Bf4    2        e     d                    to
Ef5    6        q.    d                    God,
Ef5    2        e     d                    to
measure 33
D5     4        q     d                    God,
rest   2        e
Bf4    2        e     d                    who
D5     2        e     d                    giv-
C5     1        s     d  [[                eth_
Bf4    1        s     d  ]]                _
A4     2        e     u                    us
G4     2        e     u                    the
measure 34
F4     3        e.    u                    vic-
F4     1        s     u                    to-
F4     2        e     u                    ry,
F4     2        e     u                    who
F5     2        e     d                    giv-
Ef5    1        s     d  [[                eth_
D5     1        s     d  ]]                _
C5     2        e     d                    us
Bf4    2        e     d                    the
measure 35
A4     3        e.    u                    vic-
A4     1        s     u                    to-
A4     2        e     u                    ry,
Bf4    2        e     d                    who
C5     2        e     d                    giv-
C5     2        e     d                    eth
C5     2        e     d                    us
D5     2        e     d                    the
measure 36
Ef5    3        e.    d                    vic-
Ef5    1        s     d                    to-
Ef5    2        e     d                    ry,
F5     2        e     d                    through
D5     6        q.    d                    our
C5     2        e     d                    Lord
measure 37
C5     6        q.    d                    Je-
Bf4    2        e     d                    sus
Bf4    4        q     d                    Christ;
rest   4        q
measure 38
rest  16
measure 39
rest  16
measure 40
rest   8        h
rest   2        e
Bf4    2        e     d                    but
Ef5    4        q     d                    thanks,
measure 41
rest   4        q
F5     4        q     d                    thanks,
rest   2        e
F5     2        e     d                    thanks
Ef5    2        e     d                    be
D5     2        e     d                    to
measure 42
G5     8        h     d                    God,
rest   8        h
measure 43
rest   2        e
C5     2        e     d                    thanks
C5     2        e     d                    be
C5     2        e     d                    to
Bf4    4        q     d                    God,
rest   2        e
Ef5    2        e     d                    who
measure 44
G5     2        e     d                    giv-
F5     1        s     d  [[                eth_
Ef5    1        s     d  ]]                _
D5     2        e     d                    us
C5     2        e     d                    the
Bf4    6        q.    d                    vic-
Bf4    2        e     d                    to-
measure 45
Bf4    6        q.    d                    ry,
C5     2        e     d                    through
D5     6        q.    d                    our
Ef5    2        e     d                    Lord
measure 46
F5     6        q.    d                    Je-
G5     2        e     d                    sus
Af5    6        q.    d                    Christ,
G5     2        e     d                    who
measure 47
C5     3        e.    d                    giv-
C5     1        s     d                    eth
D5     2        e     d                    us
Ef5    2        e     d                    the
D5     3        e.    d                    vic-
C5     1        s     d                    to-
Bf4    4        q     d                    ry,
measure 48
rest   4        q
$ D:Adagio
Ef5    4        q     d                    through
D5     4        q     d                    our
Ef5    4        q     d                    Lord
measure 49
Ef5    8        h     d                    Je-
D5     8        h     d                    sus
measure 50
Ef5   16        w     d                    Christ.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/5} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:a23397eca011331976f0ecdc090aa2f1]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
G4     2        e     u                    But
F4     4        q     u                    thanks,
rest   2        e
F4     2        e     u                    but
measure 2
Ef4    4        q     u                    thanks,
Af4    4        q     u                    thanks,
rest   2        e
Ef4    2        e     u                    thanks
Af4    2        e     u                    be
G4     2        e     u                    to
measure 3
F4     2        e     u                    God,
F4     2        e     u                    to
Bf4    4        q     u                    God,
rest   2        e
Bf4    2        e     u                    thanks
A4     3        e.    u                    be
A4     1        s     u                    to
measure 4
Bf4    4        q     u                    God,
rest   4        q
rest   2        e
F4     2        e     u                    thanks
F4     2        e     u                    be
G4     2        e     u                    to
measure 5
A4     4        q     u                    God,
rest   4        q
rest   4        q
rest   2        e
D4     2        e     u                    who
measure 6
F4     2        e     u                    giv-
Ef4    1        s     u  [[                eth_
D4     1        s     u  ]]                _
C4     2        e     u                    us
Bf3    2        e     u                    the
C4     3        e.    u                    vic-
C4     1        s     u                    to-
C4     2        e     u                    ry,
Bf4    2        e     u                    through
measure 7
A4     2        e     u                    our
G4     4        q     u         (          Lord_
F#4    2        e     u         )          _
G4     6        q.    u                    Je-
G4     2        e     u                    sus
measure 8
F#4    8        h     u                    Christ,
rest   8        h
measure 9
rest   4        q
rest   2        e
D4     2        e     u                    who
G4     2        e     u                    giv-
F4     1        s     u  [[     +          eth_
Ef4    1        s     u  ]]                _
D4     2        e     u                    us
C4     2        e     u                    the
measure 10
B3     3        e.    u                    vic-
B3     1        s     u                    to-
B3     2        e     u                    ry,
G4     2        e     u                    who
G4     2        e     u                    giv-
F4     1        s     u  [[                eth_
Ef4    1        s     u  ]]                _
F4     2        e     u                    us
F4     2        e     u                    the
measure 11
G4     3        e.    u                    vic-
F4     1        s     u                    to-
Ef4    2        e     u                    ry,
Ef4    2        e     u                    through
D4     4        q     u                    our
C4     4        q     u                    Lord
measure 12
G4     6        q.    u                    Je-
F4     2        e     u                    sus
Ef4    4        q     u                    Christ;
rest   2        e
Ef4    2        e     u                    but
measure 13
F4     4        q     u                    thanks,
rest   2        e
F4     2        e     u                    but
G4     4        q     u                    thanks,
Af4    4        q     u                    thanks,
measure 14
rest   2        e
G4     2        e     u                    thanks
F4     2        e     u                    be
Ef4    2        e     u                    to
Bf4    8-       h     u        -           God,_
measure 15
Bf4    2        e     u                    _
Bf4    2        e     u                    thanks
A4     3        e.    u                    be
A4     1        s     u                    to
Bf4    4        q     u                    God,
rest   4        q
measure 16
rest  16
measure 17
rest   2        e
D4     2        e     u                    thanks
Ef4    2        e     u                    be
F4     2        e     u                    to
Bf3    4        q     u                    God,
rest   4        q
measure 18
rest   2        e
Ef4    2        e     u                    but
Af4    4        q     u                    thanks,
rest   2        e
G4     2        e     u                    thanks
Af4    2        e     u                    be
Bf4    2        e     u                    to
measure 19
Ef4    4        q     u                    God,
rest   2        e
Ef4    2        e     u                    to
D4     4        q     u                    God,
rest   4        q
measure 20
rest   8        h
rest   2        e
F4     2        e     u                    but
Bf4    4-       q     u        -           thanks_
measure 21
Bf4    4        q     u                    _
A4     2        e     u                    be
A4     2        e     u                    to
Bf4    4        q     u                    God,
rest   4        q
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest   4        q
rest   2        e
G4     2        e     u                    who
Af4    2        e     u                    giv-
G4     1        s     u  [[                eth_
F4     1        s     u  ]]                _
Ef4    2        e     u                    us
Df4    2        e     u                    the
measure 26
C4     3        e.    u                    vic-
C4     1        s     u                    to-
C4     4        q     u                    ry,
rest   8        h
measure 27
rest   4        q
rest   2        e
Bf4    2        e     u                    who
Af4    2        e     u                    giv-
Af4    2        e     u                    eth
G4     2        e     u                    us
F4     2        e     u                    the
measure 28
E4     3        e.    u                    vic-
E4     1        s     u                    to-
E4     2        e     u                    ry,
G4     2        e     u                    through
F4     4        q     u                    our
F4     4        q     u                    Lord
measure 29
F4     4        q     u                    Je-
E4     4        q     u                    sus
F4     2        e     u                    Christ;
G4     2        e     u                    but
Af4    4        q     u                    thanks,
measure 30
Af4    4        q     u                    thanks
G4     2        e     u                    be
G4     2        e     u                    to
F4     4        q     u                    God,
rest   2        e
F4     2        e     u                    but
measure 31
G4     4        q     u                    thanks,
rest   2        e
G4     2        e     u                    but
A4     4        q     u                    thanks,
rest   4        q
measure 32
D4     8        h     u                    thanks
G4     6        q.    u                    be
G4     2        e     u                    to
measure 33
F4     4        q     u                    God,
rest   4        q
rest   8        h
measure 34
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    who
measure 35
F4     2        e     u                    giv-
Ef4    1        s     u  [[                eth_
D4     1        s     u  ]]                _
C4     2        e     u                    us
Bf3    2        e     u                    the
A4     3        e.    u                    vic-
A4     1        s     u                    to-
A4     2        e     u                    ry,
Bf4    2        e     u                    the
measure 36
F4     3        e.    u                    vic-
G4     1        s     u                    to-
A4     2        e     u                    ry,
F4     2        e     u                    through
F4     4        q     u                    our
G4     4        q     u                    Lord
measure 37
F4     6        q.    u                    Je-
F4     2        e     u                    sus
F4     4        q     u                    Christ;
rest   2        e
Ef4    2        e     u                    but
measure 38
F4     4        q     u                    thanks,
rest   2        e
F4     2        e     u                    but
G4     4        q     u                    thanks,
Af4    4        q     u                    thanks,
measure 39
rest   2        e
Af4    2        e     u                    thanks
G4     2        e     u                    be
C5     2        e     d                    to
F4     4        q     u                    God,
Bf4    4        q     u                    thanks,
measure 40
rest   2        e
Ef4    2        e     u                    thanks
Af4    2        e     u                    be
Af4    2        e     u                    to
F4     4        q     u                    God,
rest   2        e
G4     2        e     u                    but
measure 41
Ef4    4        q     u                    thanks,
rest   4        q
Bf4    4        q     u                    thanks,
rest   4        q
measure 42
rest   8        h
rest   2        e
G4     2        e     u                    thanks
F4     2        e     u                    be
Ef4    2        e     u                    to
measure 43
Af4    6        q.    u                    God,
Af4    2        e     u                    to
G4     4        q     u                    God,
rest   4        q
measure 44
rest   8        h
rest   4        q
rest   2        e
G4     2        e     u                    who
measure 45
Bf4    2        e     u                    giv-
Af4    1        s     u  [[                eth_
G4     1        s     u  ]]                _
F4     2        e     u                    us
Ef4    2        e     u                    the
D4     3        e.    u                    vic-
Ef4    1        s     u                    to-
F4     2        e     u                    ry,
G4     2        e     u                    who
measure 46
F4     3        e.    u                    giv-
G4     1        s     u                    eth
Af4    2        e     u                    us
G4     2        e     u                    the
F4     3        e.    u                    vic-
F4     1        s     u                    to-
F4     2        e     u                    ry,
Ef4    2        e     u                    who
measure 47
Ef4    3        e.    u                    giv-
Ef4    1        s     u                    eth
D4     2        e     u                    us
C4     2        e     u                    the
Bf4    3        e.    u                    vic-
F4     1        s     u                    to-
F4     4        q     u                    ry,
measure 48
rest   4        q
$ D:Adagio
Bf4    4        q     u                    through
Af4    4        q     u                    our
G4     4        q     u                    Lord
measure 49
F4    12        h.    u                    Je-
Af4    2        e     u  [                 sus_
G4     2        e     u  ]                 _
measure 50
G4    16        w     u                    Christ.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/6} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:9e5a2031a496d4f909251157c189fe14]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:34
rest   4        q
rest   2        e
Bf3    2        e     u                    But
Af3    4        q     u                    thanks,
rest   2        e
Af3    2        e     u                    but
measure 2
Bf3    4        q     u                    thanks,
Ef4    4        q     d                    thanks,
rest   2        e
Bf3    2        e     u                    thanks
Bf3    2        e     u                    be
Bf3    2        e     u                    to
measure 3
D4     4        q     d                    God,
rest   2        e
D4     2        e     d                    thanks
G4     4        q     d                    be
F4     4        q     d                    to
measure 4
F4     2        e     d                    God,
Bf3    2        e     u                    thanks
G3     2        e     u                    be
C4     2        e     d                    to
F3     4        q     u                    God,
rest   2        e
Bf3    2        e     d                    to
measure 5
C4     4        q     d                    God,
rest   4        q
rest   4        q
rest   2        e
Bf3    2        e     d                    who
measure 6
D4     2        e     d                    giv-
C4     1        s     d  [[                eth_
Bf3    1        s     d  ]]                _
A3     2        e     u                    us
G3     2        e     u                    the
F3     3        e.    u                    vic-
F3     1        s     u                    to-
F3     2        e     u                    ry,
G3     2        e     u                    through
measure 7
A3     2        e     u  [                 our_
Bf3    2        e     u  ]                 _
C4     2        e     d  [                 Lord_
D4     2        e     d  ]                 _
Ef4    6        q.    d                    Je-
Ef4    2        e     d                    sus
measure 8
D4     8        h     d                    Christ,
rest   4        q
rest   2        e
G3     2        e     u                    who
measure 9
D4     2        e     d                    giv-
C4     1        s     d  [[                eth_
Bf3    1        s     d  ]]                _
A3     2        e     u                    us
A3     2        e     u                    the
D4     3        e.    d                    vic-
G3     1        s     u                    to-
G3     2        e     u                    ry,
C4     2        e     d                    who
measure 10
G4     2        e     d                    giv-
F4     1        s     d  [[                eth_
Ef4    1        s     d  ]]                _
D4     2        e     d                    us,
C4     1        s     d  [[                who_
B3     1        s     d  ]]                _
C4     2        e     d                    giv-
C4     2        e     d                    eth
F3     2        e     u                    us
Bf3    2        e     u                    the
measure 11
Bf3    2        e     u                    vic-
G3     2        e     u                    to-
C4     2        e     d                    ry,
C4     2        e     d                    through
G3     4        q     u                    our
F4     4        q     d                    Lord
measure 12
Ef4    4        q     d         (          Je-
D4     2        e     d         )          -
G3     2        e     u                    sus
G3     4        q     u                    Christ;
rest   4        q
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
rest   2        e
Bf3    2        e     d                    but
measure 15
C4     4        q     d                    thanks,
rest   2        e
C4     2        e     d                    but
D4     4        q     d                    thanks,
Ef4    4        q     d                    thanks,
measure 16
rest   2        e
Ef4    2        e     d                    thanks
D4     2        e     d                    be
F4     2        e     d                    to
Bf3    2        e     d                    God,
Bf3    2        e     d                    to
Ef4    4        q     d                    God,
measure 17
rest   8        h
rest   2        e
Ef4    2        e     d                    thanks
F4     2        e     d                    be
G4     2        e     d                    to
measure 18
C4     4        q     d                    God,
rest   2        e
Bf3    2        e     d                    to
Bf3    4        q     d                    God,
rest   4        q
measure 19
rest   8        h
rest   2        e
F3     2        e     u                    but
Bf3    4-       q     u        -           thanks_
measure 20
Bf3    4        q     u                    _
A3     2        e     u                    be
A3     2        e     u                    to
Bf3    4        q     u                    God,
rest   4        q
measure 21
rest   8        h
rest   4        q
rest   2        e
Ef3    2        e     u                    but
measure 22
F3     4        q     u                    thanks,
rest   2        e
F3     2        e     u                    but
G3     4        q     u                    thanks,
Af3    4        q     u                    thanks,
measure 23
rest   2        e
Af3    2        e     u                    thanks
G3     2        e     u                    be
C4     2        e     d                    to
F3     4        q     u                    God,
Bf3    4-       q     u        -           thanks_
measure 24
Bf3    4        q     u                    _
Af3    2        e     u                    be
F3     2        e     u                    to
Df4    6        q.    d                    God,
Df4    2        e     d                    to
measure 25
C4     8        h     d                    God,
rest   4        q
rest   2        e
G3     2        e     u                    who
measure 26
C4     2        e     d                    giv-
Bf3    1        s     u  [[                eth_
Af3    1        s     u  ]]                _
G3     2        e     u                    us
F3     2        e     u                    the
E4     3        e.    d                    vic-
D4     1        s     d                    to-
C4     4        q     d                    ry,
measure 27
rest   4        q
rest   2        e
Ef4    2        e     d         +          who
Ef4    2        e     d                    giv-
F4     2        e     d                    eth
C4     2        e     d                    us
F3     2        e     u                    the
measure 28
G3     3        e.    u                    vic-
G3     1        s     u                    to-
G3     2        e     u                    ry,
C4     2        e     d                    through
C4     4        q     d                    our
Df4    4        q     d                    Lord
measure 29
C4     6        q.    d                    Je-
C4     2        e     d                    sus
C4     4        q     d                    Christ;
rest   2        e
F4     2        e     d                    but
measure 30
F4     4        q     d                    thanks
Ef4    2        e     d                    be
Ef4    2        e     d                    to
D4     4        q     d                    God,
rest   2        e
D4     2        e     d                    but
measure 31
Bf3    4        q     d                    thanks,
rest   2        e
Ef4    2        e     d                    but
C4     4        q     d                    thanks,
rest   4        q
measure 32
Bf3    8        h     d                    thanks
Bf3    4        q     d                    be
C4     4        q     d                    to
measure 33
D4     4        q     d                    God,
rest   4        q
rest   4        q
rest   2        e
D4     2        e     d                    who
measure 34
F4     2        e     d                    giv-
Ef4    1        s     d  [[                eth_
D4     1        s     d  ]]                _
C4     2        e     d                    us
Bf3    2        e     u                    the
A3     3        e.    u                    vic-
A3     1        s     u                    to
A3     2        e     u                    ry,
Bf3    2        e     u                    the
measure 35
C4     3        e.    d                    vic-
F3     1        s     u                    to-
F3     2        e     u                    ry,
D4     2        e     d                    who
C4     3        e.    d                    giv-
D4     1        s     d                    eth
Ef4    2        e     d                    us
F4     2        e     d                    the
measure 36
C4     3        e.    d                    vic-
Bf3    1        s     d                    to-
C4     2        e     d                    ry,
C4     2        e     d                    through
D4     4        q     d                    our
Bf3    4        q     d                    Lord
measure 37
Bf3    4        q     d                    Je-
A3     4        q     u                    sus
D4     2        e     d                    Christ;
Bf3    2        e     d                    but
Ef4    4        q     d                    thanks,
measure 38
rest   4        q
D4     4        q     d                    thanks,
rest   2        e
D4     2        e     d                    thanks
C4     2        e     d                    be
F4     2        e     d                    to
measure 39
Bf3    4        q     d                    God,
Ef4    4        q     d                    thanks,
rest   2        e
Ef4    2        e     d                    thanks
D4     2        e     d                    be
G4     2        e     d                    to
measure 40
C4     4        q     d                    God,
rest   2        e
F4     2        e     d                    to
D4     4        q     d                    God,
rest   2        e
Bf3    2        e     d                    but
measure 41
C4     4        q     d                    thanks,
rest   4        q
D4     4        q     d                    thanks,
rest   4        q
measure 42
rest   2        e
D4     2        e     d                    thanks
C4     2        e     d                    be
Bf3    2        e     d                    to
Ef4    4        q     d                    God,
rest   4        q
measure 43
rest   2        e
D4     2        e     d                    thanks
Ef4    2        e     d                    be
F4     2        e     d                    to
G4     4        q     d                    God,
rest   4        q
measure 44
rest   4        q
rest   2        e
Ef4    2        e     d                    who
G4     2        e     d                    giv-
F4     1        s     d  [[                eth_
Ef4    1        s     d  ]]                _
D4     2        e     d                    us
C4     2        e     d                    the
measure 45
Bf3    3        e.    u                    vic-
Bf3    1        s     u                    to-
Bf3    2        e     u                    ry,
G3     2        e     u                    who
Bf3    2        e     u                    giv-
Af3    1        s     u  [[                eth_
G3     1        s     u  ]]                _
F3     2        e     u                    us
Ef3    2        e     u                    the
measure 46
D4     3        e.    d                    vic-
D4     1        s     d                    to-
D4     2        e     d                    ry,
Ef4    2        e     d                    the
Bf3    3        e.    d                    vic-
Bf3    1        s     d                    to-
Bf3    2        e     d                    ry,
Bf3    2        e     d                    who
measure 47
F4     3        e.    d                    giv-
F4     1        s     d                    eth
F4     2        e     d                    us
F4     2        e     d                    the
F4     3        e.    d                    vic-
Ef4    1        s     d                    to-
D4     4        q     d                    ry,
measure 48
rest   4        q
$ D:Adagio
Ef4    4        q     d                    through
F4     4        q     d                    our
Bf3    4        q     d                    Lord
measure 49
Bf3   12        h.    d                    Je-
Bf3    4        q     d                    sus
measure 50
Bf3   16        w     d                    Christ.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/7} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:c47e167847012020090772cfa1e82d0b]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:22
rest   4        q
rest   2        e
Ef3    2        e     d                    But
F3     4        q     d                    thanks,
rest   2        e
F3     2        e     d                    but
measure 2
G3     4        q     d                    thanks,
Af3    4        q     d                    thanks,
rest   2        e
G3     2        e     d                    thanks
F3     2        e     d                    be
Ef3    2        e     d                    to
measure 3
Bf3    4        q     d                    God,
rest   2        e
G3     2        e     d                    thanks
Ef3    4        q     d                    be
F3     4        q     d                    to
measure 4
Bf2    4        q     u                    God,
rest   4        q
rest   2        e
Bf3    2        e     d                    thanks
A3     2        e     d                    be
G3     2        e     d                    to
measure 5
F3     4        q     d                    God,
rest   4        q
rest   8        h
measure 6
rest  16
measure 7
rest  16
measure 8
rest   4        q
rest   2        e
D3     2        e     d                    who
Bf3    2        e     d                    giv-
A3     1        s     d  [[                eth_
G3     1        s     d  ]]                _
F3     2        e     d                    us
Ef3    2        e     d                    the
measure 9
D3     3        e.    d                    vic-
D3     1        s     d                    to-
D3     2        e     d                    ry,
C3     2        e     u                    the
Bf2    3        e.    u                    vic-
Bf2    1        s     u                    to-
Bf2    2        e     u                    ry,
Af3    2        e     d         +          through
measure 10
G3     6        q.    d                    our
G3     2        e     d                    Lord
C3     4        q     u                    Je-
D3     4        q     d                    sus
measure 11
Ef3    6        q.    d                    Christ,
F3     2        e     d                    through
G3     4        q     d                    our
Af3    4        q     d                    Lord
measure 12
G3     6        q.    d                    Je-
G3     2        e     d                    sus
C3     4        q     u                    Christ;
rest   4        q
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest   8        h
rest   4        q
rest   2        e
Ef3    2        e     d                    but
measure 17
F3     4        q     d                    thanks,
rest   2        e
F3     2        e     d                    but
G3     4        q     d                    thanks,
rest   2        e
Ef3    2        e     d                    but
measure 18
Af3    2        e     d  [                 thanks_
G3     2        e     d  ]                 _
F3     2        e     d                    be
Bf3    2        e     d                    to
Ef3    4        q     d                    God,
rest   2        e
D3     2        e     d                    thanks
measure 19
C3     6        q.    u                    be
C3     2        e     u                    to
Bf2    4        q     u                    God,
rest   2        e
Bf2    2        e     u                    but
measure 20
C3     4        q     u                    thanks,
rest   2        e
C3     2        e     u                    but
D3     4        q     d                    thanks,
rest   2        e
D3     2        e     d                    thanks
measure 21
Ef3    4        q     d                    be
F3     4        q     d                    to
Bf2    4        q     u                    God,
rest   4        q
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   4        q
rest   2        e
G3     2        e     d                    who
Af3    2        e     d                    giv-
G3     1        s     d  [[                eth_
F3     1        s     d  ]]                _
Ef3    2        e     d                    us
Df3    2        e     d                    the
measure 28
C3     3        e.    u                    vic-
C3     1        s     u                    to-
C3     2        e     u                    ry,
E3     2        e     d                    through
F3     4        q     d                    our
Bf2    4        q     u                    Lord
measure 29
C3     6        q.    u                    Je-
C3     2        e     u                    sus
F3     4        q     d                    Christ;
rest   2        e
Ef3    2        e     d         +          but
measure 30
D3     4        q     d                    thanks
Ef3    2        e     d                    be
Ef3    2        e     d                    to
Bf3    4        q     d                    God,
rest   2        e
D3     2        e     d                    but
measure 31
Ef3    4        q     d                    thanks,
rest   2        e
Ef3    2        e     d                    but
F3     4        q     d                    thanks,
rest   4        q
measure 32
G3    12        h.    d                    thanks
F3     2        e     d                    be
Ef3    2        e     d                    to
measure 33
Bf3    4        q     d                    God,
rest   4        q
rest   4        q
rest   2        e
Bf3    2        e     d                    who
measure 34
D4     2        e     d                    giv-
C4     1        s     d  [[                eth_
Bf3    1        s     d  ]]                _
A3     2        e     d                    us
G3     2        e     d                    the
F3     3        e.    d                    vic-
F3     1        s     d                    to-
F3     2        e     d                    ry,
Bf2    2        e     u                    the
measure 35
F3     3        e.    d                    vic-
F3     1        s     d                    to-
F3     2        e     d                    ry,
Bf2    2        e     u                    who
F3     2        e     d                    giv-
Ef3    1        s     d  [[                eth_
D3     1        s     d  ]]                _
C3     2        e     u                    us
Bf2    2        e     u                    the
measure 36
A3     3        e.    d                    vic-
G3     1        s     d                    to-
F3     2        e     d                    ry,
A3     2        e     d                    through
Bf3    4        q     d                    our
Ef3    4        q     d                    Lord
measure 37
F3     6        q.    d                    Je-
F3     2        e     d                    sus
Bf2    4        q     u                    Christ;
rest   4        q
measure 38
rest  16
measure 39
rest  16
measure 40
rest   8        h
rest   4        q
rest   2        e
Ef3    2        e     d                    but
measure 41
Af3    4        q     d                    thanks,
rest   4        q
Bf3    4        q     d                    thanks,
rest   4        q
measure 42
rest   2        e
Bf3    2        e     d                    thanks
Af3    2        e     d                    be
G3     2        e     d                    to
C4     4        q     d                    God,
rest   4        q
measure 43
rest   2        e
Bf3    2        e     d                    thanks
C4     2        e     d                    be
D4     2        e     d                    to
Ef4    4        q     d                    God,
rest   4        q
measure 44
rest   8        h
rest   4        q
rest   2        e
Ef3    2        e     d                    who
measure 45
G3     2        e     d                    giv-
F3     1        s     d  [[                eth_
Ef3    1        s     d  ]]                _
D3     2        e     d                    us
C3     2        e     u                    the
Bf2    3        e.    u                    vic-
Bf2    1        s     u                    to-
Bf2    2        e     u                    ry,
Ef3    2        e     d                    who
measure 46
Bf3    2        e     d                    giv-
Af3    1        s     d  [[                eth_
G3     1        s     d  ]]                _
F3     2        e     d                    us
Ef3    2        e     d                    the
D3     3        e.    d                    vic-
D3     1        s     d                    to-
D3     2        e     d                    ry,
Ef3    2        e     d                    who
measure 47
Af3    3        e.    d                    giv-
Af3    1        s     d                    eth
A3     2        e     d                    us
A3     2        e     d                    the
Bf3    3        e.    d                    vic-
Bf3    1        s     d                    to-
Bf3    4        q     d                    ry,
measure 48
rest   4        q
$ D:Adagio
G3     4        q     d                    through
F3     4        q     d                    our
Ef3    4        q     d                    Lord
measure 49
Bf3    8        h     d                    Je-
Bf2    8        h     u                    sus
measure 50
Ef3   16        w     d                    Christ.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-07/8} [KHM:4047712115]
TIMESTAMP: DEC/26/2001 [md5sum:e242da08f1bea02daa7dd5f2a5791b58]
06/26/90 E. Correia
WK#:56        MV#:3,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
0 19
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:22
Ef3    2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
Ef3    2        e     d  ]
F3     2        e     d  [
G3     2        e     d  =
Af3    2        e     d  =
F3     2        e     d  ]
measure 2
G3     4        q     d
Af3    4        q     d
rest   2        e
G3     2        e     d  [
F3     2        e     d  =
Ef3    2        e     d  ]
measure 3
Bf3    4        q     d
rest   2        e
G3     2        e     d
Ef3    2        e     u  [
C3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
measure 4
Bf2    2        e     d  [
Bf3    2        e     d  =
G3     2        e     d  =
C4     2        e     d  ]
F3     2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
measure 5
F3     4        q     d
$ C:15
rest   2        e
Bf4    2        e     d
D5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     d  [
$ C:12
Bf3    2        e     d  ]
measure 6
D4     2        e     d  [
C4     1        s     d  =[
Bf3    1        s     d  ]]
A3     2        e     u  [
G3     2        e     u  ]
F3     4        q     u
F3     2        e     u  [
G3     2        e     u  ]
measure 7
A3     2        e     d  [
f1              6
Bf3    2        e     d  =
C4     2        e     d  =
f1              #
D4     2        e     d  ]
Ef4    6        q.    d
Ef4    2        e     d
measure 8
D4     6        q.    d
$ C:22
D3     2        e     d
Bf3    2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F3     2        e     d  [
Ef3    2        e     d  ]
measure 9
D3     6        q.    d
C3     2        e     u
Bf2    6        q.    u
Af2    2        e     u         +
measure 10
G2     6        q.    u
G2     2        e     u
C3     4        q     u
D3     4        q     d
measure 11
Ef3    6        q.    d
F3     2        e     d
G3     4        q     d
Af3    4        q     d
measure 12
G3     4        q     d
G2     4        q     u
C3     2        e     d  [
D3     2        e     d  =
Ef3    2        e     d  =
C3     2        e     d  ]
measure 13
Af3    2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
Bf2    2        e     d  ]
Ef3    2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
Ef3    2        e     d  ]
measure 14
D3     2        e     u  [
Ef3    2        e     u  =
Af2    2        e     u  =
C3     2        e     u  ]
Bf2    2        e     d  [
D3     2        e     d  =
G3     2        e     d  =
D3     2        e     d  ]
measure 15
Ef3    2        e     u  [
C3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
G3     2        e     d  =
C4     2        e     d  ]
measure 16
Af3    4        q     d
Bf3    2        e     d  [
D3     2        e     d  ]
Ef3    4        q     d
rest   2        e
Ef3    2        e     d
measure 17
F3     4        q     d
rest   2        e
F3     2        e     d
G3     4        q     d
rest   2        e
Ef3    2        e     d
measure 18
Af3    2        e     d  [
G3     2        e     d  =
F3     2        e     d  =
Bf3    2        e     d  ]
Ef3    4        q     d
rest   2        e
D3     2        e     d
measure 19
C3     6        q.    u
C3     2        e     u
Bf2    4        q     u
rest   2        e
Bf2    2        e     u
measure 20
C3     4        q     u
rest   2        e
C3     2        e     u
D3     4        q     d
rest   2        e
D3     2        e     d
measure 21
Ef3    4        q     d
F3     4        q     d
Bf2    2        e     d  [
Bf3    2        e     d  =
G3     2        e     d  =
C3     2        e     d  ]
measure 22
Af2    2        e     u  [
F2     2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
Ef3    2        e     u  [
Ef2    2        e     u  =
F2     2        e     u  =
Ef3    2        e     u  ]
measure 23
D3     2        e     u  [
Bf2    2        e     u  =
C3     2        e     u  =
Af2    2        e     u  ]
Bf2    2        e     u  [
Af2    2        e     u  =
Bf2    2        e     u  =
G2     2        e     u  ]
measure 24
E3     2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
Af3    2        e     d  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
Df4    2        e     d  ]
measure 25
C4     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F3     2        e     d  [
Af3    2        e     d  =
G3     2        e     d  =
Ef3    2        e     d  ]
measure 26
Af3    2        e     u  [
F3     2        e     u  =
C3     2        e     u  =
F2     2        e     u  ]
C3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
E4     2        e     d  ]
measure 27
F4     2        e     d  [
Af3    2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
Af3    2        e     d  [
G3     1        s     d  =[
F3     1        s     d  ]]
Ef3    2        e     d  [
Df3    2        e     d  ]
measure 28
C3     3        e.    u  [
C3     1        s     u  =\
C3     2        e     u  =
E3     2        e     u  ]
F3     4        q     d
Bf2    4        q     u
measure 29
C3     4        q     u
C2     4        q     u
F2     2        e     u  [
C3     2        e     u  =
F3     2        e     u  =
Ef3    2        e     u  ]      +
measure 30
D3     4        q     d
Ef3    4        q     d
Bf3    4        q     d
rest   2        e
D3     2        e     d
measure 31
Ef3    4        q     d
rest   2        e
Ef3    2        e     d
F3     4        q     d
rest   4        q
measure 32
G3    12        h.    d
F3     2        e     d  [
Ef3    2        e     d  ]
measure 33
Bf3    4        q     d
$ C:15
rest   2        e
Bf4    2        e     d
D5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     d  [
$ C:22
Bf3    2        e     d  ]
measure 34
D4     2        e     d  [
C4     1        s     d  =[
Bf3    1        s     d  ]]
A3     2        e     d  [
G3     2        e     d  ]
F3     3        e.    d  [
F3     1        s     d  =\
F3     2        e     d  =
Bf2    2        e     d  ]
measure 35
F3     3        e.    d  [
F3     1        s     d  =\
F3     2        e     d  =
Bf2    2        e     d  ]
F3     2        e     d  [
Ef3    1        s     d  =[
D3     1        s     d  ]]
C3     2        e     u  [
Bf2    2        e     u  ]
measure 36
A2     3        e.    u  [
G2     1        s     u  =\
F2     2        e     u  =
A2     2        e     u  ]
Bf2    4        q     u
Ef3    4        q     d
measure 37
F3     4        q     d
F2     4        q     u
Bf2    2        e     d  [
Bf3    2        e     d  =
G3     2        e     d  =
C4     2        e     d  ]
measure 38
Af3    2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
Bf2    2        e     d  ]
Ef3    4        q     d
F3     4        q     d
measure 39
G3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
Af3    2        e     d  ]
Bf3    4        q     d
rest   2        e
G3     2        e     d
measure 40
Af3    2        e     d  [
G3     2        e     d  =
F3     2        e     d  =
Af3    2        e     d  ]
Bf3    2        e     d  [
Af3    2        e     d  =
G3     2        e     d  =
Ef3    2        e     d  ]
measure 41
Af3    4        q     d
rest   4        q
Bf3    4        q     d
rest   4        q
measure 42
rest   2        e
Bf3    2        e     d  [
Af3    2        e     d  =
G3     2        e     d  ]
C4     4        q     d
rest   4        q
measure 43
rest   2        e
Bf3    2        e     d  [
C4     2        e     d  =
D4     2        e     d  ]
Ef4    4        q     d
$ C:15
rest   2        e
Ef5    2        e     d
measure 44
G5     2        e     d  [
F5     1        s     d  =[
Ef5    1        s     d  ]]
D5     2        e     d  [
$ C:12
Ef4    2        e     d  ]
G4     2        e     d  [
F4     1        s     d  =[
Ef4    1        s     d  ]]
D4     2        e     d  [
$ C:22
Ef3    2        e     d  ]
measure 45
G3     2        e     d  [
F3     1        s     d  =[
Ef3    1        s     d  ]]
D3     2        e     u  [
C3     2        e     u  ]
Bf2    3        e.    u  [
Bf2    1        s     u  =\
Bf2    2        e     u  =
Ef3    2        e     u  ]
measure 46
Bf3    2        e     d  [
Af3    1        s     d  =[
G3     1        s     d  ]]
F3     2        e     d  [
Ef3    2        e     d  ]
D3     3        e.    d  [
D3     1        s     d  =\
D3     2        e     d  =
Ef3    2        e     d  ]
measure 47
Af3    3        e.    d  [
Af3    1        s     d  =\
A3     2        e     d  =
A3     2        e     d  ]
Bf3    3        e.    d  [
Bf2    1        s     d  ]\
Bf2    4        q     u
measure 48
rest   4        q
$ D:Adagio
G3     4        q     d
F3     4        q     d
Ef3    4        q     d
measure 49
Bf3    8        h     d
Bf2    8        h     u
measure 50
Ef3   16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
