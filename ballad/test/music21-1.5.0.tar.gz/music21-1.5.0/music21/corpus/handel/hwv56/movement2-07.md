&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-07/1} [KHM:1822233464]
TIMESTAMP: DEC/26/2001 [md5sum:21915ba443905beb46b77214dfeb7024]
06/10/90 E. Correia
WK#:56        MV#:2,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
0 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:4   D:Largo
Ef5    8        h     d
E5     8-       h     d        -
measure 2
E5     8        h     d
C5     8-       h     d        -
measure 3
C5    16        w     d
measure 4
F#5   16-       w     d        -
measure 5
F#5    8        h     d
D5     8-       h     d        -
measure 6
D5     8        h     d
G4     8-       h     u        -
measure 7
G4    12        h.    u
F#4    3        e.    u  [      t
E4     1        s     u  ]\
measure 8
E4    16-       w     u        -
measure 9
E4    16        w     u
measure 10
C5    16        w     d
measure 11
Ef5   16        w     d
measure 12
F4    16        w     u
measure 13
F4     4        q     u
E4     4        q     u
G4     8-       h     u        -
measure 14
G4    16-       w     u        -
measure 15
G4     8        h     u
F#4    8        h     u
measure 16
B4     8        h     d
C5     8-       h     d        -
measure 17
C5     8        h     d
D4     8        h     u
measure 18
D4     4        q     u
C#4    4        q     u
B3     4        q     u
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-07/2} [KHM:1822233464]
TIMESTAMP: DEC/26/2001 [md5sum:75ebb57f3d0947b5d0f4221379715713]
06/10/90 E. Correia
WK#:56        MV#:2,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
0 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:4   D:Largo
C5     2        h     d
Bf4    2-       h     d        -
measure 2
Bf4    2        h     d
Af4    2        h     u
measure 3
A4     4-       w     u        -+
measure 4
A4     4-       w     u        -
measure 5
A4     2        h     u
Bf4    2-       h     d        -
measure 6
Bf4    2        h     d
E4     2-       h     u        -
measure 7
E4     3        h.    u
D#4    1        q     u         t
measure 8
E4     2        h     u
B4     2-       h     d        -
measure 9
B4     4        w     d
measure 10
E4     2        h     u
F4     2        h     u
measure 11
Bf4    4        w     d
measure 12
D5     4        w     d
measure 13
D5     1        q     d
C#5    1        q     d
C#5    2        h     d
measure 14
E4     4-       w     u        -
measure 15
E4     2        h     u
D4     2        h     u
measure 16
F#4    2        h     u
G4     2-       h     u        -
measure 17
G4     2        h     u
B4     2        h     u
measure 18
B4     1        q     u
A#4    1        q     u
B4     1        q     u
rest   1        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-07/3} [KHM:1822233464]
TIMESTAMP: DEC/26/2001 [md5sum:64c7a1e0d95c60c14844babfd8fd742d]
06/10/90 E. Correia
WK#:56        MV#:2,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
0 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:13   D:Largo
Af4    2        h     d
Bf3    2-       h     u        -
measure 2
Bf3    2        h     u
F4     2-       h     d        -
measure 3
F4     4        w     d
measure 4
C4     4-       w     d        -
measure 5
C4     2        h     d
G3     2-       h     u        -
measure 6
G3     2        h     u
C#4    2        h     d
measure 7
B3     3        h.    u
B3     1        q     u
measure 8
B3     4-       w     u        -
measure 9
B3     4        w     u
measure 10
A4     4        w     d
measure 11
Bf3    4        w     u
measure 12
B3     4        w     u         +
measure 13
A3     1        q     u
A4     1        q     d
E4     2        h     d
measure 14
C#4    4-       w     d        -
measure 15
C#4    2        h     d
B3     2        h     u
measure 16
D4     2        h     d
E4     2-       h     d        -
measure 17
E4     2        h     d
G#4    2        h     d
measure 18
F#4    1        q     d
F#4    1        q     d
F#3    1        q     u
rest   1        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-07/4} [KHM:1822233464]
TIMESTAMP: DEC/26/2001 [md5sum:ad8836e5a0531c9d22c07a8d9880ffb1]
06/10/90 E. Correia
WK#:56        MV#:2,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Tenore
0 72 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:34   D:Largo
rest   4        q
C5     2        e     d                    Thy
C5     2        e     d                    re-
E5     4        q     d         +          buke
rest   2        e
Bf4    2        e     d                    hath
measure 2
E4     4        q     u         +          bro-
E4     2        e     u                    ken
F4     2        e     u                    his
F4     4        q     u                    heart;
rest   4        q
measure 3
rest   4        q
F4     2        e     u                    he
F4     2        e     u                    is
A4     4        q     u         +          full
rest   2        e
G4     2        e     u                    of
measure 4
A4     3        e.    u                    hea-
A4     1        s     u                    vi-
A4     4        q     u                    ness,
rest   4        q
A4     2        e     u                    he
A4     2        e     u                    is
measure 5
C5     4        q     d                    full
rest   2        e
D5     2        e     d                    of
Bf4    3        e.    d                    hea-
Bf4    1        s     d                    vi-
Bf4    4        q     d                    ness;
measure 6
rest   4        q
Bf4    2        e     d                    thy
Bf4    2        e     d                    re-
G4     4        q     u                    buke
rest   2        e
G4     2        e     u                    hath
measure 7
G4     4        q     u                    bro-
G4     2        e     u                    ken
G4     2        e     u                    his
E4     4        q     u                    heart.
rest   4        q
measure 8
rest   4        q
rest   2        e
E4     2        e     u                    He
G#4    4        q     u                    loo-
G#4    2        e     u                    ked
A4     2        e     u                    for
measure 9
B4     4        q     d                    some
rest   2        e
B4     1        s     d                    to
B4     1        s     d                    have
D5     4        q     d                    pi-
D5     2        e     d                    ty
C5     2        e     d                    on
measure 10
A4     4        q     u                    him,
rest   4        q
rest   4        q
A4     1        s     u                    but
A4     1        s     u                    there
C5     1        s     d                    was
F5     1        s     d                    no
measure 11
Ef5    4        q     d                    man;
rest   4        q
Ef5    2        e     d                    neith-
Ef5    2        e     d                    er
G5     2        e     d                    found
Ef5    2        e     d                    he
measure 12
D5     2        e     d                    a-
D5     2        e     d                    ny
rest   4        q
rest   4        q
D5     4        q     d                    to
measure 13
D5     3        e.    d                    com-
A4     1        s     u                    fort
A4     4        q     u                    him.
rest   4        q
rest   2        e
C#5    2        e     d                    He
measure 14
C#5    4        q     d                    loo-
C#5    2        e     d                    ked
B4     2        e     d                    for
C#5    4        q     d                    some
rest   2        e
C#5    1        s     d                    to
C#5    1        s     d                    have
measure 15
E5     4        q     d                    pi-
D5     2        e     d                    ty
C#5    2        e     d                    on
D5     4        q     d                    him,
rest   4        q
measure 16
D5     2        e     d                    but
D5     2        e     d                    there
F#5    2        e     d                    was
D5     2        e     d                    no
C5     4        q     d         +          man;
rest   4        q
measure 17
C5     2        e     d                    neith-
C5     2        e     d                    er
E5     2        e     d                    found
C5     2        e     d                    he
B4     2        e     d                    a-
B4     2        e     d                    ny
rest   2        e
B4     2        e     d                    to
measure 18
B4     3        e.    d                    com-
F#4    1        s     u                    fort
F#4    4        q     u                    him.
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-07/5} [KHM:1822233464]
TIMESTAMP: DEC/26/2001 [md5sum:77e338f3594935db4f47851b4fedb14d]
06/10/90 E. Correia
WK#:56        MV#:2,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
0 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:22   D:Largo
Af2    2        h     u
f2              6n f
G2     2-       h     u        -
measure 2
G2     2        h     u
f1              f
F2     2        h     u
measure 3
f2              4 2
Ef3    4        w     d
measure 4
f2              7 #
D3     4-       w     d        -
measure 5
D3     2        h     d
f1              f
G3     2-       h     d        -
measure 6
G3     2        h     d
f2              7 #
A#2    2        h     u
measure 7
f2              6 4
B2     3        h.    u
f1              #
B2     1        q     u
measure 8
f1              6
G#2    4-       w     u        -
measure 9
G#2    4        w     u
measure 10
f1     2        5
f1              6
A2     4        w     u
measure 11
f1              6f
G2     4        w     u
measure 12
G#2    4        w     u
measure 13
f2              6 4
A2     1        q     u
f2              5 #
A2     1        q     u
f3              7 5 #
A#2    2-       h     u        -
measure 14
A#2    4-       w     u        -
measure 15
A#2    2        h     u
B2     2-       h     u        -
measure 16
B2     2        h     u
f1              6
E3     2-       h     d        -
measure 17
E3     2        h     d
f2              7 #
E#3    2        h     d
measure 18
f2              6 4
F#3    1        q     d
f2              5+ #
F#2    1        q     u
f1              #
B2     1        q     u
rest   1        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
