&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/1} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:8ef54b8218bb6380029a8d04db3f7aca]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:4   D:Allegro
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
rest  32
measure 7
rest  32
measure 8
rest   8        q
rest   4        e
A5     4        e     d         p
Bf5    4        e     d  [
F5     4        e     d  =
Bf4    4        e     d  =
F5     4        e     d  ]
measure 9
rest   4        e
A4     4        e     d  [
C5     4        e     d  =
F5     4        e     d  ]
rest   4        e
C5     4        e     u  [
A4     4        e     u  =
F4     4        e     u  ]
measure 10
rest   4        e
F4     4        e     u  [
A4     4        e     u  =
C5     4        e     u  ]
rest   4        e
F5     4        e     d         f
D5     2        s     d  [[
E5     2        s     d  =]
F5     4        e     d  ]
measure 11
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
E5     6        e.    d  [      &t
F5     2        s     d  ]\
F5     4        e     d  [
C5     4        e     d  ]
F4     8        q     u
measure 12
rest   4        e
F5     4        e     d  [      p
C5     4        e     d  =
A4     4        e     d  ]
rest   4        e
C5     4        e     d  [      pp
F5     4        e     d  =
F4     4        e     d  ]
measure 13
Bf4    4        e     d  [
C5     4        e     d  ]
rest   4        e
C5     4        e     d
A4     4        e     u  [
F4     4        e     u  =
A4     4        e     u  =
C5     4        e     u  ]
measure 14
rest  16        h
rest   4        e
F5     4        e     d  [
A5     4        e     d  =
F5     4        e     d  ]
measure 15
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
E5     6        e.    d  [      &t
F5     2        s     d  ]\
F5     4        e     u  [
C5     4        e     u  =
F4     4        e     u  =
A4     4        e     u  ]
measure 16
rest   4        e
C5     4        e     u  [
G4     4        e     u  =
A4     4        e     u  ]
rest   4        e
Bf4    4        e     d  [
G4     4        e     d  =
G5     4        e     d  ]
measure 17
rest   4        e
A5     4        e     d  [
F5     4        e     d  =
C5     4        e     d  ]
rest   4        e
C5     4        e     u  [
A4     4        e     u  =
F4     4        e     u  ]
measure 18
rest   4        e
G4     4        e     u  [
E4     4        e     u  =
G4     4        e     u  ]
rest   4        e
A4     4        e     u  [
A3     4        e     u  =
A5     4        e     d  ]      fi
measure 19
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
E5     6        e.    d  [      &t
D5     2        s     d  ]\
D5     8        q     d
rest   8        q
measure 20
rest   4        e
D5     4        e     d  [      pp
Ef5    4        e     d  =      +
C5     4        e     d  ]
rest   4        e
C5     4        e     d  [
B4     4        e     d  =
D5     4        e     d  ]
measure 21
rest   4        e
C5     4        e     d
C5     8        q     d
rest   4        e
D5     4        e     d  [
Ef5    4        e     d  =
C5     4        e     d  ]
measure 22
rest   4        e
D5     4        e     d
D5     8        q     d
rest   4        e
G4     4        e     u  [
G3     4        e     u  =
G5     4        e     d  ]      f
measure 23
F5     4        e     d  [
Ef5    2        s     d  =[
D5     2        s     d  ]]
D5     6        e.    d  [      &t
C5     2        s     d  ]\
C5     8        q     d
rest   8        q
measure 24
rest  32
measure 25
rest  16        h
rest   4        e
C5     4        e     u  [      pp
F5     4        e     u  =
F4     4        e     u  ]
measure 26
Ef4    4        e     u  [
Ef5    4        e     u  =
Bf4    4        e     u  =
C5     4        e     u  ]
D5     8        q     d
rest   8        q
measure 27
rest   4        e
D5     4        e     d
Bf4    8        q     u
rest   4        e
D5     4        e     d
Bf4    8        q     u
measure 28
rest   4        e
Bf4    4        e     d  [
D5     4        e     d  =
Ef5    4        e     d  ]
rest  16        h
measure 29
rest   8        q
rest   4        e
Bf5    4        e     d         f
Af5    4        e     d  [
G5     2        s     d  =[
F5     2        s     d  ]]
F5     6        e.    d  [      &t
Ef5    2        s     d  ]\
measure 30
Ef5    8        q     d
rest   8        q
rest  16        h
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest  16        h
rest   8        q
rest   4        e
Bf5    4        e     d         f
measure 35
A5     2        s     d  [[
G5     2        s     d  =]
F5     4        e     d  ]
rest   8        q
rest   4        e
C5     4        e     d         p
F5     8        q     d
measure 36
rest   8        q
rest   4        e
F5     4        e     d         f
G5     2        s     d  [[
A5     2        s     d  =]
Bf5    4        e     d  ]
rest   4        e
C5     4        e     d
measure 37
D5     2        s     d  [[
Ef5    2        s     d  =]
F5     4        e     d  ]
rest   4        e
F5     4        e     d
Ef5    4        e     d  [
D5     2        s     d  =[
C5     2        s     d  ]]
C5     6        e.    d  [      &t
Bf4    2        s     d  ]\
measure 38
Bf4    8        q     u
Af4    8        q     u
G4     8        q     u
C5     8-       q     d        -
measure 39
C5     8        q     d
Bf4    8        q     u
A4     8        q     u         +
D5     8-       q     d        -
measure 40
D5     8        q     d
C5    16        h     d
Bf4    4        e     d  [
Bf5    4        e     d  ]
measure 41
A5     6        e.    d  [      &t
G5     2        s     d  =\
F5     4        e     d  =
A5     4        e     d  ]
Bf5    6        e.    d  [
C6     2        s     d  ]\
D6     4        e     d  [
C6     2        s     d  =[
Bf5    2        s     d  ]]
measure 42
F5     8-       q     d        -
F5     2        s     d  [[
G5     2        s     d  ==
F5     2        s     d  ==
G5     2        s     d  ]]
Ef5    3        s.    d  [[
D5     1        t     d  ==\
Ef5    2        s     d  ==
F5     2        s     d  ]]
Ef5    2        s     d  [[
F5     2        s     d  ==
Ef5    2        s     d  ==
F5     2        s     d  ]]
measure 43
D5     2        s     d  [[
C5     2        s     d  =]
Bf4    4        e     d  ]
Bf5    4        e     d  [
Bf5    4        e     d  ]
Bf5    8        q     d
Bf5    4        e     d  [
Bf5    4        e     d  ]
measure 44
Bf5   12        q.    d
D6     4        e     d
C6     2        s     d  [[
Bf5    2        s     d  ]]
A5     8        q     d
D6     4        e     d
measure 45
C6     2        s     d  [[
Bf5    2        s     d  =]
A5     4        e     d  ]
rest   4        e
F5     4        e     d
G5     2        s     d  [[
A5     2        s     d  =]
Bf5    4        e     d  ]
rest   4        e
C5     4        e     d
measure 46
D5     2        s     d  [[
Ef5    2        s     d  ]]
F5     8        q     d
F5     4-       e     d        -
F5     8        q     d
Ef5    8-       q     d        -
measure 47
Ef5    8        q     d
D5     8        q     d
C5     6        e.    d  [      &t
Bf4    2        s     d  ]\
C5     8        q     d
measure 48
rest  16        h
C6    12        q.    d
C6     4        e     d
measure 49
C6    16        h     d
Bf5   16-       h     d        -
measure 50
Bf5   16        h     d
A5    16        h     d
measure 51
Bf5   32        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/2} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:9c4cd22acc1794c4664c69e1948e7f07]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:4   D:Allegro
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
rest  32
measure 7
rest  32
measure 8
rest   8        q
rest   4        e
C5     4        e     d         p
Bf4    4        e     u  [
D5     4        e     u  =
F4     4        e     u  =
Bf4    4        e     u  ]
measure 9
rest   4        e
C4     4        e     u  [
A4     4        e     u  =
Bf4    4        e     u  ]
rest   4        e
A4     4        e     u  [
F4     4        e     u  =
C4     4        e     u  ]
measure 10
rest   4        e
D4     4        e     u  [
C4     4        e     u  =
F5     4        e     d  ]
rest   4        e
Bf4    4        e     u  [      f
F4     4        e     u  =
C5     4        e     u  ]
measure 11
Bf4    4        e     u  [
A4     2        s     u  =[
Bf4    2        s     u  ]]
G4     4        e     u  [
C4     4        e     u  ]
C5     4        e     u  [
F4     4        e     u  ]
D4     8        q     u
measure 12
rest   4        e
C5     4        e     u  [      p
F4     4        e     u  =
C5     4        e     u  ]
rest   4        e
F4     4        e     u  [      pp
A4     4        e     u  =
C5     4        e     u  ]
measure 13
E5     4        e     d  [
F5     4        e     d  =
F5     4        e     d  =
E5     4        e     d  ]
F5     4        e     d  [
A4     4        e     d  =
C5     4        e     d  =
F5     4        e     d  ]
measure 14
rest  16        h
rest   4        e
C5     4        e     d  [
F5     4        e     d  =
D5     4        e     d  ]
measure 15
Bf4    4        e     u  [
A4     4        e     u  =
G4     6        e.    u  =
G4     2        s     u  ]\
A4     4        e     u  [
A4     4        e     u  =
C4     4        e     u  =
F4     4        e     u  ]
measure 16
rest   4        e
F5     4        e     d  [
C5     4        e     d  =
F4     4        e     d  ]
rest   4        e
F4     4        e     u  [
E4     4        e     u  =
C5     4        e     u  ]
measure 17
rest   4        e
C5     4        e     u  [
C5     4        e     u  =
F4     4        e     u  ]
rest   4        e
G4     4        e     u  [
F4     4        e     u  =
C4     4        e     u  ]
measure 18
rest   4        e
E4     4        e     u  [
G4     4        e     u  =
E4     4        e     u  ]
rest   4        e
F4     4        e     u  [
E4     4        e     u  =
D4     4        e     u  ]      fi
measure 19
C#5    4        e     d  [
D5     2        s     d  =[
E5     2        s     d  ]]
C#5    6        e.    d  [
D5     2        s     d  ]\
D5     8        q     d
rest   8        q
measure 20
rest   4        e
B4     4        e     d  [      pp
C5     4        e     d  =      +
G4     4        e     d  ]
rest   4        e
Af4    4        e     u  [
G4     4        e     u  =
G4     4        e     u  ]
measure 21
rest   4        e
G4     4        e     u
Ef4    8        q     u
rest   4        e
G4     4        e     u  [
G4     4        e     u  =
C5     4        e     u  ]
measure 22
rest   4        e
B4     4        e     u
B4     8        q     u
rest   4        e
C5     4        e     u  [
Ef4    4        e     u  =
C4     4        e     u  ]      f
measure 23
B4     4        e     d  [
C5     2        s     d  =[
D5     2        s     d  ]]
B4     6        e.    d  [
C5     2        s     d  ]\
C5     8        q     d
rest   8        q
measure 24
rest  32
measure 25
rest  16        h
rest   4        e
C4     4        e     u  [      p&p
C5     4        e     u  =
D4     4        e     u  ]
measure 26
Ef4    4        e     u  [
G4     4        e     u  =
Ef4    4        e     u  =
C4     4        e     u  ]
Bf4    8        q     u
rest   8        q
measure 27
rest   4        e
Bf4    4        e     u
G4     8        q     u
rest   4        e
Bf4    4        e     u
G4     8        q     u
measure 28
rest   4        e
F4     4        e     u  [
F4     4        e     u  =
G4     4        e     u  ]
rest  16        h
measure 29
rest   8        q
rest   4        e
Bf4    4        e     u         f
D5     4        e     d  [
Ef5    2        s     d  =[
F5     2        s     d  ]]
D5     6        e.    d  [
Ef5    2        s     d  ]\
measure 30
Ef5    8        q     d
rest   8        q
rest  16        h
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest  16        h
rest   8        q
rest   4        e
F5     4        e     d         f
measure 35
F5     4        e     d  [
C5     4        e     d  ]
rest   8        q
rest   4        e
A4     4        e     u         p
C5     8        q     d
measure 36
rest   8        q
rest   4        e
Bf4    4        e     u         f
Ef5    4        e     d  [
D5     2        s     d  =[
Ef5    2        s     d  ]]
C5     8        q     d
measure 37
Bf4    8        q     u
rest   4        e
F4     4        e     u
G4     2        s     u  [[
A4     2        s     u  =]
Bf4    4        e     u  ]
rest   4        e
C4     4        e     u
measure 38
D4     2        s     u  [[
Ef4    2        s     u  ]]
F4     8        q     u
F4     4-       e     u        -
F4     8        q     u
Ef4    8        q     u
measure 39
D4     8        q     u
G4    16        h     u
F4     8        q     u
measure 40
Ef5   16        h     d
D5    12        q.    d
E5     4        e     d
measure 41
F5     8        q     d
C5     4        e     d  [
F5     4        e     d  ]
F5     6        e.    d  [
Ef5    2        s     d  =\     +
D5     4        e     d  =
D5     4        e     d  ]
measure 42
C5     6        e.    u  [
Bf4    2        s     u  =\
A4     4        e     u  =
A3     4        e     u  ]
Bf3    3        s.    u  [[
A3     1        t     u  ==\
Bf3    2        s     u  ==
C4     2        s     u  ]]
Bf3    2        s     u  [[
C4     2        s     u  ==
Bf3    2        s     u  ==
C4     2        s     u  ]]
measure 43
D4     2        s     u  [[
Ef4    2        s     u  =]
F4     4        e     u  ]
rest   4        e
G5     4        e     d
F5     2        s     d  [[
Ef5    2        s     d  ]]
D5     8        q     d
G5     4        e     d
measure 44
F5     2        s     d  [[
Ef5    2        s     d  =]
D5     4        e     d  ]
F5     4        e     d  [
F5     4        e     d  ]
F5    12        q.    d
F5     4        e     d
measure 45
F5     4        e     d
F5     8        q     d
F5     4        e     d
Ef5    4        e     d  [
D5     2        s     d  =[
Ef5    2        s     d  ]]
C5     6        e.    d  [
C5     2        s     d  ]\
measure 46
Bf4    8        q     u
Af4    8        q     u
G4     8        q     u
C5     8-       q     d        -
measure 47
C5     8        q     d
Bf4   16        h     u
A4     8        q     u         +
measure 48
rest  16        h
A5    12        q.    d
A5     4        e     d
measure 49
F5    24        h.    d
C5     8        q     d
measure 50
C5    16        h     d
C5    12        q.    d
Ef5    2        s     d  [[
D5     2        s     d  ]]
measure 51
D5    32        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/3} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:41e0477219c754af1793f679cfcb7a5f]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:13   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest   4        q
rest   2        e
A4     2        e     d         p
D4     2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  =
D4     2        e     d  ]
measure 9
rest   2        e
F3     2        e     u  [
F4     2        e     u  =
D4     2        e     u  ]
rest   2        e
F4     2        e     d  [
C4     2        e     d  =
A3     2        e     d  ]
measure 10
rest   2        e
F3     2        e     u  [
F4     2        e     u  =
F4     2        e     u  ]
rest   2        e
D4     2        e     u  [      f
D4     2        e     u  =
A3     2        e     u  ]
measure 11
Bf3    2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
G4     2        e     d  ]
A4     2        e     u  [
C4     2        e     u  ]
Bf3    4        q     u
measure 12
rest   2        e
A4     2        e     d  [      p
F4     2        e     d  =
F4     2        e     d  ]
rest   2        e
F4     2        e     d  [      pp
C5     2        e     d  =
F4     2        e     d  ]
measure 13
G4     2        e     d  [
A4     2        e     d  ]
rest   2        e
C4     2        e     u
C4     2        e     d  [
C5     2        e     d  =
A4     2        e     d  =
F4     2        e     d  ]
measure 14
rest  16
measure 15
rest   2        e
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
C4     2        e     d  [
F4     2        e     d  =
F3     2        e     d  =
C4     2        e     d  ]
measure 16
rest   2        e
F4     2        e     d  [
G4     2        e     d  =
C4     2        e     d  ]
rest   2        e
Bf3    2        e     d  [
Bf3    2        e     d  =
E4     2        e     d  ]
measure 17
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A3     2        e     d  ]
rest   2        e
E4     2        e     d  [
C4     2        e     d  =
A3     2        e     d  ]
measure 18
rest   2        e
Bf3    2        e     d  [
C4     2        e     d  =
Bf4    2        e     d  ]
rest   2        e
A4     2        e     d  [
C#4    2        e     d  =
D5     2        e     d  ]      fi
measure 19
G4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
A4     4        q     d
rest   4        q
measure 20
rest   2        e
G4     2        e     d  [      &pp
G4     2        e     d  =
Ef4    2        e     d  ]
rest   2        e
F4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
measure 21
rest   2        e
Ef4    2        e     d
Ef4    4        q     d
rest   2        e
D4     2        e     d  [
C4     2        e     d  =
G4     2        e     d  ]
measure 22
rest   2        e
G4     2        e     d
G4     4        q     d
rest   2        e
G3     2        e     d  [
C4     2        e     d  =
C5     2        e     d  ]      f
measure 23
F4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
G4     4        q     d
rest   4        q
measure 24
rest  16
measure 25
rest   8        h
rest   2        e
A4     2        e     d  [      p&p
F4     2        e     d  =
D4     2        e     d  ]
measure 26
G3     4        q     u
rest   2        e
F4     2        e     d
F4     4        q     d
rest   4        q
measure 27
rest   2        e
F4     2        e     d
Ef4    4        q     d
rest   2        e
F4     2        e     d
Ef4    4        q     d
measure 28
rest   2        e
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
rest   8        h
measure 29
rest   4        q
rest   2        e
Ef4    2        e     d         f
F4     2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  =
F4     2        e     d  ]
measure 30
G4     1        s     d  [[
Af4    1        s     d  =]
Bf4    2        e     d  ]
rest   4        q
rest   8        h
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest   8        h
rest   4        q
rest   2        e
D5     2        e     d         f
measure 35
C5     1        s     d  [[
Bf4    1        s     d  =]
A4     2        e     d  ]
rest   4        q
rest   2        e
A4     2        e     d         p
F4     4        q     d
measure 36
rest   4        q
rest   2        e
F4     2        e     d         f
Ef4    2        e     d  [
F4     2        e     d  =
A4     2        e     d  =
F4     2        e     d  ]
measure 37
F4     2        e     d  [
Bf4    2        e     d  ]
Bf3    4        q     u
Ef4    2        e     d
Bf3    4        q     u
A3     2        e     u
measure 38
Bf3    1        s     u  [[
C4     1        s     u  ]]
D4     4        q     d
D4     2        e     d
Bf3    4        q     u
G4     4-       q     d        -
measure 39
G4     2        e     d  [
F4     1        s     d  =[
Ef4    1        s     d  ]]
D4     8        h     d
A3     2        e     d  [
A4     2        e     d  ]
measure 40
Bf4    4        q     d
F4     8        h     d
G4     4        q     d
measure 41
C5     4        q     d
F4     2        e     d  [
C4     2        e     d  ]
D4     3        e.    d  [
Ef4    1        s     d  =\
F4     2        e     d  =
F4     2        e     d  ]
measure 42
F4     4        q     d
C4     2        e     d  [
C4     2        e     d  ]
G4     6        q.    d
G4     2        e     d
measure 43
F4     1        s     d  [[
Ef4    1        s     d  =]
D4     2        e     d  ]
rest   2        e
G4     2        e     d
D4     1        s     d  [[
Ef4    1        s     d  ]]
F4     4        q     d
Ef4    2        e     d
measure 44
D4     1        s     d  [[
Ef4    1        s     d  ]]
F4     4        q     d
F4     2        e     d
A4     1        s     d  [[
Bf4    1        s     d  ]]
C5     4        q     d
Bf4    2        e     d
measure 45
F4     1        s     d  [[
G4     1        s     d  =]
A4     2        e     d  ]
rest   2        e
Bf4    2        e     d
Ef4    2        e     d  [
F4     1        s     d  =[
Bf4    1        s     d  ]]
A4     3        e.    d  [
A4     1        s     d  ]\
measure 46
F4     4        q     d
Bf3    4-       q     u        -
Bf3    2        e     d  [
G4     2        e     d  ]
G4     2        e     d  [
F4     1        s     d  =[
Ef4    1        s     d  ]]
measure 47
F4     4        q     d
F4     4        q     d
F4     4        q     d
F4     4        q     d
measure 48
rest   8        h
Ef5    6        q.    d
Ef5    2        e     d
measure 49
D5    12        h.    d
G4     4        q     d
measure 50
F4     8        h     d
F4     6        q.    d
F4     2        e     d
measure 51
F4    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/4} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:d35f7fde48cc643a87a1d243c1d62743]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:4   D:Allegro
rest   8        q
rest   4        e
F4     4        e     u                    His
Bf4    6        e.    d  [                 yoke_
C5     2        s     d  =\                _
D5     4        e     d  ]                 _
C5     2        s     d  [[                is_
Bf4    2        s     d  ]]                _
measure 2
F5     8-       q     d        -           ea-
F5     2        s     d  [[                -
G5     2        s     d  ==                -
F5     2        s     d  ==                -
G5     2        s     d  ]]                -
Ef5    3        s.    d  [[                -
D5     1        t     d  ==\               -
Ef5    2        s     d  ==                -
F5     2        s     d  ]]                -
Ef5    2        s     d  [[                -
F5     2        s     d  ==                -
Ef5    2        s     d  ==                -
F5     2        s     d  ]]                -
measure 3
D5     2        s     d  [[                -
C5     2        s     d  ]]                -
Bf4    4        e     u                    sy,
rest   4        e
Ef5    4        e     d                    his
D5     2        s     d  [[                bur-
C5     2        s     d  ]]                -
Bf4    8        q     u                    then
G5     4        e     d                    is
measure 4
F5     2        s     d  [[                light,_
Ef5    2        s     d  =]                _
D5     4        e     d  ]                 _
rest   4        e
F4     4        e     u                    his
G4     2        s     u  [[                bur-
A4     2        s     u  ]]                -
Bf4    4        e     u                    then,
rest   4        e
F5     4        e     d                    his
measure 5
Ef5    4        e     d  [                 bur-
D5     2        s     d  =[                -
C5     2        s     d  ]]                -
C5     6        e.    d                    then
Bf4    2        s     u                    is
Bf4    8        q     u                    light,
rest   8        q
measure 6
rest  32
measure 7
rest  32
measure 8
rest  32
measure 9
rest  32
measure 10
rest  32
measure 11
rest   8        q
rest   4        e
Bf4    4        e     u                    his
A4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
F4     8        q     u                    then
D5     4        e     d                    is
measure 12
C5     2        s     u  [[                light,_
Bf4    2        s     u  =]                _
A4     4        e     u  ]                 _
rest   4        e
C5     4        e     d                    his
D5     2        s     d  [[                bur-
E5     2        s     d  ]]                -
F5     4        e     d                    then,
rest   4        e
C5     4        e     d                    his
measure 13
Bf4    4        e     u  [                 bur-
A4     2        s     u  =[                -
G4     2        s     u  ]]                -
G4     6        e.    u                    then
F4     2        s     u                    is
F4     8        q     u                    light,
rest   8        q
measure 14
rest   8        q
rest   4        e
G4     4        e     u                    his
A4     2        s     u  [[                bur-
Bf4    2        s     u  ]]                -
C5     8        q     d                    then,
D5     4        e     d                    his
measure 15
E5     4        e     d  [                 bur-
F5     2        s     d  =[                -
G5     2        s     d  ]]                -
E5     6        e.    d                    then
F5     2        s     d                    is
F5     8        q     d                    light,
rest   8        q
measure 16
rest  16        h
rest   8        q
rest   4        e
C5     4        e     d                    his
measure 17
F4     6        e.    u  [                 yoke_
G4     2        s     u  =\                _
A4     4        e     u  ]                 _
G4     2        s     u  [[                is_
F4     2        s     u  ]]                _
C5     8-       q     d        -           ea-
C5     2        s     d  [[                -
D5     2        s     d  ==                -
C5     2        s     d  ==                -
D5     2        s     d  ]]                -
measure 18
Bf4    3        s.    d  [[                -
A4     1        t     d  ==\               -
Bf4    2        s     d  ==                -
C5     2        s     d  ]]                -
Bf4    2        s     d  [[                -
C5     2        s     d  ==                -
Bf4    2        s     d  ==                -
C5     2        s     d  ]]                -
A4     2        s     u  [[                -
G4     2        s     u  ]]                -
F4     4        e     u                    sy,
rest   4        e
D5     4        e     d                    his
measure 19
C#5    4        e     d  [                 bur-
D5     2        s     d  =[                -
E5     2        s     d  ]]                -
C#5    6        e.    d                    then
D5     2        s     d                    is
D5     8        q     d                    light,
rest   8        q
measure 20
rest  16        h
rest   8        q
rest   4        e
G4     4        e     u                    his
measure 21
C5     6        e.    d  [                 yoke_
D5     2        s     d  =\                _
Ef5    4        e     d  ]      +          _
D5     2        s     d  [[                is_
C5     2        s     d  ]]                _
G5     8-       q     d        -           ea-
G5     2        s     d  [[                -
Af5    2        s     d  ==                -
G5     2        s     d  ==                -
Af5    2        s     d  ]]                -
measure 22
F5     3        s.    d  [[                -
Ef5    1        t     d  ==\               -
F5     2        s     d  ==                -
G5     2        s     d  ]]                -
F5     2        s     d  [[                -
G5     2        s     d  ==                -
F5     2        s     d  ==                -
G5     2        s     d  ]]                -
Ef5    2        s     d  [[                -
D5     2        s     d  ]]                -
C5     4        e     d                    sy,
rest   4        e
C5     4        e     d                    his
measure 23
B4     4        e     d  [                 bur-
C5     2        s     d  =[                -
D5     2        s     d  ]]                -
B4     6        e.    u                    then
C5     2        s     d                    is
C5     8        q     d                    light,
rest   8        q
measure 24
rest  32
measure 25
rest  32
measure 26
rest  16        h
rest   8        q
rest   4        e
Ef5    4        e     d                    his
measure 27
D5     2        s     d  [[                bur-
C5     2        s     d  ]]                -
Bf4    8        q     u                    then
G5     4        e     d                    is
F5     2        s     d  [[                light,_
Ef5    2        s     d  =]                _
D5     4        e     d  ]                 _
rest   8        q
measure 28
rest   8        q
rest   4        e
Bf4    4        e     u                    his
C5     2        s     d  [[                bur-
D5     2        s     d  ]]                -
Ef5    4        e     d                    then,
rest   4        e
D5     4        e     d                    his
measure 29
Ef5    2        s     d  [[                bur-
F5     2        s     d  ]]                -
G5     4        e     d                    then,
rest   4        e
Bf4    4        e     u                    his
Af4    4        e     u  [                 bur-
G4     2        s     u  =[                -
F4     2        s     u  ]]                -
F4     6        e.    u                    then
Ef4    2        s     u                    is
measure 30
Ef4    8        q     u                    light,
rest   8        q
rest   8        q
rest   4        e
Bf4    4        e     u                    his
measure 31
Ef4    6        e.    u  [                 yoke_
F4     2        s     u  =\                _
G4     4        e     u  ]                 _
F4     2        s     u  [[                is_
Ef4    2        s     u  ]]                _
Ef5    8-       q     d        -           ea-
Ef5    2        s     d  [[                -
F5     2        s     d  ==                -
Ef5    2        s     d  ==                -
F5     2        s     d  ]]                -
measure 32
D5     3        s.    d  [[                -
C5     1        t     d  ==\               -
D5     2        s     d  ==                -
Ef5    2        s     d  ]]                -
D5     2        s     d  [[                -
Ef5    2        s     d  ==                -
D5     2        s     d  ==                -
Ef5    2        s     d  =]                -
C5     4        e     d  ]                 -
C5     4        e     d                    sy,
rest   4        e
Ef5    4        e     d                    his
measure 33
D5     2        s     d  [[                bur-
C5     2        s     d  ]]                -
Bf4    8        q     u                    then
G5     4        e     d                    is
F5     2        s     d  [[                light,_
Ef5    2        s     d  =]                _
D5     4        e     d  ]                 _
rest   8        q
measure 34
rest  16        h
rest   8        q
rest   4        e
Bf4    4        e     u                    his
measure 35
A4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
F4     8        q     u                    then
D5     4        e     d                    is
C5     2        s     d  [[                light,_
Bf4    2        s     d  =]                _
A4     4        e     d  ]                 _
rest   8        q
measure 36
rest   8        q
rest   4        e
F5     4        e     d                    his
G5     2        s     d  [[                bur-
A5     2        s     d  ]]                -
Bf5    4        e     d                    then,
rest   4        e
C5     4        e     d                    his
measure 37
D5     2        s     d  [[                bur-
Ef5    2        s     d  ]]                -
F5     4        e     d                    then,
rest   4        e
F5     4        e     d                    his
Ef5    4        e     d  [                 bur-
D5     2        s     d  =[                -
C5     2        s     d  ]]                -
C5     6        e.    d                    then
Bf4    2        s     u                    is
measure 38
Bf4    8        q     u                    light,
Af4    8        q     u                    his
G4     8        q     u                    bur-
C5     8-       q     d        -           -
measure 39
C5     8        q     d                    -
Bf4    8        q     u                    -
A4     8        q     u         +          -
D5     8-       q     d        -           -
measure 40
D5     8        q     d                    -
C5    16        h     d                    -
Bf4    4        e     u                    then
Bf4    4        e     u                    is
measure 41
A4     8        q     u                    light,
rest   4        e
A4     4        e     u                    his
Bf4    6        e.    d  [                 yoke_
C5     2        s     d  =\                _
D5     4        e     d  ]                 _
C5     2        s     d  [[                is_
Bf4    2        s     d  ]]                _
measure 42
F5     8-       q     d        -           ea-
F5     2        s     d  [[                -
G5     2        s     d  ==                -
F5     2        s     d  ==                -
G5     2        s     d  ]]                -
Ef5    3        s.    d  [[                -
D5     1        t     d  ==\               -
Ef5    2        s     d  ==                -
F5     2        s     d  ]]                -
Ef5    2        s     d  [[                -
F5     2        s     d  ==                -
Ef5    2        s     d  ==                -
F5     2        s     d  ]]                -
measure 43
D5     2        s     d  [[                -
C5     2        s     d  ]]                -
Bf4    4        e     u                    sy,
Bf4    4        e     u                    and
Bf4    4        e     u                    his
Bf4    8        q     u                    bur-
Bf4    4        e     u                    then
Bf4    4        e     u                    is
measure 44
Bf4   12        q.    u                    light,
F5     4        e     d                    his
F5    12        q.    d                    yoke
F5     4        e     d                    is
measure 45
F5     4        e     d                    ea-
F5     8        q     d                    sy,
F5     4        e     d                    his
G5     2        s     d  [[                bur-
A5     2        s     d  ]]                -
Bf5    4        e     d                    then
rest   4        e
C5     4        e     d                    is
measure 46
D5     2        s     d  [[     (          light,_
Ef5    2        s     d  ]]                _
F5     8        q     d         )          _
F5     4        e     d                    his
F5     8        q     d                    yoke_
Ef5    8-       q     d        -           _
measure 47
Ef5    8        q     d                    _
D5     8        q     d                    is
C5     6        e.    d  [                 ea-
Bf4    2        s     d  ]\                -
C5     8        q     d                    sy,
measure 48
rest  16        h
Ef5   12        q.    d                    and
Ef5    4        e     d                    his
measure 49
D5    24        h.    d                    bur-
C5     8-       q     d        -           -
measure 50
C5    16        h     d                    -
C5    12        q.    d                    then
Bf4    4        e     u                    is
measure 51
Bf4   32        w     u                    light.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/5} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:71f17b8aa4c9020cdb4e116726846a01]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:4   D:Allegro
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
rest  16        h
rest   8        q
rest   4        e
F4     4        e     u                    His
measure 7
Bf3    6        e.    u  [                 yoke_
C4     2        s     u  =\                _
D4     4        e     u  ]                 _
C4     2        s     u  [[                is_
Bf3    2        s     u  ]]                _
F4     8-       q     u        -           ea-
F4     2        s     u  [[                -
G4     2        s     u  ==                -
F4     2        s     u  ==                -
G4     2        s     u  ]]                -
measure 8
Ef4    3        s.    u  [[                -
D4     1        t     u  ==\               -
Ef4    2        s     u  ==                -
F4     2        s     u  ]]                -
Ef4    2        s     u  [[                -
F4     2        s     u  ==                -
Ef4    2        s     u  ==                -
F4     2        s     u  ]]                -
D4     2        s     u  [[                -
C4     2        s     u  ]]                -
Bf3    4        e     u                    sy,
rest   4        e
Bf4    4        e     u                    his
measure 9
A4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
F4     4        e     u                    then
rest   4        e
D4     4        e     u                    is
C4     2        s     u  [[                light,_
Bf3    2        s     u  =]                _
A3     4        e     u  ]                 _
rest   8        q
measure 10
rest  16        h
rest   8        q
rest   4        e
F4     4        e     u                    his
measure 11
E4     4        e     u  [                 bur-
F4     2        s     u  =[                -
G4     2        s     u  ]]                -
E4     6        e.    u                    then
F4     2        s     u                    is
F4     8        q     u                    light,
rest   8        q
measure 12
rest  32
measure 13
rest  32
measure 14
rest  16        h
rest   8        q
rest   4        e
F4     4        e     u                    his
measure 15
Bf4    4        e     u  [                 bur-
A4     4        e     u  ]                 -
G4     6        e.    u                    then
G4     2        s     u                    is
A4     8        q     u                    light,
rest   8        q
measure 16
rest  32
measure 17
rest   8        q
rest   4        e
F4     4        e     u                    his
E4     2        s     u  [[                bur-
D4     2        s     u  ]]                -
C4     8        q     u                    then
A4     4        e     u                    is
measure 18
G4     2        s     u  [[                light,_
F4     2        s     u  =]                _
E4     4        e     u  ]                 _
rest   4        e
E4     4        e     u                    his
F4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
A4     4        e     u                    then,
rest   4        e
A4     4        e     u                    his
measure 19
G4     4        e     u  [                 bur-
F4     2        s     u  =[                -
E4     2        s     u  ]]                -
E4     6        e.    u                    then
D4     2        s     u                    is
D4     8        q     u                    light,
rest   8        q
measure 20
rest  32
measure 21
rest  32
measure 22
rest  32
measure 23
rest   8        q
rest   4        e
G4     4        e     u                    his
C4     6        e.    u  [                 yoke_
D4     2        s     u  =\                _
Ef4    4        e     u  ]                 _
D4     2        s     u  [[                is_
C4     2        s     u  ]]                _
measure 24
F4     8-       q     u        -           ea-
F4     2        s     u  [[                -
G4     2        s     u  ==                -
F4     2        s     u  ==                -
G4     2        s     u  ]]                -
Ef4    3        s.    u  [[                -
D4     1        t     u  ==\               -
Ef4    2        s     u  ==                -
F4     2        s     u  ]]                -
Ef4    2        s     u  [[                -
F4     2        s     u  ==                -
Ef4    2        s     u  ==                -
F4     2        s     u  ]]                -
measure 25
D4     3        s.    u  [[                -
C4     1        t     u  ==\               -
D4     2        s     u  ==                -
Ef4    2        s     u  ]]                -
D4     2        s     u  [[                -
Ef4    2        s     u  ==                -
D4     2        s     u  ==                -
Ef4    2        s     u  =]                -
C4     4        e     u  ]                 -
C4     4        e     u                    sy,
rest   8        q
measure 26
rest   8        q
rest   4        e
Ef4    4        e     u                    his
D4     2        s     u  [[                bur-
C4     2        s     u  ]]                -
Bf3    8        q     u                    then
G4     4        e     u                    is
measure 27
F4     2        s     u  [[                light,_
Ef4    2        s     u  =]                _
D4     4        e     u  ]                 _
rest   8        q
rest   8        q
rest   4        e
C4     4        e     u                    his
measure 28
D4     2        s     u  [[                bur-
Ef4    2        s     u  ]]                -
F4     4        e     u                    then,
rest   4        e
Bf4    4        e     u                    his
Af4    4        e     u  [                 bur-
G4     2        s     u  =[                -
F4     2        s     u  ]]                -
F4     6        e.    u                    then
Ef4    2        s     u                    is
measure 29
Ef4    8        q     u                    light,
rest   4        e
Ef4    4        e     u                    his
D4     4        e     u  [                 bur-
Ef4    2        s     u  =[                -
F4     2        s     u  ]]                -
D4     6        e.    u                    then
Ef4    2        s     u                    is
measure 30
Ef4    8        q     u                    light,
rest   8        q
rest  16        h
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest   8        q
rest   4        e
Bf4    4        e     u                    his
A4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
F4     8        q     u                    then
Ef4    2        s     u  [[                is_
D4     2        s     u  ]]                _
measure 35
C4     8        q     u                    light,
rest   4        e
Bf4    4        e     u                    his
A4     2        s     u  [[                bur-
G4     2        s     u  ]]                -
F4     4        e     u                    then
rest   4        e
C4     4        e     u                    is
measure 36
D4     2        s     u  [[                light,_
E4     2        s     u  =]                _
F4     4        e     u  ]                 _
rest   4        e
Bf4    4        e     u                    his
Ef4    4        e     u                    bur-
F4     4        e     u                    then
rest   4        e
F4     4        e     u                    is
measure 37
F4     8        q     u                    light,
rest   4        e
F4     4        e     u                    his
G4     2        s     u  [[                bur-
A4     2        s     u  ]]                -
Bf4    4        e     u                    then
rest   4        e
C4     4        e     u                    is
measure 38
D4     2        s     u  [[     (          light,_
Ef4    2        s     u  ]]                _
F4     8        q     u         )          _
F4     4        e     u                    his
F4     8        q     u                    bur-
Ef4    8        q     u                    -
measure 39
D4     8        q     u                    -
G4    16        h     u                    -
F4     8        q     u                    -
measure 40
Ef4   16        h     u                    -
D4     8        q     u                    -
D4     4        e     u                    then
E4     4        e     u                    is
measure 41
F4     8        q     u                    light,
rest   4        e
F4     4        e     u                    his
F4     6        e.    u  [                 yoke_
Ef4    2        s     u  =\     +          _
D4     4        e     u  ]                 _
F4     4        e     u                    is
measure 42
F4     8        q     u                    ea-
C4     4        e     u                    sy,
A4     4        e     u                    his
G4    12        q.    u                    yoke
G4     4        e     u                    is
measure 43
F4     4        e     u                    ea-
F4     4        e     u                    sy,
rest   4        e
G4     4        e     u                    his
F4     2        s     u  [[                bur-
Ef4    2        s     u  ]]                -
D4     8        q     u                    then
G4     4        e     u                    is
measure 44
F4     2        s     u  [[     (          light,_
Ef4    2        s     u  ]]                _
D4     8        q     u         )          _
F4     4        e     u                    his
F4     2        s     u  [[     (          yoke_
G4     2        s     u  ]]                _
A4     8        q     u         )          _
Bf4    4        e     u                    is
measure 45
F4     2        s     u  [[                ea-
G4     2        s     u  ]]                -
A4     4        e     u                    sy,
rest   4        e
Bf4    4        e     u                    his
Ef4    4        e     u  [                 bur-
F4     4        e     u  ]                 -
A4     6        e.    u                    then
A4     2        s     u                    is
measure 46
Bf4    8        q     u                    light,
Af4    8        q     u                    his
G4    12        q.    u         (          yoke_
F4     2        s     u  [[                _
Ef4    2        s     u  ]]                _
measure 47
F4     8        q     u         )          _
F4     8        q     u                    is
F4     8        q     u                    ea-
F4     8        q     u                    sy,
measure 48
rest  16        h
A4    12        q.    u                    and
A4     4        e     u                    his
measure 49
F4    24        h.    u         (          bur-
G4     8        q     u                    -
measure 50
F4    16        h     u         )          -
F4    12        q.    u                    then
F4     4        e     u                    is
measure 51
F4    32        w     u                    light.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/6} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:14a9ae1e430b6db3c983eb6495ea92d9]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:34   D:Allegro
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest   8        q
rest   4        e
F3     4        e     u                    His
Bf3    6        e.    d  [                 yoke_
C4     2        s     d  =\                _
D4     4        e     d  ]                 _
C4     2        s     d  [[                is_
Bf3    2        s     d  ]]                _
measure 6
F4     8-       q     d        -           ea-
F4     2        s     d  [[                -
G4     2        s     d  ==                -
F4     2        s     d  ==                -
G4     2        s     d  ]]                -
Ef4    3        s.    d  [[                -
D4     1        t     d  ==\               -
Ef4    2        s     d  ==                -
F4     2        s     d  ]]                -
Ef4    2        s     d  [[                -
F4     2        s     d  ==                -
Ef4    2        s     d  ==                -
F4     2        s     d  ]]                -
measure 7
D4     2        s     d  [[                -
C4     2        s     d  ]]                -
Bf3    4        e     u                    sy,
rest   4        e
Bf3    4        e     u                    his
A3     2        s     u  [[                bur-
G3     2        s     u  ]]                -
F3     8        q     u                    then
D4     4        e     d                    is
measure 8
C4     2        s     d  [[                light,_
Bf3    2        s     d  =]                _
A3     4        e     d  ]                 _
rest   4        e
C4     4        e     d                    his
D4     2        s     d  [[                bur-
Ef4    2        s     d  ]]                -
F4     8        q     d                    then
Ef4    2        s     d  [[                is_
D4     2        s     d  ]]                _
measure 9
C4     8        q     d                    light,
rest   8        q
rest   8        q
rest   4        e
A3     4        e     u                    his
measure 10
Bf3    2        s     d  [[                bur-
C4     2        s     d  ]]                -
D4     4        e     d                    then,
rest   4        e
C4     4        e     d                    his
D4     2        s     d  [[                bur-
E4     2        s     d  ]]                -
F4     4        e     d                    then,
rest   4        e
C4     4        e     d                    his
measure 11
Bf3    4        e     u  [                 bur-
A3     2        s     u  =[                -
Bf3    2        s     u  ]]                -
G3     6        e.    u                    then
F3     2        s     u                    is
F3     8        q     u                    light,
rest   4        e
Bf3    4        e     u                    is
measure 12
A3     2        s     u  [[                light,_
G3     2        s     u  =]                _
F3     4        e     u  ]                 _
rest   8        q
rest  16        h
measure 13
rest  16        h
rest   8        q
rest   4        e
C4     4        e     d                    his
measure 14
D4     2        s     d  [[                bur-
E4     2        s     d  ]]                -
F4     8        q     d                    then
E4     4        e     d                    is
F4     8        q     d                    light,
rest   8        q
measure 15
rest   8        q
rest   4        e
C4     4        e     d                    is
C4     8        q     d                    light,
rest   8        q
measure 16
rest  32
measure 17
rest  32
measure 18
rest  32
measure 19
rest   8        q
rest   4        e
A3     4        e     u                    his
D4     6        e.    d  [                 yoke_
E4     2        s     d  =\                _
F4     4        e     d  ]                 _
E4     2        s     d  [[                is_
D4     2        s     d  ]]                _
measure 20
G4     8-       q     d        -           ea-
G4     2        s     d  [[                -
Af4    2        s     d  ==                -
G4     2        s     d  ==                -
Af4    2        s     d  ]]                -
F4     3        s.    d  [[                -
Ef4    1        t     d  ==\    +          -
F4     2        s     d  ==                -
G4     2        s     d  ]]                -
F4     2        s     d  [[                -
G4     2        s     d  ==                -
F4     2        s     d  ==                -
G4     2        s     d  ]]                -
measure 21
Ef4    2        s     d  [[                -
D4     2        s     d  ]]                -
C4     4        e     d                    sy,
rest   4        e
C4     4        e     d                    his
B3     2        s     u  [[                bur-
A3     2        s     u  ]]                -
G3     8        q     u                    then
Ef4    4        e     d                    is
measure 22
D4     2        s     d  [[                light,_
C4     2        s     d  =]                _
B3     4        e     d  ]                 _
rest   4        e
D4     4        e     d                    his
Ef4    2        s     d  [[                bur-
F4     2        s     d  ]]                -
G4     4        e     d                    then,
rest   4        e
G4     4        e     d                    his
measure 23
F4     4        e     d  [                 bur-
Ef4    2        s     d  =[                -
D4     2        s     d  ]]                -
D4     6        e.    d                    then
C4     2        s     d                    is
C4     8        q     d                    light,
rest   8        q
measure 24
rest  32
measure 25
rest  32
measure 26
rest  32
measure 27
rest   8        q
rest   4        e
Ef4    4        e     d                    his
D4     2        s     d  [[                bur-
C4     2        s     d  ]]                -
Bf3    8        q     d                    then
G4     4        e     d                    is
measure 28
F4     2        s     d  [[                light,_
Ef4    2        s     d  =]                _
D4     4        e     d  ]                 _
rest   8        q
rest  16        h
measure 29
rest  16        h
rest   8        q
rest   4        e
F3     4        e     u                    his
measure 30
G3     2        s     u  [[                bur-
Af3    2        s     u  ]]                -
Bf3    4        e     u                    then,
rest   4        e
C4     4        e     d                    his
D4     4        e     d  [                 bur-
Ef4    2        s     d  =[                -
F4     2        s     d  ]]                -
D4     6        e.    d                    then
Ef4    2        s     d                    is
measure 31
Ef4    8        q     d                    light,
rest   8        q
rest  16        h
measure 32
rest  32
measure 33
rest   8        q
rest   4        e
Ef4    4        e     d                    his
D4     2        s     d  [[                bur-
C4     2        s     d  ]]                -
Bf3    8        q     d                    then
G4     4        e     d                    is
measure 34
F4     8        q     d                    light,
rest   8        q
rest   8        q
rest   4        e
F4     4        e     d                    is
measure 35
F4     8        q     d                    light,
rest   8        q
rest  16        h
measure 36
rest   8        q
rest   4        e
F4     4        e     d                    his
Ef4    4        e     d  [                 bur-
D4     4        e     d  ]                 -
C4     4        e     d                    then
F4     4        e     d                    is
measure 37
D4     8        q     d                    light,
rest   8        q
rest   8        q
rest   4        e
A3     4        e     u                    is
measure 38
Bf3    2        s     d  [[     (          light,_
C4     2        s     d  ]]                _
D4     8        q     d         )          _
D4     4        e     d                    his
Bf3    8        q     d                    bur-
G4     8-       q     d        -           -
measure 39
G4     4        e     d  [                 -
F4     2        s     d  =[                -
Ef4    2        s     d  ]]                -
D4    16        h     d                    -
A3     8        q     u                    -
measure 40
Bf3    8        q     d                    -
F4    16        h     d                    -
Bf3    4        e     d                    then
Bf3    4        e     d                    is
measure 41
C4     8        q     d                    light,
rest   4        e
C4     4        e     d                    his
D4     6        e.    d  [                 yoke_
Ef4    2        s     d  =\                _
F4     4        e     d  ]                 _
D4     4        e     d                    is
measure 42
C4     6        e.    d  [                 ea-
Bf3    2        s     d  ]\                -
A3     4        e     u                    sy,
A3     4        e     u                    is
Bf3    3        s.    d  [[                ea-
A3     1        t     d  ==\               -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
Bf3    2        s     d  [[                -
C4     2        s     d  ==                -
Bf3    2        s     d  ==                -
C4     2        s     d  =]                -
measure 43
D4     4        e     d  ]                 -
D4     4        e     d                    sy,
rest   4        e
Bf3    4        e     d                    his
D4     2        s     d  [[                bur-
Ef4    2        s     d  ]]                -
F4     8        q     d                    then
Ef4    4        e     d                    is
measure 44
D4     2        s     d  [[     (          light,_
Ef4    2        s     d  ]]                _
F4     8        q     d         )          _
D4     4        e     d                    his
A3     2        s     u  [[     (          yoke_
Bf3    2        s     u  ]]                _
C4     8        q     d         )          _
D4     4        e     d                    is
measure 45
A3     2        s     u  [[                ea-
Bf3    2        s     u  ]]                -
C4     4        e     d                    sy,
rest   4        e
F4     4        e     d                    his
Ef4    4        e     d  [                 bur-
D4     4        e     d  ]                 -
C4     4        e     d                    then
F4     4        e     d                    is
measure 46
F4     8        q     d                    light,
Bf3    8        q     d                    his
Bf3    8        q     d                    yoke_
C4     8-       q     d        -           _
measure 47
C4     8        q     d                    _
Bf3    8        q     d                    is
Bf3    8        q     d                    ea-
A3     8        q     u                    sy,
measure 48
rest  16        h
C4    12        q.    d                    and
C4     4        e     d                    his
measure 49
C4    16        h     d                    bur-
Bf3   16-       h     d        -           -
measure 50
Bf3   16        h     d                    -
A3    12        q.    u                    then
Ef4    4        e     d                    is
measure 51
D4    32        w     d                    light.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/7} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:0d9f9fc8fe54b63b6e1e68570cdc5723]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:1/1   C:22   D:Allegro
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
rest  32
measure 7
rest  32
measure 8
rest   8        q
rest   4        e
F3     4        e     d                    His
Bf2    6        e.    u  [                 yoke_
C3     2        s     u  =\                _
D3     4        e     u  ]                 _
C3     2        s     u  [[                is_
Bf2    2        s     u  ]]                _
measure 9
F3     8-       q     d        -           ea-
F3     2        s     d  [[                -
G3     2        s     d  ==                -
F3     2        s     d  ==                -
G3     2        s     d  ]]                -
Ef3    3        s.    d  [[                -
D3     1        t     d  ==\               -
Ef3    2        s     d  ==                -
F3     2        s     d  ]]                -
Ef3    2        s     d  [[                -
F3     2        s     d  ==                -
Ef3    2        s     d  ==                -
F3     2        s     d  ]]                -
measure 10
D3     2        s     u  [[                -
C3     2        s     u  ]]                -
Bf2    4        e     u                    sy,
rest   4        e
A3     4        e     d                    his
Bf3    2        s     d  [[                bur-
C4     2        s     d  ]]                -
D4     4        e     d                    then,
rest   4        e
A3     4        e     d                    his
measure 11
G3     4        e     d  [                 bur-
F3     4        e     d  ]                 -
C3     6        e.    u                    then
C3     2        s     u                    is
F3     8        q     d                    light,
rest   8        q
measure 12
rest  32
measure 13
rest   8        q
rest   4        e
G3     4        e     d                    his
A3     2        s     d  [[                bur-
Bf3    2        s     d  ]]                -
C4     4        e     d                    then
rest   4        e
C4     4        e     d                    his
measure 14
Bf3    4        e     d  [                 bur-
A3     2        s     d  =[                -
G3     2        s     d  ]]                -
G3     6        e.    d                    then
F3     2        s     d                    is
F3     8        q     d                    light,
rest   8        q
measure 15
rest   8        q
rest   4        e
C3     4        e     u                    his
F3     6        e.    d  [                 yoke_
G3     2        s     d  =\                _
A3     4        e     d  ]                 _
G3     2        s     d  [[                is_
F3     2        s     d  ]]                _
measure 16
C4     8-       q     d        -           ea-
C4     2        s     d  [[                -
D4     2        s     d  ==                -
C4     2        s     d  ==                -
D4     2        s     d  ]]                -
Bf3    3        s.    d  [[                -
A3     1        t     d  ==\               -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
Bf3    2        s     d  [[                -
C4     2        s     d  ==                -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
measure 17
A3     2        s     d  [[                -
G3     2        s     d  ]]                -
F3     4        e     d                    sy,
rest   8        q
rest  16        h
measure 18
rest  16        h
rest   8        q
rest   4        e
F3     4        e     d                    his
measure 19
E3     4        e     d  [                 bur-
D3     4        e     d  ]                 -
A3     4        e     d                    then
G3     4        e     d                    is
F3     2        s     d  [[                light,_
E3     2        s     d  ]]                _
D3     4        e     u                    _
rest   8        q
measure 20
rest  32
measure 21
rest  32
measure 22
rest  16        h
rest   8        q
rest   4        e
Ef3    4        e     d                    his
measure 23
D3     4        e     u  [                 bur-
C3     4        e     u  ]                 -
G3     4        e     d                    then
F3     4        e     d                    is
Ef3    2        s     u  [[                light,_
D3     2        s     u  =]                _
C3     4        e     u  ]                 _
rest   4        e
Ef4    4        e     d                    his
measure 24
F3     6        e.    d  [                 yoke_
G3     2        s     d  =\                _
A3     4        e     d  ]                 _
G3     2        s     d  [[                is_
F3     2        s     d  ]]                _
C4     8-       q     d        -           ea-
C4     2        s     d  [[                -
D4     2        s     d  ==                -
C4     2        s     d  ==                -
D4     2        s     d  ]]                -
measure 25
Bf3    3        s.    d  [[                -
A3     1        t     d  ==\               -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
Bf3    2        s     d  [[                -
C4     2        s     d  ==                -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
A3     2        s     d  [[                -
G3     2        s     d  ==                -
A3     2        s     d  ==                -
Bf3    2        s     d  ]]                -
A3     2        s     d  [[                -
Bf3    2        s     d  ==                -
A3     2        s     d  ==                -
Bf3    2        s     d  ]]                -
measure 26
G3     2        s     d  [[                -
F3     2        s     d  ==                -
G3     2        s     d  ==                -
A3     2        s     d  ]]                -
G3     2        s     d  [[                -
A3     2        s     d  ==                -
G3     2        s     d  ==                -
A3     2        s     d  =]                -
F3     4        e     d  ]                 -
F3     4        e     d                    sy,
rest   8        q
measure 27
rest  16        h
rest   8        q
rest   4        e
Ef3    4        e     d                    his
measure 28
D3     2        s     u  [[                bur-
C3     2        s     u  ]]                -
Bf2    4        e     u                    then,
rest   8        q
rest   8        q
rest   4        e
Bf3    4        e     d                    his
measure 29
C4     2        s     d  [[                bur-
D4     2        s     d  ]]                -
Ef4    4        e     d                    then,
rest   4        e
G3     4        e     d                    his
F3     4        e     d  [                 bur-
Ef3    4        e     d  ]                 -
Bf3    4        e     d                    then,
Bf2    4        e     u                    his
measure 30
Ef3    2        s     d  [[                bur-
F3     2        s     d  ]]                -
G3     4        e     d                    then,
rest   4        e
Af3    4        e     d                    his
Bf3    4        e     d  [                 bur-
C4     4        e     d  ]                 -
F3     4        e     d                    then
Bf3    4        e     d                    is
measure 31
G3     2        s     d  [[                light,_
F3     2        s     d  =]                _
Ef3    4        e     d  ]                 _
rest   4        e
Bf2    4        e     u                    his
Ef3    6        e.    d  [                 yoke_
F3     2        s     d  =\                _
G3     4        e     d  ]                 _
F3     2        s     d  [[                is_
Ef3    2        s     d  ]]                _
measure 32
Bf3    8-       q     d        -           ea-
Bf3    2        s     d  [[                -
C4     2        s     d  ==                -
Bf3    2        s     d  ==                -
C4     2        s     d  ]]                -
A3     3        s.    d  [[                -
G3     1        t     d  ==\               -
A3     2        s     d  ==                -
Bf3    2        s     d  ]]                -
A3     2        s     d  [[                -
Bf3    2        s     d  ==                -
G3     2        s     d  ==                -
A3     2        s     d  =]                -
measure 33
F3     4        e     d  ]                 -
F3     4        e     d                    sy,
rest   8        q
rest   8        q
rest   4        e
Bf3    4        e     d                    his
measure 34
A3     2        s     d  [[                bur-
G3     2        s     d  ]]                -
F3     8        q     d                    then
D4     4        e     d                    is
C4     8        q     d                    light,
rest   4        e
Bf3    4        e     d                    is
measure 35
F3     8        q     d                    light,
rest   8        q
rest  16        h
measure 36
rest   8        q
rest   4        e
D4     4        e     d                    his
C4     4        e     d  [                 bur-
Bf3    4        e     d  ]                 -
F3     4        e     d                    then
A3     4        e     d                    is
measure 37
Bf3    8        q     d                    light,
rest   8        q
rest   8        q
rest   4        e
F3     4        e     d                    is
measure 38
Bf2    8        q     u                    light,
rest   4        e
Bf2    4        e     u                    his
Ef3   12        q.    d                    bur-
D3     2        s     u  [[                -
C3     2        s     u  ]]                -
measure 39
G3    16        h     d                    -
D3    12        q.    u                    -
F3     4        e     d                    -
measure 40
G3     8        q     d                    -
A3     8        q     d                    -
Bf3    8        q     d                    -
G3     4        e     d                    then
G3     4        e     d                    is
measure 41
F3     8        q     d                    light,
rest   4        e
F3     4        e     d                    his
D3     6        e.    u  [                 yoke_
C3     2        s     u  =\                _
Bf2    4        e     u  ]                 _
Bf3    4        e     d                    is
measure 42
A3     6        e.    d  [                 ea-
G3     2        s     d  ]\                -
F3     4        e     d                    sy,
F3     4        e     d                    is
G3     3        s.    d  [[                ea-
F3     1        t     d  ==\               -
G3     2        s     d  ==                -
A3     2        s     d  ]]                -
G3     2        s     d  [[                -
A3     2        s     d  ==                -
G3     2        s     d  ==                -
A3     2        s     d  =]                -
measure 43
Bf3    4        e     d  ]                 -
Bf2    4        e     u                    sy,
rest   4        e
Ef3    4        e     d                    his
D3     2        s     u  [[                bur-
C3     2        s     u  ]]                -
Bf2    8        q     u                    then
Ef3    4        e     d                    is
measure 44
Bf3    2        s     d  [[     (          light,_
C4     2        s     d  ]]                _
D4     8        q     d         )          _
Bf3    4        e     d                    his
A3     2        s     d  [[     (          yoke_
G3     2        s     d  ]]                _
F3     8        q     d         )          _
Bf3    4        e     d                    is
measure 45
A3     2        s     d  [[                ea-
G3     2        s     d  ]]                -
F3     4        e     d                    sy,
rest   4        e
D4     4        e     d                    his
C4     4        e     d  [                 bur-
Bf3    4        e     d  ]                 -
F3     4        e     d                    then
F3     4        e     d                    is
measure 46
Bf3    8        q     d                    light,
D3     8        q     u                    his
Ef3    8        q     d                    yoke_
C3     8        q     u                    _
measure 47
D3    12        q.    u                    _
Ef3    4        e     d                    is
F3     8        q     d                    ea-
F3     8        q     d                    sy,
measure 48
rest  16        h
C3    12        q.    u                    and
C3     4        e     u                    his
measure 49
D3    24        h.    u         (          bur-
Ef3    8        q     d                    -
measure 50
F3    16        h     d         )          -
F3    12        q.    d                    then
F3     4        e     d                    is
measure 51
Bf2   32        w     u                    light.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-23/8} [KHM:2926349006]
TIMESTAMP: DEC/26/2001 [md5sum:9539fe80350beaed52d9717d01e5f471]
04/11/90 E. Correia
WK#:56        MV#:1,23
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Allegro
Bf2    2        e     d  [      &p
Bf3    2        e     d  =
f1              6
A3     2        e     d  =
Bf3    2        e     d  ]
G3     4        q     d
f1              6
F3     2        e     d  [
G3     2        e     d  ]
measure 2
D3     2        e     d  [
D4     2        e     d  =
f1              6
A3     2        e     d  =
Bf3    2        e     d  ]
C4     2        e     d  [
C3     2        e     d  =
f1              6
G3     2        e     d  =
f2              6 5
A3     2        e     d  ]
measure 3
Bf3    2        e     d  [
D3     2        e     d  =
f1              6
G3     2        e     d  =
Ef3    2        e     d  ]
Bf3    2        e     d  [
D4     2        e     d  =
D3     2        e     d  =
Ef3    2        e     d  ]
measure 4
Bf2    2        e     d  [
Bf3    2        e     d  =
f1              6
D4     2        e     d  =
D3     2        e     d  ]
Ef3    2        e     d  [
f1              6
D3     2        e     d  ]
rest   2        e
f1              6
D3     2        e     u
measure 5
f1              6
C3     2        e     u  [
Bf2    2        e     u  =
f1              4
F2     2        e     u  =
f1              3
F3     2        e     u  ]
f1              6
D3     2        e     u  [
Bf2    2        e     u  ]
rest   2        e
Bf3    2        e     d
measure 6
f1              6
A3     2        e     d  [
F3     2        e     d  =
D4     2        e     d  =
Bf3    2        e     d  ]
f1              6
G3     2        e     d  [
C4     2        e     d  =
f1              7
F3     2        e     d  =
A3     2        e     d  ]
measure 7
Bf3    2        e     u  [
Bf2    2        e     u  =
G2     2        e     u  =
G3     2        e     u  ]
F3     4        q     d
f1              6
D3     2        e     u  [
Bf2    2        e     u  ]
measure 8
C3     2        e     u  [
F2     2        e     u  ]
rest   2        e
F3     2        e     d
Bf2    3        e.    u  [
C3     1        s     u  =\
D3     2        e     u  =
Bf2    2        e     u  ]
measure 9
F3     6        q.    d
F3     2        e     d
Ef3    3        e.    d  [
F3     1        s     d  =\
Ef3    3        e.    d  =
F3     1        s     d  ]\
measure 10
D3     2        e     d  [
Bf2    2        e     d  =
F3     2        e     d  =
A3     2        e     d  ]
Bf3    1        s     d  [[
C4     1        s     d  =]
D4     2        e     d  ]
Bf3    2        e     d  [
f1              6
A3     2        e     d  ]      f
measure 11
G3     2        e     u  [
F3     2        e     u  =
C3     2        e     u  =
C2     2        e     u  ]
F2     2        e     u  [
A3     2        e     u  =
Bf3    2        e     u  =
Bf2    2        e     u  ]
measure 12
F2     2        e     d  [
F3     2        e     d  =      p
A3     2        e     d  =
F3     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  ]
rest   2        e
A3     2        e     d
measure 13
G3     2        e     d  [
F3     2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
F3     2        e     u  [
F2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 14
G2     2        e     u  [
F2     2        e     u  ]
C3     4        q     u
F3     2        e     d  [
A3     2        e     d  ]
rest   2        e
Bf3    2        e     d
measure 15
G3     2        e     d  [
F3     2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
F3     3        e.    d  [
G3     1        s     d  =\
A3     2        e     d  =
F3     2        e     d  ]
measure 16
A2     2        e     d  [
A3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  ]
G3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
E3     2        e     d  ]
measure 17
F3     6        q.    d
A3     2        e     d
C3     2        e     u  [
E3     2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
measure 18
f1              7
G2     2        e     d  [
f1              6n
G3     2        e     d  =
f1              n
C4     2        e     d  =
C3     2        e     d  ]
F2     2        e     u  [
D3     2        e     u  =
f1              6
C#3    2        e     u  =
F3     2        e     u  ]      &f
measure 19
E3     2        e     d  [
D3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
F3     2        e     d  [
D3     2        e     d  ]
D4     2        e     d  [      &p
F4     2        e     d  ]
measure 20
f1              6
B3     2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
Ef3    2        e     d  ]      +
D3     2        e     d  [
D4     2        e     d  =
G3     2        e     d  =
B3     2        e     d  ]
measure 21
C3     2        e     d  [
Ef4    2        e     d  =
C4     2        e     d  =
Af3    2        e     d  ]
G3     2        e     d  [
B2     2        e     d  =
C3     2        e     d  =
C4     2        e     d  ]
measure 22
D3     2        e     d  [
G3     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
C4     2        e     d  [
Ef3    2        e     d  =
C3     2        e     d  =
Ef3    2        e     d  ]      &f
measure 23
f1              6n
D3     2        e     d  [
C3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
Ef3    2        e     d  [
C3     2        e     d  ]
G3     2        e     d  [      &p
Ef4    2        e     d  ]
measure 24
F3     3        e.    d  [
G3     1        s     d  =\
A3     2        e     d  =
F3     2        e     d  ]
C3     3        e.    d  [
D3     1        s     d  =\
Ef3    2        e     d  =
F3     2        e     d  ]
measure 25
G3     2        e     u  [
G2     2        e     u  =
D3     2        e     u  =
Ef3    2        e     u  ]
F3     2        e     u  [
F2     2        e     u  =
A2     2        e     u  =
Bf2    2        e     u  ]
measure 26
C3     2        e     u  [
C2     2        e     u  =
G2     2        e     u  =
A2     2        e     u  ]
Bf2    2        e     u  [
D3     2        e     u  =
Ef3    2        e     u  =
Ef2    2        e     u  ]
measure 27
Bf2    4        q     u
rest   2        e
Ef3    2        e     d
Bf3    4        q     d
rest   2        e
f1              6
Ef3    2        e     d
measure 28
D3     2        e     u  [
Bf2    2        e     u  =
Af2    2        e     u  =
G2     2        e     u  ]
F2     2        e     u  [
Ef2    2        e     u  =
Bf2    2        e     u  =
Bf3    2        e     u  ]
measure 29
C4     2        e     d  [
Ef4    2        e     d  ]
G3     4        q     d         &f
F3     2        e     d  [
Ef3    2        e     d  =
Bf3    2        e     d  =
Bf2    2        e     d  ]
measure 30
Ef3    2        e     d  [
G3     2        e     d  ]
rest   2        e
Af3    2        e     d         &p
Bf3    2        e     d  [
C4     2        e     d  =
F3     2        e     d  =
Bf3    2        e     d  ]
measure 31
G3     2        e     d  [
Ef3    2        e     d  ]
rest   2        e
Bf2    2        e     u
G2     2        e     u  [
Ef2    2        e     u  ]
rest   2        e
C3     2        e     u
measure 32
Bf2    2        e     u  [
Bf2    2        e     u  =
D3     2        e     u  =
Ef3    2        e     u  ]
F3     6        q.    d
A2     2        e     u
measure 33
Bf2    2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
Ef3    2        e     d  ]
Bf2    2        e     d  [
Bf3    2        e     d  =
D3     2        e     d  =
Ef3    2        e     d  ]
measure 34
F3     2        e     d  [
A2     2        e     d  =
Bf2    2        e     d  =
Bf3    2        e     d  ]
F3     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  ]
Bf2    2        e     u         &f
measure 35
F3     2        e     d  [
A3     2        e     d  ]
Bf3    2        e     d  [      &p
Bf2    2        e     d  ]
F3     4        q     d
A3     2        e     d  [
F3     2        e     d  ]
measure 36
Bf3    2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  ]
D4     2        e     d         &f
C4     2        e     d  [
Bf3    2        e     d  =
F3     2        e     d  =
A3     2        e     d  ]
measure 37
Bf3    2        e     d  [
D4     2        e     d  ]
D3     4        q     u
C3     2        e     u  [
Bf2    2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
measure 38
Bf2    4        q     u
D3     2        e     u  [
Bf2    2        e     u  ]
Ef3    6        q.    d
D3     1        s     u  [[
C3     1        s     u  ]]
measure 39
G3     6        q.    d
G2     2        e     u
D3     6        q.    u
F3     2        e     d
measure 40
G3     4        q     d
A3     4        q     d
Bf3    4        q     d
G3     4        q     d
measure 41
F3     3        e.    d  [
G3     1        s     d  =\
A3     2        e     d  =
F3     2        e     d  ]
D3     3        e.    d  [
C3     1        s     d  =\
Bf2    2        e     d  =
Bf3    2        e     d  ]
measure 42
A3     3        e.    d  [
G3     1        s     d  =\
F3     2        e     d  =
F3     2        e     d  ]
G3     3        e.    d  [
A3     1        s     d  =\
G3     3        e.    d  =
A3     1        s     d  ]\
measure 43
Bf3    2        e     d  [
Bf2    2        e     d  ]
rest   2        e
Ef3    2        e     d
D3     2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Ef3    2        e     u  ]
measure 44
Bf3    2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
Bf3    2        e     d  ]
measure 45
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
D4     2        e     d
C4     2        e     d  [
Bf3    2        e     d  =
F3     2        e     d  =
F2     2        e     d  ]
measure 46
Bf2    4        q     u
D3     4        q     u
Ef3    4        q     d
C3     4        q     u
measure 47
D3     6        q.    u
Ef3    2        e     d
F3     4        q     d
F2     4        q     u
measure 48
rest   8        h
C3     6        q.    u
C3     2        e     u
measure 49
D3    12        h.    u
Ef3    4        q     d
measure 50
F3     8        h     d
F2     8        h     u
measure 51
Bf2   16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
