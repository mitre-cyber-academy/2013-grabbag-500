&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-05/1} [KHM:1800854027]
TIMESTAMP: DEC/26/2001 [md5sum:69f088800e7341449b971b5ffcdcf37b]
04/04/90 E. Correia
WK#:56        MV#:1,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
0 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4
rest   2        e
D4     2        e     u  [
D4     3        e.    u  =
D4     1        s     u  ]\
F4     3        e.    u  [
F4     1        s     u  =\
A4     3        e.    u  =
A4     1        s     u  ]\
measure 2
D5     4        q     d
rest   4        q
rest   8        h
measure 3
rest   8        h
rest   2        e
rest   1        s
A4     1        s     u  [/
A4     3        e.    u  =
A4     1        s     u  ]\
measure 4
A4     4        q     u
rest   4        q
rest   8        h
measure 5
rest   2        e
rest   1        s
C5     1        s     d  [/
C5     3        e.    d  =
C5     1        s     d  ]\
C5     4        q     d
rest   4        q
measure 6
rest  16
measure 7
rest   8        h
rest   2        e
rest   1        s
C5     1        s     d  [/
C5     3        e.    d  =
C5     1        s     d  ]\
measure 8
F5     4        q     d
rest   4        q
rest   2        e
rest   1        s
D5     1        s     d  [/
D5     3        e.    d  =
D5     1        s     d  ]\
measure 9
G5     4        q     d
rest   4        q
rest   2        e
rest   1        s
G4     1        s     u  [/
G4     3        e.    u  =
G4     1        s     u  ]\
measure 10
C5     4        q     d
rest   4        q
C5     4        q     d
rest   4        q
measure 11
F5     4        q     d
rest   4        q
F4     4        q     u
rest   4        q
measure 12
Bf4    4        q     u
rest   4        q
D5     4        q     d
rest   4        q
measure 13
G5     4        q     d
rest   4        q
G4     4        q     u
rest   4        q
measure 14
rest   1        s
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
measure 15
D5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
D5     1        s     d  ]]
G5     1        s     d  [[
G5     1        s     d  ==
G5     1        s     d  ==
G5     1        s     d  ]]
E5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
E5     1        s     d  ]]
A5     1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
A5     1        s     d  ]]
measure 16
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
Bf5    1        s     d  [[
Bf5    1        s     d  ==
Bf5    1        s     d  ==
Bf5    1        s     d  ]]
Bf5    1        s     d  [[
Bf5    1        s     d  ==
Bf5    1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
A5     1        s     d  ]]
measure 17
A5     1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
G5     1        s     d  ==
G5     1        s     d  ==
G5     1        s     d  ]]
G5     1        s     d  [[
G5     1        s     d  ==
G5     1        s     d  ==
G5     1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
measure 18
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
E5     1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
F5     1        s     d  ==
F5     1        s     d  ]]
Bf4    1        s     u  [[
Bf4    1        s     u  ==
Bf4    1        s     u  ==
Bf4    1        s     u  ]]
measure 19
Bf4    2        e     u  [      (
Bf4    2        e     u  =
Bf4    2        e     u  =
Bf4    2        e     u  ]      )
A4     2        e     d  [      (
A4     2        e     d  =      )
F5     2        e     d  =      (.
F5     2        e     d  ]      ).
measure 20
F5     2        e     d  [      (.
F5     2        e     d  =      ).
E5     2        e     d  =      (.
E5     2        e     d  ]      ).
F5     2        e     d  [      (
F5     2        e     d  =      )
A5     2        e     d  =      (
A5     2        e     d  ]      )
measure 21
A5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
F5     2        e     d  ]
E5     2        e     d  [
E5     2        e     d  =
F5     2        e     d  =
F5     2        e     d  ]
measure 22
F5     2        e     d  [
F5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
F5     2        e     d  [
rest   1        s
*               G +     f
A4     1        s     d  =\
A4     3        e.    d  =
A4     1        s     d  ]\
measure 23
D5     4        q     d
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest   2        e
rest   1        s
D5     1        s     d  [/
D5     3        e.    d  =
D5     1        s     d  ]\
D5     4        q     d
rest   4        q
measure 26
rest   8        h
G5     4        q     d
rest   4        q
measure 27
B4     4        q     u
rest   4        q
rest   2        e
rest   1        s
C5     1        s     d  [/
C5     3        e.    d  =
C5     1        s     d  ]\
measure 28
E5     4        q     d
rest   4        q
rest   8        h
measure 29
E5     3        e.    d  [
C5     1        s     d  =\
C5     3        e.    d  =
C5     1        s     d  ]\
C5     4        q     d
rest   4        q
measure 30
rest   8        h
G#5    4        q     d
A5     4        q     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-05/2} [KHM:1800854027]
TIMESTAMP: DEC/26/2001 [md5sum:069c5631c7c0702c86ca7adc77fc6870]
04/04/90 E. Correia
WK#:56        MV#:1,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
0 72
Group memberships: score
score: part 2 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4
rest   2        e
F4     2        e     u  [
F4     3        e.    u  =
F4     1        s     u  ]\
A4     3        e.    u  [
A4     1        s     u  =\
F4     3        e.    u  =
F4     1        s     u  ]\
measure 2
F4     4        q     u
rest   4        q
rest   8        h
measure 3
rest   8        h
rest   2        e
rest   1        s
F4     1        s     u  [/
F4     3        e.    u  =
F4     1        s     u  ]\
measure 4
F4     4        q     u
rest   4        q
rest   8        h
measure 5
rest   2        e
rest   1        s
G4     1        s     u  [/
G4     3        e.    u  =
G4     1        s     u  ]\
G4     4        q     u
rest   4        q
measure 6
rest  16
measure 7
rest   8        h
rest   2        e
rest   1        s
A4     1        s     u  [/
A4     3        e.    u  =
A4     1        s     u  ]\
measure 8
C5     4        q     d
rest   4        q
rest   2        e
rest   1        s
Bf4    1        s     u  [/
Bf4    3        e.    u  =
Bf4    1        s     u  ]\
measure 9
D5     4        q     d
rest   4        q
rest   2        e
rest   1        s
E4     1        s     u  [/
E4     3        e.    u  =
E4     1        s     u  ]\
measure 10
G4     4        q     u
rest   4        q
A4     4        q     u
rest   4        q
measure 11
C5     4        q     d
rest   4        q
D4     4        q     u
rest   4        q
measure 12
F4     4        q     u
rest   4        q
Bf4    4        q     u
rest   4        q
measure 13
D5     4        q     d
rest   4        q
E4     4        q     u
rest   4        q
measure 14
rest   1        s
G4     1        s     u  [[
G4     1        s     u  ==
G4     1        s     u  ]]
G4     1        s     u  [[
G4     1        s     u  ==
G4     1        s     u  ==
G4     1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
measure 15
Bf4    1        s     u  [[
Bf4    1        s     u  ==
Bf4    1        s     u  ==
Bf4    1        s     u  ]]
Bf4    1        s     u  [[
Bf4    1        s     u  ==
Bf4    1        s     u  ==
Bf4    1        s     u  ]]
G4     1        s     u  [[
G4     1        s     u  ==
G4     1        s     u  ==
G4     1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
measure 16
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     u  [[
Bf4    1        s     u  ==
Bf4    1        s     u  ==
Bf4    1        s     u  ]]
E5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
E5     1        s     d  ]]
measure 17
D5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
D5     1        s     d  ]]
D5     1        s     d  [[
D5     1        s     d  ==
Bf4    1        s     d  ==
Bf4    1        s     d  ]]
A4     1        s     u  [[
A4     1        s     u  ==
A4     1        s     u  ==
A4     1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
measure 18
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     u  [[
Bf4    1        s     u  ==
Bf4    1        s     u  ==
Bf4    1        s     u  ]]
measure 19
C5     2        e     d  [      (
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]      )
C5     2        e     d  [      (
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]      )
measure 20
Bf4    2        e     u  [      (
Bf4    2        e     u  =
Bf4    2        e     u  =
Bf4    2        e     u  ]      )
C5     2        e     d  [      (
C5     2        e     d  =      )
F5     2        e     d  =      (
F5     2        e     d  ]      )
measure 21
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
G4     2        e     u  [
G4     2        e     u  =
C5     2        e     u  =
A4     2        e     u  ]
measure 22
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
A4     2        e     u  [
rest   1        s
F4     1        s     u  =\     &f
F4     3        e.    u  =
F4     1        s     u  ]\
measure 23
A4     4        q     u
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest   2        e
rest   1        s
Bf4    1        s     u  [/
Bf4    3        e.    u  =
Bf4    1        s     u  ]\
B4     4        q     u
rest   4        q
measure 26
rest   8        h
C5     4        q     d
rest   4        q
measure 27
F4     4        q     u
rest   4        q
rest   2        e
rest   1        s
G4     1        s     u  [/
G4     3        e.    u  =
G4     1        s     u  ]\
measure 28
B4     4        q     u
rest   4        q
rest   8        h
measure 29
C5     3        e.    u  [
E4     1        s     u  =\
E4     3        e.    u  =
E4     1        s     u  ]\
F#4    4        q     u
rest   4        q
measure 30
rest   8        h
B4     4        q     d
C#5    4        q     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-05/3} [KHM:1800854027]
TIMESTAMP: DEC/26/2001 [md5sum:2ac108f3b139699563d2462c630350ca]
04/04/90 E. Correia
WK#:56        MV#:1,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
0 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:13
rest   2        e
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
D4     3        e.    d  [
D4     1        s     d  =\
D4     3        e.    d  =
D4     1        s     d  ]\
measure 2
A4     4        q     d
rest   4        q
rest   8        h
measure 3
rest   8        h
rest   2        e
rest   1        s
D4     1        s     d  [/
D4     3        e.    d  =
D4     1        s     d  ]\
measure 4
D4     4        q     d
rest   4        q
rest   8        h
measure 5
rest   2        e
rest   1        s
C4     1        s     u  [/
C4     3        e.    u  =
C4     1        s     u  ]\
C4     4        q     u
rest   4        q
measure 6
rest  16
measure 7
rest   8        h
rest   2        e
rest   1        s
F4     1        s     d  [/
F4     3        e.    d  =
F4     1        s     d  ]\
measure 8
F4     4        q     d
rest   4        q
rest   2        e
rest   1        s
F4     1        s     d  [/
F4     3        e.    d  =
F4     1        s     d  ]\
measure 9
G4     4        q     d
rest   4        q
rest   2        e
rest   1        s
C4     1        s     u  [/
C4     3        e.    u  =
C4     1        s     u  ]\
measure 10
C4     4        q     u
rest   4        q
F4     4        q     d
rest   4        q
measure 11
F4     4        q     d
rest   4        q
Bf3    4        q     u
rest   4        q
measure 12
Bf3    4        q     u
rest   4        q
G4     4        q     d
rest   4        q
measure 13
G4     4        q     d
rest   4        q
C4     4        q     u
rest   4        q
measure 14
rest   1        s
E4     1        s     d  [[
E4     1        s     d  ==
E4     1        s     d  ]]
E4     1        s     d  [[
E4     1        s     d  ==
E4     1        s     d  ==
E4     1        s     d  ]]
A4     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
A4     1        s     d  ]]
A4     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
A4     1        s     d  ]]
measure 15
F4     1        s     d  [[
F4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
D4     1        s     d  [[
D4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
E4     1        s     d  [[
E4     1        s     d  ==
E4     1        s     d  ==
E4     1        s     d  ]]
measure 16
F4     1        s     d  [[
F4     1        s     d  ==
F4     1        s     d  ==
F4     1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
F4     1        s     d  ==
F4     1        s     d  ]]
E4     1        s     d  [[
E4     1        s     d  ==
E4     1        s     d  ==
E4     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
C5     1        s     d  ==
C5     1        s     d  ]]
measure 17
Bf4    1        s     d  [[
Bf4    1        s     d  ==
Bf4    1        s     d  ==
Bf4    1        s     d  ]]
Bf4    1        s     d  [[
Bf4    1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
D4     1        s     d  [[
D4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
C4     1        s     u  [[
C4     1        s     u  ==
C4     1        s     u  ==
C4     1        s     u  ]]
measure 18
G4     1        s     d  [[
G4     1        s     d  ==
G4     1        s     d  ==
G4     1        s     d  ]]
G4     1        s     d  [[
G4     1        s     d  ==
G4     1        s     d  ==
G4     1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
F4     1        s     d  ==
F4     1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
F4     1        s     d  ==
F4     1        s     d  ]]
measure 19
G4     2        e     d  [      (
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]      )
A4     2        e     d  [      (
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]      )
measure 20
G4     2        e     d  [      (
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]      )
F4     2        e     d  [      (
F4     2        e     d  =      )
C5     2        e     d  =      (
C5     2        e     d  ]      )
measure 21
Bf4    2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  =
Bf4    2        e     d  ]
Bf4    2        e     d  [
Bf4    1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
C4     2        e     d  ]
measure 22
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
C4     2        e     u  [
rest   1        s
C4     1        s     u  =\     &f
C4     3        e.    u  =
C4     1        s     u  ]\
measure 23
D4     4        q     d
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest   2        e
rest   1        s
G4     1        s     d  [/
G4     3        e.    d  =
G4     1        s     d  ]\
G4     4        q     d
rest   4        q
measure 26
rest   8        h
G4     4        q     d
rest   4        q
measure 27
D4     4        q     d
rest   4        q
rest   2        e
rest   1        s
E4     1        s     d  [/
E4     3        e.    d  =
E4     1        s     d  ]\
measure 28
E4     4        q     d
rest   4        q
rest   8        h
measure 29
A4     3        e.    d  [
A4     1        s     d  =\
A4     3        e.    d  =
A4     1        s     d  ]\
A4     4        q     d
rest   4        q
measure 30
rest   8        h
E4     4        q     d
E4     4        q     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-05/4} [KHM:1800854027]
TIMESTAMP: DEC/26/2001 [md5sum:06075f5cb7e7b7d09c9d36ab132f49a9]
04/04/90 E. Correia
WK#:56        MV#:1,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Basso
0 72 B
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:22
rest  16
measure 2
D4     4        q     d                    Thus
A3     3        e.    d                    saith
A3     1        s     d                    the
F3     4        q     d                    Lord,
rest   4        q
measure 3
rest   2        e
F3     2        e     d                    the
G3     2        e     d                    Lord
A3     2        e     d                    of
D3     8        h     u                    Hosts:
measure 4
rest   4        q
rest   2        e
D3     2        e     u                    Yet
A3     2        e     d                    once
A3     2        e     d                    a
A3     2        e     d                    lit-
D4     2        e     d                    tle
measure 5
C4     4        q     d                    while,
rest   4        q
rest   2        e
C4     2        e     d                    and
E3     2        e     d                    I
G3     2        e     d                    will
measure 6
C3     4-       q     u        -           shake_
C3     1        s     u  [[                _
D3     1        s     u  ==                _
C3     1        s     u  ==                _
D3     1        s     u  ]]                _
E3     1        s     d  [[                _
F3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 7
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     d  [[                _
G3     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
A3     4        q     d                    _
rest   2        e
C4     2        e     d                    the
measure 8
C4     4        q     d                    heav'ns
F3     2        e     d                    and
C3     2        e     u                    the
D3     4        q     u                    earth,
rest   2        e
D4     2        e     d                    the
measure 9
D4     4        q     d                    sea
D3     2        e     u                    and
F3     2        e     d                    the
F3     2        e     d                    dry
E3     2        e     d                    land,
rest   4        q
measure 10
rest   2        e
C4     2        e     d                    and
C4     2        e     d                    I
C4     2        e     d                    will
A3     1        s     d  [[                shake,_
Bf3    1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
A3     1        s     d  [[                _
Bf3    1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 11
F3     1        s     d  [[                _
G3     1        s     d  ==                _
A3     1        s     d  ==                _
G3     1        s     d  ]]                _
F3     1        s     d  [[                _
G3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
D3     1        s     d  [[                _
E3     1        s     d  ==                _
F3     1        s     d  ==                _
E3     1        s     d  ]]                _
D3     1        s     d  [[                _
E3     1        s     d  ==                _
C3     1        s     d  ==                _
D3     1        s     d  =]                _
measure 12
D3     2        e     d  ]                 _
rest   1        s
D4     1        s     d                    and
D4     2        e     d                    I
D4     2        e     d                    will
Bf3    1        s     d  [[                shake_
C4     1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
A3     1        s     d  ==                _
Bf3    1        s     d  ]]                _
measure 13
G3     1        s     d  [[                _
A3     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
F3     1        s     d  ==                _
G3     1        s     d  ]]                _
E3     1        s     d  [[                _
F3     1        s     d  ==                _
G3     1        s     d  ==                _
F3     1        s     d  ]]                _
E3     1        s     d  [[                _
F3     1        s     d  ==                _
D3     1        s     d  ==                _
E3     1        s     d  ]]                _
measure 14
C3     4        q     u                    _
rest   2        e
C4     2        e     d                    all
A3     2        e     d                    na-
F3     2        e     d                    tions,
rest   2        e
F3     2        e     d                    I'll
measure 15
Bf3    4        q     d                    shake
rest   2        e
G3     2        e     d                    the
C4     4        q     d                    heav'ns,
rest   2        e
A3     2        e     d                    the
measure 16
D3     4        q     u                    earth,
rest   2        e
G3     2        e     d                    the
C3     4        q     u                    sea,
rest   2        e
F3     2        e     d                    the
measure 17
Bf3    2        e     d                    dry
Bf3    2        e     d                    land,
rest   2        e
G3     2        e     d                    all
D4     2        e     d                    na-
D4     2        e     d                    tions,
rest   2        e
A3     2        e     d                    I'll
measure 18
C4     4        q     d                    shake,
rest   4        q
rest   2        e
D3     2        e     u                    and
D3     2        e     u                    the
D3     2        e     u                    de-
measure 19
E3     1        s     d  [[                sire_
D3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
E3     1        s     d  [[                _
F3     1        s     d  ==                _
D3     1        s     d  ==                _
E3     1        s     d  ]]                _
F3     1        s     d  [[                _
E3     1        s     d  ==                _
F3     1        s     d  ==                _
G3     1        s     d  ]]                _
F3     1        s     d  [[                _
G3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
measure 20
G3     1        s     d  [[                _
F3     1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
F3     1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
G3     1        s     d  ==                _
A3     1        s     d  ==                _
Bf3    1        s     d  ]]                _
A3     1        s     d  [[                _
Bf3    1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 21
Bf3    1        s     d  [[                _
A3     1        s     d  ==                _
Bf3    1        s     d  ==                _
C4     1        s     d  ]]                _
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
A3     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     4        q     d                    _
A3     2        e     d                    of
F3     2        e     d                    all
measure 22
C3     4        q     u                    na-
C3     2        e     u                    tions
C3     2        e     u                    shall
F3     8        h     d                    come.
measure 23
rest   4        q
rest   2        e
D3     2        e     u                    The
F#3    4        q     d                    Lord
F#3    2        e     d                    whom
G3     2        e     d                    ye
measure 24
A3     4        q     d                    seek,
rest   2        e
A3     2        e     d                    shall
C4     1        s     d                    sud-
C4     1        s     d                    den-
C4     2        e     d                    ly
C4     2        e     d                    come
C4     1        s     d                    to
Bf3    1        s     d                    his
measure 25
G3     2        e     d                    tem-
G3     2        e     d                    ple;
rest   4        q
rest   4        q
G3     2        e     d                    ev'n
A3     2        e     d                    the
measure 26
B3     1        s     d                    mes-
B3     1        s     d                    sen-
B3     2        e     d                    ger
A3     2        e     d                    of
G3     2        e     d                    the
C4     3        e.    d                    Co-
C4     1        s     d                    ve-
C4     4        q     d                    nant,
measure 27
rest   2        e
F3     2        e     d                    whom
G3     2        e     d                    ye
D3     2        e     d                    de-
E3     2        e     d                    light
E3     2        e     d                    in,
rest   4        q
measure 28
rest   4        q
rest   2        e
E3     2        e     d                    be-
B3     4        q     d                    hold
rest   2        e
B3     1        s     d                    he
E3     1        s     d                    shall
measure 29
C4     4        q     d                    come,
rest   4        q
rest   4        q
A3     3        e.    d                    saith
A3     1        s     d                    the
measure 30
G#3    6        q.    d                    Lord
A3     2        e     d                    of
E3     4        q     d                    Hosts.
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-05/5} [KHM:1800854027]
TIMESTAMP: DEC/26/2001 [md5sum:036f826017d4ba426badbc7dc0d3ac8a]
04/04/90 E. Correia
WK#:56        MV#:1,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
0 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
Note: includes alternate readings of measures 5,7,8,25,and 27
      enclosed in comments
&
$ K:-1   Q:4   T:1/1   C:22
rest   2        e
D3     2        e     u  [
D3     3        e.    u  =
D3     1        s     u  ]\
D3     3        e.    u  [
D3     1        s     u  =\
D3     3        e.    u  =
D3     1        s     u  ]\
measure 2
D3     4        q     u
rest   4        q
rest   8        h
measure 3
rest   8        h
rest   2        e
rest   1        s
D3     1        s     u  [/
D3     3        e.    u  =
D3     1        s     u  ]\
measure 4
D3     4        q     u
rest   4        q
rest   8        h
measure 5
rest   2        e
f1              6
E3     2        e     d  [
E3     3        e.    d  =
E3     1        s     d  ]\
E3     4        q     d
rest   4        q
&
Early stage2 file contains this alternate reading of measure 5
measure 5
rest   2        e
rest   1        s
f1              6
E3     1        s     d  [/
E3     3        e.    d  =
E3     1        s     d  ]\
E3     4        q     d
rest   4        q
&
measure 6
rest  16
measure 7
rest   8        h
rest   2        e
F3     2        e     d  [
F3     3        e.    d  =
F3     1        s     d  ]\
measure 8
A2     4        q     u
rest   4        q
rest   2        e
Bf2    2        e     u  [
Bf2    3        e.    u  =
Bf2    1        s     u  ]\
&
Early stage2 file contains this alternate reading of measures 7 and 8
measure 7
rest   8        h
rest   2        e
rest   1        s
F3     1        s     d  [/
F3     3        e.    d  =
F3     1        s     d  ]\
measure 8
A2     4        q     u
rest   4        q
rest   2        e
rest   1        s
Bf2    1        s     u  [/
Bf2    3        e.    u  =
Bf2    1        s     u  ]\
&
measure 9
B2     4        q     u
rest   4        q
rest   2        e
C3     2        e     u  [
C3     3        e.    u  =
C3     1        s     u  ]\
measure 10
E3     4        q     d
rest   4        q
F3     4        q     d
rest   4        q
measure 11
A2     4        q     u
rest   4        q
Bf2    4        q     u
rest   4        q
measure 12
D2     4        q     u
rest   4        q
G2     4        q     u
rest   4        q
measure 13
Bf2    4        q     u
rest   4        q
C3     4        q     u
rest   4        q
measure 14
E2     4        q     u
rest   2        e
C4     2        e     d
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 15
Bf3    1        s     d  [[
Bf3    1        s     d  ==
Bf3    1        s     d  ==
Bf3    1        s     d  ]]
G3     1        s     d  [[
G3     1        s     d  ==
G3     1        s     d  ==
G3     1        s     d  ]]
C4     1        s     d  [[
C4     1        s     d  ==
C4     1        s     d  ==
C4     1        s     d  ]]
A3     1        s     d  [[
A3     1        s     d  ==
A3     1        s     d  ==
A3     1        s     d  ]]
measure 16
D3     1        s     u  [[
D3     1        s     u  ==
D3     1        s     u  ==
D3     1        s     u  ]]
G3     1        s     d  [[
G3     1        s     d  ==
G3     1        s     d  ==
G3     1        s     d  ]]
C3     1        s     u  [[
C3     1        s     u  ==
C3     1        s     u  ==
C3     1        s     u  ]]
F3     1        s     d  [[
F3     1        s     d  ==
F3     1        s     d  ==
F3     1        s     d  ]]
measure 17
Bf3    1        s     d  [[
Bf3    1        s     d  ==
Bf3    1        s     d  ==
Bf3    1        s     d  ]]
Bf3    1        s     d  [[
Bf3    1        s     d  ==
G3     1        s     d  ==
G3     1        s     d  ]]
D4     1        s     d  [[
D4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
A3     1        s     d  [[
A3     1        s     d  ==
A3     1        s     d  ==
A3     1        s     d  ]]
measure 18
C4     1        s     d  [[
C4     1        s     d  ==
C4     1        s     d  ==
C4     1        s     d  ]]
C3     1        s     u  [[
C3     1        s     u  ==
C3     1        s     u  ==
C3     1        s     u  ]]
D3     1        s     u  [[
D3     1        s     u  ==
D3     1        s     u  ==
D3     1        s     u  ]]
D3     1        s     u  [[
D3     1        s     u  ==
D3     1        s     u  ==
D3     1        s     u  ]]
measure 19
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 20
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 21
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
C4     2        e     d  [
C4     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 22
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
F3     2        e     d  [
rest   1        s
F3     1        s     d  =\     &f
F3     3        e.    d  =
F3     1        s     d  ]\
measure 23
F#3    4        q     d
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest   2        e
G3     2        e     d  [
G3     3        e.    d  =
G3     1        s     d  ]\
f2              4n 2
F3     4        q     d
rest   4        q
&
Early stage2 file contains this alternate reading of measure 25
measure 25
rest   2        e
rest   1        s
G3     1        s     d  [/
G3     3        e.    d  =
G3     1        s     d  ]\
f2              4n 2
F3     4        q     d
rest   4        q
&
measure 26
rest   8        h
f1              6
E3     4        q     d
rest   4        q
measure 27
f1              6n
D3     4        q     u
rest   4        q
rest   2        e
C3     2        e     u  [
C3     3        e.    u  =
C3     1        s     u  ]\
&
Early stage2 file contains this alternate reading of measure 27
measure 27
f1              6n
D3     4        q     u
rest   4        q
rest   2        e
rest   1        s
C3     1        s     u  [/
C3     3        e.    u  =
C3     1        s     u  ]\
&
measure 28
f2              6 n
G#2    4        q     u
rest   4        q
rest   8        h
measure 29
A2     3        e.    d  [
A3     1        s     d  =\
A3     3        e.    d  =
A3     1        s     d  ]\
f3              7 5 #
D#3    4        q     u
rest   4        q
measure 30
rest   8        h
f1              #
E3     4        q     d
f1              #
A2     4        q     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
