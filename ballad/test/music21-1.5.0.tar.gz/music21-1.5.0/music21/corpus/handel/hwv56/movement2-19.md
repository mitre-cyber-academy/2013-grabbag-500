&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-19/1} [KHM:1972812308]
TIMESTAMP: DEC/26/2001 [md5sum:27b8e88696a667a0da47af8420c9e35b]
06/12/90 E. Correia
WK#:56        MV#:2,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Tenore
1 20 T
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:34
rest   2        q
A4     1        e     u                    He
A4     1        e     u                    that
C#5    2        q     d                    dwel-
C#5    1        e     d                    leth
D5     1        e     d                    in
measure 2
E5     1        e     d                    hea-
E5     1        e     d                    ven
rest   1        e
G5     1        e     d                    shall
C#5    2        q     d                    laugh
C#5    1        e     d                    them
D5     1        e     d                    to
measure 3
A4     2        q     u                    scorn,
rest   1        e
D5     1        e     d                    the
F#5    2        q     d                    Lord
rest   1        e
F#5    1        e     d                    shall
measure 4
D#5    1        e     d                    have
D#5    1        e     d                    them
D#5    1        e     d                    in
E5     1        e     d                    de-
B4     1        e     d                    ri-
B4     1        e     d                    sion.
rest   2        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-19/2} [KHM:1972812308]
TIMESTAMP: DEC/26/2001 [md5sum:953d38bfebd6391366cf05106585ea53]
06/12/90 E. Correia
WK#:56        MV#:2,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Bassi
1 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:22
C#3    4-       w     u        -
measure 2
C#3    2        h     u
f2              4+ 2
G3     2        h     d
measure 3
F#3    4        w     d
measure 4
f2              4+ 2
A3     2        h     d
f1              #
B3     1        q     d
f1              #
E3     1        q     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
