&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-08/1} [KHM:2387179170]
TIMESTAMP: DEC/26/2001 [md5sum:1c8ac2d49ea543eeacd6fdc4a4dc316c]
06/26/90 E. Correia
WK#:56        MV#:3,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violini unisoni
0 19
Group memberships: score
score: part 1 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:8   T:3/4   C:4   D:Larghetto
rest   8        q
rest   8        q
G4     8        q     u
measure 2
Bf4    8        q     u
A4     8        q     u
G4     8        q     u
measure 3
D5    16        h     d
G5     8        q     d
measure 4
F5    12        q.    d
G5     4        e     d
Ef5    8        q     d
measure 5
Ef5   12        q.    d
F5     4        e     d
D5     8        q     d
measure 6
D5    12        q.    d
Ef5    4        e     d
C5     8        q     d
measure 7
C5    12        q.    d
D5     4        e     d  [
Bf4    4        e     d  =
A4     4        e     d  ]
measure 8
Bf4    4        e     d  [
C5     4        e     d  ]
C5    12        q.    d         &t
D5     4        e     d
measure 9
D5    16        h     d
D5     8        q     d
measure 10
Ef5    4        e     d  [      (
G5     4        e     d  =      )
C5     4        e     d  =      (
Ef5    4        e     d  =      )
A4     4        e     d  =      (
C5     4        e     d  ]      )
measure 11
F4    12        q.    u
rest   2        s
C5     2        s     d  [/
C5     6        e.    d  =      t&(
Bf4    1        t     d  =[[
C5     1        t     d  ]]]     &)
measure 12
D5     4        e     d  [      (
F5     4        e     d  =      )
Bf4    4        e     d  =      (
D5     4        e     d  =      )
G4     4        e     d  =      (
Bf4    4        e     d  ]      )
measure 13
Ef4   12        q.    u
rest   2        s
Bf4    2        s     u  [/
Bf4    6        e.    u  =      t&(
A4     1        t     u  =[[
Bf4    1        t     u  ]]]     &)
measure 14
C5     4        e     d  [      (
Ef5    4        e     d  =      )
A4     4        e     d  =      (
C5     4        e     d  =      )
F#4    4        e     d  =      (
A4     4        e     d  ]      )
measure 15
D4    12        q.    u
rest   2        s
A5     2        s     d  [/
A5     6        e.    d  =      t&(
G5     1        t     d  =[[
A5     1        t     d  ]]]     &)
measure 16
Bf5   12        q.    d
rest   2        s
F#5    2        s     d  [/
F#5    6        e.    d  =      t&(
E5     1        t     d  =[[
F#5    1        t     d  ]]]     &)
measure 17
G5    12        q.    d
rest   2        s
D5     2        s     d  [/
D5     6        e.    d  =      t&(
C5     1        t     d  =[[
D5     1        t     d  ]]]     &)
measure 18
Ef5   12        q.    d
rest   2        s
B4     2        s     u  [/
B4     6        e.    u  =      t&(
A4     1        t     u  =[[
B4     1        t     u  ]]]     &)
measure 19
C5     4        e     d  [      &(
G4     4        e     d  =      &)
Ef5    4        e     d  =      &(
B4     4        e     d  =      &)
C5     4        e     d  =      &(
G4     4        e     d  ]      &)
measure 20
Ef4    4        e     u  [      &(
C4     4        e     u  =      &)
G4     4        e     u  =
Ef4    4        e     u  =
C5     4        e     u  =
G4     4        e     u  ]
measure 21
Ef5    4        e     d  [
C5     4        e     d  =
G5     4        e     d  =
Ef5    4        e     d  =
C5     4        e     d  =
G4     4        e     d  ]
measure 22
Ef5    4        e     d  [
C5     4        e     d  =
G5     4        e     d  =
Ef5    4        e     d  =
C6     4        e     d  =
A5     4        e     d  ]
measure 23
F#5   12        q.    d
rest   2        s
D5     2        s     d  [/
G5     6        e.    d  =
C5     2        s     d  ]\
measure 24
Bf4    6        e.    u  [
A4     2        s     u  ]\
A4    12        q.    u         &t
G4     4        e     u
measure 25
G4    16        h     u
rest   8        q
measure 26
rest  24
measure 27
rest  24
measure 28
rest  24
measure 29
rest   8        q
rest   8        q
G4     8        q     u
measure 30
D5    12        q.    d
C5     4        e     d
Bf4    8        q     d
measure 31
A4     8        q     u
G4     8        q     u
rest   8        q
measure 32
rest  24
measure 33
rest  24
measure 34
rest  24
measure 35
rest   8        q
rest   8        q
Bf4    8        q     d
measure 36
F5    12        q.    d
Ef5    4        e     d
D5     8        q     d
measure 37
C5     8        q     d
Bf4    8        q     d
rest   8        q
measure 38
rest  24
measure 39
rest  24
measure 40
rest  24
measure 41
rest   8        q
rest   8        q
D5     8        q     d         f
measure 42
Ef5    4        e     d  [      (
G5     4        e     d  =      )
C5     4        e     d  =      (
Ef5    4        e     d  =      )
A4     4        e     d  =      (
C5     4        e     d  ]      )
measure 43
F4    12        q.    u
rest   2        s
C5     2        s     d  [/
C5     6        e.    d  =      t
Bf4    1        t     d  =[[
C5     1        t     d  ]]]
measure 44
D5     4        e     d  [      (
F5     4        e     d  =      )
Bf4    4        e     d  =      (
D5     4        e     d  =      )
G4     4        e     d  =      (
Bf4    4        e     d  ]      )
measure 45
Ef4   12        q.    u
rest   2        s
Bf4    2        s     u  [/
Bf4    6        e.    u  =      t
A4     1        t     u  =[[
Bf4    1        t     u  ]]]
measure 46
C5     4        e     d  [      (
Ef5    4        e     d  =      )
A4     4        e     d  =      (
C5     4        e     d  =      )
F#4    4        e     d  =      (
A4     4        e     d  ]      )
measure 47
D4     8        q     u
rest   8        q
rest   8        q
measure 48
rest  24
measure 49
rest  24
measure 50
rest  24
measure 51
rest  24
measure 52
rest   8        q
rest   4        e
rest   2        s
C6     2        s     d  [/
C6     6        e.    d  =      t
Bf5    1        t     d  =[[
C6     1        t     d  ]]]
measure 53
D6    12        q.    d
rest   2        s
A5     2        s     d  [/
A5     6        e.    d  =      t
G5     1        t     d  =[[
A5     1        t     d  ]]]
measure 54
Bf5    8        q     d
rest   8        q
rest   8        q
measure 55
rest  24
measure 56
rest   8        q
rest   4        e
rest   2        s
F5     2        s     d  [/
F5     6        e.    d  =      t
Ef5    1        t     d  =[[
F5     1        t     d  ]]]
measure 57
G5    12        q.    d
rest   2        s
A4     2        s     u  [/
A4     6        e.    u  =      t
G4     1        t     u  =[[
A4     1        t     u  ]]]
measure 58
Bf4    8        q     d
rest   8        q
rest   8        q
measure 59
rest  24
measure 60
rest  24
measure 61
rest  24
measure 62
rest   8        q
rest   4        e
rest   2        s
*               G +     p
C5     2        s     d  [/
C5     6        e.    d  =      t
Bf4    1        t     d  =[[
C5     1        t     d  ]]]
measure 63
D5     4        e     d  [      (
Bf4    4        e     d  =      )
F5     4        e     d  =      (
A4     4        e     d  =      )
Bf4    4        e     d  =      (
F4     4        e     d  ]      )
measure 64
D4     4        e     u  [      (
Bf3    4        e     u  =      )
F4     4        e     u  =      (
D4     4        e     u  =      )
Bf4    4        e     u  =      (
F4     4        e     u  ]      )
measure 65
D5     4        e     d  [      &(
Bf4    4        e     d  =      &)
F5     4        e     d  =      &(
D5     4        e     d  =      &)
Bf5    4        e     d  =
F5     4        e     d  ]
measure 66
D6    12        q.    d
C6     4        e     d
Bf5    8        q     d
measure 67
rest  24
measure 68
rest   8        q
rest   4        e
rest   2        s
F5     2        s     d  [/
F5     6        e.    d  =      &t
Ef5    1        t     d  =[[
F5     1        t     d  ]]]
measure 69
G5     4        e     d  [      &(
Bf5    4        e     d  =      &)
Ef5    4        e     d  =      &(
G5     4        e     d  =      &)
C5     4        e     d  =      &(
Ef5    4        e     d  ]      &)
measure 70
A4     4        e     d  [      &(
C5     4        e     d  =      &)
F5     4        e     d  =      &(
A5     4        e     d  =      &)
D5     4        e     d  =      &(
F5     4        e     d  ]      &)
measure 71
Bf4   12        q.    d
rest   2        s
Ef5    2        s     d  [/
D5     6        e.    d  =
C5     2        s     d  ]\
measure 72
D5     2        s     d  [[     &(
C5     2        s     d  =]
Bf4    4        e     d  ]      &)
A4    12        q.    u
Bf4    4        e     u
measure 73
Bf4   16        h     u
rest   8        q
measure 74
rest  24
measure 75
rest  24
measure 76
rest  24
measure 77
rest  24
measure 78
rest  24
measure 79
rest   8        q
rest   4        e
rest   2        s
A4     2        s     u  [/
A4     6        e.    u  =      t
G4     1        t     u  =[[
A4     1        t     u  ]]]
measure 80
Bf4    4        e     u  [      &(
D5     4        e     u  =      &)
G4     4        e     u  =      &(
Bf4    4        e     u  =      &)
E4     4        e     u  =      &(
G4     4        e     u  ]      &)
measure 81
C4     8        q     u
rest   8        q
rest   8        q
measure 82
A4     4        e     u  [      (
C5     4        e     u  =      )
F4     4        e     u  =      (
A4     4        e     u  =      )
D4     4        e     u  =      (
F4     4        e     u  ]      )
measure 83
Bf3    8        q     u
rest   8        q
rest   8        q
measure 84
G4     4        e     u  [      &(
Bf4    4        e     u  =      &)
E4     4        e     u  =      &(
G4     4        e     u  =      &)
C#4    4        e     u  =      &(
E4     4        e     u  ]      &)
measure 85
A3     8        q     u
rest   8        q
rest   8        q
measure 86
rest  24
measure 87
rest  24
measure 88
rest  24
measure 89
rest  24
measure 90
rest  24
measure 91
rest   8        q
rest   4        e
rest   2        s
A5     2        s     d  [/     f
A5     6        e.    d  =      t
G5     1        t     d  =[[
A5     1        t     d  ]]]
measure 92
Bf5    4        e     d  [      &(
D6     4        e     d  =      &)
G5     4        e     d  =      &(
Bf5    4        e     d  =      &)
E5     4        e     d  =      &(
G5     4        e     d  ]      &)
measure 93
C#5    4        e     d  [      &(
E5     4        e     d  =      &)
A4     4        e     d  =      &(
G5     4        e     d  ]      &)
F5     8        q     d
measure 94
E5     4        e     d  [      &(
D5     4        e     d  ]      &)
C#5   12        q.    d         &t
D5     4        e     d
measure 95
D5     8        q     d
rest   8        q
rest   8        q
measure 96
rest  24
measure 97
rest   8        q
rest   4        e
rest   2        s
B4     2        s     u  [/
B4     6        e.    u  =      t&(
A4     1        t     u  =[[
B4     1        t     u  ]]]     &)
measure 98
C5     4        e     d  [      &(
G4     4        e     d  =      &)
Ef5    4        e     d  =      &(
B4     4        e     d  =      &)
C5     4        e     d  =      &(
G4     4        e     d  ]      &)
measure 99
Ef4    4        e     u  [      &(
C4     4        e     u  =      &)
G4     4        e     u  =
Ef4    4        e     u  =
C5     4        e     u  =
G4     4        e     u  ]
measure 100
Ef5    4        e     d  [
C5     4        e     d  =
G5     4        e     d  =
Ef5    4        e     d  =
C6     4        e     d  =
G5     4        e     d  ]
measure 101
Af5    4        e     d  [      &(
C6     4        e     d  =      &)
F5     6        e.    d  =      &(
Af5    2        s     d  =\     &)
D5     6        e.    d  =      &(
F5     2        s     d  ]\     &)
measure 102
Bf4   12        q.    d
rest   2        s
F5     2        s     d  [/
F5     6        e.    d  =      t&(
Ef5    1        t     d  =[[
F5     1        t     d  ]]]     &)
measure 103
G5     4        e     d  [      (
Bf5    4        e     d  =      )
Ef5    6        e.    d  =      (
G5     2        s     d  =\     )
C5     6        e.    d  =      (
Ef5    2        s     d  ]\     )
measure 104
Af4    4        e     u  [      (
C5     4        e     u  =      )
F4     4        e     u  =      (
Af4    4        e     u  =      )
D4     4        e     u  =      (
F4     4        e     u  ]      )
measure 105
B3     8        q     u
rest   8        q
rest   8        q
measure 106
rest  24
measure 107
rest   8        q
rest   4        e
rest   2        s
G5     2        s     d  [/     f
G5     6        e.    d  =      t&(
F5     1        t     d  =[[
G5     1        t     d  ]]]     &)
measure 108
Af5   12        q.    d
rest   2        s
E5     2        s     d  [/
E5     6        e.    d  =      t&(
D5     1        t     d  =[[
E5     1        t     d  ]]]     &)
measure 109
F5     4        e     d  [
Af5    4        e     d  =
G5     4        e     d  =
D5     4        e     d  =
Ef5    4        e     d  =
B4     4        e     d  ]
measure 110
C5     4        e     u  [
Af4    4        e     u  ]
G4    12        q.    u
rest   2        s
B5     2        s     d
measure 111
C6     8        q     d
C5     8        q     d
rest   8        q
measure 112
rest  24
measure 113
rest   8        q
rest   8        q
G5     8        q     d
measure 114
F5    12        q.    d
G5     4        e     d
Ef5    8        q     d
measure 115
D5     8        q     d
G4     8        q     u
rest   8        q
measure 116
rest  24
measure 117
rest  24
measure 118
rest   8        q
rest   8        q
A5     8        q     d
measure 119
D6    12        q.    d
C6     4        e     d
Bf5    8        q     d
measure 120
A5     8        q     d
D5     8        q     d
F#4    8        q     u
measure 121
F#4   16        h     u
F#4    8        q     u
measure 122
G4    16        h     u
F#4    8        q     u
measure 123
G4    16        h     u
D5     8        q     d
measure 124
G5    24-       h.    d        -
measure 125
G5    24-       h.    d        -
measure 126
G5    24        h.    d
measure 127
F5    24-       h.    d        -
measure 128
F5    24-       h.    d        -
measure 129
F5    16        h     d
F#5    8        q     d
measure 130
G5    16        h     d
D5     8        q     d
measure 131
C5     4        e     d  [
Bf4    4        e     d  ]
A4     8        q     u
G4     8        q     u
measure 132
F#4   12        q.    u         &t
E4     4        e     u
D4     8        q     u
measure 133
rest   8        q
rest   8        q
D5     8        q     d
measure 134
Ef5    4        e     d  [
G5     4        e     d  =
C5     4        e     d  =
Ef5    4        e     d  =
A4     4        e     d  =
C5     4        e     d  ]
measure 135
F4     8        q     u
rest   8        q
rest   8        q
measure 136
D5     4        e     d  [
F5     4        e     d  =
Bf4    4        e     d  =
D5     4        e     d  =
G4     4        e     d  =
Bf4    4        e     d  ]
measure 137
Ef4    8        q     u
rest   8        q
rest   8        q
measure 138
C5     4        e     u  [
Ef5    4        e     u  =
A4     4        e     u  =
C5     4        e     u  =
F#4    4        e     u  =
A4     4        e     u  ]
measure 139
D4     8        q     u
rest   8        q
rest   8        q
measure 140
rest  24
measure 141
rest  24
measure 142
rest   8        q
rest   4        e
rest   2        s
A5     2        s     d  [/
A5     6        e.    d  =      t
G5     1        t     d  =[[
A5     1        t     d  ]]]
measure 143
Bf5   12        q.    d
rest   2        s
F#5    2        s     d  [/
F#5    6        e.    d  =      &t
E5     1        t     d  =[[
F#5    1        t     d  ]]]
measure 144
G5     8        q     d
D5     8        q     d
rest   8        q
measure 145
rest   8        q
rest   8        q
D5     8        q     d
measure 146
Ef5    4        e     d  [
G5     4        e     d  =
C5     4        e     d  =
Ef5    4        e     d  =
A4     4        e     d  =
C5     4        e     d  ]
measure 147
F#4    8        q     u
rest   8        q
rest   8        q
measure 148
rest  24
measure 149
rest   8        q
rest   8        q
D5     8        q     d
measure 150
G5    24-       h.    d        -
measure 151
G5    24-       h.    d        -
measure 152
G5    24        h.    d
measure 153
F5    24-       h.    d        -
measure 154
F5    24-       h.    d        -
measure 155
F5    16        h     d
F#5    8        q     d
measure 156
G5    24        h.    d
measure 157
G4     8        q     u
Ef4    8        q     u
C4     8        q     u
measure 158
A3    24        h.    u         F
measure 159
rest  24
measure 160
rest  24
measure 161
rest  24
measure 162
rest   8        q
rest   8        q
D5     8        q     d         f
measure 163
Ef5    4        e     d  [      &(
G5     4        e     d  =      &)
C5     4        e     d  =      &(
Ef5    4        e     d  =      &)
A4     4        e     d  =      &(
C5     4        e     d  ]      &)
measure 164
F4    12        q.    u
rest   2        s
C5     2        s     d  [/
C5     6        e.    d  =      t&(
Bf4    1        t     d  =[[
C5     1        t     d  ]]]     &)
measure 165
D5     4        e     d  [      &(
F5     4        e     d  =      &)
Bf4    4        e     d  =      &(
D5     4        e     d  =      &)
G4     4        e     d  =      &(
Bf4    4        e     d  ]      &)
measure 166
Ef4   12        q.    u
rest   2        s
Bf4    2        s     u  [/
Bf4    6        e.    u  =      t&(
A4     1        t     u  =[[
Bf4    1        t     u  ]]]     &)
measure 167
C5     4        e     d  [      &(
Ef5    4        e     d  =      &)
A4     4        e     d  =      &(
C5     4        e     d  =      &)
F#4    4        e     d  =      &(
A4     4        e     d  ]      &)
measure 168
D4    12        q.    u
rest   2        s
A5     2        s     d  [/
A5     6        e.    d  =      &(t
G5     1        t     d  =[[
A5     1        t     d  ]]]    &)
measure 169
Bf5   12        q.    d
rest   2        s
F#5    2        s     d  [/
F#5    6        e.    d  =      t&(
E5     1        t     d  =[[
F#5    1        t     d  ]]]     &)
measure 170
G5    12        q.    d
rest   2        s
D5     2        s     d  [/
D5     6        e.    d  =      &(t
C5     1        t     d  =[[
D5     1        t     d  ]]]    &)
measure 171
Ef5   12        q.    d
rest   2        s
B4     2        s     u  [/
B4     6        e.    u  =      &(t
A4     1        t     u  =[[
B4     1        t     u  ]]]    &)
measure 172
C5     4        e     d  [      &(
G4     4        e     d  =      &)
Ef5    4        e     d  =      &(
B4     4        e     d  =      &)
C5     4        e     d  =      &(
G4     4        e     d  ]      &)
measure 173
Ef4    4        e     u  [      &(
C4     4        e     u  =      &)
G4     4        e     u  =
Ef4    4        e     u  =
C5     4        e     u  =
G4     4        e     u  ]
measure 174
Ef5    4        e     d  [
C5     4        e     d  =
G5     4        e     d  =
Ef5    4        e     d  =
C5     4        e     d  =
G4     4        e     d  ]
measure 175
Ef5    4        e     d  [
C5     4        e     d  =
G5     4        e     d  =
Ef5    4        e     d  =
C6     4        e     d  =
A5     4        e     d  ]
measure 176
F#5   12        q.    d
rest   2        s
D5     2        s     d  [/
G5     6        e.    d  =
C5     2        s     d  ]\
measure 177
Bf4    6        e.    u  [
A4     2        s     u  ]\
A4    12        q.    u         &t
G4     4        e     u
measure 178
G4    24        h.    u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-08/2} [KHM:2387179170]
TIMESTAMP: DEC/26/2001 [md5sum:cfcdb6f654003197a217838251ca74a8]
06/26/90 E. Correia
WK#:56        MV#:3,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Soprano
0 19 S
Group memberships: score
score: part 2 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:3/4   C:4   D:Larghetto
rest  12
measure 2
rest  12
measure 3
rest  12
measure 4
rest  12
measure 5
rest  12
measure 6
rest  12
measure 7
rest  12
measure 8
rest  12
measure 9
rest  12
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
rest  12
measure 19
rest  12
measure 20
rest  12
measure 21
rest  12
measure 22
rest  12
measure 23
rest  12
measure 24
rest  12
measure 25
rest   4        q
rest   4        q
G4     4        q     u                    If
measure 26
Bf4    4        q     u         (          God_
A4     4        q     u         )          _
G4     4        q     u                    be
measure 27
D5     4        q     d                    for
D5     4        q     d                    us,
G5     4        q     d                    who
measure 28
F5     6        q.    d                    can
G5     2        e     d                    be
Ef5    4        q     d                    a-
measure 29
D5     4        q     d                    gainst
G4     4        q     u                    us?
rest   4        q
measure 30
rest  12
measure 31
rest   4        q
rest   4        q
G4     4        q     u                    who
measure 32
D5     6        q.    d                    can
C5     2        e     d                    be
Bf4    4        q     d                    a-
measure 33
A4     4        q     u                    gainst
G4     4        q     u                    us,
Bf4    4        q     d                    who
measure 34
F5     6        q.    d                    can
Ef5    2        e     d                    be
D5     4        q     d                    a-
measure 35
C5     4        q     d                    gainst
Bf4    4        q     d                    us?
rest   4        q
measure 36
rest  12
measure 37
rest   4        q
rest   4        q
D5     4        q     d                    if
measure 38
C5     8        h     d                    God
D5     4        q     d                    be
measure 39
Ef5    4        q     d                    for
Ef5    4        q     d                    us,
D5     4        q     d                    who
measure 40
G5     4        q     d                    can
Bf4    4        q     d                    be
C5     4        q     d                    a-
measure 41
D5     4        q     d                    gainst
D5     4        q     d                    us?
rest   4        q
measure 42
rest  12
measure 43
rest  12
measure 44
rest  12
measure 45
rest  12
measure 46
rest  12
measure 47
rest   4        q
A4     4        q     u                    Who
D5     4        q     d                    shall
measure 48
Bf4    3        e.    u  [                 lay_
A4     1        s     u  ]\                _
Bf4    4        q     u                    a-
Ef5    4        q     d                    ny
measure 49
C5     4        q     d                    thing
C5     4        q     d                    to
F5     4        q     d                    the
measure 50
D5     8        h     d                    charge
C5     4        q     d                    of
measure 51
D5     4        q     d         (          God's_
C5     4        q     d         )          _
Bf4    4        q     d                    e-
measure 52
F5    12-       h.    d        -           lect,_
measure 53
F5    12        h.    d                    _
measure 54
rest   4        q
rest   4        q
F4     4        q     u                    of
measure 55
G4     4        q     u         (          God's_
F4     4        q     u         )          _
Ef4    4        q     u                    e-
measure 56
Bf4   12        h.    u                    lect?
measure 57
rest  12
measure 58
rest   4        q
F4     4        q     u                    who
Bf4    4        q     d                    shall
measure 59
G4     4        q     u                    lay
Ef5    4        q     d                    a-
C5     4        q     d                    ny
measure 60
A4     4        q     u                    thing
F5     4        q     d                    to
D5     4        q     d                    the
measure 61
Bf4    2        e     d  [                 charge_
A4     2        e     d  =                 _
Bf4    2        e     d  =                 _
C5     2        e     d  =                 _
D5     2        e     d  =                 _
E5     2        e     d  ]                 _
measure 62
F5    12-       h.    d        -           _
measure 63
F5    12-       h.    d        -           _
measure 64
F5    12-       h.    d        -           _
measure 65
F5    12-       h.    d        -           _
measure 66
F5     6        q.    d                    _
Ef5    2        e     d  [                 _
D5     2        e     d  =                 _
C5     2        e     d  ]                 _
measure 67
Bf4    2        e     d  [                 of_
C5     2        e     d  ]                 _
A4     6        q.    u                    God's
Bf4    2        e     d                    e-
measure 68
Bf4   12        h.    d                    lect?
measure 69
rest  12
measure 70
rest  12
measure 71
rest  12
measure 72
rest  12
measure 73
rest   4        q
D5     4        q     d                    It
D5     4        q     d                    is
measure 74
G5     8        h     d                    God
E5     4        q     d                    that
measure 75
C#5    4        q     d                    jus-
D5     8        h     d                    ti-
measure 76
E5     4        q     d                    \0=-
A4     4        q     u                    eth,
rest   4        q
measure 77
rest   4        q
A4     4        q     u                    it
A4     4        q     u                    is
measure 78
D5    12        h.    d                    God
measure 79
A4     4        q     u                    that
D5     4        q     d                    jus-
F5     4        q     d                    ti-
measure 80
Bf4   12-       h.    d        -           \0=-
measure 81
Bf4    2        e     d  [                 -
D5     2        e     d  =                 -
C5     2        e     d  =                 -
Bf4    2        e     d  =                 -
A4     2        e     d  =                 -
G4     2        e     d  ]                 -
measure 82
A4    12-       h.    u        -           -
measure 83
A4     2        e     u  [                 -
C5     2        e     u  =                 -
Bf4    2        e     u  =                 -
A4     2        e     u  =                 -
G4     2        e     u  =                 -
F4     2        e     u  ]                 -
measure 84
G4    12-       h.    u        -           -
measure 85
G4     2        e     u  [                 -
Bf4    2        e     u  =                 -
A4     2        e     u  =                 -
G4     2        e     u  =                 -
F4     2        e     u  =                 -
E4     2        e     u  ]                 -
measure 86
F4     3        e.    u  [                 -
E4     1        s     u  =\                -
F4     2        e     u  =                 -
A4     2        e     u  =                 -
G4     2        e     u  =                 -
Bf4    2        e     u  ]                 -
measure 87
A4     3        e.    u  [                 -
G4     1        s     u  =\                -
A4     2        e     u  =                 -
C5     2        e     u  =                 -
B4     2        e     u  =                 -
D5     2        e     u  ]                 -
measure 88
C#5    3        e.    d  [                 -
B4     1        s     d  =\                -
C#5    2        e     d  =                 -
E5     2        e     d  =                 -
D5     2        e     d  =                 -
F5     2        e     d  ]                 -
measure 89
E5     2        e     d  [                 -
G5     2        e     d  =                 -
F5     3        e.    d  =                 -
E5     1        s     d  =\                -
F5     2        e     d  =                 -
D5     2        e     d  ]                 -
measure 90
E5     2        e     d  [                 -
B4     2        e     d  ]                 -
C#5    8        h     d                    -
measure 91
D5     8        h     d                    eth,
rest   4        q
measure 92
rest  12
measure 93
rest  12
measure 94
rest  12
measure 95
rest   4        q
D5     4        q     d                    who
G4     4        q     u                    is
measure 96
Ef5    4        q     d                    he
D5     4        q     d                    that
C5     4        q     d                    con-
measure 97
G5     4        q     d                    demn-
G4     4        q     u                    eth?
rest   4        q
measure 98
rest  12
measure 99
rest  12
measure 100
rest   4        q
Ef5    4        q     d                    who
Ef5    4        q     d                    is
measure 101
Ef5    4        q     d                    he
Af5    2        e     d  [                 that_
G5     2        e     d  ]                 _
F5     2        e     d  [                 con-
Ef5    2        e     d  ]                 -
measure 102
D5     2        e     d  [                 demn-
C5     2        e     d  ]                 -
D5     4        q     d                    eth?
D5     2        e     d                    who
D5     2        e     d                    is
measure 103
D5     4        q     d                    he
G5     2        e     d  [                 that_
F5     2        e     d  ]                 _
Ef5    2        e     d  [                 con-
D5     2        e     d  ]                 -
measure 104
C5     4        q     d                    demn-
F5     8-       h     d        -           -
measure 105
F5     6        q.    d                    -
G5     2        e     d  [                 -
Ef5    2        e     d  =                 -
D5     2        e     d  ]                 -
measure 106
Ef5    1        s     d  [[                -
D5     1        s     d  =]                -
C5     2        e     d  ]                 -
B4     8        h     d                    -
measure 107
C5    12        h.    d                    eth?
measure 108
rest  12
measure 109
rest  12
measure 110
rest  12
measure 111
rest   4        q
C5     4        q     d                    It
D5     4        q     d                    is
measure 112
Ef5    8        h     d                    Christ
D5     4        q     d                    that
measure 113
Bf4    4        q     d                    di-
Bf4    4        q     d                    ed,
rest   4        q
measure 114
rest  12
measure 115
rest   4        q
rest   4        q
D5     4        q     d                    yea
measure 116
G4     6        q.    u                    ra-
A4     2        e     u                    ther,
Bf4    2        e     d                    that
C5     2        e     d                    is
measure 117
D5     4        q     d                    ri-
D5     4        q     d                    sen
G5     4        q     d                    a-
measure 118
F#5   12        h.    d                    gain,
measure 119
rest  12
measure 120
rest   4        q
rest   4        q
A4     4        q     u                    who
measure 121
A4     4        q     u                    is
A4     4        q     u                    at
Ef5    4        q     d                    the
measure 122
D5     4        q     d                    right
C5     4        q     d                    hand
Bf4    2        e     u  [                 of_
A4     2        e     u  ]                 _
measure 123
Bf4    8        h     u                    God,
rest   4        q
measure 124
rest   4        q
rest   4        q
D5     4        q     d                    who
measure 125
G4     4        q     u                    makes
D5     6        q.    d                    in-
D5     2        e     d                    ter-
measure 126
Ef5    4        q     d                    ces-
Ef5    4        q     d                    sion
D5     4        q     d                    for
measure 127
C5     4        q     d                    us,
rest   4        q
C5     4        q     d                    who
measure 128
F4     4        q     u                    makes
C5     6        q.    d                    in-
C5     2        e     d                    ter-
measure 129
D5     4        q     d                    ces-
D5     4        q     d                    sion
C5     4        q     d                    for
measure 130
Bf4    4        q     u                    us,
A4     4        q     u                    in-
G4     4        q     u                    ter-
measure 131
Ef5    2        e     d  [                 ces-
D5     2        e     d  ]                 -
C5     4        q     d                    sion
Bf4    4        q     d                    for
measure 132
A4     8        h     u                    us,
A4     4        q     u                    who
measure 133
Bf4    4        q     u                    makes
A4     4        q     u                    in-
G4     4        q     u                    ter-
measure 134
Ef5   12-       h.    d        -           ces-
measure 135
Ef5    2        e     d  [                 -
G5     2        e     d  =                 -
F5     2        e     d  =                 -
Ef5    2        e     d  =                 -
D5     2        e     d  =                 -
C5     2        e     d  ]                 -
measure 136
D5    12-       h.    d        -           -
measure 137
D5     2        e     d  [                 -
F5     2        e     d  =                 -
Ef5    2        e     d  =                 -
D5     2        e     d  =                 -
C5     2        e     d  =                 -
Bf4    2        e     d  ]                 -
measure 138
C5    12-       h.    d        -           -
measure 139
C5     2        e     d  [                 -
Ef5    2        e     d  =                 -
D5     2        e     d  =                 -
C5     2        e     d  =                 -
Bf4    2        e     d  =                 -
A4     2        e     d  ]                 -
measure 140
Bf4    2        e     u  [                 -
A4     2        e     u  =                 -
G4     2        e     u  =                 -
Bf4    2        e     u  =                 -
A4     2        e     u  =                 -
Bf4    2        e     u  ]                 -
measure 141
C5     2        e     d  [                 -
Bf4    2        e     d  =                 -
A4     2        e     d  =                 -
C5     2        e     d  =                 -
Bf4    2        e     d  =                 -
C5     2        e     d  ]                 -
measure 142
D5     4        q     d                    -
G4     4        q     u                    sion,
rest   4        q
measure 143
rest  12
measure 144
rest   4        q
rest   4        q
D5     4        q     d                    who
measure 145
Ef5    4        q     d                    makes
B4     6        q.    d                    in-
B4     2        e     d                    ter-
measure 146
C5    12-       h.    d        -           ces-
measure 147
C5     2        e     d  [                 -
D5     2        e     d  =                 -
Ef5    2        e     d  =                 -
D5     2        e     d  =                 -
C5     2        e     d  =                 -
Bf4    2        e     d  ]                 -
measure 148
A4     2        e     u  [                 sion_
G4     2        e     u  ]                 _
F#4    8        h     u                    for
measure 149
G4     8        h     u                    us,
rest   4        q
measure 150
rest   4        q
rest   4        q
D5     4        q     d                    who
measure 151
G4     4        q     u                    is
D5     6        q.    d                    at
D5     2        e     d                    the
measure 152
Ef5    4        q     d                    right
Ef5    4        q     d                    hand
D5     4        q     d                    of
measure 153
C5     8        h     d                    God,
C5     4        q     d                    who
measure 154
F4     4        q     u                    is
C5     6        q.    d                    at
C5     2        e     d                    the
measure 155
D5     4        q     d                    right
D5     4        q     d                    hand
C5     4        q     d                    of
measure 156
Bf4    4        q     u                    God,
A4     4        q     u                    at
G4     4        q     u                    the
measure 157
Ef5    4        q     d                    right
C5     4        q     d                    hand
A4     4        q     u                    of
measure 158
F#4   12        h.    u         F          God,
measure 159
rest   4        q
rest   4        q
*               D +     Adagio
Ef5    4        q     d                    who
measure 160
D5     4        q     d                    makes
D5     4        q     d                    in-
G5     4        q     d                    ter-
measure 161
Bf4    6        q.    u                    ces-
A4     2        e     u                    sion
G4     4        q     u                    for
measure 162
G4    12        h.    u                    us.
measure 163
rest  12
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest  12
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
rest  12
measure 174
rest  12
measure 175
rest  12
measure 176
rest  12
measure 177
rest  12
measure 178
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-08/3} [KHM:2387179170]
TIMESTAMP: DEC/26/2001 [md5sum:7eaf42eab8b24af4470103a8ab8e845a]
06/26/90 E. Correia
WK#:56        MV#:3,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
0 19
Group memberships: score
score: part 3 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:3/4   C:22   D:Larghetto
G3     8        h     d
rest   4        q
measure 2
rest   4        q
rest   4        q
G2     4        q     u
measure 3
Bf2    4        q     u
A2     4        q     u
G2     4        q     u
measure 4
D3     8        h     d
G3     4        q     d
measure 5
F3     8        h     d
Bf2    4        q     u
measure 6
Ef3    8        h     d
Ef4    4        q     d
measure 7
f2              6 5
F#3    8        h     d
G3     4        q     d
measure 8
F3     4        q     d         +
Ef3    8        h     d
measure 9
D3     4        q     u
Bf2    4        q     u
G2     4        q     u
measure 10
C3     4        q     u
rest   4        q
rest   4        q
measure 11
A3     4        q     d
rest   4        q
rest   4        q
measure 12
Bf2    4        q     u
rest   4        q
rest   4        q
measure 13
G3     4        q     d
rest   4        q
rest   4        q
measure 14
A2     4        q     u
rest   4        q
rest   4        q
measure 15
F#3    4        q     d
rest   4        q
rest   4        q
measure 16
G3     4        q     d
rest   4        q
A3     4        q     d
measure 17
Bf3    4        q     d
rest   4        q
B3     4        q     d
measure 18
C4     4        q     d
rest   4        q
D4     4        q     d
measure 19
Ef4    4        q     d
rest   4        q
rest   4        q
measure 20
rest  12
measure 21
rest  12
measure 22
rest   4        q
rest   4        q
Ef3    4        q     d
measure 23
D3     6        q.    u
rest   1        s
C3     1        s     u
Bf2    4        q     u
measure 24
C3     4        q     u
D3     4        q     u
D2     4        q     u
measure 25
G2     8        h     u
rest   4        q
measure 26
rest   4        q
rest   4        q
G2     4        q     u         p
measure 27
Bf2    4        q     u
A2     4        q     u
G2     4        q     u
measure 28
D3     8        h     d
G3     4        q     d
measure 29
F3     4        q     d
Ef3    8        h     d
measure 30
D3     8        h     d
G3     4        q     d
measure 31
D4     4        q     d
Bf3    4        q     d
G3     4        q     d
measure 32
F#3    8        h     d
G3     4        q     d
measure 33
D3     4        q     d
G2     4        q     u
G3     4        q     d
measure 34
A3     8        h     d
Bf3    4        q     d
measure 35
F3     4        q     d
Bf2    4        q     u
Bf3    4        q     d
measure 36
D4     6        q.    d
C4     2        e     d
Bf3    4        q     d
measure 37
F3     4        q     d
Bf2    4        q     u
Bf3    4        q     d
measure 38
F3     4        q     d
Ef3    4        q     d
D3     4        q     d
measure 39
C3     8        h     u
G3     4        q     d
measure 40
Ef3   12        h.    d
measure 41
f1              #
D3     8        h     d
f1              6
Bf3    4        q     d
measure 42
C3     4        q     u
rest   4        q
rest   4        q
measure 43
A3     4        q     d
rest   4        q
rest   4        q
measure 44
Bf2    4        q     u
rest   4        q
rest   4        q
measure 45
G3     4        q     d
rest   4        q
rest   4        q
measure 46
A2     4        q     u
rest   4        q
rest   4        q
measure 47
F#3    4        q     d
rest   4        q
rest   4        q
measure 48
G3     4        q     d
rest   4        q
rest   4        q
measure 49
A3     4        q     d
rest   4        q
rest   4        q
measure 50
Bf3    4        q     d
rest   4        q
A3     4        q     d
measure 51
Bf3    4        q     d
A3     4        q     d
G3     4        q     d
measure 52
F3     4        q     d
rest   4        q
A3     4        q     d
measure 53
Bf3    4        q     d
rest   4        q
C4     4        q     d
measure 54
D4     4        q     d
rest   4        q
D3     4        q     d
measure 55
Ef3    4        q     d
D3     4        q     d
C3     4        q     u
measure 56
Bf2    4        q     u
rest   4        q
D3     4        q     d
measure 57
Ef3    4        q     d
rest   4        q
C3     4        q     u
measure 58
D3     4        q     d
rest   4        q
rest   4        q
measure 59
Ef3    4        q     d
C3     4        q     u
Ef3    4        q     d
measure 60
F3     4        q     d
D3     4        q     d
F3     4        q     d
measure 61
G3     4        q     d
rest   4        q
G3     4        q     d
measure 62
A3     4        q     d
F3     4        q     d
A3     4        q     d
measure 63
Bf3    4        q     d
rest   4        q
rest   4        q
measure 64
rest  12
measure 65
rest  12
measure 66
Bf2    6        q.    u
C3     2        e     u
D3     4        q     u
measure 67
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 68
Bf2    4        q     u
rest   4        q
D3     4        q     d
measure 69
Ef3    4        q     d
rest   4        q
rest   4        q
measure 70
F3     4        q     d
rest   4        q
rest   4        q
measure 71
G3     6        q.    d
rest   1        s
A3     1        s     d
Bf3    4        q     d
measure 72
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 73
Bf2    4        q     u
rest   4        q
rest   4        q
measure 74
rest   4        q
Bf3    4        q     d
f1              6n
G3     4        q     d
measure 75
A3     4        q     d
F3     4        q     d
D3     4        q     d
measure 76
f2              6 n
C#3    8        h     u
D3     4        q     d
measure 77
f2              5n #
A2     4        q     u
A3     4        q     d
f2              4+ 2
G3     4        q     d
measure 78
F3     4        q     d
F3     4        q     d
E3     4        q     d
measure 79
D3     4        q     d
F3     4        q     d
D3     4        q     d
measure 80
G3     4        q     d
rest   4        q
rest   4        q
measure 81
E3     4        q     d
rest   4        q
rest   4        q
measure 82
F3     4        q     d
rest   4        q
rest   4        q
measure 83
D3     4        q     d
rest   4        q
rest   4        q
measure 84
E3     4        q     d
rest   4        q
rest   4        q
measure 85
C#3    4        q     u
rest   4        q
rest   4        q
measure 86
D3     4        q     d
rest   4        q
E3     4        q     d
measure 87
F3     4        q     d
rest   4        q
G3     4        q     d
measure 88
A3     4        q     d
rest   4        q
B3     4        q     d
measure 89
C#4    4        q     d
rest   4        q
D4     4        q     d
measure 90
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 91
D3     4        q     d
E3     4        q     d
F3     4        q     d
measure 92
G3     4        q     d
Bf3    6        q.    d
Bf3    2        e     d
measure 93
A3     6        q.    d
C#4    2        e     d
D4     4        q     d
measure 94
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 95
D3     4        q     d
rest   4        q
f1              6
B3     4        q     d
measure 96
C4     4        q     d
Bf3    4        q     d         +
Af3    4        q     d
measure 97
G3     4        q     d
rest   4        q
F3     4        q     d
measure 98
Ef3    4        q     d
C3     4        q     u
rest   4        q
measure 99
rest  12
measure 100
rest   4        q
C4     4        q     d
Ef3    4        q     d
measure 101
F3     4        q     d
rest   4        q
rest   4        q
measure 102
Bf3    4        q     d
rest   4        q
rest   4        q
measure 103
Ef3    4        q     d
rest   4        q
rest   4        q
measure 104
Af3    4        q     d
rest   4        q
rest   4        q
measure 105
G3     6        q.    d
B3     2        e     d
C4     4        q     d
measure 106
F3     4        q     d
G3     4        q     d
G2     4        q     u
measure 107
C3     4        q     u
D3     4        q     d
Ef3    4        q     d
measure 108
f1              f
F3     4        q     d
rest   4        q
f1              6n
G3     4        q     d
measure 109
Af3    4        q     d
B2     4        q     u
C3     4        q     u
measure 110
rest   2        e
F3     2        e     d
G3     4        q     d
G2     4        q     u
measure 111
C3     8        h     u
rest   4        q
measure 112
F#2    8        h     u
F#3    4        q     d
measure 113
G3    12        h.    d
measure 114
A3    12        h.    d
measure 115
Bf3   12        h.    d
measure 116
Ef3   12        h.    d
measure 117
D3     4        q     u
Bf2    4        q     u
G2     4        q     u
measure 118
D3     4        q     d
D4     4        q     d
C4     4        q     d
measure 119
Bf3    6        q.    d
A3     2        e     d
G3     4        q     d
measure 120
D4     8        h     d
D3     4        q     d
measure 121
C3     8        h     u
C3     4        q     u
measure 122
Bf2    4        q     u
A2     4        q     u
D3     4        q     u
measure 123
G2     8        h     u
rest   4        q
measure 124
rest   4        q
rest   4        q
G3     4        q     d
measure 125
Bf2    8        h     u
Bf3    4        q     d
measure 126
C4     8        h     d
Bf3    4        q     d
measure 127
A3     8        h     d
rest   4        q
measure 128
A2     8        h     u
A3     4        q     d
measure 129
Bf3    8        h     d
A3     4        q     d
measure 130
G3    12        h.    d
measure 131
C3     8        h     u
C#3    4        q     u
measure 132
D3     8        h     d
F#3    4        q     d
measure 133
G3     4        q     d
A3     4        q     d
Bf3    4        q     d
measure 134
C3     4        q     u
rest   4        q
rest   4        q
measure 135
A3     4        q     d
rest   4        q
rest   4        q
measure 136
Bf2    4        q     u
rest   4        q
rest   4        q
measure 137
G3     4        q     d
rest   4        q
rest   4        q
measure 138
A2     4        q     u
rest   4        q
rest   4        q
measure 139
F#3    4        q     d
rest   4        q
rest   4        q
measure 140
G3     4        q     d
rest   4        q
rest   4        q
measure 141
A3     4        q     d
rest   4        q
rest   4        q
measure 142
Bf3    4        q     d
rest   4        q
f1              6
F#3    4        q     d
measure 143
G3     4        q     d
rest   4        q
f1              6+
A3     4        q     d
measure 144
Bf3    4        q     d
rest   4        q
B3     4        q     d
measure 145
C4     4        q     d
rest   4        q
G3     4        q     d
measure 146
C3     4        q     u
rest   4        q
Ef3    4        q     d
measure 147
f1              #
D3     4        q     d
rest   4        q
G3     4        q     d
measure 148
C3     4        q     u
D3     4        q     u
D2     4        q     u
measure 149
G2     8        h     u
rest   4        q
measure 150
rest   4        q
rest   4        q
G3     4        q     d
measure 151
Bf2    8        h     u
Bf3    4        q     d
measure 152
C4     4        q     d
C4     4        q     d
Bf3    4        q     d
measure 153
A3    12        h.    d
measure 154
A2     8        h     u
A3     4        q     d
measure 155
Bf3    4        q     d
Bf3    4        q     d
A3     4        q     d
measure 156
G3     4        q     d
A3     4        q     d
Bf3    4        q     d
measure 157
C3    12        h.    u
measure 158
D3    12        h.    d         F
measure 159
rest   4        q
rest   4        q
f2              4+ 3
C3     4        q     u
measure 160
f1              6
Bf2    8        h     u
C3     4        q     u
measure 161
D3     8        h     u
D2     4        q     u
measure 162
G2     8        h     u
Bf3    4        q     d         f
measure 163
C3     4        q     u
rest   4        q
rest   4        q
measure 164
A3     4        q     d
rest   4        q
rest   4        q
measure 165
Bf2    4        q     u
rest   4        q
rest   4        q
measure 166
G3     4        q     d
rest   4        q
rest   4        q
measure 167
A2     4        q     u
rest   4        q
rest   4        q
measure 168
F#3    4        q     d
rest   4        q
rest   4        q
measure 169
G3     4        q     d
rest   4        q
f1              6+
A3     4        q     d
measure 170
f1              6
Bf3    4        q     d
rest   4        q
B3     4        q     d
measure 171
C4     4        q     d
rest   4        q
f1              6n
D4     4        q     d
measure 172
Ef4    4        q     d
rest   4        q
rest   4        q
measure 173
rest  12
measure 174
rest  12
measure 175
rest   4        q
rest   4        q
Ef3    4        q     d
measure 176
D3     6        q.    u
rest   1        s
C3     1        s     u
Bf2    4        q     u
measure 177
C3     4        q     u
D3     4        q     u
D2     4        q     u
measure 178
G2    12        h.    u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
