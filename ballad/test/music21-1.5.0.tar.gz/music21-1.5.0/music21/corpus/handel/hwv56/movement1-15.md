&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-15/1} [KHM:1435814151]
TIMESTAMP: DEC/26/2001 [md5sum:97f02c101afc271c8cb30c1eef63caed]
04/09/90 E. Correia
WK#:56        MV#:1,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Soprano
1 20 S
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:4
rest   4        q
G4     2        e     u                    There
G4     2        e     u                    were
C5     2        e     d                    shep-
C5     2        e     d                    herds
rest   2        e
C5     2        e     d                    a-
measure 2
C5     2        e     d                    bid-
C5     2        e     d                    ing
C5     2        e     d                    in
D5     2        e     d                    the
B4     4        q     d                    \0=eld,
rest   2        e
B4     1        s     d                    keep-
C5     1        s     d                    ing
measure 3
D5     4        q     d                    watch
rest   4        q
D5     2        e     d                    o-
D5     1        s     d                    ver
E5     1        s     d                    their
F5     2        e     d                    \0>ock
E5     2        e     d                    by
measure 4
C5     4        q     d                    night.
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-15/2} [KHM:1435814151]
TIMESTAMP: DEC/26/2001 [md5sum:5ec55f9f5bbfc264e0ab914a8ba46063]
04/09/90 E. Correia
WK#:56        MV#:1,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Bassi
1 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:22
C3     4-       w     u        -
measure 2
f1     2        b
f3              7 4 2
C3     4-       w     u        -
measure 3
C3     4-       w     u        -
measure 4
f2              5 3
C3     4        w     u
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
