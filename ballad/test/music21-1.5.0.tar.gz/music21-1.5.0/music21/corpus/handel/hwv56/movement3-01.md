&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-01/1} [KHM:3127120370]
TIMESTAMP: DEC/26/2001 [md5sum:3e757b357f59f686c10018a0a333a1df]
06/24/90 E. Correia
WK#:56        MV#:3,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violini unisoni
1 19
Group memberships: score
score: part 1 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:12   T:3/4   C:4   D:Larghetto
rest  12        q
rest  12        q
B4    12        q     d
measure 2
E5    24        h     d
G#4    9        e.    u  [      (t
F#4    3        s     u  ]\     )
measure 3
E4    24        h     u
C#5   12        q     d
measure 4
A4    18        q.    u         (&t
G#4    6        e     u         )
A4    12        q     u
measure 5
G#4   12        q     u
rest   6        e
G#5    6        e     d  [
F#5    6        e     d  =      (t
E5     6        e     d  ]      )
measure 6
B4    36-       h.    d        -
measure 7
B4    18        q.    d
rest   3        s
G#4    3        s     u  [/
F#4    9        e.    u  =      t
E4     3        s     u  ]\
measure 8
E5    36-       h.    d        -
measure 9
E5    12        q     d
rest   6        e
E4     6        e     u  [
D#4    6        e     u  =
C#4    6        e     u  ]
measure 10
B3     9        e.    u  [      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  ]\     )
measure 11
A3     9        e.    u  [      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  ]\     )
measure 12
G#3   18        q.    u
rest   3        s
G#4    3        s     u  [/
F#4    9        e.    u  =      t
E4     3        s     u  ]\
measure 13
D#4   18        q.    u
rest   3        s
A5     3        s     d  [/
G#5    9        e.    d  =      t
F#5    3        s     d  ]\
measure 14
G#5    4        e  3  d  [      (*
F#5    4        e  3  d  =
E5     4        e  3  d  ]      )!
D#5   18        q.    d         &t
E5     6        e     d
measure 15
E4    18        q.    u
F#4    6        e     u  [
G#4    6        e     u  =
A4     6        e     u  ]
measure 16
B4    18        q.    d
C#5    3        s     d  [[     (
D#5    3        s     d  ]]
E5     6        e     d  [
D#5    3        s     d  =[
C#5    3        s     d  ]]     )
measure 17
B4     3        s     d  [[     &(
C#5    3        s     d  =]     &)
A4     6        e     d  ]
G#4   12        q     u         &(
F#4    9        e.    u  [      &)t
E4     3        s     u  ]\
measure 18
E4    24        h     u
rest  12        q
measure 19
rest  36
measure 20
rest  36
measure 21
rest  36
measure 22
rest  12        q
rest  12        q
B4    12        q     u         p
measure 23
E5    24        h     d
G#4    9        e.    u  [      &(t
F#4    3        s     u  ]\     &)
measure 24
E4    24        h     u
C#5   12        q     d
measure 25
A4    18        q.    u         &(t
G#4    6        e     u         &)
A4    12        q     u
measure 26
G#4   24        h     u
rest  12        q
measure 27
rest  36
measure 28
rest  12        q
rest   6        e
G#4    6        e     u  [
F#4    6        e     u  =      (t
E4     6        e     u  ]      )
measure 29
B3    24        h     u
rest  12        q
measure 30
rest  12        q
rest   6        e
G#4    6        e     u  [
F#4    6        e     u  =      &(
E4     6        e     u  ]      &)
measure 31
A#4   24        h     u
rest  12        q
measure 32
rest  12        q
rest   6        e
B4     6        e     u  [
A#4    6        e     u  =      &(
G#4    6        e     u  ]      &)
measure 33
F#4   36        h.    u
measure 34
rest  36
measure 35
rest  12        q
rest  12        q
F#5   12        q     d         f
measure 36
B5    24        h     d
D#5    9        e.    d  [      (&t
C#5    3        s     d  ]\     )
measure 37
B4    24        h     d
G#5   12        q     d
measure 38
E5    18        q.    d         &t
D#5    6        e     d
E5    12        q     d
measure 39
D#5   24        h     d
rest  12        q
measure 40
rest  36
measure 41
rest  36
measure 42
rest  36
measure 43
rest  36
measure 44
rest  36
measure 45
rest  12        q
rest   6        e
G#5    6        e     d  [      p
F#5    6        e     d  =      (t
E5     6        e     d  ]      )
measure 46
B4    36-       h.    d        -
measure 47
B4    24        h     d
C#5    9        e.    d  [
B4     3        s     d  ]\
measure 48
C#5   24-       h     d        -
C#5    6        e     d  [
D#5    6        e     d  ]
measure 49
E5    18        q.    d
E4     6        e     u  [
F#4    6        e     u  =      &(
G#4    6        e     u  ]      &)
measure 50
A4    18        q.    u
E4     6        e     u  [
D#4    6        e     u  =      &(
C#4    6        e     u  ]      &)
measure 51
B3    24        h     u
rest  12        q
measure 52
rest  36
measure 53
rest  12        q
rest   6        e
G#4    6        e     u  [
F#4    6        e     u  =      &(
E4     6        e     u  ]      &)
measure 54
B3    24        h     u
rest  12        q
measure 55
rest  12        q
rest   6        e
G#4    6        e     u  [
F#4    6        e     u  =      &(
E4     6        e     u  ]      &)
measure 56
E5    24-       h     d        -
E5     6        e     d  [
E5     6        e     d  ]
measure 57
E5     9        e.    d  [      &(
F#5    3        s     d  =\     &)
G#5    6        e     d  =
E5     6        e     d  =
D#5    6        e     d  =      &(
C#5    6        e     d  ]      &)
measure 58
B4    36-       h.    d        -
measure 59
B4    18        q.    d
C#5    6        e     u  [
A4     6        e     u  =      &(
G#4    6        e     u  ]      &)
measure 60
A4    18        q.    u
G#4    6        e     u  [
F#4    6        e     u  =      &(
E4     6        e     u  ]      &)
measure 61
D#4   18        q.    u
F#4    6        e     u
B3    12        q     u
measure 62
rest  36
measure 63
rest  36
measure 64
rest  36
measure 65
rest  36
measure 66
rest  12        q
rest   6        e
G#5    6        e     d  [      f
F#5    9        e.    d  =      &t
E5     3        s     d  ]\
measure 67
B4    36        h.    d
measure 68
rest  12        q
rest   6        e
G#4    6        e     u  [
F#4    9        e.    u  =      &t
E4     3        s     u  ]\
measure 69
C#5   24-       h     d        -
C#5    6        e     d  [
D#5    6        e     d  ]
measure 70
E5    18        q.    d
E4     6        e     u  [
D#4    6        e     u  =
C#4    6        e     u  ]
measure 71
B3     9        e.    u  [      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  ]\     )
measure 72
A3     9        e.    u  [      &(
B3     3        s     u  =\     &)
A3     9        e.    u  =      &(
B3     3        s     u  =\     &)
A3     9        e.    u  =      &(
A4     3        s     u  ]\     &)
measure 73
G#4   18        q.    u
F#4    6        e     u
E4     4        e  3  u  [      (*
F#4    4        e  3  u  =
G#4    4        e  3  u  ]      )!
measure 74
A4     4        e  3  u  [      (*
G#4    4        e  3  u  =
F#4    4        e  3  u  ]      )!
D#4   18        q.    u         t
E4     6        e     u
measure 75
E4    24        h     u
rest  12        q
measure 76
rest  36
measure 77
rest  36
measure 78
rest  12        q
rest   6        e
E4     6        e     u  [      p
D#4    6        e     u  =      &(
C#4    6        e     u  ]      &)
measure 79
B3     9        e.    u  [      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  ]\     )
measure 80
A3     9        e.    u  [      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  ]\     )
measure 81
G#3   12        q     u
rest  12        q
rest  12        q
measure 82
rest  36
measure 83
rest  36
measure 84
rest   6        e
C#5    6        e     d  [      p
B4     9        e.    d  =      (
C#5    3        s     d  =\     )
B4     9        e.    d  =      (
C#5    3        s     d  ]\     )
measure 85
B4     9        e.    d  [      (
C#5    3        s     d  =\     )
B4     9        e.    d  =      (
C#5    3        s     d  =\     )
B4     9        e.    d  =      (
C#5    3        s     d  ]\     )
measure 86
B4     9        e.    d  [      (
C#5    3        s     d  =\     )
B4     9        e.    d  =      (
C#5    3        s     d  =\     )
B4     9        e.    d  =      (
C#5    3        s     d  ]\     )
measure 87
B4     9        e.    d  [
C#5    3        s     d  ]\
B4    12        q     d
A#4   12        q     u         &t
measure 88
B4    24        h     d
F#5   12        q     d         f
measure 89
B5    24        h     d
D#5    9        e.    d  [      &(t
C#5    3        s     d  ]\     &)
measure 90
B4    24        h     d
G#5   12        q     d
measure 91
E5    18        q.    d         &(t
D#5    6        e     d         &)
E5    12        q     d
measure 92
D#5   24        h     d
rest  12        q
measure 93
rest  36
measure 94
rest  36
measure 95
rest  36
measure 96
rest  12        q
rest   6        e
A4     6        e     u  [      &p
G#4    6        e     u  =      &(
F#4    6        e     u  ]      &)
measure 97
E4     9        e.    u  [      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  ]\     )
measure 98
E4     9        e.    u  [      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  ]\     )
measure 99
E4     9        e.    u  [      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      (
F#4    3        s     u  ]\     )
measure 100
E4     9        e.    u  [      &(
F#4    3        s     u  =\     &)
E4     9        e.    u  =      &(
F#4    3        s     u  =\     &)
E4     9        e.    u  =      &(
F#4    3        s     u  ]\     &)
measure 101
E4     9        e.    u  [      &(
F#4    3        s     u  =\     &)
E4     9        e.    u  =      &(
F#4    3        s     u  =\     &)
E4     9        e.    u  =      &(
F#4    3        s     u  ]\     &)
measure 102
E4    18        q.    u
D4     6        e     u
C#4   12        q     u
measure 103
D4    12        q     u
B3    12        q     u
E4    12        q     u
measure 104
C#4   12        q     u
rest   6        e
C#5    6        e     u  [      f
B4     6        e     u  =      &(t
A4     6        e     u  ]      &)
measure 105
E4    24        h     u
rest  12        q
measure 106
rest  36
measure 107
rest  12        q
rest   6        e
D5     6        e     d  [      p
C#5    6        e     d  =
B4     6        e     d  ]
measure 108
A4     6        e     u  [
G#4    6        e     u  =
F#4    6        e     u  =
E4     6        e     u  =
D4     6        e     u  =
C#4    6        e     u  ]
measure 109
B3    12        q     u
E4    12        q     u
rest  12        q
measure 110
rest  36
measure 111
rest  36
measure 112
rest  36
measure 113
rest  36
measure 114
rest  36
measure 115
rest  12        q
rest  12        q
E5    12        q     d         f
measure 116
A5    24        h     d
C#5    9        e.    d  [      &(t
B4     3        s     d  ]\     &)
measure 117
A4    24        h     u
F#5   12        q     d
measure 118
D5    18        q.    d         &(t
C#5    6        e     d         &)
D5    12        q     d
measure 119
C#5   36        h.    d
measure 120
rest  36
measure 121
rest  36
measure 122
rest  36
measure 123
rest  12        q
rest   6        e
E4     6        e     u  [      p
D#4    6        e     u  =      &(
C#4    6        e     u  ]      &)
measure 124
B3     9        e.    u  [      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  =\     )
B3     9        e.    u  =      (
C#4    3        s     u  ]\     )
measure 125
A3     9        e.    u  [      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  =\     )
A3     9        e.    u  =      (
B3     3        s     u  ]\     )
measure 126
G#3    9        e.    u  [      &(
A3     3        s     u  =\     &)
G#3    9        e.    u  =      &(
A3     3        s     u  =\     &)
G#3    9        e.    u  =      &(
G#4    3        s     u  ]\     &)
measure 127
F#4    9        e.    u  [      (
G#4    3        s     u  =\     )
F#4    9        e.    u  =      (
G#4    3        s     u  =\     )
F#4    9        e.    u  =      (
G#4    3        s     u  ]\     )
measure 128
E4     9        e.    u  [      (
F#4    3        s     u  =\     )
E4     9        e.    u  =      &(
F#4    3        s     u  =\     &)
E4     9        e.    u  =      &(
F#4    3        s     u  ]\     &)
measure 129
D#4   12        q     u         .(
D#4   12        q     u         .
D#4   12        q     u         .)
measure 130
F#4   12        q     u         .(
F#4   12        q     u         .
F#4   12        q     u         .)
measure 131
B3    12        q     u         .(
B3    12        q     u         .
B3    12        q     u         .)
measure 132
C#4   12        q     u         .(
C#4   12        q     u         .
D#4   12        q     u         .)
measure 133
E4    24        h     u
rest  12        q
measure 134
rest  36
measure 135
rest  36
measure 136
rest  36
measure 137
rest  12        q
rest  12        q
B5    12        q     d         p
measure 138
A#5    9        e.    d  [      (
B5     3        s     d  =\     )
A#5    9        e.    d  =      (
B5     3        s     d  =\     )
A#5    9        e.    d  =      (
B5     3        s     d  ]\     )
measure 139
E5    24        h     d
A5    12        q     d         +
measure 140
G#5    4        e  3  d  [      *&(
F#5    4        e  3  d  =
E5     4        e  3  d  ]      !&)
G#5   12        q     d          &(
F#5    9        e.    d  [       &)t
E5     3        s     d  ]\
measure 141
E5    24        h     d
rest  12        q
measure 142
rest  36
measure 143
rest  36
measure 144
rest  36
measure 145
rest  36
measure 146
rest  36
measure 147
rest  12        q
rest  12        q
B4    12        q     u
measure 148
A#4    9        e.    u  [      (
B4     3        s     u  =\     )
A#4    9        e.    u  =      (
B4     3        s     u  =\     )
A#4    9        e.    u  =      (
B4     3        s     u  ]\     )
measure 149
B3    24        h     u
rest  12        q
measure 150
rest  36
measure 151
rest  36
measure 152
rest  36
measure 153
rest  12        q
rest  12        q
B4    12        q     d         f
measure 154
E5    24        h     d
G#4    9        e.    u  [      &(t
F#4    3        s     u  ]\     &)
measure 155
E4    24        h     u
C#5   12        q     d
measure 156
A4    18        q.    u         &(t
G#4    6        e     u         &)
A4    12        q     u
measure 157
G#4   12        q     u
rest   6        e
G#5    6        e     d  [
F#5    6        e     d  =      &(t
E5     6        e     d  ]      &)
measure 158
B4    12        q     d
rest   6        e
E4     6        e     u  [
D#4    6        e     u  =      &(t
C#4    6        e     u  ]      &)
measure 159
B3    18        q.    u
rest   3        s
A5     3        s     d  [/
G#5    9        e.    d  =      &t
F#5    3        s     d  ]\
measure 160
G#5    4        e  3  d  [      *&(
F#5    4        e  3  d  =
E5     4        e  3  d  ]      !&)
D#5   18        q.    d         &t
E5     6        e     d
measure 161
E4    18        q.    u
F#4    6        e     u  [
G#4    6        e     u  =
A4     6        e     u  ]
measure 162
B4    18        q.    d
C#5    3        s     d  [[     &(
D#5    3        s     d  ]]
E5     6        e     d  [
D#5    3        s     d  =[
C#5    3        s     d  ]]     &)
measure 163
B4     3        s     d  [[     &(
C#5    3        s     d  =]     &)
A4     6        e     d  ]
G#4   12        q     u         &(
F#4    9        e.    u  [      &)t
E4     3        s     u  ]\
measure 164
E4    36        h.    u         F
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-01/2} [KHM:3127120370]
TIMESTAMP: DEC/26/2001 [md5sum:20a55fe681e38e4134796473aa916a84]
06/24/90 E. Correia
WK#:56        MV#:3,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Soprano
1 19 S
Group memberships: score
score: part 2 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:3/4   C:4   D:Larghetto
rest  12
measure 2
rest  12
measure 3
rest  12
measure 4
rest  12
measure 5
rest  12
measure 6
rest  12
measure 7
rest  12
measure 8
rest  12
measure 9
rest  12
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
rest   4        q
rest   4        q
B4     4        q     d                    I
measure 19
E5     8        h     d                    know
G#4    3        e.    u  [      (          that_
F#4    1        s     u  ]\     )          _
measure 20
E4     8        h     u                    my
C#5    4        q     d                    Re-
measure 21
A4     6        q.    u         (          deem-
G#4    2        e     u         )          -
A4     4        q     u                    er
measure 22
G#4    4        q     u                    liv-
G#4    4        q     u                    eth,
rest   4        q
measure 23
rest  12
measure 24
rest  12
measure 25
rest  12
measure 26
rest   4        q
B4     4        q     d                    and
B4     4        q     d                    that
measure 27
E5     8        h     d                    he
F#5    4        q     d                    shall
measure 28
B4    12-       h.    d        -           stand_
measure 29
B4     6        q.    d                    _
G#4    2        e     u  [                 at_
F#4    2        e     u  ]                 _
E4     2        e     u                    the
measure 30
C#5   12-       h.    d        -           lat-
measure 31
C#5    6        q.    d                    -
A#4    2        e     u  [                 ter_
G#4    2        e     u  =                 _
F#4    2        e     u  ]                 _
measure 32
E5    12-       h.    d        -           day_
measure 33
E5     6        q.    d                    _
F#5    2        e     d  [                 _
D#5    2        e     d  =                 _
C#5    2        e     d  ]                 _
measure 34
D#5    1        s     d  [[                _
C#5    1        s     d  ]]                _
B4     2        e     d                    up-
A#4    6        q.    u                    on
B4     2        e     d                    the
measure 35
B4     8        h     d                    earth.
rest   4        q
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest   4        q
rest   4        q
B4     4        q     d                    I
measure 40
E5     8        h     d                    know
G#4    3        e.    u  [      &(         that_
F#4    1        s     u  ]\     &)         _
measure 41
E4     8        h     u                    my
C#5    4        q     d                    Re-
measure 42
A4     8        h     u         t          deem-
G#4    4        q     u                    er
measure 43
F#4    4        q     u                    liv-
F#4    4        q     u                    eth,
F#4    4        q     u                    and
measure 44
G#4    6        q.    u                    that
G#4    2        e     u  [                 He_
F#4    2        e     u  ]                 _
E4     2        e     u                    shall
measure 45
B4    12-       h.    d        -           stand_
measure 46
B4    12-       h.    d        -           _
measure 47
B4     8        h     d                    _
C#5    3        e.    d                    at
B4     1        s     d                    the
measure 48
C#5    8-       h     d        -           lat-
C#5    2        e     d                    -
D#5    2        e     d                    ter
measure 49
E5     6        q.    d                    day
E4     2        e     u                    up-
F#4    2        e     u                    on
G#4    2        e     u                    the
measure 50
A4    12-       h.    u        -           earth,_
measure 51
A4     6        q.    u                    _
B4     2        e     u  [                 _
G#4    2        e     u  =                 _
F#4    2        e     u  ]                 _
measure 52
G#4    2        e     u                    _
A4     2        e     u                    up-
F#4    6        q.    u                    on
E4     2        e     u                    the
measure 53
E4     8        h     u                    earth;
B4     4        q     d                    I
measure 54
B4    12-       h.    d        -           know_
measure 55
B4     6        q.    d                    _
G#4    2        e     u                    that
F#4    2        e     u                    my
E4     2        e     u                    Re-
measure 56
E5     8-       h     d        -           deem-
E5     2        e     d                    -
E5     2        e     d                    er
measure 57
E5     3        e.    d  [      (          liv-
F#5    1        s     d  ]\     )          -
G#5    2        e     d                    eth,
E5     2        e     d                    and
D#5    2        e     d                    that
C#5    2        e     d                    he
measure 58
B4    12-       h.    d        -           shall_
measure 59
B4     6        q.    d                    _
C#5    2        e     d                    stand
A4     2        e     u                    at
G#4    2        e     u                    the
measure 60
A4    12-       h.    u        -           lat-
measure 61
A4     6        q.    u                    -
B4     2        e     u                    ter
G#4    2        e     u  [                 day_
F#4    2        e     u  ]                 _
measure 62
G#4    2        e     u  [                 up-
A4     2        e     u  ]                 -
F#4    6        q.    u                    on
E4     2        e     u                    the
measure 63
E4     6        q.    u                    earth,_
F#4    2        e     u  [                 _
G#4    2        e     u  =                 _
A4     2        e     u  ]                 _
measure 64
B4     6        q.    d                    _
C#5    1        s     d  [[                _
D#5    1        s     d  ]]                _
E5     2        e     d  [                 _
D#5    1        s     d  =[                _
C#5    1        s     d  =]                _
measure 65
B4     2        e     d  ]                 _
A4     2        e     u                    up-
G#4    4        q     u         (          on_
F#4    3        e.    u         )          _
E4     1        s     u                    the
measure 66
E4     8        h     u                    earth.
rest   4        q
measure 67
rest  12
measure 68
rest  12
measure 69
rest  12
measure 70
rest  12
measure 71
rest  12
measure 72
rest  12
measure 73
rest  12
measure 74
rest  12
measure 75
rest   4        q
E4     4        q     u                    And
G#4    4        q     u                    though
measure 76
B4     8        h     d                    worms
B4     4        q     d                    de-
measure 77
C#5    4        q     d                    stroy
D#5    8        h     d                    this
measure 78
E5     4        q     d                    bo-
E4     4        q     u                    dy,
rest   4        q
measure 79
rest  12
measure 80
rest  12
measure 81
E4     4        q     u                    yet
G#4    4        q     u                    in
A4     4        q     u                    my
measure 82
B4     8        h     d                    \0>esh
C#5    4        q     d                    shall
measure 83
A4     4        q     u                    I
G#4    8        h     u                    see
measure 84
F#4    8        h     u                    God,
F#5    4        q     d                    yet
measure 85
C#5    8        h     d                    in
D#5    4        q     d                    my
measure 86
E5     4        q     d         (          \0>esh_
D#5    4        q     d         )          _
C#5    4        q     d                    shall
measure 87
D#5    2        e     d  [                 I_
E5     2        e     d  ]                 _
C#5    8        h     d                    see
measure 88
B4     8        h     d                    God.
rest   4        q
measure 89
rest  12
measure 90
rest  12
measure 91
rest  12
measure 92
rest   4        q
rest   4        q
F#4    4        q     u                    I
measure 93
B4     8        h     d                    know
D#5    3        e.    d  [                 that_
C#5    1        s     d  ]\                _
measure 94
B4     8        h     d                    my
G#5    4        q     d                    Re-
measure 95
E5     6        q.    d         (          deem-
D#5    2        e     d         )          -
E5     4        q     d                    er
measure 96
D#5    4        q     d                    liv-
D#5    4        q     d                    eth,
rest   4        q
measure 97
rest   4        q
B4     4        q     d                    and
E5     4        q     d                    though
measure 98
F#4    8        h     u                    worms
A4     4        q     u                    de-
measure 99
G#4    8        h     u                    stroy
B4     4        q     d                    this
measure 100
A4     4        q     u                    bo-
A4     4        q     u                    dy,
E5     4        q     d                    yet
measure 101
B4     8        h     d                    in
D5     4        q     d                    my
measure 102
C#5    6        q.    d         (          \0>esh_
B4     2        e     d         )          _
A4     4        q     u                    shall
measure 103
B4     4        q     d                    I
G#4    8        h     u                    see
measure 104
A4     8        h     u                    God,
rest   4        q
measure 105
rest   4        q
rest   2        e
C#5    2        e     d                    yet
B4     2        e     d                    in
A4     2        e     u                    my
measure 106
E5    12-       h.    d        -           \0>esh_
measure 107
E5     8        h     d                    _
E5     4        q     d                    shall
measure 108
F#5    4        q     d                    I
F#4    8        h     u                    see
measure 109
G#4    8        h     u                    God,
A4     4        q     u                    shall
measure 110
D5     4        q     d                    I
B4     8        h     d                    see
measure 111
A4     8        h     u                    God.
E4     4        q     u                    I
measure 112
A4     8        h     u                    know
C#5    3        e.    d  [                 that_
B4     1        s     d  ]\                _
measure 113
A4     8        h     u                    my
F#5    4        q     d                    Re-
measure 114
D5     6        q.    d         (          deem-
C#5    2        e     d         )          -
D5     4        q     d                    er
measure 115
C#5    4        q     d                    liv-
C#5    4        q     d                    eth.
rest   4        q
measure 116
rest  12
measure 117
rest  12
measure 118
rest  12
measure 119
rest   4        q
rest   4        q
A4     4        q     u                    For
measure 120
C#5    4        q     d                    now
B4     4        q     d                    is
A4     4        q     u                    Christ
measure 121
E5     4        q     d                    ri-
E5     4        q     d                    sen
rest   4        q
measure 122
A4     4        q     u                    from
G#4    8        h     u                    the
measure 123
F#4   12        h.    u                    dead,
measure 124
rest  12
measure 125
rest   4        q
rest   4        q
B4     4        q     d                    the
measure 126
B4    12        h.    u         (          first_
measure 127
A4     8        h     u         )          _
A4     4        q     u                    fruits
measure 128
G#4    4        q     u                    of
G#4    4        q     u                    them
A#4    4        q     u                    that
measure 129
B4    12-       h.    d        -           sleep,_
measure 130
B4    12-       h.    d        -           _
measure 131
B4     8        h     d                    _
E4     4        q     u                    of
measure 132
A4     8        h     u                    them
A4     4        q     u                    that
measure 133
G#4    8        h     u                    sleep,
B4     4        q     d                    the
measure 134
A#4    6        q.    u                    first_
B4     2        e     u  [                 _
A#4    2        e     u  =                 _
B4     2        e     u  ]                 _
measure 135
E4     8        h     u                    _
A4     4        q     u         +          fruits
measure 136
G#4    2        e     u  [                 of_
A4     2        e     u  ]                 _
F#4    6        q.    u                    them
E4     2        e     u                    that
measure 137
E4     8        h     u                    sleep;
rest   4        q
measure 138
rest  12
measure 139
rest  12
measure 140
rest  12
measure 141
rest   4        q
rest   4        q
F#4    4        q     u                    for
measure 142
G#4    4        q     u                    now
G#4    4        q     u                    is
A4     4        q     u                    Christ
measure 143
B4     4        q     d                    ri-
B4     4        q     d                    sen,
C#5    4        q     d                    for
measure 144
D#5    4        q     d                    now
D#5    4        q     d                    is
E5     4        q     d                    Christ
measure 145
F#5    4        q     d                    ri-
G#5    8        h     d                    sen
measure 146
C#5    4        q     d         (          from_
D#5    4        q     d         )          _
E5     4        q     d                    the
measure 147
G#4    4        q     u         (          dead,_
F#4    8        h     u         )          _
measure 148
rest  12
measure 149
rest   4        q
rest   4        q
A4     4        q     u                    the
measure 150
G#4    4        q     u         (          first_
F#4    4        q     u                    _
E4     4        q     u         )          _
measure 151
*               D +     Adagio
D#5    8        h     d         (          fruits_
E5     4        q     d         )          _
measure 152
G#4    4        q     u                    of
F#4    6        q.    u                    them
E4     2        e     u                    that
measure 153
E4     8        h     u                    sleep.
rest   4        q
measure 154
rest  12
measure 155
rest  12
measure 156
rest  12
measure 157
rest  12
measure 158
rest  12
measure 159
rest  12
measure 160
rest  12
measure 161
rest  12
measure 162
rest  12
measure 163
rest  12
measure 164
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-01/3} [KHM:3127120370]
TIMESTAMP: DEC/26/2001 [md5sum:7af01f0190f7b18114dc12c1642550e1]
06/24/90 E. Correia
WK#:56        MV#:3,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
1 19
Group memberships: score
score: part 3 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:3/4   C:22   D:Larghetto
E3     8        h     d
rest   4        q
measure 2
rest   4        q
rest   4        q
f1              6
B3     4        q     d
measure 3
C#4    8        h     d
A3     4        q     d
measure 4
f1              7
F#3    8        h     d
B2     4        q     u
measure 5
E3     8        h     d
rest   4        q
measure 6
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =      (
E3     2        e     d  ]      )
measure 7
B2     8        h     u
rest   4        q
measure 8
rest   4        q
rest   2        e
C#3    2        e     u  [
B2     2        e     u  =
A2     2        e     u  ]
measure 9
G#2    4        q     u
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 10
D#3    8        h     d
E3     4        q     d
measure 11
F#3    8        h     d
B2     4        q     u
measure 12
E3     4        q     d
A2     8        h     u
measure 13
B2     4        q     u
D#3    4        q     d
E3     4        q     d
measure 14
A3     4        q     d
B3     4        q     d
B2     4        q     u
measure 15
C#3    4        q     u
B2     4        q     u
A2     4        q     u
measure 16
G#2   12        h.    u
measure 17
rest   2        e
A3     2        e     d
B3     4        q     d
B2     4        q     u
measure 18
E2     8        h     u
rest   4        q
measure 19
rest   4        q
rest   4        q
B3     4        q     d         p
measure 20
C#4    8        h     d
A3     4        q     d
measure 21
F#3    8        h     d
B2     4        q     u
measure 22
E3     8        h     d
rest   4        q
measure 23
rest   4        q
rest   4        q
B2     4        q     u
measure 24
C#3    8        h     u
A2     4        q     u
measure 25
F#2    8        h     u
D#3    4        q     d
measure 26
E3     8        h     d
E3     4        q     d
measure 27
C#3    8        h     u
D#3    4        q     d
measure 28
E3     8        h     d
rest   4        q
measure 29
D#3    4        q     d
E3     4        q     d
G#3    4        q     d
measure 30
rest   4        q
rest   2        e
E3     2        e     d  [
D#3    2        e     d  =
C#3    2        e     d  ]
measure 31
F#3    8        h     d
rest   4        q
measure 32
rest   4        q
rest   2        e
G#3    2        e     d  [
C#4    2        e     d  =
B3     2        e     d  ]
measure 33
A#3    8        h     d
B3     4        q     d
measure 34
E3     4        q     d
F#3    4        q     d
F#2    4        q     u
measure 35
B2     8        h     u
rest   4        q
measure 36
rest   4        q
rest   4        q
F#3    4        q     d
measure 37
G#3    8        h     d
E3     4        q     d
measure 38
C#3    8        h     u
A#3    4        q     d
measure 39
B3     8        h     d
f2              4 2
A3     4        q     d         +
measure 40
G#3    8        h     d
B3     4        q     d
measure 41
C#4    8        h     d
A3     4        q     d
measure 42
F#3    8        h     d
E3     4        q     d
measure 43
B2     8        h     u
rest   4        q
measure 44
rest  12
measure 45
rest  12
measure 46
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 47
B2     8        h     u
rest   4        q
measure 48
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
measure 49
G#3    4        q     d
rest   4        q
rest   4        q
measure 50
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 51
D#3    8        h     d
E3     4        q     d
measure 52
A2     4        q     u
B2     4        q     u
B2     4        q     u
measure 53
E3     8        h     d
rest   4        q
measure 54
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 55
B2     8        h     u
rest   4        q
measure 56
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
measure 57
G#3    8        h     d
rest   4        q
measure 58
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 59
D#3    8        h     d
rest   4        q
measure 60
rest   4        q
rest   2        e
E3     2        e     d  [
D#3    2        e     d  =
C#3    2        e     d  ]
measure 61
B2     6        q.    u
D#3    2        e     d
E3     4        q     d
measure 62
A3     4        q     d
B3     4        q     d
B2     4        q     u
measure 63
C#3    4        q     u
B2     4        q     u
A2     4        q     u
measure 64
G#2    4        q     u
rest   4        q
rest   4        q
measure 65
rest   2        e
A2     2        e     u
B2     4        q     u
B2     4        q     u
measure 66
E2     8        h     u
rest   4        q
measure 67
rest   4        q
rest   2        e
G#3    2        e     d  [      &f
F#3    2        e     d  =
E3     2        e     d  ]
measure 68
B2     8        h     u
rest   4        q
measure 69
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
measure 70
G#3    6        q.    d
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 71
D#3    4        q     d
rest   4        q
E3     4        q     d
measure 72
F#3    4        q     d
D#3    4        q     d
B2     4        q     u
measure 73
E3     4        q     d
B2     4        q     u
C#3    4        q     u
measure 74
A2     4        q     u
B2     4        q     u
B2     4        q     u
measure 75
E2     8        h     u
rest   4        q
measure 76
rest   4        q
E3     4        q     d         &p
G#3    4        q     d
measure 77
A3     4        q     d
F#3    8        h     d
measure 78
E3     8        h     d
B2     4        q     u
measure 79
G#2    8        h     u
E3     4        q     d
measure 80
F#2    8        h     u
D#3    4        q     d
measure 81
E3     8        h     d
F#3    4        q     d
measure 82
G#3    8        h     d
A3     4        q     d
measure 83
F#3    4        q     d
E3     8        h     d
measure 84
B2     8        h     u
D#3    4        q     d
measure 85
E3     8        h     d
F#3    4        q     d
measure 86
G#3   12        h.    d
measure 87
F#3    8        h     d
F#2    4        q     u
measure 88
B2     8        h     u
rest   4        q
measure 89
rest   4        q
rest   4        q
F#3    4        q     d         f
measure 90
G#3    8        h     d
E3     4        q     d
measure 91
C#3    8        h     u
A#3    4        q     d
measure 92
B3     8        h     d
rest   4        q
measure 93
rest   4        q
rest   4        q
F#3    4        q     d         p
measure 94
G#3    8        h     d
E3     4        q     d
measure 95
f1              7
C#3    8        h     u
f2              7 #
F#3    4        q     d
measure 96
B2     6        q.    u
C#3    2        e     u  [
B2     2        e     u  =
A2     2        e     u  ]
measure 97
G#2    4        q     u
rest   4        q
rest   4        q
measure 98
A2     4        q     u
rest   4        q
rest   4        q
measure 99
B2     4        q     u
rest   4        q
rest   4        q
measure 100
C#3    4        q     u
rest   4        q
rest   4        q
measure 101
G#3    4        q     d
rest   4        q
rest   4        q
measure 102
A3     4        q     d
E3     4        q     d
F#3    4        q     d
measure 103
D3     4        q     d
E3     4        q     d
E2     4        q     u
measure 104
A2     8        h     u
rest   4        q
measure 105
rest  12
measure 106
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
measure 107
E3    12-       h.    d        -
measure 108
E3     4        q     d
D3     8-       h     d        -
measure 109
D3     8        h     d
C#3    4        q     u
measure 110
F#3    4        q     d
D3     4        q     d
E3     4        q     d
measure 111
A2     8        h     u
rest   4        q
measure 112
rest   4        q
rest   4        q
E3     4        q     d
measure 113
F#3    8        h     d
D3     4        q     d
measure 114
B2     8        h     u
E3     4        q     d
measure 115
A2     8        h     u
rest   4        q
measure 116
rest   4        q
rest   4        q
*               G +     f
f1              6
E3     4        q     d
measure 117
F#3    8        h     d
D3     4        q     d
measure 118
B2     8        h     u
E3     4        q     d
measure 119
A2    12        h.    u
measure 120
A3    12        h.    d
measure 121
G#3   12        h.    d
measure 122
F#3    4        q     d
E3     8        h     d
measure 123
B2    12-       h.    u        -
measure 124
B2    12-       h.    u        -
measure 125
B2    12-       h.    u        -
measure 126
B2    12-       h.    u        -
measure 127
B2    12-       h.    u        -
measure 128
B2    12-       h.    u        -
measure 129
B2     3        e.    u  [
C#3    1        s     u  =\
B2     3        e.    u  =
C#3    1        s     u  =\
B2     3        e.    u  =
C#3    1        s     u  ]\
measure 130
A2     3        e.    u  [
B2     1        s     u  =\
A2     3        e.    u  =
B2     1        s     u  =\
A2     3        e.    u  =
B2     1        s     u  ]\
measure 131
G#2    3        e.    u  [
A2     1        s     u  =\
G#2    3        e.    u  =
A2     1        s     u  =\
G#2    3        e.    u  =
A2     1        s     u  ]\
measure 132
F#2    3        e.    u  [
G#2    1        s     u  =\
F#2    3        e.    u  =
G#2    1        s     u  =\
F#2    3        e.    u  =
G#2    1        s     u  ]\
measure 133
E2     4        q     u
E3     4        q     d
D#3    4        q     d
measure 134
C#3   12-       h.    u        -
measure 135
C#3   12        h.    u
measure 136
B2     8        h     u
B2     4        q     u
measure 137
E3     4        q     d
E4     4        q     d
D#4    4        q     d
measure 138
f1              6+
C#4   12        h.    d
measure 139
f1              6n
C#3    8        h     u
C#4    4        q     d
measure 140
B3     8        h     d
B2     4        q     u
measure 141
E3     8        h     d
B2     4        q     u
measure 142
E3     8        h     d
F#3    4        q     d
measure 143
G#3    8        h     d
A3     4        q     d
measure 144
F#3    8        h     d
G#3    4        q     d
measure 145
D#3    4        q     d
E3     8        h     d
measure 146
A3     8        h     d
E3     4        q     d
measure 147
B3     8        h     d
B2     4        q     u
measure 148
C#3   12        h.    u
measure 149
D#3   12        h.    d
measure 150
E3     4        q     d
A3     8        h     d
measure 151
A3     8        h     d
G#3    4        q     d
measure 152
B3     8        h     d
B2     4        q     u
measure 153
E3    12        h.    d
measure 154
rest   4        q
rest   4        q
B3     4        q     d         f
measure 155
C#4    8        h     d
A3     4        q     d
measure 156
F#3    8        h     d
B2     4        q     u
measure 157
E3     8        h     d
rest   4        q
measure 158
rest   4        q
rest   2        e
G#3    2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 159
D#3    6        q.    d
rest   1        s
B2     1        s     u
E3     4        q     d
measure 160
A3     4        q     d
B3     4        q     d
B2     4        q     u
measure 161
C#3    4        q     u
B2     4        q     u
A2     4        q     u
measure 162
G#2    8        h     u
rest   4        q
measure 163
G#3    2        e     d  [
A3     2        e     d  ]
B3     4        q     d
B2     4        q     u
measure 164
E2    12        h.    u         F
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
