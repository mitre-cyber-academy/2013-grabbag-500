&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/1} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:28656c11f164455f7c31d0c4158152d5]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
0 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4   D:Allegro
C5     4        q     d
rest   4        q
rest   8        h
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
C5     4        q     d
measure 15
G4     4        q     u
A4     2        e     u  [
A4     2        e     u  ]
Bf4    2        e     u  [
G4     2        e     u  ]
C5     4-       q     d        -
measure 16
C5     2        e     u  [
Bf4    1        s     u  =[
A4     1        s     u  ]]
Bf4    2        e     d  [
C5     2        e     d  ]
D5     2        e     d  [
Bf4    2        e     d  ]
Ef5    4-       q     d        -
measure 17
Ef5    2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
G5     2        e     d  [
C5     2        e     d  ]
C5     4        q     d
measure 18
rest   2        e
Ef5    2        e     d  [
D5     2        e     d  =
C5     2        e     d  ]
Bf4    4        q     u
A4     4        q     u
measure 19
G4     4        q     u
rest   4        q
rest   8        h
measure 20
rest   2        e
C5     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  ]
D5     3        e.    d  [      &t
C5     1        s     d  ]\
Bf4    4        q     u
measure 21
rest   2        e
Bf4    2        e     u
C5     4-       q     d        -
C5     2        e     d  [
C5     2        e     d  ]
Bf4    4-       q     u        -
measure 22
Bf4    4        q     u
A4     4        q     u
Bf4    4        q     u
rest   4        q
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   2        e
F4     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  ]
D5     3        e.    d  [      &t
C5     1        s     d  ]\
Bf4    4        q     u
measure 28
rest   8        h
rest   4        q
Bf4    4        q     u
measure 29
Ef4    4        q     u
F4     2        e     u  [
F4     2        e     u  ]
G4     2        e     u  [
Ef4    2        e     u  ]
Af4    4-       q     u        -
measure 30
Af4    2        e     u  [
G4     1        s     u  =[
F4     1        s     u  ]]
G4     2        e     u  [
Af4    2        e     u  ]
Bf4    2        e     u  [
G4     2        e     u  ]
C5     4        q     d
measure 31
rest   2        e
Bf4    2        e     u  [
Bf4    2        e     u  =
Bf4    2        e     u  ]
Ef5    2        e     d  [
Af4    2        e     d  ]
Af4    4        q     u
measure 32
rest   2        e
C5     2        e     d  [
Bf4    2        e     d  =
Af4    2        e     d  ]
G4     4        q     u
F4     4        q     u
measure 33
Ef4    4        q     u
rest   4        q
rest   8        h
measure 34
rest   2        e
C5     2        e     d  [
F5     2        e     d  =
F5     2        e     d  ]
E5     3        e.    d  [      &t
D5     1        s     d  ]\
C5     4        q     d
measure 35
rest   8        h
rest   2        e
G4     2        e     u  [
C5     2        e     u  =
Bf4    2        e     u  ]
measure 36
Af4    2        e     u  [
G4     2        e     u  =
F4     2        e     u  =
E4     2        e     u  ]
F4     4        q     u
Df5    4        q     d
measure 37
C5     8        h     d
rest   2        e
G4     2        e     u  [
C5     2        e     u  =
Bf4    2        e     u  ]
measure 38
A4     3        e.    u  [      &t
G4     1        s     u  ]\
F4     4        q     u
rest   8        h
measure 39
rest   2        e
C5     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  ]
D5     3        e.    d  [      &t
C5     1        s     d  ]\
Bf4    4        q     u
measure 40
rest   2        e
C5     2        e     d  [
A4     2        e     d  =
Bf4    2        e     d  ]
C5     2        e     d  [
D5     2        e     d  =
Ef5    2        e     d  =
D5     2        e     d  ]
measure 41
D5     4        q     d
C5     4        q     d
D5     3        e.    d  [
D5     1        s     d  ]\
D5     4        q     d
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest   8        h
rest   2        e
D4     2        e     u  [
D5     2        e     u  =
C5     2        e     u  ]
measure 46
B4     3        e.    u  [      &t
A4     1        s     u  ]\
G4     4        q     u
rest   8        h
measure 47
rest   2        e
D5     2        e     d  [
G5     2        e     d  =
F5     2        e     d  ]
Ef5    3        e.    d  [      &t
D5     1        s     d  ]\
C5     4        q     d
measure 48
rest   2        e
C5     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  ]
D5     3        e.    d  [      &t
C5     1        s     d  ]\
Bf4    4        q     u
measure 49
rest  16
measure 50
rest   4        q
G5     4        q     d
C5     4        q     d
D5     2        e     d  [
D5     2        e     d  ]
measure 51
Ef5    2        e     d  [
C5     2        e     d  ]
F5     4-       q     d        -
F5     2        e     d  [
Ef5    1        s     d  =[
D5     1        s     d  ]]
Ef5    2        e     d  [
F5     2        e     d  ]
measure 52
G5     2        e     d  [
Ef5    2        e     d  ]
Af5    4-       q     d        -
Af5    2        e     d  [
G5     1        s     d  =[
F5     1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
measure 53
C6     2        e     d  [
F5     2        e     d  ]
F5     4        q     d
rest   2        e
Af5    2        e     d  [
G5     2        e     d  =
F5     2        e     d  ]
measure 54
Ef5    4        q     d
D5     4        q     d
C5     4        q     d
rest   4        q
measure 55
rest  16
measure 56
rest   2        e
Bf4    2        e     d  [
Ef5    2        e     d  =
D5     2        e     d  ]
C5     2        e     d  [
D5     1        s     d  =[
Ef5    1        s     d  ]]
D5     2        e     d  [
C5     2        e     d  ]
measure 57
B4     4        q     u
rest   4        q
rest   2        e
C5     2        e     d  [
Bf4    2        e     d  =
Af4    2        e     d  ]
measure 58
G4     2        e     d  [
Ef5    2        e     d  =
D5     2        e     d  =
C5     2        e     d  ]
B4     2        e     u  [
G4     2        e     u  ]
G5     4-       q     d        -
measure 59
G5     4        q     d
F5     2        e     d  [
Ef5    2        e     d  ]
D5     2        e     d  [
Bf4    2        e     d  ]
Ef5    4-       q     d        -
measure 60
Ef5    4        q     d
D5     2        e     d  [
C5     2        e     d  ]
B4     3        e.    u  [
B4     1        s     u  ]\
B4     4        q     u
measure 61
rest   4        q
$ D:Adagio
B4     4        q     u
C5     4        q     d
C5     4        q     d
measure 62
C5     8        h     d
B4     8        h     u
measure 63
C5    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/2} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:5f69883e6423b09c01c1571ed3a1be7f]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
0 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4   D:Allegro
Ef4    4        q     u
rest   4        q
rest   8        h
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   4        q
G4     4        q     u
C4     4        q     u
D4     2        e     u  [
D4     2        e     u  ]
measure 11
Ef4    2        e     u  [
C4     2        e     u  ]
F4     4-       q     u        -
F4     2        e     u  [
Ef4    1        s     u  =[
D4     1        s     u  ]]
Ef4    2        e     u  [
F4     2        e     u  ]
measure 12
G4     2        e     u  [
Ef4    2        e     u  ]
Af4    4        q     u
rest   2        e
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  ]
measure 13
C5     2        e     u  [
F4     2        e     u  ]
F4     4        q     u
rest   2        e
Af4    2        e     u  [
G4     2        e     u  =
F4     2        e     u  ]
measure 14
Ef4    4        q     u
D4     4        q     u
C4     4        q     u
rest   4        q
measure 15
rest   2        e
G4     2        e     u  [
F4     2        e     u  =
Ef4    2        e     u  ]
D4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
measure 16
D4     2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
G4     6        q.    u
A4     1        s     u  [[
Bf4    1        s     u  ]]
measure 17
A4     6        q.    u
Bf4    1        s     u  [[
A4     1        s     u  ]]
G4     6        q.    u
A4     1        s     u  [[
G4     1        s     u  ]]
measure 18
F#4    4        q     u
G4     8        h     u
F#4    4        q     u
measure 19
G4     4        q     u
rest   4        q
rest   8        h
measure 20
rest   8        h
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
Af4    2        e     u  ]
measure 21
G4     3        e.    u  [
F4     1        s     u  =\
Ef4    2        e     u  =
G4     2        e     u  ]
F4     6        q.    u
G4     2        e     u
measure 22
Ef4    6        q.    u
Ef4    2        e     u
D4     4        q     u
rest   4        q
measure 23
rest   4        q
F4     4        q     u
Bf3    4        q     u
C4     2        e     u  [
C4     2        e     u  ]
measure 24
D4     2        e     u  [
Bf3    2        e     u  ]
Ef4    4-       q     u        -
Ef4    2        e     u  [
D4     1        s     u  =[
C4     1        s     u  ]]
D4     2        e     u  [
Ef4    2        e     u  ]
measure 25
F4     2        e     u  [
D4     2        e     u  ]
G4     4        q     u
rest   2        e
F4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  ]
measure 26
Bf4    2        e     u  [
Ef4    2        e     u  ]
Ef4    4        q     u
rest   2        e
G4     2        e     u  [
F4     2        e     u  =
Ef4    2        e     u  ]
measure 27
D4     4        q     u
C4     4        q     u
Bf3    2        e     u  [
D4     2        e     u  =
Ef4    2        e     u  =
F4     2        e     u  ]
measure 28
G4     2        e     u  [
Ef4    2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
Bf3    2        e     u
Ef4    4        q     u
D4     2        e     u
measure 29
C4     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
Ef4    4        q     u
rest   4        q
measure 30
rest   2        e
D4     2        e     u  [
Ef4    2        e     u  =
F4     2        e     u  ]
G4     2        e     u  [
Ef4    2        e     u  =
Af4    2        e     u  =
F4     2        e     u  ]
measure 31
D4     6        q.    u
D4     2        e     u
C4     6        q.    u
C4     2        e     u
measure 32
D4     2        e     u  [
D4     2        e     u  =
Ef4    2        e     u  =
Ef4    2        e     u  ]
Ef4    4        q     u
D4     4        q     u
measure 33
Ef4    4        q     u
rest   4        q
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
Bf4    2        e     u  ]
measure 34
Af4    3        e.    u  [
G4     1        s     u  ]\
F4     4        q     u
rest   8        h
measure 35
rest   2        e
C4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  ]
E4     3        e.    u  [
D4     1        s     u  ]\
C4     4        q     u
measure 36
rest   8        h
rest   2        e
Af4    2        e     u  [
G4     2        e     u  =
F4     2        e     u  ]
measure 37
E4     2        e     u  [
C4     2        e     u  ]
F4     8        h     u
E4     2        e     u  [
D4     2        e     u  ]
measure 38
C4     4        q     u
rest   4        q
rest   8        h
measure 39
rest   8        h
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
Bf4    2        e     u  ]
measure 40
A4     3        e.    u  [
G4     1        s     u  ]\
F4     4        q     u
rest   2        e
Bf4    2        e     u  [
G4     2        e     u  =
F#4    2        e     u  ]
measure 41
G4     6        q.    u
G4     2        e     u
F#4    6        q.    u
F#4    2        e     u
measure 42
G4     4        q     u
F4     2        e     u  [      +
Ef4    2        e     u  ]
D4     2        e     u  [
Bf4    2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 43
F#4    2        e     u  [
D4     2        e     u  =
G4     2        e     u  =
A4     2        e     u  ]
Bf4    6        q.    u
Bf4    2        e     u
measure 44
A4     2        e     u  [
F4     2        e     u  =
Bf4    2        e     u  =
A4     2        e     u  ]
G4     2        e     u  [
A4     1        s     u  =[
Bf4    1        s     u  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 45
F#4    2        e     u  [
D4     2        e     u  ]
G4     8        h     u
F#4    4        q     u
measure 46
G4     2        e     u  [
D4     2        e     u  =
G4     2        e     u  =
F4     2        e     u  ]      +
Ef4    3        e.    u  [
D4     1        s     u  ]\
C4     4        q     u
measure 47
rest  16
measure 48
rest   8        h
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
Af4    2        e     u  ]
measure 49
G4    12        h.    u
F4     4        q     u
measure 50
G4     4        q     u
G4     4        q     u
Ef4    4        q     u
G4     2        e     u  [
G4     2        e     u  ]
measure 51
G4     2        e     u  [
G4     2        e     u  =
Af4    2        e     u  =
Af4    2        e     u  ]
G4     6        q.    u
F4     2        e     u
measure 52
Ef4    2        e     u  [
Ef4    2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
F4     2        e     u  [
D4     2        e     u  ]
Bf4    4        q     u
measure 53
Af4    6        q.    u
Af4    2        e     u
G4     2        e     u  [
D4     2        e     u  =
G4     2        e     u  =
Af4    2        e     u  ]
measure 54
G4     3        e.    u  [
G4     1        s     u  ]\
G4     4        q     u
rest   2        e
G4     2        e     u  [
C5     2        e     u  =
Bf4    2        e     u  ]
measure 55
Af4    3        e.    u  [
G4     1        s     u  ]\
F4     4        q     u
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
Af4    2        e     u  ]
measure 56
G4     6        q.    u
F4     2        e     u
Ef4    2        e     u  [
F4     1        s     u  =[
G4     1        s     u  ]]
F4     4-       q     u        -
measure 57
F4     2        e     u  [
G4     1        s     u  =[
F4     1        s     u  ]]
Ef4    2        e     u  [
D4     2        e     u  ]
Ef4    4        q     u
D4     2        e     u  [
C4     2        e     u  ]
measure 58
Bf3    2        e     u  [
Ef4    2        e     u  ]
Af4    4        q     u
G4     6        q.    u
F4     2        e     u
measure 59
Ef4    4        q     u
F4     4        q     u
Bf4    6        q.    u
Bf4    2        e     u
measure 60
Af4    6        q.    u
Af4    2        e     u
G4     3        e.    u  [
G4     1        s     u  ]\
G4     4        q     u
measure 61
rest   4        q
$ D:Adagio
G4     4        q     u
G4     4        q     u
G4     4        q     u
measure 62
G4    12        h.    u
G4     4        q     u
measure 63
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/3} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:559b80afe20393267a926fc840513e3c]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
0 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:13   D:Allegro
G4     4        q     d
rest   4        q
rest   8        h
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
C4     4        q     u
measure 6
G3     4        q     u
A3     2        e     u  [
A3     2        e     u  ]
Bf3    2        e     u  [
G3     2        e     u  ]
C4     4-       q     u        -
measure 7
C4     2        e     u  [
Bf3    1        s     u  =[
A3     1        s     u  ]]
Bf3    2        e     u  [
C4     2        e     u  ]
D4     2        e     d  [
Bf3    2        e     d  ]
Ef4    4-       q     d        -
measure 8
Ef4    2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
G4     2        e     d  [
C4     2        e     d  ]
C4     4        q     u
measure 9
rest   2        e
Ef4    2        e     d  [
D4     2        e     d  =
C4     2        e     d  ]
Bf3    4        q     u
A3     4        q     u
measure 10
G3     4        q     u
rest   4        q
rest   2        e
G3     2        e     u  [
A3     2        e     u  =
B3     2        e     u  ]
measure 11
C4     4        q     u
rest   2        e
D4     2        e     d
G3     2        e     u  [
B3     2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
measure 12
Ef4    2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
Bf3    4        q     u         +
rest   2        e
Ef4    2        e     d
measure 13
Af3    6        q.    u
Af3    2        e     u
G3     2        e     u  [
B3     2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
measure 14
G3     4        q     u
B3     4        q     u
C4     2        e     d  [
D4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  ]
measure 15
C4     6        q.    u
D4     1        s     d  [[
C4     1        s     d  ]]
Bf3    2        e     u  [      +
D4     2        e     u  =
C4     2        e     u  =
Bf3    2        e     u  ]
measure 16
A3     2        e     u
D4     4        q     d
C4     2        e     u
Bf3    2        e     u  [
D4     2        e     u  ]
C4     4-       q     u        -
measure 17
C4     2        e     d  [
F4     2        e     d  ]
D4     4-       q     d        -
D4     2        e     d  [
Ef4    1        s     d  =[
D4     1        s     d  ]]
C4     2        e     d  [
Ef4    2        e     d  ]
measure 18
A3     4        q     u
Bf3    2        e     u  [
C4     2        e     u  ]
D4     8        h     d
measure 19
rest   2        e
D4     2        e     d  [
G4     2        e     d  =
F4     2        e     d  ]
E4     3        e.    d  [
D4     1        s     d  ]\
C4     4        q     u
measure 20
rest   8        h
rest   4        q
rest   2        e
Bf3    2        e     u
measure 21
Ef4    6        q.    d
Ef4    2        e     d
D4     6        q.    d
Ef4    1        s     d  [[
D4     1        s     d  ]]
measure 22
C4     6        q.    u
C4     2        e     u
Bf3    2        e     u  [
Bf3    2        e     u  =
A3     2        e     u  =
G3     2        e     u  ]
measure 23
F3     2        e     u
Bf3    4        q     u
A3     2        e     u
G3     2        e     u  [
F3     2        e     u  =
G3     2        e     u  =
A3     2        e     u  ]
measure 24
Bf3    4        q     u
rest   4        q
rest   2        e
A3     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  ]
measure 25
D4     2        e     d  [
Bf3    2        e     d  =
Ef4    2        e     d  =
C4     2        e     d  ]
A3     6        q.    u
A3     2        e     u
measure 26
G3     6        q.    u
G3     2        e     u
A3     2        e     u  [
A3     2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 27
Bf3    4        q     u
A3     4        q     u
Bf3    4        q     u
Bf3    4        q     u
measure 28
Ef3    4        q     u
F3     2        e     u  [
F3     2        e     u  ]
G3     6        q.    u
G3     2        e     u
measure 29
Af3    2        e     u  [
G3     2        e     u  =
Af3    2        e     u  =
F3     2        e     u  ]
Ef3    2        e     d  [
Ef4    2        e     d  =
F4     2        e     d  =
Ef4    2        e     d  ]
measure 30
D4     2        e     d  [
Bf3    2        e     d  ]
Ef4    4        q     d
rest   4        q
rest   2        e
Af3    2        e     u
measure 31
F3     4        q     u
G3     4        q     u
Ef3    4        q     u
F3     4        q     u
measure 32
Bf3    2        e     u  [
Af3    2        e     u  =
G3     2        e     u  =
Af3    2        e     u  ]
Bf3    6        q.    u
Bf3    2        e     u
measure 33
Bf3    2        e     d  [
Bf3    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
D4     3        e.    d  [
C4     1        s     d  ]\
Bf3    4        q     u
measure 34
rest  16
measure 35
rest   8        h
rest   4        q
rest   2        e
C4     2        e     u
measure 36
F3     4        q     u
G3     2        e     u  [
G3     2        e     u  ]
Af3    2        e     u  [
F3     2        e     u  ]
Bf3    4-       q     u        -
measure 37
Bf3    2        e     u  [
Af3    1        s     u  =[
G3     1        s     u  ]]
Af3    2        e     u  [
Bf3    2        e     u  ]
C4     6        q.    u
C4     2        e     u
measure 38
F3     4        q     u
rest   4        q
rest   2        e
F3     2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 39
A3     3        e.    u  [
G3     1        s     u  ]\
F3     4        q     u
rest   8        h
measure 40
rest   2        e
F3     2        e     u  [
F3     2        e     u  =
G3     2        e     u  ]
A3     2        e     u  [
Bf3    2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
measure 41
Ef4    6        q.    d
Ef4    2        e     d
D4     3        e.    u  [
D4     1        s     u  =\
A3     2        e     u  =
A3     2        e     u  ]
measure 42
Bf3    4        q     u
C4     2        e     u  [
C4     2        e     u  ]
D4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 43
A3     2        e     u  [
A3     2        e     u  =
D4     2        e     u  =
C4     2        e     u  ]
Bf3    2        e     d  [
Bf3    2        e     d  =
G4     2        e     d  =
Ef4    2        e     d  ]
measure 44
C4     2        e     d  [
D4     1        s     d  =[
Ef4    1        s     d  ]]
F4     2        e     d  [
D4     2        e     d  ]
Bf3    2        e     d  [
C4     1        s     d  =[
D4     1        s     d  ]]
Ef4    2        e     d  [
C4     2        e     d  ]
measure 45
A3     2        e     u  [
Bf3    1        s     u  =[
C4     1        s     u  ]]
D4     2        e     d  [
C4     2        e     d  ]
Bf3    4        q     u
A3     4        q     u
measure 46
G3     4        q     u
rest   4        q
rest   2        e
G3     2        e     u  [
C4     2        e     u  =
C4     2        e     u  ]
measure 47
B3     3        e.    u  [
A3     1        s     u  ]\
G3     4        q     u
rest   8        h
measure 48
rest  16
measure 49
rest   2        e
Bf3    2        e     d  [      +
Ef4    2        e     d  =
D4     2        e     d  ]
C4     2        e     d  [
D4     1        s     d  =[
Ef4    1        s     d  ]]
D4     2        e     d  [
C4     2        e     d  ]
measure 50
B3     2        e     u  [
D4     2        e     u  =
C4     2        e     u  =
B3     2        e     u  ]
G4     6        q.    d
F4     2        e     d
measure 51
Ef4    4        q     d
D4     8        h     d
C4     2        e     u  [
B3     2        e     u  ]
measure 52
C4     6        q.    u
D4     1        s     d  [[
C4     1        s     d  ]]
Bf3    4        q     u         +
G4     2        e     d  [
F4     2        e     d  ]
measure 53
Ef4    2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
Ef4    2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
Ef4    2        e     d  =
C4     2        e     d  ]
measure 54
C4     4        q     u
B3     4        q     u
C4     4        q     u
rest   4        q
measure 55
rest   2        e
C4     2        e     d  [
F4     2        e     d  =
Ef4    2        e     d  ]
D4     3        e.    d  [
C4     1        s     d  ]\
Bf3    4        q     u         +
measure 56
rest   2        e
Ef3    2        e     u  [
F3     2        e     u  =
G3     2        e     u  ]
Af3    6        q.    u
Af3    2        e     u
measure 57
G3     2        e     u  [
D4     2        e     u  =
C4     2        e     u  =
B3     2        e     u  ]
G4     4        q     d
F4     4        q     d
measure 58
Ef4    2        e     d  [
G4     2        e     d  =
F4     2        e     d  =
Ef4    2        e     d  ]
D4     4        q     d
C4     2        e     d  [
D4     2        e     d  ]
measure 59
Bf3    4        q     u
C4     4        q     u
F4     2        e     d  [
F4     2        e     d  =
G4     2        e     d  =
Ef4    2        e     d  ]
measure 60
F4     6        q.    d
Ef4    2        e     d
D4     3        e.    d  [
D4     1        s     d  ]\
D4     4        q     d
measure 61
rest   4        q
$ D:Adagio
D4     4        q     d
Ef4    4        q     d
Ef4    4        q     d
measure 62
D4    12        h.    d
D4     4        q     d
measure 63
Ef4   16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/4} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:b93f8f5e26508f9bcddd6a67e9b806f6]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
0 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
C5     4        q     d                    He
measure 15
G4     4        q     u                    trus-
A4     2        e     u                    ted
A4     2        e     u                    in
Bf4    2        e     u                    God
G4     2        e     u                    that
C5     4-       q     d        -           he_
measure 16
C5     2        e     d                    _
Bf4    1        s     d  [[                would_
A4     1        s     u  =]                _
Bf4    2        e     u  ]                 _
C5     2        e     d                    de-
D5     2        e     d                    li-
Bf4    2        e     u                    ver
Ef5    4        q     d                    him;
measure 17
rest   2        e
D5     2        e     d                    let
D5     2        e     d                    him
D5     2        e     d                    de-
G5     2        e     d                    li-
C5     2        e     d                    ver
C5     4        q     d                    him,
measure 18
rest   2        e
Ef5    2        e     d                    if
D5     2        e     d                    he
C5     2        e     d                    de-
Bf4    4        q     u                    light
A4     4        q     u                    in
measure 19
G4     4        q     u                    him,
rest   4        q
rest   8        h
measure 20
rest   2        e
C5     2        e     d                    let
F5     2        e     d                    him
Ef5    2        e     d                    de-
D5     3        e.    d                    li-
C5     1        s     d                    ver
Bf4    4        q     u                    him,
measure 21
rest   2        e
Bf4    2        e     u                    if
C5     4-       q     d        -           he_
C5     2        e     d                    _
C5     2        e     d                    de-
Bf4    4-       q     u        -           light_
measure 22
Bf4    4        q     u                    _
A4     4        q     u                    in
Bf4    4        q     u                    him,
rest   4        q
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   2        e
F4     2        e     u                    let
F5     2        e     d                    him
Ef5    2        e     d                    de-
D5     3        e.    d                    li-
C5     1        s     d                    ver
Bf4    4        q     u                    him.
measure 28
rest   8        h
rest   4        q
Bf4    4        q     u                    He
measure 29
Ef4    4        q     u                    trus-
F4     2        e     u                    ted
F4     2        e     u                    in
G4     2        e     u                    God
Ef4    2        e     u                    that
Af4    4-       q     u        -           he_
measure 30
Af4    2        e     u                    _
G4     1        s     u  [[                would_
F4     1        s     u  =]                _
G4     2        e     u  ]                 _
Af4    2        e     u                    de-
Bf4    2        e     u                    li-
G4     2        e     u                    ver
C5     4        q     d                    him,
measure 31
rest   2        e
Bf4    2        e     u                    let
Bf4    2        e     u                    him
Bf4    2        e     u                    de-
Ef5    2        e     d                    li-
Af4    2        e     u                    ver
Af4    4        q     u                    him,
measure 32
rest   2        e
C5     2        e     d                    if
Bf4    2        e     u                    he
Af4    2        e     u                    de-
G4     4        q     u                    light
F4     4        q     u                    in
measure 33
Ef4    4        q     u                    him,
rest   4        q
rest   8        h
measure 34
rest   2        e
C5     2        e     d                    let
F5     2        e     d                    him
F5     2        e     d                    de-
E5     3        e.    d                    li-
D5     1        s     d                    ver
C5     4        q     d                    him,
measure 35
rest   8        h
rest   2        e
G4     2        e     u                    if
C5     2        e     d                    he
Bf4    2        e     u                    de-
measure 36
Af4    2        e     u  [                 light_
G4     2        e     u  =                 _
F4     2        e     u  =                 _
E4     2        e     u  ]                 _
F4     4        q     u                    _
Df5    4        q     d                    in
measure 37
C5     8        h     d                    him,
rest   2        e
G4     2        e     u                    if
C5     2        e     d                    he
Bf4    2        e     u                    de-
measure 38
A4     3        e.    u                    light
G4     1        s     u                    in
F4     4        q     u                    him,
rest   8        h
measure 39
rest   2        e
C5     2        e     d                    let
F5     2        e     d                    him
Ef5    2        e     d                    de-
D5     3        e.    d                    li-
C5     1        s     d                    ver
Bf4    4        q     u                    him,
measure 40
rest   2        e
C5     2        e     d                    if
A4     2        e     u                    he
Bf4    2        e     u                    de-
C5     2        e     d                    light
D5     2        e     d                    in
Ef5    2        e     d                    him,
D5     2        e     d                    let
measure 41
D5     4        q     d                    him
C5     4        q     d                    de-
D5     3        e.    d                    li-
D5     1        s     d                    ver
D5     4        q     d                    him,
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest   8        h
rest   2        e
D4     2        e     u                    let
D5     2        e     d                    him
C5     2        e     d                    de-
measure 46
B4     3        e.    u                    li-
A4     1        s     u                    ver
G4     4        q     u                    him,
rest   8        h
measure 47
rest   2        e
D5     2        e     d                    let
G5     2        e     d                    him
F5     2        e     d                    de-
Ef5    3        e.    d                    li-
D5     1        s     d                    ver
C5     4        q     d                    him,
measure 48
rest   2        e
C5     2        e     d                    let
F5     2        e     d                    him
Ef5    2        e     d                    de-
D5     3        e.    d                    li-
C5     1        s     d                    ver
Bf4    4        q     u                    him.
measure 49
rest  16
measure 50
rest   4        q
G5     4        q     d                    He
C5     4        q     d                    trus-
D5     2        e     d                    ted
D5     2        e     d                    in
measure 51
Ef5    2        e     d                    God
C5     2        e     d                    that
F5     4-       q     d        -           he_
F5     2        e     d                    _
Ef5    1        s     d  [[                would_
D5     1        s     d  =]                _
Ef5    2        e     d  ]                 _
F5     2        e     d                    de-
measure 52
G5     2        e     d                    li-
Ef5    2        e     d                    ver
Af5    4        q     d                    him,
rest   2        e
G5     2        e     d                    let
G5     2        e     d                    him
G5     2        e     d                    de-
measure 53
G5     2        e     d                    li-
F5     2        e     d                    ver
F5     4        q     d                    him,
rest   2        e
Af5    2        e     d                    if
G5     2        e     d                    he
F5     2        e     d                    de-
measure 54
Ef5    4        q     d                    light
D5     4        q     d                    in
C5     4        q     d                    him,
rest   4        q
measure 55
rest  16
measure 56
rest   2        e
Bf4    2        e     u                    if
Ef5    2        e     d                    he
D5     2        e     d                    de-
C5     2        e     d  [                 light_
D5     1        s     d  =[                _
Ef5    1        s     d  =]                _
D5     2        e     d  ]                 _
C5     2        e     d                    in
measure 57
B4     4        q     u                    him,
rest   4        q
rest   2        e
C5     2        e     d                    if
Bf4    2        e     u                    he
Af4    2        e     u                    de-
measure 58
G4     2        e     d  [                 light_
Ef5    2        e     d  =                 _
D5     2        e     d  =                 _
C5     2        e     d  ]                 _
B4     2        e     u  [                 _
G4     2        e     u  ]                 _
G5     4-       q     d        -           _
measure 59
G5     4        q     d                    _
F5     2        e     d  [                 in_
Ef5    2        e     d  ]                 _
D5     2        e     d                    him,
Bf4    2        e     u                    let
Ef5    4-       q     d        -           him_
measure 60
Ef5    4        q     d                    _
D5     2        e     d  [                 de-
C5     2        e     d  ]                 -
B4     3        e.    u                    li-
B4     1        s     u                    ver
B4     4        q     u                    him,
measure 61
rest   4        q
$ D:Adagio
B4     4        q     u                    if
C5     4        q     d                    he
C5     4        q     d                    de-
measure 62
C5     8        h     d                    light
B4     8        h     u                    in
measure 63
C5    16        w     d                    him.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/5} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:4258f4c08cff6952ae18b1cfaabcaa27]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
0 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   4        q
G4     4        q     u                    He
C4     4        q     u                    trus-
D4     2        e     u                    ted
D4     2        e     u                    in
measure 11
Ef4    2        e     u                    God
C4     2        e     u                    that
F4     4-       q     u        -           he_
F4     2        e     u                    _
Ef4    1        s     u  [[                would_
D4     1        s     u  =]                _
Ef4    2        e     u  ]                 _
F4     2        e     u                    de-
measure 12
G4     2        e     u                    li-
Ef4    2        e     u                    ver
Af4    4        q     u                    him;
rest   2        e
G4     2        e     u                    let
G4     2        e     u                    him
G4     2        e     u                    de-
measure 13
C5     2        e     d                    li-
F4     2        e     u                    ver
F4     4        q     u                    him,
rest   2        e
Af4    2        e     u                    if
G4     2        e     u                    he
F4     2        e     u                    de-
measure 14
Ef4    4        q     u                    light
D4     4        q     u                    in
C4     4        q     u                    him,
rest   4        q
measure 15
rest   2        e
G4     2        e     u                    if
F4     2        e     u                    he
Ef4    2        e     u                    de-
D4     2        e     u  [                 light_
G4     2        e     u  =                 _
F#4    2        e     u  =                 _
G4     2        e     u  ]                 _
measure 16
D4     2        e     u  [                 _
A4     2        e     u  =                 _
G4     2        e     u  =                 _
F#4    2        e     u  ]                 _
G4     6        q.    u                    _
A4     1        s     u  [[                _
Bf4    1        s     u  ]]                _
measure 17
A4     6        q.    u                    _
Bf4    1        s     u  [[                _
A4     1        s     u  ]]                _
G4     6        q.    u                    _
A4     1        s     u  [[                _
G4     1        s     u  ]]                _
measure 18
F#4    4        q     u                    _
G4     8        h     u                    _
F#4    4        q     u                    in
measure 19
G4     4        q     u                    him,
rest   4        q
rest   8        h
measure 20
rest   8        h
rest   2        e
F4     2        e     u                    let
Bf4    2        e     u                    him
Af4    2        e     u                    de-
measure 21
G4     3        e.    u                    li-
F4     1        s     u                    ver
Ef4    2        e     u                    him,
G4     2        e     u                    if
F4     6        q.    u                    he
G4     2        e     u                    de-
measure 22
Ef4    6        q.    u                    light
Ef4    2        e     u                    in
D4     4        q     u                    him.
rest   4        q
measure 23
rest   4        q
F4     4        q     u                    He
Bf3    4        q     u                    trus-
C4     2        e     u                    ted
C4     2        e     u                    in
measure 24
D4     2        e     u                    God
Bf3    2        e     u                    that
Ef4    4-       q     u        -           he_
Ef4    2        e     u                    _
D4     1        s     u  [[                would_
C4     1        s     u  =]                _
D4     2        e     u  ]                 _
Ef4    2        e     u                    de-
measure 25
F4     2        e     u                    li-
D4     2        e     u                    ver
G4     4        q     u                    him;
rest   2        e
F4     2        e     u                    let
F4     2        e     u                    him
F4     2        e     u                    de-
measure 26
Bf4    2        e     u                    li-
Ef4    2        e     u                    ver
Ef4    4        q     u                    him,
rest   2        e
G4     2        e     u                    if
F4     2        e     u                    he
Ef4    2        e     u                    de-
measure 27
D4     4        q     u                    light
C4     4        q     u                    in
Bf3    2        e     u                    him,
D4     2        e     u                    if
Ef4    2        e     u                    he
F4     2        e     u                    de-
measure 28
G4     2        e     u  [                 light_
Ef4    2        e     u  =                 _
D4     2        e     u  =                 _
C4     2        e     u  ]                 _
Bf3    2        e     u                    _
Ef4    4        q     u                    _
D4     2        e     u                    _
measure 29
C4     2        e     u  [                 _
Bf3    2        e     u  ]                 _
C4     2        e     u  [                 in_
D4     2        e     u  ]                 _
Ef4    4        q     u                    him,
rest   4        q
measure 30
rest   2        e
D4     2        e     u                    let
Ef4    2        e     u                    him
F4     2        e     u                    de-
G4     2        e     u                    li-
Ef4    2        e     u                    ver
Af4    2        e     u                    him,
F4     2        e     u                    if
measure 31
D4     6        q.    u                    he
D4     2        e     u                    de-
C4     6        q.    u                    light
C4     2        e     u                    in
measure 32
D4     2        e     u                    him,
D4     2        e     u                    if
Ef4    2        e     u                    he
Ef4    2        e     u                    de-
Ef4    4        q     u                    light
D4     4        q     u                    in
measure 33
Ef4    4        q     u                    him,
rest   4        q
rest   2        e
F4     2        e     u                    let
Bf4    2        e     u                    him
Bf4    2        e     u                    de-
measure 34
Af4    3        e.    u                    li-
G4     1        s     u                    ver
F4     4        q     u                    him,
rest   8        h
measure 35
rest   2        e
C4     2        e     u                    let
F4     2        e     u                    him
F4     2        e     u                    de-
E4     3        e.    u                    li-
D4     1        s     u                    ver
C4     4        q     u                    him,
measure 36
rest   8        h
rest   2        e
Af4    2        e     u                    if
G4     2        e     u                    he
F4     2        e     u                    de-
measure 37
E4     2        e     u  [      (          light_
C4     2        e     u  ]                 _
F4     8        h     u         )          _
E4     2        e     u  [                 in_
D4     2        e     u  ]                 _
measure 38
C4     4        q     u                    him,
rest   4        q
rest   8        h
measure 39
rest   8        h
rest   2        e
F4     2        e     u                    let
Bf4    2        e     u                    him
Bf4    2        e     u                    de-
measure 40
A4     3        e.    u                    li-
G4     1        s     u                    ver
F4     4        q     u                    him,
rest   2        e
Bf4    2        e     u                    if
G4     2        e     u                    he
F#4    2        e     u                    de-
measure 41
G4     6        q.    u                    light
G4     2        e     u                    in
F#4    6        q.    u                    him.
F#4    2        e     u                    He
measure 42
G4     4        q     u                    trus-
F4     2        e     u         +          ted
Ef4    2        e     u                    in
D4     2        e     u                    God,
Bf4    2        e     u                    let
A4     2        e     u                    him
G4     2        e     u                    de-
measure 43
F#4    2        e     u                    li-
D4     2        e     u                    ver
G4     2        e     u                    him,
A4     2        e     u                    if
Bf4    6        q.    u                    he
Bf4    2        e     u                    de-
measure 44
A4     2        e     u  [                 light_
F4     2        e     u  =                 _
Bf4    2        e     u  =                 _
A4     2        e     u  ]                 _
G4     2        e     u  [                 _
A4     1        s     u  =[                _
Bf4    1        s     u  ]]                _
A4     2        e     u  [                 _
G4     2        e     u  ]                 _
measure 45
F#4    2        e     u  [                 _
D4     2        e     u  ]                 _
G4     8        h     u                    _
F#4    4        q     u                    in
measure 46
G4     2        e     u                    him,
D4     2        e     u                    let
G4     2        e     u                    him
F4     2        e     u         +          de-
Ef4    3        e.    u                    li-
D4     1        s     u                    ver
C4     4        q     u                    him,
measure 47
rest  16
measure 48
rest   8        h
rest   2        e
F4     2        e     u                    if
Bf4    2        e     u                    he
Af4    2        e     u                    de-
measure 49
G4    12        h.    u                    light
F4     4        q     u                    in
measure 50
G4     4        q     u                    him.
G4     4        q     u                    He
Ef4    4        q     u                    trus-
G4     2        e     u                    ted
G4     2        e     u                    in
measure 51
G4     2        e     u                    God,
G4     2        e     u                    let
Af4    2        e     u                    him
Af4    2        e     u                    de-
G4     6        q.    u                    li-
F4     2        e     u                    ver
measure 52
Ef4    2        e     u                    him,
Ef4    2        e     u                    let
F4     2        e     u                    him
F4     2        e     u                    de-
F4     2        e     u  [                 li-
D4     2        e     u  ]                 -
Bf4    4        q     u                    -
measure 53
Af4    6        q.    u                    -
Af4    2        e     u                    ver
G4     2        e     u                    him,
D4     2        e     u                    if
G4     2        e     u                    he
Af4    2        e     u                    de-
measure 54
G4     3        e.    u                    light
G4     1        s     u                    in
G4     4        q     u                    him,
rest   2        e
G4     2        e     u                    let
C5     2        e     d                    him
Bf4    2        e     u                    de-
measure 55
Af4    3        e.    u                    li-
G4     1        s     u                    ver
F4     4        q     u                    him,
rest   2        e
F4     2        e     u                    if
Bf4    2        e     u                    he
Af4    2        e     u                    de-
measure 56
G4     6        q.    u                    light_
F4     2        e     u                    _
Ef4    2        e     u  [                 _
F4     1        s     u  =[                _
G4     1        s     u  ]]                _
F4     4-       q     u        -           _
measure 57
F4     2        e     u  [                 _
G4     1        s     u  =[                _
F4     1        s     u  ]]                _
Ef4    2        e     u  [                 _
D4     2        e     u  ]                 _
Ef4    4        q     u                    _
D4     2        e     u  [                 _
C4     2        e     u  ]                 _
measure 58
Bf3    2        e     u  [                 _
Ef4    2        e     u  ]                 _
Af4    4        q     u                    _
G4     6        q.    u                    _
F4     2        e     u                    _
measure 59
Ef4    4        q     u                    _
F4     4        q     u                    in
Bf4    6        q.    u                    him,
Bf4    2        e     u                    let
measure 60
Af4    6        q.    u                    him
Af4    2        e     u                    de-
G4     3        e.    u                    li-
G4     1        s     u                    ver
G4     4        q     u                    him,
measure 61
rest   4        q
$ D:Adagio
G4     4        q     u                    if
G4     4        q     u                    he
G4     4        q     u                    de-
measure 62
G4    12        h.    u                    light
G4     4        q     u                    in
measure 63
G4    16        w     u                    him.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/6} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:0e49ef58cabe63c17b4928b901f8e705]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
0 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:34   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
C4     4        q     d                    He
measure 6
G3     4        q     u                    trus-
A3     2        e     u                    ted
A3     2        e     u                    in
Bf3    2        e     u                    God
G3     2        e     u                    that
C4     4-       q     d        -           he_
measure 7
C4     2        e     d                    _
Bf3    1        s     u  [[                would_
A3     1        s     u  =]                _
Bf3    2        e     u  ]                 _
C4     2        e     d                    de-
D4     2        e     d                    li-
Bf3    2        e     d                    ver
Ef4    4        q     d                    him;
measure 8
rest   2        e
D4     2        e     d                    let
D4     2        e     d                    him
D4     2        e     d                    de-
G4     2        e     d                    li-
C4     2        e     d                    ver
C4     4        q     d                    him,
measure 9
rest   2        e
Ef4    2        e     d                    if
D4     2        e     d                    he
C4     2        e     d                    de-
Bf3    4        q     u                    light
A3     4        q     u                    in
measure 10
G3     4        q     u                    him,
rest   4        q
rest   2        e
G3     2        e     u                    if
A3     2        e     u                    he
B3     2        e     u                    de-
measure 11
C4     4        q     d                    light
rest   2        e
D4     2        e     d                    in
G3     2        e     u                    him,
B3     2        e     d                    let
C4     2        e     d                    him
D4     2        e     d                    de-
measure 12
Ef4    2        e     d                    li-
C4     2        e     d                    ver
F4     2        e     d                    him,
F4     2        e     d                    if
Bf3    4        q     d         +          he
rest   2        e
Ef4    2        e     d                    de-
measure 13
Af3    6        q.    u                    light
Af3    2        e     u                    in
G3     2        e     u                    him,
B3     2        e     d                    if
C4     2        e     d                    he
D4     2        e     d                    de-
measure 14
G3     4        q     u                    light
B3     4        q     d                    in
C4     2        e     d                    him,
D4     2        e     d                    if
Ef4    2        e     d                    he
D4     2        e     d                    de-
measure 15
C4     6        q.    d                    light_
D4     1        s     d  [[                _
C4     1        s     d  ]]                _
Bf3    2        e     d  [      +          _
D4     2        e     d  =                 _
C4     2        e     d  =                 _
Bf3    2        e     d  ]                 _
measure 16
A3     2        e     u                    _
D4     4        q     d                    _
C4     2        e     d                    _
Bf3    2        e     d  [                 _
D4     2        e     d  ]                 _
C4     4-       q     d        -           _
measure 17
C4     2        e     d  [                 _
F4     2        e     d  ]                 _
D4     4-       q     d        -           _
D4     2        e     d  [                 _
Ef4    1        s     d  =[                _
D4     1        s     d  ]]                _
C4     2        e     d  [                 _
Ef4    2        e     d  ]                 _
measure 18
A3     4        q     u                    _
Bf3    2        e     d  [                 in_
C4     2        e     d  ]                 _
D4     8        h     d                    him,
measure 19
rest   2        e
D4     2        e     d                    let
G4     2        e     d                    him
F4     2        e     d                    de-
E4     3        e.    d                    li-
D4     1        s     d                    ver
C4     4        q     d                    him,
measure 20
rest   8        h
rest   4        q
rest   2        e
Bf3    2        e     d                    if
measure 21
Ef4    6        q.    d                    he
Ef4    2        e     d                    de-
D4     6        q.    d                    light_
Ef4    1        s     d  [[                _
D4     1        s     d  ]]                _
measure 22
C4     6        q.    d                    _
C4     2        e     d                    in
Bf3    2        e     u                    him,
Bf3    2        e     u                    if
A3     2        e     u                    he
G3     2        e     u                    de-
measure 23
F3     2        e     u                    light_
Bf3    4        q     u                    _
A3     2        e     u                    _
G3     2        e     u  [                 _
F3     2        e     u  =                 _
G3     2        e     u  ]                 _
A3     2        e     u                    in
measure 24
Bf3    4        q     u                    him,
rest   4        q
rest   2        e
A3     2        e     u                    let
Bf3    2        e     u                    him
C4     2        e     d                    de-
measure 25
D4     2        e     d                    li-
Bf3    2        e     d                    ver
Ef4    2        e     d                    him
C4     2        e     d                    if
A3     6        q.    u                    he
A3     2        e     u                    de-
measure 26
G3     6        q.    u                    light
G3     2        e     u                    in
A3     2        e     u                    him,
A3     2        e     u                    if
Bf3    2        e     u                    he
Bf3    2        e     u                    de-
measure 27
Bf3    4        q     u                    light
A3     4        q     u                    in
Bf3    4        q     u                    him.
Bf3    4        q     u                    He
measure 28
Ef3    4        q     u                    trus-
F3     2        e     u                    ted
F3     2        e     u                    in
G3     6        q.    u                    God,
G3     2        e     u                    he
measure 29
Af3    2        e     u  [                 trus-
G3     2        e     u  ]                 -
Af3    2        e     u                    ted
F3     2        e     u                    in
Ef3    2        e     u                    God,
Ef4    2        e     d                    let
F4     2        e     d                    him
Ef4    2        e     d                    de-
measure 30
D4     2        e     d                    li-
Bf3    2        e     d                    ver
Ef4    4        q     d                    him,
rest   4        q
rest   2        e
Af3    2        e     u                    if
measure 31
F3     4        q     u                    he
G3     4        q     u                    de-
Ef3    4        q     u                    light
F3     4        q     u                    in
measure 32
Bf3    2        e     u                    him,
Af3    2        e     u                    if
G3     2        e     u                    he
Af3    2        e     u                    de-
Bf3    6        q.    u                    light
Bf3    2        e     u                    in
measure 33
Bf3    2        e     u                    him,
Bf3    2        e     u                    let
Ef4    2        e     d                    him
Ef4    2        e     d                    de-
D4     3        e.    d                    li-
C4     1        s     d                    ver
Bf3    4        q     d                    him.
measure 34
rest  16
measure 35
rest   8        h
rest   4        q
rest   2        e
C4     2        e     d                    He
measure 36
F3     4        q     u                    trus-
G3     2        e     u                    ted
G3     2        e     u                    in
Af3    2        e     u                    God
F3     2        e     u                    that
Bf3    4-       q     u        -           he_
measure 37
Bf3    2        e     u                    _
Af3    1        s     u  [[                would_
G3     1        s     u  =]                _
Af3    2        e     u  ]                 _
Bf3    2        e     u                    de-
C4     6        q.    d                    li-
C4     2        e     d                    ver
measure 38
F3     4        q     u                    him;
rest   4        q
rest   2        e
F3     2        e     u                    let
Bf3    2        e     u                    him
Bf3    2        e     u                    de-
measure 39
A3     3        e.    u                    li-
G3     1        s     u                    ver
F3     4        q     u                    him,
rest   8        h
measure 40
rest   2        e
F3     2        e     u                    if
F3     2        e     u                    he
G3     2        e     u                    de-
A3     2        e     u                    light
Bf3    2        e     u                    in
C4     2        e     d                    him,
D4     2        e     d                    let
measure 41
Ef4    6        q.    d                    him
Ef4    2        e     d                    de-
D4     3        e.    d                    li-
D4     1        s     d                    ver
A3     2        e     u                    him.
A3     2        e     u                    He
measure 42
Bf3    4        q     d                    trus-
C4     2        e     d                    ted
C4     2        e     d                    in
D4     2        e     d                    God,
D4     2        e     d                    let
C4     2        e     d                    him
Bf3    2        e     d                    de-
measure 43
A3     2        e     u                    li-
A3     2        e     u                    ver
D4     2        e     d                    him,
C4     2        e     d                    if
Bf3    2        e     d                    he
Bf3    2        e     d                    de-
G4     2        e     d  [                 light_
Ef4    2        e     d  ]                 _
measure 44
C4     2        e     d  [                 _
D4     1        s     d  =[                _
Ef4    1        s     d  ]]                _
F4     2        e     d  [                 _
D4     2        e     d  ]                 _
Bf3    2        e     d  [                 _
C4     1        s     d  =[                _
D4     1        s     d  ]]                _
Ef4    2        e     d  [                 _
C4     2        e     d  ]                 _
measure 45
A3     2        e     d  [                 _
Bf3    1        s     d  =[                _
C4     1        s     d  ]]                _
D4     2        e     d  [                 _
C4     2        e     d  ]                 _
Bf3    4        q     d                    _
A3     4        q     u                    in
measure 46
G3     4        q     u                    him,
rest   4        q
rest   2        e
G3     2        e     u                    let
C4     2        e     d                    him
C4     2        e     d                    de-
measure 47
B3     3        e.    u                    li-
A3     1        s     u                    ver
G3     4        q     u                    him,
rest   8        h
measure 48
rest  16
measure 49
rest   2        e
Bf3    2        e     d         +          if
Ef4    2        e     d                    he
D4     2        e     d                    de-
C4     2        e     d  [                 light_
D4     1        s     d  =[                _
Ef4    1        s     d  =]                _
D4     2        e     d  ]                 _
C4     2        e     d                    in
measure 50
B3     2        e     d                    him,
D4     2        e     d                    if
C4     2        e     d                    he
B3     2        e     d                    de-
G4     6        q.    d                    light,_
F4     2        e     d                    _
measure 51
Ef4    4        q     d                    _
D4     8        h     d                    _
C4     2        e     d  [                 _
B3     2        e     d  ]                 _
measure 52
C4     6        q.    d                    _
D4     1        s     d  [[                _
C4     1        s     d  ]]                _
Bf3    4        q     d         +          _
G4     2        e     d  [                 _
F4     2        e     d  ]                 _
measure 53
Ef4    2        e     d  [                 _
C4     2        e     d  =                 _
F4     2        e     d  =                 _
Ef4    2        e     d  =                 _
D4     2        e     d  ]                 _
D4     2        e     d                    if
Ef4    2        e     d                    he
C4     2        e     d                    de-
measure 54
C4     4        q     d                    light
B3     4        q     d                    in
C4     4        q     d                    him,
rest   4        q
measure 55
rest   2        e
C4     2        e     d                    let
F4     2        e     d                    him
Ef4    2        e     d                    de-
D4     3        e.    d                    li-
C4     1        s     d                    ver
Bf3    4        q     d         +          him,
measure 56
rest   2        e
Ef3    2        e     u                    if
F3     2        e     u                    he
G3     2        e     u                    de-
Af3    6        q.    u                    light
Af3    2        e     u                    in
measure 57
G3     2        e     u                    him,
D4     2        e     d                    if
C4     2        e     d                    he
B3     2        e     d                    de-
G4     4        q     d                    light_
F4     4        q     d                    _
measure 58
Ef4    2        e     d  [                 _
G4     2        e     d  =                 _
F4     2        e     d  =                 _
Ef4    2        e     d  ]                 _
D4     4        q     d                    _
C4     2        e     d  [                 _
D4     2        e     d  ]                 _
measure 59
Bf3    4        q     d                    _
C4     4        q     d                    in
F4     2        e     d                    him,
F4     2        e     d                    let
G4     2        e     d                    him,
Ef4    2        e     d                    let
measure 60
F4     6        q.    d                    him
Ef4    2        e     d                    de-
D4     3        e.    d                    li-
D4     1        s     d                    ver
D4     4        q     d                    him,
measure 61
rest   4        q
$ D:Adagio
D4     4        q     d                    if
Ef4    4        q     d                    he
Ef4    4        q     d                    de-
measure 62
D4    12        h.    d                    light
D4     4        q     d                    in
measure 63
Ef4   16        w     d                    him.
mheavy
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/7} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:91da25ff551d2517f42bf5d4909806b3]
04/12/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
0 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:22   D:Allegro
rest   4        q
G3     4        q     d                    He
C3     4        q     u                    trus-
D3     2        e     u                    ted
D3     2        e     u                    in
measure 2
Ef3    2        e     d                    God
C3     2        e     u                    that
F3     4-       q     d        -           he_
F3     2        e     d                    _
Ef3    1        s     d  [[                would_
D3     1        s     d  =]                _
Ef3    2        e     d  ]                 _
F3     2        e     d                    de-
measure 3
G3     2        e     d                    li-
Ef3    2        e     d                    ver
Af3    4        q     d                    him;
rest   2        e
G3     2        e     d                    let
G3     2        e     d                    him
G3     2        e     d                    de-
measure 4
C4     2        e     d                    li-
F3     2        e     d                    ver
F3     4        q     d                    him,
rest   2        e
Af3    2        e     d                    if
G3     2        e     d                    he
F3     2        e     d                    de-
measure 5
Ef3    4        q     d                    light
D3     4        q     u                    in
C3     4        q     u                    him,
rest   4        q
measure 6
rest   2        e
Ef3    2        e     d                    if
D3     2        e     u                    he
C3     2        e     u                    de-
G3     4        q     d                    light
rest   2        e
A3     2        e     d                    in
measure 7
D3     2        e     u                    him,
F#3    2        e     d                    let
G3     2        e     d                    him
A3     2        e     d                    de-
Bf3    2        e     d                    li-
G3     2        e     d                    ver
C4     2        e     d                    him,
C4     2        e     d                    if
measure 8
F3     4        q     d                    he
rest   2        e
Bf3    2        e     d                    de-
Ef3    6        q.    d                    light
Ef3    2        e     d                    in
measure 9
D3     2        e     u                    him,
F#3    2        e     d                    if
G3     2        e     d                    he
C3     2        e     u                    de-
D3     4        q     u                    light
F#3    4        q     d                    in
measure 10
G3     2        e     d                    him,
F3     2        e     d         +          if
Ef3    2        e     d                    he
D3     2        e     u                    de-
Ef3    4        q     d                    light
F3     2        e     d  [                 in_
G3     2        e     d  ]                 _
measure 11
C3     4        q     u                    him.
rest   4        q
rest   8        h
measure 12
rest  16
measure 13
rest  16
measure 14
rest   4        q
G3     4        q     d                    He
C3     4        q     u                    trus-
C3     2        e     u                    ted
D3     2        e     u                    in
measure 15
Ef3    4        q     d                    God,
D3     2        e     u  [                 in_
C3     2        e     u  ]                 _
G3     2        e     d                    God,
Bf3    2        e     d                    in
A3     2        e     d                    God
G3     2        e     d                    he
measure 16
F#3    4        q     d                    trus-
G3     2        e     d                    ted;
A3     2        e     d                    let
Bf3    2        e     d                    him
G3     2        e     d                    de-
C4     2        e     d                    li-
C4     2        e     d                    ver
measure 17
F3     2        e     d         +          him,
F3     2        e     d                    if
Bf3    2        e     d                    he
Bf3    2        e     d                    de-
Ef3    6        q.    d                    light
Ef3    2        e     d                    in
measure 18
D3     8        h     u                    him,
rest   2        e
D3     2        e     u                    if
D4     2        e     d                    he
C4     2        e     d                    de-
measure 19
B3     3        e.    d                    light
A3     1        s     d                    in
G3     4        q     d                    him,
rest   2        e
G3     2        e     d                    let
C4     2        e     d                    him
Bf3    2        e     d                    de-
measure 20
Af3    3        e.    d         +          li-
G3     1        s     d                    ver
F3     4        q     d                    him.
rest   8        h
measure 21
rest  16
measure 22
rest   4        q
F3     4        q     d                    He
Bf2    4        q     u                    trus-
C3     2        e     u                    ted
C3     2        e     u                    in
measure 23
D3     6        q.    u                    God,
D3     2        e     u                    he
Ef3    2        e     d  [                 trus-
D3     2        e     d  ]                 -
Ef3    2        e     d                    ted
C3     2        e     u                    in
measure 24
Bf2    2        e     u                    God,
Bf3    2        e     d                    let
C4     2        e     d                    him
Bf3    2        e     d                    de-
A3     2        e     d                    li-
F3     2        e     d                    ver
Bf3    4        q     d                    him,
measure 25
rest   4        q
rest   2        e
Ef3    2        e     d                    if
C3     4        q     u                    he
D3     4        q     u                    de-
measure 26
Bf2    4        q     u                    light
C3     4        q     u                    in
F3     2        e     d                    him,
Ef3    2        e     d                    if
D3     2        e     u                    he
Ef3    2        e     d                    de-
measure 27
F3     6        q.    d                    light
F3     2        e     d                    in
Bf2    4        q     u                    him,
rest   4        q
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
rest   2        e
Bf2    2        e     u                    let
Bf3    2        e     d                    him
Af3    2        e     d                    de-
measure 33
G3     3        e.    d                    li-
F3     1        s     d                    ver
Ef3    4        q     d                    him,
rest   8        h
measure 34
rest   8        h
rest   2        e
G3     2        e     d                    let
C4     2        e     d                    him
Bf3    2        e     d                    de-
measure 35
Af3    3        e.    d                    li-
G3     1        s     d                    ver
F3     4        q     d                    him,
rest   8        h
measure 36
rest  16
measure 37
rest  16
measure 38
rest   2        e
F3     2        e     d                    let
F3     2        e     d                    him
Ef3    2        e     d                    de-
D3     3        e.    u                    li-
C3     1        s     u                    ver
Bf2    4        q     u                    him.
measure 39
rest  16
measure 40
rest  16
measure 41
rest   8        h
rest   4        q
D3     4        q     u                    He
measure 42
G2     4        q     u                    trus-
A2     2        e     u                    ted
A2     2        e     u                    in
Bf2    2        e     u                    God
G2     2        e     u                    that
C3     4-       q     u        -           he_
measure 43
C3     2        e     u                    _
Bf2    1        s     u  [[                would_
A2     1        s     u  =]                _
Bf2    2        e     u  ]                 _
C3     2        e     u                    de-
D3     2        e     u                    li-
Bf2    2        e     u                    ver
Ef3    4-       q     d        -           him;_
measure 44
Ef3    2        e     d                    _
D3     2        e     u                    let
D3     2        e     u                    him
D3     2        e     u                    de-
D3     2        e     u                    li-
C3     2        e     u                    ver
C3     4-       q     u        -           him,_
measure 45
C3     2        e     u                    _
C3     2        e     u                    if
Bf2    2        e     u                    he
C3     2        e     u                    de-
D3     6        q.    u                    light
D3     2        e     u                    in
measure 46
G2     4        q     u                    him,
rest   4        q
rest   8        h
measure 47
rest   8        h
rest   2        e
G3     2        e     d                    let
C4     2        e     d                    him
Bf3    2        e     d                    de-
measure 48
Af3    3        e.    d                    li-
G3     1        s     d                    ver
F3     4        q     d                    him,
rest   8        h
measure 49
rest   2        e
Ef3    2        e     d                    if
G3     2        e     d                    he
Ef3    2        e     d                    de-
Af3    6        q.    d                    light
Af3    2        e     d                    in
measure 50
G3     2        e     d                    him,
F3     2        e     d                    if
Ef3    2        e     d                    he
D3     2        e     u                    de-
C3     2        e     d  [                 light_
C4     2        e     d  =                 _
B3     2        e     d  =                 _
G3     2        e     d  ]                 _
measure 51
C4     6        q.    d                    _
D4     1        s     d  [[                _
C4     1        s     d  ]]                _
B3     2        e     d  [                 _
G3     2        e     d  =                 _
C3     2        e     d  =                 _
D3     2        e     d  ]                 _
measure 52
Ef3    2        e     d  [                 _
C3     2        e     d  =                 _
F3     2        e     d  ]                 _
Ef3    2        e     d                    in
D3     2        e     u                    him,
Bf3    2        e     d         +          if
Ef4    2        e     d                    he
D4     2        e     d                    de-
measure 53
C4     2        e     d  [                 light_
Ef4    2        e     d  =                 _
D4     2        e     d  =                 _
C4     2        e     d  ]                 _
B3     2        e     d  [                 _
C4     1        s     d  =[                _
B3     1        s     d  =]                _
C4     2        e     d  ]                 _
F3     2        e     d                    in
measure 54
G3     2        e     d                    him,
G3     2        e     d                    let
G3     2        e     d                    him
F3     2        e     d                    de-
Ef3    3        e.    d                    li-
D3     1        s     u                    ver
C3     4        q     u                    him.
measure 55
rest  16
measure 56
rest  16
measure 57
rest   4        q
G3     4        q     d                    He
C3     4        q     u                    trus-
D3     2        e     u                    ted
D3     2        e     u                    in
measure 58
Ef3    2        e     d                    God
C3     2        e     u                    that
F3     4-       q     d        -           he_
F3     2        e     d                    _
Ef3    1        s     d  [[                would_
D3     1        s     d  =]                _
Ef3    2        e     d  ]                 _
F3     2        e     d                    de-
measure 59
G3     2        e     d                    li-
Ef3    2        e     d                    ver
Af3    4-       q     d        -           him;_
Af3    2        e     d                    _
G3     2        e     d                    let
G3     2        e     d                    him,
G3     2        e     d                    let
measure 60
F3     6        q.    d                    him
F3     2        e     d                    de-
F3     3        e.    d                    li-
F3     1        s     d                    ver
F3     4        q     d                    him,
measure 61
rest   4        q
$ D:Adagio
F3     4        q     d                    if
Ef3    4        q     d                    he
C3     4        q     u                    de-
measure 62
G3    12        h.    d                    light
G3     4        q     d                    in
measure 63
C3    16        w     u                    him.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-06/8} [KHM:951764819]
TIMESTAMP: DEC/26/2001 [md5sum:c1cc6fea71528395a005d42e5dcc9a0b]
06/10/90 E. Correia
WK#:56        MV#:2,6
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
0 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:22   D:Allegro
C4     4        q     d
*               D       Tasto solo
G3     4        q     d
C3     4        q     u
D3     2        e     d  [
D3     2        e     d  ]
measure 2
Ef3    2        e     d  [
C3     2        e     d  ]
F3     4-       q     d        -
F3     2        e     d  [
Ef3    1        s     d  =[
D3     1        s     d  ]]
Ef3    2        e     d  [
F3     2        e     d  ]
measure 3
G3     2        e     d  [
Ef3    2        e     d  ]
Af3    4-       q     d        -
Af3    2        e     d  [
G3     1        s     d  =[
F3     1        s     d  ]]
G3     2        e     d  [
G3     2        e     d  ]
measure 4
C4     2        e     d  [
F3     2        e     d  ]
F3     4-       q     d        -
F3     2        e     d  [
G3     1        s     d  =[
Af3    1        s     d  ]]
G3     2        e     d  [
F3     2        e     d  ]
measure 5
Ef3    4        q     d
D3     4        q     u
C3     4        q     u
rest   4        q
measure 6
rest   2        e
Ef3    2        e     d  [
D3     2        e     d  =
C3     2        e     d  ]
G3     4        q     d
rest   2        e
A3     2        e     d
measure 7
D3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
Bf3    2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 8
f1              7
F3     6        q.    d
Bf3    2        e     d
f1     4        7
f1              6
Ef3    6        q.    d
Ef3    2        e     d
measure 9
f2              7 #
D3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  =
C3     2        e     d  ]
D3     4        q     u
D2     4        q     u
measure 10
G2     2        e     u  [
F3     2        e     u  =      +
Ef3    2        e     u  =
D3     2        e     u  ]
Ef3    4        q     d
F3     2        e     d  [
G3     2        e     d  ]
measure 11
C3     4        q     u
$ C:13
rest   2        e
D4     2        e     d
G3     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 12
Ef4    2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
Bf3    4        q     d         +
rest   2        e
Ef4    2        e     d
measure 13
Af3    6        q.    d
Af3    2        e     d
G3     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 14
G3     4        q     d
$ C:22
f1              n
G3     4        q     d
C3     4        q     u
C3     2        e     u  [
D3     2        e     u  ]
measure 15
Ef3    4        q     d
D3     2        e     u  [
C3     2        e     u  ]
G3     2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
measure 16
F#3    4        q     d
G3     2        e     d  [
f1              6
A3     2        e     d  ]
Bf3    2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 17
F3     2        e     d  [      +
F3     2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
Ef3    6        q.    d
Ef3    2        e     d
measure 18
f2     4        7 #
f2              6 4
D3     8-       h     d        -
D3     2        e     d  [
D3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 19
B3     3        e.    d  [
A3     1        s     d  =\
G3     2        e     d  =
B3     2        e     d  ]
C4     2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 20
Af3    3        e.    d  [      +
G3     1        s     d  =\
F3     2        e     d  =
Af3    2        e     d  ]
Bf3    4        q     d
D3     4        q     d
measure 21
Ef3    4        q     d
$ C:12
f1              6
Ef4    4        q     d
f1     4        7
f1              6
D4     6        q.    d
Ef4    1        s     d  [[
D4     1        s     d  ]]
measure 22
C4     4        q     d
$ C:22
F3     4        q     d
Bf2    4        q     u
f1              6n
C3     2        e     u  [
f1              5
C3     2        e     u  ]
measure 23
D3     6        q.    u
D3     2        e     u
f1              5
Ef3    2        e     u  [
D3     2        e     u  =
f1              6
Ef3    2        e     u  =
f1              6n
C3     2        e     u  ]
measure 24
Bf2    2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  ]
measure 25
D4     2        e     d  [
Bf3    2        e     d  =
Ef4    2        e     d  =
Ef3    2        e     d  ]
f2              6n 5
C3     4        q     u
D3     4        q     u
measure 26
f2              6 5
Bf2    4        q     u
C3     4        q     u
F3     2        e     d  [
Ef3    2        e     d  =
D3     2        e     d  =
Ef3    2        e     d  ]
measure 27
F3     6        q.    d
F3     2        e     d
Bf2    4        q     u
$ C:12
Bf3    4        q     d
measure 28
Ef3    4        q     u
f1              6
F3     2        e     u  [
F3     2        e     u  ]
f1              6
G3     6        q.    u
G3     2        e     u
measure 29
f1              5
Af3    2        e     u  [
G3     2        e     u  =
f1              6
Af3    2        e     u  =
Bf3    2        e     u  ]
Ef3    2        e     u  [
Ef4    2        e     d  =
F4     2        e     d  =
Ef4    2        e     d  ]
measure 30
f2              6 5
D4     2        e     d  [
Bf3    2        e     d  =
Ef4    2        e     d  =
F4     2        e     d  ]
G4     2        e     d  [
Ef4    2        e     d  =
Af4    2        e     d  =
Af3    2        e     d  ]
measure 31
f2              6 5
F3     4        q     u
G3     4        q     u
f2              6 5
Ef3    4        q     u
F3     4        q     u
measure 32
Bf3    2        e     d  [
Af3    2        e     d  =
f1              6
G3     2        e     d  =
Af3    2        e     d  ]
Bf3    2        e     d  [
$ C:22
Bf2    2        e     d  =
Bf3    2        e     d  =
Af3    2        e     d  ]
measure 33
G3     3        e.    d  [
F3     1        s     d  ]\
Ef3    4        q     d
Bf3    2        e     d  [
Bf2    2        e     d  =
D3     2        e     d  =
E3     2        e     d  ]
measure 34
F3     2        e     d  [
G3     2        e     d  =
Af3    2        e     d  =
Bf3    2        e     d  ]
C4     2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 35
Af3    3        e.    d  [
G3     1        s     d  =\
Af3    2        e     d  =
F3     2        e     d  ]
C4     4        q     d
E3     2        e     d  [
C3     2        e     d  ]
$ C:12
measure 36
F3     4        q     u
G3     2        e     u  [
G3     2        e     u  ]
f1              6
Af3    2        e     u  [
F3     2        e     u  ]
f2     2        6 f
f1              5
Bf3    4-       q     d        -
measure 37
Bf3    2        e     d  [
Af3    1        s     d  =[
G3     1        s     d  ]]
Af3    2        e     d  [
Bf3    2        e     d  ]
C4     6        q.    d
C4     2        e     d
measure 38
F3     2        e     u  [
$ C:22
F2     2        e     u  ]
F3     2        e     d  [
Ef3    2        e     d  ]
D3     3        e.    d  [
C3     1        s     d  =\
Bf2    2        e     d  =
Bf3    2        e     d  ]
measure 39
A3     3        e.    d  [
G3     1        s     d  =\
F3     2        e     d  =
A3     2        e     d  ]
Bf3    2        e     d  [
$ C:12
C4     2        e     d  =
D4     2        e     d  =
Ef4    2        e     d  ]
measure 40
F4     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
A3     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 41
Ef4    6        q.    d
Ef4    2        e     d
D4     4        q     d
$ C:22
f1              #
D3     4        q     u
measure 42
G2     4        q     u
f1              6n
A2     2        e     u  [
A2     2        e     u  ]
Bf2    2        e     u  [
G2     2        e     u  ]
C3     4-       q     u        -
measure 43
C3     2        e     u  [
Bf2    1        s     u  =[
A2     1        s     u  ]]
Bf2    2        e     u  [
C3     2        e     u  ]
D3     2        e     u  [
Bf2    2        e     u  ]
Ef3    4-       q     d        -
measure 44
Ef3    2        e     d  [
D3     1        s     d  =[
C3     1        s     d  ]]
D3     2        e     u  [
D3     2        e     u  ]
D3     2        e     u  [
C3     2        e     u  ]
C3     4-       q     u        -
measure 45
f2              4+ 2
C3     2        e     u  [
C3     2        e     u  =
Bf2    2        e     u  =
C3     2        e     u  ]
D3     6        q.    u
D3     2        e     u
measure 46
G2     2        e     d  [
G3     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
C4     2        e     d  [
C3     2        e     d  =
Ef3    2        e     d  =
C3     2        e     d  ]
measure 47
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
C3     2        e     d  [
C3     2        e     d  =
Ef3    2        e     d  =
C3     2        e     d  ]
measure 48
F3     2        e     u  [
F2     2        e     u  =
Af2    2        e     u  =
F2     2        e     u  ]
Bf2    2        e     u  [
Bf2    2        e     u  =
D3     2        e     u  =
Bf2    2        e     u  ]
measure 49
Ef3    2        e     d  [
Ef3    2        e     d  =
G3     2        e     d  =
Ef3    2        e     d  ]
Af3    6        q.    d
Af3    2        e     d
measure 50
f1              n
G3     2        e     d  [
F3     2        e     d  =
Ef3    2        e     d  =
D3     2        e     d  ]
C3     2        e     d  [
C4     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
measure 51
C4     6        q.    d
D4     1        s     d  [[
C4     1        s     d  ]]
B3     2        e     d  [
G3     2        e     d  =
C3     2        e     d  =
D3     2        e     d  ]
measure 52
Ef3    2        e     d  [
C3     2        e     d  =
F3     2        e     d  =
Ef3    2        e     d  ]
D3     2        e     d  [
Bf3    2        e     d  =      +
Ef4    2        e     d  =
D4     2        e     d  ]
measure 53
C4     2        e     d  [
Ef4    2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
B3     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
F3     2        e     d  ]
measure 54
G3     2        e     u  [
G2     2        e     u  =
G3     2        e     u  =
F3     2        e     u  ]
Ef3    3        e.    d  [
D3     1        s     d  =\
C3     2        e     d  =
Ef3    2        e     d  ]
measure 55
F3     2        e     d  [
G3     2        e     d  =
Af3    2        e     d  =
F3     2        e     d  ]
Bf3    2        e     d  [
C4     2        e     d  =
D4     2        e     d  =
Bf3    2        e     d  ]
measure 56
Ef4    2        e     d  [
Ef3    2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
Af3    6        q.    d
Af3    2        e     d
measure 57
G3     4        q     d
G3     4        q     d
C3     4        q     u
D3     2        e     u  [
D3     2        e     u  ]
measure 58
Ef3    2        e     d  [
C3     2        e     d  ]
F3     4-       q     d        -
F3     2        e     d  [
Ef3    1        s     d  =[
D3     1        s     d  ]]
Ef3    2        e     d  [
F3     2        e     d  ]
measure 59
G3     2        e     d  [
Ef3    2        e     d  ]
Af3    4-       q     d        -
Af3    2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 60
f1     4        7
f1              6
F3     6        q.    d
f1              5
F3     2        e     d
f2              4n 2
F3     3        e.    d  [
F3     1        s     d  ]\
F3     4        q     d
measure 61
rest   4        q
$ D:Adagio
F3     4        q     d
Ef3    4        q     d
C3     4        q     u
measure 62
G3     8        h     d
G2     8        h     u
measure 63
C3    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
