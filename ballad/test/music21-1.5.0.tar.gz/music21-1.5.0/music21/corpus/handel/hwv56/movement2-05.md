&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-05/1} [KHM:1336091234]
TIMESTAMP: DEC/26/2001 [md5sum:60540b08f78d22cd5af0f50d9bc9ad0c]
04/12/90 E. Correia
WK#:56        MV#:2,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I, II
1 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Larghetto
Bf5    3        s.    d  [[
F5     1        t     d  ==\
Bf5    3        s.    d  ==
F5     1        t     d  ]]\
Bf5    3        s.    d  [[
F5     1        t     d  ==\
Bf5    3        s.    d  ==
F5     1        t     d  ]]\
Bf5    3        s.    d  [[
Ef5    1        t     d  ==\
Bf5    3        s.    d  ==
Ef5    1        t     d  ]]\
Bf5    3        s.    d  [[
Ef5    1        t     d  ==\
Bf5    3        s.    d  ==
Ef5    1        t     d  ]]\
measure 2
F5     3        s.    d  [[
Bf4    1        t     d  ==\
F5     3        s.    d  ==
Bf4    1        t     d  ]]\
F5     3        s.    d  [[
A4     1        t     d  ==\
F5     3        s.    d  ==
A4     1        t     d  ]]\
F5     3        s.    d  [[
Bf4    1        t     d  ==\
F5     3        s.    d  ==
Bf4    1        t     d  ]]\
F5     3        s.    d  [[
Bf4    1        t     d  ==\
Gf5    3        s.    d  ==
Bf4    1        t     d  ]]\
measure 3
F5     3        s.    d  [[
A4     1        t     d  ==\
Bf4    3        s.    d  ==
Ef5    1        t     d  ]]\
Df5    4        e     d  [      &(
C5     3        s.    d  =[     &)t
Bf4    1        t     d  ]]\
Bf4    3        s.    u  [[
F4     1        t     u  ==\
Bf4    3        s.    u  ==
F4     1        t     u  ]]\
Bf4    3        s.    u  [[
F4     1        t     u  ==\
Bf4    3        s.    u  ==
F4     1        t     u  ]]\
measure 4
Bf4    3        s.    u  [[     (p
F4     1        t     u  ==\    )
Bf4    3        s.    u  ==     (
F4     1        t     u  ]]\    )
Bf4    3        s.    u  [[     (
F4     1        t     u  ==\    )
Bf4    3        s.    u  ==     (
F4     1        t     u  ]]\    )
Bf4    3        s.    u  [[     (
F4     1        t     u  ==\    )
Bf4    3        s.    u  ==     (
F4     1        t     u  ]]\    )
Bf4    3        s.    u  [[     (
F4     1        t     u  ==\    )
Bf4    3        s.    u  ==     (
F4     1        t     u  ]]\    )
measure 5
Ef5    3        s.    d  [[     (
A4     1        t     d  ==\    )
Ef5    3        s.    d  ==     (
A4     1        t     d  ]]\    )
Ef5    3        s.    d  [[     (
A4     1        t     d  ==\    )
Ef5    3        s.    d  ==     (
A4     1        t     d  ]]\    )
A5     8        q     d
rest   8        q
measure 6
Bf5    1        t     d  [[[    f
Bf5    1        t     d  ===
F5     1        t     d  ===
F5     1        t     d  ]]]
Df5    1        t     d  [[[
Df5    1        t     d  ===
F5     1        t     d  ===
F5     1        t     d  ]]]
Bf4    1        t     d  [[[
Bf4    1        t     d  ===
Df5    1        t     d  ===
Df5    1        t     d  ]]]
F4     1        t     u  [[[
F4     1        t     u  ===
Bf4    1        t     u  ===
Bf4    1        t     u  ]]]
F5     3        s.    d  [[
Bf4    1        t     d  ==\
F5     3        s.    d  ==
Bf4    1        t     d  ]]\
F5     3        s.    d  [[
Bf4    1        t     d  ==\
F5     3        s.    d  ==
Bf4    1        t     d  ]]\
measure 7
Bf5    8        q     d
rest   8        q
Bf5    1        t     d  [[[
Bf5    1        t     d  ===
G5     1        t     d  ===
G5     1        t     d  ]]]
Ef5    1        t     d  [[[
Ef5    1        t     d  ===
G5     1        t     d  ===
G5     1        t     d  ]]]
Bf4    1        t     d  [[[
Bf4    1        t     d  ===
Ef5    1        t     d  ===
Ef5    1        t     d  ]]]
G4     1        t     u  [[[
G4     1        t     u  ===
Bf4    1        t     u  ===
Bf4    1        t     u  ]]]
measure 8
Ef4    2        s     u  [[     (
F4     2        s     u  ==     )
Ef4    2        s     u  ==     (
F4     2        s     u  ]]     )
Ef4    2        s     u  [[     (
F4     2        s     u  ==     )
Ef4    2        s     u  ==     (
F4     2        s     u  ]]     )
Ef4    8        q     u
rest   8        q
measure 9
Ef4    2        s     u  [[     (
F4     2        s     u  ==     )
Ef4    2        s     u  ==     (
F4     2        s     u  ]]     )
Ef4    2        s     u  [[     (
F4     2        s     u  ==     )
Ef4    2        s     u  ==     (
F4     2        s     u  ]]     )
Gf4   16        h     u
measure 10
rest   8        q
rest   3        s.
F4     1        t     u  [[/
F4     3        s.    u  ==
F4     1        t     u  ]]\
D5     3        s.    d  [[
D5     1        t     d  ==\
D5     3        s.    d  ==
D5     1        t     d  ]]\
D5     3        s.    d  [[
D5     1        t     d  ==\
D5     3        s.    d  ==
D5     1        t     d  ]]\
measure 11
Ef5    8        q     d
rest   8        q
rest  16        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-05/2} [KHM:1336091234]
TIMESTAMP: DEC/26/2001 [md5sum:2a19d18473c4e5c8cf75c4d7806a1dba]
04/12/90 E. Correia
WK#:56        MV#:2,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino III
1 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Larghetto
F4     4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
F4     4        e     u  ]
Gf4    4        e     u  [
Gf4    4        e     u  =
Gf4    4        e     u  =
Gf4    4        e     u  ]
measure 2
F4     4        e     u  [
F4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  =
C5     4        e     d  ]
measure 3
C5     4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  =
A4     4        e     d  ]
Bf4    4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
F4     4        e     u  ]
measure 4
F4     8        q     u         &p
rest   8        q
rest  16        h
measure 5
rest  16        h
C5     8        q     d
rest   8        q
measure 6
F5     1        t     d  [[[    &f
F5     1        t     d  ===
Df5    1        t     d  ===
Df5    1        t     d  ]]]
Bf4    1        t     d  [[[
Bf4    1        t     d  ===
Df5    1        t     d  ===
Df5    1        t     d  ]]]
F4     1        t     u  [[[
F4     1        t     u  ===
Bf4    1        t     u  ===
Bf4    1        t     u  ]]]
F4     1        t     u  [[[
F4     1        t     u  ===
Ef4    1        t     u  ===
Ef4    1        t     u  ]]]
D4     4        e     u  [      +
D4     4        e     u  =
D4     4        e     u  =
D4     4        e     u  ]
measure 7
D4     8        q     u
rest   8        q
G5     1        t     d  [[[
G5     1        t     d  ===
Ef5    1        t     d  ===
Ef5    1        t     d  ]]]
Bf4    1        t     d  [[[
Bf4    1        t     d  ===
Ef5    1        t     d  ===
Ef5    1        t     d  ]]]
G4     1        t     u  [[[
G4     1        t     u  ===
Bf4    1        t     u  ===
Bf4    1        t     u  ]]]
Ef4    1        t     u  [[[
Ef4    1        t     u  ===
G4     1        t     u  ===
G4     1        t     u  ]]]
measure 8
Bf3    2        s     u  [[     (
C4     2        s     u  ==     )
Bf3    2        s     u  ==     (
C4     2        s     u  ]]     )
Bf3    2        s     u  [[     (
C4     2        s     u  ==     )
Bf3    2        s     u  ==     (
C4     2        s     u  ]]     )
Bf3    8        q     u
rest   8        q
measure 9
C4     2        s     u  [[     (
D4     2        s     u  ==     )
C4     2        s     u  ==     (
D4     2        s     u  ]]     )
C4     2        s     u  [[     (
D4     2        s     u  ==     )
C4     2        s     u  ==     (
D4     2        s     u  ]]     )
Ef4   16        h     u
measure 10
rest   8        q
rest   3        s.
D4     1        t     u  [[/
D4     3        s.    u  ==
D4     1        t     u  ]]\
F4     3        s.    u  [[
F4     1        t     u  ==\
F4     3        s.    u  ==
F4     1        t     u  ]]\
F4     3        s.    u  [[
F4     1        t     u  ==\
F4     3        s.    u  ==
F4     1        t     u  ]]\
measure 11
G4     8        q     u
rest   8        q
rest  16        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-05/3} [KHM:1336091234]
TIMESTAMP: DEC/26/2001 [md5sum:c5b63229f48607fa3b36da1c27f2e478]
04/12/90 E. Correia
WK#:56        MV#:2,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
1 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:13   D:Larghetto
Df4    4        e     d  [
Df4    4        e     d  =
Df4    4        e     d  =
Df4    4        e     d  ]
Ef4    4        e     d  [
Ef4    4        e     d  =
Ef4    4        e     d  =
Ef4    4        e     d  ]
measure 2
Df4    4        e     d  [
Df4    4        e     d  =
Ef4    4        e     d  =
Ef4    4        e     d  ]
F4     4        e     d  [
F4     4        e     d  =
F4     4        e     d  =
Bf4    4        e     d  ]
measure 3
A4     4        e     d  [
Ef4    4        e     d  =
F4     4        e     d  =
Ef4    4        e     d  ]
Df4    4        e     d  [
Df4    4        e     d  =
Df4    4        e     d  =
Df4    4        e     d  ]
measure 4
Df4    8        q     d         &p
rest   8        q
rest  16        h
measure 5
rest  16        h
F4     8        q     d
rest   8        q
measure 6
Df4    2        s     d  [[     &f
F4     2        s     d  ==
F4     2        s     d  ==
Bf4    2        s     d  ]]
Df4    2        s     d  [[
F4     2        s     d  ==
Bf3    2        s     d  ==
C4     2        s     d  ]]
D4     4        e     d  [
D4     4        e     d  =
D4     4        e     d  =
D4     4        e     d  ]
measure 7
D4     8        q     d
rest   8        q
Ef4    2        s     d  [[
Bf4    2        s     d  ==
G4     2        s     d  ==
Bf4    2        s     d  ]]
Ef4    2        s     d  [[
G4     2        s     d  ==
Bf3    2        s     d  ==
Ef4    2        s     d  ]]
measure 8
Bf3    2        s     u  [[     (
C4     2        s     u  ==     )
Bf3    2        s     u  ==     (
C4     2        s     u  ]]     )
Bf3    2        s     u  [[     (
C4     2        s     u  ==     )
Bf3    2        s     u  ==     (
C4     2        s     u  ]]     )
Bf3    8        q     u
rest   8        q
measure 9
C4     2        s     d  [[     (
D4     2        s     d  ==     )
C4     2        s     d  ==     (
D4     2        s     d  ]]     )
C4     2        s     d  [[     (
D4     2        s     d  ==     )
C4     2        s     d  ==     (
D4     2        s     d  ]]     )
C4    16        h     u
measure 10
rest   8        q
rest   3        s.
Bf3    1        t     u  [[/
Bf3    3        s.    u  ==
Bf3    1        t     u  ]]\
Bf3    3        s.    u  [[
Bf3    1        t     u  ==\
Bf3    3        s.    u  ==
Bf3    1        t     u  ]]\
Bf3    3        s.    u  [[
Bf3    1        t     u  ==\
Bf3    3        s.    u  ==
Bf3    1        t     u  ]]\
measure 11
Bf3    8        q     u
rest   8        q
rest  16        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-05/4} [KHM:1336091234]
TIMESTAMP: DEC/26/2001 [md5sum:d491447ce5d8c41114b98739695fd598]
04/12/90 E. Correia
WK#:56        MV#:2,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Tenore
1 72 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:4   T:1/1   C:34   D:Larghetto
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest   4        q
rest   2        e
F4     2        e     u                    All
Df5    4        q     d                    they
rest   2        e
Df5    1        s     d  [[                that_
C5     1        s     d  ]]                _
measure 5
A4     2        e     u                    see
A4     2        e     u                    him,
rest   4        q
rest   4        q
Ef5    2        e     d                    laugh
Ef5    1        s     d                    him
Df5    1        s     d                    to
measure 6
Bf4    4        q     u                    scorn;
rest   4        q
rest   4        q
rest   2        e
D5     2        e     d         +          they
measure 7
F5     4        q     d                    shoot
D5     2        e     d                    out
Bf4    2        e     u                    their
Ef5    4        q     d                    lips,
rest   4        q
measure 8
rest   8        h
rest   2        e
Bf4    2        e     u                    and
Ef5    2        e     d                    shake
Bf4    2        e     u                    their
measure 9
C5     4        q     d                    heads,
rest   4        q
rest   4        q
Ef5    4-       q     d        -           say-
measure 10
Ef5    4        q     d                    -
Bf4    4        q     u                    ing,
rest   8        h
measure 11
rest  16
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-05/5} [KHM:1336091234]
TIMESTAMP: DEC/26/2001 [md5sum:aa17419e7949e380ef87997a7f9cd57d]
04/12/90 E. Correia
WK#:56        MV#:2,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
1 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:22   D:Larghetto
f1              f
Bf2    4        e     u  [
Bf2    4        e     u  =
Bf2    4        e     u  =
Bf2    4        e     u  ]
f2              6f 4
Bf2    4        e     u  [
Bf2    4        e     u  =
Bf2    4        e     u  =
Bf2    4        e     u  ]
measure 2
Bf2    4        e     u  [
Bf2    4        e     u  =
f1              6n
C3     4        e     u  =
C3     4        e     u  ]
Df3    4        e     d  [
Df3    4        e     d  =
Df3    4        e     d  =
Ef3    4        e     d  ]
measure 3
F3     4        e     u  [
Gf3    4        e     u  =
F3     4        e     u  =
F2     4        e     u  ]
Bf2    4        e     u  [
Bf2    4        e     u  =
Bf2    4        e     u  =
Bf2    4        e     u  ]
measure 4
Bf2   32        w     u         &p
measure 5
f1              6n
C3    16        h     u
f2              7 n
F2     8        q     u
rest   8        q
measure 6
Bf2    2        s     u  [[     &f
Bf2    2        s     u  ==
Bf2    2        s     u  ==
Bf2    2        s     u  ]]
Bf3    2        s     d  [[
Bf3    2        s     d  ==
Bf3    2        s     d  ==
Bf3    2        s     d  ]]
f2              4+ 2
Af3    4        e     d  [
Af3    4        e     d  =
Af3    4        e     d  =
Af3    4        e     d  ]
measure 7
Af3    8        q     d
rest   8        q
G3     2        s     d  [[
G3     2        s     d  ==
G3     2        s     d  ==
G3     2        s     d  ]]
G3     2        s     d  [[
G3     2        s     d  ==
G3     2        s     d  ==
G3     2        s     d  ]]
measure 8
G3     2        s     d  [[     (
Af3    2        s     d  ==     )
G3     2        s     d  ==     (
Af3    2        s     d  ]]     )
G3     2        s     d  [[     (
Af3    2        s     d  ==     )
G3     2        s     d  ==     (
Af3    2        s     d  ]]     )
G3     8        q     d
rest   8        q
measure 9
Af3    4        e     u  [
Af2    4        e     u  =
Af2    4        e     u  =
Af2    4        e     u  ]
A2    16        h     u
measure 10
rest   8        q
rest   3        s.
Bf2    1        t     u  [[/
Bf2    3        s.    u  ==
Bf2    1        t     u  ]]\
Bf2    3        s.    u  [[
Bf2    1        t     u  ==\
Bf2    3        s.    u  ==
Bf2    1        t     u  ]]\
Bf2    3        s.    u  [[
Bf2    1        t     u  ==\
Bf2    3        s.    u  ==
Bf2    1        t     u  ]]\
measure 11
Ef2    8        q     u
rest   8        q
rest  16        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
