&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/1} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:f4ca7c5546e7c3a1d1695df1b587de11]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:4   D:Allegro e staccato
G4     2        e     u  [      i
D4     2        e     u  ]      i
E4     2        e     u  [      i
B3     2        e     u  ]      i
C4     2        e     u  [      i
G3     2        e     u  ]      i
measure 2
A3     2        e     u  [
E4     2        e     u  ]
F4     2        e     u  [
E4     2        e     u  ]
D4     1        s     u  [[
E4     1        s     u  =]
F4     2        e     u  ]
measure 3
E4     4        q     u
rest   4        q
rest   4        q
measure 4
rest  12
measure 5
D6     2        e     d  [      &i
A5     2        e     d  =      &i
B5     2        e     d  =      &i
F#5    2        e     d  =      &i
G5     2        e     d  =
A5     2        e     d  ]
measure 6
B5     1        s     d  [[
C6     1        s     d  =]
D6     2        e     d  ]
G5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  ]
measure 7
C5     1        s     d  [[
D5     1        s     d  =]
E5     2        e     d  ]
D5     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C#5    2        e     d  ]
measure 8
D5     4        q     d
rest   4        q
rest   4        q
measure 9
A5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
C#5    2        e     d  =
D5     2        e     d  =
A4     2        e     d  ]
measure 10
F#4    4        q     u
rest   4        q
rest   4        q
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
D5     4        q     d         i
B4     4        q     d         i
G4     4        q     u         i
measure 16
E4     2        e     u  [
C5     2-       e     u  ]     -
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ]]
A4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 17
F#4    2        e     u  [
D5     2-       e     u  ]     -
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
measure 18
B5     4        q     d         i
D6     4        q     d         i
A5     4        q     d         i
measure 19
B5     4        q     d         i
D5     4        q     d         i
rest   2        e
D5     2        e     d
measure 20
E5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
A4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 21
A4     2        e     d  [
A5     2        e     d  ]
D6     6        q.    d
C6     2        e     d         +
measure 22
B5     2        e     d  [
C6     2        e     d  ]
A5     6        q.    d         &t
A5     2        e     d
measure 23
B5     4        q     d
rest   4        q
rest   4        q
measure 24
G5     2        e     d  [      &i
D5     2        e     d  =      &i
E5     2        e     d  =      &i
B4     2        e     d  ]      &i
C5     4        q     d
measure 25
rest   4        q
C6     2        e     d  [      &i
G5     2        e     d  =      &i
A5     2        e     d  =      &i
E5     2        e     d  ]      &i
measure 26
F5     4        q     d
rest   4        q
rest   4        q
measure 27
F5     2        e     d  [
C5     2        e     d  =
D5     2        e     d  =
A4     2        e     d  =
Bf4    2        e     d  =
G4     2        e     d  ]
measure 28
A4     2        e     u  [
G4     2        e     u  ]
F4     4        q     u
rest   4        q
measure 29
G5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 30
E5     1        s     d  [[
F5     1        s     d  =]
G5     2        e     d  ]
C5     1        s     d  [[
D5     1        s     d  =]
E5     2        e     d  ]
D5     1        s     d  [[
E5     1        s     d  =]
F5     2        e     d  ]
measure 31
E5     4        q     d
C5     2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
F#4    2        e     u  ]
measure 32
B4     4        q     d
rest   4        q
rest   4        q
measure 33
rest  12
measure 34
D6     2        e     d  [
A5     2        e     d  =
B5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  =
D5     2        e     d  ]
measure 35
B4     4        q     d
G5     4        q     d         i
E5     4        q     d         i
measure 36
C5     4        q     d         i
A4     2        e     d  [
F5     2-       e     d  ]     -
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
E5     1        s     d  ]]
measure 37
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F4     1        s     u  ]]
measure 38
E4     2        e     u  [
C5     2-       e     u  ]     -
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 39
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
E4     1        s     u  ]]
D4     1        s     u  [[
E4     1        s     u  ==
D4     1        s     u  ==
C4     1        s     u  ]]
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
A3     1        s     u  ]]
measure 40
G3     4        q     u
rest   4        q
rest   4        q
measure 41
C6     4        q     d         i
A5     4        q     d         i
F5     4        q     d         i
measure 42
D5     2        e     d  [
G5     2-       e     d  ]     -
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
measure 43
C5     2        e     d  [
D5     2        e     d  ]
C5     8        h     d
measure 44
B4     4        q     u
D5     2        e     u  [
A4     2        e     u  =
B4     2        e     u  =
F#4    2        e     u  ]
measure 45
G4     2        e     u  [
D4     2        e     u  =
E4     2        e     u  =
B3     2        e     u  =
C4     2        e     u  =
D4     2        e     u  ]
measure 46
B3     4        q     u
G5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 47
G5     4        q     d
G4     4        q     u
rest   4        q
measure 48
G5     4        q     d         i
E5     4        q     d         i
C5     4        q     d         i
measure 49
A4     2        e     d  [
F5     2-       e     d  ]     -
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
measure 50
B4     2        e     d  [
G5     2-       e     d  ]     -
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
measure 51
C5     1        s     d  [[
B4     1        s     d  ==
A4     1        s     d  ==
B4     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 52
G5     6        q.    d
F5     2        e     d  [      +
E5     2        e     d  =
D5     2        e     d  ]
measure 53
E5     2        e     d  [
F5     2        e     d  ]
D5     8        h     d
measure 54
E5     4        q     d
rest   4        q
rest   4        q
measure 55
rest   4        q
C6     2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
F5     2        e     d  ]
measure 56
E5     2        e     d  [
B4     2        e     d  ]
C5     6        q.    d
C6     2        e     d
measure 57
B5     6        q.    d
G5     2        e     d  [
F5     2        e     d  =
G5     2        e     d  ]
measure 58
E5     2        e     d  [
D5     2        e     d  ]
D5     8        h     d
measure 59
C5     4        q     d
G5     2        e     d  [      &i
D5     2        e     d  =      &i
E5     2        e     d  =      &i
B4     2        e     d  ]      &i
measure 60
C5     4        q     d
C6     2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
measure 61
F5     2        e     d  [
D5     2        e     d  ]
E5     4        q     d
F#5    4        q     d
measure 62
G5     4        q     d
G4     4        q     u
rest   4        q
measure 63
G5     4        q     d
E5     4        q     d
C5     4        q     d
measure 64
A4     2        e     d  [
F5     2-       e     d  ]     -
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
measure 65
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     2        e     d  [
F5     2        e     d  ]
E5     3        e.    d  [      &t
D5     1        s     d  ]\
measure 66
E5     2        e     d  [
F5     2        e     d  ]
D5     6        q.    d         &t
C5     2        e     d
measure 67
C5    12        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/2} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:28ba0e8f16a86b5437eb96bb0b725917]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:4   D:Allegro e staccato
rest   4        q
G5     2        e     d  [      i
D5     2        e     d  ]      i
E5     2        e     d  [      i
B4     2        e     d  ]      i
measure 2
C5     2        e     d  [      i
G4     2        e     d  ]      i
A4     1        s     d  [[
B4     1        s     d  =]
C5     2        e     d  ]
B4     1        s     d  [[
C5     1        s     d  =]
D5     2        e     d  ]
measure 3
G4     4        q     u
C6     2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
measure 4
F5     2        e     d  [
D5     2        e     d  ]
E5     1        s     d  [[
F#5    1        s     d  =]
G5     2        e     d  ]
F#5    1        s     d  [[
G5     1        s     d  =]
A5     2        e     d  ]
measure 5
D5     2        e     u  [
F#4    2        e     u  =
G4     2        e     u  =
D4     2        e     u  =
E4     2        e     u  =
C4     2        e     u  ]
measure 6
D4     4        q     u
rest   4        q
rest   4        q
measure 7
rest  12
measure 8
D6     2        e     d  [
A5     2        e     d  =
B5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  =
E5     2        e     d  ]
measure 9
F#4    4        q     u
A5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
C#5    2        e     d  ]
measure 10
D5     4        q     d
rest   4        q
rest   4        q
measure 11
rest  12
measure 12
A4     4        q     u         i
F#4    4        q     u         i
D4     4        q     u         i
measure 13
B3     2        e     u  [
G4     2-       e     u  ]     -
G4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
E4     1        s     u  [[
F#4    1        s     u  ==
E4     1        s     u  ==
D4     1        s     u  ]]
measure 14
C#4    2        e     u  [
A4     2-       e     u  ]     -
A4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    1        s     u  [[
G4     1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
measure 15
D4     4        q     u
rest   2        e
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  ]
measure 16
E4     4        q     u
rest   2        e
E4     2        e     u  [
E4     2        e     u  =
E4     2        e     u  ]
measure 17
F#4    4        q     u
rest   2        e
F#4    2        e     u  [
F#4    2        e     u  =
F#4    2        e     u  ]
measure 18
G5     4        q     d         i
A5     4        q     d         i
F#5    4        q     d         i
measure 19
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
measure 20
E4     2        e     u  [
C#5    2        e     u  ]
E5     4        q     d
rest   2        e
E5     2        e     d
measure 21
D5     4        q     d
rest   2        e
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  ]
measure 22
G5     2        e     d  [
E5     2        e     d  ]
F#5    6        q.    d
F#5    2        e     d
measure 23
G5     4        q     d
D5     2        e     u  [      &i
A4     2        e     u  =      &i
B4     2        e     u  =      &i
F#4    2        e     u  ]      &i
measure 24
G4     4        q     u
G5     2        e     d  [      &i
D5     2        e     d  =      &i
E5     2        e     d  =      &i
B4     2        e     d  ]      &i
measure 25
C5     4        q     d
rest   4        q
rest   4        q
measure 26
F5     2        e     d  [
C5     2        e     d  =
D5     2        e     d  =
A4     2        e     d  =
Bf4    2        e     d  =
G4     2        e     d  ]
measure 27
A4     4        q     u
rest   4        q
rest   4        q
measure 28
A5     2        e     d  [
E5     2        e     d  =
F5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  =
G5     2        e     d  ]
measure 29
E5     4        q     d
G4     2        e     u  [
D4     2        e     u  =
E4     2        e     u  =
B3     2        e     u  ]
measure 30
C4     2        e     u  [
G3     2        e     u  ]
A3     1        s     u  [[
B3     1        s     u  =]
C4     2        e     u  ]
B3     1        s     u  [[
C4     1        s     u  =]
D4     2        e     u  ]
measure 31
C4     4        q     u
rest   4        q
rest   4        q
measure 32
G5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  =
A4     2        e     d  ]
measure 33
B4     2        e     u  [
F#4    2        e     u  =
G4     2        e     u  =
D4     2        e     u  =
E4     2        e     u  =
C4     2        e     u  ]
measure 34
D4     4        q     u
D6     2        e     d  [
A5     2        e     d  =
B5     2        e     d  =
F#5    2        e     d  ]
measure 35
G5     4        q     d
rest   4        q
rest   4        q
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
G5     4        q     d         i
E5     4        q     d         i
C5     4        q     d         i
measure 41
A4     2        e     d  [
F5     2-       e     d  ]     -
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
measure 42
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     4        q     u
rest   2        e
G5     2        e     d
measure 43
E5     1        s     d  [[
F#5    1        s     d  =]
G5     2        e     d  ]
G5     4        q     d
F#5    4        q     d
measure 44
G5     4        q     d
rest   4        q
D5     2        e     d  [
A4     2        e     d  ]
measure 45
B4     2        e     u  [
F#4    2        e     u  ]
G4     4        q     u
rest   4        q
measure 46
G5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 47
B4     4        q     d
D4     4        q     u
B3     4        q     u
measure 48
G3     4        q     u
G4     4        q     u
E4     4        q     u
measure 49
C4     2        e     u  [
A3     2        e     u  ]
A4     6        q.    u
A4     2        e     u
measure 50
G4     4        q     u
rest   2        e
B4     2        e     u  [
B4     2        e     u  =
B4     2        e     u  ]
measure 51
A4     4        q     u
rest   2        e
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
measure 52
G4     6        q.    u
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  ]
measure 53
G4     2        e     u  [
A4     2        e     u  ]
G4     8        h     u
measure 54
G4     4        q     u
C5     2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
F4     2        e     u  ]
measure 55
G4     2        e     u  [
F4     2        e     u  =
E4     2        e     u  =
C5     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
measure 56
C5     2        e     d  [
D5     2        e     d  ]
E5     6        q.    d
A5     2        e     d
measure 57
D5     6        q.    d
B4     2        e     d  [
C5     2        e     d  =
D5     2        e     d  ]
measure 58
C5     4        q     d
C5     4        q     d
B4     2        e     u  [
F4     2        e     u  ]
measure 59
E4     2        e     u  [
B3     2        e     u  ]
C4     4        q     u
G5     2        e     d  [      &i
D5     2        e     d  ]      &i
measure 60
E5     2        e     d  [      &i
B4     2        e     d  ]      &i
C5     6        q.    d
C5     2        e     d
measure 61
A4     2        e     u  [
B4     2        e     u  =
G4     2        e     u  =
C5     2        e     u  ]
A4     4        q     u
measure 62
D5     4        q     d
B4     4        q     d
G4     4        q     u
measure 63
E4     2        e     u  [
C5     2-       e     u  ]     -
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ]]
A4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 64
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
E4     1        s     u  ]]
D4     2        e     u  [
A4     2        e     u  ]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
E5     1        s     d  ]]
measure 65
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     3        e.    u  [
B4     1        s     u  ]\
measure 66
C5     8        h     d
B4     4        q     d
measure 67
C5    12        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/3} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:76f90cd4fd00ae403fd4609e8d1da946]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:13   D:Allegro e staccato
G4     2        e     d  [      i
D4     2        e     d  ]      i
E4     2        e     d  [      i
B3     2        e     d  ]      i
C4     2        e     u  [      i
G3     2        e     u  ]      i
measure 2
A3     2        e     d  [
E4     2        e     d  ]
F4     2        e     d  [
E4     2        e     d  ]
D4     1        s     d  [[
E4     1        s     d  =]
F4     2        e     d  ]
measure 3
E4     4        q     d
rest   2        e
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 4
C4     2        e     d  [
B3     2        e     d  =
G4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  =
F#4    2        e     d  ]
measure 5
G4     4        q     d
G4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
C4     2        e     d  ]
measure 6
D4     2        e     u  [
F#3    2        e     u  ]
B3     1        s     u  [[
C4     1        s     u  =]
D4     2        e     u  ]
G3     4        q     u
measure 7
rest  12
measure 8
A4     2        e     d  [
F#4    2        e     d  ]
B4     1        s     d  [[
C#5    1        s     d  =]
D5     2        e     d  ]
B3     2        e     u  [
C#4    2        e     u  ]
measure 9
D4     4        q     d
D4     4        q     d
rest   4        q
measure 10
D4     4        q     d         i
B3     4        q     u         i
G3     4        q     u         i
measure 11
E3     2        e     u  [
C4     2-       e     u  ]     -
C4     1        s     u  [[
D4     1        s     u  ==
C4     1        s     u  ==
B3     1        s     u  ]]
A3     1        s     u  [[
B3     1        s     u  ==
A3     1        s     u  ==
G3     1        s     u  ]]
measure 12
F#3    2        e     u  [
D4     2-       e     u  ]     -
D4     1        s     d  [[
E4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
B3     1        s     u  [[
C4     1        s     u  ==
B3     1        s     u  ==
A3     1        s     u  ]]
measure 13
G3     4        q     u
rest   2        e
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  ]
measure 14
A3     4        q     u
rest   2        e
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  ]
measure 15
B3     4        q     u
rest   2        e
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  ]
measure 16
C4     4        q     d
rest   2        e
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 17
D4     4        q     d
rest   2        e
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
measure 18
D5     4        q     d         &i
D4     4        q     d         &i
D5     4        q     d         &i
measure 19
G4     4        q     d
G4     4        q     d
B4     4        q     d
measure 20
A4     4        q     d
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 21
D4     4        q     d
rest   2        e
A4     2        e     d  [
G4     2        e     d  =
D4     2        e     d  ]
measure 22
D4     2        e     d  [
E4     2        e     d  ]
A3     4        q     u
D4     4        q     d
measure 23
D4     2        e     u  [      &i
A3     2        e     u  =      &i
B3     2        e     u  =      &i
F#3    2        e     u  ]      &i
G3     4        q     u
measure 24
rest   4        q
rest   4        q
G4     2        e     d  [
D4     2        e     d  ]
measure 25
E4     1        s     d  [[
F4     1        s     d  =]
G4     2        e     d  ]
C4     6        q.    d
C4     2        e     d
measure 26
F4     6        q.    d
F4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  ]
measure 27
F4     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
measure 28
F4     4        q     d
rest   4        q
rest   4        q
measure 29
rest   4        q
G4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
B3     2        e     d  ]
measure 30
C4     2        e     u  [
G3     2        e     u  ]
A3     1        s     u  [[
B3     1        s     u  =]
C4     2        e     u  ]
B3     1        s     d  [[
C4     1        s     d  =]
D4     2        e     d  ]
measure 31
C4     4        q     d
E4     4        q     d
D4     4        q     d
measure 32
D4     4        q     d
G4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
F#4    2        e     d  ]
measure 33
G4     4        q     d
rest   2        e
G4     2        e     d
G4     2        e     d  [
A4     1        s     d  =[
F#4    1        s     d  ]]
measure 34
B4     4        q     d
G4     4        q     d
rest   4        q
measure 35
G4     4        q     d
E4     4        q     d
C4     4        q     d
measure 36
A3     2        e     d  [
F4     2-       e     d  ]     -
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
E4     1        s     d  ]]
D4     1        s     d  [[
E4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
measure 37
B3     2        e     d  [
G4     2-       e     d  ]     -
G4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ]]
E4     1        s     d  [[
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
measure 38
E4     1        s     d  [[
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
C4     2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 39
Bf4    2        e     d  [
D4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  =
Bf4    2        e     d  =
D5     2        e     d  ]
measure 40
C5     2        e     d  [
G4     2-       e     d  ]     -
G4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ]]
E4     1        s     d  [[
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
measure 41
C4     4        q     d
rest   2        e
D4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 42
B4     4        q     d
rest   2        e
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
measure 43
E4     2        e     d  [
B3     2        e     d  ]
C4     8        h     d
measure 44
D4     4        q     d
G3     4        q     u
rest   4        q
measure 45
rest   4        q
G3     2        e     u  [
D3     2        e     u  =
E3     2        e     u  =
F#3    2        e     u  ]
measure 46
G3     4        q     u
rest   4        q
rest   4        q
measure 47
D4     4        q     d
B3     4        q     u
G3     4        q     u
measure 48
E3     4        q     u
C4     6        q.    d
C4     2        e     d
measure 49
C4     2        e     d  [
D4     2        e     d  ]
D4     6        q.    d
D4     2        e     d
measure 50
D4     2        e     d  [
E4     2        e     d  ]
E4     6        q.    d
E4     2        e     d
measure 51
E4     4        q     d
rest   2        e
E4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 52
D4     6        q.    d
D4     2        e     d  [
C4     2        e     d  =
D4     2        e     d  ]
measure 53
C4     2        e     d  [
C4     2        e     d  ]
B3     8        h     u
measure 54
C5     2        e     d  [
G4     2        e     d  =
A4     2        e     d  =
E4     2        e     d  =
F4     2        e     d  =
D4     2        e     d  ]
measure 55
E4     2        e     d  [
D4     2        e     d  ]
C4     6        q.    d
F4     2        e     d
measure 56
G4     4        q     d
G4     2        e     d  [
F4     2        e     d  =
G4     2        e     d  =
D4     2        e     d  ]
measure 57
D4     6        q.    d
D4     2        e     d  [
C4     2        e     d  =
G4     2        e     d  ]
measure 58
G4     2        e     d  [
A4     2        e     d  ]
G4     4        q     d
G4     4        q     d
measure 59
G4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
B3     2        e     d  ]
C4     4        q     d
measure 60
G4     4        q     d
E4     4        q     d
C4     4        q     d
measure 61
F4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  =
D4     2        e     d  ]
measure 62
D4     4        q     d
D5     4        q     d
B4     4        q     d
measure 63
G4     4        q     d
G4     4        q     d
E4     4        q     d
measure 64
C4     4        q     d
A4     6        q.    d
A4     2        e     d
measure 65
D4     6        q.    d
G4     2        e     d
C4     4-       q     d        -
measure 66
C4     2        e     d  [
A4     2        e     d  ]
D4     4        q     d
G4     4        q     d
measure 67
E4    12        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/4} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:c369230f5f99bb5afa8a9c5345f51256]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:4   D:Allegro e staccato
rest   4        q
G5     2        e     d                    Let
D5     2        e     d                    us
E5     2        e     d                    break
B4     2        e     d                    their
measure 2
C5     2        e     d                    bonds
G4     2        e     u                    a-
A4     1        s     u  [[                sun-
B4     1        s     u  ]]                -
C5     2        e     d                    der,
B4     1        s     d  [[                let_
C5     1        s     d  ]]                _
D5     2        e     d                    us
measure 3
G4     4        q     u                    break,
rest   4        q
rest   4        q
measure 4
rest  12
measure 5
D5     2        e     d                    let
A4     2        e     u                    us
B4     2        e     d                    break
F#4    2        e     u                    their
G4     2        e     u                    bonds
A4     2        e     u                    a-
measure 6
B4     1        s     d  [[                sun-
C5     1        s     d  =]                -
D5     2        e     d  ]                 -
G4     4        q     u                    der,
rest   4        q
measure 7
rest  12
measure 8
D5     2        e     d                    let
A4     2        e     u                    us
B4     2        e     d                    break
D5     2        e     d                    their
G5     2        e     d                    bonds
E5     2        e     d                    a-
measure 9
F#5    3        e.    d  [                 sun-
E5     1        s     d  ]\                -
D5     4        q     d                    der,
rest   4        q
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
D5     4        q     d                    and
B4     4        q     d                    cast
G4     4        q     u                    a-
measure 16
E4     2        e     u  [                 way_
C5     2-       e     u  ]     -           _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
B4     1        s     d  ]]                _
A4     1        s     u  [[                _
B4     1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
measure 17
F#4    2        e     u  [                 _
D5     2-       e     u  ]     -           _
D5     1        s     d  [[                _
E5     1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
C5     1        s     d  ==                _
B4     1        s     d  ==                _
A4     1        s     d  =]                _
measure 18
B4     2        e     d  ]                 _
G4     2        e     u                    their
D5     6        q.    d                    yokes
D5     2        e     d                    from
measure 19
D5     2        e     d                    us,
B4     2        e     d                    and
B4     6        q.    d                    cast
B4     2        e     d                    a-
measure 20
E5     2        e     d                    way
C#5    2        e     d                    their
C#5    6        q.    d                    yokes
C#5    2        e     d                    from
measure 21
D5     2        e     d                    us,
A4     2        e     u                    and
D5     6        q.    d                    cast
C5     2        e     d         +          a-
measure 22
B4     2        e     d                    way
C5     2        e     d                    their
A4     6        q.    u                    yokes
A4     2        e     u                    from
measure 23
B4     4        q     d                    us.
D5     2        e     d                    Let
A4     2        e     u                    us
B4     2        e     d                    break
F#4    2        e     u                    their
measure 24
G4     4        q     u                    bonds,
G5     2        e     d                    let
D5     2        e     d                    us
E5     2        e     d                    break
B4     2        e     d                    their
measure 25
C5     4        q     d                    bonds,
rest   4        q
rest   4        q
measure 26
rest  12
measure 27
F5     2        e     d                    let
C5     2        e     d                    us
D5     2        e     d                    break
A4     2        e     u                    their
Bf4    2        e     d                    bonds
G4     2        e     u                    a-
measure 28
A4     2        e     u  [                 sun-
G4     2        e     u  ]                 -
F4     4        q     u                    der,
rest   4        q
measure 29
G5     2        e     d                    let
D5     2        e     d                    us
E5     2        e     d                    break
B4     2        e     d                    their
C5     2        e     d                    bonds
D5     2        e     d                    a-
measure 30
E5     1        s     d  [[                sun-
F5     1        s     d  ]]                -
G5     2        e     d                    der,
C5     1        s     d  [[                let_
D5     1        s     d  ]]                _
E5     2        e     d                    us,
D5     1        s     d  [[                let_
E5     1        s     d  ]]                _
F5     2        e     d                    us
measure 31
E5     4        q     d                    break,
rest   4        q
rest   4        q
measure 32
G5     2        e     d                    let
D5     2        e     d                    us
E5     2        e     d                    break
B4     2        e     d                    their
C5     2        e     d                    bonds
A4     2        e     u                    a-
measure 33
B4     2        e     u  [                 sun-
A4     2        e     u  ]                 -
G4     2        e     u                    der,
G4     2        e     u                    their
G4     2        e     u                    bonds
A4     2        e     u                    a-
measure 34
B4     4        q     d                    sun-
B4     4        q     d                    der,
rest   4        q
measure 35
rest   4        q
G5     4        q     d                    and
E5     4        q     d                    cast
measure 36
C5     4        q     d                    a-
A4     2        e     d  [                 way_
F5     2-       e     d  ]     -           _
F5     1        s     d  [[                _
G5     1        s     d  ==                _
F5     1        s     d  ==                _
E5     1        s     d  ]]                _
measure 37
D5     1        s     d  [[                _
E5     1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
C5     1        s     d  ==                _
B4     1        s     d  ==                _
A4     1        s     d  ]]                _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
F4     1        s     u  ]]                _
measure 38
E4     2        e     u  [                 _
C5     2-       e     u  ]     -           _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
A4     1        s     u  [[                _
Bf4    1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
measure 39
F4     4        q     u                    _
rest   2        e
F4     2        e     u                    their
Bf4    2        e     d                    yokes
D5     2        e     d                    from
measure 40
C5     4        q     d                    us,
rest   2        e
G4     2        e     u                    and
G4     2        e     u                    cast
G4     2        e     u                    a-
measure 41
A4     4        q     u                    way
rest   2        e
A4     2        e     u                    their
A4     2        e     u                    yokes
A4     2        e     u                    from
measure 42
B4     4        q     d                    us,
rest   2        e
B4     2        e     d                    and
B4     2        e     d                    cast
B4     2        e     d                    a-
measure 43
C5     2        e     d                    way
D5     2        e     d                    their
C5     8        h     d                    yokes
measure 44
B4     4        q     d                    from
B4     4        q     d                    us.
rest   4        q
measure 45
rest  12
measure 46
G5     2        e     d                    Let
D5     2        e     d                    us
E5     2        e     d                    break
B4     2        e     d                    their
C5     2        e     d                    bonds
D5     2        e     d                    a-
measure 47
B4     3        e.    u  [                 sun-
A4     1        s     u  ]\                -
G4     4        q     u                    der,
rest   4        q
measure 48
G5     4        q     d                    and
E5     4        q     d                    cast
C5     4        q     d                    a-
measure 49
A4     2        e     d  [                 way,_
F5     2-       e     d  ]     -           _
F5     1        s     d  [[                _
G5     1        s     d  ==                _
F5     1        s     d  ==                _
E5     1        s     d  ]]                _
D5     1        s     d  [[                _
E5     1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
measure 50
B4     2        e     d  [                 _
G5     2-       e     d  ]     -           _
G5     1        s     d  [[                _
A5     1        s     d  ==                _
G5     1        s     d  ==                _
F5     1        s     d  ]]                _
E5     1        s     d  [[                _
F5     1        s     d  ==                _
E5     1        s     d  ==                _
D5     1        s     d  ]]                _
measure 51
C5     1        s     d  [[                _
B4     1        s     d  ==                _
A4     1        s     d  ==                _
B4     1        s     d  ]]                _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
E5     1        s     d  [[                _
F#5    1        s     d  ==                _
E5     1        s     d  ==                _
F#5    1        s     d  ]]                _
measure 52
G5     6        q.    d                    _
F5     2        e     d         +          and
E5     2        e     d                    cast
D5     2        e     d                    a-
measure 53
E5     2        e     d                    way
F5     2        e     d                    their
D5     8        h     d                    yokes
measure 54
E5     4        q     d                    from
E5     4        q     d                    us;
rest   4        q
measure 55
rest   4        q
C5     2        e     d                    let
G4     2        e     u                    us
A4     2        e     u                    break
B4     2        e     d                    their
measure 56
C5     2        e     d                    bonds,
D5     2        e     d                    and
E5     6        q.    d                    cast
D5     1        s     d  [[                a-
C5     1        s     d  ]]                -
measure 57
B4     6        q.    d                    way,
G5     2        e     d                    and
F5     2        e     d                    cast
G5     2        e     d                    a-
measure 58
E5     2        e     d                    way
F5     2        e     d                    their
D5     8        h     d                    yokes
measure 59
C5     4        q     d                    from
C5     4        q     d                    us.
rest   4        q
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/5} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:dd67bf8d9b4c310ed87be5b7c2e91620]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:4   D:Allegro e staccato
rest  12
measure 2
rest  12
measure 3
rest   4        q
C5     2        e     d                    Let
G4     2        e     u                    us
A4     2        e     u                    break
E4     2        e     u                    their
measure 4
F4     2        e     u                    bonds
D4     2        e     u                    a-
E4     1        s     u  [[                sun-
F#4    1        s     u  ]]                -
G4     2        e     u                    der,
F#4    1        s     u  [[                let_
G4     1        s     u  ]]                _
A4     2        e     u                    us
measure 5
D4     4        q     u                    break,
rest   4        q
rest   4        q
measure 6
rest   4        q
G4     2        e     u                    let
D4     2        e     u                    us
E4     2        e     u                    break
B3     2        e     u                    their
measure 7
C4     1        s     u  [[                bonds_
D4     1        s     u  =]                _
E4     2        e     u  =                 _
D4     2        e     u  ]                 _
C4     2        e     u                    a-
B3     2        e     u                    sun-
C#4    2        e     u                    der,
measure 8
D4     2        e     u                    let
D4     2        e     u                    us
D4     2        e     u                    break
F#4    2        e     u                    their
G4     2        e     u                    bonds
A4     2        e     u                    a-
measure 9
A4     3        e.    u  [                 sun-
G4     1        s     u  ]\                -
F#4    4        q     u                    der,
rest   4        q
measure 10
rest  12
measure 11
rest  12
measure 12
A4     4        q     u                    and
F#4    4        q     u                    cast
D4     4        q     u                    a-
measure 13
B3     2        e     u  [                 way_
G4     2-       e     u  ]     -           _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
F#4    1        s     u  ]]                _
E4     1        s     u  [[                _
F#4    1        s     u  ==                _
E4     1        s     u  ==                _
D4     1        s     u  ]]                _
measure 14
C#4    2        e     u  [                 _
A4     2-       e     u  ]     -           _
A4     1        s     u  [[                _
B4     1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
F#4    1        s     u  [[                _
G4     1        s     u  ==                _
F#4    1        s     u  ==                _
E4     1        s     u  ]]                _
measure 15
D4     4        q     u                    _
rest   2        e
D4     2        e     u                    their
D4     2        e     u                    yokes
D4     2        e     u                    from
measure 16
E4     4        q     u                    us,
rest   2        e
E4     2        e     u                    and
E4     2        e     u                    cast
E4     2        e     u                    a-
measure 17
F#4    4        q     u                    way
rest   2        e
F#4    2        e     u                    their
F#4    2        e     u                    yokes
F#4    2        e     u                    from
measure 18
G4     4        q     u                    us,
rest   2        e
A4     2        e     u                    and
F#4    2        e     u                    cast
F#4    2        e     u                    a-
measure 19
G4     4        q     u                    way,
rest   2        e
G4     2        e     u                    and
G4     2        e     u                    cast
G4     2        e     u                    a-
measure 20
A4     4        q     u                    way
rest   2        e
A4     2        e     u                    their
A4     2        e     u                    yokes
A4     2        e     u                    from
measure 21
A4     4        q     u                    us,
rest   2        e
F#4    2        e     u                    and
G4     2        e     u                    cast
A4     2        e     u                    a-
measure 22
G4     2        e     u                    way
G4     2        e     u                    their
F#4    6        q.    u                    yokes
F#4    2        e     u                    from
measure 23
G4     4        q     u                    us.
rest   4        q
rest   4        q
measure 24
G4     2        e     u                    Let
D4     2        e     u                    us
E4     2        e     u                    break
B3     2        e     u                    their
C4     2        e     u                    bonds
D4     2        e     u                    a-
measure 25
E4     1        s     u  [[                sun-
F4     1        s     u  ]]                -
G4     2        e     u                    der,
C4     2        e     u                    let
G4     2        e     u                    us
A4     2        e     u                    break
E4     2        e     u                    their
measure 26
F4     4        q     u                    bonds,
rest   4        q
rest   4        q
measure 27
rest  12
measure 28
A4     2        e     u                    let
E4     2        e     u                    us
F4     2        e     u                    break
C4     2        e     u                    their
D4     2        e     u                    bonds
G4     2        e     u                    a-
measure 29
E4     2        e     u  [                 sun-
F4     2        e     u  ]                 -
G4     4        q     u                    der,
rest   4        q
measure 30
rest  12
measure 31
rest   4        q
C5     2        e     d                    let
G4     2        e     u                    us
A4     2        e     u                    break
F#4    2        e     u                    their
measure 32
D4     4        q     u                    bonds,
G4     2        e     u                    let
D4     2        e     u                    us
E4     2        e     u                    break
F#4    2        e     u                    their
measure 33
G4     2        e     u  [      (          bonds,_
F#4    2        e     u  ]                 _
G4     2        e     u         )          _
D4     2        e     u                    their
E4     2        e     u                    bonds
F#4    2        e     u                    a-
measure 34
G4     4        q     u                    sun-
G4     4        q     u                    der,
rest   4        q
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
G4     4        q     u                    and
E4     4        q     u                    cast
C4     4        q     u                    a-
measure 41
A3     2        e     u  [                 way_
F4     2-       e     u  ]     -           _
F4     1        s     u  [[                _
G4     1        s     u  ==                _
F4     1        s     u  ==                _
E4     1        s     u  ]]                _
D4     1        s     u  [[                _
E4     1        s     u  ==                _
D4     1        s     u  ==                _
C4     1        s     u  ]]                _
measure 42
B3     2        e     u  [                 _
G4     2-       e     u  ]     -           _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
F4     1        s     u  ]]                _
E4     1        s     u  [[                _
F4     1        s     u  ==                _
E4     1        s     u  ==                _
D4     1        s     u  =]                _
measure 43
C4     2        e     u  ]                 _
G4     2        e     u                    their
G4     4        q     u         (          yokes_
F#4    4        q     u         )          _
measure 44
G4     4        q     u                    from
G4     4        q     u                    us.
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
G4     2        e     u                    Let
D4     2        e     u                    us
E4     2        e     u                    break
F#4    2        e     u                    their
measure 47
G4     4        q     u                    bonds,
rest   4        q
rest   4        q
measure 48
rest   4        q
G4     4        q     u                    and
E4     4        q     u                    cast
measure 49
C4     2        e     u  [                 a-
A3     2        e     u  ]                 -
A4     6        q.    u                    way
A4     2        e     u                    their
measure 50
G4     4        q     u                    yokes,
rest   2        e
B4     2        e     u                    their
B4     2        e     u                    yokes
B4     2        e     u                    from
measure 51
A4     4        q     u                    us,
rest   2        e
A4     2        e     u                    and
A4     2        e     u                    cast
A4     2        e     u                    a-
measure 52
G4     6        q.    u                    way,
G4     2        e     u                    and
G4     2        e     u                    cast
G4     2        e     u                    a-
measure 53
G4     2        e     u                    way
A4     2        e     u                    their
G4     8-       h     u        -           yokes,_
measure 54
G4     4        q     u                    _
C5     2        e     d                    let
G4     2        e     u                    us
A4     2        e     u                    break
F4     2        e     u                    their
measure 55
G4     2        e     u                    bonds,
F4     2        e     u                    their
E4     4        q     u                    bonds
A4     2        e     u  [                 a-
F4     2        e     u  ]                 -
measure 56
G4     4        q     u                    sun-
G4     2        e     u                    der,
F4     2        e     u                    and
G4     2        e     u                    cast
A4     2        e     u                    a-
measure 57
G4     6        q.    u                    way,
D4     2        e     u                    and
C4     2        e     u                    cast
G4     2        e     u                    a-
measure 58
G4     2        e     u                    way
A4     2        e     u                    their
G4     8        h     u                    yokes
measure 59
G4     4        q     u                    from
G4     4        q     u                    us.
rest   4        q
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/6} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:d11bee1d4ddc62de20ebfb6681155866]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:34   D:Allegro e staccato
G4     2        e     d                    Let
D4     2        e     d                    us
E4     2        e     d                    break
B3     2        e     d                    their
C4     2        e     d                    bonds
G3     2        e     u                    a-
measure 2
A3     2        e     u                    sun-
E4     2        e     d                    der,
F4     2        e     d                    let
E4     2        e     d                    us,
D4     1        s     d  [[                let_
E4     1        s     d  ]]                _
F4     2        e     d                    us
measure 3
E4     4        q     d                    break
rest   2        e
C4     2        e     d                    their
C4     2        e     d                    bonds
C4     2        e     d                    a-
measure 4
C4     2        e     d                    sun-
B3     2        e     d                    der,
E4     2        e     d                    let
D4     2        e     d                    us,
C4     2        e     d                    let
F#4    2        e     d                    us
measure 5
G4     4        q     d                    break,
G4     2        e     d                    let
D4     2        e     d                    us
E4     2        e     d                    break
C4     2        e     d                    their
measure 6
D4     2        e     d                    bonds
F#3    2        e     u                    a-
B3     1        s     d  [[                sun-
C4     1        s     d  =]                -
D4     2        e     d  ]                 -
G3     4        q     u                    der,
measure 7
rest  12
measure 8
A3     2        e     u                    let
F#3    2        e     u                    us
D4     2        e     d                    break
A3     2        e     u                    their
B3     2        e     u                    bonds
C#4    2        e     d                    a-
measure 9
D4     4        q     d                    sun-
A3     4        q     u                    der,
rest   4        q
measure 10
D4     4        q     d                    and
B3     4        q     d                    cast
G3     4        q     u                    a-
measure 11
E3     2        e     u  [                 way_
C4     2-       e     u  ]     -           _
C4     1        s     d  [[                _
D4     1        s     d  ==                _
C4     1        s     d  ==                _
B3     1        s     d  ]]                _
A3     1        s     u  [[                _
B3     1        s     u  ==                _
A3     1        s     u  ==                _
G3     1        s     u  ]]                _
measure 12
F#3    2        e     d  [                 _
D4     2-       e     d  ]     -           _
D4     1        s     d  [[                _
E4     1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
B3     1        s     d  [[                _
C4     1        s     d  ==                _
B3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 13
G3     4        q     u                    _
rest   2        e
G3     2        e     u                    their
G3     2        e     u                    yokes
G3     2        e     u                    from
measure 14
A3     4        q     u                    us,
rest   2        e
A3     2        e     u                    and
A3     2        e     u                    cast
A3     2        e     u                    a-
measure 15
B3     4        q     d                    way
rest   2        e
B3     2        e     d                    their
B3     2        e     d                    yokes
B3     2        e     d                    from
measure 16
C4     4        q     d                    us,
rest   2        e
C4     2        e     d                    and
C4     2        e     d                    cast
C4     2        e     d                    a-
measure 17
D4     4        q     d                    way
rest   2        e
D4     2        e     d                    their
D4     2        e     d                    yokes
D4     2        e     d                    from
measure 18
D4     4        q     d                    us,
rest   2        e
D4     2        e     d                    and
A3     2        e     u                    cast
A3     2        e     u                    a-
measure 19
B3     4        q     d                    way,
rest   2        e
D4     2        e     d                    and
E4     2        e     d                    cast
E4     2        e     d                    a-
measure 20
E4     4        q     d                    way
rest   2        e
E4     2        e     d                    their
E4     2        e     d                    yokes
E4     2        e     d                    from
measure 21
D4     4        q     d                    us,
rest   2        e
A3     2        e     u                    and
G3     2        e     u                    cast
D4     2        e     d                    a-
measure 22
D4     2        e     d                    way
E4     2        e     d                    their
A3     2        e     u                    yokes
A3     2        e     u                    from
D4     4        q     d                    us.
measure 23
D4     2        e     d                    Let
A3     2        e     u                    us
B3     2        e     u                    break
F#3    2        e     u                    their
G3     4        q     u                    bonds,
measure 24
rest  12
measure 25
rest  12
measure 26
F4     2        e     d                    let
C4     2        e     d                    us
D4     2        e     d                    break
A3     2        e     u                    their
Bf3    2        e     u                    bonds
G3     2        e     u                    a-
measure 27
A3     2        e     u                    sun-
A3     2        e     u                    der,
Bf3    2        e     d                    let
C4     2        e     d                    us
D4     2        e     d                    break
E4     2        e     d                    their
measure 28
F4     4        q     d                    bonds,
rest   4        q
rest   4        q
measure 29
rest   4        q
G4     2        e     d                    let
D4     2        e     d                    us
E4     2        e     d                    break
B3     2        e     d                    their
measure 30
C4     2        e     d                    bonds
G3     2        e     u                    a-
A3     1        s     u  [[                sun-
B3     1        s     u  ]]                -
C4     2        e     d                    der,
B3     1        s     d  [[                let_
C4     1        s     d  ]]                _
D4     2        e     d                    us
measure 31
C4     4        q     d                    break,
E4     2        e     d                    let
E4     2        e     d                    us
D4     2        e     d                    break
D4     2        e     d                    their
measure 32
B3     4        q     d                    bonds,
rest   4        q
rest   4        q
measure 33
D4     2        e     d                    let
C4     2        e     d                    us
B3     2        e     u                    break
G3     2        e     u                    their
E4     2        e     d                    bonds
C4     2        e     d                    a-
measure 34
D4     4        q     d                    sun-
D4     4        q     d                    der,
rest   4        q
measure 35
G4     4        q     d                    and
E4     4        q     d                    cast
C4     4        q     d                    a-
measure 36
A3     2        e     d  [                 way,_
F4     2-       e     d  ]     -           _
F4     1        s     d  [[                _
G4     1        s     d  ==                _
F4     1        s     d  ==                _
E4     1        s     d  ]]                _
D4     1        s     d  [[                _
E4     1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
measure 37
B3     2        e     d  [                 _
G4     2-       e     d  ]     -           _
G4     1        s     d  [[                _
A4     1        s     d  ==                _
G4     1        s     d  ==                _
F4     1        s     d  ]]                _
E4     1        s     d  [[                _
F4     1        s     d  ==                _
E4     1        s     d  ==                _
D4     1        s     d  ]]                _
measure 38
C4     4        q     d                    _
rest   2        e
C4     2        e     d                    and
C4     2        e     d                    cast
C4     2        e     d                    a-
measure 39
F4     1        s     d  [[                way,_
G4     1        s     d  ==                _
F4     1        s     d  ==                _
E4     1        s     d  ]]                _
D4     1        s     d  [[                _
E4     1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
measure 40
G3     4        q     u                    _
rest   2        e
G3     2        e     u                    and
C4     2        e     d                    cast
C4     2        e     d                    a-
measure 41
C4     4        q     d                    way
rest   2        e
D4     2        e     d                    their
D4     2        e     d                    yokes
D4     2        e     d                    from
measure 42
D4     4        q     d                    us,
rest   2        e
E4     2        e     d                    and
E4     2        e     d                    cast
E4     2        e     d                    a-
measure 43
E4     2        e     d                    way
B3     2        e     d                    their
C4     8        h     d                    yokes
measure 44
D4     4        q     d                    from
D4     4        q     d                    us.
rest   4        q
measure 45
G4     2        e     d                    Let
D4     2        e     d                    us
E4     2        e     d                    break
B3     2        e     d                    their
C4     2        e     d                    bonds
D4     2        e     d                    a-
measure 46
B3     2        e     u  [                 sun-
A3     2        e     u  ]                 -
G3     4        q     u                    der,
rest   4        q
measure 47
rest   4        q
D4     4        q     d                    and
B3     4        q     d                    cast
measure 48
G3     4        q     u                    and
C4     6        q.    d                    cast
C4     2        e     d                    a-
measure 49
C4     2        e     d                    way,
D4     2        e     d                    and
D4     6        q.    d                    cast
D4     2        e     d                    a-
measure 50
D4     2        e     d                    way
E4     2        e     d                    their
E4     6        q.    d                    yokes
E4     2        e     d                    from
measure 51
E4     4        q     d                    us,
rest   2        e
E4     2        e     d                    and
C4     2        e     d                    cast
C4     2        e     d                    a-
measure 52
D4     6        q.    d                    way,
D4     2        e     d                    and
C4     2        e     d                    cast
D4     2        e     d                    a-
measure 53
C4     2        e     d                    way
C4     2        e     d                    their
B3     8        h     d                    yokes,
measure 54
C4     2        e     d                    let
G3     2        e     u                    us
A3     2        e     u                    break
E3     2        e     u                    their
F3     2        e     u                    bonds
D4     2        e     d                    a-
measure 55
E4     2        e     d  [                 sun-
D4     2        e     d  ]                 -
C4     2        e     d                    der,
C4     2        e     d                    their
C4     2        e     d                    bonds
D4     2        e     d                    a-
measure 56
E4     4        q     d                    sun-
E4     2        e     d                    der,
D4     2        e     d                    and
C4     2        e     d                    cast
F4     2        e     d                    a-
measure 57
D4     6        q.    d                    way,
B3     2        e     d                    and
C4     2        e     d                    cast
D4     2        e     d                    a-
measure 58
E4     2        e     d                    way
C4     2        e     d                    their
C4     4        q     d         (          yokes_
B3     2        e     d  [                 _
F4     2        e     d  ]      )          _
measure 59
E4     4        q     d                    from
E4     4        q     d                    us.
rest   4        q
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/7} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:0aff55bce5df6c6435febb5fd9e9dc22]
06/11/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:22   D:Allegro e staccato
rest  12
measure 2
rest  12
measure 3
C4     2        e     d                    Let
G3     2        e     d                    us
A3     2        e     d                    break
E3     2        e     d                    their
F3     2        e     d                    bonds
C3     2        e     u                    a-
measure 4
D3     2        e     d                    sun-
G3     2        e     d                    der,
C4     2        e     d                    let
B3     2        e     d                    us,
A3     2        e     d                    let
D4     2        e     d                    us
measure 5
B3     2        e     d                    break
D4     2        e     d                    their
G3     4        q     d                    bonds,
rest   4        q
measure 6
G3     2        e     d                    let
D3     2        e     d                    us
E3     2        e     d                    break
B2     2        e     u                    their
C3     2        e     u                    bonds
E3     2        e     d                    a-
measure 7
A3     2        e     d                    sun-
G3     2        e     d                    der,
F#3    1        s     d  [[                let_
G3     1        s     d  =]                _
A3     2        e     d  =                 _
G3     2        e     d  ]                 _
E3     2        e     d                    us
measure 8
F#3    2        e     d                    break
D3     2        e     d                    their
G3     2        e     d  [                 bonds_
F#3    2        e     d  =                 _
E3     2        e     d  ]                 _
A3     2        e     d                    a-
measure 9
D3     4        q     d                    sun-
D3     4        q     d                    der,
rest   4        q
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
G3     4        q     d                    and
F#3    4        q     d                    cast
D3     4        q     d                    a-
measure 19
B2     2        e     d  [                 way,_
G3     2-       e     d  ]     -           _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
F#3    1        s     d  ]]                _
E3     1        s     d  [[                _
F#3    1        s     d  ==                _
E3     1        s     d  ==                _
D3     1        s     d  ]]                _
measure 20
C#3    2        e     d  [                 _
A3     2-       e     d  ]     -           _
A3     1        s     d  [[                _
B3     1        s     d  ==                _
A3     1        s     d  ==                _
G3     1        s     d  ]]                _
F#3    1        s     d  [[                _
G3     1        s     d  ==                _
F#3    1        s     d  ==                _
E3     1        s     d  ]]                _
measure 21
F#3    4        q     d                    _
rest   2        e
D3     2        e     d                    and
E3     2        e     d                    cast
F#3    2        e     d                    a-
measure 22
G3     2        e     d                    way
C3     2        e     u                    their
D3     6        q.    d                    yokes
D3     2        e     d                    from
measure 23
G3     4        q     d                    us.
rest   4        q
rest   4        q
measure 24
rest  12
measure 25
C4     2        e     d                    Let
G3     2        e     d                    us
A3     2        e     d                    break
E3     2        e     d                    their
F3     2        e     d                    bonds
C3     2        e     u                    a-
measure 26
D3     2        e     d                    sun-
A3     2        e     d                    der,
Bf3    2        e     d                    let
F3     2        e     d                    us
G3     2        e     d                    break
C3     2        e     u                    their
measure 27
F3     4        q     d                    bonds,
rest   4        q
rest   4        q
measure 28
F3     2        e     d                    let
C3     2        e     u                    us
D3     2        e     d                    break
A3     2        e     d                    their
B3     2        e     d                    bonds
G3     2        e     d                    a-
measure 29
C4     4        q     d                    sun-
C3     4        q     u                    der,
rest   4        q
measure 30
rest  12
measure 31
C4     2        e     d                    let
G3     2        e     d                    us
A3     2        e     d                    break
E3     2        e     d                    their
F#3    2        e     d                    bonds
D3     2        e     d                    a-
measure 32
G3     4        q     d                    sun-
G3     4        q     d                    der,
rest   4        q
measure 33
G3     2        e     d                    let
D3     2        e     d                    us
E3     2        e     d                    break
B2     2        e     u                    their
C3     2        e     u                    bonds
A2     2        e     u                    a-
measure 34
G2     4        q     u                    sun-
G2     4        q     u                    der,
rest   4        q
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
C4     4        q     d                    and
A3     4        q     d                    cast
F3     4        q     d                    a-
measure 39
D3     2        e     d  [                 way_
Bf3    2-       e     d  ]     -           _
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
F3     1        s     d  ]]                _
measure 40
E3     1        s     d  [[                _
F3     1        s     d  ==                _
E3     1        s     d  ==                _
D3     1        s     d  ]]                _
C3     4        q     u                    _
rest   2        e
E3     2        e     d                    their
measure 41
F3     4        q     d                    yokes,
rest   2        e
F3     2        e     d                    their
F3     2        e     d                    yokes
F3     2        e     d                    from
measure 42
G3     4        q     d                    us,
rest   2        e
G3     2        e     d                    and
G3     2        e     d                    cast
G3     2        e     d                    a-
measure 43
A3     2        e     d                    way
G3     2        e     d                    their
A3     8        h     d                    yokes
measure 44
G3     4        q     d                    from
G3     4        q     d                    us.
rest   4        q
measure 45
rest   4        q
G3     2        e     d                    Let
D3     2        e     d                    us
E3     2        e     d                    break
F#3    2        e     d                    their
measure 46
G3    12        h.    d                    bonds,
measure 47
D4     4        q     d                    and
B3     4        q     d                    cast
G3     4        q     d                    a-
measure 48
E3     2        e     d                    way
C3     2        e     u                    their
C3     6        q.    u                    yokes
C3     2        e     u                    from
measure 49
F3     4        q     d                    us,
rest   2        e
F3     2        e     d                    and
F3     2        e     d                    cast
F3     2        e     d                    a-
measure 50
G3     4        q     d                    way
rest   2        e
G3     2        e     d                    their
G3     2        e     d                    yokes
G3     2        e     d                    from
measure 51
A3     4        q     d                    us,
rest   2        e
A3     2        e     d                    and
A3     2        e     d                    cast
A3     2        e     d                    a-
measure 52
B3     6        q.    d                    way,
B3     2        e     d                    and
C4     2        e     d                    cast
B3     2        e     d                    a-
measure 53
C4     2        e     d                    way
F3     2        e     d                    their
G3     8        h     d                    yokes
measure 54
C3     4        q     u                    from
C3     4        q     u                    us;
rest   4        q
measure 55
C4     2        e     d                    let
G3     2        e     d                    us
A3     2        e     d                    break
E3     2        e     d                    their
F3     2        e     d                    bonds
D3     2        e     d                    a-
measure 56
C3     4        q     u                    sun-
C3     2        e     u                    der,
D3     2        e     d                    and
E3     2        e     d                    cast
F3     2        e     d                    a-
measure 57
G3     6        q.    d                    way,
G3     2        e     d                    and
A3     2        e     d                    cast
B3     2        e     d                    a-
measure 58
C4     2        e     d                    way
F3     2        e     d                    their
G3     8        h     d                    yokes
measure 59
C3     4        q     u                    from
C3     4        q     u                    us.
rest   4        q
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-18/8} [KHM:1719304763]
TIMESTAMP: DEC/26/2001 [md5sum:6a2f5b2bba1575b10c749ef1b02c6638]
06/12/90 E. Correia
WK#:56        MV#:2,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:3/4   C:22   D:Allegro e staccato
$ C:4
rest   4        7
G5     2        6     u  [
D5     2        6     u  ]
E5     2        6     u  [
B4     2        6     u  ]
back  12
G4     2        6     d  [
D4     2        6     d  ]
E4     2        6     d  [
B3     2        6     d  ]
C4     2        6     d  [
G3     2        6     d  ]
measure 2
C5     2        6     u  [
G4     2        6     u  ]
A4     1        5     u  [[
B4     1        5     u  =]
C5     2        6     u  ]
B4     1        5     u  [[
C5     1        5     u  =]
D5     2        6     u  ]
back  12
A3     2        6     d  [
E4     2        6     d  ]
F4     2        6     d  [
E4     2        6     d  ]
D4     1        5     d  [[
E4     1        5     d  =]
F4     2        6     d  ]
$ C:22
measure 3
C4     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 4
D3     2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
B3     2        e     d  =
A3     2        e     d  =
D4     2        e     d  ]
measure 5
B3     2        e     d  [
D4     2        e     d  ]
G3     4        q     d
$ C:12
E4     2        e     d  [
C4     2        e     d  ]
$ C:22
measure 6
G3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
B2     2        e     d  =
C3     2        e     d  =
E3     2        e     d  ]
measure 7
A3     2        e     d  [
G3     2        e     d  ]
F#3    1        s     d  [[
G3     1        s     d  =]
A3     2        e     d  ]
G3     2        e     d  [
E3     2        e     d  ]
measure 8
F#3    2        e     d  [
D3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  =
A3     2        e     d  ]
measure 9
D3     4        q     d
D2     4        q     u
rest   4        q
$ C:13
measure 10
D4     4        7     d
B3     4        7     d
G3     4        7     d
measure 11
E3     2        6     d  [
C4     2-       6     d  ]     -
C4     1        5     d  [[
D4     1        5     d  ==
C4     1        5     d  ==
B3     1        5     d  ]]
A3     1        5     d  [[
B3     1        5     d  ==
A3     1        5     d  ==
G3     1        5     d  ]]
measure 12
A4     4        7     u
F#4    4        7     u
D4     4        7     u
back  12
F#3    2        6     d  [
D4     2-       6     d  ]     -
D4     1        5     d  [[
E4     1        5     d  ==
D4     1        5     d  ==
C4     1        5     d  ]]
B3     1        5     d  [[
C4     1        5     d  ==
B3     1        5     d  ==
A3     1        5     d  ]]
measure 13
B3     2        6     u  [
G4     2-       6     u  ]     -
G4     1        5     u  [[
A4     1        5     u  ==
G4     1        5     u  ==
F#4    1        5     u  ]]
E4     1        5     u  [[
F#4    1        5     u  ==
E4     1        5     u  ==
D4     1        5     u  ]]
back  12
G3     4        7     d
rest   2        6
G3     2        6     d
G3     2        6     d  [
G3     2        6     d  ]
measure 14
C#4    2        6     u  [
A4     2-       6     u  ]     -
A4     1        5     u  [[
B4     1        5     u  ==
A4     1        5     u  ==
G4     1        5     u  ]]
F#4    1        5     u  [[
G4     1        5     u  ==
F#4    1        5     u  ==
E4     1        5     u  ]]
back  12
A3     4        7     d
rest   2        6
A3     2        6     d
A3     2        6     d  [
A3     2        6     d  ]
measure 15
D4     4        7     u
back   4
B3     4        7     d
$   C:12
rest   2        e
f1              6
B3     2        e     d
B3     2        e     d  [
B3     2        e     d  ]
measure 16
C4     4        q     d
rest   2        e
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 17
D4     4        q     d
rest   2        e
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
$ C:22
measure 18
G3     4        q     d
F#3    4        q     d
D3     4        q     d
measure 19
B2     2        e     d  [
G3     2-       e     d  ]     -
G3     2        e     d  [
F#3    2        e     d  =
E3     3        e.    d  =
D3     1        s     d  ]\
measure 20
C#3    2        e     d  [
A3     2-       e     d  ]     -
A3     2        e     d  [
G3     2        e     d  =
F#3    3        e.    d  =
E3     1        s     d  ]\
measure 21
F#3    4        q     d
rest   2        e
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  ]
measure 22
G3     2        e     d  [
C3     2        e     d  ]
D3     6        q.    d
D3     2        e     d
measure 23
G2     4        q     d
$ C:13
B3     2        e     d  [
F#3    2        e     d  ]
G3     4        q     d
$ C:15
measure 24
G4     2        e     d  [
D4     2        e     d  ]
E4     2        e     d  [
B3     2        e     d  ]
C4     2        e     d  [
D4     2        e     d  ]
$ C:22
measure 25
C4     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 26
D3     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
F3     2        e     d  =
G3     2        e     d  =
C3     2        e     d  ]
measure 27
F3     2        e     d  [
$ C:12
A3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
$ C:22
measure 28
F3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
A2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
measure 29
C3     4        q     u
C2     4        q     u
$ C:12
f1              6
E4     2        e     d  [
B3     2        e     d  ]
measure 30
C4     2        e     d  [
G3     2        e     d  ]
A3     1        s     d  [[
B3     1        s     d  =]
C4     2        e     d  ]
B3     1        s     d  [[
C4     1        s     d  =]
D4     2        e     d  ]
$ C:22
measure 31
C4     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 32
G3     4        q     d
G2     2        e     d  [
$ C:15
D4     2        e     d  ]
E4     2        e     d  [
F#4    2        e     d  ]
$ C:22
measure 33
G3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
B2     2        e     d  =
C3     2        e     d  =
A2     2        e     d  ]
measure 34
G2     4        q     u
G2     4        q     u
rest   4        q
$ C:15
measure 35
G4     4        q     d
E4     4        q     d
C4     4        q     d
measure 36
A3     2        e     d  [
F4     2-       e     d  ]     -
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
E4     1        s     d  ]]
D4     1        s     d  [[
E4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
measure 37
B3     2        e     d  [
G4     2-       e     d  ]     -
G4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ]]
E4     1        s     d  [[
F4     1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
$ C:22
measure 38
C4     4        q     d
A3     4        q     d
F3     4        q     d
measure 39
D3     2        e     d  [
Bf3    2-       e     d  ]     -
Bf3    1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
A3     1        s     d  ]]
G3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F3     1        s     d  ]]
measure 40
E3     1        s     d  [[
F3     1        s     d  ==
E3     1        s     d  ==
D3     1        s     d  ]]
C3     4        q     u
rest   2        e
f1              6
E3     2        e     d
measure 41
f1              5
F3     4        q     d
rest   2        e
f1              6
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 42
G3     4        q     d
rest   2        e
f1              6
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  ]
measure 43
A3     2        e     d  [
G3     2        e     d  ]
f1     4        7
f1              6+
A3     8        h     d
measure 44
G3     4        q     d
G2     4        q     u
G2     4        q     u
measure 45
G2    12-       h.    u        -
measure 46
G2    12-       h.    u        -
measure 47
G2    12        h.    u
measure 48
C3     4        q     u
C3     6        q.    u
C3     2        e     u
measure 49
F3     6        q.    d
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 50
G3     6        q.    d
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  ]
measure 51
A3     6        q.    d
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  ]
measure 52
B3     6        q.    d
B3     2        e     d  [
C4     2        e     d  =
B3     2        e     d  ]
measure 53
C4     2        e     d  [
F3     2        e     d  ]
G3     4        q     d
G2     4        q     u
measure 54
C3    12-       h.    u        -
measure 55
C3    12        h.    u
measure 56
C3     6        q.    u
D3     2        e     d  [
E3     2        e     d  =
F3     2        e     d  ]
measure 57
G3     6        q.    d
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  ]
measure 58
C4     2        e     d  [
F3     2        e     d  ]
G3     4        q     d
G2     4        q     u
measure 59
C3    12        h.    u
measure 60
C4     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  =
C3     2        e     d  ]
measure 61
D3     2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
A3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
measure 62
B3     4        q     d
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
measure 63
C4     4        q     d
C3     6        q.    u
C3     2        e     u
measure 64
F3     6        q.    d
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 65
G3     6        q.    d
B3     2        e     d
C4     4        q     d
measure 66
A3     2        e     d  [
F3     2        e     d  ]
G3     4        q     d
G2     4        q     u
measure 67
C3    12        h.    u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
