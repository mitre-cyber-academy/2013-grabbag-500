&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-17/1} [KHM:1493998247]
TIMESTAMP: DEC/26/2001 [md5sum:7d37d97f26b545c8729b616f05f306d9]
04/09/90 E. Correia
WK#:56        MV#:1,17
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Soprano
1 20 S
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:4
rest   4        q
A4     2        e     u                    And
B4     2        e     u                    the
C#5    2        e     d                    An-
C#5    2        e     d                    gel
rest   1        s
C#5    1        s     d                    said
C#5    1        s     d                    un-
D5     1        s     d                    to
measure 2
E5     4        q     d                    them:
rest   4        q
E5     2        e     d                    Fear
A4     2        e     u                    not,
rest   2        e
A4     1        s     u                    for
A4     1        s     u                    be-
measure 3
D5     4        q     d                    hold!
rest   2        e
D5     2        e     d                    I
D5     4        q     d                    bring
C#5    2        e     d                    you
B4     2        e     u                    good
measure 4
E5     2        e     d                    ti-
E5     2        e     d                    dings
rest   2        e
E5     1        s     d                    of
B4     1        s     u                    great
C#5    4        q     d                    joy,
rest   2        e
C#5    1        s     d                    which
A4     1        s     u                    shall
measure 5
D#5    4        q     d                    be
D#5    2        e     d                    to
E5     2        e     d                    all
B4     2        e     u                    peo-
B4     2        e     u                    ple:
rest   4        q
measure 6
rest   2        e
G#4    2        e     u                    For
G#4    2        e     u                    un-
G#4    2        e     u                    to
C#5    2        e     d                    you
rest   1        s
C#5    1        s     d                    is
C#5    2        e     d                    born
B4     2        e     u                    this
measure 7
D5     4        q     d                    day,
rest   2        e
D5     1        s     d                    in
D5     1        s     d                    the
D5     4        q     d                    ci-
D5     2        e     d                    ty
C#5    2        e     d                    of
measure 8
A4     2        e     u                    Da-
A4     2        e     u                    vid,
rest   2        e
C#5    2        e     d                    a
D5     2        e     d                    Sa-
B4     2        e     u                    viour,
rest   2        e
B4     1        s     u                    which
B4     1        s     u                    is
measure 9
E#5    4        q     d                    Christ,
rest   2        e
F#5    2        e     d                    the
C#5    4        q     d                    Lord.
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-17/2} [KHM:1493998247]
TIMESTAMP: DEC/26/2001 [md5sum:5d9616279bb1922b92b8a6d1a4cbdbd0]
04/09/90 E. Correia
WK#:56        MV#:1,17
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Bassi
1 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:22
C#3    4-       w     u        -
measure 2
C#3    4        w     u
measure 3
F#3    4        w     d
measure 4
G#3    2        h     d
f1              #
A3     2-       h     d        -
measure 5
A3     2        h     d
f1              #
B3     1        q     d
f1              #
E3     1        q     d
measure 6
E#3    4-       w     d        -
measure 7
E#3    4        w     d
measure 8
F#3    2        h     d
B2     2-       h     u        -
measure 9
B2     2        h     u
f1              #
C#3    1        q     u
F#3    1        q     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
