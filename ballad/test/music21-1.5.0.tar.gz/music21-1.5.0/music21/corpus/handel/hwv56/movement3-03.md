&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-03/1} [KHM:2512263026]
TIMESTAMP: DEC/26/2001 [md5sum:6c01b7df143381d37ba17f08685131b3]
06/24/90 E. Correia
WK#:56        MV#:3,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
1 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4
A4    16-       w     u        -
measure 2
A4     8        h     u
B4     8-       h     d        -
measure 3
B4    16        w     d
measure 4
C#4   16        w     u
measure 5
C#5    8        h     d
rest   2        e
B4     1        s     d  [[
B4     1        s     d  ]]
B4     4-       q     d        -
measure 6
B4     8        h     d
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
A4     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
measure 7
F#5    4        q     d
rest   4        q
rest   2        e
G#5    1        s     d  [[
G#5    1        s     d  ]]
G#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 8
C#5    4        q     d
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-03/2} [KHM:2512263026]
TIMESTAMP: DEC/26/2001 [md5sum:aba0da6004d6381e9d74c4583517aa02]
06/24/90 E. Correia
WK#:56        MV#:3,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
1 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4
F#4   16-       w     u        -
measure 2
F#4   16-       w     u        -
measure 3
F#4   16        w     u
measure 4
G4    16-       w     u        -
measure 5
G4     4        q     u
F#4    4        q     u
rest   2        e
F#4    1        s     u  [[
F#4    1        s     u  ]]
F#4    4        q     u
measure 6
E#4    8        h     u
rest   2        e
F#4    1        s     u  [[
F#4    1        s     u  ]]
F#4    2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
measure 7
A4     4        q     u
rest   4        q
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
E5     2        e     d  [
B4     1        s     d  =[
B4     1        s     d  ]]
measure 8
A4     4        q     u
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-03/3} [KHM:2512263026]
TIMESTAMP: DEC/26/2001 [md5sum:a7fbf0a9f080d3831e12825154f8f01d]
06/24/90 E. Correia
WK#:56        MV#:3,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
1 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13
D4    16-       w     d        -
measure 2
D4    16-       w     d        -
measure 3
D4    16        w     d
measure 4
E4    16-       w     d        -
measure 5
E4     4        q     d
C#4    4        q     d
D4     4        q     d
B3     4-       q     u        -
measure 6
B3     8        h     u
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
C#4    2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
measure 7
D4     4        q     d
rest   4        q
rest   2        e
B4     1        s     d  [[
B4     1        s     d  ]]
B4     2        e     d  [
E4     1        s     d  =[
E4     1        s     d  ]]
measure 8
E4     4        q     d
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-03/4} [KHM:2512263026]
TIMESTAMP: DEC/26/2001 [md5sum:e2fe06a0f5a7f3216402e8c0bcc08c2f]
06/24/90 E. Correia
WK#:56        MV#:3,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Basso
1 72 B
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22
rest   4        q
rest   2        e
D3     2        e     d                    Be-
F#3    4        q     d                    hold,
rest   2        e
F#3    2        e     d                    I
measure 2
A3     4        q     d                    tell
A3     2        e     d                    you
A3     2        e     d                    a
D4     3        e.    d                    my-
D3     1        s     d                    ste-
D3     4        q     d                    ry!
measure 3
rest   4        q
F#3    2        e     d                    We
F#3    2        e     d                    shall
F#3    4        q     d                    not
B3     4        q     d                    all
measure 4
G3     4        q     d                    sleep,
rest   2        e
G3     2        e     d                    but
E3     2        e     d                    we
E3     2        e     d                    shall
F#3    2        e     d                    all
G3     2        e     d                    be
measure 5
A2     6        q.    u                    chang'd,
F#3    1        s     d                    in
F#3    1        s     d                    a
B3     2        e     d                    mo-
B3     2        e     d                    ment,
rest   2        e
B3     1        s     d                    in
B3     1        s     d                    the
measure 6
B3     2        e     d                    twink-
B3     2        e     d                    ling
C#4    2        e     d                    of
G#3    2        e #   d                    an
A3     4        q     d                    eye,
rest   4        q
measure 7
rest   4        q
D4     2        e     d                    at
G#3    1        s #   d                    the
A3     1        s     d                    last
A3     2        e     d                    trum-
E3     2        e     d                    pet.
rest   4        q
measure 8
rest  16
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-03/5} [KHM:2512263026]
TIMESTAMP: DEC/26/2001 [md5sum:9dd9733c6872eca0e06727e59b7ec397]
06/24/90 E. Correia
WK#:56        MV#:3,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
1 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22
D3    16-       w     d        -
measure 2
D3     8        h     d
B2     8-       h     u        -
measure 3
B2    16        w     u
measure 4
A#2   16        w     u
measure 5
A2     8        h     u         +
rest   2        e
G#2    1        s     u  [[
G#2    1        s     u  ]]
G#2    4-       q     u        -
measure 6
G#2    8        h     u
rest   2        e
F#2    1        s     u  [[
F#2    1        s     u  ]]
F#2    2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
measure 7
D3     4        q     u
rest   4        q
rest   2        e
E3     1        s     d  [[
E3     1        s     d  ]]
E3     2        e     u  [
E2     1        s     u  =[
E2     1        s     u  ]]
measure 8
A2     4        q     u
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
