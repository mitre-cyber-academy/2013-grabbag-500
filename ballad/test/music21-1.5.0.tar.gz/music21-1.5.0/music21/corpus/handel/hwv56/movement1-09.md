&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-09/1} [KHM:1665492715]
TIMESTAMP: DEC/26/2001 [md5sum:5b8832f236ba1e07b361f3ed0f330b2f]
04/07/90 E. Correia
WK#:56        MV#:1,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violini unisoni
1 19
Group memberships: score
score: part 1 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4   D:Andante
A5     4        e     d
measure 1
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 2
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      &(
E5     4        e     d  =      &)
A4     4        e     d  ]
measure 3
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 4
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     2        s     d  [[     (
F#5    2        s     d  ==
E5     2        s     d  ==     )
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 5
D6     2        s     d  [[     (
C#6    2        s     d  ==
D6     2        s     d  ==     )
A3     2        s     u  ==
B3     2        s     u  ==
C4     2        s     u  ]]
B3     2        s     u  [[     (
A3     2        s     u  ==
G3     2        s     u  ==     )
B4     2        s     d  ==
C#5    2        s     d  ==     +
D5     2        s     d  ]]
measure 6
E5     2        s     d  [[     (
D5     2        s     d  ==
E5     2        s     d  ==     )
B3     2        s     u  ==
C#4    2        s     u  ==
D4     2        s     u  ]]
C#4    2        s     u  [[     (
B3     2        s     u  ==
A3     2        s     u  ==     )
C#5    2        s     d  ==
D5     2        s     d  ==
E5     2        s     d  ]]
measure 7
F#5    2        s     d  [[     (
E5     2        s     d  ==
F#5    2        s     d  ==     )
C#4    2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[     (
C#4    2        s     u  ==
B3     2        s     u  ==     )
D4     2        s     u  ==
E4     2        s     u  ==
F#4    2        s     u  ]]
measure 8
E4     2        s     u  [[     (
D4     2        s     u  ==
C#4    2        s     u  ==     )
E4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[     (
E4     2        s     u  ==
D4     2        s     u  ==     )
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 9
D6     4        e     d  [      (
C#6    4        e     d  =
B5     4        e     d  ]      )
A5     4        e     d  [      (
G5     4        e     d  =
F#5    4        e     d  ]      )
measure 10
E4    12        q.    u         t
E4    12        q.    u         t
measure 11
E4     8        q     u         t
D5     4        e     d
C#5    2        s     d  [[
E5     2        s     d  ==
A4     2        s     d  ==
G5     2        s     d  ==
F#5    2        s     d  ==
D5     2        s     d  ]]
measure 12
E5     2        s     d  [[
G4     2        s     d  ==
F#4    2        s     d  ==
D5     2        s     d  ==
E4     2        s     d  ==
C#5    2        s     d  ]]
D5     4        e     u  [
D4     4        e     u  ]
rest   4        e
measure 13
rest  24
measure 14
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A5     4        e     d         p
measure 15
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 16
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      (t
E5     4        e     d  ]      &)
rest   4        e
measure 17
rest  24
measure 18
rest   8        q
rest   4        e
rest   4        e
rest   2        s
E5     2        s     d  [[
F#5    2        s     d  ==
G5     2        s     d  ]]
measure 19
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 20
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 21
rest  24
measure 22
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A5     4        e     d
measure 23
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 24
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      (t
E5     4        e     d  ]      &)
rest   4        e
measure 25
rest   8        q
rest   4        e
rest   4        e
rest   4        e
D5     4        e     d
measure 26
A5     4        e     d  [      (
G#5    4        e     d  =
F#5    4        e     d  ]      )
E5     4        e     d  [      (
D5     4        e     d  =
C#5    4        e     d  ]      )
measure 27
B4     2        s     d  [[     (
C#5    2        s     d  ==
B4     2        s     d  ==     )
A5     2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ]]
B4     2        s     d  [[     (
C#5    2        s     d  ==
B4     2        s     d  ==     )
A5     2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ]]
measure 28
B4     8        q     d
rest   4        e
rest   4        e
rest   2        s
E5     2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ]]
measure 29
F#4    2        s     u  [[     (
G#4    2        s     u  ==
F#4    2        s     u  ==     )
D5     2        s     u  ==
C#5    2        s     u  ==
D5     2        s     u  ]]
E4     8        q     u
rest   4        e
measure 30
rest  24
measure 31
rest  24
measure 32
rest   8        q
rest   4        e
rest   4        e
rest   4        e
E5     4        e     d
measure 33
A5     4        e     d  [      (
G#5    4        e     d  =
F#5    4        e     d  ]      )
E5     4        e     d  [      (
D5     4        e     d  =
C#5    4        e     d  ]      )
measure 34
B3    12-       q.    u        -
B3     8        q     u
C#6    4        e     d
measure 35
D6     4        e     d
B5     8        q     d         t
A5     4        e     d  [
rest   2        s
E5     2        s     d  =[     f
F#5    2        s     d  ==
G#5    2        s     d  ]]
measure 36
A5     2        s     d  [[     (
G#5    2        s     d  ==
A5     2        s     d  ==     )
E4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]     +
F#4    2        s     u  [[
E4     2        s     u  ==
D4     2        s     u  ==
F#5    2        s     d  ==
G#5    2        s     d  ==     +
A5     2        s     d  ]]
measure 37
B5     2        s     d  [[
A5     2        s     d  ==
B5     2        s     d  ==
F#4    2        s     u  ==
G#4    2        s     u  ==
A4     2        s     u  ]]
G#4    2        s     u  [[
F#4    2        s     u  ==
E4     2        s     u  ==
G#4    2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ]]
measure 38
A4     2        s     u  [[
G#4    2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ==
C#5    2        s     u  ]]
B4     2        s     u  [[
A4     2        s     u  ==
G#4    2        s     u  ==
B4     2        s     u  ==
C#5    2        s     u  ==
D5     2        s     u  ]]
measure 39
C#5    2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
F#5    2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ]]
D5     6        e.    d  [
B5     2        s     d  =[
C#5    2        s     d  ==
A5     2        s     d  ]]
measure 40
B4     2        s     d  [[
A5     2        s     d  =]
G#5    6        e.    d  =      t
A5     2        s     d  ]\
A5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 41
rest  24
measure 42
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u
measure 43
F#5    4        e     d  [
G5     2        s     d  =[
F#5    2        s     d  ==
E5     2        s     d  ==
D5     2        s     d  ]]
A5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 44
rest   4        e
rest   2        s
A4     2        s     u  [[     &(
B4     2        s     u  ==
C5     2        s     u  ]]     )
B4     2        s     u  [[     (
A4     2        s     u  =]     )
G4     4        e     u  ]
rest   4        e
measure 45
rest   4        e
rest   2        s
B4     2        s     d  [[     &(
C#5    2        s     d  ==     +
D5     2        s     d  ]]     &)
C#5    2        s     d  [[     &(
B4     2        s     d  =]     &)
A4     4        e     d  ]
rest   4        e
measure 46
rest   4        e
rest   2        s
C#5    2        s     d  [[     (
D5     2        s     d  ==
E5     2        s     d  ]]     )
D5     2        s     d  [[     (
C#5    2        s     d  =]     )
B4     4        e     d  ]
rest   4        e
measure 47
rest   2        s
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
A4     8        q     u
rest   4        e
measure 48
rest   4        e
rest   2        s
A5     2        s     d  [[
B5     2        s     d  ==
A5     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 49
F#5    2        s     d  [[
G5     2        s     d  ==
F#5    2        s     d  ==
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 50
rest   4        e
rest   2        s
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ]]
G5     2        s     d  [[
A5     2        s     d  ==
G5     2        s     d  ==
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 51
F#5    2        s     d  [[
G5     2        s     d  ==
F#5    2        s     d  ==
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 52
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A5     4        e     d
measure 53
D6     4        e     d  [      (
C#6    4        e     d  =
B5     4        e     d  ]      )
A5     4        e     d  [      (
G5     4        e     d  =
F#5    4        e     d  ]      )
measure 54
E4    12-       q.    u        -
E4    12-       q.    u        -
measure 55
E4    12-       q.    u        -
E4    12        q.    u
measure 56
D4    12-       q.    u        -
D4    12-       q.    u        -
measure 57
D4    12-       q.    u        -
D4    12        q.    u
measure 58
rest  24
measure 59
rest   8        q
rest   4        e
rest   4        e
rest   4        e
D5     4        e     d
measure 60
D5     4        e     d  [      (
C#5    4        e     d  =      )
E5     4        e     d  ]
E5     4        e     d  [      (
D5     4        e     d  =      )
F#5    4        e     d  ]
measure 61
F#5    4        e     d  [      (
E5     4        e     d  =      )
G5     4        e     d  ]
F#5    4        e     d  [      (
E5     4        e     d  =      )
D5     4        e     d  ]
measure 62
rest   8        q
rest   4        e
rest   4        e
rest   4        e
D5     4        e     d
measure 63
G5     4        e     d  [      (
F#5    4        e     d  =
E5     4        e     d  ]      )
D5     4        e     d  [      (
C5     4        e     d  =
B4     4        e     d  ]      )
measure 64
A3    12        q.    u         &t
A3    12        q.    u         &t
measure 65
A3    12        q.    u         &t
A3    12        q.    u         &t
measure 66
A3    12        q.    u
rest   4        e
rest   4        e
A4     4        e     u         f
measure 67
G5     4        e     d  [      (
F#5    4        e     d  =
E5     4        e     d  ]      )
D5     4        e     d  [      (
C5     4        e     d  =
B4     4        e     d  ]      )
measure 68
A4     2        s     d  [[     (
B4     2        s     d  ==
A4     2        s     d  ==     )
G5     2        s     d  ==
F#5    2        s     d  ==
G5     2        s     d  ]]
A4     2        s     d  [[     (
B4     2        s     d  ==
A4     2        s     d  ==     )
G5     2        s     d  ==
F#5    2        s     d  ==
G5     2        s     d  ]]
measure 69
A4     2        s     d  [[     (
B4     2        s     d  ==
A4     2        s     d  ==     )
G5     2        s     d  ==
F#5    2        s     d  ==
G5     2        s     d  ]]
A4     2        s     d  [[     (
B4     2        s     d  ==
A4     2        s     d  ==     )
G5     2        s     d  ==
F#5    2        s     d  ==
G5     2        s     d  ]]
measure 70
A4     4        e     d  [
F#5    4        e     d  =
G5     4        e     d  ]
E4     4        e     u  [      (
D4     4        e     u  =      )
F#5    4        e     u  ]
measure 71
G5     4        e     d  [
B3     4        e     u  =
D4     4        e     u  ]
G3     8        q     u
rest   4        e
measure 72
rest  24
measure 73
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A5     4        e     d
measure 74
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 75
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      (t
E5     4        e     d  ]      )
rest   4        e
measure 76
rest  24
measure 77
rest   8        q
rest   4        e
rest   4        e
rest   2        s
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ]]
measure 78
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 79
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 80
rest   4        e
rest   2        s
E5     2        s     d  [[     (
F#5    2        s     d  ==
G5     2        s     d  ]]     )
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  ]
rest   4        e
measure 81
rest   4        e
rest   2        s
G5     2        s     d  [[
A5     2        s     d  ==
B5     2        s     d  ]]
A5     2        s     d  [[
G5     2        s     d  =]
F#5    4        e     d  ]
rest   4        e
measure 82
rest  24
measure 83
rest   8        q
rest   4        e
rest   4        e
rest   4        e
E5     4        e     d
measure 84
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
E5    12        q.    d
measure 85
rest  24
measure 86
rest  24
measure 87
rest  24
measure 88
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A5     4        e     d
measure 89
E5     2        s     d  [[     (
D5     2        s     d  =]     )
E5     4        e     d  =
G5     4        e     d  ]
F#5    8        q     d
rest   4        e
measure 90
rest  24
measure 91
*               G +     &p
A3     2        s     u  [[     (
F#4    2        s     u  ==     )
A4     2        s     u  ==     (
F#4    2        s     u  ==     )
C4     2        s     u  ==     (
F#4    2        s     u  ]]     )
A3     2        s     u  [[     (
F#4    2        s     u  ==     )
A4     2        s     u  ==     (
F#4    2        s     u  ==     )
C4     2        s     u  ==     (
F#4    2        s     u  ]]     )
measure 92
A3     2        s     u  [[     (
F#4    2        s     u  ==     )
A4     2        s     u  ==     (
F#4    2        s     u  ==     )
C4     2        s     u  ==     (
F#4    2        s     u  ]]     )
A3     2        s     u  [[
F#4    2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
C4     2        s     u  ==
F#4    2        s     u  ]]
measure 93
G3     8        q     u
rest   4        e
rest   8        q
rest   4        e
measure 94
rest  24
measure 95
rest  24
measure 96
rest  24
measure 97
rest   8        q
rest   4        e
rest   4        e
rest   4        e
E5     1        t     d  [[[    (
F#5    1        t     d  ==]
G5     2        s     d  ]]     )
measure 98
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  ]
E5     1        t     d  [[[    (
F#5    1        t     d  ==]
G5     2        s     d  ]]     )
F#5    2        s     d  [[
E5     2        s     d  =]
D5     4        e     d  ]
rest   4        e
measure 99
rest   4        e
rest   4        e
E5     1        t     d  [[[    (
F#5    1        t     d  ==]
G5     2        s     d  ]]     )
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  ]
rest   4        e
measure 100
rest   4        e
rest   4        e
G5     1        t     d  [[[    (
A5     1        t     d  ==]
B5     2        s     d  ]]     )
A5     2        s     d  [[     (
G5     2        s     d  =]     )
F#5    4        e     d  =
A4     4        e     d  ]
measure 101
B4     4        e     u  [      (
A4     4        e     u  =
G4     4        e     u  ]      )
F#4    4        e     u  [      (
E4     4        e     u  =
D4     4        e     u  ]      )
measure 102
A4     2        s     d  [[     (
F#5    2        s     d  ==     )
A5     2        s     d  ==     (
F#5    2        s     d  ==     )
C5     2        s     d  ==     (
F#5    2        s     d  ]]     )
A4     2        s     d  [[     (
F#5    2        s     d  ==     )
A5     2        s     d  ==     (
F#5    2        s     d  ==     )
C5     2        s     d  ==     (
F#5    2        s     d  ]]     )
measure 103
A4     2        s     d  [[     (
F#5    2        s     d  ==     )
A5     2        s     d  ==     (
F#5    2        s     d  ==     )
C5     2        s     d  ==     (
F#5    2        s     d  ]]     )
A4     2        s     d  [[     (
F#5    2        s     d  ==     )
A5     2        s     d  ==     (
F#5    2        s     d  ==     )
A4     2        s     d  ==     (
F#5    2        s     d  ]]     )
measure 104
D4    12        q.    u
rest   8        q
rest   4        e
measure 105
rest  24
measure 106
rest   8        q
rest   4        e
rest   8        q
*               D       (attacca il Coro)
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-09/2} [KHM:1665492715]
TIMESTAMP: DEC/26/2001 [md5sum:97ddbab8540dfe409204a44ef7dd734a]
04/07/90 E. Correia
WK#:56        MV#:1,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Contr'alto
1 19 A
Group memberships: score
score: part 2 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4   D:Andante
rest   4        e
measure 1
rest  24
measure 2
rest  24
measure 3
rest  24
measure 4
rest  24
measure 5
rest  24
measure 6
rest  24
measure 7
rest  24
measure 8
rest  24
measure 9
rest  24
measure 10
rest  24
measure 11
rest  24
measure 12
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    O!
measure 13
D4     8        q     u                    thou
E4     4        e     u                    that
C#4    4        e     u                    tell-
D4     4        e     u                    est
E4     4        e     u                    good
measure 14
F#4    4        e     u                    ti-
G4     4        e     u                    dings
F#4    4        e     u                    to
F#4    4        e     u                    Zi-
E4     4        e     u                    on,
rest   4        e
measure 15
rest  24
measure 16
rest   8        q
rest   4        e
rest   4        e
E4     4        e     u                    get
E4     4        e     u                    thee
measure 17
A4     8        q     u                    up
A4     4        e     u                    in-
E4     4        e     u                    to
F#4    4        e     u                    the
G4     4        e     u                    high
measure 18
F#4   12        q.    u                    moun-
E4    12        q.    u                    tain!
measure 19
rest  24
measure 20
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    O!
measure 21
D4     8        q     u                    thou
E4     4        e     u                    that
C#4    4        e     u                    tell-
D4     4        e     u                    est
E4     4        e     u                    good
measure 22
F#4    4        e     u                    ti-
G4     4        e     u                    dings
F#4    4        e     u                    to
F#4    4        e     u                    Zi-
E4     4        e     u                    on,
rest   4        e
measure 23
rest  24
measure 24
rest   8        q
rest   4        e
rest   4        e
E4     4        e     u                    get
E4     4        e     u                    thee
measure 25
F#4    8        q     u                    up
E4     4        e     u                    in-
F#4    4        e     u                    to
A4     4        e     u                    the
G#4    4        e     u                    high
measure 26
A4    12-       q.    u        -           moun-
A4    12-       q.    u        -           -
measure 27
A4    12-       q.    u        -           -
A4    12-       q.    u        -           -
measure 28
A4     4        e     u  [                 -
G#4    4        e     u  =                 -
F#4    4        e     u  ]                 -
G#4    2        s     u  [[                -
F#4    2        s     u  ]]                -
E4     4        e     u                    tain,
rest   4        e
measure 29
rest   8        q
rest   4        e
rest   4        e
E4     4        e     u                    get
E4     4        e     u                    thee
measure 30
F#4    8        q     u                    up
D4     4        e     u                    in-
E4     2        s     u  [[                to_
D4     2        s     u  ]]                _
C#4    4        e     u                    the
E4     4        e     u                    high
measure 31
F#4    2        s     u  [[                moun-
E4     2        s     u  =]                -
D4     4        e     u  =                 -
F#4    4        e     u  ]                 -
E4     2        s     u  [[                -
D4     2        s     u  =]                -
C#4    4        e     u  =                 -
E4     4        e     u  ]                 -
measure 32
F#4    2        s     u  [[                -
E4     2        s     u  =]                -
D4     4        e     u  =                 -
F#4    4        e     u  ]                 -
G#4    2        s     u  [[                -
F#4    2        s     u  =]                -
E4     4        e     u  =                 -
G#4    4        e     u  ]                 -
measure 33
A4    12-       q.    u        -           -
A4    12-       q.    u        -           -
measure 34
A4     4        e     u  [                 -
G#4    4        e     u  =                 -
F#4    4        e     u  ]                 -
G#4    4        e     u  [                 -
E4     4        e     u  =                 -
A4     4        e     u  ]                 -
measure 35
F#4    4        e     u                    -
G#4    8        q     u                    -
A4    12        q.    u                    tain.
measure 36
rest  24
measure 37
rest  24
measure 38
rest  24
measure 39
rest  24
measure 40
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    O!
measure 41
D4     8        q     u                    thou
E4     4        e     u                    that
C#4    4        e     u                    tell-
D4     4        e     u                    est
E4     4        e     u                    good
measure 42
F#4    4        e     u                    ti-
G4     2        s     u  [[                dings_
F#4    2        s     u  ]]                _
E4     2        s     u                    to
D4     2        s     u                    Je-
A4     4        e     u                    ru-
G4     2        s     u  [[                sa-
F#4    2        s     u  ]]                -
E4     4        e     u                    lem,
measure 43
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A3     4        e     u                    lift
measure 44
D4    12        q.    u                    up
rest   4        e
rest   4        e
B3     4        e     u                    thy
measure 45
E4    12        q.    u                    voice
rest   4        e
rest   4        e
C#4    4        e     u                    with
measure 46
F#4   12        q.    u                    strength,
rest   4        e
D4     4        e     u                    lift
D4     4        e     u                    it
measure 47
G4    12        q.    u                    up,
F#4    4        e     u                    be
E4     4        e     u                    not
D4     4        e     u                    a-
measure 48
A4    12        q.    u                    fraid,
rest   8        q
rest   4        e
measure 49
rest   4        e
rest   4        e
A4     4        e     u                    say
G4     2        s     u  [[                un-
F#4    2        s     u  ]]                -
E4     4        e     u                    to
G4     4        e     u                    the
measure 50
F#4    2        s     u  [[                ci-
E4     2        s     u  ]]                -
D4     4        e     u                    ties
F#4    4        e     u                    of
E4     4        e     u                    Ju-
A3     4        e     u                    dah,
rest   4        e
measure 51
rest   4        e
rest   4        e
A4     4        e     u                    say
G4     2        s     u  [[                un-
F#4    2        s     u  ]]                -
E4     4        e     u                    to
G4     4        e     u                    the
measure 52
F#4    2        s     u  [[                ci-
E4     2        s     u  ]]                -
D4     4        e     u                    ties
F#4    4        e     u                    of
E4     4        e     u                    Ju-
A3     4        e     u                    dah,
rest   4        e
measure 53
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    Be-
measure 54
B4    12-       q.    u        -           hold_
B4     8        q     u                    _
D4     4        e     u                    your
measure 55
C#4   12-       q.    u        -           God,_
C#4    8        q     u                    _
A4     4        e     u                    be-
measure 56
A4    12-       q.    u        -           hold_
A4     8        q     u                    _
C4     4        e     u                    your
measure 57
B3    12        q.    u                    God!
rest   4        e
rest   4        e
D4     4        e     u                    say
measure 58
D4     4        e     u                    un-
C#4    4        e     u         +          to
E4     4        e     u                    the
E4     4        e     u                    ci-
D4     4        e     u                    ties
F#4    4        e     u                    of
measure 59
F#4    4        e     u  [                 Ju-
E4     4        e     u  =                 -
G4     4        e     u  ]                 -
F#4    4        e     u  [                 -
E4     4        e     u  ]                 -
D4     4        e     u                    dah,
measure 60
rest   8        q
rest   4        e
rest   4        e
rest   4        e
D4     4        e     u                    be-
measure 61
A4    12-       q.    u        -           hold_
A4     8        q     u                    _
D4     4        e     u                    your
measure 62
G4    12-       q.    u        -           God,_
G4     8        q     u                    _
G4     4        e     u                    be-
measure 63
G4    12        q.    u                    hold
G4    12        q.    u                    your
measure 64
G4    12-       q.    u        -           God,_
G4    12-       q.    u        -           _
measure 65
G4    12-       q.    u        -           _
G4     8        q     u                    _
G4     4        e     u                    be-
measure 66
G4    12        q.    u                    hold
F#4   12        q.    u                    your
measure 67
G4    24        h.    u                    God!
measure 68
rest  24
measure 69
rest  24
measure 70
rest  24
measure 71
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    O!
measure 72
D4     8        q     u                    thou
E4     4        e     u                    that
C#4    4        e     u                    tell-
D4     4        e     u                    est
E4     4        e     u                    good
measure 73
F#4    4        e     u                    ti-
G4     4        e     u                    dings
F#4    4        e     u                    to
F#4    4        e     u                    Zi-
E4     4        e     u                    on,
rest   4        e
measure 74
rest  24
measure 75
rest   8        q
rest   4        e
rest   4        e
rest   4        e
E4     4        e     u                    a-
measure 76
A4     8        q     u                    rise,
rest   4        e
G4     8        q     u                    shine,
E4     4        e     u                    for
measure 77
F#4    4        e     u                    thy
G4     4        e     u                    light
F#4    4        e     u                    is
E4    12        q.    u                    come,
measure 78
rest  24
measure 79
rest   8        q
rest   4        e
rest   4        e
rest   2        s
E4     2        s     u  [[                a-
F#4    2        s     u  ==                -
G4     2        s     u  ]]                -
measure 80
F#4    2        s     u  [[                rise,_
E4     2        s     u  =]                _
D4     4        e     u  ]                 _
rest   4        e
rest   4        e
rest   2        s
G4     2        s     u  [[                a-
A4     2        s     u  ==                -
B4     2        s     u  ]]                -
measure 81
A4     2        s     u  [[                rise,_
G4     2        s     u  =]                _
F#4    4        e     u  ]                 _
rest   4        e
rest   4        e
rest   4        e
D4     4        e     u                    a-
measure 82
A4     8        q     u                    rise,
rest   4        e
G4     8        q     u                    shine,
E4     4        e     u                    for
measure 83
F#4    4        e     u                    thy
G4     4        e     u                    light
F#4    4        e     u                    is
E4    12        q.    u                    come,
measure 84
rest   8        q
rest   4        e
rest   4        e
A3     4        e     u                    and
A3     4        e     u                    the
measure 85
D4     2        s     u  [[                glo-
E4     2        s     u  ==                -
F#4    2        s     u  ==                -
D4     2        s     u  ==                -
E4     2        s     u  ==                -
C#4    2        s     u  ]]                -
B3     2        s     u  [[                -
D4     2        s     u  ==                -
C#4    2        s     u  ==                -
B3     2        s     u  ==                -
C#4    2        s     u  ==                -
D4     2        s     u  ]]                -
measure 86
E4     2        s     u  [[                -
F#4    2        s     u  ==                -
G4     2        s     u  ==                -
E4     2        s     u  ==                -
F#4    2        s     u  ==                -
D4     2        s     u  ]]                -
C#4    2        s     u  [[                -
E4     2        s     u  ==                -
D4     2        s     u  ==                -
C#4    2        s     u  ==                -
D4     2        s     u  ==                -
E4     2        s     u  ]]                -
measure 87
F#4    2        s     u  [[                -
G4     2        s     u  ==                -
A4     2        s     u  ==                -
F#4    2        s     u  ==                -
G4     2        s     u  ==                -
E4     2        s     u  ]]                -
D4     2        s     u  [[                -
C#4    2        s     u  =]                -
D4     4        e     u  ]                 -
F#4    4        e     u                    ry
measure 88
E4     8        q     u                    of
G4     4        e     u                    the
F#4   12        q.    u                    Lord,
measure 89
rest   8        q
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    the
measure 90
B4     4        e     u  [                 glo-
A4     4        e     u  ]                 -
G4     4        e     u                    ry
F#4    4        e     u  [                 of_
E4     4        e     u  ]                 _
D4     4        e     u                    the
measure 91
C4    24-       h.    u        -           Lord_
measure 92
C4    12-       q.    u        -           _
C4     8        q     u                    _
C4     4        e     u                    is
measure 93
C4     4        e     u  [                 ri-
B3     4        e     u  =                 -
D4     4        e     u  ]                 -
D4     4        e     u  [                 sen,_
C#4    4        e     u  ]                 _
E4     4        e     u                    is
measure 94
E4     4        e     u  [                 ri-
D4     4        e     u  =                 -
F#4    4        e     u  ]                 -
F#4    4        e     u  [                 sen_
E4     4        e     u  ]                 _
G4     4        e     u                    up-
measure 95
G4     4        e     u  [                 on_
F#4    4        e     u  =                 _
A4     4        e     u  ]                 _
A4     4        e     u  [                 thee,_
G4     4        e     u  ]                 _
B4     4        e     u                    is
measure 96
A4    12        q.    u                    ri-
A4     8        q     u                    sen,
G4     4        e     u                    is
measure 97
F#4    4        e     u  [                 ri-
E4     4        e     u  =                 -
G4     4        e     u  ]                 -
F#4    4        e     u  [                 sen_
G4     4        e     u  ]                 _
E4     4        e     u                    up-
measure 98
D4     4        e     u                    on
D4     4        e     u                    thee,
rest   4        e
rest   4        e
rest   4        e
E4     1        t     u  [[[               the_
F#4    1        t     u  ==]               _
G4     2        s     u  ]]                _
measure 99
F#4    2        s     u  [[                glo-
E4     2        s     u  ]]                -
D4     4        e     u                    ry,
rest   4        e
rest   4        e
rest   4        e
G4     1        t     u  [[[               the_
A4     1        t     u  ==]               _
B4     2        s     u  ]]                _
measure 100
A4     2        s     u  [[                glo-
G4     2        s     u  ]]                -
F#4    4        e     u                    ry,
rest   4        e
rest   4        e
rest   4        e
A4     4        e     u                    the
measure 101
B4     4        e     u  [                 glo-
A4     4        e     u  ]                 -
G4     4        e     u                    ry
F#4    4        e     u  [                 of_
E4     4        e     u  ]                 _
D4     4        e     u                    the
measure 102
C4    12-       q.    u        -           Lord_
C4    12-       q.    u        -           _
measure 103
C4    12        q.    u                    _
rest   4        e
rest   4        e
C4     4        e     u                    is
measure 104
B3    12        q.    u         (          ri-
G4    12        q.    u         )          -
measure 105
F#4   12        q.    u         (          sen_
E4     8        q     u         )          _
D4     4        e     u                    up-
measure 106
D4    12        q.    u                    on
D4     8-       q     u        -           thee.
*               D       (attacca il Coro)
*               X       D4
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-09/3} [KHM:1665492715]
TIMESTAMP: DEC/26/2001 [md5sum:9c182f696922858310e79a723d9fc980]
04/07/90 E. Correia
WK#:56        MV#:1,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
1 19
Group memberships: score
score: part 3 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:6/8   C:22   D:Andante
D3     1        e     u
measure 1
F#3    1        e     d  [
G3     1        e     d  =
E3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  ]
measure 2
D4     1        e     d  [
f1              6
E4     1        e     d  =
D4     1        e     d  ]
A3     2        q     d
G3     1        e     d
measure 3
F#3    2        q     d
D4     1        e     d
E3     2        q     d
f1              6
C#4    1        e     d
measure 4
D3     2        q     u
D4     1        e     d
C#4    2        q     d
A3     1        e     d
measure 5
F#3    2        q     d
D3     1        e     u
G2     1        e     u  [
B3     1        e     d  =
A3     1        e     d  ]
measure 6
G#3    2        q     d
G#2    1        e     u
A2     1        e     u  [
C#4    1        e     d  =
B3     1        e     d  ]
measure 7
A#3    2        q     d
A#2    1        e     u
B2     1        e     u  [
D3     1        e     u  =
B2     1        e     u  ]
measure 8
C#3    1        e     u  [
A2     1        e     u  =      +
C#3    1        e     u  ]
D3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
measure 9
B3     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
measure 10
f2              6 5
G#2    1        e     u  [
B2     1        e     u  =
A2     1        e     u  ]
f2              6 5
G#2    1        e     u  [
B2     1        e     u  =
A2     1        e     u  ]
measure 11
f2              6 5
G#2    1        e     u  [
B2     1        e     u  =
G#2    1        e     u  ]
A2     1        e     u  [
C#3    1        e     u  =
D3     1        e     u  ]
measure 12
G3     1        e     d  [
A3     1        e     d  =
A2     1        e     d  ]
D3     2        q     d
rest   1        e
measure 13
rest   1        e
F#3    1        e     d  [      p
G3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  ]
measure 14
D4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
A3     2        q     d
G3     1        e     d
measure 15
F#3    1        e     d  [
D3     1        e     d  =
G3     1        e     d  ]
A2     1        e     u  [
B2     1        e     u  =
C#3    1        e     u  ]
measure 16
D3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
A3     2        q     d
G3     1        e     d
measure 17
F#3    1        e     d  [
A3     1        e     d  =
D4     1        e     d  ]
C#4    2        q     d
A3     1        e     d
measure 18
D4     2        q     d
D3     1        e     u
A2     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
measure 19
F#3    2        q     d
D4     1        e     d
E3     2        q     d
C#4    1        e     d
measure 20
D4     2        q     d
D3     1        e     u
C#3    2        q     u
A3     1        e     d
measure 21
B3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  ]
A3     2        q     d
C#3    1        e     u
measure 22
D3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
A2     2        q     u
C#3    1        e     u
measure 23
D3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  ]
measure 24
D4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
A3     2        q     d
C#3    1        e     u
measure 25
D3     2        q     u
C#3    1        e     u
D3     1        e     u  [
C#3    1        e     u  =
B2     1        e     u  ]
measure 26
C#3    2        q     u
D4     1        e     d
C#4    1        e     d  [
B3     1        e     d  =
A3     1        e     d  ]
measure 27
D#3    3-       q.    u        -
D#3    3-       q.    u        -
measure 28
D#3    3        q.    u
E3     2        q     d
C#4    1        e     d
measure 29
D4     2        q     d
B3     1        e     d
C#4    2        q     d
A3     1        e     d
measure 30
D3     2        q     d
B3     1        e     d
C#3    1        e     d  [
A3     1        e     d  =
C#3    1        e     d  ]
measure 31
D3     1        e     d  [
B3     1        e     d  =
D3     1        e     d  ]
C#3    1        e     d  [
A3     1        e     d  =
C#3    1        e     d  ]
measure 32
D3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
B2     1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
measure 33
C#3    2        q     u
D4     1        e     d
C#4    1        e     d  [
B3     1        e     d  =
A3     1        e     d  ]
measure 34
D#3    3        q.    d
E3     2        q     d
F#3    1        e     d
measure 35
D3     1        e     u  [      +
E3     1        e     u  =
E2     1        e     u  ]
A2     2        q     u
D4     1        e     d
measure 36
C#4    2        q     d
C#3    1        e     u
D3     1        e     d  [
F#3    1        e     d  =
E3     1        e     d  ]
measure 37
D#3    2        q     u
B2     1        e     u
E3     1        e     d  [
G#3    1        e     d  =
E3     1        e     d  ]
measure 38
F#3    1        e     d  [
A3     1        e     d  =
F#3    1        e     d  ]
G#3    1        e     d  [
B3     1        e     d  =
G#3    1        e     d  ]
measure 39
A3     1        e     d  [
C#4    1        e     d  =
D4     1        e     d  ]
B3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  ]
measure 40
D3     1        e     u  [
E3     1        e     u  =
E2     1        e     u  ]
A2     1        e     u  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 41
B3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  ]
measure 42
D4     1        e     d  [
C#4    1        e     d  =
B3     1        e     d  ]
A3     2        q     d
C#3    1        e     u
measure 43
D3     1        e     u  [
C#3    1        e     u  =
B2     1        e     u  ]
A2     1        e     u  [
C#3    1        e     u  =
A2     1        e     u  ]
measure 44
F#3    1        e     d  [
D3     1        e     d  =
F#3    1        e     d  ]
G3     2        q     d
rest   1        e
measure 45
G#3    1        e     d  [
E3     1        e     d  =
G#3    1        e     d  ]
A3     2        q     d
rest   1        e
measure 46
A#3    1        e     d  [
F#3    1        e     d  =
A#3    1        e     d  ]
B3     2        q     d
rest   1        e
measure 47
B3     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]      +
D4     1        e     d  [
C#4    1        e     d  =
B3     1        e     d  ]
measure 48
F#3    2        q     d
D4     1        e     d
E3     2        q     d
C#4    1        e     d
measure 49
D4     2        q     d
F#3    1        e     d
E3     1        e     u  [
C#3    1        e     u  =
A2     1        e     u  ]
measure 50
D3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
E3     1        e     u  [
C#3    1        e     u  =
A2     1        e     u  ]
measure 51
D3     2        q     u
F#3    1        e     d
E3     1        e     u  [
C#3    1        e     u  =
A2     1        e     u  ]
measure 52
D3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  ]
A3     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 53
B3     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
measure 54
G#2    3-       q.    u        -
G#2    3        q.    u
measure 55
A2     3        q.    u
G2     3        q.    u         +
measure 56
F#2    3-       q.    u        -
F#2    3        q.    u
measure 57
G2     3        q.    u
F#3    3        q.    d
measure 58
f1     1        7
f1              6+
E3     2        q     d
G3     1        e     d
f1     1        7
f1              6
F#3    2        q     d
D3     1        e     u
measure 59
D3     1        e     d  [
C#3    1        e     d  =
E3     1        e     d  ]
D3     2        q     d
F#3    1        e     d
measure 60
E3     2        q     d
G3     1        e     d
F#3    2        q     d
D3     1        e     d
measure 61
D3     1        e     d  [
C#3    1        e     d  =
E3     1        e     d  ]
D3     2        q     d
D3     1        e     d
measure 62
E3     1        e     d  [
D3     1        e     d  =
C3     1        e     d  ]
B2     1        e     u  [
A2     1        e     u  =
G2     1        e     u  ]
measure 63
E4     1        e     d  [
D4     1        e     d  =
C4     1        e     d  ]
B3     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
measure 64
C2     3-       q.    u        -
C2     3        q.    u
measure 65
C#2    3-       q.    u        -+
C#2    3        q.    u
measure 66
D2     3-       q.    u        -
D2     3        q.    u
measure 67
G2     2        q     u
A2     1        e     u
B2     1        e     u  [
A2     1        e     u  =
G2     1        e     u  ]
measure 68
C3     3-       q.    u        -
C3     3        q.    u
measure 69
C#3    3-       q.    u        -+
C#3    3        q.    u
measure 70
D3     2        q     u
E3     1        e     d
C3     2        q     u
D3     1        e     u
measure 71
G2     3        q.    u
rest   1        e
rest   1        e
F#3    1        e     d
measure 72
B3     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
A3     2        q     d
C#3    1        e     u
measure 73
D3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
A3     2        q     d
F#3    1        e     d
measure 74
B3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  ]
measure 75
D4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
A3     2        q     d
G3     1        e     d
measure 76
F#3    1        e     d  [
D4     1        e     d  =
F#3    1        e     d  ]
E3     2        q     d
C#4    1        e     d
measure 77
D4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
A3     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 78
F#3    2        q     d
D4     1        e     d
E3     2        q     d
C#4    1        e     d
measure 79
D4     2        q     d
F#3    1        e     d
A3     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 80
D4     2        q     d
A3     1        e     d
D3     2        q     u
G2     1        e     u
measure 81
D3     2        q     u
G3     1        e     d
D4     2        q     d
D4     1        e     d
measure 82
F#3    1        e     d  [
D4     1        e     d  =
F#3    1        e     d  ]
E3     2        q     d
C#4    1        e     d
measure 83
D4     2        q     d
D3     1        e     d
A3     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 84
D4     1        e     d  [
C#4    1        e     d  =
D4     1        e     d  ]
A3     2        q     d
G3     1        e     d
measure 85
F#3    2        q     d
rest   1        e
G3     2        q     d
rest   1        e
measure 86
E3     2        q     d
rest   1        e
A3     2        q     d
rest   1        e
measure 87
f1              6
F#3    2        q     d
rest   1        e
B3     2        q     d
F#3    1        e     d
measure 88
G3     1        e     d  [
A3     1        e     d  =
A2     1        e     d  ]
D3     1        e     d  [
E3     1        e     d  =
F#3    1        e     d  ]
measure 89
G3     1        e     d  [
E3     1        e     d  =
A3     1        e     d  ]
D3     2        q     d
rest   1        e
measure 90
rest   6
measure 91
D2     6-       h.    u        -
measure 92
D2     3-       q.    u        -
D2     2        q     u
D3     1        e     u
measure 93
G3     2        q     d
F#3    1        e     d
E3     1        e     d  [
A3     1        e     d  =
G3     1        e     d  ]
measure 94
F#3    2        q     d
D3     1        e     u
D3     1        e     u  [
C#3    1        e     u  =
A2     1        e     u  ]
measure 95
D3     2        q     u
F#3    1        e     d
F#3    1        e     d  [
E3     1        e     d  =
G3     1        e     d  ]
measure 96
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
C#3    1        e     u  [
A2     1        e     u  =
C#3    1        e     u  ]
measure 97
D3     2        q     u
G2     1        e     u
A2     2        q     u
A3     1        e     d
measure 98
D4     2        q     d
A3     1        e     d
D3     2        q     u
C#3    1        e     u
measure 99
D3     2        q     u
C#4    1        e     d
D4     1        e     d  [
B3     1        e     d  =
G3     1        e     d  ]
measure 100
D4     2        q     d
G3     1        e     d
D3     2        q     u
rest   1        e
measure 101
rest   6
measure 102
D2     3-       q.    u        -
D2     3-       q.    u        -
measure 103
D2     3        q.    u
rest   1        e
rest   1        e
F#3    1        e     d
measure 104
G3     3        q.    d
E3     3        q.    d
measure 105
A3     3        q.    d
A2     3        q.    u
measure 106
D3     3        q.    u
D2     2-       q     u        -
*               D       (attacca il Coro)
*               X       D2
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
