&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-18/1} [KHM:283412393]
TIMESTAMP: DEC/26/2001 [md5sum:d93948b2586a4a51a9019250f3cf0eb1]
04/09/90 E. Correia
WK#:56        MV#:1,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
1 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
D6     1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
D6     1        s     d  ]]
D6     1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
D6     1        s     d  ]]
measure 2
B5     1        s     d  [[
G5     1        s     d  ==
G5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
G5     1        s     d  ==
G5     1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
measure 3
G5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
G5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
G5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
G5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
G5     1        s     d  ]]
measure 4
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
measure 5
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
measure 6
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
measure 7
A5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
measure 8
A5     1        s     d  [[
E5     1        s     d  ==
E5     1        s     d  ==
A5     1        s     d  ]]
G#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
G#5    1        s     d  ]]
A5     4        q     d
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-18/2} [KHM:283412393]
TIMESTAMP: DEC/26/2001 [md5sum:f17207c70e4ddf5c0bd2cab84792c494]
04/09/90 E. Correia
WK#:56        MV#:1,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
1 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
measure 2
G5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
G5     1        s     d  ]]
G5     1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
measure 3
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
measure 4
D5     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
D5     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
D5     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
D5     1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
measure 5
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
measure 6
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
D5     1        s     d  ]]
C#5    1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
C#5    1        s     d  ]]
C#5    1        s     d  [[
A4     1        s     d  ==
A4     1        s     d  ==
C#5    1        s     d  ]]
measure 7
C#5    1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
C#5    1        s     d  ]]
C#5    1        s     d  [[
A5     1        s     d  ==
A5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
measure 8
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
E5     1        s     d  ]]
E5     1        s     d  [[
B4     1        s     d  ==
B4     1        s     d  ==
D5     1        s     d  ]]
C#5    4        q     d
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-18/3} [KHM:283412393]
TIMESTAMP: DEC/26/2001 [md5sum:34f1750db02d6df27e58bf951142407c]
04/09/90 E. Correia
WK#:56        MV#:1,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
1 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:13   D:Allegro
*               D       con Violoncello
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 2
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 3
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 4
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 5
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
measure 6
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
A3     1        e     u  [
A3     1        e     u  =
A3     1        e     u  =
A3     1        e     u  ]
measure 7
A3     1        e     u  [
A3     1        e     u  =
A3     1        e     u  =
A3     1        e     u  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 8
E4     1        e     d  [
E4     1        e     d  =
E4     1        e     d  =
E4     1        e     d  ]
A3     2        q     u
rest   2        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-18/4} [KHM:283412393]
TIMESTAMP: DEC/26/2001 [md5sum:8817fd046fcc38ef5966c40a8324763e]
04/09/90 E. Correia
WK#:56        MV#:1,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Soprano
1 72 S
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u                    And
measure 4
D5     3        e.    d                    sud-
D5     1        s     d                    den-
D5     4        q     d                    ly
rest   2        e
D5     2        e     d                    there
D5     2        e     d                    was
E5     1        s     d                    with
F#5    1        s     d                    the
measure 5
E5     2        e     d                    an-
E5     2        e     d                    gel
rest   2        e
E5     2        e     d                    a
E5     3        e.    d                    mul-
B4     1        s     u                    ti-
B4     4        q     u                    tude
measure 6
D5     2        e     d                    of
D5     2        e     d                    the
E5     2        e     d                    heav'n-
B4     2        e     u                    ly
C#5    4        q     d                    host,
rest   4        q
measure 7
rest   4        q
E5     2        e     d                    prais-
C#5    2        e     d                    ing
F#5    4        q     d                    God,
rest   2        e
A5     2        e     d                    and
measure 8
E5     4        q     d                    say-
E5     4        q     d                    ing:
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-18/5} [KHM:283412393]
TIMESTAMP: DEC/26/2001 [md5sum:cee31b768d7e76a5f14886189c771939]
04/09/90 E. Correia
WK#:56        MV#:1,18
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
1 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:12   D:Allegro
*               D       (Violoncello)
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 2
f2              6 4
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
f2              5 3
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 3
f3              7# 4 2
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 4
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 5
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
measure 6
G#3    1        e     u  [
G#3    1        e     u  =
G#3    1        e     u  =
G#3    1        e     u  ]
A3     1        e     u  [
A3     1        e     u  =
A3     1        e     u  =
A3     1        e     u  ]
measure 7
A3     1        e     u  [
A3     1        e     u  =
A3     1        e     u  =
A3     1        e     u  ]
D4     1        e     d  [
D4     1        e     d  =
D4     1        e     d  =
D4     1        e     d  ]
measure 8
f1              4
E4     1        e     d  [
E4     1        e     d  =
f1              #
E4     1        e     d  =
E4     1        e     d  ]
A3     2        q     u
rest   2        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
