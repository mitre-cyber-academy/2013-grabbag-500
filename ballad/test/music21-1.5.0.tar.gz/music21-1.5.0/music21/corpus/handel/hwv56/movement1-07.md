&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/1} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:82dbe5263eb9b6ea883167d6abfbdf08]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
0 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest   8        h
rest   2        e
D5     2        e     d  [      p&i
G5     2        e     d  =       &i
D5     2        e     d  ]       &i
measure 3
rest  16
measure 4
rest   8        h
rest   2        e
D5     2        e     d  [      &i
Bf5    2        e     d  =      &i
D5     2        e     d  ]      &i
measure 5
C#5    2        e     d
D5     4        q     d
C#5    2        e     d
D5     2        e     d
D6     4        q     d
C#6    2        e     d
measure 6
D6     2        e     d  [
D5     2        e     d  ]
rest   4        q
rest   2        e
A4     2        e     d  [
D5     2        e     d  =
A4     2        e     d  ]
measure 7
rest  16
measure 8
rest  16
measure 9
rest   8        h
rest   2        e
D5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  ]
measure 10
rest   8        h
rest   2        e
A5     2        e     d  [
D6     2        e     d  =
A5     2        e     d  ]
measure 11
rest   8        h
rest   2        e
E4     2        e     u  [
A4     2        e     u  =
E4     2        e     u  ]
measure 12
rest   8        h
rest   2        e
F5     2        e     d  [
A5     2        e     d  =
F5     2        e     d  ]
measure 13
rest  16
measure 14
rest  16
measure 15
rest   4        q
rest   2        e
D5     2        e     d         &mf
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
measure 16
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
measure 17
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
measure 18
B4     2        e     u  [
G4     2        e     u  ]
C5     8        h     d
B4     4        q     u
measure 19
rest   2        e
C5     2        e     d
Af5    8        h     d
G5     4-       q     d        -
measure 20
G5     4        q     d
F5     4        q     d
G5     2        e     d  [
B4     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 21
Ef5    1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==     +
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
measure 22
F5     1        s     d  [[
Ef5    1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
F5     1        s     d  [[
G5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
D5     1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
measure 23
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
Af5    1        s     d  ]]
G5     1        s     d  [[
Af5    1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
Ef5    2        e     d  [
C5     2        e     d  ]
F5     4-       q     d        -
measure 24
F5     2        e     d  [
F5     2        e     d  =
Ef5    2        e     d  =
Ef5    2        e     d  ]
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 25
Ef5    2        e     d  [
G5     2        e     d  =      &i
C6     2        e     d  =      &i
G5     2        e     d  ]      &i
rest   8        h
measure 26
rest   4        q
rest   2        e
B5     2        e     d
C6     4        q     d
G5     4        q     d
measure 27
Ef5    2        e     d  [
F5     2        e     d  ]
D5     4        q     d         &t
C5     4        q     d
rest   4        q
measure 28
rest  16
measure 29
rest   4        q
rest   2        e
C6     2        e     d
F5     4        q     d
G5     4        q     d
measure 30
A5     2        e     d  [
Bf5    2        e     d  ]
G5     4        q     d         &t
F5     4        q     d
rest   4        q
measure 31
rest  16
measure 32
rest  16
measure 33
rest   4        q
rest   2        e
F5     2        e     d
Bf4    4        q     u
C5     4        q     d
measure 34
D5     3        e.    d  [
Ef5    1        s     d  ]\
C5     4        q     d         &t
Bf4    2        e     d  [
Bf5    2        e     d  ]
C6     4        q     d
measure 35
F5     2        e     d  [
G5     1        s     d  =[     (
Bf5    1        s     d  ]]     )
A5     4        q     d         &t
Bf5    2        e     d  [
D5     2        e     d  =
F5     2        e     d  =
C5     2        e     d  ]
measure 36
D5     4        q     d
rest   4        q
F5     4        q     d
rest   4        q
measure 37
Ef5    4        q     d
rest   4        q
D5     4        q     d
rest   4        q
measure 38
F#5    2        e     d  [
A4     2        e     d  =
D5     2        e     d  =
F#4    2        e     d  ]
rest   8        h
measure 39
rest   4        q
rest   2        e
F#5    2        e     d
G5     4        q     d
F#5    4        q     d
measure 40
G5     4        q     d
F#5    4        q     d
G5     4        q     d
rest   4        q
measure 41
D5     4        q     d
rest   2        e
F#5    2        e     d
G5     4        q     d
rest   4        q
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
rest   2        e
D5     2        e     d
measure 44
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 45
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ]]
measure 46
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
A4     1        s     d  ]]
Bf4    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
measure 47
A4     2        e     d  [
A5     2        e     d  =
D6     2        e     d  =
D6     2        e     d  ]
C6     1        s     d  [[
D6     1        s     d  ==
C6     1        s     d  ==
Bf5    1        s     d  ]]
C6     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 48
Bf5    1        s     d  [[
C6     1        s     d  ==
Bf5    1        s     d  ==
A5     1        s     d  ]]
Bf5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
Bf5    1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 49
G5     2        e     d  [
D5     2        e     d  ]
Ef5    8        h     d
D5     4-       q     d        -
measure 50
D5     4        q     d
C5     4-       q     d        -
C5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
G5     1        s     d  ]]
measure 51
F#5    1        s     d  [[
G5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
measure 52
Bf5    1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
C6     1        s     d  ]]
Bf5    1        s     d  [[
C6     1        s     d  ==
Bf5    1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
Bf5    1        s     d  ]]
measure 53
C6     1        s     d  [[
Bf5    1        s     d  ==
C6     1        s     d  ==
D6     1        s     d  ]]
C6     1        s     d  [[
D6     1        s     d  ==
C6     1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
C6     1        s     d  ]]
measure 54
D6     2        e     d  [
D5     2        e     d  ]
D6     8        h     d
C6     4-       q     d        -
measure 55
C6     4        q     d
Bf5    4        q     d
A5     6        q.    d         &t
G5     2        e     d
measure 56
G5     2        e     d  [
D5     2        e     d  =
G5     2        e     d  =
F5     2        e     d  ]      +
Ef5    2        e     d  [
D5     2        e     d  ]
C5     4-       q     d        -
measure 57
C5     2        e     d  [
D5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  ]
A4     6        q.    u         &t
G4     2        e     u
measure 58
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/2} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:aad4f3729b125820ffb990f61a79e0ed]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
0 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest   8        h
rest   2        e
Bf4    2        e     d  [      &p
D5     2        e     d  =
Bf4    2        e     d  ]
measure 3
rest  16
measure 4
rest   8        h
rest   2        e
Bf4    2        e     d  [
D5     2        e     d  =
Bf4    2        e     d  ]
measure 5
A4     6        q.    u
E4     2        e     u
F4     2        e     d  [
F5     2        e     d  =
G5     2        e     d  =
G4     2        e     d  ]
measure 6
A4     4        q     u
rest   4        q
rest   2        e
F4     2        e     u  [
A4     2        e     u  =
F4     2        e     u  ]
measure 7
rest  16
measure 8
rest  16
measure 9
rest   8        h
rest   2        e
F4     2        e     u  [
Bf4    2        e     u  =
A4     2        e     u  ]
measure 10
rest   8        h
rest   2        e
F5     2        e     d  [
A5     2        e     d  =
F5     2        e     d  ]
measure 11
rest   8        h
rest   2        e
C4     2        e     u  [
E4     2        e     u  =
C4     2        e     u  ]
measure 12
rest   8        h
rest   2        e
D5     2        e     d  [
F5     2        e     d  =
D5     2        e     d  ]
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest   2        e
F4     2        e     u         &mf
Bf4    8        h     u
A4     4-       q     u        -
measure 17
A4     4        q     u
G4     8        h     u
F#4    2        e     u  [
D5     2        e     u  ]
measure 18
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
F5     1        s     d  [[     +
G5     1        s     d  ==
F5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 19
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Bf4    1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ]]
measure 20
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
B4     2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
measure 21
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
Bf4    1        s     d  ==     +
C5     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
A4     1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
C5     1        s     u  ]]
measure 22
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
B4     1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 23
Ef5    1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
measure 24
B4     2        e     d  [
B5     2        e     d  =
C6     2        e     d  =
C6     2        e     d  ]
C6     2        e     d  [
C6     2        e     d  ]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
measure 25
C6     2        e     d  [
Ef5    2        e     d  =
G5     2        e     d  =
Ef5    2        e     d  ]
rest   8        h
measure 26
rest   4        q
rest   2        e
D5     2        e     d
Ef5    4        q     d
D5     4        q     d
measure 27
C5     2        e     d  [
C5     2        e     d  ]
B4     4        q     d
C5     4        q     d
rest   4        q
measure 28
rest  16
measure 29
rest   4        q
rest   2        e
G4     2        e     u
Bf4    2        e     u  [
C5     2        e     u  =
D4     2        e     u  =
E4     2        e     u  ]
measure 30
F4     2        e     u  [
F5     2        e     u  ]
E5     4        q     d
F5     4        q     d
rest   4        q
measure 31
rest  16
measure 32
rest  16
measure 33
rest   4        q
rest   2        e
A4     2        e     u
F4     4        q     u
A4     4        q     u
measure 34
Bf4    4        q     u
A4     2        e     d  [
F5     2        e     d  ]
Ef5    6        q.    d
F5     2        e     d
measure 35
D5     2        e     d  [
Ef5    2        e     d  ]
C5     4        q     d
D5     2        e     d  [
Bf4    2        e     d  =
D5     2        e     d  =
A4     2        e     d  ]
measure 36
Bf4    4        q     u
rest   4        q
C5     4        q     d
rest   4        q
measure 37
C5     4        q     d
rest   4        q
Bf4    4        q     u
rest   4        q
measure 38
D5     2        e     u  [
F#4    2        e     u  =
A4     2        e     u  =
D4     2        e     u  ]
rest   8        h
measure 39
rest   4        q
rest   2        e
A4     2        e     u
Bf4    4        q     u
C5     4        q     d
measure 40
D5     2        e     d  [
Ef5    2        e     d  ]
C5     4        q     d
Bf4    4        q     u
rest   4        q
measure 41
Bf4    4        q     u
rest   2        e
A4     2        e     u
Bf4    4        q     u
rest   4        q
measure 42
rest   4        q
Bf4    8        h     u
Af4    4-       q     u        -
measure 43
Af4    4        q     u
G4     8        h     u
F#4    4        q     u
measure 44
D4     1        s     u  [[
C5     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ]]
Bf4    1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Ef5    1        s     d  ]]
A4     4        q     u
D4     4        q     u
measure 45
rest  16
measure 46
rest   8        h
rest   2        e
D5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  ]
measure 47
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
measure 48
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
C5     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
measure 49
Bf4    1        s     u  [[
C5     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ]]
Bf4    1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
F4     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ]]
measure 50
G4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
Bf4    2        e     d  ]
measure 51
A4     1        s     u  [[
Bf4    1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
Bf4    1        s     u  [[
C5     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 52
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 53
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
Bf5    1        s     d  ]]
A5     1        s     d  [[
Bf5    1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 54
Bf5    2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
G5     2        e     d  [
G4     2        e     d  ]
G5     1        s     d  [[
Bf5    1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
measure 55
F#5    4        q     d
G5     8        h     d
F#5    4        q     d
measure 56
G5     4        q     d
D5     4        q     d
C5     2        e     u  [
Bf4    2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 57
F#4    4        q     u
G4     8        h     u
F#4    4        q     u
measure 58
G4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/3} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:4a804b9209c67597ce02b538a5955846]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
0 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:13   D:Allegro
rest  16
measure 2
rest   8        h
rest   2        e
G4     2        e     d  [      &p
G4     2        e     d  =
G3     2        e     d  ]
measure 3
rest  16
measure 4
rest   8        h
rest   2        e
D4     2        e     d
G4     4        q     d
measure 5
E4     2        e     d  [
F4     1        s     d  =[
G4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
A4     4        q     d
E4     4        q     d
measure 6
D4     4        q     d
rest   4        q
rest   2        e
D4     2        e     u  [
D4     2        e     u  =
D3     2        e     u  ]
measure 7
rest  16
measure 8
rest  16
measure 9
rest   8        h
rest   2        e
F4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
measure 10
rest   8        h
rest   2        e
D4     2        e     d  [
F4     2        e     d  =
D4     2        e     d  ]
measure 11
rest   8        h
rest   2        e
E4     2        e     d  [
C4     2        e     d  =
E4     2        e     d  ]
measure 12
rest   8        h
rest   2        e
D3     2        e     u  [
D4     2        e     u  =
A4     2        e     u  ]
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest   4        q
rest   2        e
F4     2        e     d         &mf
G4     2        e     d  [
G4     2        e     d  =
Ef4    2        e     d  =
F4     2        e     d  ]
measure 17
F4     4        q     d
D4     4        q     d
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 18
D4     2        e     d  [
D4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
D4     2        e     d  [
Ef4    2        e     d  =
D4     2        e     d  =
B4     2        e     d  ]
measure 19
G4     4        q     d
C4     2        e     d  [
Af4    2        e     d  ]
F4     4        q     d
D4     2        e     d  [
G4     2        e     d  ]
measure 20
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
D4     2        e     d  [
D4     2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
measure 21
Ef4    2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
C4     2        e     u  [
C4     2        e     u  ]
F4     4-       q     d        -
measure 22
F4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  ]
G4     4-       q     d        -
measure 23
G4     2        e     d  [
Bf4    2        e     d  =
Bf4    2        e     d  =
Bf4    2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 24
D4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 25
G4     4        q     d
rest   4        q
rest   8        h
measure 26
rest   4        q
rest   2        e
G4     2        e     d
G4     4        q     d
G4     4        q     d
measure 27
G4     2        e     d  [
Af4    2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
Ef4    4        q     d
rest   4        q
measure 28
rest  16
measure 29
rest   4        q
rest   2        e
E4     2        e     d
D4     2        e     d  [
C4     2        e     d  ]
Bf4    4        q     d
measure 30
A4     2        e     d  [
D5     2        e     d  =
G4     2        e     d  =
C5     2        e     d  ]
C4     4        q     u
rest   4        q
measure 31
rest  16
measure 32
rest  16
measure 33
rest   4        q
rest   2        e
C4     2        e     u
D4     4        q     d
F4     4        q     d
measure 34
F4     2        e     d  [
G4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
Ef4    2        e     d  [
G4     2        e     d  ]
F4     4        q     d
measure 35
Bf4    4        q     d
F4     4        q     d
F4     4        q     d
rest   2        e
F4     2        e     d
measure 36
F4     4        q     d
rest   4        q
A4     4        q     d
rest   4        q
measure 37
G4     4        q     d
rest   4        q
G4     4        q     d
rest   4        q
measure 38
A4     2        e     d  [
D4     2        e     d  =
F#4    2        e     d  =
A4     2        e     d  ]
rest   8        h
measure 39
rest   4        q
rest   2        e
D4     2        e     d
D4     4        q     d
A4     4        q     d
measure 40
G4     4        q     d
C5     4        q     d
D4     4        q     d
rest   4        q
measure 41
G4     4        q     d
rest   2        e
D4     2        e     d
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 42
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
Ef4    1        s     d  ]]
F4     1        s     d  [[
D4     1        s     d  ==
C4     1        s     d  ==
D4     1        s     d  ]]
Ef4    1        s     d  [[
F4     1        s     d  ==
Ef4    1        s     d  ==
D4     1        s     d  ]]
Ef4    1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]
measure 43
D4     1        s     d  [[
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]
D4     1        s     d  [[
Bf3    1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ]]
C4     1        s     d  [[
D4     1        s     d  ==
C4     1        s     d  ==
Bf3    1        s     d  ]]
C4     1        s     u  [[
A3     1        s     u  ==
G3     1        s     u  ==
A3     1        s     u  ]]
measure 44
Bf3    4        q     u
rest   4        q
rest   4        q
Bf3    4-       q     u        -
measure 45
Bf3    4        q     u
Af3    8        h     u
G3     4-       q     u        -
measure 46
G3     4        q     u
F#3    4        q     u
G3     2        e     u  [
G3     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 47
D4     4        q     d
rest   2        e
G4     2        e     d
G4     4        q     d
rest   2        e
A4     2        e     d
measure 48
F4     2        e     d  [
D4     2        e     d  ]
G4     4-       q     d        -
G4     4        q     d
F#4    2        e     d  [
D4     2        e     d  ]
measure 49
D4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
Ef4    2        e     d  ]
C4     4        q     u
F4     4        q     d
measure 50
Bf3    4        q     u
C4     4        q     u
A3     2        e     d  [
D4     2        e     d  ]
D4     4        q     d
measure 51
D4     4        q     d
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 52
rest   2        e
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
E4     6        q.    d
E4     2        e     d
measure 53
E4     4        q     d
D4     2        e     d  [
E4     2        e     d  ]
F#4    2        e     d  [
A4     2        e     d  ]
D5     4        q     d
measure 54
G4     2        e     d  [
A4     2        e     d  =
Bf4    2        e     d  =
D4     2        e     d  ]
Ef4    6        q.    d         +
Ef4    2        e     d
measure 55
A3     2        e     u  [
D4     2        e     u  ]
D4     4        q     d
D4     6        q.    d
D4     2        e     d
measure 56
D4     6        q.    d
G4     2        e     d
G4     4        q     d
C4     4        q     u
measure 57
D4     4        q     d
D4     4        q     d
D4     4        q     d
A3     4        q     u
measure 58
Bf3   16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/4} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:9fb0fde8a10ba01ef2910e28988d2121]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
0 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Allegro
rest   4        q
rest   2        e
D5     2        e     d                    And
G4     4        q     u                    he
A4     4        q     u                    shall
measure 2
Bf4    2        e     d  [                 pu-
C5     2        e     d  ]                 -
A4     4        q     u                    ri-
G4     4        q     u                    fy,
rest   2        e
D5     2        e     d                    and
measure 3
G5     2        e     d                    he
G5     2        e     d                    shall
G5     2        e     d                    pu-
G5     2        e     d                    ri-
F5     1        s     d  [[                fy_
G5     1        s     d  ==                _
F5     1        s     d  ==                _
Ef5    1        s     d  ]]                _
F5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
measure 4
Ef5    1        s     d  [[                _
F5     1        s     d  ==                _
Ef5    1        s     d  ==                _
D5     1        s     d  ]]                _
Ef5    1        s     d  [[                _
C5     1        s     d  ==                _
Bf4    1        s     d  ==                _
C5     1        s     d  =]                _
D5     2        e     d  ]                 _
G4     2        e     u                    the
G5     4-       q     d        -           sons_
measure 5
G5     2        e     d                    _
F5     2        e     d                    of
E5     4        q     d                    Le-
D5     4        q     d                    vi,
rest   4        q
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest   4        q
rest   2        e
D5     2        e     d                    and
G5     2        e     d                    he
G5     2        e     d                    shall
G5     2        e     d                    pu-
G5     2        e     d                    ri-
measure 16
F5     1        s     d  [[                fy_
G5     1        s     d  ==                _
F5     1        s     d  ==                _
Ef5    1        s     d  ]]                _
F5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
Ef5    1        s     d  [[                _
F5     1        s     d  ==                _
Ef5    1        s     d  ==                _
D5     1        s     d  ]]                _
Ef5    1        s     d  [[                _
C5     1        s     d  ==                _
Bf4    1        s     d  ==                _
C5     1        s     d  ]]                _
measure 17
D5     1        s     d  [[                _
Ef5    1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
D5     1        s     d  [[                _
Bf4    1        s     d  ==                _
A4     1        s     d  ==                _
Bf4    1        s     d  ]]                _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
C5     1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  =]                _
measure 18
B4     2        e     u  ]                 _
G4     2        e     u                    the
C5     2        e     d                    sons
C5     2        e     d                    of
C5     4        q     d         (          Le-
B4     4        q     d         )          -
measure 19
C5     4        q     d                    vi,
rest   4        q
rest   4        q
rest   2        e
G4     2        e     u                    the
measure 20
C5     6        q.    d                    sons
C5     2        e     d                    of
B4     4        q     u                    Le-
B4     4        q     u                    vi,
measure 21
rest   2        e
C5     2        e     d                    that
C5     2        e     d                    they
Bf4    2        e     u         +          may
A4     6        q.    u                    of-
C5     2        e     d                    fer
measure 22
D5     4        q     d                    un-
D5     2        e     d                    to
C5     2        e     d                    the
B4     6        q.    d                    Lord
D5     2        e     d                    an
measure 23
Ef5    2        e     d                    of-
Ef5    2        e     d                    fer-
Ef5    2        e     d                    ing
D5     2        e     d                    in
C5     6        q.    d                    righ-
C5     2        e     d                    teous-
measure 24
B4     4        q     u                    ness,
C5     4        q     d                    in
C5     4        q     d                    righ-
B4     4        q     u                    teous-
measure 25
C5     4        q     d                    ness.
rest   2        e
G5     2        e     d                    And
C5     4        q     d                    he
D5     4        q     d                    shall
measure 26
Ef5    2        e     d  [                 pu-
F5     2        e     d  ]                 -
D5     4        q     d                    ri-
C5     4        q     d                    fy,
rest   4        q
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest   4        q
rest   2        e
C5     2        e     d                    and
F5     2        e     d                    he
F5     2        e     d                    shall
F5     2        e     d                    pu-
F5     2        e     d                    ri-
measure 31
Ef5    1        s     d  [[                fy,_
F5     1        s     d  ==                _
Ef5    1        s     d  ==                _
D5     1        s     d  ]]                _
Ef5    1        s     d  [[                _
C5     1        s     d  ==                _
Bf4    1        s     d  ==                _
C5     1        s     d  ]]                _
D5     1        s     d  [[                _
Ef5    1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
D5     1        s     d  [[                _
Bf4    1        s     d  ==                _
A4     1        s     d  ==                _
Bf4    1        s     d  ]]                _
measure 32
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
C5     1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
Bf4    4        q     u                    _
C5     4        q     d                    shall
measure 33
D5     2        e     d  [                 pu-
Ef5    2        e     d  ]                 -
C5     4        q     d                    ri-
Bf4    4        q     u                    fy,
rest   4        q
measure 34
rest   4        q
rest   2        e
F5     2        e     d                    and
Bf4    4        q     u                    he
C5     4        q     d                    shall
measure 35
D5     2        e     d  [                 pu-
Ef5    2        e     d  ]                 -
C5     4        q     d                    ri-
Bf4    4        q     u                    fy,
rest   4        q
measure 36
rest   4        q
rest   2        e
Bf4    2        e     u                    and
F5     2        e     d                    he
F5     2        e     d                    shall
F5     2        e     d                    pu-
F5     2        e     d                    ri-
measure 37
Ef5    2        e     d                    fy
D5     2        e     d                    the
Ef5    2        e     d                    sons,
C5     2        e     d                    the
D5     2        e     d  [                 sons_
C5     2        e     d  ]                 _
D5     2        e     d  [                 of_
E5     2        e     d  ]                 _
measure 38
F#5    3        e.    d  [                 Le-
E5     1        s     d  ]\                -
D5     4        q     d                    vi,
rest   8        h
measure 39
rest   4        q
rest   2        e
F#5    2        e     d                    and
G5     4        q     d                    he
F#5    4        q     d                    shall
measure 40
G5     2        e     d  [                 pu-
Ef5    2        e     d  ]                 -
C5     4        q     d                    ri-
Bf4    4        q     u                    fy,
rest   4        q
measure 41
rest  16
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
rest   2        e
D5     2        e     d                    and
measure 44
G5     2        e     d                    he
G5     2        e     d                    shall
G5     2        e     d                    pu-
G5     2        e     d                    ri-
F5     1        s     d  [[                fy,_
G5     1        s     d  ==                _
F5     1        s     d  ==                _
Ef5    1        s     d  ]]                _
F5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
measure 45
Ef5    1        s     d  [[                _
F5     1        s     d  ==                _
Ef5    1        s     d  ==                _
D5     1        s     d  ]]                _
Ef5    1        s     d  [[                _
C5     1        s     d  ==                _
Bf4    1        s     d  ==                _
C5     1        s     d  ]]                _
D5     1        s     d  [[                _
Ef5    1        s     d  ==                _
D5     1        s     d  ==                _
C5     1        s     d  ]]                _
D5     1        s     d  [[                _
Bf4    1        s     d  ==                _
A4     1        s     d  ==                _
Bf4    1        s     d  ]]                _
measure 46
C5     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
C5     1        s     d  [[                _
A4     1        s     d  ==                _
G4     1        s     d  ==                _
A4     1        s     d  ]]                _
Bf4    1        s     d  [[                _
C5     1        s     d  ==                _
Bf4    1        s     d  ==                _
A4     1        s     d  ]]                _
Bf4    1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
measure 47
A4     4        q     u                    _
rest   4        q
rest   4        q
rest   2        e
A4     2        e     u                    and
measure 48
D5     2        e     d                    he
D5     2        e     d                    shall
D5     2        e     d                    pu-
D5     2        e     d                    ri-
C5     1        s     d  [[                fy_
D5     1        s     d  ==                _
C5     1        s     d  ==                _
Bf4    1        s     d  ]]                _
C5     1        s     d  [[                _
A4     1        s     d  ==                _
G4     1        s     d  ==                _
A4     1        s     d  ]]                _
measure 49
Bf4    1        s     u  [[                _
C5     1        s     u  ==                _
Bf4    1        s     u  ==                _
A4     1        s     u  ]]                _
Bf4    1        s     u  [[                _
G4     1        s     u  ==                _
F4     1        s     u  ==                _
G4     1        s     u  =]                _
A4     2        e     u  ]                 _
A4     2        e     u                    the
D5     4-       q     d        -           sons_
measure 50
D5     4        q     d                    _
C5     8        h     d                    _
Bf4    4        q     u                    _
measure 51
A4     4        q     u                    _
Bf4    4        q     u                    of
A4     4        q     u                    Le-
A4     4        q     u                    vi,
measure 52
rest   2        e
G5     2        e     d                    that
G5     2        e     d                    they
F5     2        e     d                    may
E5     6        q.    d                    of-
G5     2        e     d                    fer
measure 53
A5     4        q     d                    un-
A5     2        e     d                    to
G5     2        e     d                    the
F#5    4        q     d                    Lord
D5     4        q     d                    an
measure 54
D5     2        e     d                    of-
D5     2        e     d                    fer-
D5     2        e     d                    ing
D5     2        e     d                    in
D5     4        q     d                    righ-
C5     4        q     d                    teous-
measure 55
C5     4        q     d                    ness,
Bf4    4        q     u                    in
A4     6        q.    u                    righ-
A4     2        e     u                    teous-
measure 56
G4     8        h     u                    ness.
rest   8        h
measure 57
rest  16
measure 58
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/5} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:4501570db373abe92389c2c5e10238a5]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
0 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest   4        q
rest   2        e
A4     2        e     u                    And
D4     4        q     u                    he
E4     4        q     u                    shall
measure 10
F4     3        e.    u  [                 pu-
G4     1        s     u  ]\                -
E4     4        q     u                    ri-
D4     4        q     u                    fy,
rest   4        q
measure 11
rest  16
measure 12
rest   8        h
rest   4        q
rest   2        e
D4     2        e     u                    and
measure 13
G4     2        e     u                    he
G4     2        e     u                    shall
G4     2        e     u                    pu-
G4     2        e     u                    ri-
F4     1        s     u  [[                fy_
G4     1        s     u  ==                _
F4     1        s     u  ==                _
Ef4    1        s     u  ]]                _
F4     1        s     u  [[                _
D4     1        s     u  ==                _
C4     1        s     u  ==                _
D4     1        s     u  ]]                _
measure 14
Ef4    1        s     u  [[                _
F4     1        s     u  ==                _
Ef4    1        s     u  ==                _
D4     1        s     u  ]]                _
Ef4    1        s     u  [[                _
C4     1        s     u  ==                _
Bf3    1        s     u  ==                _
C4     1        s     u  ]]                _
D4     1        s     u  [[                _
Ef4    1        s     u  ==                _
D4     1        s     u  ==                _
C4     1        s     u  ]]                _
D4     1        s     u  [[                _
Bf3    1        s     u  ==                _
A3     1        s     u  ==                _
Bf3    1        s     u  ]]                _
measure 15
C4     1        s     u  [[                _
D4     1        s     u  ==                _
C4     1        s     u  ==                _
Bf3    1        s     u  ]]                _
C4     1        s     u  [[                _
A3     1        s     u  ==                _
G3     1        s     u  ==                _
A3     1        s     u  ]]                _
Bf3    4        q     u                    _
rest   4        q
measure 16
rest   2        e
F4     2        e     u                    the
Bf4    8        h     u                    sons_
A4     4-       q     u        -           _
measure 17
A4     4        q     u                    _
G4     4        q     u                    of
G4     4        q     u         (          Le-
F#4    3        e.    u  [                 -
E4     1        s     u  ]\     )          -
measure 18
D4     4        q     u                    vi,
rest   4        q
rest   8        h
measure 19
rest   2        e
C4     2        e     u                    the
Af4    8        h     u                    sons_
G4     4-       q     u        -           _
measure 20
G4     4        q     u                    _
F4     4        q     u                    of
G4     4        q     u                    Le-
G4     4        q     u                    vi,
measure 21
rest   2        e
G4     2        e     u                    that
G4     2        e     u                    they
G4     2        e     u                    may
A4     6        q.    u                    of-
G4     2        e     u                    fer
measure 22
A4     4        q     u                    un-
A4     2        e     u                    to
A4     2        e     u                    the
G4     6        q.    u                    Lord
G4     2        e     u                    an
measure 23
G4     2        e     u                    of-
G4     2        e     u                    fer-
G4     2        e     u                    ing
G4     2        e     u                    in
G4     4        q     u                    righ-
F4     4        q     u                    teous-
measure 24
G4     4        q     u                    ness,
G4     4        q     u                    in
G4     6        q.    u                    righ-
G4     2        e     u                    teous-
measure 25
G4     4        q     u                    ness.
rest   4        q
rest   8        h
measure 26
rest   4        q
rest   2        e
G4     2        e     u                    And
Ef4    4        q     u                    he
G4     4        q     u                    shall
measure 27
G4     2        e     u  [                 pu-
Af4    2        e     u  ]                 -
B3     4        q     u                    ri-
C4     4        q     u                    fy,
rest   4        q
measure 28
rest  16
measure 29
rest   4        q
rest   2        e
C4     2        e     u                    and
F4     4        q     u                    he
G4     4        q     u                    shall
measure 30
A4     2        e     u  [                 pu-
Bf4    2        e     u  ]                 -
G4     4        q     u                    ri-
A4     4        q     u                    fy,
rest   4        q
measure 31
rest  16
measure 32
rest   4        q
rest   2        e
F4     2        e     u                    and
Bf3    4        q     u                    he
F4     4        q     u                    shall
measure 33
F4     2        e     u  [                 pu-
G4     2        e     u  ]                 -
F4     4        q     u                    ri-
F4     4        q     u                    fy,
rest   4        q
measure 34
rest   4        q
rest   2        e
A4     2        e     u                    and
G4     4        q     u                    he
F4     4        q     u                    shall
measure 35
F4     2        e     u  [                 pu-
G4     2        e     u  ]                 -
A4     4        q     u                    ri-
F4     4        q     u                    fy,
rest   4        q
measure 36
rest  16
measure 37
rest  16
measure 38
rest   4        q
rest   2        e
D4     2        e     u                    and
G4     4        q     u                    he
A4     4        q     u                    shall
measure 39
Bf4    2        e     d  [                 pu-
C5     2        e     d  ]                 -
A4     4        q     u                    ri-
G4     4        q     u                    fy,
rest   4        q
measure 40
rest   4        q
rest   2        e
C4     2        e     u                    and
G4     4        q     u                    he
A4     4        q     u                    shall
measure 41
Bf4    2        e     d  [                 pu-
C5     2        e     d  ]                 -
A4     4        q     u                    ri-
G4     4        q     u                    fy
rest   4        q
measure 42
rest   4        q
Bf4    4        q     u                    the
Bf4    4        q     u                    sons_
Af4    4-       q     u        -           _
measure 43
Af4    4        q     u                    _
G4     4        q     u                    of
G4     4        q     u                    Le-
F#4    4        q     u                    vi,
measure 44
rest  16
measure 45
rest  16
measure 46
rest   8        h
rest   2        e
D4     2        e     u                    shall
G4     2        e     u                    pu-
G4     2        e     u                    ri-
measure 47
F4     1        s     u  [[                fy,_
G4     1        s     u  ==                _
F4     1        s     u  ==                _
Ef4    1        s     u  ]]                _
F4     1        s     u  [[                _
D4     1        s     u  ==                _
C4     1        s     u  ==                _
D4     1        s     u  ]]                _
Ef4    1        s     u  [[                _
F4     1        s     u  ==                _
Ef4    1        s     u  ==                _
D4     1        s     u  ]]                _
Ef4    1        s     u  [[                _
C4     1        s     u  ==                _
Bf3    1        s     u  ==                _
C4     1        s     u  =]                _
measure 48
D4     2        e     u  ]                 _
D4     2        e     u                    shall
Bf4    2        e     u                    pu-
Bf4    2        e     u                    ri-
A4     1        s     u  [[                fy_
Bf4    1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
A4     1        s     u  [[                _
F#4    1        s     u  ==                _
E4     1        s     u  ==                _
F#4    1        s     u  ]]                _
measure 49
G4     2        e     u                    _
D4     2        e     u                    shall
G4     2        e     u                    pu-
Bf4    2        e     u                    ri-
A4     1        s     u  [[                fy_
Bf4    1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
A4     1        s     u  [[                _
F4     1        s     u  ==                _
Bf4    1        s     u  ==                _
A4     1        s     u  ]]                _
measure 50
G4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
Bf4    1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
F#4    4        q     u                    _
G4     4        q     u                    the
measure 51
F#4    4        q     u                    sons
G4     4        q     u                    of
F#4    4        q     u                    Le-
F#4    4        q     u                    vi,
measure 52
rest   2        e
Bf4    2        e     u                    that
Bf4    2        e     u                    they
A4     2        e     u                    may
G4     6        q.    u                    of-
Bf4    2        e     u                    fer
measure 53
E4     4        q     u                    un-
A4     2        e     u                    to
A4     2        e     u                    the
A4     6        q.    u                    Lord
A4     2        e     u                    an
measure 54
G4     2        e     u                    of-
A4     2        e     u                    fer-
Bf4    2        e     u                    ing
A4     2        e     u                    in
G4     6        q.    u                    righ-
G4     2        e     u                    teous-
measure 55
A4     4        q     u                    ness,
G4     4        q     u                    in
G4     4        q     u                    righ-
F#4    4        q     u                    teous-
measure 56
G4     8        h     u                    ness.
rest   8        h
measure 57
rest  16
measure 58
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/6} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:e00fa59387b4afd4c390475aa0632721]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
0 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:34   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    And
measure 11
D4     2        e     d                    he
D4     2        e     d                    shall
D4     2        e     d                    pu-
D4     2        e     d                    ri-
C4     1        s     d  [[                fy_
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     1        s     u  [[                _
A3     1        s     u  ==                _
G3     1        s     u  ==                _
A3     1        s     u  ]]                _
measure 12
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     u  [[                _
G3     1        s     u  ==                _
F3     1        s     u  ==                _
G3     1        s     u  =]                _
A3     2        e     u  ]                 _
A3     2        e     u                    the
D4     4-       q     d        -           sons_
measure 13
D4     4        q     d                    _
C4     8        h     d                    _
Bf3    4-       q     d        -           _
measure 14
Bf3    4        q     d                    _
A3     8        h     u                    _
G3     4        q     u                    of
measure 15
G3     4        q     u         (          Le-
F#3    4        q     u         )          -
G3     4        q     u                    vi,
rest   4        q
measure 16
rest  16
measure 17
rest   8        h
rest   4        q
rest   2        e
D4     2        e     d                    and
measure 18
G4     2        e     d                    he
G4     2        e     d                    shall
G4     2        e     d                    pu-
G4     2        e     d                    ri-
F4     1        s     d  [[                fy_
G4     1        s     d  ==                _
F4     1        s     d  ==                _
Ef4    1        s     d  ]]                _
F4     1        s     d  [[                _
D4     1        s     d  ==                _
C4     1        s     d  ==                _
D4     1        s     d  ]]                _
measure 19
Ef4    1        s     d  [[                _
F4     1        s     d  ==                _
Ef4    1        s     d  ==                _
D4     1        s     d  ]]                _
Ef4    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
C4     1        s     d  ]]                _
D4     1        s     d  [[                _
Ef4    1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
D4     1        s     d  [[                _
Bf3    1        s     d  ==                _
Ef4    1        s     d  ==                _
D4     1        s     d  =]                _
measure 20
C4     2        e     d  ]                 _
C4     2        e     d                    the
C4     2        e     d                    sons
C4     2        e     d                    of
D4     4        q     d                    Le-
D4     4        q     d                    vi,
measure 21
rest   2        e
Ef4    2        e     d                    that
Ef4    2        e     d                    they
D4     2        e     d                    may
C4     6        q.    d                    of-
Ef4    2        e     d                    fer
measure 22
F4     4        q     d                    un-
F4     2        e     d                    to
Ef4    2        e     d                    the
D4     6        q.    d                    Lord
D4     2        e     d                    an
measure 23
Bf3    2        e     d                    of-
Bf3    2        e     d                    fer-
Bf3    2        e     d                    ing
Ef4    2        e     d                    in
Ef4    4        q     d                    righ-
C4     4        q     d                    teous-
measure 24
D4     4        q     d                    ness,
Ef4    4        q     d                    in
D4     6        q.    d                    righ-
D4     2        e     d                    teous-
measure 25
Ef4    4        q     d                    ness.
rest   4        q
rest   8        h
measure 26
rest   4        q
rest   2        e
B3     2        e     d                    And
G4     4        q     d                    he
D4     4        q     d                    shall
measure 27
Ef4    2        e     d  [                 pu-
F4     2        e     d  ]                 -
D4     4        q     d                    ri-
C4     4        q     d                    fy,
rest   4        q
measure 28
rest  16
measure 29
rest   4        q
rest   2        e
G3     2        e     u                    and
Bf3    2        e     d  [                 he_
C4     2        e     d  ]                 _
D4     2        e     d  [                 shall_
E4     2        e     d  ]                 _
measure 30
F4     2        e     d  [                 pu-
D4     2        e     d  ]                 -
E4     4        q     d                    ri-
C4     4        q     d                    fy,
rest   4        q
measure 31
rest  16
measure 32
rest   4        q
rest   2        e
C4     2        e     d                    and
Ef4    4        q     d                    he
Ef4    4        q     d                    shall
measure 33
Bf3    6        q.    d                    pu-
A3     2        e     u                    ri-
D4     4        q     d                    fy,
rest   4        q
measure 34
rest   4        q
rest   2        e
C4     2        e     d                    and
Bf3    4        q     d                    he
F4     4        q     d                    shall
measure 35
D4     2        e     d  [                 pu-
Bf3    2        e     d  ]                 -
F4     2        e     d  [                 ri-
Ef4    2        e     d  ]                 -
D4     4        q     d                    fy,
rest   4        q
measure 36
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    and
measure 37
C4     2        e     d                    he
C4     2        e     d                    shall
C4     2        e     d                    pu-
C4     2        e     d                    ri-
Bf3    2        e     u                    fy
A3     2        e     u                    the
Bf3    2        e     u                    sons
G3     2        e     u                    of
measure 38
A3     4        q     u                    Le-
A3     4        q     u                    vi,
rest   8        h
measure 39
rest   4        q
rest   2        e
D4     2        e     d                    and
Bf3    4        q     d                    he
C4     4        q     d                    shall
measure 40
D4     2        e     d  [                 pu-
G4     2        e     d  ]                 -
F#4    4        q     d                    ri-
G4     4        q     d                    fy,
rest   4        q
measure 41
rest   4        q
rest   2        e
D4     2        e     d                    and
G4     2        e     d                    he
G4     2        e     d                    shall
G4     2        e     d                    pu-
G4     2        e     d                    ri-
measure 42
F4     1        s     d  [[                fy_
G4     1        s     d  ==                _
F4     1        s     d  ==                _
Ef4    1        s     d  ]]                _
F4     1        s     d  [[                _
D4     1        s     d  ==                _
C4     1        s     d  ==                _
D4     1        s     d  ]]                _
Ef4    1        s     d  [[                _
F4     1        s     d  ==                _
Ef4    1        s     d  ==                _
D4     1        s     d  ]]                _
Ef4    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
C4     1        s     d  ]]                _
measure 43
D4     1        s     d  [[                _
Ef4    1        s     d  ==                _
D4     1        s     d  ==                _
C4     1        s     d  ]]                _
D4     1        s     d  [[                _
Bf3    1        s     d  ==                _
A3     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     1        s     d  [[                _
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     1        s     u  [[                _
A3     1        s     u  ==                _
G3     1        s     u  ==                _
A3     1        s     u  ]]                _
measure 44
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     d  [[                _
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Ef4    1        s     d  =]                _
D4     2        e     d  ]                 _
D4     2        e     d                    the
D4     2        e     d                    sons
D4     2        e     d                    of
measure 45
C4     4        q     d                    Le-
C4     4        q     d                    vi,
rest   8        h
measure 46
rest  16
measure 47
rest   2        e
A3     2        e     u                    shall
D4     2        e     d                    pu-
D4     2        e     d                    ri-
C4     1        s     d  [[                fy_
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     1        s     u  [[                _
A3     1        s     u  ==                _
G3     1        s     u  ==                _
A3     1        s     u  ]]                _
measure 48
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     u  [[                _
G3     1        s     u  ==                _
F#3    1        s     u  ==                _
G3     1        s     u  =]                _
A3     2        e     u  ]                 _
A3     2        e     u                    the
D4     4-       q     d        -           sons_
measure 49
D4     2        e     d                    _
Bf3    2        e     d                    of
Ef4    8        h     d                    Le-
D4     2        e     d  [                 -
Bf3    2-       e     d  ]     -           -
measure 50
Bf3    4        q     d                    -
C4     4        q     d                    -
A3     2        e     u                    -
D4     2        e     d                    vi,
D4     4        q     d                    the
measure 51
D4     4        q     d                    sons
D4     4        q     d                    of
D4     4        q     d                    Le-
D4     4        q     d                    vi,
measure 52
rest   2        e
D4     2        e     d                    that
D4     2        e     d                    they
D4     2        e     d                    may
E4     6        q.    d                    of-
D4     2        e     d                    fer
measure 53
C4     4        q     d                    un-
D4     2        e     d                    to
E4     2        e     d                    the
F#4    6        q.    d                    Lord
F#4    2        e     d                    an
measure 54
D4     2        e     d                    of-
D4     2        e     d                    fer-
D4     2        e     d                    ing
D4     2        e     d                    in
Ef4    6        q.    d         +          righ-
Ef4    2        e     d                    teous-
measure 55
F#3    4        q     u                    ness,
G3     4        q     u                    in
A3     4        q     u                    righ-
D4     4        q     d                    teous-
measure 56
Bf3    8        h     d                    ness.
rest   8        h
measure 57
rest  16
measure 58
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/7} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:9ccf23c8f3a3b4919889c2f9d89b3c9a]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
0 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   4        q
rest   2        e
A3     2        e     d                    And
D3     4        q     d                    he
E3     4        q     d                    shall
measure 6
F3     2        e     d  [                 pu-
G3     2        e     d  ]                 -
E3     4        q     d                    ri-
D3     4        q     d                    fy,
rest   2        e
A3     2        e     d                    and
measure 7
D4     2        e     d                    he
D4     2        e     d                    shall
D4     2        e     d                    pu-
D4     2        e     d                    ri-
C4     1        s     d  [[                fy_
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  ]]                _
C4     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 8
Bf3    1        s     d  [[                _
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     d  [[                _
G3     1        s     d  ==                _
F3     1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
Bf3    1        s     d  ==                _
A3     1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
F3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
measure 9
G3     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
F3     1        s     d  ]]                _
G3     1        s     d  [[                _
E3     1        s     d  ==                _
D3     1        s     d  ==                _
E3     1        s     d  =]                _
F3     2        e     d  ]                 _
Bf3    2        e     d                    the
G3     2        e     d                    sons
A3     2        e     d                    of
measure 10
D4     3        e.    d  [      (          Le-
E4     1        s     d  ]\                -
C#4    4        q     d         )          -
D4     4        q     d                    vi,
rest   4        q
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
G3     2        e     d                    and
measure 16
D4     2        e     d                    he
D4     2        e     d                    shall
D4     2        e     d                    pu-
D4     2        e     d                    ri-
C4     1        s     d  [[                fy,_
D4     1        s     d  ==                _
C4     1        s     d  ==                _
Bf3    1        s     d  =]                _
C4     2        e     d  ]                 _
F3     2        e     d                    and
measure 17
Bf3    2        e     d                    he
Bf3    2        e     d                    shall
Bf3    2        e     d                    pu-
Bf3    2        e     d                    ri-
A3     1        s     d  [[                fy_
Bf3    1        s     d  ==                _
A3     1        s     d  ==                _
G3     1        s     d  =]                _
A3     2        e     d  ]                 _
F#3    2        e     d                    the
measure 18
G3     4        q     d                    sons
Ef3    4        q     d                    of
D3     2        e     d  [                 Le-
C3     2        e     d  =                 -
D3     2        e     d  =                 -
G3     2        e     d  ]                 -
measure 19
C3     6        q.    u                    vi,
F3     2        e     d                    the
Bf2    6        q.    u                    sons,
Bf3    2        e     d                    the
measure 20
Af3    6        q.    d                    sons
Af3    2        e     d                    of
G3     4        q     d                    Le-
G3     4        q     d                    vi,
measure 21
rest   2        e
C3     2        e     u                    that
D3     2        e     u                    they
Ef3    2        e     d                    may
F3     6        q.    d                    of-
Ef3    2        e     d                    fer
measure 22
D3     4        q     u                    un-
Ef3    2        e     d                    to
F3     2        e     d                    the
G3     6        q.    d                    Lord
F3     2        e     d                    an
measure 23
Ef3    2        e     d                    of-
Ef3    2        e     d                    fer-
F3     2        e     d                    ing
G3     2        e     d                    in
Af3    6        q.    d                    righ-
Af3    2        e     d                    teous-
measure 24
G3     4        q     d                    ness,
C3     4        q     u                    in
G3     6        q.    d                    righ-
G3     2        e     d                    teous-
measure 25
C3     4        q     u                    ness.
rest   4        q
rest   8        h
measure 26
rest   4        q
rest   2        e
G3     2        e     d                    And
C4     4        q     d                    he
B3     4        q     d                    shall
measure 27
C4     2        e     d  [                 pu-
F3     2        e     d  ]                 -
G3     4        q     d                    ri-
C3     2        e     u                    fy,
C4     2        e     d                    shall
C4     2        e     d                    pu-
C4     2        e     d                    ri-
measure 28
Bf3    1        s     d  [[                fy_
C4     1        s     d  ==                _
Bf3    1        s     d  ==                _
A3     1        s     d  ]]                _
Bf3    1        s     d  [[                _
G3     1        s     d  ==                _
F3     1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
Bf3    1        s     d  ==                _
A3     1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
F3     1        s     d  ==                _
E3     1        s     d  ==                _
F3     1        s     d  ]]                _
measure 29
G3     1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
F3     1        s     d  ]]                _
G3     1        s     d  [[                _
E3     1        s     d  ==                _
D3     1        s     d  ==                _
E3     1        s     d  ]]                _
F3     2        e     d  [                 _
A3     2        e     d  =                 _
Bf3    2        e     d  ]                 _
C4     2        e     d                    the
measure 30
F3     2        e     d                    sons
Bf2    2        e     u                    of
C4     4        q     d                    Le-
F3     4        q     d                    vi,
rest   4        q
measure 31
rest  16
measure 32
rest   4        q
rest   2        e
F3     2        e     d                    and
G3     4        q     d                    he
A3     4        q     d                    shall
measure 33
Bf3    2        e     d  [                 pu-
Ef3    2        e     d  ]                 -
F3     4        q     d                    ri-
Bf3    4        q     d                    fy,
rest   4        q
measure 34
rest   4        q
rest   2        e
F3     2        e     d                    and
G3     4        q     d                    he
A3     4        q     d                    shall
measure 35
Bf3    2        e     d  [                 pu-
Ef3    2        e     d  ]                 -
F3     4        q     d                    ri-
Bf2    4        q     u                    fy,
rest   2        e
F3     2        e     d                    and
measure 36
Bf3    2        e     d                    he
Bf3    2        e     d                    shall
Bf3    2        e     d                    pu-
Bf3    2        e     d                    ri-
A3     2        e     d                    fy
G3     2        e     d                    the
A3     2        e     d                    sons
F3     2        e     d                    of
measure 37
C4     4        q     d                    Le-
C3     2        e     u                    vi,
C3     2        e     u                    the
G3     6        q.    d                    sons
G3     2        e     d                    of
measure 38
D3     4        q     u                    Le-
D3     4        q     u                    vi,
rest   8        h
measure 39
rest   4        q
rest   2        e
D4     2        e     d                    and
G3     4        q     d                    he
A3     4        q     d                    shall
measure 40
Bf3    2        e     d  [                 pu-
C4     2        e     d  ]                 -
A3     4        q     d                    ri-
G3     4        q     d                    fy,
rest   4        q
measure 41
rest   8        h
rest   4        q
rest   2        e
G3     2        e     d                    and
measure 42
D4     2        e     d                    he
D4     2        e     d                    shall
D4     2        e     d                    pu-
D4     2        e     d                    ri-
C4     2        e     d                    fy,
Bf3    2        e     d                    shall
C4     2        e     d                    pu-
F3     2        e     d                    ri-
measure 43
Bf3    2        e     d                    fy
Bf3    2        e     d                    the
Bf3    2        e     d                    sons
G3     2        e     d                    of
A3     4        q     d                    Le-
D3     4        q     u                    vi,
measure 44
rest   8        h
rest   4        q
Bf3    4        q     d                    the
measure 45
Bf3    4        q     d                    sons_
Af3    8        h     d                    _
G3     4-       q     d        -           _
measure 46
G3     4        q     d                    _
F#3    4        q     d                    of
G3     8        h     d                    Le-
measure 47
D3     4        q     u                    vi,
rest   4        q
rest   8        h
measure 48
rest   8        h
rest   4        q
rest   2        e
D3     2        e     u                    and
measure 49
G3     2        e     d                    he
G3     2        e     d                    shall
G3     2        e     d                    pu-
G3     2        e     d                    ri-
F3     1        s     d  [[                fy_
G3     1        s     d  ==                _
F3     1        s     d  ==                _
Ef3    1        s     d  ]]                _
F3     1        s     d  [[                _
D3     1        s     d  ==                _
C3     1        s     d  ==                _
D3     1        s     d  ]]                _
measure 50
Ef3    1        s     d  [[                _
D3     1        s     d  ==                _
Ef3    1        s     d  ==                _
F3     1        s     d  =]                _
Ef3    2        e     d  ]                 _
C3     2        e     u                    the
D3     4        q     u                    sons,
G3     4        q     d                    the
measure 51
D3     4        q     u                    sons
G2     4        q     u                    of
D3     4        q     u                    Le-
D3     4        q     u                    vi,
measure 52
rest   2        e
G3     2        e     d                    that
A3     2        e     d                    they
Bf3    2        e     d                    may
C4     6        q.    d                    of-
Bf3    2        e     d                    fer
measure 53
A3     4        q     d                    un-
Bf3    2        e     d                    to
C4     2        e     d                    the
D4     6        q.    d                    Lord
C4     2        e     d                    an
measure 54
Bf3    2        e     d                    of-
A3     2        e     d                    fer-
G3     2        e     d                    ing
F3     2        e     d                    in
Ef3    6        q.    d                    righ-
Ef3    2        e     d                    teous-
measure 55
D3     4        q     u                    ness,
G2     4        q     u                    in
D3     6        q.    u                    righ-
D3     2        e     u                    teous-
measure 56
G2     8        h     u                    ness.
rest   8        h
measure 57
rest  16
measure 58
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-07/8} [KHM:436410090]
TIMESTAMP: DEC/26/2001 [md5sum:7916059eb02a76e14ad02c9136392952]
04/07/90 E. Correia
WK#:56        MV#:1,7
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
0 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Allegro
G2     2        e     u  [
G3     2        e     u  =
f1              6
F#3    2        e     u  =
D3     2        e     u  ]
Ef3    2        e     u  [
Bf2    2        e     u  =
C3     2        e     u  =
D3     2        e     u  ]
measure 2
G3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
D2     2        e     u  ]
G2     2        e     d  [
G3     2        e     d  =
Bf3    2        e     d  =
G3     2        e     d  ]
measure 3
rest   2        e
G2     2        e     u  [
Bf2    2        e     u  =
G2     2        e     u  ]
D3     4        q     u
rest   2        e
f1              6
F3     2        e     d
measure 4
f1              6
G3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
f1              6
A3     2        e     d  ]
Bf3    4        q     d
rest   2        e
G3     2        e     d
measure 5
A3     2        e     d  [
D3     2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
D3     4        q     d
E3     4        q     d
measure 6
F3     2        e     d  [
G3     2        e     d  ]
E3     4        q     d
D3     2        e     u  [
D2     2        e     u  =
f1              6
F2     2        e     u  =
D2     2        e     u  ]
measure 7
rest   2        e
D3     2        e     d  [
F3     2        e     d  =
D3     2        e     d  ]
f1              5n
A3     4        q     d
rest   2        e
f2              6 n
C3     2        e     u
measure 8
f1              6
D3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
E3     2        e     d  ]
F3     2        e     d  [
D3     2        e     d  =
C#3    2        e     d  =
D3     2        e     d  ]
measure 9
E3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C#3    2        e     d  ]
D3     2        e     d  [
Bf3    2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
measure 10
D4     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
D3     4        q     u
rest   2        e
D2     2        e     u
measure 11
D3     2        e     d  [
E3     2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
f1              5n
A3     4        q     d
rest   2        e
C3     2        e     u
measure 12
D3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
E3     2        e     d  ]
F3     4        q     d
rest   2        e
F3     2        e     d
measure 13
Ef3    6        q.    d         +
Ef3    2        e     d
D3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
G2     2        e     u  ]
measure 14
C3     6        q.    u
F2     2        e     u
Bf2    6        q.    u
Ef3    2        e     d
measure 15
A2     4        q     u
D3     2        e     d  [
F#3    2        e     d  ]
G2     4        q     u
Bf2    2        e     d  [
G3     2        e     d  ]
measure 16
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
C4     6        q.    d
F3     2        e     d
measure 17
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
A3     6        q.    d
F#3    2        e     d
measure 18
G3     4        q     d
Ef3    4        q     d
f1              7
D3     2        e     d  [
C3     2        e     d  =
f1              6n
D3     2        e     d  =
G3     2        e     d  ]
measure 19
f1     4        5
f1              6f
C3     6        q.    u
F3     2        e     d
f1     4        7f
f1              6
Bf2    6        q.    u
Bf3    2        e     d
measure 20
Af3    8        h     d
G3     2        e     d  [
F3     2        e     d  =
Ef3    2        e     d  =
D3     2        e     d  ]
measure 21
C3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
Ef3    2        e     u  ]
f1     2        3
f2              4 2
F3     6        q.    d
f1              6
Ef3    2        e     d
measure 22
D3     4        q     u
Ef3    2        e     d  [
F3     2        e     d  ]
f1              n
G3     6        q.    d
F3     2        e     d
measure 23
Ef3    2        e     d  [
Ef3    2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
Af3    6        q.    d
Af3    2        e     d
measure 24
G3     4        q     d
C3     4        q     u
f1     4        4
f1              n
G3     6        q.    d
G3     2        e     d
measure 25
C3     4        q     u
rest   2        e
C4     2        e     d         p
Af3    2        e     d  [
Ef3    2        e     d  =
F3     2        e     d  =
G3     2        e     d  ]
measure 26
C4     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
C3     2        e     d  [
C4     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
measure 27
C4     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
C3     2        e     u  [
Bf2    2        e     u  =
A2     2        e     u  =
F2     2        e     u  ]
measure 28
f1              7
G2     2        e     u  [
F2     2        e     u  =
f1              6n
G2     2        e     u  =
C3     2        e     u  ]
F3     4        q     d
rest   2        e
D3     2        e     u
measure 29
Bf2    4        q     u
rest   2        e
C3     2        e     u
D3     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
C4     2        e     d  ]
measure 30
F3     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
A2     2        e     d  [
F3     2        e     d  =
D4     2        e     d  =
Bf3    2        e     d  ]
measure 31
C4     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
F3     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
D3     2        e     d  ]
measure 32
Ef3    2        e     d  [
D3     2        e     d  =
Ef3    2        e     d  =
F3     2        e     d  ]
G3     4        q     d
A3     4        q     d
measure 33
Bf3    2        e     d  [
Ef3    2        e     d  =
F3     3        e.    d  =
Ef3    1        s     d  ]\
D3     2        e     d  [
Bf3    2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 34
Bf3    2        e     d  [
Ef3    2        e     d  =
F3     2        e     d  =
F2     2        e     d  ]
G2     4        q     u
A2     4        q     u
measure 35
Bf2    2        e     u  [
Ef3    2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
Bf2    4        q     u
rest   2        e
F3     2        e     d
measure 36
Bf3    2        e     d  [
Bf3    2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
A3     2        e     d  [
G3     2        e     d  =
A3     2        e     d  =
F3     2        e     d  ]
measure 37
C4     4        q     d
C3     4        q     u
G3     6        q.    d
G3     2        e     d
measure 38
D3     4        q     u
D3     2        e     u  [
C3     2        e     u  ]
Bf2    2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 39
G3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
D4     2        e     d  ]
G3     4        q     d
A3     4        q     d
measure 40
Bf3    2        e     d  [
C4     2        e     d  ]
A3     4        q     d
G3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 41
G3     2        e     d  [
C3     2        e     d  =
D3     2        e     d  =
D4     2        e     d  ]
Bf3    2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
G3     2        e     d  ]
measure 42
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
f1              7
C4     2        e     d  [
Bf3    2        e     d  =
f1              6f
C4     2        e     d  =
F3     2        e     d  ]
measure 43
Bf3    6        q.    d
G3     2        e     d
A3     4        q     d
D3     2        e     d  [
F#3    2        e     d  ]
measure 44
G2     4        q     u
G3     2        e     d  [
Ef3    2        e     d  ]
D3     4        q     d
D3     2        e     d  [
G3     2        e     d  ]
measure 45
C3     6        q.    u
F3     2        e     d
Bf2    6        q.    u
Ef3    2        e     d
measure 46
A2     4        q     u
D3     4        q     u
G2     2        e     d  [
G3     2        e     d  =
Bf3    2        e     d  =
G3     2        e     d  ]
measure 47
D3     4        q     u
rest   2        e
Bf2    2        e     u
C3     4        q     u
rest   2        e
F2     2        e     u
measure 48
Bf2    4        q     u
rest   2        e
Ef3    2        e     d
C3     4        q     u
rest   2        e
D3     2        e     u
measure 49
G2     6        q.    u
C3     2        e     u
F3     6        q.    d
D3     2        e     u
measure 50
Ef3    6        q.    d
C3     2        e     u
D3     4        q     u
G2     4        q     u
measure 51
D3     4        q     u
G2     4        q     u
D3     2        e     u  [
C3     2        e     u  =
Bf2    2        e     u  =
A2     2        e     u  ]
measure 52
G2     2        e     u  [
G3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
C4     6        q.    d
Bf3    2        e     d
measure 53
A3     4        q     d
Bf3    2        e     d  [
C4     2        e     d  ]
D4     6        q.    d
C4     2        e     d
measure 54
Bf3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F3     2        e     d  ]
Ef3    6        q.    d
Ef3    2        e     d
measure 55
D3     4        q     u
G2     4        q     u
D3     6        q.    u
D3     2        e     u
measure 56
G2     2        e     u  [
A2     2        e     u  =
Bf2    2        e     u  =
G2     2        e     u  ]
C3     2        e     u  [
D3     2        e     u  ]
Ef3    4        q     d
measure 57
D3     4        q     u
G2     4        q     u
D3     4        q     u
D2     4        q     u
measure 58
G2    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
