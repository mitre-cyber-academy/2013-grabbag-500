&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/1} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:048ffa63ca26e3fdf28312510401b4c7]
06/10/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest   4        q
rest   2        e
A5     2        e     d
D6     4        q     d
A5     4        q     d
measure 2
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
F#5    2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -
measure 3
G5     4        q     d
F#5    4        q     d
E5     6        q.    d         &t
D5     2        e     d
measure 4
D5     2        e     d  [
A4     2        e     d  =
D5     2        e     d  =
A4     2        e     d  ]
B4     2        e     u  [
A4     1        s     u  =[
G4     1        s     u  ]]
F#4    2        e     u  [
E4     1        s     u  =[
F#4    1        s     u  ]]
measure 5
G4     2        e     u  [
B4     2        e     u  ]
C#5    2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
D5     4        q     d
E5     4        q     d
measure 6
A5     4        q     d
E5     4        q     d
F#5    4        q     d
E5     2        e     d  [
D5     2        e     d  ]
measure 7
C#5    2        e     d  [
E5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  ]
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
measure 8
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
A5     2        e     d  [
A4     2        e     d  ]
B4     2        e     u  [
A4     1        s     u  =[
B4     1        s     u  ]]
measure 9
C#5    4        q     d
D5     8        h     d
C#5    4        q     d         &t
measure 10
D5     4        q     d
rest   4        q
rest   8        h
measure 11
rest   8        h
rest   2        e
A4     2        e     d  [
D5     2        e     d  =
A4     2        e     d  ]
measure 12
B4     2        e     u  [
A4     1        s     u  =[
G4     1        s     u  ]]
F#4    2        e     u  [
E4     1        s     u  =[
F#4    1        s     u  ]]
G4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  =
C5     2        e     u  ]
measure 13
D5     4        q     d
G5     8        h     d
F#5    4        q     d
measure 14
E5     4        q     d
rest   4        q
rest   8        h
measure 15
rest   2        e
B4     2        e     d  [
E5     2        e     d  =
B4     2        e     d  ]
C#5    2        e     u  [
B4     1        s     u  =[
A4     1        s     u  ]]
G#4    2        e     u  [
F#4    1        s     u  =[
G#4    1        s     u  ]]
measure 16
A4     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
D5     2        e     d  ]
E5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 17
A4     8        h     u
A4     4        q     u
B4     4        q     d
measure 18
E4     4        q     u
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest   2        e
E5     2        e     d  [
A5     2        e     d  =
E5     2        e     d  ]
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
measure 23
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
A5     2        e     d  [
A4     1        s     d  =[
B4     1        s     d  ]]
C5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ]]
measure 24
B4     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
C#5    4        q     d         +
F#5    2        e     d  [
E5     2        e     d  ]
measure 25
D5     2        e     d  [
E5     1        s     d  =[
F#5    1        s     d  ]]
G5     4-       q     d        -
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
measure 26
C#5    2        e     d  [
D5     2        e     d  ]
E5     4        q     d
A4     2        e     u  [
B4     1        s     u  =[
A4     1        s     u  ]]
G4     2        e     u  [
F#4    2        e     u  ]
measure 27
E4     3        e.    u  [
E4     1        s     u  ]\
E4     4        q     u
rest   4        q
A4     4        q     u
measure 28
D5     4        q     d
A4     4        q     u
B4     4        q     u
A4     2        e     u  [
G4     2        e     u  ]
measure 29
F#4    4        q     u
E4     2        e     u  [
F#4    2        e     u  ]
G4     4        q     u
A4     4        q     u
measure 30
B4     4        q     d
C#5    4        q     d
D5     4        q     d
E5     2        e     d  [
E5     2        e     d  ]
measure 31
F#5    4        q     d
G5     4-       q     d        -
G5     4        q     d
F#5    4-       q     d        -
measure 32
F#5    4        q     d
E5     4-       q     d        -
E5     4        q     d
D5     4        q     d
measure 33
C#5    4        q     d
D5     4-       q     d        -
D5     4        q     d
C#5    4        q     d
measure 34
D5     4        q     d
rest   2        e
A5     2        e     d         f
D6     4        q     d
A5     4        q     d
measure 35
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
F#5    2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -
measure 36
G5     4        q     d
F#5    4        q     d
E5     6        q.    d         &t
D5     2        e     d
measure 37
D5    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/2} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:2d95df2fe94336de32007160b24669c5]
06/10/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest   4        q
rest   2        e
F#5    2        e     d
A5     4        q     d
F#5    4        q     d
measure 2
D5     4        q     d
C#5    2        e     d  [
C#5    2        e     d  ]
D5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 3
E5     4        q     d
D5     8        h     d
C#5    4        q     d
measure 4
D5     4        q     d
A5     4        q     d
D6     4        q     d
A5     4        q     d
measure 5
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
F#5    2        e     d  [
D4     2        e     u  =
A4     2        e     u  =
E4     2        e     u  ]
measure 6
F#4    2        e     u  [
E4     1        s     u  =[
D4     1        s     u  ]]
C#4    2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
D4     2        e     u  [
F#4    2        e     u  ]
G#4    2        e     u  [
F#4    1        s     u  =[
G#4    1        s     u  ]]
measure 7
A4     4        q     u
C#5    3        e.    d  [
B4     1        s     d  ]\
A4     6        q.    u
G4     2        e     u         +
measure 8
F#4    6        q.    u
E4     2        e     u
D4     4        q     u
G4     2        e     u  [
F#4    2        e     u  ]
measure 9
E4     4        q     u
A4     4        q     u
G4     6        q.    u
G4     2        e     u
measure 10
F#4    4        q     u
A4     4        q     u
D5     4        q     d
A4     4        q     u
measure 11
B4     4        q     u
A4     2        e     u  [
G4     2        e     u  ]
F#4    8        h     u
measure 12
D4     6        q.    u
A4     2        e     u
G4     4        q     u
rest   4        q
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest   8        h
rest   4        q
E4     4        q     u
measure 17
A4     4        q     u
E4     4        q     u
F#4    4        q     u
E4     2        e     u  [
D4     2        e     u  ]
measure 18
C#4    4        q     u
D4     8        h     u
C#4    2        e     u  [
D4     2        e     u  ]
measure 19
E4     6        q.    u
E4     2        e     u
E4     4        q     u
rest   4        q
measure 20
rest   8        h
rest   2        e
E4     2        e     u  [
A4     2        e     u  =
E4     2        e     u  ]
measure 21
F#4    2        e     u  [
E4     1        s     u  =[
D4     1        s     u  ]]
C#4    2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
D4     2        e     u  [
C#4    2        e     u  =
B3     2        e     u  =
E4     2        e     u  ]
measure 22
C#4    8        h     u
A4     6        q.    u
G4     2        e     u
measure 23
F#4    6        q.    u
E4     2        e     u
D4     8-       h     u        -
measure 24
D4     2        e     u  [
E4     1        s     u  =[
F#4    1        s     u  ]]
G4     2        e     u  [
F#4    2        e     u  ]
E4     2        e     u  [
F#4    1        s     u  =[
G4     1        s     u  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 25
F#4    4        q     u
E4     2        e     u  [
D4     2        e     u  ]
A4     8-       h     u        -
measure 26
A4     6        q.    u
G4     2        e     u
F#4    2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
E4     2        e     u  [
D4     2        e     u  ]
measure 27
C#4    3        e.    u  [
C#4    1        s     u  ]\
C#4    4        q     u
rest   2        e
A4     2        e     u  [
A4     2        e     u  =
G4     2        e     u  ]
measure 28
F#4    6        q.    u
G4     1        s     u  [[
A4     1        s     u  ]]
D4     2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
E4     2        e     u  [
D4     1        s     u  =[
E4     1        s     u  ]]
measure 29
F#4    4        q     u
A3     2        e     u  [
A3     2        e     u  ]
D4     4        q     u
F#4    4        q     u
measure 30
D4     4        q     u
G4     2        e     u  [
E4     2        e     u  ]
A4     4        q     u
A4     2        e     u  [
A4     2        e     u  ]
measure 31
A4     4        q     u
G4     2        e     u  [
F#4    2        e     u  ]
E4     4        q     u
D4     4-       q     u        -
measure 32
D4     4        q     u
C#4    4        q     u
A4     8        h     u
measure 33
G4     4        q     u
F#4    4        q     u
E4     6        q.    u
E4     2        e     u
measure 34
F#4    4        q     u
rest   2        e
F#5    2        e     d         &f
A5     4        q     d
F#5    4        q     d
measure 35
D5     4        q     d
C#5    2        e     d  [
C#5    2        e     d  ]
D5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 36
E5     4        q     d
D5     4-       q     d        -
D5     4        q     d
C#5    4        q     d
measure 37
D5    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/3} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:420498c38c86c4b102fe52add8ceaaa3]
06/10/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Allegro
rest   4        q
rest   2        e
A4     2        e     d
A4     4        q     d
D5     4        q     d
measure 2
B4     4        q     d
E4     2        e     d  [
E4     2        e     d  ]
D4     2        e     d  [
B3     2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
measure 3
A4     8        h     d
A4     4        q     d
E4     4        q     d
measure 4
F#4    4        q     d
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   2        e
A3     2        e     u  [
D4     2        e     u  =
A3     2        e     u  ]
B3     2        e     u  [
A3     1        s     u  =[
G3     1        s     u  ]]
F#3    2        e     u  [
E3     1        s     u  =[
F#3    1        s     u  ]]
measure 11
G3     2        e     u  [
B3     2        e     u  =
C#4    3        e.    u  =
C#4    1        s     u  ]\
D4     8        h     d
measure 12
D4     6        q.    d
C4     2        e     d
B3     6        q.    u
A3     2        e     u
measure 13
G3     6        q.    u
E4     2        e     d
A3     4        q     u
D4     4-       q     d        -
measure 14
D4     4        q     d
C#4    2        e     u  [      +
B3     2        e     u  ]
C#4    2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
A3     2        e     d  ]
measure 15
G#3    4        q     u
E4     4        q     d
A4     4        q     d
E4     4        q     d
measure 16
F#4    4        q     d
E4     2        e     d  [
D4     2        e     d  ]
C#4    8        h     d
measure 17
C#4    4        q     d
E4     4        q     d
A3     4        q     u
rest   4        q
measure 18
rest  16
measure 19
rest   2        e
B3     2        e     d  [
E4     2        e     d  =
B3     2        e     d  ]
C#4    2        e     u  [
B3     1        s     u  =[
A3     1        s     u  ]]
G#3    2        e     u  [
F#3    1        s     u  =[
G#3    1        s     u  ]]
measure 20
A3     2        e     u  [
F#3    2        e     u  =
B3     2        e     u  =
A3     2        e     u  ]
G#3    4        q     u
A3     4-       q     u        -
measure 21
A3     4        q     u
G#3    4        q     u
A3     4        q     u
rest   4        q
measure 22
rest   4        q
A3     4        q     u
D4     4        q     d
A3     4        q     u
measure 23
B3     4        q     u
A3     2        e     u  [
G3     2        e     u  ]
F#3    8        h     u
measure 24
G3     2        e     u  [
F#3    2        e     u  ]
E3     2        e     u  [
F#3    1        s     u  =[
G3     1        s     u  ]]
A3     2        e     u  [
G3     2        e     u  ]
F#3    2        e     u  [
G3     1        s     u  =[
A3     1        s     u  ]]
measure 25
B3     6        q.    u
A3     1        s     u  [[
B3     1        s     u  ]]
C#4    4        q     d
D4     4        q     d
measure 26
A3     6        q.    u
A3     2        e     u
A3     8        h     u
measure 27
rest   2        e
E4     2        e     d  [
A3     2        e     d  =
E4     2        e     d  ]
F#4    6        q.    d
E4     2        e     d
measure 28
D4     6        q.    d
C#4    2        e     d
B3     4        q     u
E4     4        q     d
measure 29
A3     4        q     u
A3     2        e     u  [
A3     2        e     u  ]
B3     4        q     u
D4     4        q     d
measure 30
B3     4        q     u
E4     4        q     d
F#4    4        q     d
E4     2        e     d  [
E4     2        e     d  ]
measure 31
D4     6        q.    d
E4     1        s     d  [[
D4     1        s     d  ]]
C#4    4        q     d
rest   4        q
measure 32
A4     6        q.    d
G4     2        e     d
F#4    6        q.    d
G4     1        s     d  [[
F#4    1        s     d  ]]
measure 33
E4     4        q     d
A3     4-       q     u        -
A3     4        q     u
A3     4        q     u
measure 34
A3     4        q     u
rest   2        e
A4     2        e     d         &f
A4     4        q     d
D5     4        q     d
measure 35
B4     4        q     d
E4     2        e     d  [
E4     2        e     d  ]
D4     2        e     d  [
B3     2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
measure 36
A4     8        h     d
A4     4        q     d
E4     4        q     d
measure 37
F#4   16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/4} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:217562d9ed4e510f9bd4be9f368f913b]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest   4        q
rest   2        e
A4     2        e     u                    Let
D5     4        q     d                    all
A4     4        q     u                    the
measure 2
B4     4        q     d                    an-
C#5    2        e     d                    gels
C#5    2        e     d                    of
D5     8        h     d                    God
measure 3
E5     4        q     d         (          wor-
D5     8        h     d         )          -
C#5    4        q     d                    ship
measure 4
D5     4        q     d                    him,
rest   4        q
rest   8        h
measure 5
rest   8        h
rest   4        q
E5     4        q     d                    let
measure 6
A5     4        q     d                    all
E5     4        q     d                    the
F#5    4        q     d                    an-
E5     2        e     d                    gels
D5     2        e     d                    of
measure 7
C#5    2        e     d                    God,
E5     2        e     d                    let
A5     2        e     d                    all
E5     2        e     d                    the
F#5    2        e     d  [                 an-
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
C#5    2        e     d  [                 -
B4     1        s     d  =[                -
C#5    1        s     d  ]]                -
measure 8
D5     2        e     d  [                 -
E5     2        e     d  =                 -
F#5    2        e     d  =                 -
G5     2        e     d  ]                 -
A5     2        e     d  [                 -
A4     2        e     d  ]                 -
B4     3        e.    d                    gels
B4     1        s     d                    of
measure 9
C#5    4        q     d                    God
D5     8        h     d                    wor-
C#5    4        q     d                    ship
measure 10
D5     4        q     d                    him,
rest   4        q
rest   8        h
measure 11
rest   8        h
rest   2        e
A4     2        e     u                    let
D5     2        e     d                    all
A4     2        e     u                    the
measure 12
B4     2        e     u  [                 an-
A4     1        s     u  =[                -
G4     1        s     u  ]]                -
F#4    2        e     u  [                 -
E4     1        s     u  =[                -
F#4    1        s     u  ]]                -
G4     2        e     u  [                 -
A4     2        e     u  ]                 -
B4     2        e     d                    gels
C5     2        e     d                    of
measure 13
D5     4        q     d                    God
G5     8        h     d                    wor-
F#5    4        q     d                    ship
measure 14
E5     4        q     d                    him,
rest   4        q
rest   8        h
measure 15
rest   2        e
B4     2        e     d                    let
E5     2        e     d                    all
B4     2        e     d                    the
C#5    2        e     u  [                 an-
B4     1        s     u  =[                -
A4     1        s     u  ]]                -
G#4    2        e     u  [                 -
F#4    1        s     u  =[                -
G#4    1        s     u  ]]                -
measure 16
A4     2        e     d  [                 -
B4     2        e     d  =                 -
C#5    2        e     d  =                 -
D5     2        e     d  ]                 -
E5     4        q     d                    -
C#5    2        e     d                    gels
B4     2        e     d                    of
measure 17
A4     8        h     u                    God
A4     4        q     u                    wor-
B4     4        q     d                    ship
measure 18
E4     4        q     u                    him,
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest   2        e
E5     2        e     d                    let
A5     2        e     d                    all
E5     2        e     d                    the
F#5    2        e     d  [                 an-
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
C#5    2        e     d  [                 -
B4     1        s     d  =[                -
C#5    1        s     d  ]]                -
measure 23
D5     2        e     d  [                 -
E5     2        e     d  =                 -
F#5    2        e     d  =                 -
G5     2        e     d  ]                 -
A5     2        e     d  [                 -
A4     1        s     d  =[                -
B4     1        s     d  ]]                -
C5     2        e     d  [                 -
D5     1        s     d  =[                -
C5     1        s     d  ]]                -
measure 24
B4     4        q     d                    -
E5     2        e     d                    gels
D5     2        e     d                    of
C#5    4        q     d         +          God
F#5    2        e     d  [                 wor-
E5     2        e     d  ]                 -
measure 25
D5     2        e     d  [                 -
E5     1        s     d  =[                -
F#5    1        s     d  ]]                -
G5     4-       q     d        -           -
G5     2        e     d  [                 -
F#5    1        s     d  =[                -
E5     1        s     d  ]]                -
F#5    2        e     d  [                 -
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
measure 26
C#5    2        e     d  [                 -
D5     2        e     d  ]                 -
E5     4        q     d                    -
A4     2        e     u  [                 -
B4     1        s     u  =[                -
A4     1        s     u  ]]                -
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 27
E4     3        e.    u                    -
E4     1        s     u                    ship
E4     4        q     u                    him,
rest   4        q
A4     4        q     u                    let
measure 28
D5     4        q     d                    all
A4     4        q     u                    the
B4     4        q     d                    an-
A4     2        e     u  [                 -
G4     2        e     u  ]                 -
measure 29
F#4    4        q     u                    -
E4     2        e     u                    gels
F#4    2        e     u                    of
G4     4        q     u                    God,
A4     4        q     u                    let
measure 30
B4     4        q     d                    all
C#5    4        q     d                    the
D5     4        q     d                    an-
E5     2        e     d                    gels
E5     2        e     d                    of
measure 31
F#5    4        q     d                    God
G5     4-       q     d        -           wor-
G5     4        q     d                    -
F#5    4-       q     d        -           -
measure 32
F#5    4        q     d                    -
E5     4-       q     d        -           -
E5     4        q     d                    -
D5     4        q     d                    -
measure 33
C#5    4        q     d                    -
D5     4-       q     d        -           -
D5     4        q     d                    -
C#5    4        q     d                    ship
measure 34
D5    16        w     d                    him.
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/5} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:e9976e31908eaa44dcb1cfcb6925b01f]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest   4        q
rest   2        e
F#4    2        e     u                    Let
A4     4        q     u                    all
F#4    4        q     u                    the
measure 2
B4     4        q     u                    an-
A4     2        e     u                    gels
G4     2        e     u                    of
F#4    4        q     u         (          God_
E4     2        e     u  [                 _
D4     2        e     u  ]      )          _
measure 3
A4    12        h.    u                    wor-
E4     4        q     u                    ship
measure 4
F#4    4        q     u                    him,
rest   4        q
rest   8        h
measure 5
rest   8        h
rest   2        e
D4     2        e     u                    let
A4     2        e     u                    all
E4     2        e     u                    the
measure 6
F#4    2        e     u  [                 an-
E4     1        s     u  =[                -
D4     1        s     u  ]]                -
C#4    2        e     u  [                 -
B3     1        s     u  =[                -
C#4    1        s     u  ]]                -
D4     2        e     u  [                 -
F#4    2        e     u  ]                 -
G#4    3        e.    u                    gels
G#4    1        s     u                    of
measure 7
A4     8        h     u                    God
A4     6        q.    u                    wor-
G4     2        e     u         +          -
measure 8
F#4    6        q.    u                    -
E4     2        e     u                    -
D4     4        q     u                    -
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
measure 9
E4     4        q     u                    -
A4     4        q     u                    -
G4     6        q.    u                    -
G4     2        e     u                    ship
measure 10
F#4    4        q     u                    him,
A4     4        q     u                    let
D4     4        q     d                    all
&
 D5    4        q     u
&
A4     4        q     u                    the
measure 11
B4     4        q     u                    an-
A4     2        e     u                    gels
G4     2        e     u                    of
F#4    8        h     u                    God
measure 12
D4     6        q.    u                    wor-
A4     2        e     u                    ship
G4     4        q     u                    him,
rest   4        q
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest   8        h
rest   4        q
E4     4        q     u                    let
measure 17
A4     4        q     u                    all
E4     4        q     u                    the
F#4    4        q     u                    an-
E4     2        e     u                    gels
D4     2        e     u                    of
measure 18
C#4    4        q     u                    God
D4     8        h     u                    wor-
C#4    2        e     u  [                 -
D4     2        e     u  ]                 -
measure 19
E4     6        q.    u                    -
E4     2        e     u                    ship
E4     4        q     u                    him,
rest   4        q
measure 20
rest   8        h
rest   2        e
E4     2        e     u                    let
A4     2        e     u                    all
E4     2        e     u                    the
measure 21
F#4    2        e     u  [                 an-
E4     1        s     u  =[                -
D4     1        s     u  ]]                -
C#4    2        e     u  [                 -
B3     1        s     u  =[                -
C#4    1        s     u  ]]                -
D4     2        e     u  [                 -
C#4    2        e     u  ]                 -
B3     2        e     u                    gels
E4     2        e     u                    of
measure 22
C#4    8        h     u                    God
A4     6        q.    u                    wor-
G4     2        e     u                    -
measure 23
F#4    6        q.    u                    -
E4     2        e     u                    ship,
D4     8-       h     u        -           wor-
measure 24
D4     2        e     u  [                 -
E4     1        s     u  =[                -
F#4    1        s     u  ]]                -
G4     2        e     u  [                 -
F#4    2        e     u  ]                 -
E4     2        e     u  [                 -
F#4    1        s     u  =[                -
G4     1        s     u  ]]                -
A4     2        e     u  [                 -
G4     2        e     u  ]                 -
measure 25
F#4    4        q     u                    -
E4     2        e     u  [                 -
D4     2        e     u  ]                 -
A4     8-       h     u        -           -
measure 26
A4     6        q.    u                    -
G4     2        e     u                    -
F#4    2        e     u  [                 -
G4     1        s     u  =[                -
F#4    1        s     u  ]]                -
E4     2        e     u  [                 -
D4     2        e     u  ]                 -
measure 27
C#4    3        e.    u                    -
C#4    1        s     u                    ship
C#4    4        q     u                    him,
rest   2        e
A4     2        e     u                    let
A4     2        e     u                    all
G4     2        e     u                    the
measure 28
F#4    6        q.    u                    an-
G4     1        s     u  [[                -
A4     1        s     u  ]]                -
D4     2        e     u  [                 -
G4     1        s     u  =[                -
F#4    1        s     u  ]]                -
E4     2        e     u  [                 -
D4     1        s     u  =[                -
E4     1        s     u  ]]                -
measure 29
F#4    4        q     u                    -
A3     2        e     u                    gels
A3     2        e     u                    of
D4     4        q     u                    God,
F#4    4        q     u                    let
measure 30
D4     4        q     u                    all
G4     2        e     u  [                 the_
E4     2        e     u  ]                 _
A4     4        q     u                    an-
A4     2        e     u                    gels
A4     2        e     u                    of
measure 31
A4     4        q     u         (          God_
G4     2        e     u  [                 _
F#4    2        e     u  ]                 _
E4     4        q     u         )          _
D4     4-       q     u        -           wor-
measure 32
D4     4        q     u                    -
C#4    4        q     u                    -
A4     8        h     u                    -
measure 33
G4     4        q     u                    -
F#4    4        q     u                    -
E4     6        q.    u                    -
E4     2        e     u                    ship
measure 34
F#4   16        w     u                    him.
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/6} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:225b6102c487464dd20d342418a58f2a]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:34   D:Allegro
rest   4        q
rest   2        e
D4     2        e     d                    Let
D4     4        q     d                    all
D4     4        q     d                    the
measure 2
D4     4        q     d                    an-
A3     2        e     u                    gels
A3     2        e     u                    of
D4     4        q     d                    God
G4     4-       q     d        -           wor-
measure 3
G4     4        q     d                    -
F#4    4        q     d                    -
E4     4        q     d                    -
A3     4        q     u                    ship
measure 4
A3     4        q     u                    him,
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   2        e
A3     2        e     u                    let
D4     2        e     d                    all
A3     2        e     u                    the
B3     2        e     u  [                 an-
A3     1        s     u  =[                -
G3     1        s     u  ]]                -
F#3    2        e     u  [                 -
E3     1        s     u  =[                -
F#3    1        s     u  ]]                -
measure 11
G3     2        e     u  [                 -
B3     2        e     u  ]                 -
C#4    3        e.    d                    gels
C#4    1        s     d                    of
D4     8        h     d                    God
measure 12
D4     6        q.    d                    wor-
C4     2        e     d                    -
B3     6        q.    d                    -
A3     2        e     u                    -
measure 13
G3     6        q.    u                    -
E4     2        e     d                    -
A3     4        q     u                    -
D4     4-       q     d        -           -
measure 14
D4     4        q     d                    -
C#4    2        e     d  [      +          -
B3     2        e     d  ]                 -
C#4    2        e     d  [                 -
D4     2        e     d  =                 -
E4     2        e     d  ]                 -
A3     2        e     u                    ship
measure 15
G#3    4        q     u                    him,
E4     4        q     d                    let
A3     4        q     d                    all
&
 A4    4        q     u
&
E4     4        q     d                    the
measure 16
F#4    4        q     d                    an-
E4     2        e     d                    gels
D4     2        e     d                    of
C#4    8        h     d                    God
measure 17
C#4    4        q     d                    wor-
E4     4        q     d                    ship
A3     4        q     u                    him,
rest   4        q
measure 18
rest  16
measure 19
rest   2        e
B3     2        e     d                    let
E4     2        e     d                    all
B3     2        e     d                    the
C#4    2        e     d  [                 an-
B3     1        s     d  =[                -
A3     1        s     d  ]]                -
G#3    2        e     u  [                 -
F#3    1        s     u  =[                -
G#3    1        s     u  ]]                -
measure 20
A3     2        e     u  [                 -
F#3    2        e     u  ]                 -
B3     2        e     u                    gels
A3     2        e     u                    of
G#3    4        q     u                    God
A3     4-       q     u        -           wor-
measure 21
A3     4        q     u                    -
G#3    4        q     u                    ship
A3     4        q     u                    him,
rest   4        q
measure 22
rest   4        q
A3     4        q     u                    let
D4     4        q     d                    all
A3     4        q     u                    the
measure 23
B3     4        q     u                    an-
A3     2        e     u                    gels
G3     2        e     u                    of
F#3    8        h     u                    God
measure 24
G3     2        e     u  [                 wor-
F#3    2        e     u  ]                 -
E3     2        e     u  [                 -
F#3    1        s     u  =[                -
G3     1        s     u  ]]                -
A3     2        e     u  [                 -
G3     2        e     u  ]                 -
F#3    2        e     u  [                 -
G3     1        s     u  =[                -
A3     1        s     u  ]]                -
measure 25
B3     6        q.    u                    -
A3     1        s     u  [[                -
B3     1        s     u  ]]                -
C#4    4        q     d                    -
D4     4        q     d                    -
measure 26
A3     6        q.    u                    -
A3     2        e     u                    ship
A3     8        h     u                    him,
measure 27
rest   2        e
E4     2        e     d                    let
A3     2        e     u                    all
E4     2        e     d                    the
F#4    6        q.    d                    an-
E4     2        e     d                    -
measure 28
D4     6        q.    d                    -
C#4    2        e     d                    -
B3     4        q     d                    -
E4     4        q     d                    -
measure 29
A3     4        q     u                    -
A3     2        e     u                    gels
A3     2        e     u                    of
B3     4        q     u                    God,
D4     4        q     d                    let
measure 30
B3     4        q     d                    all
E4     4        q     d                    the
F#4    4        q     d                    an-
E4     2        e     d                    gels
E4     2        e     d                    of
measure 31
D4     6        q.    d         (          God_
E4     1        s     d  [[                _
D4     1        s     d  ]]                _
C#4    4        q     d         )          _
rest   4        q
measure 32
A4     6        q.    d                    wor-
G4     2        e     d                    -
F#4    6        q.    d                    -
G4     1        s     d  [[                -
F#4    1        s     d  ]]                -
measure 33
E4     4        q     d                    -
A3     4-       q     u        -           -
A3     4        q     u                    -
A3     4        q     u                    ship
measure 34
A3    16        w     u                    him.
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/7} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:6ea6f9eb08b03c87d5b1261076684d86]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro
rest   4        q
rest   2        e
D3     2        e     d                    Let
F#3    4        q     d                    all
D3     4        q     d                    the
measure 2
G3     4        q     d                    an-
A3     2        e     d                    gels
A3     2        e     d                    of
B3     8        h     d                    God
measure 3
C#4    4        q     d         (          wor-
D4     4        q     d                    -
A3     6        q.    d         )          -
A3     2        e     d                    ship
measure 4
D3     4        q     d                    him,
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest   4        q
A3     4        q     d                    let
D4     4        q     d                    all
A3     4        q     d                    the
measure 8
B3     4        q     d                    an-
A3     2        e     d                    gels
G3     2        e     d                    of
F#3    4        q     d                    God
G3     4-       q     d        -           wor-
measure 9
G3     4        q     d                    -
F#3    4        q     d                    -
E3     6        q.    d                    -
E3     2        e     d                    ship
measure 10
D3     4        q     d                    him,
rest   4        q
rest   8        h
measure 11
rest   8        h
rest   4        q
D3     4        q     d                    let
measure 12
G3     4        q     d                    all
D3     4        q     d                    the
E3     4        q     d                    an-
D3     2        e     d                    gels
C3     2        e     u                    of
measure 13
B2     6        q.    u         (          God_
C#3    2        e     u         )+         _
D3     2        e     d  [                 wor-
E3     2        e     d  =                 -
F#3    2        e     d  =                 -
G3     2        e     d  ]                 -
measure 14
A3     6        q.    d                    -
E3     2        e     d                    -
A2     2        e     u  [                 -
B2     2        e     u  =                 -
C#3    2        e     u  ]                 -
D3     2        e     u                    ship
measure 15
E3     4        q     d                    him,
rest   4        q
rest   8        h
measure 16
rest   8        h
rest   2        e
E3     2        e     d                    let
A3     2        e     d                    all
E3     2        e     d                    the
measure 17
F#3    2        e     d  [                 an-
E3     1        s     d  =[                -
D3     1        s     d  ]]                -
C#3    2        e     u  [                 -
B2     1        s     u  =[                -
C#3    1        s     u  ]]                -
D3     2        e     d  [                 -
F#3    2        e     d  ]                 -
G#3    2        e     d  [                 -
F#3    1        s     d  =[                -
G#3    1        s     d  ]]                -
measure 18
A3     2        e     d  [                 -
F#3    2        e     d  =                 -
B3     2        e     d  =                 -
A3     2        e     d  ]                 -
G#3    2        e     d  [                 -
E3     2        e     d  ]                 -
A3     4-       q     d        -           -
measure 19
A3     4        q     d                    -
G#3    2        e     d                    gels
G#3    2        e     d                    of
A3     4        q     d                    God
E3     4-       q     d        -           wor-
measure 20
E3     4        q     d                    -
D3     8        h     d                    -
C#3    4        q     u                    -
measure 21
D3     4        q     d                    -
E3     4        q     d                    -
F#3    4        q     d                    -
G#3    4        q     d                    ship
measure 22
A3     4        q     d                    him,
rest   4        q
rest   8        h
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest   8        h
rest   2        e
A3     2        e     d                    let
D4     2        e     d                    all
A3     2        e     d                    the
measure 28
B3     2        e     d  [                 an-
A3     1        s     d  =[                -
G3     1        s     d  ]]                -
F#3    2        e     d  [                 -
E3     1        s     d  =[                -
F#3    1        s     d  ]]                -
G3     2        e     d  [                 -
B2     2        e     d  ]                 -
C#3    2        e     u  [                 -
B2     1        s     u  =[                -
C#3    1        s     u  ]]                -
measure 29
D3     2        e     u  [                 -
A2     1        s     u  =[                -
B2     1        s     u  ]]                -
C3     2        e     u  [                 -
D3     1        s     u  =[                -
C3     1        s     u  ]]                -
B2     2        e     d  [                 -
G3     2        e     d  ]                 -
F#3    2        e     d  [                 -
E3     1        s     d  =[                -
F#3    1        s     d  ]]                -
measure 30
G3     2        e     d  [                 -
F#3    1        s     d  =[                -
G3     1        s     d  ]]                -
E3     2        e     d  [                 -
A3     1        s     d  =[                -
G3     1        s     d  ]]                -
F#3    2        e     d  [                 -
E3     1        s     d  =[                -
D3     1        s     d  ]]                -
C#3    2        e     u  [      +          -
B2     1        s     u  =[                -
C#3    1        s     u  ]]                -
measure 31
D3     2        e     d  [                 -
C#3    1        s     d  =[                -
D3     1        s     d  ]]                -
B2     2        e     u                    gels
E3     2        e     d                    of
A2     4        q     u                    God
rest   4        q
measure 32
A3    16-       w     d        -           wor-
measure 33
A3    12        h.    d                    -
A2     4        q     u                    ship
measure 34
D3    16        w     d                    him.
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/8} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:0fd7191799da9685e9904b7635c19290]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro
D3     4        q     d
rest   2        e
D3     2        e     d
f1              6
F#3    4        q     d
D3     4        q     d
measure 2
G3     4        q     d
A3     2        e     d  [
A3     2        e     d  ]
f1     4        5
f1              6
B3     8        h     d
measure 3
f2              6 5
C#4    4        q     d
D4     4        q     d
A3     6        q.    d
A3     2        e     d
measure 4
D3     2        e     d  [
$ C:4
A4     2        e     d  =
D5     2        e     d  =
A4     2        e     d  ]
B4     2        e     d  [
A4     1        s     d  =[
G4     1        s     d  ]]
F#4    2        e     d  [
E4     1        s     d  =[
F#4    1        s     d  ]]
measure 5
G4     2        e     d  [
B4     2        e     d  ]
C#5    2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
D5     2        e     d  [
$ C:15
D4     2        e     d  ]
A4     2        e     d  [
E4     2        e     d  ]
measure 6
F#4    2        e     d  [
E4     1        s     d  =[
D4     1        s     d  ]]
C#4    2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
D4     2        e     d  [
F#4    2        e     d  ]
G#4    2        e     d  [
F#4    1        s     d  =[
G#4    1        s     d  ]]
measure 7
A4     4        q     d
$ C:22
A3     4        q     d
D4     4        q     d
A3     4        q     d
measure 8
B3     4        q     d
A3     2        e     d  [
G3     2        e     d  ]
F#3    4        q     d
G3     4-       q     d        -
measure 9
G3     4        q     d
F#3    4        q     d
f1     4        7
f1              6
E3     6        q.    d
E3     2        e     d
measure 10
D3     2        e     d  [
$ C:13
A3     2        e     d  =
D4     2        e     d  =
A3     2        e     d  ]
B3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
measure 11
G3     2        e     d  [
B3     2        e     d  ]
C#4    2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
D4     4        q     d
$ C:22
D3     4        q     d
measure 12
G3     4        q     d
D3     4        q     d
E3     4        q     d
D3     2        e     u  [
C3     2        e     u  ]
measure 13
B2     6        q.    u
C#3    2        e     u         +
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G3     2        e     d  ]
measure 14
A3     6        q.    d
E3     2        e     d
A2     2        e     u  [
B2     2        e     u  =
C#3    2        e     u  =
D3     2        e     u  ]
measure 15
f1              #
E3     4        q     d
$ C:12
f1              #
E4     4        q     d
A4     4        q     d
E4     4        q     d
measure 16
F#4    4        q     d
E4     2        e     d  [
D4     2        e     d  ]
C#4    2        e     d  [
$ C:22
E3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  ]
measure 17
F#3    2        e     d  [
E3     1        s     d  =[
D3     1        s     d  ]]
C#3    2        e     u  [
B2     1        s     u  =[
C#3    1        s     u  ]]
D3     2        e     d  [
F#3    2        e     d  ]
G#3    2        e     d  [
F#3    1        s     d  =[
G#3    1        s     d  ]]
measure 18
A3     2        e     d  [
F#3    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
G#3    2        e     d  [
E3     2        e     d  ]
A3     4-       q     d        -
measure 19
A3     4        q     d
G#3    2        e     d  [
G#3    2        e     d  ]
A3     4        q     d
E3     4-       q     d        -
measure 20
E3     4        q     d
D3     8        h     d
C#3    4        q     u
measure 21
D3     4        q     d
E3     4        q     d
F#3    4        q     d
G#3    4        q     d
measure 22
A3     4        q     d
$ C:12
A3     4        q     d
D4     4        q     d
A3     4        q     d
measure 23
B3     4        q     d
A3     2        e     u  [
G3     2        e     u  ]
F#3    8        h     u
measure 24
G3     2        e     u  [
F#3    2        e     u  ]
E3     2        e     u  [
F#3    1        s     u  =[
G3     1        s     u  ]]
A3     2        e     u  [
G3     2        e     u  ]
F#3    2        e     u  [
G3     1        s     u  =[
A3     1        s     u  ]]
measure 25
B3     6        q.    d
A3     1        s     d  [[
B3     1        s     d  ]]
C#4    4        q     d
D4     4        q     d
measure 26
A3    16        w     d
measure 27
A3     8        h     d
F#4    2        e     d  [
$ C:22
A3     2        e     d  =
D4     2        e     d  =
A3     2        e     d  ]
measure 28
B3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
G3     2        e     d  [
B2     2        e     d  ]
C#3    2        e     u  [
B2     1        s     u  =[
C#3    1        s     u  ]]
measure 29
D3     2        e     u  [
A2     1        s     u  =[
B2     1        s     u  ]]
C3     2        e     u  [
D3     1        s     u  =[
C3     1        s     u  ]]
B2     2        e     d  [
G3     2        e     d  ]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
measure 30
G3     2        e     d  [
F#3    1        s     d  =[
G3     1        s     d  ]]
E3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
D3     1        s     d  ]]
C#3    2        e     u  [      +
B2     1        s     u  =[
C#3    1        s     u  ]]
measure 31
D3     2        e     u  [
C#3    1        s     u  =[
D3     1        s     u  ]]
B2     2        e     u  [
E3     2        e     u  ]
A2     8        h     u
measure 32
A2    16-       w     u        -
measure 33
A2    12        h.    u
A2     4        q     u
measure 34
D3     4        q     d
rest   2        e
D3     2        e     d         &f
F#3    4        q     d
D3     4        q     d
measure 35
G3     4        q     d
A3     2        e     d  [
A3     2        e     d  ]
B3     8        h     d
measure 36
C#4    4        q     d
D4     4        q     d
A3     4        q     d
A2     4        q     u
measure 37
D3    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 9
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-13/9} [KHM:1590671051]
TIMESTAMP: DEC/26/2001 [md5sum:17f3e8a8895ca66d90ec79f39603d5a3]
06/09/90 E. Correia
WK#:56        MV#:2,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 9 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22
measure 1
D3     4        q     d
rest   2        e
D3     2        e     d
F#3    4        q     d
D3     4        q     d
measure 2
G3     4        q     d
A3     2        e     d  [
A3     2        e     d  ]
B3     8        h     d
measure 3
C#4    4        q     d
D4     4        q     d
A3     6        q.    d
A3     2        e     d
measure 4
irest  2        e
$ C:4
irest  2        e
A5     4        7     u
D6     4        7     u
A5     4        7     u
back  16
D3     2        6     d
A4     2        6     d  [
D5     2        6     d  =
A4     2        6     d  ]
B4     2        6     d  [
A4     1        5     d  =[
G4     1        5     d  ]]
F#4    2        6     d  [
E4     1        5     d  =[
F#4    1        5     d  ]]
measure 5
B5     4        7     u
A5     2        6     u  [
G5     2        6     u  ]
F#5    4        7     u
E5     4        7     u
back  16
G4     2        6     d  [
B4     2        6     d  ]
C#5    2        6     d  [
B4     1        5     d  =[
C#5    1        5     d  ]]
D5     2        6     d  [
D4     2        6     d  =
A4     2        6     d  =
E4     2        6     d  ]
measure 6
A5     4        7     u
E5     4        7     u
F#5    4        7     u
E5     2        6     u  [
D5     2        6     u  ]
back  16
F#4    2        6     d  [
E4     1        5     d  =[
D4     1        5     d  ]]
C#4    2        6     d  [
B3     1        5     d  =[
C#4    1        5     d  ]]
D4     2        6     d  [
F#4    2        6     d  ]
G#4    2        6     d  [
F#4    1        5     d  =[
G#4    1        5     d  ]]
measure 7
C#5    2        6     u  [
E5     2        6     u  ]
back   4
A4     4        7     d
$ C:22
A3     4        q     d
D4     4        q     d
A3     4        q     d
measure 8
B3     4        q     d
A3     2        e     d  [
G3     2        e     d  ]
F#3    4        q     d
G3     4-       q     d        -
measure 9
G3     4        q     d
F#3    4        q     d
E3     6        q.    d
E3     2        e     d
measure 10
D3     2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
A3     2        e     d  ]
B3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
measure 11
G3     2        e     d  [
B3     2        e     d  ]
C#4    2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
D4     4        q     d
D3     4        q     d
measure 12
G3     4        q     d
D3     4        q     d
E3     4        q     d
D3     2        e     u  [
C3     2        e     u  ]
measure 13
B2     6        q.    u
C#3    2        e     u
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G3     2        e     d  ]
measure 14
A3     6        q.    d
E3     2        e     d
A2     2        e     u  [
B2     2        e     u  =
C#3    2        e     u  =
D3     2        e     u  ]
measure 15
E3     4        q     d
E4     4        q     d
A4     4        q     d
E4     4        q     d
measure 16
F#4    4        q     d
E4     2        e     d  [
D4     2        e     d  ]
C#4    2        e     d  [
E3     2        e     d  =
A3     2        e     d  =
E3     2        e     d  ]
measure 17
F#3    2        e     d  [
E3     1        s     d  =[
D3     1        s     d  ]]
C#3    2        e     u  [
B2     1        s     u  =[
C#3    1        s     u  ]]
D3     2        e     d  [
F#3    2        e     d  ]
G#3    2        e     d  [
F#3    1        s     d  =[
G#3    1        s     d  ]]
measure 18
A3     2        e     d  [
F#3    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
G#3    2        e     d  [
E3     2        e     d  ]
A3     4-       q     d        -
measure 19
A3     4        q     d
G#3    2        e     d  [
G#3    2        e     d  ]
A3     4        q     d
E3     4-       q     d        -
measure 20
E3     4        q     d
D3     8        h     d
C#3    4        q     u
measure 21
D3     4        q     d
E3     4        q     d
F#3    4        q     d
G#3    4        q     d
measure 22
A3     4        q     d
A3     4        q     d
D4     4        q     d
A3     4        q     d
measure 23
B3     4        q     d
A3     2        e     d  [
G3     2        e     d  ]
F#3    8        h     d
measure 24
G3     2        e     d  [
F#3    2        e     d  ]
E3     2        e     d  [
F#3    1        s     d  =[
G3     1        s     d  ]]
A3     2        e     d  [
G3     2        e     d  ]
F#3    2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
measure 25
B3     6        q.    d
A3     1        s     d  [[
B3     1        s     d  ]]
C#4    4        q     d
D4     4        q     d
measure 26
A3    16        w     d
measure 27
A3     8        h     d
F#4    2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
A3     2        e     d  ]
measure 28
B3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
G3     2        e     d  [
B2     2        e     d  ]
C#3    2        e     u  [
B2     1        s     u  =[
C#3    1        s     u  ]]
measure 29
D3     2        e     u  [
A2     1        s     u  =[
B2     1        s     u  ]]
C3     2        e     u  [
D3     1        s     u  =[
C3     1        s     u  ]]
B2     2        e     d  [
G3     2        e     d  ]
F#3    2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
measure 30
G3     2        e     d  [
F#3    1        s     d  =[
G3     1        s     d  ]]
E3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
F#3    2        e     d  [
E3     1        s     d  =[
D3     1        s     d  ]]
C#3    2        e     u  [
B2     1        s     u  =[
C#3    1        s     u  ]]
measure 31
D3     2        e     d  [
C#3    1        s     d  =[
D3     1        s     d  ]]
B2     2        e     u  [
E3     2        e     u  ]
A2     8        h     u
measure 32
A2    16-       w     u        -
measure 33
A2    12        h.    u
A2     4        q     u
measure 34
D3     4        q     d
rest   2        e
D3     2        e     d
F#3    4        q     d
D3     4        q     d
measure 35
G3     4        q     d
A3     2        e     d  [
A3     2        e     d  ]
B3     8        h     d
measure 36
C#4    4        q     d
D4     4        q     d
A3     4        q     d
A2     4        q     u
measure 37
D3    16        w     d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
