&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/01} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:2e2e8219dd421480cb12227fa1e2383f]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba I
1 23
Group memberships: score
score: part 1 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
A5     4        q     d
rest   4        q
measure 2
G5     4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
A5     4        q     d
A5     2        e     d  [
A5     2        e     d  ]
measure 3
B5     6        q.    d
G5     2        e     d
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
measure 4
A5     4        q     d
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
A5     4        q     d
rest   4        q
measure 11
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
A5     4        q     d
rest   4        q
measure 12
B5     4        q     d
A5     3        e.    d  [
G5     1        s     d  ]\
A5     4        q     d
F#5    2        e     d  [
F#5    2        e     d  ]
measure 13
E5     8        h     d
E5     8        h     d
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
E5     4        q     d
A5     4-       q     d        -
A5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
D5     2        e     d  ]
measure 23
E5     4        q     d
A4     4        q     u
F#5    4        q     d
G5     2        e     d  [
F#5    2        e     d  ]
measure 24
E5     4        q     d
D5     4        q     d
G5     6        q.    d
G5     2        e     d
measure 25
F#5    8        h     d
rest   8        h
measure 26
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
A5     4        q     d
rest   4        q
measure 27
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
A5     4        q     d
A5     2        e     d  [
A5     2        e     d  ]
measure 28
G5     4        q     d
B5     4        q     d
A5     8        h     d
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
A4     4        q     u
D5     4        q     d
rest   8        h
measure 36
rest  16
measure 37
rest  16
measure 38
D5     4        q     d
G5     4-       q     d        -
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 39
E5     6        q.    d
F#5    2        e     d
G5     8        h     d
measure 40
F#5    4        q     d
E5     4        q     d
A5     6        q.    d
G5     1        s     d  [[
F#5    1        s     d  ]]
measure 41
E5    12        h.    d
E5     4        q     d
measure 42
D5     8        h     d
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/02} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:21f4d41a815dc1f58036aaf109c16166]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba II
1 23
Group memberships: score
score: part 2 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
D5     4        q     d
A4     3        e.    u  [
A4     1        s     u  ]\
A4     4        q     u
rest   4        q
measure 2
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
F#5    4        q     d
F#5    2        e     d  [
F#5    2        e     d  ]
measure 3
G5     6        q.    d
D5     2        e     d
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 4
F#5    4        q     d
rest   4        q
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
A4     4        q     u
A4     3        e.    d  [
D5     1        s     d  ]\
E5     4        q     d
rest   4        q
measure 11
D5     4        q     d
D5     3        e.    d  [
D5     1        s     d  ]\
D5     4        q     d
rest   4        q
measure 12
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
F#5    4        q     d
D5     2        e     d  [
D5     2        e     d  ]
measure 13
A4     8        h     u
A4     8        h     u
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest   8        h
D5     4        q     d
G5     4-       q     d        -
measure 23
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
D5     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
measure 24
A4     6        q.    u
A4     2        e     u
E5     6        q.    d
E5     2        e     d
measure 25
A4     8        h     u
rest   8        h
measure 26
A4     4        q     u
A4     3        e.    d  [
D5     1        s     d  ]\
E5     4        q     d
rest   4        q
measure 27
D5     4        q     d
D5     3        e.    d  [
D5     1        s     d  ]\
D5     4        q     d
F#5    2        e     d  [
F#5    2        e     d  ]
measure 28
D5     4        q     d
G5     4        q     d
F#5    8        h     d
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
D4     4        q     u
F#4    4        q     u
rest   8        h
measure 36
rest  16
measure 37
rest  16
measure 38
rest  16
measure 39
A4     4        q     u
E5     4        q     d
D5     6        q.    d
E5     2        e     d
measure 40
A4     4        q     u
G5     2        e     d  [
F#5    2        e     d  ]
E5     4        q     d
D5     4        q     d
measure 41
A4    12        h.    u
A4     4        q     u
measure 42
F#4    8        h     u
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/03} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:06594586d17c2f0250f589ec7609d241]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 3 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
A5     4        q     d
A5     3        e.    d  [
D6     1        s     d  ]\
C#6    1        s     d  [[
D6     1        s     d  ==
C#6    1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 2
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 3
B5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
B4     1        s     d  ==
C#5    1        s     d  ==
D5     1        s     d  ]]
G4     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 4
F#5    1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
D5     1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
measure 5
F#4    4        q     u
rest   4        q
rest   4        q
A4     4        q     u
measure 6
A4    12        h.    u
A3     4        q     u
measure 7
A3     6        q.    u
E4     2        e     u         p
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
measure 8
F#4    2        e     u  [      .(
F#4    2        e     u  =      .
F#4    2        e     u  =      .
F#4    2        e     u  ]      .)
F#4    2        e     u  [      .(
F#4    2        e     u  =      .
F#4    2        e     u  =      .
F#4    2        e     u  ]      .)
measure 9
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
E4     4        q     u
rest   4        q
measure 10
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
A5     1        s     d  [[
D6     1        s     d  ==
C#6    1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 11
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
F#5    1        s     d  ]]
measure 12
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
C#6    1        s     d  ==
D6     1        s     d  ==
B5     1        s     d  ]]
measure 13
C#6    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G#5    1        s     d  ]]
A5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ]]
C#5    1        s     u  [[
E4     1        s     u  ==
F#4    1        s     u  ==
G#4    1        s     u  ]]
A4     1        s     u  [[
C#4    1        s     u  ==
D4     1        s     u  ==
E4     1        s     u  ]]
measure 14
A3     4        q     u
rest   4        q
rest   4        q
D5     4        q     d
measure 15
D5    12        h.    d
D4     4        q     u
measure 16
D4     6        q.    u
A4     2        e     u         p
A4     2        e     u  [      (.
A4     2        e     u  =       .
A4     2        e     u  =       .
A4     2        e     u  ]      ).
measure 17
B4     2        e     u  [      (.
B4     2        e     u  =       .
B4     2        e     u  =       .
B4     2        e     u  ]      ).
B4     2        e     u  [      (.
B4     2        e     u  =       .
B4     2        e     u  =       .
B4     2        e     u  ]      ).
measure 18
A4     4        q     u
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
A4     4        q     u
D5     4-       q     d        -
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
C#5    2        e     d  [
A4     2        e     d  ]
measure 21
B4     6        q.    u         &t
B4     2        e     u
A4     8        h     u
measure 22
rest   8        h
D5     4        q     d
G5     4-       q     d        -
measure 23
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
C#5    2        e     d  ]
D5     4        q     d
E5     2        e     d  [
D6     2        e     d  ]
measure 24
C#6    4        q     d
D6     8        h     d
C#6    4        q     d
measure 25
D6     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 26
A5     4        q     d
A5     3        e.    d  [
D6     1        s     d  ]\
C#6    1        s     d  [[
D6     1        s     d  ==
C#6    1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 27
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 28
D5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
measure 29
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
F#4    4        q     u
G3     4        q     u
measure 30
G3    12        h.    u
G3     4        q     u
measure 31
G3     6        q.    u
D4     2        e     u         p
D4     2        e     u  [      (.
D4     2        e     u  =       .
D4     2        e     u  =       .
D4     2        e     u  ]      ).
measure 32
E4     2        e     u  [      (.
E4     2        e     u  =       .
E4     2        e     u  =       .
E4     2        e     u  ]      ).
E4     2        e     u  [      (.
E4     2        e     u  =       .
E4     2        e     u  =       .
E4     2        e     u  ]      ).
measure 33
D4     4        q     u         f
G4     4-       q     u        -
G4     2        e     u  [
F#4    1        s     u  =[
E4     1        s     u  ]]
F#4    2        e     u  [
D4     2        e     u  ]
measure 34
E4     4        q     u
rest   4        q
rest   8        h
measure 35
A4     4        q     u
D5     4        q     d
rest   8        h
measure 36
B4     4        q     u
E5     4        q     d
rest   8        h
measure 37
C#5    4        q     d
F#5    4        q     d
rest   8        h
measure 38
D5     4        q     d
G5     4-       q     d        -
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 39
E5     6        q.    d
F#5    2        e     d
G5     8        h     d
measure 40
F#5    4        q     d
E5     2        e     d  [
D5     2        e     d  ]
C#6    4        q     d
D6     4-       q     d        -
measure 41
D6     8        h     d
C#6    8        h     d
measure 42
D6     8        h     d
rest   8        h
measure 43
A5     4        q     d
D6     4-       q     d        -
D6     2        e     d  [
C#6    1        s     d  =[
B5     1        s     d  ]]
C#6    2        e     d  [
A5     2        e     d  ]
measure 44
B5     8        h     d
A5     6        q.    d
A5     2        e     d         p
measure 45
G5     8        h     d         t
F#5    4        q     d
A5     4        q     d
measure 46
A5     4        q     d         &pp
rest   4        q
G5     4        q     d
rest   4        q
measure 47
G5     4        q     d
rest   4        q
F#5    4        q     d
rest   4        q
measure 48
E5     4        q     d
rest   4        q
C#6    6        q.    d         t
rest   1        s
C#6    1        s     d
measure 49
D6     4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/04} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:4f3dafcf23263f976b921a6fc3f56ac6]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 4 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
E5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 2
D5     4        q     d
C#5    3        e.    d  [
B4     1        s     d  ]\
A4     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 3
D5     1        s     d  [[
B4     1        s     d  ==
C#5    1        s     d  ==
D5     1        s     d  ]]
G4     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
measure 4
A5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
measure 5
D5     4        q     d
rest   4        q
rest   4        q
A4     4        q     u
measure 6
A4    12        h.    u
A3     4        q     u
measure 7
A3     6        q.    u
C#4    2        e     u         p
C#4    2        e     u  [      .(
C#4    2        e     u  =      .
C#4    2        e     u  =      .
C#4    2        e     u  ]      .)
measure 8
D4     2        e     u  [      .(
D4     2        e     u  =      .
D4     2        e     u  =      .
D4     2        e     u  ]      .)
D4     2        e     u  [      .(
D4     2        e     u  =      .
D4     2        e     u  =      .
D4     2        e     u  ]      .)
measure 9
C#4    2        e     u  [      .(
C#4    2        e     u  =      .
C#4    2        e     u  =      .
C#4    2        e     u  ]      .)
C#4    4        q     u
rest   4        q
measure 10
A5     4        q     d
A5     3        e.    d  [
D6     1        s     d  ]\
C#6    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 11
B4     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
measure 12
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
A4     2        e     d  [
A5     2        e     d  ]
measure 13
E5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ]]
C#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G#5    1        s     d  ]]
A5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
B4     1        s     d  ]]
C#5    1        s     u  [[
E4     1        s     u  ==
F#4    1        s     u  ==
G#4    1        s     u  ]]
measure 14
A4     4        q     u
rest   4        q
rest   4        q
D5     4        q     d
measure 15
D5    12        h.    d
D4     4        q     u
measure 16
D4     6        q.    u
F#4    2        e     u         p
F#4    2        e     u  [      .(
F#4    2        e     u  =      .
F#4    2        e     u  =      .
F#4    2        e     u  ]      .)
measure 17
G4     2        e     u  [      .(
G4     2        e     u  =      .
G4     2        e     u  =      .
G4     2        e     u  ]      .)
G4     2        e     u  [      .(
G4     2        e     u  =      .
G4     2        e     u  =      .
G4     2        e     u  ]      .)
measure 18
F#4    4        q     u
rest   4        q
rest   8        h
measure 19
E4     4        q     u
A4     4-       q     u        -
A4     2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
G4     2        e     u  [
E4     2        e     u  ]
measure 20
F#4    6        q.    u
F#4    2        e     u
E4     8        h     u
measure 21
D4     4        q     u
G4     4-       q     u        -
G4     2        e     u  [
F#4    1        s     u  =[
E4     1        s     u  ]]
F#4    2        e     u  [
D4     2        e     u  ]
measure 22
E4     8        h     u
D4     4        q     u
B4     4        q     u
measure 23
E4     4        q     u
A4     4        q     u
F#4    4        q     u
G4     4        q     u
measure 24
A4     6        q.    u
A5     2        e     d
G5     6        q.    d
G5     2        e     d
measure 25
F#5    3        e.    d  [
E5     1        s     d  ]\
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
measure 26
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
E5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 27
B4     1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 28
B4     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
measure 29
D5     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
F#4    1        s     u  [[
A3     1        s     u  ==
B3     1        s     u  ==
C#4    1        s     u  ]]
D4     4        q     u
G3     4        q     u
measure 30
G3    12        h.    u
G3     4        q     u
measure 31
G3     6        q.    u
B3     2        e     u          p
B3     2        e     u  [      (.
B3     2        e     u  =       .
B3     2        e     u  =       .
B3     2        e     u  ]      ).
measure 32
C4     2        e     u  [      (.
C4     2        e     u  =       .
C4     2        e     u  =       .
C4     2        e     u  ]      ).
C4     2        e     u  [      (.
C4     2        e     u  =       .
C4     2        e     u  =       .
C4     2        e     u  ]      ).
measure 33
B3     4        q     u
rest   4        q
A3     4        q     u          f
D4     4-       q     u        -
measure 34
D4     2        e     u  [
C#4    1        s     u  =[     +
B3     1        s     u  ]]
C#4    2        e     u  [
A3     2        e     u  ]
B3     2        e     u  [
A3     2        e     u  =
B3     2        e     u  =
C#4    2        e     u  ]
measure 35
D4     4        q     u
rest   4        q
F#4    4        q     u
D4     4        q     u
measure 36
rest   8        h
G4     4        q     u
E4     4        q     u
measure 37
rest   8        h
A4     4        q     u
F#4    4        q     u
measure 38
rest   8        h
rest   4        q
A5     4        q     d
measure 39
G5     4        q     d
A5     4        q     d
D5     4        q     d
B5     4        q     d
measure 40
A5     4        q     d
G5     2        e     d  [
F#5    2        e     d  ]
E5     4        q     d
A5     4        q     d
measure 41
E5    12        h.    d
E5     4        q     d
measure 42
D5     4        q     d
A5     4-       q     d        -
A5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
G5     2        e     d  [
E5     2        e     d  ]
measure 43
F#5    8        h     d
E5     6        q.    d
C#5    2        e     d
measure 44
D5     4        q     d
G5     8        h     d
F#5    2        e     d  [      p
E5     2        e     d  ]
measure 45
D5     4        q     d
E5     4        q     d
A4     4        q     u
E5     4        q     d
measure 46
D5     4        q     d         &pp
rest   4        q
D5     4        q     d
rest   4        q
measure 47
C#5    4        q     d
rest   4        q
D5     4        q     d
rest   4        q
measure 48
C#5    4        q     d
rest   4        q
E5     6        q.    d         t
rest   1        s
G5     1        s     d
measure 49
F#5    4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 05
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/05} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:4de8a40d4c4e2d49ab46594a986d0546]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 5 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Allegro
D4     4        q     d
C#4    3        e.    u  [
B3     1        s     u  ]\
A3     4        q     u
rest   4        q
measure 2
B3     4        q     u
A3     3        e.    u  [
G3     1        s     u  ]\
D4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
measure 3
G4    16        w     d
measure 4
D4     8        h     d
rest   8        h
measure 5
rest   8        h
rest   4        q
A4     4        q     d
measure 6
A4    12        h.    d
A3     4        q     u
measure 7
A3     6        q.    u
A3     2        e     u         &p
A3     2        e     u  [      .(
A3     2        e     u  =      .
A3     2        e     u  =      .
A3     2        e     u  ]      .)
measure 8
A3     2        e     u  [      .(
A3     2        e     u  =      .
A3     2        e     u  =      .
A3     2        e     u  ]      .)
A3     2        e     u  [      .(
A3     2        e     u  =      .
A3     2        e     u  =      .
A3     2        e     u  ]      .)
measure 9
A3     2        e     u  [      .(
A3     2        e     u  =      .
A3     2        e     u  =      .
A3     2        e     u  ]      .)
A3     4        q     u
rest   4        q
measure 10
D4     4        q     d
C#4    3        e.    u  [
B3     1        s     u  ]\
A3     4        q     u
rest   4        q
measure 11
B3     4        q     u
A3     3        e.    u  [
G3     1        s     u  ]\
F#3    4        q     u
rest   4        q
measure 12
G4     4        q     d
F#4    3        e.    d  [
E4     1        s     d  ]\
D4     4        q     d
F#4    2        e     d  [
F#4    2        e     d  ]
measure 13
A4     8        h     d
A3     8        h     u
measure 14
rest   8        h
rest   4        q
D4     4        q     d
measure 15
D4    12        h.    d
D3     4        q     u
measure 16
D3     6        q.    u
D4     2        e     d         &p
D4     2        e     d  [      (.
D4     2        e     d  =       .
D4     2        e     d  =       .
D4     2        e     d  ]      ).
measure 17
D4     2        e     d  [      (.
D4     2        e     d  =       .
D4     2        e     d  =       .
D4     2        e     d  ]      ).
D4     2        e     d  [      (.
D4     2        e     d  =       .
D4     2        e     d  =       .
D4     2        e     d  ]      ).
measure 18
D4     4        q     d
rest   4        q
A3     4        q     u
D4     4-       q     d        -
measure 19
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
C#4    2        e     u  [
A3     2        e     u  ]
E4     8        h     d
measure 20
D4     6        q.    d
D4     2        e     d
A3     8        h     u
measure 21
rest  16
measure 22
E4     4        q     d
A4     4-       q     d        -
A4     2        e     d  [
G4     1        s     d  =[
F#4    1        s     d  ]]
E4     2        e     d  [
D4     2        e     d  ]
measure 23
C#4    4        q     u
C#5    4        q     d
B4     8        h     d
measure 24
E4     4        q     d
D4     4        q     d
E4     6        q.    d
E4     2        e     d
measure 25
A4     8        h     d
rest   8        h
measure 26
A4     4        q     d
A4     3        e.    d  [
B4     1        s     d  ]\
E4     4        q     d
rest   4        q
measure 27
B4     4        q     d
B4     3        e.    d  [
B4     1        s     d  ]\
D4     4        q     d
D5     2        e     d  [
D5     2        e     d  ]
measure 28
D5     4        q     d
D5     2        e     d  [
G4     2        e     d  ]
A4     8        h     d
measure 29
rest   8        h
rest   4        q
G3     4        q     u
measure 30
G3    12        h.    u
G3     4        q     u
measure 31
G3     6        q.    u
G3     2        e     u         &p
G3     2        e     u  [      (.
G3     2        e     u  =       .
G3     2        e     u  =       .
G3     2        e     u  ]      ).
measure 32
G3     2        e     u  [      (.
G3     2        e     u  =       .
G3     2        e     u  =       .
G3     2        e     u  ]      ).
G3     2        e     u  [      (.
G3     2        e     u  =       .
G3     2        e     u  =       .
G3     2        e     u  ]      ).
measure 33
G3     4        q     u
rest   4        q
rest   8        h
measure 34
E4     4        q     d         &f
A4     4-       q     d        -
A4     2        e     d  [
G4     1        s     d  =[
F#4    1        s     d  ]]
G4     2        e     d  [
E4     2        e     d  ]
measure 35
F#4    4        q     d
rest   4        q
A3     4        q     u
B3     4        q     u
measure 36
rest   8        h
E4     4        q     d
C#4    4        q     u
measure 37
rest   8        h
F#4    4        q     d
D4     4        q     d
measure 38
rest   8        h
rest   4        q
F#4    4        q     d
measure 39
E4     6        q.    d
C#4    2        e     u
D4     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
measure 40
F#4    4        q     d
B4     2        e     d  [
D5     2        e     d  ]
A4     4        q     d
A4     4        q     d
measure 41
A4    12        h.    d
A4     4        q     d
measure 42
A4     4        q     d
F#4    4        q     d
B3     6        q.    u
C#4    2        e     u
measure 43
D4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
G4     2        e     d  ]
A4     2        e     d  [
A3     2        e     d  ]
A4     4-       q     d        -
measure 44
A4     2        e     d  [
G4     1        s     d  =[
F#4    1        s     d  ]]
E4     2        e     d  [
D4     2        e     d  ]
C#4    2        e     d  [
A3     2        e     d  =
D4     2        e     d  =       p
C#4    2        e     d  ]
measure 45
B3     4        q     u
C#4    4        q     u
D4     4        q     d
C#4    4        q     u
measure 46
B3     4        q     u          pp
rest   4        q
E4     4        q     d
rest   4        q
measure 47
A3     4        q     u
rest   4        q
D4     4        q     d
rest   4        q
measure 48
A4     4        q     d
rest   4        q
A3     4        q     u
rest   4        q
measure 49
D4     4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 06
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/06} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:97ddb3cd2509f9e9f4686af70bd0f90e]
04/09/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 6 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
F#5    4        q     d                    Glo-
E5     3        e.    d                    ry
D5     1        s     d                    to
C#5    4        q     d                    God,
rest   4        q
measure 2
D5     4        q     d                    glo-
D5     3        e.    d                    ry
E5     1        s     d                    to
F#5    4        q     d                    God
F#5    2        e     d                    in
F#5    2        e     d                    the
measure 3
D5    16        w     d                    high-
measure 4
F#5    8        h     d                    est,
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
A4     4        q     u                    Glo-
A4     3        e.    u                    ry
D5     1        s     d                    to
C#5    4        q     d                    God,
rest   4        q
measure 11
D5     4        q     d                    glo-
D5     3        e.    d                    ry
E5     1        s     d                    to
F#5    4        q     d                    God,
rest   4        q
measure 12
D5     4        q     d                    glo-
D5     3        e.    d                    ry
C#5    1        s     d                    to
D5     4        q     d                    God
D5     2        e     d                    in
D5     2        e     d                    the
measure 13
C#5    8        h     d                    high-
C#5    8        h     d                    est,
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
A4     4        q     u                    good
D5     4-       q     d        -           will_
D5     2        e     d                    _
C#5    1        s     d  [[     (          to-
B4     1        s     d  ]]                -
C#5    2        e     d         )          -
A4     2        e     u                    wards
measure 21
B4     4        q     u                    men,
B4     2        e     u                    to-
B4     2        e     u                    wards
A4     8        h     u                    men,
measure 22
rest   8        h
D5     4        q     d                    good
G5     4-       q     d        -           will_
measure 23
G5     2        e     d                    _
F#5    1        s     d  [[     (          to-
E5     1        s     d  ]]                -
F#5    2        e     d         )          -
C#5    2        e     d                    wards
D5     4        q     d         (          men,_
E5     2        e     d  [                 _
D5     2        e     d  ]                 _
measure 24
C#5    4        q     d         )          _
D5     8        h     d                    to-
C#5    4        q     d                    wards
measure 25
D5     8        h     d                    men.
rest   8        h
measure 26
F#5    4        q     d                    Glo-
E5     3        e.    d                    ry
D5     1        s     d                    to
C#5    4        q     d                    God,
rest   4        q
measure 27
D5     4        q     d                    glo-
C#5    3        e.    d                    ry
B4     1        s     u                    to
A4     4        q     u                    God
D5     2        e     d                    in
D5     2        e     d                    the
measure 28
D5     8        h     d                    high-
D5     8        h     d                    est,
measure 29
rest   8        h
rest   4        q
D4     4        q     u                    and
measure 30
D4    12        h.    u                    peace
D4     4        q     u                    on
measure 31
D4    16        w     u                    earth,
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
A4     4        q     u                    good
D5     4        q     d                    will,
rest   8        h
measure 36
B4     4        q     u                    good
E5     4        q     d                    will,
rest   8        h
measure 37
C#5    4        q     d                    good
F#5    4        q     d                    will,
rest   8        h
measure 38
D5     4        q     d                    good
G5     4-       q     d        -           will_
G5     2        e     d                    _
F#5    1        s     d  [[     (          to-
E5     1        s     d  ]]                -
F#5    2        e     d         )          -
D5     2        e     d                    wards
measure 39
E5     6        q.    d         (          men,_
F#5    2        e     d                    _
G5     8        h     d         )          _
measure 40
F#5    4        q     d                    good
E5     2        e     d  [      (          will_
D5     2        e     d  ]                 _
C#5    4        q     d         )          _
D5     4-       q     d        -           to-
measure 41
D5     8        h     d                    -
C#5    8        h     d                    wards
measure 42
D5     8        h     d                    men.
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 07
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/07} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:30c698adfd10bc11f56702e7ae0b5389]
04/10/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 7 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
A4     4        q     u                    Glo-
A4     3        e.    u                    ry
B4     1        s     u                    to
E4     4        q     u                    God,
rest   4        q
measure 2
G4     4        q     u                    glo-
A4     3        e.    u                    ry
B4     1        s     u                    to
A4     4        q     u                    God
A4     2        e     u                    in
A4     2        e     u                    the
measure 3
B4    16        w     u                    high-
measure 4
A4     8        h     u                    est,
rest   8        h
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
F#4    4        q     u                    Glo-
E4     3        e.    u                    ry
D4     1        s     u                    to
A4     4        q     u                    God,
rest   4        q
measure 11
F#4    4        q     u                    glo-
F#4    3        e.    u                    ry
G4     1        s     u                    to
A4     4        q     u                    God,
rest   4        q
measure 12
B4     4        q     u                    glo-
A4     3        e.    u                    ry
G4     1        s     u                    to
F#4    4        q     u                    God
A4     2        e     u                    in
A4     2        e     u                    the
measure 13
A4     8        h     u                    high-
E4     8        h     u                    est,
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
E4     4        q     u                    good
A4     4-       q     u        -           will_
A4     2        e     u                    _
G4     1        s     u  [[     (          to-
F#4    1        s     u  ]]                -
G4     2        e     u         )          -
E4     2        e     u                    wards
measure 20
F#4    4        q     u                    men,
F#4    2        e     u                    to-
F#4    2        e     u                    wards
E4     8        h     u                    men,
measure 21
D4     4        q     u                    good
G4     4-       q     u        -           will_
G4     2        e     u                    _
F#4    1        s     u  [[     (          to-
E4     1        s     u  ]]                -
F#4    2        e     u         )          -
D4     2        e     u                    wards
measure 22
E4     8        h     u                    men,
D4     4        q     u                    to-
B4     4        q     u                    wards
measure 23
E4     4        q     u                    men,
A4     4        q     u                    good
F#4    4        q     u         (          will_
G4     4        q     u                    _
measure 24
A4     8        h     u         )          _
G4     6        q.    u                    to-
G4     2        e     u                    wards
measure 25
F#4    8        h     u                    men.
rest   8        h
measure 26
A4     4        q     u                    Glo-
A4     3        e.    u                    ry
B4     1        s     u                    to
E4     4        q     u                    God,
rest   4        q
measure 27
D4     4        q     u                    glo-
D4     3        e.    u                    ry
E4     1        s     u                    to
F#4    4        q     u                    God
A4     2        e     u                    in
A4     2        e     u                    the
measure 28
B4     8        h     u                    high-
A4     8        h     u                    est,
measure 29
rest   8        h
rest   4        q
B3     4        q     u                    and
measure 30
B3    12        h.    u                    peace
B3     4        q     u                    on
measure 31
B3    16        w     u                    earth,
measure 32
rest  16
measure 33
D4     4        q     u                    good
G4     4-       q     u        -           will_
G4     2        e     u                    _
F#4    1        s     u  [[     (          to-
E4     1        s     u  =]                -
F#4    2        e     u  ]      )          -
D4     2        e     u                    wards
measure 34
E4     4        q     u                    men,
A4     4-       q     u        -           to-
A4     2        e     u                    -
G4     1        s     u  [[     (          -
F#4    1        s     u  ]]                -
G4     2        e     u         )          -
E4     2        e     u                    wards
measure 35
F#4    4        q     u                    men,
rest   4        q
F#4    4        q     u                    good
D4     4        q     u                    will,
measure 36
rest   8        h
G4     4        q     u                    good
E4     4        q     u                    will,
measure 37
rest   8        h
A4     4        q     u                    good
F#4    4        q     u                    will,
measure 38
rest   8        h
rest   4        q
A4     4        q     u                    good
measure 39
G4     4        q     u                    will
A4     2        e     u                    to-
A4     2        e     u                    wards
D4     4        q     u                    men,
B4     4        q     u                    good
measure 40
A4     4        q     u         (          will_
G4     4        q     u                    _
A4     8        h     u         )          _
measure 41
A4    12        h.    u                    to-
A4     4        q     u                    wards
measure 42
A4     8        h     u                    men.
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 08
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/08} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:f970bf71ea9e3610d2128a04a87ddcdb]
04/10/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 8 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:34   D:Allegro
D4     4        q     d                    Glo-
C#4    3        e.    d                    ry
B3     1        s     u                    to
A3     4        q     u                    God,
rest   4        q
measure 2
B3     4        q     u                    glo-
A3     3        e.    u                    ry
G3     1        s     u                    to
D4     4        q     d                    God
D4     2        e     d                    in
D4     2        e     d                    the
measure 3
G4    16        w     d                    high-
measure 4
D4     8        h     d                    est,
rest   8        h
measure 5
rest   8        h
rest   4        q
A3     4        q     u                    and
measure 6
A3    12        h.    u                    peace
A3     4        q     u                    on
measure 7
A3    16        w     u                    earth!
measure 8
rest  16
measure 9
rest  16
measure 10
D4     4        q     d                    Glo-
C#4    3        e.    d                    ry
B3     1        s     u                    to
A3     4        q     u                    God,
rest   4        q
measure 11
B3     4        q     u                    glo-
A3     3        e.    u                    ry
G3     1        s     u                    to
F#3    4        q     u                    God,
rest   4        q
measure 12
G4     4        q     d                    glo-
F#4    3        e.    d                    ry
E4     1        s     d                    to
D4     4        q     d                    God
F#4    2        e     d                    in
F#4    2        e     d                    the
measure 13
A4     8        h     d                    high-
A3     8        h     u                    est,
measure 14
rest   8        h
rest   4        q
D4     4        q     d                    and
measure 15
D4    12        h.    d                    peace
D3     4        q     u                    on
measure 16
D3    16        w     u                    earth,
measure 17
rest  16
measure 18
rest   8        h
A3     4        q     u                    good
D4     4-       q     d        -           will_
measure 19
D4     2        e     d                    _
C#4    1        s     d  [[     (          to-
B3     1        s     d  ]]                -
C#4    2        e     d         )          -
A3     2        e     u                    wards
E4     8        h     d                    men,
measure 20
D4     6        q.    d                    to-
D4     2        e     d                    wards
A3     8        h     u                    men,
measure 21
rest  16
measure 22
E4     4        q     d                    good
A4     4-       q     d        -           will_
A4     2        e     d                    _
G4     1        s     d  [[     (          to-
F#4    1        s     d  ]]                -
E4     2        e     d         )          -
D4     2        e     d                    wards
measure 23
C#4    8        h     d                    men,
B3     8        h     d                    good
measure 24
E4     4        q     d         (          will_
D4     4        q     d         )          _
E4     6        q.    d                    to-
E4     2        e     d                    wards
measure 25
A3     8        h     u                    men.
rest   8        h
measure 26
F#4    4        q     d                    Glo-
F#4    3        e.    d                    ry
G4     1        s     d                    to
A4     4        q     d                    God,
rest   4        q
measure 27
F#4    4        q     d                    glo-
F#4    3        e.    d                    ry
G4     1        s     d                    to
D4     4        q     d                    God
D4     2        e     d                    in
D4     2        e     d                    the
measure 28
G4     8        h     d                    high-
F#4    8        h     d                    est,
measure 29
rest   8        h
rest   4        q
G3     4        q     u                    and
measure 30
G3    12        h.    u                    peace
G3     4        q     u                    on
measure 31
G3    16        w     u                    earth,
measure 32
rest  16
measure 33
rest   8        h
A3     4        q     u                    good
D4     4-       q     d        -           will_
measure 34
D4     2        e     d                    _
C#4    1        s     d  [[     (          to-
B3     1        s     d  ]]                -
C#4    2        e     d         )          -
A3     2        e     u                    wards
B3     2        e     u  [                 men,_
A3     2        e     u  ]                 _
B3     2        e     u                    to-
C#4    2        e     d                    wards
measure 35
D4     4        q     d                    men,
rest   4        q
A3     4        q     u                    good
B3     4        q     u                    will,
measure 36
rest   8        h
E4     4        q     d                    good
C#4    4        q     d                    will,
measure 37
rest   8        h
F#4    4        q     d                    good
D4     4        q     d                    will,
measure 38
rest   8        h
rest   4        q
F#4    4        q     d                    good
measure 39
E4     4        q     d                    will
E4     2        e     d                    to-
C#4    2        e     d                    wards
D4     2        e     d  [                 men,_
C#4    2        e     d  =                 _
D4     2        e     d  =                 _
E4     2        e     d  ]                 _
measure 40
F#4    4        q     d                    _
B3     4        q     d                    good
E4     4        q     d         (          will_
F#4    4        q     d         )          _
measure 41
E4    12        h.    d                    to-
E4     4        q     d                    wards
measure 42
F#4    8        h     d                    men.
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 09
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/09} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:a27f15f371c04e4733926ba5f9f811ec]
04/10/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 9 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
A3     4        q     d                    and
measure 6
A3    12        h.    d                    peace
A2     4        q     u                    on
measure 7
A2    16        w     u                    earth!
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
D4     4        q     d                    and
measure 15
D4    12        h.    d                    peace
D3     4        q     u                    on
measure 16
D3    16        w     u                    earth,
measure 17
rest  16
measure 18
D3     4        q     u                    good
G3     4-       q     d        -           will_
G3     2        e     d                    _
F#3    1        s     d  [[     (          to-
E3     1        s     d  ]]                -
F#3    2        e     d         )          -
D3     2        e     u                    wards
measure 19
A3     8        h     d                    men,
rest   8        h
measure 20
rest  16
measure 21
rest   8        h
A3     4        q     d                    good
D4     4-       q     d        -           will_
measure 22
D4     2        e     d                    _
C#4    1        s     d  [[     (          to-
B3     1        s     d  ]]                -
C#4    2        e     d         )          -
A3     2        e     d                    wards
B3     8        h     d                    men,
measure 23
A3    12        h.    d                    good
G3     4-       q     d        -           will_
measure 24
G3     4        q     d                    _
F#3    4        q     d                    _
E3     6        q.    d                    to-
E3     2        e     d                    wards
measure 25
D3     8        h     u                    men.
rest   8        h
measure 26
D4     4        q     d                    Glo-
C#4    3        e.    d                    ry
B3     1        s     d                    to
A3     4        q     d                    God,
rest   4        q
measure 27
B3     4        q     d                    glo-
A3     3        e.    d                    ry
G3     1        s     d                    to
F#3    4        q     d                    God
F#3    2        e     d                    in
F#3    2        e     d                    the
measure 28
G3     8        h     d                    high-
D3     8        h     u                    est,
measure 29
rest   8        h
rest   4        q
G3     4        q     d                    and
measure 30
G3    12        h.    d                    peace
G2     4        q     u                    on
measure 31
G2    16        w     u                    earth,
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
rest   8        h
D3     4        q     u                    good
G3     4        q     d                    will,
measure 36
rest   8        h
E3     4        q     d                    good
A3     4        q     d                    will,
measure 37
rest   8        h
F#3    4        q     d                    good
B3     4        q     d                    will,
measure 38
rest   8        h
A3     4        q     d                    good
D4     4-       q     d        -           will_
measure 39
D4     2        e     d                    _
C#4    1        s     d  [[     (          to-
B3     1        s     d  ]]                -
C#4    2        e     d         )          -
A3     2        e     d                    wards
B3     2        e     d  [                 men,_
A3     2        e     d  =                 _
B3     2        e     d  =                 _
C#4    2        e     d  ]                 _
measure 40
D4     4        q     d                    _
G3     8        h     d                    good
F#3    4        q     d                    will
measure 41
A3    12        h.    d                    to-
A3     4        q     d                    wards
measure 42
D3     8        h     u                    men.
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 10
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-19/10} [KHM:1801793848]
TIMESTAMP: DEC/26/2001 [md5sum:883d7299f2de09b1a5195ca94ab95c0d]
04/10/90 E. Correia
WK#:56        MV#:1,19
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 10 of 10
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:12   D:Allegro
D4     4        q     d
C#4    3        e.    d  [
B3     1        s     d  ]\
A3     4        q     d
rest   4        q
measure 2
B3     4        q     d
A3     3        e.    u  [
G3     1        s     u  ]\
D4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
measure 3
G4    16        w     d
measure 4
D4     8        h     d
rest   8        h
$ C:22
measure 5
rest   8        h
rest   4        q
*               D +     Tutti
*               D       tasto solo
A3     4        q     d
measure 6
A3    12        h.    d
A2     4        q     u
measure 7
A2    16        w     u
measure 8
rest  16
measure 9
rest  16
$ C:12
measure 10
*               D +     Violonc.
D4     4        q     d
f1              6
C#4    3        e.    d  [
B3     1        s     d  ]\
A3     4        q     u
rest   4        q
measure 11
B3     4        q     d
f1              6
A3     3        e.    u  [
G3     1        s     u  ]\
F#3    4        q     u
rest   4        q
measure 12
G4     4        q     d
F#4    3        e.    d  [
E4     1        s     d  ]\
D4     4        q     d
f1              6
F#4    2        e     d  [
F#4    2        e     d  ]
measure 13
A4     8        h     d
A3     8        h     u
$ C:22
measure 14
rest   8        h
rest   4        q
*               D +     Tutti
*               D       tasto solo
D4     4        q     d
measure 15
D4    12        h.    d
D3     4        q     u
measure 16
D3    16        w     u
measure 17
rest  16
measure 18
D3     4        q     d
G3     4-       q     d        -
G3     2        e     d  [
F#3    1        s     d  =[
E3     1        s     d  ]]
F#3    2        e     d  [
D3     2        e     d  ]
&
Alternate reading, not used in the CCARH score or parts
measure 18                  |
rest   8        h           |   Doubles the tenor part
A3     4        q     u     |   instead of the base part
D4     4        q     u     |
&
measure 19
f1     4        4
f1              3
A3     8        h     d
$ C:12
f2     4        5 4
f2              6 3
E4     8        h     d
measure 20
D4     6        q.    d
D4     2        e     d
f1     4        4
f1              3
A3     8        h     u
$ C:15
measure 21
D4     4        q     d
G4     4        q     d
$ C:22
f1              7
A3     4        q     d
f1              3
D4     4-       q     d        -
measure 22
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
C#4    2        e     d  [
A3     2        e     d  ]
f1     4        7
f1              6
B3     8        h     d
measure 23
f1     2        7
f1     4        6
f1     2        5
f2              4 2
A3    12        h.    d
f1              6
G3     4-       q     d        -
measure 24
f2              4 2
G3     4        q     d
f1              6
F#3    4        q     d
E3     6        q.    d
E3     2        e     d
measure 25
D3     8        h     u
rest   8        h
measure 26
D4     4        q     d
C#4    3        e.    d  [
B3     1        s     d  ]\
A3     4        q     d
rest   4        q
measure 27
B3     4        q     d
A3     3        e.    d  [
G3     1        s     d  ]\
F#3    4        q     d
F#3    2        e     d  [
F#3    2        e     d  ]
measure 28
G3     8        h     d
D3     8        h     u
measure 29
rest   8        h
rest   4        q
G3     4        q     d
measure 30
G3    12        h.    d
G2     4        q     u
measure 31
G2    16        w     u
measure 32
rest  16
$ C:13
measure 33
rest   8        h
A3     4        q     d
D4     4-       q     d        -
measure 34
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
C#4    2        e     d  [
A3     2        e     d  ]
B3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 35
D4     8        h     d
&
alternate reading, not used in CCARH score or parts
measure 33                          |
D4     4        q     u             |
G4     4-       q     u        -    |   This music doubles
G4     2        e     u  [          |   the Alto (and Soprano)
F#4    1        s     u  =[         |
E4     1        s     u  ]]         |   rather than the Tenor
F#4    2        e     u  [          |   as above
D4     2        e     u  ]          |
measure 34                          |
E4     4        q     u             |
A4     4-       q     u        -    |
A4     2        e     u  [          |
G4     1        s     u  =[         |
F#4    1        s     u  ]]         |
G4     2        e     u  [          |
E4     2        e     u  ]          |
measure 35                          |
A4     4        q     u             |
D5     4        q     u             |
&
$ C:22
D3     4        q     u
G3     4        q     d
$ C:15
measure 36
B4     4        q     d
E5     4        q     d
$ C:22
E3     4        q     d
A3     4        q     d
$ C:15
measure 37
C#5    4        q     d
F#5    4        q     d
$ C:22
F#3    4        q     d
B3     4        q     d
$ C:15
measure 38
D5     4        q     d
G5     4        q     d
$ C:22
f1              7
A3     4        q     d
f1              3
D4     4-       q     d        -
measure 39
f1              2
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
f1              6
C#4    2        e     d  [
A3     2        e     d  ]
f1              6
B3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 40
D4     4        q     d
f1     2        6
f1     2        5
f2              4 2
G3     8        h     d
f1              6
F#3    4        q     d
measure 41
A3     8        h     d
A2     8        h     u
measure 42
D3     8        h     u
$ C:12
*               D +     Violonc.
f1     4        7
f1              6
B3     6        q.    d
C#4    2        e     d
measure 43
D4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
G4     2        e     d  ]
A4     2        e     d  [
A3     2        e     d  ]
A4     4-       q     d        -
measure 44
A4     2        e     d  [
G4     1        s     d  =[
F#4    1        s     d  ]]
E4     2        e     d  [
D4     2        e     d  ]
C#4    2        e     d  [
A3     2        e     d  =
D4     2        e     d  =      &p
C#4    2        e     d  ]
measure 45
f2              6 5
B3     4        q     d
f2              6 5
C#4    4        q     d
D4     4        q     d
f1              6
C#4    4        q     d
measure 46
f1              7
B3     4        q     d         pp
rest   4        q
f1              7
E4     4        q     d
rest   4        q
measure 47
A3     4        q     u
rest   4        q
D4     4        q     d
rest   4        q
measure 48
A4     4        q     d
rest   4        q
A3     4        q     u
rest   4        q
measure 49
D3     4        q     u
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
