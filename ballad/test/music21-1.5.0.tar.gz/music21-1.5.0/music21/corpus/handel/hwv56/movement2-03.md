&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/1} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:c4814ebee62475527717a2471efd501c]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
2 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Largo e staccato
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
F5     8        q     d
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
F5     8        q     d
measure 2
rest   2        s
F4     2        s     u  [[
F4     3        s.    u  ==
F4     1        t     u  ]]\
F5     8-       q     d        -
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
G5     1        t     d  ]]\
measure 3
E5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
D5     1        t     d  ]]\
Ef5    6        e.    d  [
F5     2        s     d  ]\
D5     3        s.    d  [[
Bf4    1        t     d  ==\
Bf4    3        s.    d  ==
C5     1        t     d  ]]\
Df5    6        e.    d  [
Ef5    2        s     d  ]\
measure 4
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
Af5    8        q     d
rest   2        s
Bf4    2        s     u  [[
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
G5     8        q     d
measure 5
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
F5     8-       q     d        -
F5     3        s.    d  [[
C5     1        t     d  ==\
Bf4    3        s.    d  ==
Af4    1        t     d  ]]\
G4     6        e.    u  [      &t
F4     2        s     u  ]\
measure 6
F4     3        s.    u  [[
C5     1        t     u  ==\
C5     3        s.    u  ==
C5     1        t     u  ]]\
F5     8        q     d
rest   2        s
Bf4    2        s     u  [[
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
G5     8        q     d
measure 7
rest   2        s
F4     2        s     u  [[
F4     3        s.    u  ==
F4     1        t     u  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
measure 8
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
G5     8        q     d
G4     8        q     u
measure 9
rest   2        s
G5     2        s     d  [[
G5     3        s.    d  ==
G5     1        t     d  ]]\
C6     8        q     d
rest   2        s
G5     2        s     d  [[
G5     3        s.    d  ==
G5     1        t     d  ]]\
C6     8        q     d
measure 10
rest   2        s
C4     2        s     u  [[
C4     3        s.    u  ==
C4     1        t     u  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
measure 11
D5     3        s.    d  [[
D5     1        t     d  ==\
D5     3        s.    d  ==
D5     1        t     d  ]]\
D5     4        e     u  [
D4     4        e     u  ]
rest   2        s
D5     2        s     d  [[
D5     3        s.    d  ==
D5     1        t     d  ]]\
G5     8        q     d
measure 12
rest   2        s
G4     2        s     u  [[
G4     3        s.    u  ==
G4     1        t     u  ]]\
C5     8-       q     d        -
C5     3        s.    d  [[
C5     1        t     d  ==\
B4     3        s.    d  ==
A4     1        t     d  ]]\
B4     4        e     u  [
G4     4        e     u  ]
measure 13
C5    24        h.    d
Bf4    8        q     u         +
measure 14
Ef5   24        h.    d
Ef5    8        q     d
measure 15
D5     8        q     d
D5     8        q     d
E5    12        q.    d
E5     4        e     d
measure 16
F5    24        h.    d
Ef5    8        q     d         +
measure 17
Df5   16        h     d
C5    16-       h     d        -
measure 18
C5    16        h     d
Bf4   16        h     u
measure 19
C5     6        e.    u  [
G4     2        s     u  ]\
G4     8        q     u
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
Af5    3        s.    d  [[
Af5    1        t     d  ==\
Af5    3        s.    d  ==
Af5    1        t     d  ]]\
measure 20
Af5    3        s.    d  [[
Af5    1        t     d  ==\
Af5    3        s.    d  ==
Af5    1        t     d  ]]\
G5     3        s.    d  [[
G5     1        t     d  ==\
G5     3        s.    d  ==
G5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
Bf5    3        s.    d  [[
Bf5    1        t     d  ==\
Bf5    3        s.    d  ==
Bf5    1        t     d  ]]\
measure 21
Bf5    3        s.    d  [[
Bf5    1        t     d  ==\
Bf5    3        s.    d  ==
Bf5    1        t     d  ]]\
Af5    3        s.    d  [[
Af5    1        t     d  ==\
Af5    3        s.    d  ==
Af5    1        t     d  ]]\
G5     3        s.    d  [[
G5     1        t     d  ==\
G5     3        s.    d  ==
G5     1        t     d  ]]\
C6     3        s.    d  [[
C6     1        t     d  ==\
C6     3        s.    d  ==
C6     1        t     d  ]]\
measure 22
C6     3        s.    d  [[
C6     1        t     d  ==\
C6     3        s.    d  ==
C6     1        t     d  ]]\
Bf5    3        s.    d  [[
Bf5    1        t     d  ==\
Bf5    3        s.    d  ==
Bf5    1        t     d  ]]\
Bf5    3        s.    d  [[
Bf5    1        t     d  ==\
Bf5    3        s.    d  ==
Bf5    1        t     d  ]]\
Af5    3        s.    d  [[
Af5    1        t     d  ==\
Af5    3        s.    d  ==
Af5    1        t     d  ]]\
measure 23
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 24
Bf4    3        s.    u  [[
Bf4    1        t     u  ==\
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
Ef5    8        q     d
rest   2        s
Ef5    2        s     d  [[
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
C6     8        q     d
measure 25
rest   2        s
Df5    2        s     d  [[
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
Bf5    8        q     d
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
Af5    8        q     d
measure 26
rest   2        s
Bf4    2        s     d  [[
C5     3        s.    d  ==
Df5    1        t     d  ]]\
Bf4    6        e.    u  [      &t
Af4    2        s     u  ]\
Af4    8        q     u
rest   8        q
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  16        h
C5    16        h     d
measure 28
Af4   16        h     u
Df5   16        h     d
measure 29
E4    32        w     u
measure 30
F4    24        h.    u
G4     8        q     u
measure 31
Af4   24        h.    u
Bf4    8        q     u
measure 32
C5    32        w     d
measure 33
rest   8        q
D5     8        q     d
G5     8        q     d
F5     8        q     d
measure 34
Ef5    8        q     d
D5     8        q     d
C5     8        q     d
B4     8        q     u
measure 35
C5     8        q     d
G4     8        q     u
C5    16-       h     d        -
measure 36
C5    16        h     d
Bf4   16-       h     u        -
measure 37
Bf4   16        h     u
Af4   16        h     u
measure 38
G4    32        w     u
measure 39
F4     8        q     u
G4     8        q     u
Af4    8        q     u
Bf4    8        q     u
measure 40
C5    16        h     d
G4    16        h     u
measure 41
rest  32
measure 42
rest   8        q
C5     8        q     d
F5     8        q     d
Ef5    8        q     d
measure 43
Df5    8        q     d
C5     8        q     d
Bf4    8        q     u
A4     8        q     u
measure 44
Bf4    8        q     u
C5     8        q     d
Df5   16        h     d
measure 45
C5    16        h     d
C5    16        h     d
measure 46
C5    24        h.    d
C5     8        q     d
measure 47
D5    32        w     d         +
measure 48
G4    16        h     u
rest  16        h
measure 49
rest  32
measure 50
rest  32
measure 51
rest  16        h
F5    16        h     d
measure 52
Ef5   16        h     d
Af5   16        h     d
measure 53
B4    32        w     u
measure 54
C5    16        h     d
D5    16        h     d
measure 55
Ef5   24        h.    d
F5     4        e     d  [
Ef5    4        e     d  ]
measure 56
Df5    8        q     d
C5     8        q     d
Df5   16        h     d
measure 57
C5    32        w     d
measure 58
F4    16        h     u
rest  16        h
measure 59
rest  32
measure 60
rest  32
measure 61
rest  32
measure 62
rest  32
measure 63
rest  32
measure 64
rest  32
measure 65
rest   8        q
G4     8        q     u
C5     8        q     d
Bf4    8        q     u
measure 66
Af4    8        q     u
G4     8        q     u
F4     8        q     u
E4     8        q     u
measure 67
F4     8        q     u
C5     8        q     d
F5     8        q     d
Ef5    8        q     d         +
measure 68
Df5    8        q     d
C5     8        q     d
Bf4    8        q     u
A4     8        q     u
measure 69
Bf4    8        q     u
C5     8        q     d
Df5   16-       h     d        -
measure 70
Df5   16        h     d
C5    16        h     d
measure 71
Bf4   32-       w     u        -
measure 72
Bf4   16        h     u
Af4   16-       h     u        -
measure 73
Af4    8        q     u
Bf4    8        q     u
G4     8        q     u
Af4    8        q     u
measure 74
F4    32        w     u
measure 75
rest  32
measure 76
rest  32
measure 77
rest  32
measure 78
rest  32
measure 79
rest  32
measure 80
rest  32
measure 81
rest  16        h
Ef5   16        h     d
measure 82
C5    16        h     d
F5    16        h     d
measure 83
G4    32        w     u
measure 84
Af4   16        h     u
Bf4   16        h     u
measure 85
C5     8        q     d
Af4    8        q     u
Df5   16-       h     d        -
measure 86
Df5    8        q     d
Ef5    8        q     d
C5     8        q     d
Df5    8        q     d
measure 87
Bf4   16        h     u
Af4    8        q     u
Df5    8        q     d
measure 88
Bf4   32        w     u
measure 89
Af4   16        h     u
C5    16        h     d
measure 90
Af4   16        h     u
Df5   16        h     d
measure 91
E4    32        w     u
measure 92
F4    16        h     u
G4    16        h     u
measure 93
Af4   32        w     u
measure 94
G4    24        h.    u
F4     8        q     u
measure 95
G4    32        w     u
measure 96
rest  32
measure 97
rest  32
measure 98
rest  32
measure 99
rest  32
measure 100
rest  32
measure 101
rest  32
measure 102
rest  32
measure 103
rest  32
measure 104
rest  32
measure 105
rest  16        h
F5    16        h     d
measure 106
Ef5   16        h     d
Af5   16        h     d
measure 107
B4    32        w     u
measure 108
C5    16        h     d
D5    16        h     d
measure 109
Ef5   16        h     d
E5    16        h     d
measure 110
F5    32        w     d
measure 111
C5    32-       w     d        -
measure 112
C5    16        h     d
Bf4   16        h     u
measure 113
Af4    8        q     u
G4     8        q     u
Af4    8        q     u
Bf4    8        q     u
measure 114
C5    32-       w     d        -
measure 115
$ D:Adagio
C5    32        w     d
measure 116
Bf4   32        w     d
measure 117
C5    32        b     d         F
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/2} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:f47f6aa1b1e6181f4843f130893f2d3b]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
2 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Largo e staccato
Af4    8        q     u
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
F4     8        q     u
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 2
Bf4    8        q     u
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
Af4    6        e.    u  [
Af4    2        s     u  ]\
G4     3        s.    u  [[
G4     1        t     u  ==\
G4     3        s.    u  ==
G4     1        t     u  ]]\
measure 3
G4     8        q     u
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
F4     8        q     u
rest   2        s
Bf4    2        s     u  [[
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
measure 4
Ef4    8        q     u
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
Af4    8        q     u
rest   2        s
G4     2        s     u  [[
G4     3        s.    u  ==
G4     1        t     u  ]]\
measure 5
G4     8        q     u
rest   2        s
F4     2        s     u  [[
F4     3        s.    u  ==
F4     1        t     u  ]]\
F4     4        e     u
F4     8        q     u
E4     4        e     u
measure 6
F4     3        s.    u  [[
C5     1        t     u  ==\
C5     3        s.    u  ==
C5     1        t     u  ]]\
F5     3        s.    u  [[
F4     1        t     u  ==\
F4     3        s.    u  ==
F4     1        t     u  ]]\
Bf4    8        q     u
rest   2        s
Bf4    2        s     u  [[
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
measure 7
Af4    8        q     u
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
Af4    3        s.    u  [[
Af4    1        t     u  ==\
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
Af4    3        s.    u  [[
Af4    1        t     u  ==\
G4     3        s.    u  ==
G4     1        t     u  ]]\
measure 8
G4     3        s.    u  [[
G4     1        t     u  ==\
G4     3        s.    u  ==
G4     1        t     u  ]]\
G4     3        s.    u  [[
G4     1        t     u  ==\
C5     3        s.    u  ==
C5     1        t     u  ]]\
B4     3        s.    u  [[
B4     1        t     u  ==\
B4     3        s.    u  ==
B4     1        t     u  ]]\
B4     3        s.    u  [[
B4     1        t     u  ==\
B4     3        s.    u  ==
B4     1        t     u  ]]\
measure 9
G4     8        q     u
rest   2        s
Ef4    2        s     u  [[
Ef4    3        s.    u  ==
Ef4    1        t     u  ]]\
Ef5    8        q     d
rest   2        s
G4     2        s     u  [[
G4     3        s.    u  ==
G4     1        t     u  ]]\
measure 10
C5     8        q     d
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 11
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
B4     8        q     u
rest   2        s
D4     2        s     u  [[
D4     3        s.    u  ==
D4     1        t     u  ]]\
measure 12
G4     8        q     u
rest   2        s
Ef4    2        s     u  [[
Ef4    3        s.    u  ==
Ef4    1        t     u  ]]\
D4     8        q     u
G4     8-       q     u        -
measure 13
G4     8        q     u
F4     8        q     u
G4    16-       h     u        -
measure 14
G4     8        q     u
A4     4        e     u  [
G4     4        e     u  ]
A4    12        q.    u
A4     4        e     u
measure 15
A4     8        q     u
G4     8        q     u
G4    12        q.    u
G4     4        e     u
measure 16
F4     8        q     u
G4     8        q     u
A4     8        q     u
F4     8        q     u
measure 17
F4    16        h     u
G4     8        q     u
F4     4        e     u  [
Af4    4        e     u  ]      +
measure 18
Af4   16        h     u
G4     8        q     u
F4     8        q     u
measure 19
G4     6        e.    u  [
F4     2        s     u  ]\
E4     8        q     u
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 20
Bf4    3        s.    u  [[
Bf4    1        t     u  ==\
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
measure 21
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
F5     3        s.    d  [[
F5     1        t     d  ==\
F5     3        s.    d  ==
F5     1        t     d  ]]\
Ef5    3        s.    d  [[
Ef5    1        t     d  ==\
Ef5    3        s.    d  ==
Ef5    1        t     d  ]]\
measure 22
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
Df5    3        s.    d  [[
Df5    1        t     d  ==\
Df5    3        s.    d  ==
Df5    1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 23
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
Bf4    3        s.    u  [[
Bf4    1        t     u  ==\
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
Bf4    3        s.    u  [[
Bf4    1        t     u  ==\
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
Af4    3        s.    u  [[
Af4    1        t     u  ==\
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
measure 24
Af4    3        s.    u  [[
Af4    1        t     u  ==\
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
G4     3        s.    u  [[
G4     1        t     u  ==\
G4     3        s.    u  ==
G4     1        t     u  ]]\
C5     8        q     d
rest   2        s
C5     2        s     d  [[
C5     3        s.    d  ==
C5     1        t     d  ]]\
measure 25
C5     8        q     d
rest   2        s
Bf4    2        s     u  [[
Bf4    3        s.    u  ==
Bf4    1        t     u  ]]\
Bf4    8        q     u
rest   2        s
Af4    2        s     u  [[
Af4    3        s.    u  ==
Af4    1        t     u  ]]\
measure 26
Af4    3        s.    u  [[
G4     1        t     u  =]\
Af4    4        e     u  ]
Af4    4        e     u  [
G4     4        e     u  ]
Af4    8        q     u
rest   8        q
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  32
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  16        h
F4    16        h     u
measure 32
Ef4   16        h     u
Af4   16        h     u
measure 33
B3    32        w     u
measure 34
C4    16        h     u
D4    16        h     u
measure 35
Ef4   24        h.    u
F4     8        q     u
measure 36
G4     8        q     u
F4     8        q     u
D4     8        q     u
E4     8        q     u
measure 37
F4     8        q     u
C4     8        q     u
F4    16-       h     u        -
measure 38
F4    16        h     u
E4    16        h     u
measure 39
F4    32        w     u
measure 40
rest   8        q
G4     8        q     u
C5     8        q     d
Bf4    8        q     u
measure 41
Af4    8        q     u
G4     8        q     u
F4     8        q     u
E4     8        q     u
measure 42
F4    32-       w     u        -
measure 43
F4    32-       w     u        -
measure 44
F4    16        h     u
Bf4   16-       h     u        -
measure 45
Bf4   16        h     u
Af4   16        h     u
measure 46
G4    16        h     u
F4     8        q     u
Ef4    8        q     u
measure 47
D4    32        w     u
measure 48
C4    16        h     u
rest  16        h
measure 49
rest   8        q
G4     8        q     u
C5     8        q     d
Bf4    8        q     u
measure 50
Af4    8        q     u
G4     8        q     u
F4     8        q     u
E4     8        q     u
measure 51
F4    16        h     u
C4    16        h     u
measure 52
rest  32
measure 53
rest  32
measure 54
rest  32
measure 55
rest  32
measure 56
rest  32
measure 57
rest  32
measure 58
rest  32
measure 59
rest   8        q
C4     8        q     u
F4     8        q     u
Ef4    8        q     u
measure 60
Df4    8        q     u
C4     8        q     u
Bf3    8        q     u
A3     8        q     u
measure 61
Bf3    8        q     u
Bf4    8        q     u
F4     8        q     u
G4     8        q     u
measure 62
Af4   24        h.    u
Bf4    4        e     u  [
Af4    4        e     u  ]
measure 63
G4    24        h.    u
E4     8        q     u
measure 64
F4     8        q     u
G4     8        q     u
Af4    8        q     u
Bf4    8        q     u
measure 65
C5    16        h     d
C4    16        h     u
measure 66
C4    16        h     u
rest  16        h
measure 67
rest  32
measure 68
rest  32
measure 69
rest  32
measure 70
rest  32
measure 71
rest  32
measure 72
rest  32
measure 73
rest  32
measure 74
rest  16        h
Bf4   16        h     u
measure 75
G4    16        h     u
C5    16        h     d
measure 76
D4    32        w     u
measure 77
Ef4   16        h     u
F4    16        h     u
measure 78
G4     8        q     u
Ef4    8        q     u
Af4   16-       h     u        -
measure 79
Af4    8        q     u
Bf4    8        q     u
G4     8        q     u
Af4    8        q     u
measure 80
F4    32        w     u
measure 81
Bf3   32        w     u
measure 82
rest  32
measure 83
rest  32
measure 84
rest  32
measure 85
rest  32
measure 86
rest  32
measure 87
rest  32
measure 88
rest   8        q
Bf4    8        q     u
Ef5    8        q     d
Df5    8        q     d
measure 89
C5     8        q     d
Bf4    8        q     u
Af4    8        q     u
G4     8        q     u
measure 90
F4    16        h     u
Bf3   16        h     u
measure 91
G3    16        h     u
rest  16        h
measure 92
rest  32
measure 93
rest  32
measure 94
rest  32
measure 95
rest   8        q
D4     8        q     u
G4     8        q     u
F4     8        q     u
measure 96
Ef4    8        q     u
Af4    8        q     u
G4     8        q     u
F4     8        q     u
measure 97
G4     8        q     u
C5     8        q     d
G4     8        q     u
Af4    8        q     u
measure 98
Bf4   24        h.    u
Af4    4        e     u  [
G4     4        e     u  ]
measure 99
Af4   32        w     u
measure 100
A4    32        w     u
measure 101
Bf4    8        q     u
Bf4    8        q     u
F4     8        q     u
G4     8        q     u
measure 102
Af4   24        h.    u         +
G4     4        e     u  [
F4     4        e     u  ]
measure 103
G4    32-       w     u        -
measure 104
G4    16        h     u
G4    16        h     u
measure 105
Af4   32        w     u
measure 106
G4    16        h     u
F4     8        q     u
Ef4    8        q     u
measure 107
D4    16        h     u
rest  16        h
measure 108
rest  32
measure 109
rest  32
measure 110
rest  32
measure 111
rest   8        q
G4     8        q     u
C5     8        q     d
Bf4    8        q     u
measure 112
Af4    8        q     u
G4     8        q     u
F4     8        q     u
E4     8        q     u
measure 113
F4     8        q     u
E4     8        q     u
F4     8        q     u
G4     8        q     u
measure 114
Af4   24        h.    u
G4     8        q     u
measure 115
$ D:Adagio
F4    32-       w     u        -
measure 116
F4    32        w     u
measure 117
E4    32        b     u         F
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/3} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:7667b0c252890df06d69204a571e7faf]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
2 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:13   D:Largo e staccato
C4     8        q     u
rest   2        s
C4     2        s     u  [[
C4     3        s.    u  ==
C4     1        t     u  ]]\
C4     8        q     u
rest   2        s
Af4    2        s     d  [[
Af4    3        s.    d  ==
Af4    1        t     d  ]]\
measure 2
F4     8        q     d
rest   2        s
F4     2        s     d  [[
F4     3        s.    d  ==
F4     1        t     d  ]]\
D4     8        q     d
rest   2        s
D4     2        s     d  [[
D4     3        s.    d  ==
D4     1        t     d  ]]\
measure 3
E4     8        q     d
rest   2        s
F4     2        s     d  [[
F4     3        s.    d  ==
F4     1        t     d  ]]\
Bf4    8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 4
Af4    8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
F4     8        q     d
rest   2        s
C4     2        s     u  [[
C4     3        s.    u  ==
C4     1        t     u  ]]\
measure 5
C4     8        q     u
rest   2        s
Df4    2        s     d  [[
Df4    3        s.    d  ==
Df4    1        t     d  ]]\
C4     4        e     u  [
Df4    4        e     u  =
G3     4        e     u  =
C4     4        e     u  ]
measure 6
C4     3        s.    d  [[
F4     1        t     d  ==\
F4     3        s.    d  ==
F4     1        t     d  ]]\
Af4    3        s.    d  [[
C4     1        t     d  ==\
C4     3        s.    d  ==
C4     1        t     d  ]]\
E4     8        q     d
rest   2        s
E4     2        s     d  [[
E4     3        s.    d  ==
E4     1        t     d  ]]\
measure 7
F4     8        q     d
rest   2        s
Ef4    2        s     d  [[     +
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
D4     3        s.    d  [[
D4     1        t     d  ==\
D4     3        s.    d  ==
D4     1        t     d  ]]\
D4     3        s.    d  [[
D4     1        t     d  ==\
D4     3        s.    d  ==
D4     1        t     d  ]]\
measure 8
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
C4     3        s.    d  ==
C4     1        t     d  ]]\
D4     3        s.    d  [[
D4     1        t     d  ==\
D4     3        s.    d  ==
D4     1        t     d  ]]\
D4     3        s.    d  [[
D4     1        t     d  ==\
D4     3        s.    d  ==
D4     1        t     d  ]]\
measure 9
Ef4    8        q     d
rest   2        s
C4     2        s     u  [[
C4     3        s.    u  ==
C4     1        t     u  ]]\
C5     8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 10
Ef4    8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
A4     3        s.    d  [[
A4     1        t     d  ==\
A4     3        s.    d  ==
A4     1        t     d  ]]\
A4     3        s.    d  [[
A4     1        t     d  ==\
A4     3        s.    d  ==
A4     1        t     d  ]]\
measure 11
A4     3        s.    d  [[
A4     1        t     d  ==\
A4     3        s.    d  ==
A4     1        t     d  ]]\
A4     3        s.    d  [[
A4     1        t     d  ==\
A4     3        s.    d  ==
A4     1        t     d  ]]\
G4     8        q     d
rest   2        s
B4     2        s     d  [[
B4     3        s.    d  ==
B4     1        t     d  ]]\
measure 12
C4     8        q     u
rest   2        s
G3     2        s     u  [[
G3     3        s.    u  ==
G3     1        t     u  ]]\
G4     8        q     d
G4     8        q     d
measure 13
Ef4    8        q     d
D4     4        e     d  [
C4     4        e     d  ]
D4    16-       h     d        -
measure 14
D4     8        q     d
C4     8        q     u
C4    12        q.    u
C4     4        e     u
measure 15
C4     8        q     u
Bf3    8        q     u
Bf3   12        q.    u
Bf3    4        e     u
measure 16
Af3    8        q     u         +
Bf3    8        q     u
C4     8        q     u
C4     8-       q     u        -
measure 17
C4     8        q     u
Bf3    8-       q     u        -
Bf3    8        q     u
Af3    4        e     u  [
C4     4        e     u  ]
measure 18
F4    24        h.    d
F4     8        q     d
measure 19
E4     6        e.    d  [
D4     2        s     d  ]\
C4     8        q     u
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 20
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Bf4    3        s.    d  [[
Bf4    1        t     d  ==\
Bf4    3        s.    d  ==
Bf4    1        t     d  ]]\
Bf4    3        s.    d  [[
Bf4    1        t     d  ==\
Bf4    3        s.    d  ==
Bf4    1        t     d  ]]\
F4     3        s.    d  [[
F4     1        t     d  ==\
F4     3        s.    d  ==
F4     1        t     d  ]]\
measure 21
F4     3        s.    d  [[
F4     1        t     d  ==\
F4     3        s.    d  ==
F4     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
C5     3        s.    d  [[
C5     1        t     d  ==\
C5     3        s.    d  ==
C5     1        t     d  ]]\
G4     3        s.    d  [[
G4     1        t     d  ==\
G4     3        s.    d  ==
G4     1        t     d  ]]\
measure 22
Af4    3        s.    d  [[
Af4    1        t     d  ==\
Af4    3        s.    d  ==
Af4    1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 23
Af4    3        s.    d  [[
Af4    1        t     d  ==\
Af4    3        s.    d  ==
Af4    1        t     d  ]]\
F4     3        s.    d  [[
F4     1        t     d  ==\
F4     3        s.    d  ==
F4     1        t     d  ]]\
G4     3        s.    d  [[
G4     1        t     d  ==\
G4     3        s.    d  ==
G4     1        t     d  ]]\
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 24
Ef4    3        s.    d  [[
Ef4    1        t     d  ==\
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Bf4    3        s.    d  [[
Bf4    1        t     d  ==\
Bf4    3        s.    d  ==
Bf4    1        t     d  ]]\
Af4    8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
measure 25
Af4    8        q     d
rest   2        s
Ef4    2        s     d  [[
Ef4    3        s.    d  ==
Ef4    1        t     d  ]]\
Ef4    8        q     d
rest   2        s
F4     2        s     d  [[
F4     3        s.    d  ==
F4     1        t     d  ]]\
measure 26
F4     4        e     d  [
Ef4    4        e     d  =
Ef4    4        e     d  =
Df4    4        e     d  ]
C4     8        q     u
rest   8        q
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  32
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest  32
measure 35
rest  32
measure 36
rest  32
measure 37
rest  32
measure 38
rest  16        h
C4    16        h     u
measure 39
Af3   16        h     u
Df4   16        h     d
measure 40
E3    32        w     u
measure 41
F3    16        h     u
G3    16        h     u
measure 42
Af3   16        h     u
A3    16        h     u
measure 43
Bf3   16        h     u
C4    16        h     u
measure 44
Df4   24        h.    d
Ef4    8        q     d
measure 45
F4    16        h     d
C4    16        h     u
measure 46
rest  32
measure 47
rest   8        q
D4     8        q     d         +
G4     8        q     d
F4     8        q     d
measure 48
Ef4    8        q     d
D4     8        q     d
C4     8        q     u
B3     8        q     u
measure 49
C4    16        h     u
G3    16        h     u
measure 50
C4    24        h.    u
Bf3    8        q     u         +
measure 51
C4    24        h.    u
D4     8        q     d
measure 52
Ef4   32        w     d
measure 53
D4    32        w     d
measure 54
G3    32        w     u
measure 55
rest  32
measure 56
rest  32
measure 57
rest  16        h
F4    16        h     d
measure 58
Df4   16        h     d
Gf4   16        h     d
measure 59
A3    32        w     u
measure 60
Bf3   24        h.    u
C4     8        q     u
measure 61
Df4   24        h.    d
Ef4    4        e     d  [
Df4    4        e     d  ]
measure 62
C4     8        q     u
F4     8        q     d
C4     8        q     u
D4     8        q     d         +
measure 63
E4     8        q     d
F4     8        q     d
G4    16        h     d
measure 64
C4    16        h     u
F4    16        h     d
measure 65
G3    32        w     u
measure 66
Af3   16        h     u
Bf3   16        h     u
measure 67
C4    32        w     u
measure 68
Df4   16        h     d
Ef4   16        h     d
measure 69
F4    32        w     d
measure 70
Ef4   16        h     d
Af3   16-       h     u        -
measure 71
Af3    8        q     u
G3     8        q     u
Af3    8        q     u
Bf3    8        q     u
measure 72
Ef3    8        q     u
Ef4    8        q     d
F4     8        q     d
Ef4    8        q     d
measure 73
D4    16        h     d
Ef4   16-       h     d        -
measure 74
Ef4   16        h     d
D4    16        h     d
measure 75
Ef4   16        h     d
Af3   16        h     u
measure 76
F3    16        h     u
Bf3   16-       h     u        -
measure 77
Bf3   16        h     u
Bf3   16        h     u
measure 78
Ef4   16        h     d
D4     8        q     d
C4     8        q     u
measure 79
D4    16        h     d
Ef4   16-       h     d        -
measure 80
Ef4   16        h     d
D4    16        h     d
measure 81
Ef4   32        w     d
measure 82
Ef4   16        h     d
rest  16        h
measure 83
rest   8        q
Bf3    8        q     u
Ef4    8        q     d
Df4    8        q     d
measure 84
C4     8        q     u
Bf3    8        q     u
Af3    8        q     u
G3     8        q     u
measure 85
Af3   16        h     u
F4    16        h     d
measure 86
Ef4   32        w     d
measure 87
F3     8        q     u
G3     8        q     u
Af3   16-       h     u        -
measure 88
Af3   16        h     u
G3    16        h     u
measure 89
Af3   32        w     u
measure 90
rest  32
measure 91
rest   8        q
G3     8        q     u
C4     8        q     u
Bf3    8        q     u
measure 92
Af3    8        q     u
Df4    8        q     d
C4     8        q     u
Bf3    8        q     u
measure 93
C4     8        q     u
F4     8        q     d
C4     8        q     u
D4     8        q     d         +
measure 94
Ef4    8        q     d
D4     8        q     d
C4    16        h     u
measure 95
D4    32        w     d
measure 96
C4    16        h     u
B3    16        h     u
measure 97
C4    32        w     u
measure 98
rest  32
measure 99
rest   8        q
F4     8        q     d
C4     8        q     u
D4     8        q     d
measure 100
Ef4   24        h.    d
Df4    4        e     d  [
C4     4        e     d  ]
measure 101
Df4   32        w     d
measure 102
D4    32        w     d         +
measure 103
Ef4    8        q     d
Ef4    8        q     d
Bf3    8        q     u
C4     8        q     u
measure 104
Df4   24        h.    d
C4     4        e     u  [
Bf3    4        e     u  ]
measure 105
C4    32        w     u
measure 106
rest  32
measure 107
rest   8        q
G3     8        q     u
G4     8        q     d
F4     8        q     d
measure 108
Ef4    8        q     d
D4     8        q     d
C4     8        q     u
B3     8        q     u
measure 109
C4    32-       w     u        -
measure 110
C4    16        h     u
Bf3   16        h     u
measure 111
G4    32        w     d
measure 112
F4    16        h     d
Bf3   16        h     u
measure 113
C4    24        h.    u
Bf3    8        q     u
measure 114
Af3    8        q     u
Bf3    8        q     u
C4    16        h     u
measure 115
$ D:Adagio
Df4   32-       w     d        -
measure 116
Df4   32        w     d
measure 117
G3    32        b     u         F
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/4} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:4c2311a5ed7655dd9208808c9dddbd2b]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
2 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Largo e staccato
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
C5     3        s.    d                    Su-
Bf4    1        t     u                    re-
Af4    4        e     u                    ly,
rest   8        q
Bf4    3        s.    u                    su-
Af4    1        t     u                    re-
G4     4        e     u                    ly,
rest   4        e
E5     2        s     d                    he
E5     2        s     d                    hath
measure 7
F5    12        q.    d                    borne
F5     4        e     d                    our
F5    12        q.    d                    griefs,
F5     4        e     d                    and
measure 8
Ef5    8        q     d                    car-
Ef5    4        e     d                    ried
F5     4        e     d                    our
G5     8        q     d                    sor-
G5     8        q     d                    rows!
measure 9
Ef5    3        s.    d                    su-
D5     1        t     d                    re-
C5     4        e     d                    ly,
rest   8        q
Ef5    3        s.    d                    su-
D5     1        t     d                    re-
C5     4        e     d                    ly,
rest   4        e
G4     2        s     u                    he
G4     2        s     u                    hath
measure 10
C5    12        q.    d                    borne
C5     4        e     d                    our
C5    12        q.    d                    griefs,
C5     4        e     d                    and
measure 11
C5     8        q     d                    car-
C5     4        e     d                    ried
C5     4        e     d                    our
B4     8        q     u                    sor-
B4     8        q     u                    rows;
measure 12
rest  32
measure 13
C5    24        h.    d                    He
Bf4    8        q     u                    was
measure 14
Ef5    8        q     d                    wound-
Ef5    4        e     d                    ed
Ef5    4        e     d                    for
Ef5   12        q.    d                    our
Ef5    4        e     d                    trans-
measure 15
D5     8        q     d                    gres-
D5     8        q     d                    sions;
E5    12        q.    d                    He
E5     4        e     d                    was
measure 16
F5    24        h.    d                    bruis-
Ef5    8        q     d         +          ed,
measure 17
Df5    8        q     d                    He
Df5    8        q     d                    was
C5     8        q     d                    bruis-
C5     4        e     d                    ed
C5     4        e     d                    for
measure 18
C5    16        h     d                    our
Bf4   16        h     u                    i-
measure 19
C5     6        e.    d                    ni-
G4     2        s     u                    qui-
G4     8        q     u                    ties;
rest   8        q
C5     4        e     d                    the
Ef5    4        e     d                    chas-
measure 20
Bf4    8        q     u                    tise-
Bf4    8        q     u                    ment
rest   8        q
Df5    4        e     d                    the
F5     4        e     d                    chas-
measure 21
C5     8        q     d                    tise-
C5     8        q     d                    ment
rest   8        q
C5     8-       q     d        -           of_
measure 22
C5     8        q     d                    _
Bf4    8        q     u                    our
Bf4    8        q     u         (          peace_
Af4    8        q     u         )          _
measure 23
Df5   24        h.    d                    was
C5     8        q     d                    up-
measure 24
Bf4   16        h     u                    on
Af4   16        h     u                    him;
measure 25
rest  32
measure 26
rest  32
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  16        h
C5    16        h     d                    And
measure 28
Af4   16        h     u                    with
Df5   16        h     d                    his
measure 29
E4    32        w     u                    stripes
measure 30
F4    24        h.    u                    we
G4     8        q     u                    are
measure 31
Af4   24        h.    u         (          hea-
Bf4    8        q     u         )          -
measure 32
C5    32        w     d                    led,
measure 33
rest   8        q
D5     8        q     d                    and
G5     8        q     d                    with
F5     8        q     d                    his
measure 34
Ef5    8        q     d         (          stripes_
D5     8        q     d         )          _
C5     8        q     d                    we
B4     8        q     u                    are
measure 35
C5     8        q     d                    hea-
G4     8        q     u                    -
C5    16-       h     d        -           -
measure 36
C5    16        h     d                    -
Bf4   16-       h     u        -           -
measure 37
Bf4   16        h     u                    -
Af4   16        h     u                    -
measure 38
G4    32        w     u                    led,
measure 39
F4     8        q     u         (          we_
G4     8        q     u         )          _
Af4    8        q     u         (          are_
Bf4    8        q     u         )          _
measure 40
C5    16        h     d                    hea-
G4    16        h     u                    led,
measure 41
rest  32
measure 42
rest   8        q
C5     8        q     d                    and
F5     8        q     d                    with
Ef5    8        q     d                    his
measure 43
Df5    8        q     d         (          stripes_
C5     8        q     d         )          _
Bf4    8        q     u                    we
A4     8        q     u                    are
measure 44
Bf4    8        q     u         (          hea-
C5     8        q     d                    -
Df5   16        h     d         )          -
measure 45
C5    32        w     d                    led,
measure 46
C5    24        h.    d                    we
C5     8        q     d                    are
measure 47
D5    32        w     d         +          hea-
measure 48
G4    16        h     u                    led,
rest  16        h
measure 49
rest  32
measure 50
rest  32
measure 51
rest  16        h
F5    16        h     d                    and
measure 52
Ef5   16        h     d                    with
Af5   16        h     d                    his
measure 53
B4    32        w     u                    stripes
measure 54
C5    16        h     d                    we
D5    16        h     d                    are
measure 55
Ef5   24        h.    d                    hea-
F5     4        e     d  [                 -
Ef5    4        e     d  ]                 -
measure 56
Df5    8        q     d                    -
C5     8        q     d                    -
Df5   16        h     d                    -
measure 57
C5    32        w     d                    -
measure 58
F4    16        h     u                    led,
rest  16        h
measure 59
rest  32
measure 60
rest  32
measure 61
rest  32
measure 62
rest  32
measure 63
rest  32
measure 64
rest  32
measure 65
rest   8        q
G4     8        q     u                    and
C5     8        q     d                    with
Bf4    8        q     u                    his
measure 66
Af4    8        q     u         (          stripes_
G4     8        q     u         )          _
F4     8        q     u                    we
E4     8        q     u                    are
measure 67
F4     8        q     u                    hea-
C5     8        q     d                    -
F5     8        q     d                    -
Ef5    8        q     d         +          -
measure 68
Df5    8        q     d                    -
C5     8        q     d                    -
Bf4    8        q     u                    -
A4     8        q     u                    -
measure 69
Bf4    8        q     u                    -
C5     8        q     d                    -
Df5   16-       h     d        -           -
measure 70
Df5   16        h     d                    -
C5    16        h     d                    -
measure 71
Bf4   32-       w     u        -           -
measure 72
Bf4   16        h     u                    -
Af4   16-       h     u        -           -
measure 73
Af4    8        q     u                    -
Bf4    8        q     u                    -
G4     8        q     u                    -
Af4    8        q     u                    -
measure 74
F4    32        w     u                    led,
measure 75
rest  32
measure 76
rest  32
measure 77
rest  32
measure 78
rest  32
measure 79
rest  32
measure 80
rest  32
measure 81
rest  16        h
Ef5   16        h     d                    and
measure 82
C5    16        h     d                    with
F5    16        h     d                    his
measure 83
G4    32        w     u                    stripes
measure 84
Af4   16        h     u                    we
Bf4   16        h     u                    are
measure 85
C5     8        q     d                    hea-
Af4    8        q     u                    -
Df5   16-       h     d        -           -
measure 86
Df5    8        q     d                    -
Ef5    8        q     d                    -
C5     8        q     d                    -
Df5    8        q     d                    -
measure 87
Bf4   16        h     u                    -
Af4    8        q     u                    -
Df5    8        q     d                    -
measure 88
Bf4   32        w     u                    -
measure 89
Af4   16        h     u                    led,
C5    16        h     d                    and
measure 90
Af4   16        h     u                    with
Df5   16        h     d                    his
measure 91
E4    32        w     u                    stripes
measure 92
F4    16        h     u                    we
G4    16        h     u                    are
measure 93
Af4   32        w     u                    hea-
measure 94
G4    24        h.    u                    -
F4     8        q     u                    -
measure 95
G4    32        w     u                    led,
measure 96
rest  32
measure 97
rest  32
measure 98
rest  32
measure 99
rest  32
measure 100
rest  32
measure 101
rest  32
measure 102
rest  32
measure 103
rest  32
measure 104
rest  32
measure 105
rest  16        h
F5    16        h     d                    and
measure 106
Ef5   16        h     d                    with
Af5   16        h     d                    his
measure 107
B4    32        w     u                    stripes
measure 108
C5    16        h     d                    we
D5    16        h     d                    are
measure 109
Ef5   16        h     d                    hea-
E5    16        h     d                    -
measure 110
F5    32        w     d                    -
measure 111
C5    32-       w     d        -           -
measure 112
C5    16        h     d                    -
Bf4   16        h     u                    -
measure 113
Af4    8        q     u                    -
G4     8        q     u                    -
Af4    8        q     u                    -
Bf4    8        q     u                    -
measure 114
C5    32-       w     d        -           -
measure 115
$ D:Adagio
C5    32        w     d                    -
measure 116
Bf4   32        w     u                    -
measure 117
C5    32        b     d         F          led.
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/5} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:a971b0c73342fd7cf7ff50a1a1bbc428]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
2 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:4   D:Largo e staccato
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
Af4    3        s.    u                    Su-
G4     1        t     u                    re-
F4     4        e     u                    ly,
rest   8        q
G4     3        s.    u                    su-
F4     1        t     u                    re-
E4     4        e     u                    ly,
rest   4        e
C4     2        s     u                    he
C4     2        s     u                    hath
measure 7
Af4   12        q.    u                    borne
Af4    4        e     u                    our
Af4   12        q.    u                    griefs,
G4     4        e     u                    and
measure 8
G4     8        q     u                    car-
G4     4        e     u                    ried
Af4    4        e     u                    our
D4     8        q     u                    sor-
D4     8        q     u                    rows!
measure 9
G4     3        s.    u                    su-
F4     1        t     u                    re-
Ef4    4        e     u                    ly,
rest   8        q
G4     3        s.    u                    su-
F4     1        t     u                    re-
Ef4    4        e     u                    ly,
rest   4        e
Ef4    2        s     u                    he
Ef4    2        s     u                    hath
measure 10
C4    12        q.    u                    borne
C4     4        e     u                    our
A4    12        q.    u                    griefs,
A4     4        e     u                    and
measure 11
A4     8        q     u                    car-
A4     4        e     u                    ried
A4     4        e     u                    our
G4     8        q     u                    sor-
G4     8        q     u                    rows;
measure 12
rest  16        h
rest   8        q
G4     8-       q     u        -           He_
measure 13
G4     8        q     u                    _
F4     8        q     u                    was
G4    16-       h     u        -           wound-
measure 14
G4     8        q     u                    -
A4     4        e     u                    ed
G4     4        e     u                    for
A4    12        q.    u                    our
A4     4        e     u                    trans-
measure 15
A4     8        q     u                    gres-
G4     8        q     u                    sions;
G4    12        q.    u                    He
G4     4        e     u                    was
measure 16
F4     8        q     u         (          bruis-
G4     8        q     u                    -
A4     8        q     u         )          -
F4     8        q     u                    ed,
measure 17
F4     8        q     u                    He
F4     8        q     u                    was
G4     8        q     u                    bruis-
F4     4        e     u                    ed
Af4    4        e     u         +          for
measure 18
Af4   16        h     u         (          our_
G4     8        q     u         )          _
F4     8        q     u                    i-
measure 19
G4     6        e.    u                    ni-
F4     2        s     u                    qui-
E4     8        q     u                    ties;
rest  16        h
measure 20
rest   8        q
G4     4        e     u                    the
Bf4    4        e     u                    chas-
F4     8        q     u                    tise-
F4     8        q     u                    ment,
measure 21
rest   8        q
Af4    4        e     u                    the
Af4    4        e     u                    chas-
G4     8        q     u                    tise-
G4     8        q     u                    ment
measure 22
Af4    8        q     u                    of
Ef4    8        q     u                    our
Ef4   16        h     u                    peace
measure 23
Af4    8        q     u         (          was_
Bf4   16        h     u         )          _
Af4    8        q     u                    up-
measure 24
Af4    8        q     u         (          on_
G4     8        q     u         )          _
Af4   16        h     u                    him;
measure 25
rest  32
measure 26
rest  32
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  32
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  16        h
F4    16        h     u                    And
measure 32
Ef4   16        h     u                    with
Af4   16        h     u                    his
measure 33
B3    32        w     u                    stripes
measure 34
C4    16        h     u                    we
D4    16        h     u                    are
measure 35
Ef4   24        h.    u                    hea-
F4     8        q     u                    -
measure 36
G4     8        q     u                    -
F4     8        q     u                    -
D4     8        q     u                    -
E4     8        q     u                    -
measure 37
F4     8        q     u                    -
C4     8        q     u                    -
F4    16-       h     u        -           -
measure 38
F4    16        h     u                    -
E4    16        h     u                    -
measure 39
F4    32        w     u                    led,
measure 40
rest   8        q
G4     8        q     u                    and
C5     8        q     d                    with
Bf4    8        q     u                    his
measure 41
Af4    8        q     u         (          stripes_
G4     8        q     u         )          _
F4     8        q     u                    we
E4     8        q     u                    are
measure 42
F4    32-       w     u        -           hea-
measure 43
F4    32-       w     u        -           -
measure 44
F4    16        h     u                    -
Bf4   16-       h     u        -           -
measure 45
Bf4   16        h     u                    -
Af4   16        h     u                    -
measure 46
G4    16        h     u                    -
F4     8        q     u                    -
Ef4    8        q     u                    -
measure 47
D4    32        w     u                    -
measure 48
C4    16        h     u                    led,
rest  16        h
measure 49
rest   8        q
G4     8        q     u                    and
C5     8        q     d                    with
Bf4    8        q     u                    his
measure 50
Af4    8        q     u         (          stripes_
G4     8        q     u         )          _
F4     8        q     u                    we
E4     8        q     u                    are
measure 51
F4    16        h     u                    hea-
C4    16        h     u                    led,
measure 52
rest  32
measure 53
rest  32
measure 54
rest  32
measure 55
rest  32
measure 56
rest  32
measure 57
rest  32
measure 58
rest  32
measure 59
rest   8        q
C4     8        q     u                    and
F4     8        q     u                    with
Ef4    8        q     u                    his
measure 60
Df4    8        q     u         (          stripes_
C4     8        q     u         )          _
Bf3    8        q     u                    we
A3     8        q     u                    are
measure 61
Bf3    8        q     u                    hea-
Bf4    8        q     u                    -
F4     8        q     u                    -
G4     8        q     u                    -
measure 62
Af4   24        h.    u                    -
Bf4    4        e     u  [                 -
Af4    4        e     u  ]                 -
measure 63
G4    24        h.    u                    -
E4     8        q     u                    -
measure 64
F4     8        q     u                    -
G4     8        q     u                    -
Af4    8        q     u                    -
Bf4    8        q     u                    -
measure 65
C5    16        h     d                    -
C4    16        h     u                    -
measure 66
C4    16        h     u                    led,
rest  16        h
measure 67
rest  32
measure 68
rest  32
measure 69
rest  32
measure 70
rest  32
measure 71
rest  32
measure 72
rest  32
measure 73
rest  32
measure 74
rest  16        h
Bf4   16        h     u                    and
measure 75
G4    16        h     u                    with
C5    16        h     d                    his
measure 76
D4    32        w     u                    stripes
measure 77
Ef4   16        h     u                    we
F4    16        h     u                    are
measure 78
G4     8        q     u                    hea-
Ef4    8        q     u                    -
Af4   16-       h     u        -           -
measure 79
Af4    8        q     u                    -
Bf4    8        q     u                    -
G4     8        q     u                    -
Af4    8        q     u                    -
measure 80
F4    32        w     u                    -
measure 81
Bf3   32        w     u                    led,
measure 82
rest  32
measure 83
rest  32
measure 84
rest  32
measure 85
rest  32
measure 86
rest  32
measure 87
rest  32
measure 88
rest   8        q
Bf3    8        q     u                    and
Ef4    8        q     u                    with
Df4    8        q     u                    his
measure 89
C4     8        q     u         (          stripes_
Bf3    8        q     u         )          _
Af3    8        q     u                    we
G3     8        q     u                    are
measure 90
F3    16        h     u         (          hea-
Bf3   16        h     u         )          -
measure 91
G3    16        h     u                    led,
rest  16        h
measure 92
rest  32
measure 93
rest  32
measure 94
rest  32
measure 95
rest   8        q
D4     8        q     u                    and
G4     8        q     u                    with
F4     8        q     u                    his
measure 96
Ef4    8        q     u         &(         stripes_
Af4    8        q     u         &)         _
G4     8        q     u                    we
F4     8        q     u                    are
measure 97
G4     8        q     u                    hea-
C5     8        q     d                    -
G4     8        q     u                    -
Af4    8        q     u                    -
measure 98
Bf4   24        h.    u                    -
Af4    4        e     u  [                 -
G4     4        e     u  ]                 -
measure 99
Af4   32        w     u                    -
measure 100
A4    32        w     u                    -
measure 101
Bf4    8        q     u                    -
Bf4    8        q     u                    -
F4     8        q     u                    -
G4     8        q     u                    -
measure 102
Af4   24        h.    u         +          -
G4     4        e     u  [                 -
F4     4        e     u  ]                 -
measure 103
G4    32-       w     u        -           -
measure 104
G4    16        h     u                    -
G4    16        h     u                    -
measure 105
Af4   32        w     u                    -
measure 106
G4    16        h     u                    -
F4     8        q     u                    -
Ef4    8        q     u                    -
measure 107
D4    16        h     u                    led,
rest  16        h
measure 108
rest  32
measure 109
rest  32
measure 110
rest  32
measure 111
rest   8        q
G4     8        q     u                    and
C5     8        q     d                    with
Bf4    8        q     u                    his
measure 112
Af4    8        q     u         (          stripes_
G4     8        q     u         )          _
F4     8        q     u                    we
E4     8        q     u                    are
measure 113
F4     8        q     u                    hea-
E4     8        q     u                    -
F4     8        q     u                    -
G4     8        q     u                    -
measure 114
Af4   24        h.    u                    -
G4     8        q     u                    -
measure 115
$ D:Adagio
F4    32-       w     u        -           -
measure 116
F4    32        w     u                    -
measure 117
E4    32        b     u         F          led.
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/6} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:68426c2f569feb701936c0329f0a393d]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
2 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:34   D:Largo e staccato
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
F4     3        s.    d                    Su-
C4     1        t     d                    re-
C4     4        e     d                    ly,
rest   8        q
E4     3        s.    d                    su-
F4     1        t     d                    re-
G4     4        e     d                    ly,
rest   4        e
G4     2        s     d                    he
G4     2        s     d                    hath
measure 7
F4    12        q.    d                    borne
Ef4    4        e     d         +          our
D4    12        q.    d                    griefs,
D4     4        e     d                    and
measure 8
Ef4    8        q     d                    car-
Ef4    4        e     d                    ried
C4     4        e     d                    our
B3     8        q     d                    sor-
B3     8        q     d                    rows!
measure 9
C4     3        s.    d                    su-
G3     1        t     u                    re-
G3     4        e     u                    ly,
rest   8        q
Ef4    3        s.    d                    su-
G3     1        t     u                    re-
G3     4        e     u                    ly,
rest   4        e
C4     2        s     d                    he
C4     2        s     d                    hath
measure 10
Ef4   12        q.    d                    borne
Ef4    4        e     d                    our
Ef4   12        q.    d                    griefs,
Ef4    4        e     d                    and
measure 11
D4     8        q     d                    car-
D4     4        e     d                    ried
D4     4        e     d                    our
D4     8        q     d                    sor-
D4     8        q     d                    rows;
measure 12
rest  32
measure 13
rest  16        h
D4    12        q.    d                    He
D4     4        e     d                    was
measure 14
D4     8        q     d                    wound-
C4     4        e     d                    ed
C4     4        e     d                    for
C4    12        q.    d                    our
C4     4        e     d                    trans-
measure 15
C4     8        q     d                    gres-
Bf3    8        q     d                    sions;
Bf3   12        q.    d                    He
Bf3    4        e     d                    was
measure 16
Af3    8        q     u         (          bruis-
Bf3    8        q     u         )          -
C4     8        q     d                    ed,
C4     8-       q     d        -           He_
measure 17
C4     8        q     d                    _
Bf3    8        q     d                    was
Bf3    8        q     d                    bruis-
Af3    4        e     u                    ed
C4     4        e     d                    for
measure 18
F4    24        h.    d                    our
F4     8        q     d                    i-
measure 19
E4     6        e.    d                    ni-
D4     2        s     d                    qui-
C4     8        q     d                    ties;
rest   8        q
Af3    4        e     u                    the
C4     4        e     d                    chas-
measure 20
Ef4    8        q     d         +          tise-
Ef4    8        q     d                    ment,
rest   8        q
Bf3    4        e     d                    the
Df4    4        e     d                    chas-
measure 21
F4    24        h.    d                    tise-
Ef4    8        q     d                    ment
measure 22
Df4   12        q.    d                    of
Df4    4        e     d                    our
C4    16-       h     d        -           peace_
measure 23
C4     8        q     d                    _
Bf3    4        e     u  [      (          was_
Af3    4        e     u  ]                 _
G4     8        q     d         )          _
Ef4    8        q     d                    up-
measure 24
Ef4   12        q.    d         (          on_
Df4    4        e     d         )          _
C4    16        h     d                    him;
measure 25
rest  32
measure 26
rest  32
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  32
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest  32
measure 35
rest  32
measure 36
rest  32
measure 37
rest  32
measure 38
rest  16        h
C4    16        h     d                    And
measure 39
Af3   16        h     u                    with
Df4   16        h     d                    his
measure 40
E3    32        w     u                    stripes
measure 41
F3    16        h     u                    we
G3    16        h     u                    are
measure 42
Af3   16        h     u                    hea-
A3    16        h     u                    -
measure 43
Bf3   16        h     d                    -
C4    16        h     d                    -
measure 44
Df4   24        h.    d                    -
Ef4    8        q     d                    -
measure 45
F4    16        h     d                    -
C4    16        h     d                    led,
measure 46
rest  32
measure 47
rest   8        q
D4     8        q     d         +          and
G4     8        q     d                    with
F4     8        q     d                    his
measure 48
Ef4    8        q     d         (          stripes_
D4     8        q     d         )          _
C4     8        q     d                    we
B3     8        q     d                    are
measure 49
C4    16        h     d                    hea-
G3    16        h     u                    led,
measure 50
C4    24        h.    d                    we
Bf3    8        q     d         +          are
measure 51
C4    24        h.    d                    hea-
D4     8        q     d                    -
measure 52
Ef4   32        w     d                    -
measure 53
D4    32        w     d                    -
measure 54
G3    32        w     u                    led,
measure 55
rest  32
measure 56
rest  32
measure 57
rest  16        h
F4    16        h     d                    and
measure 58
Df4   16        h     d                    with
Gf4   16        h     d                    his
measure 59
A3    32        w     u                    stripes
measure 60
Bf3   24        h.    d                    we
C4     8        q     d                    are
measure 61
Df4   24        h.    d                    hea-
Ef4    4        e     d  [                 -
Df4    4        e     d  ]                 -
measure 62
C4     8        q     d                    -
F4     8        q     d                    -
C4     8        q     d                    -
D4     8        q     d         +          -
measure 63
E4     8        q     d                    -
F4     8        q     d                    -
G4    16        h     d                    -
measure 64
C4    16        h     d                    -
F4    16        h     d                    -
measure 65
G3    32        w     u                    led,
measure 66
Af3   16        h     u                    we
Bf3   16        h     u                    are
measure 67
C4    32        w     d                    hea-
measure 68
Df4   16        h     d                    -
Ef4   16        h     d                    -
measure 69
F4    32        w     d                    -
measure 70
Ef4   16        h     d                    -
Af3   16-       h     u        -           -
measure 71
Af3    8        q     u                    -
G3     8        q     u                    -
Af3    8        q     u                    -
Bf3    8        q     u                    -
measure 72
Ef3    8        q     u                    -
Ef4    8        q     d                    -
F4     8        q     d                    -
Ef4    8        q     d                    -
measure 73
D4    16        h     d                    -
Ef4   16-       h     d        -           -
measure 74
Ef4   16        h     d                    -
D4    16        h     d                    -
measure 75
Ef4   16        h     d                    -
Af3   16        h     u                    -
measure 76
F3    16        h     u                    -
Bf3   16-       h     d        -           -
measure 77
Bf3   16        h     d                    -
Bf3   16        h     d                    -
measure 78
Ef4   16        h     d                    -
D4     8        q     d                    -
C4     8        q     d                    -
measure 79
D4    16        h     d                    -
Ef4   16-       h     d        -           -
measure 80
Ef4   16        h     d                    -
D4    16        h     d                    -
measure 81
Ef4   32        w     d                    -
measure 82
Ef4   16        h     d                    led,
rest  16        h
measure 83
rest   8        q
Bf3    8        q     d                    and
Ef4    8        q     d                    with
Df4    8        q     d                    his
measure 84
C4     8        q     d         (          stripes_
Bf3    8        q     d         )          _
Af3    8        q     u                    we
G3     8        q     u                    are
measure 85
Af3   16        h     u                    hea-
F4    16        h     d                    -
measure 86
Ef4   32        w     d                    -
measure 87
F3     8        q     u                    -
G3     8        q     u                    -
Af3   16-       h     u        -           -
measure 88
Af3   16        h     u                    -
G3    16        h     u                    -
measure 89
Af3   32        w     u                    led,
measure 90
rest  32
measure 91
rest   8        q
G3     8        q     u                    and
C4     8        q     d                    with
Bf3    8        q     u                    his
measure 92
Af3    8        q     u         &(         stripes_
Df4    8        q     d         &)         _
C4     8        q     d                    we
Bf3    8        q     d                    are
measure 93
C4     8        q     d                    hea-
F4     8        q     d                    -
C4     8        q     d                    -
D4     8        q     d         +          -
measure 94
Ef4    8        q     d                    -
D4     8        q     d                    -
C4    16        h     d                    -
measure 95
D4    32        w     d                    -
measure 96
C4    16        h     d                    -
B3    16        h     d                    -
measure 97
C4    32        w     d                    led,
measure 98
rest  32
measure 99
rest   8        q
F4     8        q     d                    we
C4     8        q     d         (          are_
D4     8        q     d         )          _
measure 100
Ef4   24        h.    d                    hea-
Df4    4        e     d  [                 -
C4     4        e     d  ]                 -
measure 101
Df4   32        w     d                    -
measure 102
D4    32        w     d         +          -
measure 103
Ef4    8        q     d                    -
Ef4    8        q     d                    -
Bf3    8        q     d                    -
C4     8        q     d                    -
measure 104
Df4   24        h.    d                    -
C4     4        e     d  [                 -
Bf3    4        e     d  ]                 -
measure 105
C4    32        w     d                    led,
measure 106
rest  32
measure 107
rest   8        q
G3     8        q     u                    and
G4     8        q     d                    with
F4     8        q     d                    his
measure 108
Ef4    8        q     d         (          stripes_
D4     8        q     d         )          _
C4     8        q     d                    we
B3     8        q     d                    are
measure 109
C4    32-       w     d        -           hea-
measure 110
C4    16        h     d                    -
Bf3   16        h     d                    -
measure 111
G4    32        w     d                    -
measure 112
F4    16        h     d                    -
Bf3   16        h     d                    -
measure 113
C4    24        h.    d                    -
Bf3    8        q     d                    -
measure 114
Af3    8        q     u                    -
Bf3    8        q     d                    -
C4    16        h     d                    -
measure 115
$ D:Adagio
Df4   32-       w     d        -           -
measure 116
Df4   32        w     d                    -
measure 117
G3    32        b     u         F          led.
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/7} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:3cd188e6b38ea2784c189b264f90bb0e]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
2 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:22   D:Largo e staccato
rest  32
measure 2
rest  32
measure 3
rest  32
measure 4
rest  32
measure 5
rest  32
measure 6
C4     3        s.    d                    Su-
F3     1        t     d                    re-
F3     4        e     d                    ly,
rest   8        q
G3     3        s.    d                    su-
C3     1        t     u                    re-
C3     4        e     u                    ly,
rest   4        e
C4     2        s     d                    he
C4     2        s     d                    hath
measure 7
Df4   12        q.    d                    borne
C4     4        e     d                    our
B3    12        q.    d                    griefs,
B3     4        e     d                    and
measure 8
C4     8        q     d                    car-
C4     4        e     d                    ried
Af3    4        e     d                    our
G3     8        q     d                    sor-
G3     8        q     d                    rows!
measure 9
C4     3        s.    d                    su-
C3     1        t     u                    re-
C3     4        e     u                    ly,
rest   8        q
C4     3        s.    d                    su-
C3     1        t     u                    re-
C3     4        e     u                    ly,
rest   4        e
Bf3    2        s     d                    he
Bf3    2        s     d                    hath
measure 10
Af3   12        q.    d                    borne
G3     4        e     d                    our
F#3   12        q.    d                    griefs,
F#3    4        e     d                    and
measure 11
F#3    8        q     d                    car-
F#3    4        e     d                    ried
F#3    4        e     d                    our
G3     8        q     d                    sor-
G3     8        q     d                    rows;
measure 12
rest  32
measure 13
Af3   16        h     d                    He
G3    16        h     d                    was
measure 14
C3     8        q     u                    wound-
C4     4        e     d                    ed
C4     4        e     d                    for
F#3   12        q.    d                    our
F#3    4        e     d                    trans-
measure 15
G3     8        q     d                    gres-
G3     8        q     d                    sions;
C3    12        q.    u                    He
C3     4        e     u                    was
measure 16
Df3   16        h     u                    bruis-
A2    16        h     u                    ed,
measure 17
Bf2    8        q     u                    He
Bf3    8        q     d                    was
E3     8        q     d                    bruis-
F3     4        e     d                    ed
F3     4        e     d                    for
measure 18
Df4   24        h.    d                    our
Df4    8        q     d                    i-
measure 19
C4     6        e.    d                    ni-
C3     2        s     u                    qui-
C3     8        q     u                    ties;
rest  16        h
measure 20
rest   8        q
Ef3    4        e     d                    the
G3     4        e     d                    chas-
Bf3    8        q     d                    tise-
Bf2    8        q     u                    ment,
measure 21
rest   8        q
F3     4        e     d                    the
Af3    4        e     d                    chas-
C4     8        q     d                    tise-
C3     8        q     u                    ment
measure 22
F3     8        q     d                    of
G3     8        q     d                    our
Af3   16        h     d                    peace
measure 23
F3     8        q     d         (          was_
Df3    8        q     u                    _
Ef3    8        q     d         )          _
Af3    8        q     d                    up-
measure 24
Ef3   16        h     d                    on
Af2   16        h     u                    him;
measure 25
rest  32
measure 26
rest  32
mdouble 27
$ T:0/0   D:Alla breve moderato
rest  32
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  32
measure 32
rest  32
measure 33
rest  32
measure 34
rest  32
measure 35
rest  32
measure 36
rest  32
measure 37
rest  32
measure 38
rest  32
measure 39
rest  32
measure 40
rest  32
measure 41
rest  32
measure 42
rest  32
measure 43
rest  32
measure 44
rest  32
measure 45
rest  16        h
F3    16        h     d                    And
measure 46
Ef3   16        h     d                    with
Af3   16        h     d                    his
measure 47
B2    32        w     u                    stripes
measure 48
C3    16        h     u                    we
D3    16        h     u                    are
measure 49
Ef3   16        h     d                    hea-
E3    16        h     d                    -
measure 50
F3    24        h.    d                    -
G3     8        q     d                    -
measure 51
Af3   24        h.    d                    -
Bf3    8        q     d                    -
measure 52
C4    16        h     d                    -
C3    16        h     u                    led,
measure 53
rest   8        q
D3     8        q     u                    and
G3     8        q     d                    with
F3     8        q     d                    his
measure 54
Ef3    8        q     d         (          stripes_
D3     8        q     u         )          _
C3     8        q     u                    we
B2     8        q     u                    are
measure 55
C3     8        q     u                    hea-
C4     8        q     d                    -
G3     8        q     d                    -
A3     8        q     d                    -
measure 56
Bf3    8        q     d                    -
F3     8        q     d                    -
Bf3   16-       h     d        -           -
measure 57
Bf3   16        h     d                    -
A3    16        h     d                    -
measure 58
Bf3   16        h     d                    -
Ef3   16        h     d                    -
measure 59
F3    32        w     d                    -
measure 60
Bf2   32        w     u                    led,
measure 61
rest  32
measure 62
rest  32
measure 63
rest  16        h
C4    16        h     d                    and
measure 64
Af3   16        h     d                    with
Df4   16        h     d                    his
measure 65
E3    32        w     d                    stripes
measure 66
F3    16        h     d                    we
G3    16        h     d                    are
measure 67
Af3   16        h     d                    hea-
A3    16        h     d                    -
measure 68
Bf3   16        h     d                    -
C4    16        h     d                    -
measure 69
Df4    8        q     d                    -
C4     8        q     d                    -
Bf3    8        q     d                    -
Af3    8        q     d                    -
measure 70
G3    16        h     d                    -
Af3   16        h     d                    -
measure 71
Ef3   24        h.    d                    -
D3     8        q     u                    -
measure 72
C3    32        w     u                    -
measure 73
Bf2   32-       w     u        -           led,_
measure 74
Bf2   32        w     u                    _
measure 75
rest  32
measure 76
rest   8        q
Bf2    8        q     u                    and
Bf3    8        q     d                    with
Af3    8        q     d                    his
measure 77
G3     8        q     d         (          stripes_
F3     8        q     d         )          _
Ef3    8        q     d                    we
D3     8        q     u                    are
measure 78
Ef3    8        q     d                    hea-
C3     8        q     u                    -
F3    16        h     d                    -
measure 79
Bf2   16        h     u                    -
Ef3   16        h     d                    -
measure 80
Bf3   24        h.    d                    -
Af3    8        q     d                    -
measure 81
G3     8        q     d                    -
Ef3    8        q     d                    -
F3     8        q     d                    -
G3     8        q     d                    -
measure 82
Af3   16        h     d                    -
Df3   16        h     u                    -
measure 83
Ef3   32        w     d                    led,
measure 84
rest  32
measure 85
rest   8        q
F3     8        q     d                    and
Bf3    8        q     d                    with
Af3    8        q     d                    his
measure 86
G3     8        q     d         (          stripes_
Ef3    8        q     d                    _
Af3   16        h     d         )          _
measure 87
Df3    8        q     d         (          we_
Ef3    8        q     d         )          _
F3     8        q     d         (          are_
Df3    8        q     d         )          _
measure 88
Ef3   32        w     d                    hea-
measure 89
Af2   32        w     u                    led,
measure 90
rest  32
measure 91
rest  32
measure 92
rest  32
measure 93
rest  16        h
F3    16        h     d                    and
measure 94
Ef3   16        h     d                    with
Af3   16        h     d                    his
measure 95
B2    32        w     u                    stripes
measure 96
C3    16        h     u                    we
D3    16        h     u                    are
measure 97
Ef3   24        h.    d                    hea-
F3     8        q     d                    -
measure 98
G3     8        q     d                    -
F3     8        q     d                    -
D3     8        q     u                    -
E3     8        q     d                    -
measure 99
F3    32-       w     d        -           -
measure 100
F3    32        w     d                    -
measure 101
Bf2   32-       w     u        -           led,_
measure 102
Bf2   16        h     u                    _
Bf2   16        h     u                    and
measure 103
Ef3   32-       w     d        -           with_
measure 104
Ef3   16        h     d                    _
Ef3   16        h     d                    his
measure 105
Af3   24        h.    d                    stripes_
Bf3    8        q     d                    _
measure 106
C4    32        w     d                    _
measure 107
rest  32
measure 108
rest  32
measure 109
rest  16        h
C4    16        h     d                    and
measure 110
Af3   16        h     d                    with
Df4   16        h     d                    his
measure 111
E3    32        w     d                    stripes
measure 112
F3    16        h     d                    we
G3    16        h     d                    are
measure 113
Af3   24        h.    d                    hea-
G3     8        q     d                    -
measure 114
F3    24        h.    d                    -
Ef3    8        q     d                    -
measure 115
$ D:Adagio
Df3   32-       w     u        -           -
measure 116
Df3   32        w     u                    -
measure 117
C3    32        b     u         F          led.
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-03/8} [KHM:667306435]
TIMESTAMP: DEC/26/2001 [md5sum:1994cead85318a367c686031de17d0a4]
04/11/90 E. Correia
WK#:56        MV#:2,3
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
2 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-3   Q:8   T:1/1   C:22   D:Largo e staccato
F3     8        q     d
rest   2        s
F3     2        s     d  [[
F3     3        s.    d  ==
F3     1        t     d  ]]\
Af3    8        q     d
rest   2        s
Af3    2        s     d  [[
Af3    3        s.    d  ==
Af3    1        t     d  ]]\
measure 2
Df4    8        q     d
rest   2        s
C4     2        s     d  [[
C4     3        s.    d  ==
C4     1        t     d  ]]\
B3     8-       q     d        -
B3     3        s.    d  [[
B3     1        t     d  ==\
B3     3        s.    d  ==
B3     1        t     d  ]]\
measure 3
f1              n
C4     8        q     d
rest   2        s
A3     2        s     d  [[
A3     3        s.    d  ==
A3     1        t     d  ]]\
Bf3    8        q     d         +
rest   2        s
G3     2        s     d  [[
G3     3        s.    d  ==
G3     1        t     d  ]]\
measure 4
Af3    8        q     d         +
rest   2        s
C3     2        s     u  [[
C3     3        s.    u  ==
C3     1        t     u  ]]\
f2              6 5
D3     8        q     u
rest   2        s
E3     2        s     d  [[
E3     3        s.    d  ==
E3     1        t     d  ]]\
measure 5
f1              9
F3     8        q     d
rest   2        s
Df3    2        s     u  [[
Df3    3        s.    u  ==
Df3    1        t     u  ]]\
Af2    4        e     u  [
Bf2    4        e     u  =
f1              4
C3     4        e     u  =
f1              n
C2     4        e     u  ]
measure 6
F3     8        q     d
rest   2        s
F3     2        s     d  [[
F3     3        s.    d  ==
F3     1        t     d  ]]\
G3     8        q     d
rest   2        s
C4     2        s     d  [[
C4     3        s.    d  ==
C4     1        t     d  ]]\
measure 7
Df4    8        q     d
rest   2        s
C4     2        s     d  [[
C4     3        s.    d  ==
C4     1        t     d  ]]\
B3     3        s.    d  [[
B3     1        t     d  ==\
B3     3        s.    d  ==
B3     1        t     d  ]]\
B3     3        s.    d  [[
B3     1        t     d  ==\
B3     3        s.    d  ==
B3     1        t     d  ]]\
measure 8
C4     3        s.    d  [[
C4     1        t     d  ==\
C4     3        s.    d  ==
C4     1        t     d  ]]\
C4     3        s.    d  [[
C4     1        t     d  ==\
Af3    3        s.    d  ==
Af3    1        t     d  ]]\
f1              n
G3     3        s.    d  [[
G3     1        t     d  ==\
G3     3        s.    d  ==
G3     1        t     d  ]]\
G3     3        s.    d  [[
G3     1        t     d  ==\
G3     3        s.    d  ==
G3     1        t     d  ]]\
measure 9
C3     8        q     u
rest   2        s
C3     2        s     u  [[
C3     3        s.    u  ==
C3     1        t     u  ]]\
f2              4 2
Bf2    8        q     u
rest   2        s
Bf2    2        s     u  [[
Bf2    3        s.    u  ==
Bf2    1        t     u  ]]\
measure 10
Af2    3        s.    d  [[
Af3    1        t     d  ==\
Af3    3        s.    d  ==
Af3    1        t     d  ]]\
Af3    3        s.    d  [[
Af3    1        t     d  ==\
G3     3        s.    d  ==
G3     1        t     d  ]]\
F#3    3        s.    d  [[
F#3    1        t     d  ==\
F#3    3        s.    d  ==
F#3    1        t     d  ]]\
F#3    3        s.    d  [[
F#3    1        t     d  ==\
F#3    3        s.    d  ==
F#3    1        t     d  ]]\
measure 11
F#3    3        s.    d  [[
F#3    1        t     d  ==\
F#3    3        s.    d  ==
F#3    1        t     d  ]]\
F#3    3        s.    d  [[
F#3    1        t     d  ==\
F#3    3        s.    d  ==
F#3    1        t     d  ]]\
G3     8        q     d
rest   2        s
G2     2        s     u  [[
G2     3        s.    u  ==
G2     1        t     u  ]]\
measure 12
Ef3    8        q     d
rest   2        s
C3     2        s     u  [[
C3     3        s.    u  ==
C3     1        t     u  ]]\
f1              4
G3     8        q     d
$ C:13
f1              n
G4     8        q     d
$ C:22
measure 13
f1     8        7
f1              6
Af3   16        h     d
f1     8        4
f1              3
G3    16        h     d
measure 14
f1              7
C3     8        q     u
f1              6n
C4     8        q     d
f1              7
F#3   12        q.    d
F#3    4        e     d
measure 15
f2     8        9 4
f2              8 3
G3    16        h     d
f2              7 n
C3    12        q.    u
C3     4        e     u
measure 16
f2     8        5 3
f2              6 4
Df3   16        h     u
f1     8        6
f1              5
A2    16        h     u
measure 17
f1              9
Bf2    8        q     u
f1              8
Bf3    8        q     d
f2              6 5
E3     8        q     d
F3     8        q     d
measure 18
f1    16        7
f1              6
Df3   32        w     u
measure 19
f1              n
C3    16        h     u
Af2    8        q     u         +
Af3    4        e     d  [
C4     4        e     d  ]
measure 20
f1              4
Ef4    8        q     d
f1              3
Ef3    4        e     d  [
G3     4        e     d  ]
f1              4
Bf3    8        q     d
f1              f
Bf2    4        e     u  [
Df3    4        e     u  ]
measure 21
f1              4
F3     8        q     d
f1              3
F3     4        e     d  [
Af3    4        e     d  ]
C4     8        q     d
C3     8        q     u
measure 22
f2              6f 5
F3     8        q     d
f2              6 5f
G3     8        q     d
Af3   16        h     d
measure 23
F3     8        q     d
Df3    8        q     u
Ef3    8        q     d
Af2    8        q     u
measure 24
Ef3   16        h     d
Af2    8        q     u
rest   2        s
Af3    2        s     d  [[
Af3    3        s.    d  ==
Af3    1        t     d  ]]\
measure 25
f2              6f 5
F3     8        q     d
rest   2        s
f2              6 5f
G3     2        s     d  [[
G3     3        s.    d  ==
G3     1        t     d  ]]\
f1              9
Af3    8        q     d
rest   2        s
f1              3
F3     2        s     d  [[
F3     3        s.    d  ==
F3     1        t     d  ]]\
measure 26
Df3    4        e     u  [
Af2    4        e     u  =
Ef3    4        e     u  =
Ef2    4        e     u  ]
Af2    8        q     u
rest   8        q
mdouble 27
$ T:0/0   D:Alla breve moderato
F2    16        h     u
$ C:15
C5    16        8     d
measure 28
Af4   16        8     d
Df5   16        8     d
measure 29
E4    32        7     u
measure 30
F4    16        8     u
G4    16        8     u
measure 31
Af4   24        8.    u
Bf4    8        7     u
back  32
rest  16        8
F4    16        8     d
measure 32
C5    16        9     u
back  32
Ef4   16        8     d
Af4   16        8     d
measure 33
rest   8        7
D5     8        7     u
G5     8        7     u
F5     8        7     u
back  32
B3    32        9     d
measure 34
Ef5    8        7     u
D5     8        7     u
C5     8        7     u
B4     8        7     u
back  32
C4    16        8     d
D4    16        8     d
measure 35
C5     8        7     u
G4     8        7     u
C5    16-       8     u        -
back  32
Ef4   24        8.    d
F4     8        7     d
measure 36
C5    16        8     u
Bf4   16-       8     u        -
back  32
G4     8        7     d
F4     8        7     d
D4     8        7     d
E4     8        7     d
measure 37
Bf4   16        8     u
Af4   16        8     u
back  32
F4     8        7     d
C4     8        7     d
F4    16-       8     d        -
measure 38
G4    16        8     u
back  16
F4    16        8     d
$ C:12
f1              n
C4    16        h     d
measure 39
Af3   16        h     u
Df4   16        h     d
measure 40
E3    32        w     u
measure 41
F3    16        h     u
G3    16        h     u
measure 42
Af3   16        h     u
A3    16        h     u
measure 43
f1              f
Bf3   16        h     d
f1              6n
C4    16        h     d
measure 44
f1              6
Df4   24        h.    d
Ef4    8        q     d
measure 45
f1              4
F4    16        h     d
$ C:22
F3    16        h     d
measure 46
Ef3   16        h     d
Af3   16        h     d
measure 47
B2    32        w     u
measure 48
C3    16        h     u
D3    16        h     u
measure 49
Ef3   16        h     d
E3    16        h     d
measure 50
F3    24        h.    d
G3     8        q     d
measure 51
Af3   24        h.    d
Bf3    8        q     d
measure 52
C4    16        h     d
C3    16        h     u
measure 53
rest   8        q
D3     8        q     u
G3     8        q     d
F3     8        q     d
measure 54
Ef3    8        q     d
D3     8        q     u
C3     8        q     u
B2     8        q     u
measure 55
C3     8        q     u
C4     8        q     d
G3     8        q     d
A3     8        q     d
measure 56
Bf3    8        q     d
F3     8        q     d
Bf3   16-       h     d        -
measure 57
Bf3   16        h     d
A3    16        h     d
measure 58
Bf3   16        h     d
f1              f
Ef3   16        h     d
measure 59
f1              n
F3    32        w     d
measure 60
Bf2   24        h.    u
F3     8        q     d
measure 61
Bf3   32        w     d
measure 62
F3    32        w     d
measure 63
C3    16        h     u
C4    16        h     d
measure 64
Af3   16        h     d
Df4   16        h     d
measure 65
E3    32        w     d
measure 66
F3    16        h     d
G3    16        h     d
measure 67
Af3   16        h     d
A3    16        h     d
measure 68
Bf3   16        h     d
C4    16        h     d
measure 69
Df4    8        q     d
C4     8        q     d
Bf3    8        q     d
Af3    8        q     d
measure 70
G3    16        h     d
Af3   16        h     d
measure 71
Ef3   24        h.    d
D3     8        q     u
measure 72
C3    32        w     u
measure 73
f2    16        7 3
f2              6 4
Bf2   32-       w     u        -
measure 74
f1    16        4
f1              3
Bf2   32        w     u
$ C:12
measure 75
Ef4   16        h     d
Af3   16        h     u
measure 76
F3     8        q     u
$ C:22
Bf2    8        q     u
Bf3    8        q     d
Af3    8        q     d
measure 77
G3     8        q     d
F3     8        q     d
Ef3    8        q     d
D3     8        q     u
measure 78
Ef3    8        q     d
C3     8        q     u
F3    16        h     d
measure 79
Bf2   16        h     u
Ef3   16        h     d
measure 80
Bf3   24        h.    d
Af3    8        q     d
measure 81
G3     8        q     d
Ef3    8        q     d
F3     8        q     d
G3     8        q     d
measure 82
Af3   16        h     d
Df3   16        h     u
measure 83
Ef3   32        w     d
$ C:12
measure 84
f1              6
C4     8        q     d
Bf3    8        q     d
Af3    8        q     u
G3     8        q     u
measure 85
Af3    8        q     u
$ C:22
F3     8        q     d
Bf3    8        q     d
Af3    8        q     d
measure 86
G3     8        q     d
Ef3    8        q     d
Af3   16        h     d
measure 87
Df3    8        q     d
Ef3    8        q     d
F3     8        q     d
Df3    8        q     d
measure 88
Ef3   32        w     d
measure 89
Af2   32        w     u
$ C:12
measure 90
F3    16        h     u
Bf3   16        h     d
measure 91
G3     8        q     u
G3     8        q     u
C4     8        q     d
Bf3    8        q     d
measure 92
Af3    8        q     u
Df4    8        q     d
C4     8        q     d
Bf3    8        q     d
measure 93
C4     8        q     d
F4     8        q     d
$ C:22
F3    16        h     d
measure 94
Ef3   16        h     d
Af3   16        h     d
measure 95
B2    32        w     u
measure 96
C3    16        h     u
D3    16        h     u
measure 97
Ef3   24        h.    d
F3     8        q     d
measure 98
G3     8        q     d
F3     8        q     d
D3     8        q     u
E3     8        q     d
measure 99
F3    32-       w     d        -
measure 100
F3    32        w     d
measure 101
Bf2   32-       w     u        -
measure 102
Bf2   16        h     u
Bf2   16        h     u
measure 103
Ef3   32-       w     d        -
measure 104
Ef3   16        h     d
Ef3   16        h     d
measure 105
Af3   24        h.    d
Bf3    8        q     d
measure 106
C4    32        w     d
$ C:12
measure 107
D4     8        q     d
G3     8        q     u
G4     8        q     d
F4     8        q     d
measure 108
Ef4    8        q     d
D4     8        q     d
C4     8        q     d
B3     8        q     d
measure 109
C4    16        h     d
$ C:22
C4    16        h     d
measure 110
Af3   16        h     d
Df4   16        h     d
measure 111
E3    32        w     d
measure 112
F3    16        h     d
G3    16        h     d
measure 113
Af3   24        h.    d
G3     8        q     d
measure 114
F3    24        h.    d
Ef3    8        q     d
measure 115
$ D:Adagio
f1              7
Df3   32-       w     u        -
measure 116
f1              6
Df3   32        w     u
measure 117
f1              n
C3    32        b     u         F
mdouble 118
$ T:1/1   K:-1
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
