&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-10/1} [KHM:177473242]
TIMESTAMP: DEC/26/2001 [md5sum:eae48210bad97d3fdf68c11c0e415fc4]
06/10/90 E. Correia
WK#:56        MV#:2,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violini unisoni
1 19
Group memberships: score
score: part 1 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:8   T:1/1   C:4   D:Andante larghetto
E4     4        e     u
measure 1
C#5   12        q.    d
E5     2        s     d  [[     &(
G#4    2        s     d  ]]     &)
A4    12        q.    u
E4     4        e     u
measure 2
B4     3        s.    d  [[     (
C#5    1        t     d  =]\
D5     4        e     d  ]      )
C#5    6        e.    d  [      &t
B4     2        s     d  ]\
B4     8        q     d
rest   4        e
A4     4        e     u
measure 3
A4     8        q     u         (
G#4    4        e     u  [      )t
B4     4        e     u  ]
B4     8        q     u         (
A4     4        e     u  [      )t
C#5    4        e     u  ]
measure 4
C#5    8        q     d         (
B4     4        e     d  [      )t
C#5    4        e     d  ]
D5     4        e     d  [
E5     4        e     d  =
C#5    6        e.    d  =
B4     2        s     d  ]\
measure 5
C#5    8        q     d         &(
B4     6        e.    u  [      &)t
A4     2        s     u  ]\
A4     8        q     u
rest   8        q
measure 6
rest  32
measure 7
rest  16        h
rest   8        q
rest   4        e
A5     4        e     d
measure 8
E5     8        q     d
D5     2        s     d  [[     (
C#5    2        s     d  ==     )
B4     2        s     d  ==     (
A4     2        s     d  ]]     )
G#4    8        q     u
rest   8        q
measure 9
rest  32
measure 10
rest  32
measure 11
rest  32
measure 12
rest  32
measure 13
rest  32
measure 14
rest  16        h
rest   8        q
rest   4        e
E5     4        e     d
measure 15
E5     8        q     d         (
D#5    4        e     d  [      )t
F#5    4        e     d  ]
F#5    8        q     d         (
E5     4        e     d  [      )t
G#5    4        e     d  ]
measure 16
G#5    8        q     d         (
F#5    4        e     d  [      )t
G#5    4        e     d  ]
A5     4        e     d  [
B5     4        e     d  =
G#5    4        e     d  =
F#5    4        e     d  ]
measure 17
G#5    8        q     d
F#5    6        e.    d  [
E5     2        s     d  ]\
E5     8        q     d
rest   8        q
measure 18
rest  32
measure 19
rest  32
measure 20
rest  32
measure 21
rest  32
measure 22
rest  16        h
rest   8        q
C#5    6        e.    d  [      (
D5     1        t     d  =[[
E5     1        t     d  ]]]    )
measure 23
G#4   12        q.    u         &t
A4     4        e     u
B4     8        q     u
rest   8        q
measure 24
rest  32
measure 25
rest  32
measure 26
rest  16        h
rest   8        q
rest   4        e
C#5    4        e     d
measure 27
D5     4        e     d  [      (
C#5    4        e     d  =      )
D5     4        e     d  =      (
B4     4        e     d  ]      )
C#5    4        e     d  [      &(
B4     4        e     d  ]
C#5    4        e     u  [      &)
E4     4        e     u  ]
measure 28
rest  32
measure 29
rest  32
measure 30
rest  32
measure 31
rest  16        h
rest   8        q
rest   4        e
A4     4        e     u
measure 32
A4     8        q     u         (
G#4    4        e     u  [      )t
B4     4        e     u  ]
B4     8        q     u         (
A4     4        e     u  [      )t
C#5    4        e     u  ]
measure 33
C#5    8        q     d         (
B4     4        e     d  [      )t
D5     4        e     d  ]
D5     8        q     d         (
C#5    4        e     d  [      )t
E5     4        e     d  ]
measure 34
A4     4        e     u  [
G#4    4        e     u  =
A4     4        e     u  =
B4     4        e     u  ]
E4     8        q     u
rest   8        q
measure 35
rest  32
measure 36
rest  32
measure 37
rest  16        h
rest   8        q
rest   4        e
A5     4        e     d         f
measure 38
A5     8        q     d         (
G#5    4        e     d  [      )t
B5     4        e     d  ]
B5     8        q     d         (
A5     4        e     d  [      )t
C#6    4        e     d  ]
measure 39
A4    12        q.    u
B4     4        e     d
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  =
F#5    4        e     d  ]
measure 40
G#5    4        e     d  [
A5     4        e     d  =
B5     4        e     d  =
C#6    4        e     d  ]
F#5   12        q.    d
B5     4        e     d
measure 41
G#5   12        q.    d         &t
A5     4        e     d
A5     4        e     d  [
A4     4        e     d  ]
D5     8-       q     d        -
measure 42
D5     4        e     d  [
E5     4        e     d  =
C#5    6        e.    d  =      &t
B4     2        s     d  ]\
C#5    4        e     u  [
G#4    4        e     u  =
A4     4        e     u  =
F#4    4        e     u  ]
measure 43
G#4   12        q.    u         &t
A4     4        e     u
A4     8        q     u
A3     8        q     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-10/2} [KHM:177473242]
TIMESTAMP: DEC/26/2001 [md5sum:228ef58fbe69b4d30fca9fc4d568e664]
06/10/90 E. Correia
WK#:56        MV#:2,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Tenore
1 19 T
Group memberships: score
score: part 2 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:4   T:1/1   C:34   D:Andante larghetto
rest   2        e
measure 1
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u                    But
measure 6
C#5    4        q     d                    thou
E5     2        e     d                    didst
C#5    2        e     d                    not
A4     6        q.    u                    leave
E4     2        e     u                    his
measure 7
D5     4        q     d                    soul
C#5    3        e.    d  [                 in_
B4     1        s     d  ]\                _
B4     4        q     d                    hell,
rest   4        q
measure 8
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u                    but
measure 9
E5     4        q     d                    thou
D5     1        s     d  [[                didst_
C#5    1        s     d  ]]                _
B4     1        s     u  [[                not_
A4     1        s     u  ]]                _
G#4    4        q     u                    leave
rest   2        e
E4     2        e     u                    his
measure 10
D5     4        q     d                    soul
C#5    3        e.    d  [                 in_
B4     1        s     d  ]\                _
B4     4        q     d                    hell;
rest   2        e
E5     2        e     d                    nor
measure 11
E5     4        q     d         (          didst_
D#5    2        e     d         )          _
F#5    2        e     d                    thou
B4     2        e     d                    suf-
B4     4        q     d                    fer,
E5     2        e     d                    nor
measure 12
E4     4        q     u                    didst
rest   2        e
F#4    2        e     u                    thou
G#4    2        e     u  [                 suf-
A4     2        e     u  ]                 -
B4     2        e     d                    fer
C#5    2        e     d                    thy
measure 13
D#5    2        e     d  [                 Ho-
E5     2        e     d  ]                 -
F#5    2        e     d  [                 ly_
G#5    2        e     d  ]                 _
C#5    6        q.    d                    One
F#5    2        e     d                    to
measure 14
D#5    6        q.    d                    see
D#5    2        e     d                    cor-
E5     4        q     d                    rup-
E5     4        q     d                    tion.
measure 15
rest  16
measure 16
rest  16
measure 17
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u                    But
measure 18
B4     4        q     d                    thou
B4     2        e     d                    didst
G#4    2        e     u                    not
E4     4        q     u                    leave
rest   2        e
E5     2        e     d                    his
measure 19
A4     4        q     u                    soul
G#4    4        q     u                    in
F#4    4        q     u                    hell,
rest   2        e
F#4    2        e     u                    thou
measure 20
B4     4        q     d                    didst
A4     4        q     u                    not
G#4    4        q     u                    leave,
rest   2        e
B4     2        e     d                    thou
measure 21
E5     4        q     d                    didst
D5     4        q     d                    not
C#5    4        q     d                    leave
rest   2        e
E5     2        e     d                    his
measure 22
G#4    6        q.    u                    soul
A4     2        e     u                    in
B4     4        q     d                    hell;
rest   4        q
measure 23
rest   8        h
rest   4        q
rest   2        e
C#5    2        e     d                    nor
measure 24
D5     2        e     d  [                 didst_
C#5    2        e     d  ]                 _
D5     2        e     d  [                 thou_
B4     2        e     d  ]                 _
C#5    2        e     d  [                 suf-
B4     2        e     d  ]                 -
C#5    2        e     d                    fer
A4     2        e     u                    thy
measure 25
B4     6        q.    d                    Ho-
C#5    2        e     d                    ly
A4     8        h     u                    One
measure 26
rest   2        e
C#5    2        e     d                    to
B4     2        e     d                    see
A4     2        e     u                    cor-
G#4    2        e     u  [                 rup-
F#4    2        e     u  ]                 -
E4     4        q     u                    tion,
measure 27
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u                    nor
measure 28
A4     4        q     u         (          didst_
G#4    2        e     u         )          _
B4     2        e     u                    thou
B4     2        e     u  [                 suf-
A4     2        e     u  ]                 -
A4     2        e     u                    fer,
C#5    2        e     d                    nor
measure 29
C#5    4        q     d         (          didst_
B4     2        e     d         )          _
C#5    2        e     d                    thou
D5     2        e     d  [                 suf-
B4     2        e     d  ]                 -
C#5    2        e     d                    fer
E5     2        e     d                    thy
measure 30
F#4    2        e     u  [                 Ho-
G#4    2        e     u  ]                 -
A4     2        e     u  [                 ly_
B4     2        e     u  ]                 _
E4     4        q     u                    One
rest   2        e
D5     2        e     d                    to
measure 31
C#5    4        q     d                    see
B4     2        e     u  [                 cor-
A4     2        e     u  ]                 -
A4     4        q     u                    rup-
A4     4        q     u                    tion,
measure 32
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d                    nor
measure 33
F#5    6        q.    d                    didst
A4     2        e     u                    thou
G#4    2        e     u                    suf-
E4     2        e     u                    fer,
E5     4        q     d                    nor
measure 34
E5     4        q     d                    didst
D5     4        q     d                    thou
D5     2        e     d                    suf-
C#5    4        q     d                    fer
E5     2        e     d                    thy
measure 35
F#4    2        e     u  [                 Ho-
G#4    2        e     u  ]                 -
A4     2        e     u  [                 ly_
B4     2        e     u  ]                 _
E4     6        q.    u                    One,
F#4    2        e     u                    thy
measure 36
G#4    2        e     u  [                 Ho-
A4     2        e     u  ]                 -
B4     2        e     d  [                 ly_
C#5    2        e     d  ]                 _
F#4    6        q.    u                    One
D5     2        e     d                    to
measure 37
G#4    6        q.    u                    see
G#4    2        e     u                    cor-
A4     4        q     u                    rup-
A4     4        q     u                    tion.
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest  16
measure 43
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-10/3} [KHM:177473242]
TIMESTAMP: DEC/26/2001 [md5sum:4ba99930e42b20e1954f8ea9343aa31c]
06/10/90 E. Correia
WK#:56        MV#:2,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
1 19
Group memberships: score
score: part 3 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:1/1   C:22   D:Andante larghetto
rest   1        e
measure 1
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
C#3    1        e     d  ]
measure 2
B2     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
A2     1        e     d  ]
E3     2        q     d
rest   2        q
measure 3
rest   1        e
C#4    1        e     d  [
B3     1        e     d  =
E3     1        e     d  ]
rest   1        e
D4     1        e     d  [
C#4    1        e     d  =
E3     1        e     d  ]
measure 4
rest   1        e
E4     1        e     d  [
D4     1        e     d  =
C#4    1        e     d  ]
B3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
D3     1        e     d  ]
measure 5
E3     1        e     u  [
D3     1        e     u  =
E3     1        e     u  =
E2     1        e     u  ]
A2     2        q     u
rest   2        q
measure 6
rest   1        e
A3     1        e     d  [
f1              6
G#3    1        e     d  =
f1              6
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
C#3    1        e     d  ]
measure 7
B2     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
A2     1        e     d  ]
E3     1        e     d  [
E4     1        e     d  =
D4     1        e     d  =
C#4    1        e     d  ]
measure 8
rest   1        e
G#3    1        e     d  [
A3     1        e     d  =
D3     1        e     d  ]
rest   1        e
E3     1        e     d  [
D3     1        e     d  =
E3     1        e     d  ]
measure 9
C#3    1        e     u  [
A2     1        e     u  =
F#3    1        e     u  =
D3     1        e     u  ]
E2     1        e     u  [
E3     1        e     u  =
D3     1        e     u  =
C#3    1        e     u  ]
measure 10
B2     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
A2     1        e     d  ]
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
E3     1        e     d  ]
measure 11
rest   1        e
G#3    1        e     d  [
F#3    1        e     d  =
B2     1        e     d  ]
rest   1        e
A3     1        e     d  [
G#3    1        e     d  =
E3     1        e     d  ]
measure 12
rest   1        e
C#3    1        e     u  [
B2     1        e     u  =
A2     1        e     u  ]
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
A3     1        e     d  ]
measure 13
F#3    1        e     d  [
G#3    1        e     d  =
D#3    1        e     d  =
E3     1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
F#3    1        e     d  ]
measure 14
f1              #
B3     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
E3     2        q     d
rest   2        q
measure 15
rest   1        e
G#3    1        e     d  [
F#3    1        e     d  =
B2     1        e     d  ]
rest   1        e
A3     1        e     d  [
G#3    1        e     d  =
B2     1        e     d  ]
measure 16
rest   1        e
B3     1        e     d  [
A3     1        e     d  =
G#3    1        e     d  ]
F#3    1        e     d  [
D#4    1        e     d  =
E4     1        e     d  =
A3     1        e     d  ]
measure 17
B3     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
E3     1        e     d  ]
measure 18
D#3    1        e     u  [
C#3    1        e     u  =
D#3    1        e     u  =
B2     1        e     u  ]
C#3    1        e     u  [
B2     1        e     u  =
C#3    1        e     u  =
G#2    1        e     u  ]
measure 19
F#2    1        e     u  [
D#3    1        e     u  =
E3     1        e     u  =
E2     1        e     u  ]
f1              #
B2     1        e     u  [
C#3    1        e     u  =
B2     1        e     u  =
A2     1        e     u  ]
measure 20
G#2    1        e     u  [
E3     1        e     u  =
F#2    1        e     u  =
D#3    1        e     u  ]
E3     1        e     d  [
F#3    1        e     d  =
E3     1        e     d  =
D3     1        e     d  ]
measure 21
C#3    1        e     d  [
A3     1        e     d  =
B2     1        e     d  =
G#3    1        e     d  ]
A2     1        e     d  [
E3     1        e     d  =
A3     1        e     d  =
C#3    1        e     d  ]
measure 22
B2     2        q     u
A2     2        q     u
E3     2        q     d
A3     1        e     d  [
C#3    1        e     d  ]
measure 23
B2     1        e     u  [
E3     1        e     u  =
C#3    1        e     u  =
A2     1        e     u  ]
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
E3     1        e     d  ]
measure 24
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
C#3    1        e     d  ]
measure 25
D3     1        e     d  [
C#3    1        e     d  =
D3     1        e     d  =
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
C#3    1        e     d  ]
measure 26
D3     2        q     d
D#3    2        q     d
E3     1        e     d  [
F#3    1        e     d  =
G#3    1        e     d  =
E3     1        e     d  ]
measure 27
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
C#4    1        e     d  ]
measure 28
rest   1        e
C#3    1        e     u  [
B2     1        e     u  =
E2     1        e     u  ]
rest   1        e
D3     1        e     u  [
C#3    1        e     u  =
E2     1        e     u  ]
measure 29
rest   1        e
E3     1        e     d  [
D3     1        e     d  =
C#3    1        e     d  ]
B2     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
C#3    1        e     d  ]
measure 30
D3     1        e     u  [
B2     1        e     u  =
C#3    1        e     u  =
D3     1        e     u  ]
E3     1        e     d  [
C#3    1        e     d  =
F#3    1        e     d  =
G#3    1        e     d  ]
measure 31
A3     1        e     u  [
D3     1        e     u  =
E3     1        e     u  =
E2     1        e     u  ]
A2     1        e     u  [
B2     1        e     u  =
C#3    1        e     u  =
A2     1        e     u  ]
measure 32
rest   1        e
C#4    1        e     d  [
B3     1        e     d  =
E3     1        e     d  ]
rest   1        e
D4     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 33
D4     2        q     d
D3     2        q     d
E3     2        q     d
rest   1        e
C#3    1        e     u
measure 34
F#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
G#3    1        e     d  ]
A3     2        q     d
A2     1        e     u  [
C#3    1        e     u  ]
measure 35
D3     1        e     u  [
B2     1        e     u  =
C#3    1        e     u  =
D3     1        e     u  ]
E3     1        e     u  [
D3     1        e     u  =
C#3    1        e     u  =
D3     1        e     u  ]
measure 36
B2     1        e     u  [
C#3    1        e     u  =
G#2    1        e     u  =
A2     1        e     u  ]
D3     1        e     u  [
C#3    1        e     u  =
D3     1        e     u  =
B2     1        e     u  ]
measure 37
E3     2        q     d
E2     2        q     u
A2     1        e     u  [
B2     1        e     u  =
C#3    1        e     u  =
A2     1        e     u  ]      &f
measure 38
rest   1        e
C#4    1        e     d  [
B3     1        e     d  =
E3     1        e     d  ]
rest   1        e
D4     1        e     d  [
C#4    1        e     d  =
A3     1        e     d  ]
measure 39
rest   1        e
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  =
D4     1        e     d  ]
measure 40
B3     1        e     d  [
C#4    1        e     d  =
G#3    1        e     d  =
A3     1        e     d  ]
D4     1        e     d  [
C#4    1        e     d  =
D4     1        e     d  =
B3     1        e     d  ]
measure 41
E4     1        e     d  [
D4     1        e     d  =
E4     1        e     d  =
E3     1        e     d  ]
F#3    2        q     d
rest   1        e
B3     1        e     d
measure 42
E3     2        q     d
rest   1        e
G#3    1        e     d
A3     1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
D3     1        e     d  ]
measure 43
E3     2        q     d
E2     2        q     u
A2     4        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
