&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/1} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:e2c335ae43a8e561f298cbbddb9c1c18]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4   D:A tempo ordinario
F5     4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
C5     4        q     d
rest   4        q
measure 2
C6     4        q     d
Bf5    3        e.    d  [
A5     1        s     d  ]\
G5     4        q     d
rest   2        e
A5     2        e     d
measure 3
F5     3        e.    d  [
E5     1        s     d  =\
F5     3        e.    d  =
G5     1        s     d  ]\
C5     3        e.    d  [
Bf5    1        s     d  =\
A5     3        e.    d  =
G5     1        s     d  ]\
measure 4
G5     6        q.    d         &t
F5     2        e     d
F5     4        q     d
rest   4        q
measure 5
F5     4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
C5     4        q     d
rest   4        q
measure 6
C6     4        q     d
Bf5    3        e.    d  [
A5     1        s     d  ]\
G5     4        q     d
rest   2        e
C6     2        e     d
measure 7
B5     4        q     d         t
B5     3        e.    d  [
C6     1        s     d  ]\
C6     4        q     d
rest   2        e
C6     2        e     d
measure 8
C6     3        e.    d  [
C6     1        s     d  =\
Bf5    3        e.    d  =      +
Bf5    1        s     d  ]\
A5     4        q     d
A5     2        e     d  [
D6     2        e     d  ]
measure 9
C6     1        s     d  [[
Bf5    1        s     d  ]]
A5     4        q     d
D6     2        e     d
C6     1        s     d  [[
Bf5    1        s     d  =]
A5     2        e     d  ]
A5     2        e     d  [
D6     2        e     d  ]
measure 10
C6     1        s     d  [[
Bf5    1        s     d  =]
A5     2        e     d  ]
A4     2        e     d  [
D5     2        e     d  ]
C5     1        s     d  [[
Bf4    1        s     d  =]
A4     2        e     d  ]
rest   2        e
E4     2        e     u
measure 11
F4     4        q     u
rest   2        e
G3     2        e     u
C4     4        q     u
rest   2        e
E4     2        e     u
measure 12
F4     3        e.    u  [
E4     1        s     u  =\
F4     3        e.    u  =
G4     1        s     u  ]\
C4     4        q     u
rest   2        e
C4     2        e     u
measure 13
C4     3        e.    u  [
Bf3    1        s     u  =\
Bf3    3        e.    u  =
Bf3    1        s     u  ]\
Bf3    2        e     u  [
A3     2        e     u  ]
rest   2        e
C4     2        e     u
measure 14
D4     3        e.    u  [
C4     1        s     u  =\
D4     3        e.    u  =
E4     1        s     u  ]\
F4     2        e     u  [
C4     2        e     u  ]
rest   2        e
C4     2        e     u
measure 15
D4     3        e.    u  [
C4     1        s     u  =\
D4     3        e.    u  =
E4     1        s     u  ]\
F4     2        e     u  [
C4     2        e     u  ]
rest   2        e
A5     2        e     d
measure 16
D6     4        q     d
D6     3        e.    d  [
C6     1        s     d  ]\
B5     3        e.    d  [
D5     1        s     d  =\
D5     3        e.    d  =
D5     1        s     d  ]\
measure 17
G5     4        q     d         &t
G5     3        e.    d  [
F5     1        s     d  ]\
E5     3        e.    d  [
E5     1        s     d  =\
E5     3        e.    d  =
A5     1        s     d  ]\
measure 18
D5     3        e.    d  [
D5     1        s     d  =\
E5     3        e.    d  =
F5     1        s     d  ]\
E5     2        e     d  [
C5     2        e     d  ]
rest   4        q
measure 19
C5     4        q     d
B4     3        e.    u  [
A4     1        s     u  ]\
G4     4        q     u
rest   4        q
measure 20
G4     4        q     u
F4     3        e.    u  [
E4     1        s     u  ]\
D4     4        q     u
rest   2        e
G4     2        e     u
measure 21
F#4    4        q     u
F#4    3        e.    u  [
G4     1        s     u  ]\
G4     4        q     u
rest   2        e
G4     2        e     u
measure 22
F4     3        e.    u  [      +
E4     1        s     u  =\
F4     3        e.    u  =
G4     1        s     u  ]\
E4     4        q     u
E4     2        e     u  [
A4     2        e     u  ]
measure 23
G4     1        s     u  [[
F4     1        s     u  ]]
E4     4        q     u
A4     2        e     u
G4     1        s     u  [[
F4     1        s     u  =]
E4     2        e     u  ]
E4     2        e     u  [
A4     2        e     u  ]
measure 24
G4     1        s     u  [[
F4     1        s     u  =]
E4     2        e     u  ]
C5     2        e     u  [
A4     2        e     u  ]
G4     1        s     u  [[
F4     1        s     u  =]
E4     2        e     u  ]
A4     2        e     d  [
D5     2        e     d  ]
measure 25
C5     1        s     d  [[
Bf4    1        s     d  ]]
A4     4        q     u
D5     2        e     d
C5     1        s     d  [[
Bf4    1        s     d  =]
A4     2        e     d  ]
A4     2        e     d  [
D5     2        e     d  ]
measure 26
C5     1        s     d  [[
Bf4    1        s     d  =]
A4     2        e     d  ]
F5     2        e     d  [
D5     2        e     d  ]
C5     1        s     d  [[
Bf4    1        s     d  =]
A4     2        e     d  ]
rest   2        e
C5     2        e     d
measure 27
D5     3        e.    d  [
C5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
F5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C5     2        e     d
measure 28
D5     3        e.    d  [
C5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
F5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C5     2        e     d
measure 29
D5     3        e.    d  [
C5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
F5     2        e     d  [
C5     2        e     d  ]
rest   2        e
F4     2        e     u
measure 30
G4     3        e.    u  [
A4     1        s     u  =\
Bf4    2        e     u  =
C5     2        e     u  ]
A4     4        q     u
rest   2        e
F5     2        e     d
measure 31
G5     3        e.    d  [
A5     1        s     d  =\
Bf5    2        e     d  =
C6     2        e     d  ]
A5     4        q     d
rest   4        q
measure 32
rest   8        h
rest   4        q
rest   2        e
C6     2        e     d
measure 33
Bf5    4        q     d
A5     4        q     d
G5     4        q     d
rest   4        q
measure 34
rest   4        q
rest   2        e
F5     2        e     d
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 35
A5     2        e     d  [
F5     2        e     d  ]
rest   2        e
F5     2        e     d
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 36
A5     2        e     d  [
F5     2        e     d  ]
rest   2        e
F4     2        e     u
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     2        e     d  [
F5     2        e     d  ]
measure 37
E5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C5     2        e     d
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     2        e     d  [
F5     2        e     d  ]
measure 38
E5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C5     2        e     d
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     2        e     d  [
F5     2        e     d  ]
measure 39
E5     2        e     d  [
C5     2        e     d  ]
rest   4        q
rest   2        e
A4     2        e     u
D5     4        q     d
measure 40
rest   2        e
G4     2        e     u
C5     4-       q     d        -
C5     2        e     d  [
C5     2        e     d  ]
Bf4    4-       q     d        -
measure 41
Bf4    4        q     d
A4     4        q     u
G4     8        h     u
measure 42
F4     2        e     u  [
C5     2        e     u  =
C5     2        e     u  =
C5     2        e     u  ]
F5     4        q     d
rest   2        e
F5     2        e     d
measure 43
E5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
F5     1        s     d  ]]
G5     2        e     d  [
G4     2        e     u  ]
measure 44
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     8        h     d
E5     4-       q     d        -
measure 45
E5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
C5     2        e     d  ]
B4     4        q     d
C5     4-       q     d        -
measure 46
C5     4        q     d
B4     4        q     d
C5     4        q     d
rest   4        q
measure 47
rest  16
measure 48
rest   2        e
F5     2        e     d  [
F5     2        e     d  =
F5     2        e     d  ]
Bf5    4        q     d
rest   2        e
Bf5    2        e     d
measure 49
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  =
A5     2        e     d  ]
G5     2        e     d  [
A5     1        s     d  =[
Bf5    1        s     d  ]]
C6     4-       q     d        -
measure 50
C6     4        q     d
Bf5    4-       q     d        -
Bf5    4        q     d
A5     2        e     d  [
Bf5    1        s     d  =[
C6     1        s     d  ]]
measure 51
D6     6        q.    d
E6     1        s     d  [[
D6     1        s     d  ]]
C6     6        q.    d
D6     1        s     d  [[
C6     1        s     d  ]]
measure 52
Bf5    2        e     d  [
A5     2        e     d  ]
Bf5    4        q     d
A5     2        e     d  [
C5     2        e     d  ]
F5     4        q     d
measure 53
rest   4        q
rest   2        e
F5     2        e     d
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 54
A5     2        e     d  [
F5     2        e     d  ]
rest   2        e
F5     2        e     d
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 55
A5     2        e     d  [
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
C5     4        q     d
rest   4        q
measure 56
rest   2        e
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
D5     4        q     d
rest   4        q
measure 57
rest   2        e
B4     2        e     u  [
B4     2        e     u  =
B4     2        e     u  ]
E5     4        q     d
rest   4        q
measure 58
rest   2        e
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
F5     4        q     d
rest   2        e
F5     2        e     d
measure 59
E5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
F5     1        s     d  ]]
G5     2        e     d  [
G4     2        e     u  ]
measure 60
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     4-       q     d        -
F5     4        q     d
E5     4-       q     d        -
measure 61
E5     2        e     d  [
F5     1        s     d  =[
E5     1        s     d  ]]
D5     2        e     d  [
C5     2        e     d  ]
B5     4        q     d
C6     4-       q     d        -
measure 62
C6     4        q     d
B5     4        q     d
C6     2        e     d  [
G4     2        e     u  ]
C5     4        q     d
measure 63
rest   4        q
rest   2        e
C5     2        e     d
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     2        e     d  [
F5     2        e     d  ]
measure 64
E5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C5     2        e     d
C5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F5     2        e     d  [
F5     2        e     d  ]
measure 65
E5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 66
rest   2        e
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  ]
Bf5    8-       h     d        -
measure 67
Bf5    2        e     d  [
Bf5    2        e     d  =
A5     2        e     d  =
G5     2        e     d  ]
A5     6        q.    d
A5     2        e     d
measure 68
A5     2        e     d  [
G5     2        e     d  ]
G5     4-       q     d        -
G5     2        e     d  [
F5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
measure 69
Bf5    6        q.    d
A5     1        s     d  [[
G5     1        s     d  ]]
A5     6        q.    d
Bf5    1        s     d  [[
A5     1        s     d  ]]
measure 70
G5     6        q.    d
A5     1        s     d  [[
G5     1        s     d  ]]
F5     6        q.    d
G5     1        s     d  [[
F5     1        s     d  ]]
measure 71
E5     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
Bf5    2        e     d  ]
A5     6        q.    d
G5     2        e     d
measure 72
G5     6        q.    d         &t
F5     2        e     d
F5     2        e     d  [
C5     2        e     d  ]
A4     4        q     u
measure 73
rest   4        q
rest   2        e
F5     2        e     d
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 74
A5     2        e     d  [
F5     2        e     d  ]
rest   2        e
F5     2        e     d
A5     2        e     d  [
Bf5    1        s     d  =[
C6     1        s     d  ]]
D6     2        e     d  [
D6     2        e     d  ]
measure 75
C6     2        e     d  [
A5     2        e     d  ]
rest   4        q
A5     8        h     d
measure 76
Bf5   16        w     d
measure 77
A5    16        b     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/2} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:a94b0300e90581c02f051b6b4b9486b1]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4   D:A tempo ordinario
A4     4        q     u
Bf4    3        e.    d  [
Bf4    1        s     d  ]\
C5     4        q     d
rest   4        q
measure 2
F5     4        q     d
G5     3        e.    d  [
F5     1        s     d  ]\
E5     4        q     d
rest   2        e
C5     2        e     d
measure 3
C5     4        q     d
Bf4    3        e.    d  [
Bf4    1        s     d  ]\
A4     3        e.    d  [
E5     1        s     d  =\
F5     3        e.    d  =
F5     1        s     d  ]\
measure 4
F5     4        q     d
E5     4        q     d
F5     4        q     d
rest   4        q
measure 5
A4     4        q     u
Bf4    3        e.    d  [
Bf4    1        s     d  ]\
C5     4        q     d
rest   4        q
measure 6
C5     4        q     d
D5     2        e     d  [
E5     1        s     d  =[
F5     1        s     d  ]]
E5     4        q     d
rest   2        e
E5     2        e     d
measure 7
F5     4        q     d
F5     3        e.    d  [
G5     1        s     d  ]\
G5     4        q     d
rest   2        e
E5     2        e     d
measure 8
F5     3        e.    d  [
E5     1        s     d  =\
F5     3        e.    d  =
G5     1        s     d  ]\
C5     4        q     d
F5     2        e     d  [
F5     2        e     d  ]
measure 9
F5     6        q.    d
F5     2        e     d
F5     4        q     d
F5     2        e     d  [
F5     2        e     d  ]
measure 10
F5     4        q     d
F5     2        e     d  [
F5     2        e     d  ]
F5     2        e     d  [
C5     2        e     d  ]
rest   2        e
C4     2        e     u
measure 11
Bf3    3        e.    u  [
A3     1        s     u  =\
Bf3    3        e.    u  =
C4     1        s     u  ]\
A3     2        e     u  [
G3     2        e     u  ]
rest   2        e
C4     2        e     u
measure 12
C4     3        e.    u  [
C4     1        s     u  =\
Bf3    3        e.    u  =
Bf3    1        s     u  ]\
A3     2        e     u  [
G3     2        e     u  ]
rest   2        e
E4     2        e     u
measure 13
F4     4        q     u
rest   2        e
G4     2        e     u
C4     4        q     u
rest   2        e
A3     2        e     u
measure 14
D4     4        q     u
rest   2        e
Bf3    2        e     u
C4     2        e     u  [
A3     2        e     u  ]
rest   2        e
A3     2        e     u
measure 15
D4     4        q     u
rest   2        e
Bf3    2        e     u
C4     2        e     u  [
A3     2        e     u  ]
rest   2        e
C5     2        e     d
measure 16
F5     4        q     d
F5     3        e.    d  [
E5     1        s     d  ]\
D5     3        e.    d  [
B4     1        s     d  =\
B4     3        e.    d  =
B4     1        s     d  ]\
measure 17
E5     4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
C5     3        e.    d  [
C5     1        s     d  =\
C5     3        e.    d  =
C5     1        s     d  ]\
measure 18
C5     3        e.    d  [
C5     1        s     d  =\
B4     3        e.    d  =
B4     1        s     d  ]\
C5     2        e     d  [
G4     2        e     d  ]
rest   4        q
measure 19
E4     4        q     u
F4     3        e.    u  [
F4     1        s     u  ]\
C4     4        q     u
rest   4        q
measure 20
C4     4        q     u
A3     4        q     u
B3     4        q     u
rest   2        e
B3     2        e     u
measure 21
C4     4        q     u
C4     3        e.    u  [
D4     1        s     u  ]\
D4     4        q     u
rest   2        e
B4     2        e     d
measure 22
C5     6        q.    d
rest   1        s
G4     1        s     u
G4     4        q     u
C5     2        e     d  [
C5     2        e     d  ]
measure 23
C5     6        q.    d
C5     2        e     d
C5     6        q.    d
C5     2        e     d
measure 24
C5     4        q     d
G4     2        e     u  [
F4     2        e     u  ]
E4     1        s     u  [[
D4     1        s     u  =]
C4     2        e     u  ]
F4     2        e     u  [
F4     2        e     u  ]
measure 25
F4     6        q.    u
F4     2        e     u
F4     6        q.    u
F4     2        e     u
measure 26
F4     2        e     u  [
C4     2        e     u  =
C5     2        e     u  =
Bf4    2        e     u  ]
A4     1        s     u  [[
G4     1        s     u  =]
F4     2        e     u  ]
rest   2        e
A5     2        e     d
measure 27
F5     3        e.    d  [
F5     1        s     d  =\
F5     3        e.    d  =
Bf5    1        s     d  ]\
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
A5     2        e     d
measure 28
F5     3        e.    d  [
F5     1        s     d  =\
F5     3        e.    d  =
Bf5    1        s     d  ]\
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
A5     2        e     d
measure 29
F5     3        e.    d  [
F5     1        s     d  =\
F5     3        e.    d  =
Bf5    1        s     d  ]\
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
A3     2        e     u
measure 30
Bf3    3        e.    u  [
C4     1        s     u  =\
D4     2        e     u  =
Ef4    2        e     u  ]
C4     4        q     u
rest   2        e
Bf4    2        e     d
measure 31
Bf4    3        e.    d  [
C5     1        s     d  =\
D5     2        e     d  =
Ef5    2        e     d  ]
C5     4        q     d
rest   4        q
measure 32
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d
measure 33
D5     3        e.    d  [
E5     1        s     d  =\
F5     2        e     d  =
G5     2        e     d  ]
E5     4        q     d
rest   4        q
measure 34
rest   4        q
rest   2        e
D5     2        e     d
A4     2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
measure 35
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
D5     2        e     d
A4     2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
measure 36
C5     2        e     d  [
A4     2        e     d  ]
rest   4        q
rest   4        q
rest   2        e
C5     2        e     d
measure 37
E4     2        e     u  [
F4     1        s     u  =[
G4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
G4     2        e     u  [
C5     2        e     u  ]
rest   2        e
C5     2        e     d
measure 38
E5     2        e     d  [
F5     1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
A5     2        e     d  ]
G5     2        e     d  [
C5     2        e     d  =
A4     2        e     d  =
B4     2        e     d  ]
measure 39
C5     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
A4     4        q     u
rest   2        e
A4     2        e     u
measure 40
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
F4     6        q.    u
E4     1        s     u  [[
D4     1        s     u  ]]
measure 41
E4     4        q     u
F4     8        h     u
E4     4        q     u
measure 42
F4     4        q     u
rest   4        q
rest   2        e
A4     2        e     u  [
A4     2        e     u  =
A4     2        e     u  ]
measure 43
G4     2        e     u  [
G4     2        e     u  ]
A4     4-       q     u        -
A4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 44
G4     2        e     u  [
F4     2        e     u  ]
F4     2        e     u  [
G4     1        s     u  =[
A4     1        s     u  ]]
Bf4    6        q.    d
A4     1        s     u  [[
G4     1        s     u  ]]
measure 45
A4     8        h     u
G4     6        q.    u
G4     2        e     u
measure 46
F4     2        e     u  [
E4     2        e     u  ]
F4     4        q     u
E4     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 47
F5     4        q     d
rest   2        e
F5     2        e     d
F5     2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -
measure 48
G5     2        e     d  [
C5     2        e     d  ]
F5     4-       q     d        -
F5     4        q     d
E5     4        q     d
measure 49
F5     4        q     d
rest   2        e
F5     2        e     d
G5     6        q.    d
F5     1        s     d  [[
E5     1        s     d  ]]
measure 50
F5     6        q.    d
E5     1        s     d  [[
D5     1        s     d  ]]
E5     2        e     d  [
F5     1        s     d  =[
G5     1        s     d  ]]
A5     4-       q     d        -
measure 51
A5     2        e     d  [
G5     1        s     d  =[
F5     1        s     d  ]]
Bf5    2        e     d  [
A5     2        e     d  ]
G5     4        q     d
F5     4-       q     d        -
measure 52
F5     4        q     d
E5     4        q     d
F5     2        e     d  [
C5     2        e     d  ]
A4     4        q     u
measure 53
rest   4        q
rest   2        e
D5     2        e     d
A4     2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
measure 54
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
D5     2        e     d
A4     2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
measure 55
C5     4        q     d
rest   4        q
rest   2        e
E5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  ]
measure 56
A5     4        q     d
rest   4        q
rest   2        e
F5     2        e     d  [
F5     2        e     d  =
F5     2        e     d  ]
measure 57
D5     4        q     d
rest   4        q
rest   2        e
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  ]
measure 58
E5     4        q     d
rest   4        q
rest   2        e
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  ]
measure 59
G5     4        q     d
rest   2        e
G4     2        e     u
G4     4        q     u
G4     4-       q     u        -
measure 60
G4     4        q     u
F4     2        e     u  [
E4     2        e     u  ]
D4     2        e     u  [
G4     2        e     u  ]
G4     2        e     u  [
F4     1        s     u  =[
G4     1        s     u  ]]
measure 61
A4     8        h     u
G4     4        q     u
rest   2        e
G5     2        e     d
measure 62
F5     2        e     d  [
E5     2        e     d  ]
F5     4        q     d
E5     4        q     d
rest   4        q
measure 63
rest   4        q
rest   2        e
C5     2        e     d
E5     2        e     d  [
F5     1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
A5     2        e     d  ]
measure 64
G5     2        e     d  [
E5     2        e     d  ]
rest   2        e
C5     2        e     d
E5     2        e     d  [
F5     1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
A5     2        e     d  ]
measure 65
G5     4        q     d
rest   4        q
rest   2        e
E5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  ]
measure 66
F5     4        q     d
rest   4        q
rest   2        e
F5     2        e     d  [
F5     2        e     d  =
F5     2        e     d  ]
measure 67
C5     4        q     d
rest   4        q
rest   2        e
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  ]
measure 68
D6     4        q     d
rest   2        e
D6     2        e     d
C6     2        e     d  [
C6     2        e     d  ]
F5     4-       q     d        -
measure 69
F5     2        e     d  [
F5     2        e     d  ]
E5     4-       q     d        -
E5     2        e     d  [
D5     1        s     d  =[
C5     1        s     d  ]]
D5     4-       q     d        -
measure 70
D5     2        e     d  [
C5     1        s     d  =[
B4     1        s     d  ]]
C5     4-       q     d        -
C5     2        e     d  [
Bf4    1        s     d  =[
A4     1        s     d  ]]
Bf4    4-       q     u        -
measure 71
Bf4    2        e     u  [
A4     1        s     u  =[
G4     1        s     u  ]]
G5     2        e     d  [
E5     2        e     d  ]
F5     4        q     d
F5     4        q     d
measure 72
F5     4        q     d
E5     4        q     d
F5     2        e     d  [
A4     2        e     d  ]
F4     4        q     u
measure 73
rest   4        q
rest   2        e
D5     2        e     d
A4     2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
measure 74
C5     2        e     d  [
A4     2        e     d  ]
rest   2        e
F4     2        e     u
F5     2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 75
A5     2        e     d  [
F5     2        e     d  ]
rest   4        q
C5     8        h     d
measure 76
D5    16        w     d
measure 77
C5    16        b     d
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/3} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:daf4df50bdb66a920039ee6bf3075099]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:13   D:A tempo ordinario
C4     4        q     u
Bf3    3        e.    u  [
Bf3    1        s     u  ]\
F4     4        q     d
rest   4        q
measure 2
A4     4        q     d
D4     3        e.    d  [
D4     1        s     d  ]\
G4     4        q     d
rest   2        e
E4     2        e     d
measure 3
F4     3        e.    d  [
G4     1        s     d  =\
F4     3        e.    d  =
C4     1        s     d  ]\
C4     3        e.    d  [
G4     1        s     d  =\
C5     3        e.    d  =
D5     1        s     d  ]\
measure 4
G4     4        q     d
C5     4        q     d
A4     4        q     d
rest   4        q
measure 5
F4     4        q     d
G4     3        e.    d  [
G4     1        s     d  ]\
A4     4        q     d
rest   4        q
measure 6
A4     4        q     d
G4     3        e.    d  [
F4     1        s     d  ]\
C4     4        q     d
rest   2        e
C4     2        e     d
measure 7
D4     4        q     d
D4     3        e.    d  [
E4     1        s     d  ]\
E4     4        q     d
rest   2        e
C4     2        e     d
measure 8
D4     3        e.    d  [
C4     1        s     d  =\
D4     3        e.    d  =
E4     1        s     d  ]\
F4     4        q     d
F4     2        e     d  [
Bf4    2        e     d  ]
measure 9
A4     1        s     d  [[
G4     1        s     d  ]]
F4     4        q     d
Bf4    2        e     d
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  ]
measure 10
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  ]
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
rest   2        e
G3     2        e     u
measure 11
F3     3        e.    u  [
E3     1        s     u  =\
F3     3        e.    u  =
C4     1        s     u  ]\
F3     2        e     u  [
E3     2        e     u  ]
rest   2        e
G3     2        e     u
measure 12
F3     4        q     u
rest   2        e
C4     2        e     d
F3     2        e     u  [
E3     2        e     u  ]
rest   2        e
G3     2        e     u
measure 13
F3     4        q     u
rest   2        e
C4     2        e     d
C4     4        q     d
rest   2        e
F4     2        e     d
measure 14
F4     4        q     d
rest   2        e
G4     2        e     d
C4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 15
F4     4        q     d
rest   2        e
G4     2        e     d
C4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 16
D4     4        q     d
E4     3        e.    d  [
F4     1        s     d  ]\
G4     3        e.    d  [
G4     1        s     d  =\
G4     3        e.    d  =
G4     1        s     d  ]\
measure 17
E4     4        q     d
F4     3        e.    d  [
G4     1        s     d  ]\
A4     3        e.    d  [
A4     1        s     d  =\
A4     3        e.    d  =
F4     1        s     d  ]\
measure 18
G4     3        e.    d  [
G4     1        s     d  =\
G4     3        e.    d  =
G4     1        s     d  ]\
C4     4        q     d
rest   4        q
measure 19
G3     4        q     u
F3     3        e.    u  [
F3     1        s     u  ]\
G3     4        q     u
rest   4        q
measure 20
G3     4        q     u
D4     3        e.    d  [
C4     1        s     d  ]\
B3     4        q     u
rest   2        e
B3     2        e     u
measure 21
A3     4        q     u
A3     3        e.    d  [
G4     1        s     d  ]\
G4     4        q     d
rest   2        e
D4     2        e     d
measure 22
C4     3        e.    d  [
B3     1        s     d  =\
C4     3        e.    d  =
D4     1        s     d  ]\
E4     4        q     d
G3     2        e     u  [
F3     2        e     u  ]
measure 23
C4     2        e     u  [
G3     2        e     u  ]
rest   2        e
F3     2        e     u
C4     2        e     u  [
G3     2        e     u  ]
rest   2        e
F3     2        e     u
measure 24
C4     4        q     u
C4     2        e     u  [
C4     2        e     u  ]
C4     2        e     u  [
G3     2        e     u  =
A3     2        e     u  =
Bf3    2        e     u  ]
measure 25
C4     6        q.    u
Bf3    2        e     u
C4     6        q.    u
Bf3    2        e     u
measure 26
C4     2        e     d
F4     4        q     d
F4     2        e     d
F4     2        e     d  [
C4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 27
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 28
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 29
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
rest   2        e
C4     2        e     d
measure 30
Ef4    4        q     d
F4     4        q     d
F4     4        q     d
rest   2        e
D4     2        e     d
measure 31
Ef4    4        q     d
Bf3    4        q     u
F4     4        q     d
rest   4        q
measure 32
rest   8        h
rest   4        q
rest   2        e
F4     2        e     d
measure 33
Bf3    4        q     u
C4     4        q     d
C5     4        q     d
rest   4        q
measure 34
rest   4        q
rest   2        e
Bf3    2        e     u
C4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 35
F4     2        e     d  [
C4     2        e     d  ]
rest   2        e
Bf3    2        e     u
C4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 36
F4     2        e     d  [
C4     2        e     d  ]
rest   4        q
rest   4        q
rest   2        e
A4     2        e     d
measure 37
G4     2        e     d  [
F4     1        s     d  =[
E4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
E4     2        e     d  [
F4     1        s     d  =[
G4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
measure 38
G4     2        e     d  [
F4     1        s     d  =[
E4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
E4     2        e     d  [
G4     2        e     d  ]
rest   4        q
measure 39
rest   2        e
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
C4     2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
D4     2-       e     d  ]     -
measure 40
D4     4        q     d
C4     4        q     d
D4     8        h     d
measure 41
G3     4        q     u
rest   4        q
rest   8        h
measure 42
rest   2        e
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  ]
C4     4        q     d
rest   2        e
C4     2        e     d
measure 43
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
A3     2        e     u  [
Bf3    1        s     u  =[
C4     1        s     u  ]]
D4     2        e     u  [
D3     2        e     u  ]
measure 44
A3     2        e     u  [
Bf3    1        s     u  =[
C4     1        s     u  ]]
D4     2        e     d  [
D3     2        e     u  ]
G3     2        e     u  [
A3     1        s     u  =[
Bf3    1        s     u  ]]
C4     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
measure 45
F4     2        e     d  [
F3     2        e     u  ]
F4     4-       q     d        -
F4     4        q     d
E4     4        q     d
measure 46
D4     2        e     d  [
C4     2        e     d  ]
D4     4        q     d
C4     4        q     d
rest   4        q
measure 47
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
D5     4        q     d
rest   2        e
D5     2        e     d
measure 48
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
D5     4        q     d
C5     4        q     d
measure 49
C5     2        e     d  [
A4     2        e     d  ]
D5     4-       q     d        -
D5     4        q     d
C5     4        q     d
measure 50
D5     6        q.    d
Bf4    2        e     d
G4     4        q     d
rest   2        e
F4     2        e     d
measure 51
F4     2        e     d  [
D4     2        e     d  =
G4     2        e     d  =
F4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  =
F4     2        e     d  =
A4     2        e     d  ]
measure 52
Bf4    2        e     d  [
C5     2        e     d  ]
Bf4    4        q     d
C5     2        e     d  [
A4     2        e     d  ]
F4     4        q     d
measure 53
rest   4        q
rest   2        e
Bf3    2        e     u
C4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 54
F4     2        e     d  [
C4     2        e     d  ]
rest   2        e
Bf3    2        e     u
C4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 55
F4     4        q     d
rest   4        q
rest   2        e
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
measure 56
F4     4        q     d
rest   4        q
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 57
B4     4        q     d
rest   4        q
rest   2        e
B4     2        e     d  [
B4     2        e     d  =
B4     2        e     d  ]
measure 58
C5     4        q     d
rest   4        q
rest   2        e
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
measure 59
C5     4        q     d
rest   2        e
C4     2        e     d
D4     6        q.    d
D4     2        e     d
measure 60
E4     4        q     d
D4     2        e     d  [
C4     2        e     d  ]
B3     2        e     d  [
C4     1        s     d  =[
D4     1        s     d  ]]
E4     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
measure 61
F4     6        q.    d
E4     2        e     d
D4     4        q     d
rest   2        e
C4     2        e     d
measure 62
F4     2        e     d  [
G4     2        e     d  ]
F4     4        q     d
G4     4        q     d
rest   4        q
measure 63
rest   4        q
rest   2        e
A4     2        e     d
G4     2        e     d  [
G4     2        e     d  =
F4     2        e     d  =
C5     2        e     d  ]
measure 64
C5     2        e     d  [
G4     2        e     d  ]
rest   2        e
A4     2        e     d
G4     2        e     d  [
G4     2        e     d  =
F4     2        e     d  =
C5     2        e     d  ]
measure 65
C5     2        e     d  [
C4     2        e     d  ]
rest   4        q
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 66
A4     4        q     d
rest   4        q
rest   2        e
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
measure 67
G4     2        e     d  [
G4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
F4     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 68
Bf4    4        q     d
rest   2        e
Bf4    2        e     d
C5     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 69
D4     4        q     d
E4     4        q     d
F4     6        q.    d
G4     1        s     d  [[
F4     1        s     d  ]]
measure 70
E4     6        q.    d
F4     1        s     d  [[
E4     1        s     d  ]]
D4     6        q.    d
E4     1        s     d  [[
D4     1        s     d  ]]
measure 71
C4     6        q.    d
C4     2        e     d
C4     4        q     d
D4     4        q     d
measure 72
C4     4        q     d
C5     4        q     d
A4     2        e     d  [
C4     2        e     d  ]
F4     4        q     d
measure 73
rest   4        q
rest   2        e
F4     2        e     d
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 74
F4     4        q     d
rest   2        e
F4     2        e     d
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 75
F4     2        e     d  [
F4     2        e     d  ]
rest   4        q
F4     8        h     d
measure 76
F4    16        w     d
measure 77
F4    16        b     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/4} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:3615b8e2d276affdcd120795d331af87]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano I
1 23 S
Group memberships: score
score: part 4 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4   D:A tempo ordinario
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
F5     4        q     d                    Lift
E5     3        e.    d                    up
D5     1        s     d                    your
C5     4        q     d                    heads,
rest   4        q
measure 6
C5     4        q     d                    O
D5     2        e     d  [                 ye_
E5     1        s     d  =[                _
F5     1        s     d  ]]                _
E5     4        q     d                    gates,
rest   2        e
C5     2        e     d                    and
measure 7
B4     4        q     d                    be
B4     3        e.    d                    ye
C5     1        s     d                    lift
C5     4        q     d                    up,
rest   2        e
E5     2        e     d                    ye
measure 8
F5     3        e.    d                    e-
E5     1        s     d                    ver-
F5     3        e.    d                    last-
G5     1        s     d                    ing
C5     4        q     d                    doors,
F5     2        e     d                    and
F5     2        e     d                    the
measure 9
F5     6        q.    d                    King
F5     2        e     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry
A4     2        e     u                    shall
D5     2        e     d                    come
measure 10
C5     1        s     u  [[                in!_
Bf4    1        s     u  =]                _
A4     2        e     u  ]                 _
rest   4        q
rest   8        h
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    The
measure 16
F5     4        q     d                    Lord
F5     3        e.    d                    strong
E5     1        s     d                    and
D5     2        e     d                    migh-
D5     2        e     d                    ty,
rest   2        e
D5     2        e     d                    the
measure 17
G5     4        q     d                    Lord
G5     3        e.    d                    strong
F5     1        s     d                    and
E5     3        e.    d                    migh-
E5     1        s     d                    ty,
E5     3        e.    d                    the
F5     1        s     d                    Lord
measure 18
D5     4        q     d                    migh-
E5     3        e.    d                    ty
F5     1        s     d                    in
E5     2        e     d                    batt-
C5     2        e     d                    le.
rest   4        q
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    Who
measure 27
D5     3        e.    d                    is
C5     1        s     d                    this
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry?
rest   2        e
C5     2        e     d                    who
measure 28
D5     3        e.    d                    is
C5     1        s     d                    this
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry?
rest   2        e
C5     2        e     d                    who
measure 29
D5     3        e.    d                    is
C5     1        s     d                    this
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry?
rest   4        q
measure 30
rest  16
measure 31
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    the
measure 32
D5     3        e.    d  [                 Lord_
E5     1        s     d  ]\                _
F5     2        e     d  [                 of_
G5     2        e     d  ]                 _
E5     4        q     d                    hosts;
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    he
measure 34
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
D5     2        e     d                    he
measure 35
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
measure 36
rest   4        q
rest   2        e
F4     2        e     u                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 37
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
C5     2        e     d                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 38
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
C5     2        e     d                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 39
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
rest   2        e
A4     2        e     u                    he
D5     4        q     d                    is
measure 40
rest   2        e
G4     2        e     u                    the
C5     4-       q     d        -           King_
C5     2        e     d                    _
C5     2        e     d                    of
Bf4    4-       q     d        -           glo-
measure 41
Bf4    4        q     d                    -
A4     4        q     u                    -
G4     8        h     u                    -
measure 42
F4     2        e     u                    ry,
C5     2        e     d                    the
C5     2        e     d                    Lord
C5     2        e     d                    of
F5     4        q     d                    hosts,
rest   2        e
F5     2        e     d                    he
measure 43
E5     2        e     d                    is
E5     2        e     d                    the
E5     2        e     d                    King
E5     2        e     d                    of
D5     2        e     d  [                 glo-
E5     1        s     d  =[                -
F5     1        s     d  ]]                -
G5     2        e     d  [                 -
G4     2        e     u  ]                 -
measure 44
C5     2        e     d  [                 -
D5     1        s     d  =[                -
E5     1        s     d  ]]                -
F5     8        h     d                    -
E5     4-       q     d        -           -
measure 45
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C5     1        s     d  ]]                -
D5     2        e     d  [                 -
C5     2        e     d  ]                 -
B4     4        q     d                    -
C5     4-       q     d        -           -
measure 46
C5     4        q     d                    -
B4     4        q     d                    -
C5     4        q     d                    ry,
rest   4        q
measure 47
rest  16
measure 48
rest   2        e
F4     2        e     u                    the
F4     2        e     u                    Lord
F4     2        e     u                    of
Bf4    4        q     d                    hosts,
rest   2        e
Bf4    2        e     d                    he
measure 49
A4     2        e     u                    is
A4     2        e     u                    the
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u  [                 glo-
A4     1        s     u  =[                -
Bf4    1        s     u  ]]                -
C5     4-       q     d        -           -
measure 50
C5     4        q     d                    -
Bf4    4-       q     d        -           -
Bf4    4        q     d                    -
A4     2        e     d  [                 -
Bf4    1        s     d  =[                -
C5     1        s     d  ]]                -
measure 51
D5     6        q.    d                    -
E5     1        s     d  [[                -
D5     1        s     d  ]]                -
C5     6        q.    d                    -
D5     1        s     d  [[                -
C5     1        s     d  ]]                -
measure 52
Bf4    2        e     u  [                 -
A4     2        e     u  ]                 -
Bf4    4        q     u                    -
A4     4        q     u                    ry,
rest   2        e
C5     2        e     d                    he
measure 53
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
D5     2        e     d                    he
measure 54
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
measure 55
rest   2        e
F4     2        e     u                    the
F4     2        e     u                    Lord
F4     2        e     u                    of
C5     4        q     d                    hosts,
rest   4        q
measure 56
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
D5     4        q     d                    hosts,
rest   4        q
measure 57
rest   2        e
B4     2        e     d                    the
B4     2        e     d                    Lord
B4     2        e     d                    of
E5     4        q     d                    hosts,
rest   4        q
measure 58
rest   2        e
C5     2        e     d                    the
C5     2        e     d                    Lord
C5     2        e     d                    of
F5     4        q     d                    hosts,
rest   2        e
F5     2        e     d                    he
measure 59
E5     2        e     d                    is
E5     2        e     d                    the
E5     2        e     d                    King
E5     2        e     d                    of
D5     2        e     d  [                 glo-
E5     1        s     d  =[                -
F5     1        s     d  ]]                -
G5     2        e     d  [                 -
G4     2        e     u  ]                 -
measure 60
C5     2        e     d  [                 -
D5     1        s     d  =[                -
E5     1        s     d  ]]                -
F5     4-       q     d        -           -
F5     4        q     d                    -
E5     4-       q     d        -           -
measure 61
E5     2        e     d  [                 -
F5     1        s     d  =[                -
E5     1        s     d  ]]                -
D5     2        e     d  [                 -
C5     2        e     d  ]                 -
B4     4        q     d                    -
C5     4-       q     d        -           -
measure 62
C5     4        q     d                    -
B4     4        q     d                    -
C5     4        q     d                    ry,
rest   2        e
C5     2        e     d                    he
measure 63
C5     2        e     d                    is
C5     2        e     d                    the
C5     2        e     d                    King
C5     2        e     d                    of
C5     2        e     d                    glo-
G4     2        e     u                    ry,
rest   2        e
C5     2        e     d                    he
measure 64
C5     2        e     d                    is
C5     2        e     d                    the
C5     2        e     d                    King
C5     2        e     d                    of
C5     2        e     d                    glo-
G4     2        e     u                    ry,
rest   4        q
measure 65
rest   8        h
rest   2        e
E5     2        e     d                    the
E5     2        e     d                    Lord
E5     2        e     d                    of
measure 66
F5     4        q     d                    hosts,
rest   4        q
rest   2        e
F5     2        e     d                    the
F5     2        e     d                    Lord
F5     2        e     d                    of
measure 67
C5     4        q     d                    hosts,
rest   4        q
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
measure 68
D5     4        q     d                    hosts,
rest   2        e
D5     2        e     d                    he
C5     2        e     d                    is
C5     2        e     d                    the
F5     4-       q     d        -           King_
measure 69
F5     2        e     d                    _
F5     2        e     d                    of
E5     4-       q     d        -           glo-
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C5     1        s     d  ]]                -
D5     4-       q     d        -           -
measure 70
D5     2        e     d  [                 -
C5     1        s     d  =[                -
B4     1        s     d  ]]                -
C5     4-       q     d        -           -
C5     2        e     d  [                 -
Bf4    1        s     d  =[                -
A4     1        s     d  ]]                -
Bf4    4-       q     d        -           -
measure 71
Bf4    4        q     d                    -
C5     2        e     d                    ry,
Bf4    2        e     d                    the
A4     6        q.    u                    King
G4     2        e     u                    of
measure 72
G4     8        h     u                    glo-
A4     4        q     u                    ry,
rest   2        e
A4     2        e     u                    he
measure 73
A4     2        e     u                    is
Bf4    1        s     d  [[                the_
C5     1        s     d  ]]                _
D5     2        e     d                    King
D5     2        e     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry,
rest   2        e
Bf4    2        e     d                    he
measure 74
A4     2        e     u                    is
Bf4    1        s     d  [[                the_
C5     1        s     d  ]]                _
D5     2        e     d                    King
D5     2        e     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry,
rest   4        q
measure 75
rest   8        h
C5     8        h     d                    of
measure 76
D5    16        w     d                    glo-
measure 77
C5    16        b     d                    ry.
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/5} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:c7a9b2195a257b8877d6eadb0dbd202b]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano II
1 23 S
Group memberships: score
score: part 5 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4   D:A tempo ordinario
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
A4     4        q     u                    Lift
Bf4    3        e.    d                    up
Bf4    1        s     d                    your
C5     4        q     d                    heads,
rest   4        q
measure 6
C5     4        q     d                    O
Bf4    3        e.    u  [                 ye_
A4     1        s     u  ]\                _
G4     4        q     u                    gates,
rest   2        e
E4     2        e     u                    and
measure 7
F4     4        q     u                    be
F4     3        e.    u                    ye
G4     1        s     u                    lift
G4     4        q     u                    up,
rest   2        e
C5     2        e     d                    ye
measure 8
C5     3        e.    d                    e-
C5     1        s     d                    ver-
Bf4    3        e.    d                    last-
Bf4    1        s     d                    ing
A4     4        q     u                    doors,
A4     2        e     u                    and
D5     2        e     d                    the
measure 9
C5     1        s     d  [[     (          King_
Bf4    1        s     d  ]]                _
A4     4        q     u         )          _
D5     2        e     d                    of
C5     1        s     d  [[                glo-
Bf4    1        s     d  ]]                -
A4     2        e     u                    ry
F5     2        e     d                    shall
F5     2        e     d                    come
measure 10
F5     4        q     d                    in!
rest   4        q
rest   8        h
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u                    The
measure 16
D5     4        q     d                    Lord
D5     3        e.    d                    strong
C5     1        s     d                    and
B4     2        e     d                    migh-
B4     2        e     d                    ty,
rest   2        e
B4     2        e     d                    the
measure 17
G4     4        q     u                    Lord
A4     3        e.    u                    strong
B4     1        s     d                    and
C5     3        e.    d                    migh-
C5     1        s     d                    ty,
C5     3        e.    d                    the
C5     1        s     d                    Lord
measure 18
C5     4        q     d                    migh-
B4     3        e.    d                    ty
B4     1        s     d                    in
C5     2        e     d                    batt-
G4     2        e     u                    le.
rest   4        q
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest   8        h
rest   4        q
rest   2        e
F5     2        e     d                    Who
measure 27
F5     3        e.    d                    is
F5     1        s     d                    this
F5     3        e.    d                    King
Bf4    1        s     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry?
rest   2        e
F5     2        e     d                    who
measure 28
F5     3        e.    d                    is
F5     1        s     d                    this
F5     3        e.    d                    King
Bf4    1        s     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry?
rest   2        e
F5     2        e     d                    who
measure 29
F5     3        e.    d                    is
F5     1        s     d                    this
F5     3        e.    d                    King
Bf4    1        s     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry?
rest   4        q
measure 30
rest  16
measure 31
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    the
measure 32
D5     3        e.    d  [                 Lord_
E5     1        s     d  ]\                _
F5     2        e     d  [                 of_
G5     2        e     d  ]                 _
E5     4        q     d                    hosts;
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
C5     2        e     d                    he
measure 34
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
D5     2        e     d                    he
measure 35
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
measure 36
rest   4        q
rest   2        e
F4     2        e     u                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 37
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
C5     2        e     d                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 38
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
C5     2        e     d                    he
C5     2        e     d                    is
D5     1        s     d  [[                the_
E5     1        s     d  ]]                _
F5     2        e     d                    King
F5     2        e     d                    of
measure 39
E5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
rest   2        e
A4     2        e     u                    he
D5     4        q     d                    is
measure 40
rest   2        e
G4     2        e     u                    the
C5     4-       q     d        -           King_
C5     2        e     d                    _
C5     2        e     d                    of
Bf4    4-       q     d        -           glo-
measure 41
Bf4    4        q     d                    -
A4     4        q     u                    -
G4     8        h     u                    -
measure 42
F4     2        e     u                    ry,
C5     2        e     d                    the
C5     2        e     d                    Lord
C5     2        e     d                    of
F5     4        q     d                    hosts,
rest   2        e
F5     2        e     d                    he
measure 43
E5     2        e     d                    is
E5     2        e     d                    the
E5     2        e     d                    King
E5     2        e     d                    of
D5     2        e     d  [                 glo-
E5     1        s     d  =[                -
F5     1        s     d  ]]                -
G5     2        e     d  [                 -
G4     2        e     u  ]                 -
measure 44
C5     2        e     d  [                 -
D5     1        s     d  =[                -
E5     1        s     d  ]]                -
F5     8        h     d                    -
E5     4-       q     d        -           -
measure 45
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C5     1        s     d  ]]                -
D5     2        e     d  [                 -
C5     2        e     d  ]                 -
B4     4        q     d                    -
C5     4-       q     d        -           -
measure 46
C5     4        q     d                    -
B4     4        q     d                    -
C5     4        q     d                    ry,
rest   4        q
measure 47
rest  16
measure 48
rest   2        e
F4     2        e     u                    the
F4     2        e     u                    Lord
F4     2        e     u                    of
Bf4    4        q     d                    hosts,
rest   2        e
Bf4    2        e     d                    he
measure 49
A4     2        e     u                    is
A4     2        e     u                    the
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u  [                 glo-
A4     1        s     u  =[                -
Bf4    1        s     u  ]]                -
C5     4-       q     d        -           -
measure 50
C5     4        q     d                    -
Bf4    4-       q     d        -           -
Bf4    4        q     d                    -
A4     2        e     d  [                 -
Bf4    1        s     d  =[                -
C5     1        s     d  ]]                -
measure 51
D5     6        q.    d                    -
E5     1        s     d  [[                -
D5     1        s     d  ]]                -
C5     6        q.    d                    -
D5     1        s     d  [[                -
C5     1        s     d  ]]                -
measure 52
Bf4    2        e     u  [                 -
A4     2        e     u  ]                 -
Bf4    4        q     u                    -
A4     4        q     u                    ry,
rest   2        e
C5     2        e     d                    he
measure 53
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   2        e
D5     2        e     d                    he
measure 54
C5     2        e     d                    is
F5     2        e     d                    the
D5     3        e.    d                    King
E5     1        s     d                    of
F5     2        e     d                    glo-
C5     2        e     d                    ry,
rest   4        q
measure 55
rest   2        e
F4     2        e     u                    the
F4     2        e     u                    Lord
F4     2        e     u                    of
C5     4        q     d                    hosts,
rest   4        q
measure 56
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
D5     4        q     d                    hosts,
rest   4        q
measure 57
rest   2        e
B4     2        e     d                    the
B4     2        e     d                    Lord
B4     2        e     d                    of
E5     4        q     d                    hosts,
rest   4        q
measure 58
rest   2        e
C5     2        e     d                    the
C5     2        e     d                    Lord
C5     2        e     d                    of
F5     4        q     d                    hosts,
rest   2        e
F5     2        e     d                    he
measure 59
E5     2        e     d                    is
E5     2        e     d                    the
E5     2        e     d                    King
E5     2        e     d                    of
D5     2        e     d  [                 glo-
E5     1        s     d  =[                -
F5     1        s     d  ]]                -
G5     2        e     d  [                 -
G4     2        e     u  ]                 -
measure 60
C5     2        e     d  [                 -
D5     1        s     d  =[                -
E5     1        s     d  ]]                -
F5     4-       q     d        -           -
F5     4        q     d                    -
E5     4-       q     d        -           -
measure 61
E5     2        e     d  [                 -
F5     1        s     d  =[                -
E5     1        s     d  ]]                -
D5     2        e     d  [                 -
C5     2        e     d  ]                 -
B4     4        q     d                    -
C5     4-       q     d        -           -
measure 62
C5     4        q     d                    -
B4     4        q     d                    -
C5     4        q     d                    ry,
rest   2        e
C5     2        e     d                    he
measure 63
C5     2        e     d                    is
C5     2        e     d                    the
C5     2        e     d                    King
C5     2        e     d                    of
C5     2        e     d                    glo-
G4     2        e     u                    ry,
rest   2        e
C5     2        e     d                    he
measure 64
C5     2        e     d                    is
C5     2        e     d                    the
C5     2        e     d                    King
C5     2        e     d                    of
C5     2        e     d                    glo-
G4     2        e     u                    ry,
rest   4        q
measure 65
rest   8        h
rest   2        e
E5     2        e     d                    the
E5     2        e     d                    Lord
E5     2        e     d                    of
measure 66
F5     4        q     d                    hosts,
rest   4        q
rest   2        e
F5     2        e     d                    the
F5     2        e     d                    Lord
F5     2        e     d                    of
measure 67
C5     4        q     d                    hosts
rest   4        q
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
measure 68
D5     4        q     d                    hosts,
rest   2        e
D5     2        e     d                    he
C5     2        e     d                    is
C5     2        e     d                    the
F5     4-       q     d        -           King_
measure 69
F5     2        e     d                    _
F5     2        e     d                    of
E5     4-       q     d        -           glo-
E5     2        e     d  [                 -
D5     1        s     d  =[                -
C5     1        s     d  ]]                -
D5     4-       q     d        -           -
measure 70
D5     2        e     d  [                 -
C5     1        s     d  =[                -
B4     1        s     d  ]]                -
C5     4-       q     d        -           -
C5     2        e     d  [                 -
Bf4    1        s     d  =[                -
A4     1        s     d  ]]                -
Bf4    4-       q     d        -           -
measure 71
Bf4    4        q     d                    -
C5     2        e     d                    ry,
Bf4    2        e     d                    the
A4     6        q.    u                    King
G4     2        e     u                    of
measure 72
G4     8        h     u                    glo-
A4     4        q     u                    ry,
rest   2        e
A4     2        e     u                    he
measure 73
A4     2        e     u                    is
Bf4    1        s     d  [[                the_
C5     1        s     d  ]]                _
D5     2        e     d                    King
D5     2        e     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry,
rest   2        e
Bf4    2        e     d                    he
measure 74
A4     2        e     u                    is
Bf4    1        s     d  [[                the_
C5     1        s     d  ]]                _
D5     2        e     d                    King
D5     2        e     d                    of
C5     2        e     d                    glo-
A4     2        e     u                    ry,
rest   4        q
measure 75
rest   8        h
C5     8        h     d                    of
measure 76
D5    16        w     d                    glo-
measure 77
C5    16        b     d                    ry.
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/6} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:0b637d0101105412a695b257efc2c951]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 6 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4   D:A tempo ordinario
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
F4     4        q     u                    Lift
G4     3        e.    u                    up
G4     1        s     u                    your
A4     4        q     u                    heads,
rest   4        q
measure 6
A4     4        q     u                    O
G4     3        e.    u  [                 ye_
F4     1        s     u  ]\                _
C4     4        q     u                    gates,
rest   2        e
C4     2        e     u                    and
measure 7
D4     4        q     u                    be
D4     3        e.    u                    ye
E4     1        s     u                    lift
E4     4        q     u                    up,
rest   2        e
C4     2        e     u                    ye
measure 8
D4     3        e.    u                    e-
C4     1        s     u                    ver-
D4     3        e.    u                    last-
E4     1        s     u                    ing
F4     4        q     u                    doors,
F4     2        e     u                    and
Bf4    2        e     u                    the
measure 9
A4     1        s     u  [[     (          King_
G4     1        s     u  ]]                _
F4     4        q     u         )          _
Bf4    2        e     u                    of
A4     1        s     u  [[                glo-
G4     1        s     u  ]]                -
F4     2        e     u                    ry
F4     2        e     u                    shall
Bf4    2        e     u                    come
measure 10
A4     1        s     u  [[                in!_
G4     1        s     u  =]                _
F4     2        e     u  ]                 _
rest   4        q
rest   8        h
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    The
measure 16
D4     4        q     u                    Lord
E4     3        e.    u                    strong
F4     1        s     u                    and
G4     2        e     u                    migh-
G4     2        e     u                    ty,
rest   2        e
G4     2        e     u                    the
measure 17
E4     4        q     u                    Lord
F4     3        e.    u                    strong
G4     1        s     u                    and
A4     3        e.    u                    migh-
A4     1        s     u                    ty,
A4     3        e.    u                    the
F4     1        s     u                    Lord
measure 18
G4     4        q     u                    migh-
G4     3        e.    u                    ty
G4     1        s     u                    in
C4     2        e     u                    batt-
C4     2        e     u                    le.
rest   4        q
measure 19
E4     4        q     u                    Lift
F4     3        e.    u                    up
F4     1        s     u                    your
G4     4        q     u                    heads,
rest   4        q
measure 20
G4     4        q     u                    O
F4     3        e.    u  [                 ye_
E4     1        s     u  ]\                _
D4     4        q     u                    gates,
rest   2        e
G4     2        e     u                    and
measure 21
F#4    4        q     u                    be
F#4    3        e.    u                    ye
G4     1        s     u                    lift
G4     4        q     u                    up,
rest   2        e
G4     2        e     u                    ye
measure 22
F4     3        e.    u         +          e-
E4     1        s     u                    ver-
F4     3        e.    u                    last-
G4     1        s     u                    ing
E4     4        q     u                    doors;
E4     2        e     u                    and
A4     2        e     u                    the
measure 23
G4     1        s     u  [[     (          King_
F4     1        s     u  ]]                _
E4     4        q     u         )          _
A4     2        e     u                    of
G4     1        s     u  [[                glo-
F4     1        s     u  ]]                -
E4     2        e     u                    ry
E4     2        e     u                    shall
A4     2        e     u                    come
measure 24
G4     1        s     u  [[                in,_
F4     1        s     u  =]                _
E4     2        e     u  ]                 _
rest   4        q
rest   4        q
F4     2        e     u                    and
F4     2        e     u                    the
measure 25
F4     6        q.    u                    King
F4     2        e     u                    of
F4     2        e     u                    glo-
F4     2        e     u                    ry
F4     2        e     u                    shall
F4     2        e     u                    come
measure 26
F4     4        q     u                    in!
rest   4        q
rest   4        q
rest   2        e
F4     2        e     u                    Who
measure 27
Bf4    3        e.    u                    is
A4     1        s     u                    this
Bf4    3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
F4     2        e     u                    ry?
rest   2        e
F4     2        e     u                    who
measure 28
Bf4    3        e.    u                    is
A4     1        s     u                    this
Bf4    3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
F4     2        e     u                    ry?
rest   2        e
F4     2        e     u                    who
measure 29
Bf4    3        e.    u                    is
A4     1        s     u                    this
Bf4    3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
F4     2        e     u                    ry?
rest   2        e
F4     2        e     u                    The
measure 30
G4     3        e.    u  [                 Lord_
A4     1        s     u  ]\                _
Bf4    4        q     u                    of
A4     4        q     u                    hosts,
rest   4        q
measure 31
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    the
measure 32
Bf4    4        q     u                    Lord
A4     4        q     u                    of
G4     4        q     u                    hosts;
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
F4     2        e     u                    he
measure 34
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 35
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
D4     2        e     u                    he
measure 36
C4     2        e     u                    is
F4     2        e     u                    the
F4     2        e     u                    King
F4     2        e     u                    of
F4     2        e     u                    glo-
C4     2        e     u                    ry,
rest   2        e
A4     2        e     u                    he
measure 37
G4     2        e     u                    is
G4     2        e     u                    the
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u                    glo-
G4     2        e     u                    ry,
rest   2        e
A4     2        e     u                    he
measure 38
G4     2        e     u                    is
G4     2        e     u                    the
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u                    glo-
G4     2        e     u                    ry,
rest   4        q
measure 39
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    Lord
G4     2        e     u                    of
A4     4        q     u                    hosts,
rest   2        e
A4     2        e     u                    he
measure 40
G4     2        e     u                    is
G4     2        e     u                    the
G4     2        e     u                    King
G4     2        e     u                    of
F4     6        q.    u                    glo-
E4     1        s     u  [[                -
D4     1        s     u  ]]                -
measure 41
E4     4        q     u                    -
F4     8        h     u                    -
E4     4        q     u                    -
measure 42
F4     4        q     u                    ry,
rest   4        q
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
measure 43
G4     2        e     u                    hosts,
G4     2        e     u                    he
A4     4-       q     u        -           is_
A4     2        e     u                    _
G4     2        e     u                    the
G4     2        e     u                    King
G4     2        e     u                    of
measure 44
G4     2        e     u  [                 glo-
F4     2        e     u  ]                 -
F4     2        e     u  [                 -
G4     1        s     u  =[                -
A4     1        s     u  ]]                -
Bf4    6        q.    u                    -
A4     1        s     u  [[                -
G4     1        s     u  ]]                -
measure 45
A4     8        h     u                    -
G4     6        q.    u                    ry,
G4     2        e     u                    of
measure 46
F4     2        e     u  [      (          glo-
E4     2        e     u  ]                 -
F4     4        q     u         )          -
E4     2        e     u                    ry,
C4     2        e     u                    the
C4     2        e     u                    Lord
C4     2        e     u                    of
measure 47
F4     4        q     u                    hosts,
rest   2        e
F4     2        e     u                    he
F4     2        e     u                    is
D4     2        e     u                    the
G4     4-       q     u        -           King_
measure 48
G4     2        e     u                    _
C4     2        e     u                    of
F4     4-       q     u        -           glo-
F4     4        q     u                    -
E4     4        q     u                    -
measure 49
F4     4        q     u                    ry,
rest   2        e
F4     2        e     u                    of
G4     6        q.    u                    glo-
F4     1        s     u  [[                -
E4     1        s     u  ]]                -
measure 50
F4     6        q.    u                    -
E4     1        s     u  [[                -
D4     1        s     u  ]]                -
E4     2        e     u  [                 -
F4     1        s     u  =[                -
G4     1        s     u  ]]                -
A4     4-       q     u        -           -
measure 51
A4     2        e     u  [                 -
G4     1        s     u  =[                -
F4     1        s     u  ]]                -
Bf4    2        e     u  [                 -
A4     2        e     u  ]                 -
G4     4        q     u                    -
F4     4-       q     u        -           -
measure 52
F4     4        q     u                    -
E4     4        q     u                    -
F4     4        q     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 53
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 54
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   4        q
measure 55
rest   8        h
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    Lord
G4     2        e     u                    of
measure 56
A4     4        q     u                    hosts,
rest   4        q
rest   2        e
F4     2        e     u                    the
F4     2        e     u                    Lord
F4     2        e     u                    of
measure 57
D4     4        q     u                    hosts,
rest   4        q
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    Lord
G4     2        e     u                    of
measure 58
E4     4        q     u                    hosts,
rest   4        q
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
measure 59
G4     4        q     u                    hosts,
rest   2        e
G4     2        e     u                    he
G4     6        q.    u                    is
G4     2        e     u                    the
measure 60
G4     4        q     u                    King
F4     2        e     u  [                 of_
E4     2        e     u  ]                 _
D4     2        e     u  [                 glo-
G4     2        e     u  ]                 -
G4     2        e     u  [                 -
F4     1        s     u  =[                -
G4     1        s     u  ]]                -
measure 61
A4     8        h     u                    -
G4     4        q     u                    ry,
rest   2        e
G4     2        e     u                    of
measure 62
F4     2        e     u  [      (          glo-
G4     2        e     u  ]                 -
F4     4        q     u         )          -
G4     4        q     u                    ry,
rest   2        e
E4     2        e     u                    he
measure 63
E4     2        e     u                    is
F4     1        s     u  [[                the_
G4     1        s     u  ]]                _
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u                    glo-
E4     2        e     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 64
E4     2        e     u                    is
F4     1        s     u  [[                the_
G4     1        s     u  ]]                _
A4     2        e     u                    King
A4     2        e     u                    of
G4     2        e     u                    glo-
E4     2        e     u                    ry,
rest   4        q
measure 65
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    Lord
G4     2        e     u                    of
A4     4        q     u                    hosts,
rest   4        q
measure 66
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    Lord
A4     2        e     u                    of
Bf4    8-       h     u        -           hosts,_
measure 67
Bf4    2        e     u  [                 _
Bf4    2        e     u  =                 _
A4     2        e     u  =                 _
G4     2        e     u  ]                 _
A4     6        q.    u                    _
A4     2        e     u                    he
measure 68
A4     2        e     u                    is
G4     2        e     u                    the
G4     4-       q     u        -           King,_
G4     2        e     u                    _
F4     2        e     u                    the
G4     2        e     u                    King
A4     2        e     u                    of
measure 69
Bf4    6        q.    u                    glo-
A4     1        s     u  [[                -
G4     1        s     u  ]]                -
A4     6        q.    u                    -
Bf4    1        s     u  [[                -
A4     1        s     u  ]]                -
measure 70
G4     6        q.    u                    -
A4     1        s     u  [[                -
G4     1        s     u  ]]                -
F4     6        q.    u                    -
G4     1        s     u  [[                -
F4     1        s     u  ]]                -
measure 71
E4     2        e     u  [                 -
F4     2        e     u  ]                 -
G4     2        e     u                    ry,
G4     2        e     u                    the
F4     4        q     u                    King
F4     4        q     u                    of
measure 72
F4     4        q     u         (          glo-
E4     4        q     u         )          -
F4     4        q     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 73
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
F4     2        e     u                    he
measure 74
F4     2        e     u                    is
F4     2        e     u                    the
F4     3        e.    u                    King
G4     1        s     u                    of
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   4        q
measure 75
rest   8        h
A4     8        h     u                    of
measure 76
Bf4   16        w     u                    glo-
measure 77
A4    16        b     u                    ry.
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/7} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:945ffe6f51f2119189a6e3cf7a1e3ba7]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 7 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:34   D:A tempo ordinario
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   8        h
rest   4        q
rest   2        e
C4     2        e     d                    Who
measure 11
Bf3    3        e.    u                    is
A3     1        s     u                    this
Bf3    3        e.    u                    King
C4     1        s     d                    of
A3     2        e     u                    glo-
G3     2        e     u                    ry?
rest   4        q
measure 12
rest   8        h
rest   4        q
rest   2        e
E4     2        e     d                    this
measure 13
F4     4        q     d                    King
rest   2        e
G4     2        e     d                    of
C4     2        e     d                    glo-
C4     2        e     d                    ry?
rest   2        e
C4     2        e     d                    who
measure 14
D4     3        e.    d                    is
C4     1        s     d                    this
D4     2        e     d                    King
E4     2        e     d                    of
F4     2        e     d                    glo-
C4     2        e     d                    ry?
rest   2        e
C4     2        e     d                    who
measure 15
D4     3        e.    d                    is
C4     1        s     d                    this
D4     2        e     d                    King
E4     2        e     d                    of
F4     2        e     d                    glo-
C4     2        e     d                    ry?
rest   4        q
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
C4     4        q     d                    Lift
B3     3        e.    u                    up
A3     1        s     u                    your
G3     4        q     u                    heads,
rest   4        q
measure 20
C4     4        q     d                    O
D4     3        e.    d  [                 ye_
C4     1        s     d  ]\                _
B3     4        q     d                    gates,
rest   2        e
B3     2        e     d                    and
measure 21
C4     4        q     d                    be
C4     3        e.    d                    ye
D4     1        s     d                    lift
D4     4        q     d                    up,
rest   2        e
B3     2        e     d                    ye
measure 22
C4     3        e.    d                    e-
B3     1        s     d                    ver-
C4     3        e.    d                    last-
D4     1        s     d                    ing
E4     4        q     d                    doors;
C4     2        e     d                    and
C4     2        e     d                    the
measure 23
C4     6        q.    d                    King
C4     2        e     d                    of
C4     2        e     d                    glo-
C4     2        e     d                    ry
C4     2        e     d                    shall
C4     2        e     d                    come
measure 24
C4     4        q     d                    in,
rest   4        q
rest   4        q
A3     2        e     u                    and
D4     2        e     d                    the
measure 25
C4     1        s     d  [[     (          King_
Bf3    1        s     d  ]]                _
A3     4        q     d         )          _
D4     2        e     d                    of
C4     1        s     d  [[                glo-
Bf3    1        s     d  ]]                -
A3     2        e     u                    ry
A3     2        e     u                    shall
D4     2        e     d                    come
measure 26
C4     1        s     d  [[                in!_
Bf3    1        s     d  =]                _
A3     2        e     d  ]                 _
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    The
measure 30
Bf3    3        e.    d  [                 Lord_
C4     1        s     d  ]\                _
D4     2        e     d  [                 of_
Ef4    2        e     d  ]                 _
C4     4        q     d                    hosts,
rest   4        q
measure 31
rest   8        h
rest   4        q
rest   2        e
C4     2        e     d                    the
measure 32
Bf3    4        q     d                    Lord
C4     4        q     d                    of
C4     4        q     d                    hosts;
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    he
measure 34
A3     2        e     u                    is
Bf3    1        s     d  [[                the_
C4     1        s     d  ]]                _
D4     2        e     d                    King
D4     2        e     d                    of
C4     2        e     d                    glo-
A3     2        e     u                    ry,
rest   2        e
Bf3    2        e     u                    he
measure 35
A3     2        e     u                    is
Bf3    1        s     d  [[                the_
C4     1        s     d  ]]                _
D4     2        e     d                    King
D4     2        e     d                    of
C4     2        e     d                    glo-
A3     2        e     u                    ry,
rest   2        e
Bf3    2        e     u                    he
measure 36
A3     2        e     u                    is
Bf3    1        s     d  [[                the_
C4     1        s     d  ]]                _
D4     2        e     d                    King
D4     2        e     d                    of
C4     2        e     d                    glo-
A3     2        e     u                    ry,
rest   2        e
F3     2        e     u                    he
measure 37
C4     2        e     d                    is
D4     1        s     d  [[                the_
E4     1        s     d  ]]                _
F4     2        e     d                    King
F4     2        e     d                    of
E4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   2        e
F3     2        e     u                    he
measure 38
C4     2        e     d                    is
D4     1        s     d  [[                the_
E4     1        s     d  ]]                _
F4     2        e     d                    King
F4     2        e     d                    of
E4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   4        q
measure 39
rest   2        e
E4     2        e     d                    the
E4     2        e     d                    Lord
E4     2        e     d                    of
C4     2        e     d                    hosts,
C4     2        e     d                    he
F4     2        e     d                    is
D4     2        e     d                    the
measure 40
D4     4        q     d                    King
C4     4        q     d                    of
D4     8        h     d                    glo-
measure 41
G3     4        q     u                    ry,
rest   4        q
rest   8        h
measure 42
rest   8        h
rest   2        e
F3     2        e     u                    the
F3     2        e     u                    Lord
F3     2        e     u                    of
measure 43
C4     4        q     d                    hosts,
rest   2        e
C4     2        e     d                    he
Bf3    2        e     d                    is
Bf3    2        e     d                    the
Bf3    2        e     d                    King
Bf3    2        e     d                    of
measure 44
A3     2        e     d  [                 glo-
Bf3    1        s     d  =[                -
C4     1        s     d  ]]                -
D4     2        e     u  [                 -
D3     2        e     u  ]                 -
G3     2        e     u  [                 -
A3     1        s     u  =[                -
Bf3    1        s     u  ]]                -
C4     2        e     d  [                 -
D4     1        s     d  =[                -
E4     1        s     d  ]]                -
measure 45
F4     2        e     d  [                 -
F3     2        e     d  ]                 -
F4     4-       q     d        -           -
F4     4        q     d                    -
E4     4        q     d                    -
measure 46
D4     2        e     d  [                 -
C4     2        e     d  ]                 -
D4     4        q     d                    -
C4     4        q     d                    ry,
rest   4        q
measure 47
rest   2        e
A3     2        e     u                    the
A3     2        e     u                    Lord
A3     2        e     u                    of
D4     4        q     d                    hosts,
rest   2        e
D4     2        e     d                    he
measure 48
C4     2        e     d                    is
C4     2        e     d                    the
C4     2        e     d                    King
C4     2        e     d                    of
D4     4        q     d         (          glo-
C4     4        q     d         )          -
measure 49
C4     2        e     d                    ry,
A3     2        e     u                    of
D4     4-       q     d        -           glo-
D4     4        q     d                    -
C4     4        q     d                    -
measure 50
D4     6        q.    d                    -
Bf3    2        e     d                    -
G3     4        q     u                    ry,
rest   2        e
F4     2        e     d                    of
measure 51
F4     2        e     d  [                 glo-
D4     2        e     d  =                 -
G4     2        e     d  =                 -
F4     2        e     d  ]                 -
E4     2        e     d  [                 -
C4     2        e     d  =                 -
F4     2        e     d  =                 -
A3     2        e     d  ]                 -
measure 52
Bf3    2        e     d  [                 -
C4     2        e     d  ]                 -
Bf3    4        q     d                    -
C4     4        q     d                    ry,
rest   2        e
A3     2        e     u                    he
measure 53
A3     2        e     u                    is
Bf3    1        s     d  [[                the_
C4     1        s     d  ]]                _
D4     2        e     d                    King
D4     2        e     d                    of
C4     2        e     d                    glo-
A3     2        e     u                    ry,
rest   2        e
Bf3    2        e     u                    he
measure 54
A3     2        e     u                    is
Bf3    1        s     d  [[                the_
C4     1        s     d  ]]                _
D4     2        e     d                    King
D4     2        e     d                    of
C4     2        e     d                    glo-
A3     2        e     u                    ry,
rest   4        q
measure 55
rest   8        h
rest   2        e
E4     2        e     d                    the
E4     2        e     d                    Lord
E4     2        e     d                    of
measure 56
C4     4        q     d                    hosts,
rest   4        q
rest   2        e
D4     2        e     d                    the
D4     2        e     d                    Lord
A3     2        e     u                    of
measure 57
B3     4        q     d                    hosts,
rest   4        q
rest   2        e
B3     2        e     d                    the
B3     2        e     d                    Lord
B3     2        e     d                    of
measure 58
C4     4        q     d                    hosts,
rest   4        q
rest   2        e
C4     2        e     d                    the
C4     2        e     d                    Lord
C4     2        e     d                    of
measure 59
C4     4        q     d                    hosts,
rest   2        e
C4     2        e     d                    he
D4     6        q.    d                    is
D4     2        e     d                    the
measure 60
E4     4        q     d                    King
D4     2        e     d  [                 of_
C4     2        e     d  ]                 _
B3     2        e     d  [                 glo-
C4     1        s     d  =[                -
D4     1        s     d  ]]                -
E4     2        e     d  [                 -
D4     1        s     d  =[                -
E4     1        s     d  ]]                -
measure 61
F4     6        q.    d                    -
E4     2        e     d                    -
D4     4        q     d                    ry,
rest   2        e
C4     2        e     d                    of
measure 62
D4     2        e     d  [      (          glo-
E4     2        e     d  ]                 -
D4     4        q     d         )          -
E4     4        q     d                    ry,
rest   2        e
G3     2        e     u                    he
measure 63
G3     2        e     u                    is
C4     2        e     d                    the
A3     2        e     u                    King
F3     2        e     u                    of
C4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   2        e
A3     2        e     u                    he
measure 64
G3     2        e     u                    is
C4     2        e     d                    the
A3     2        e     u                    King
F3     2        e     u                    of
C4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   4        q
measure 65
rest   8        h
rest   2        e
E4     2        e     d                    the
E4     2        e     d                    Lord
E4     2        e     d                    of
measure 66
D4     4        q     d                    hosts,
rest   4        q
rest   2        e
Bf3    2        e     d                    the
Bf3    2        e     d                    Lord
Bf3    2        e     d                    of
measure 67
G3     2        e     u                    hosts,
G3     2        e     u                    the
C4     2        e     d                    Lord
C4     2        e     d                    of
F4     4        q     d                    hosts,
rest   2        e
F4     2        e     d                    he
measure 68
D4     2        e     d                    is
D4     2        e     d                    the
Bf3    2        e     d                    King
Bf3    2        e     d                    of
C4     4        q     d                    glo-
C4     2        e     d                    ry,
C4     2        e     d                    the
measure 69
D4     4        q     d                    King
E4     4        q     d                    of
F4     6        q.    d                    glo-
G4     1        s     d  [[                -
F4     1        s     d  ]]                -
measure 70
E4     6        q.    d                    -
F4     1        s     d  [[                -
E4     1        s     d  ]]                -
D4     6        q.    d                    -
E4     1        s     d  [[                -
D4     1        s     d  ]]                -
measure 71
C4     4        q     d                    -
C4     2        e     d                    ry,
E4     2        e     d                    the
C4     4        q     d                    King
D4     4        q     d                    of
measure 72
C4     8        h     d                    glo-
C4     4        q     d                    ry,
rest   2        e
C4     2        e     d                    he
measure 73
C4     2        e     d                    is
A3     2        e     u                    the
D4     3        e.    d                    King
E4     1        s     d                    of
F4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   2        e
D4     2        e     d                    he
measure 74
C4     2        e     d                    is
A3     2        e     u                    the
D4     3        e.    d                    King
E4     1        s     d                    of
F4     2        e     d                    glo-
C4     2        e     d                    ry,
rest   4        q
measure 75
rest   8        h
F4     8        h     d                    of
measure 76
F4    16        w     d                    glo-
measure 77
F4    16        b     d                    ry.
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/8} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:db61a504b598c62e98c1cec72585e31e]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 8 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:22   D:A tempo ordinario
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest   8        h
rest   4        q
rest   2        e
C3     2        e     u                    Who
measure 11
D3     3        e.    d                    is
C3     1        s     u                    this
D3     3        e.    d                    King
E3     1        s     d                    of
F3     2        e     d                    glo-
C3     2        e     u                    ry?
rest   4        q
measure 12
rest   8        h
rest   4        q
rest   2        e
C3     2        e     u                    this
measure 13
D3     4        q     d                    King
rest   2        e
E3     2        e     d                    of
F3     2        e     d                    glo-
F3     2        e     d                    ry?
rest   2        e
F3     2        e     d                    who
measure 14
Bf3    3        e.    d                    is
A3     1        s     d                    this
Bf3    2        e     d                    King
G3     2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry?
rest   2        e
F3     2        e     d                    who
measure 15
Bf3    3        e.    d                    is
A3     1        s     d                    this
Bf3    2        e     d                    King
G3     2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry?
rest   4        q
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
C3     4        q     u                    Lift
D3     3        e.    d                    up
D3     1        s     d                    your
E3     4        q     d                    heads,
rest   4        q
measure 20
E3     4        q     d                    O
F3     4        q     d                    ye
G3     4        q     d                    gates,
rest   2        e
G3     2        e     d                    and
measure 21
A3     4        q     d                    be
A3     3        e.    d                    ye
B3     1        s     d                    lift
B3     4        q     d                    up,
rest   2        e
G3     2        e     d                    ye
measure 22
A3     3        e.    d                    e-
G3     1        s     d                    ver-
A3     3        e.    d                    last-
B3     1        s     d                    ing
C4     4        q     d                    doors;
C3     2        e     u                    and
F3     2        e     d                    the
measure 23
E3     1        s     d  [[     (          King_
D3     1        s     d  ]]                _
C3     4        q     u         )          _
F3     2        e     d                    of
E3     1        s     d  [[                glo-
D3     1        s     d  ]]                -
C3     2        e     u                    ry
C3     2        e     u                    shall
F3     2        e     d                    come
measure 24
E3     1        s     d  [[                in,_
D3     1        s     d  =]                _
C3     2        e     d  ]                 _
rest   4        q
rest   4        q
F3     2        e     d                    and
Bf3    2        e     d                    the
measure 25
A3     1        s     d  [[     (          King_
G3     1        s     d  ]]                _
F3     4        q     d         )          _
Bf3    2        e     d                    of
A3     1        s     d  [[                glo-
G3     1        s     d  ]]                -
F3     2        e     d                    ry
F3     2        e     d                    shall
Bf3    2        e     d                    come
measure 26
A3     1        s     d  [[                in!_
G3     1        s     d  =]                _
F3     2        e     d  ]                 _
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest   8        h
rest   4        q
rest   2        e
F3     2        e     d                    The
measure 30
Ef3    4        q     d                    Lord
Bf2    4        q     u                    of
F3     4        q     d                    hosts,
rest   4        q
measure 31
rest   8        h
rest   4        q
rest   2        e
A3     2        e     d                    the
measure 32
G3     4        q     d                    Lord
F3     4        q     d                    of
C4     4        q     d                    hosts;
rest   4        q
measure 33
rest   8        h
rest   4        q
rest   2        e
F3     2        e     d                    he
measure 34
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 35
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 36
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   4        q
measure 37
rest  16
measure 38
rest  16
measure 39
rest   2        e
C3     2        e     u                    the
C3     2        e     u                    Lord
C3     2        e     u                    of
F3     4        q     d                    hosts,
rest   2        e
F3     2        e     d                    he
measure 40
E3     2        e     d                    is
E3     2        e     d                    the
E3     2        e     d                    King
E3     2        e     d                    of
D3     2        e     d  [                 glo-
E3     1        s     d  =[                -
F3     1        s     d  ]]                -
G3     2        e     d  [                 -
G2     2        e     u  ]                 -
measure 41
C3     2        e     d  [                 -
C4     2        e     d  =                 -
D4     2        e     d  =                 -
A3     2        e     d  ]                 -
Bf3    2        e     d  [                 -
G3     2        e     d  =                 -
C4     2        e     d  =                 -
Bf3    2        e     d  ]                 -
measure 42
A3     4        q     d                    -
F3     4        q     d                    ry,
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest   2        e
F3     2        e     d                    the
F3     2        e     d                    Lord
F3     2        e     d                    of
Bf3    4        q     d                    hosts,
rest   2        e
Bf3    2        e     d                    he
measure 48
A3     2        e     d                    is
A3     2        e     d                    the
A3     2        e     d                    King
A3     2        e     d                    of
G3     2        e     d  [                 glo-
A3     1        s     d  =[                -
Bf3    1        s     d  ]]                -
C4     2        e     d  [                 -
C3     2        e     u  ]                 -
measure 49
F3     4        q     d                    ry,
rest   2        e
F3     2        e     d                    of
E3     2        e     d  [                 glo-
F3     1        s     d  =[                -
G3     1        s     d  ]]                -
A3     2        e     d  [                 -
A2     2        e     u  ]                 -
measure 50
D3     2        e     d  [                 -
E3     1        s     d  =[                -
F3     1        s     d  ]]                -
G3     2        e     d  [                 -
G2     2        e     u  ]                 -
C3     2        e     d  [                 -
D3     1        s     d  =[                -
E3     1        s     d  ]]                -
F3     2        e     d  [                 -
G3     1        s     d  =[                -
A3     1        s     d  ]]                -
measure 51
Bf3    2        e     d  [                 -
Bf2    2        e     u  ]                 -
Bf3    8        h     d                    -
A3     4        q     d                    -
measure 52
G3     2        e     d  [                 -
F3     2        e     d  ]                 -
G3     4        q     d                    -
F3     4        q     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 53
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 54
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   4        q
measure 55
rest   8        h
rest   2        e
C3     2        e     u                    the
C3     2        e     u                    Lord
C3     2        e     u                    of
measure 56
F3     4        q     d                    hosts,
rest   4        q
rest   2        e
D3     2        e     d                    the
D3     2        e     d                    Lord
D3     2        e     d                    of
measure 57
G3     4        q     d                    hosts,
rest   4        q
rest   2        e
E3     2        e     d                    the
E3     2        e     d                    Lord
E3     2        e     d                    of
measure 58
A3     4        q     d                    hosts,
rest   4        q
rest   2        e
F3     2        e     d                    the
F3     2        e     d                    Lord
F3     2        e     d                    of
measure 59
C4     4        q     d                    hosts,
rest   2        e
C4     2        e     d                    he
B3     2        e     d                    is
B3     2        e     d                    the
B3     2        e     d                    King
B3     2        e     d                    of
measure 60
A3     2        e     d  [                 glo-
B3     1        s     d  =[                -
C4     1        s     d  ]]                -
D4     2        e     d  [                 -
D3     2        e     u  ]                 -
G3     2        e     d  [                 -
A3     1        s     d  =[                -
B3     1        s     d  ]]                -
C4     2        e     d  [                 -
C3     2        e     u  ]                 -
measure 61
F3     2        e     d  [                 -
F2     2        e     u  ]                 -
F3     4-       q     d        -           -
F3     4        q     d                    -
E3     4        q     d                    -
measure 62
D3     2        e     u  [                 -
C3     2        e     u  ]                 -
D3     4        q     u                    -
C3     4        q     u                    ry,
rest   2        e
C3     2        e     u                    he
measure 63
C3     2        e     u                    is
D3     1        s     d  [[                the_
E3     1        s     d  ]]                _
F3     2        e     d                    King
F3     2        e     d                    of
E3     2        e     d                    glo-
C3     2        e     u                    ry,
rest   2        e
C3     2        e     u                    he
measure 64
C3     2        e     u                    is
D3     1        s     d  [[                the_
E3     1        s     d  ]]                _
F3     2        e     d                    King
F3     2        e     d                    of
E3     2        e     d                    glo-
C3     2        e     u                    ry,
rest   4        q
measure 65
rest   8        h
rest   2        e
C4     2        e     d                    the
C4     2        e     d                    Lord
C4     2        e     d                    of
measure 66
D4     4        q     d                    hosts,
rest   4        q
rest   2        e
D3     2        e     d                    the
D3     2        e     d                    Lord
D3     2        e     d                    of
measure 67
E3     4        q     d                    hosts,
rest   4        q
rest   2        e
F3     2        e     d                    the
F3     2        e     d                    Lord
F3     2        e     d                    of
measure 68
Bf3    4        q     d                    hosts,
rest   2        e
Bf3    2        e     d                    he
A3     2        e     d                    is
A3     2        e     d                    the
A3     2        e     d                    King
A3     2        e     d                    of
measure 69
G3     2        e     d  [                 glo-
A3     1        s     d  =[                -
Bf3    1        s     d  ]]                -
C4     2        e     d  [                 -
C3     2        e     u  ]                 -
F3     2        e     d  [                 -
G3     1        s     d  =[                -
A3     1        s     d  ]]                -
Bf3    2        e     d  [                 -
D3     2        e     d  ]                 -
measure 70
E3     2        e     d  [                 -
F3     1        s     d  =[                -
G3     1        s     d  ]]                -
A3     2        e     d  [                 -
C3     2        e     d  ]                 -
D3     2        e     d  [                 -
E3     1        s     d  =[                -
F3     1        s     d  ]]                -
G3     2        e     d  [                 -
Bf2    2        e     d  ]                 -
measure 71
C3     2        e     u  [                 -
D3     2        e     u  ]                 -
E3     2        e     d                    ry,
C3     2        e     u                    the
F3     4        q     d                    King
Bf2    4        q     u                    of
measure 72
C3     8        h     u                    glo-
F3     4        q     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 73
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   2        e
F3     2        e     d                    he
measure 74
F3     2        e     d                    is
G3     1        s     d  [[                the_
A3     1        s     d  ]]                _
Bf3    2        e     d                    King
Bf3    2        e     d                    of
A3     2        e     d                    glo-
F3     2        e     d                    ry,
rest   4        q
measure 75
rest   8        h
F3     8        h     d                    of
measure 76
Bf3   16        w     d                    glo-
measure 77
F3    16        b     d                    ry.
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 9
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-11/9} [KHM:1381492075]
TIMESTAMP: DEC/26/2001 [md5sum:6bf9e80d1e4a7e1b8a7bdeca563a5ad7]
06/10/90 E. Correia
WK#:56        MV#:2,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 9 of 9
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:22   D:A tempo ordinario
F3     4        q     d
G3     3        e.    d  [
G3     1        s     d  ]\
A3     4        q     d
rest   4        q
measure 2
A3     4        q     d
Bf3    3        e.    d  [
Bf3    1        s     d  ]\
C4     4        q     d
rest   2        e
C3     2        e     u
measure 3
D3     3        e.    d  [
C3     1        s     d  =\
D3     3        e.    d  =
E3     1        s     d  ]\
F3     3        e.    d  [
G3     1        s     d  =\
A3     3        e.    d  =
Bf3    1        s     d  ]\
measure 4
C4     4        q     d
C3     4        q     u
F3     4        q     d
rest   4        q
$ C:13
measure 5
F4     4        q     d
f1              6
G4     3        e.    d  [
G4     1        s     d  ]\
f1              6
A4     4        q     d
rest   4        q
measure 6
A4     4        q     d
G4     3        e.    d  [
F4     1        s     d  ]\
C4     4        q     d
rest   2        e
C4     2        e     d
measure 7
f1              6n
D4     4        q     d
D4     3        e.    d  [
f1              6
E4     1        s     d  ]\
E4     4        q     d
rest   2        e
C4     2        e     d
measure 8
f1              7
D4     3        e.    d  [
C4     1        s     d  =\
f1              6
D4     3        e.    d  =
E4     1        s     d  ]\
F4     4        q     d
F4     2        e     d  [
Bf4    2        e     d  ]
measure 9
A4     1        s     d  [[
G4     1        s     d  ]]
F4     4        q     d
Bf4    2        e     d
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  ]
measure 10
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
F4     2        e     d  [
Bf4    2        e     d  ]
A4     1        s     d  [[
G4     1        s     d  =]
F4     2        e     d  ]
$ C:22
rest   2        e
C3     2        e     u
measure 11
f1              6
D3     3        e.    d  [
f1              6
C3     1        s     d  =\
f1              6
D3     3        e.    d  =
f1              6
E3     1        s     d  ]\
F3     2        e     d  [
C3     2        e     d  ]
rest   2        e
C3     2        e     u
measure 12
D3     3        e.    d  [
C3     1        s     d  =\
D3     3        e.    d  =
E3     1        s     d  ]\
F3     2        e     d  [
C3     2        e     d  ]
rest   2        e
C3     2        e     u
measure 13
D3     4        q     d
rest   2        e
E3     2        e     d
F3     2        e     d  [
F2     2        e     u  ]
rest   2        e
F3     2        e     d
measure 14
Bf3    3        e.    d  [
A3     1        s     d  =\
Bf3    2        e     d  =
G3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 15
Bf3    3        e.    d  [
A3     1        s     d  =\
Bf3    2        e     d  =
G3     2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
$ C:13
rest   2        e
F4     2        e     d
measure 16
D4     4        q     d
E4     3        e.    d  [
F4     1        s     d  ]\
G4     4        q     d
rest   2        e
G4     2        e     d
measure 17
E4     4        q     d
F4     3        e.    d  [
G4     1        s     d  ]\
A4     6        q.    d
rest   1        s
F4     1        s     d
measure 18
f1              4
G4     4        q     d
f1              n
G4     4        q     d
C4     4        q     d
rest   4        q
$ C:22
measure 19
C3     4        q     u
D3     3        e.    d  [
D3     1        s     d  ]\
E3     4        q     d
rest   4        q
measure 20
E3     4        q     d
f1     3        6
f1              5
F3     4        q     d
f1              n
G3     4        q     d
rest   2        e
f1              n
G3     2        e     d
measure 21
f1              6
A3     4        q     d
A3     3        e.    d  [
B3     1        s     d  ]\
B3     4        q     d
rest   2        e
G3     2        e     d
measure 22
A3     3        e.    d  [
G3     1        s     d  =\
A3     3        e.    d  =
B3     1        s     d  ]\
C4     4        q     d
C3     2        e     d  [
F3     2        e     d  ]
measure 23
E3     2        e     d  [
C3     2        e     d  ]
rest   2        e
F3     2        e     d
E3     2        e     d  [
C3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 24
E3     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
F3     2        e     d  ]
C3     4        q     u
F3     2        e     d  [
Bf3    2        e     d  ]
measure 25
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
Bf3    2        e     d
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
Bf3    2        e     d
measure 26
A3     2        e     d  [
F3     2        e     d  =
A3     2        e     d  =
Bf3    2        e     d  ]
F3     4        q     d
$ C:13
rest   2        e
F4     2        e     d
measure 27
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 28
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
rest   2        e
F4     2        e     d
measure 29
Bf4    3        e.    d  [
A4     1        s     d  =\
Bf4    3        e.    d  =
G4     1        s     d  ]\
A4     2        e     d  [
F4     2        e     d  ]
$ C:22
rest   2        e
F3     2        e     d
measure 30
Ef3    4        q     d
Bf2    4        q     u
F3     4        q     d
$ C:13
rest   2        e
D4     2        e     d
measure 31
Ef4    4        q     d
Bf3    4        q     d
F4     4        q     d
$ C:22
rest   2        e
A3     2        e     d
measure 32
G3     4        q     d
F3     4        q     d
C4     4        q     d
rest   2        e
A3     2        e     d
measure 33
G3     4        q     d
F3     4        q     d
C3     4        q     u
rest   2        e
F3     2        e     d
measure 34
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 35
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 36
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
$ C:12
rest   2        e
F3     2        e     u
measure 37
C4     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  ]
rest   2        e
F3     2        e     u
measure 38
C4     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
E4     2        e     d  [
C4     2        e     d  ]
$ C:15
A4     2        e     d  [
B4     2        e     d  ]
measure 39
C5     2        e     d  [
$ C:22
C3     2        e     d  =
C3     2        e     d  =
C3     2        e     d  ]
F3     4        q     d
rest   2        e
f1              6
F3     2        e     d
measure 40
f1              7
E3     2        e     d  [
E3     2        e     d  =
f1              6
E3     2        e     d  =
E3     2        e     d  ]
f1              7
D3     2        e     d  [
E3     1        s     d  =[
F3     1        s     d  ]]
f1              7
G3     2        e     d  [
G2     2        e     u  ]
measure 41
f1              7
C3     2        e     d  [
C4     2        e     d  =
D4     2        e     d  =
A3     2        e     d  ]
Bf3    2        e     d  [
G3     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 42
A3     4        q     d
F3     4        q     d
$ C:12
rest   2        e
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  ]
measure 43
C4     4        q     d
rest   2        e
C4     2        e     d
f1              7
Bf3    2        e     d  [
Bf3    2        e     d  =
f1              6
Bf3    2        e     d  =
Bf3    2        e     d  ]
measure 44
f1              7
A3     2        e     d  [
Bf3    1        s     d  =[
C4     1        s     d  ]]
D4     2        e     d  [
D3     2        e     u  ]
f1              7
G3     2        e     d  [
A3     1        s     d  =[
Bf3    1        s     d  ]]
f1              7
C4     2        e     d  [
D4     1        s     d  =[
E4     1        s     d  ]]
measure 45
f1              7
F4     2        e     d  [
F3     2        e     d  ]
f1     2        6
f1     2        5
f2              4n 2
F4     8        h     d
f1              6
E4     4        q     d
measure 46
D4     2        e     d  [
C4     2        e     d  ]
D4     4        q     d
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 47
F4     2        e     d  [
$ C:22
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
f1              5
Bf3    4        q     d
f1              6
rest   2        e
Bf3    2        e     d
measure 48
f1              7
A3     2        e     d  [
A3     2        e     d  =
f1              6
A3     2        e     d  =
A3     2        e     d  ]
f1              7
G3     2        e     d  [
A3     1        s     d  =[
Bf3    1        s     d  ]]
f1              7
C4     2        e     d  [
C3     2        e     u  ]
measure 49
f1              7
F3     4        q     d
f1              6
rest   2        e
F3     2        e     d
f1              7
E3     2        e     d  [
F3     1        s     d  =[
G3     1        s     d  ]]
f1              7
A3     2        e     d  [
A2     2        e     u  ]
measure 50
f1              7
D3     2        e     d  [
E3     1        s     d  =[
F3     1        s     d  ]]
f1              7
G3     2        e     d  [
G2     2        e     u  ]
f1              7
C3     2        e     d  [
D3     1        s     d  =[
E3     1        s     d  ]]
f1              3
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
measure 51
Bf3    2        e     d  [
Bf2    2        e     u  ]
Bf3    8        h     d
A3     4        q     d
measure 52
G3     2        e     d  [
F3     2        e     d  ]
G3     4        q     d
F3     4        q     d
rest   2        e
F3     2        e     d
measure 53
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 54
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   4        q
$ C:15
measure 55
rest   2        e
F4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  ]
C5     2        e     d  [
$ C:22
C3     2        e     d  =
C3     2        e     d  =
C3     2        e     d  ]
measure 56
F3     4        q     d
rest   4        q
rest   2        e
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
measure 57
f1              n
G3     4        q     d
rest   4        q
rest   2        e
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  ]
measure 58
A3     4        q     d
rest   4        q
rest   2        e
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  ]
measure 59
C4     4        q     d
rest   2        e
C4     2        e     d
B3     2        e     d  [
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]
measure 60
f1              7
A3     2        e     d  [
B3     1        s     d  =[
C4     1        s     d  ]]
D4     2        e     d  [
D3     2        e     u  ]
G3     2        e     d  [
A3     1        s     d  =[
B3     1        s     d  ]]
C4     2        e     d  [
C3     2        e     u  ]
measure 61
F3     2        e     d  [
F2     2        e     u  ]
F3     4-       q     d        -
F3     4        q     d
E3     4        q     d
measure 62
D3     2        e     u  [
C3     2        e     u  ]
D3     4        q     u
C3     4        q     u
rest   2        e
C3     2        e     u
measure 63
C3     2        e     d  [
D3     1        s     d  =[
E3     1        s     d  ]]
F3     2        e     d  [
F3     2        e     d  ]
E3     2        e     d  [
C3     2        e     d  ]
rest   2        e
C3     2        e     u
measure 64
C3     2        e     d  [
D3     1        s     d  =[
E3     1        s     d  ]]
F3     2        e     d  [
F3     2        e     d  ]
E3     2        e     d  [
C3     2        e     d  ]
rest   4        q
$ C:13
measure 65
rest   2        e
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
A4     2        e     d  [
$ C:22
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 66
D4     4        q     d
rest   4        q
rest   2        e
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
measure 67
E3     4        q     d
$ C:12
C4     2        e     d  [
C4     2        e     d  ]
F4     2        e     d  [
$ C:22
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 68
f1     4        7
f1              6
Bf3    6        q.    d
Bf3    2        e     d
f1              7
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
f1              6
A3     2        e     d  ]
measure 69
f1              7
G3     2        e     d  [
A3     1        s     d  =[
Bf3    1        s     d  ]]
f1              7
C4     2        e     d  [
C3     2        e     u  ]
f1              7
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
f1              7
Bf3    2        e     d  [
D3     2        e     d  ]
measure 70
f1              7
E3     2        e     d  [
F3     1        s     d  =[
G3     1        s     d  ]]
f1              7
A3     2        e     d  [
C3     2        e     d  ]
f1              7
D3     2        e     d  [
E3     1        s     d  =[
F3     1        s     d  ]]
G3     2        e     d  [
Bf2    2        e     d  ]
measure 71
C3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
C3     2        e     d  ]
F3     4        q     d
Bf2    4        q     u
measure 72
C3     4        q     u
C2     4        q     u
F2     4        q     u
rest   2        e
F3     2        e     d
measure 73
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   2        e
F3     2        e     d
measure 74
F3     2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
Bf3    2        e     d  [
Bf3    2        e     d  ]
A3     2        e     d  [
F3     2        e     d  ]
rest   4        q
measure 75
rest   8        h
F3     8        h     d
measure 76
Bf3   16        w     d
measure 77
F3    16        b     d
mheavy2 78
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
