&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-12/1} [KHM:1294175972]
TIMESTAMP: DEC/26/2001 [md5sum:524138115b42597ba988303be3a842cf]
06/10/90 E. Correia
WK#:56        MV#:2,12
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Tenore
0 20 T
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:34
rest   4        q
A4     2        e     u                    Un-
A4     2        e     u                    to
C#5    4        q     d                    which
C#5    2        e     d                    of
E5     2        e     d                    the
measure 2
E5     2        e     d                    an-
A4     2        e     u                    gels
rest   2        e
A4     2        e     u                    said
A4     2        e     u                    He
G4     2        e     u                    at
A4     2        e     u                    a-
E4     2        e     u                    ny
measure 3
F4     4        q     u                    time,
rest   4        q
rest   2        e
A4     2        e     u                    Thou
A4     2        e     u                    art
A4     2        e     u                    my
measure 4
D5     4        q     d                    Son,
rest   2        e
D5     2        e     d                    this
G5     2        e     d                    day
D5     2        e     d                    have
D5     2        e     d                    I
C#5    2        e     d                    be-
measure 5
E5     3        e.    d                    got-
E5     1        s     d                    ten
E5     4        q     d                    thee?
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-12/2} [KHM:1294175972]
TIMESTAMP: DEC/26/2001 [md5sum:befca1bffd212233bed845b1a18f7b54]
06/10/90 E. Correia
WK#:56        MV#:2,12
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Bassi
0 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:1   T:1/1   C:22
C#3    4-       w     u        -
measure 2
C#3    4        w     u
measure 3
D3     4        w     d
measure 4
f1              6
Bf2    4        w     u
measure 5
f1              #
A2     4        w     u
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
