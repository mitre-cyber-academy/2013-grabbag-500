&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-12/1} [KHM:224382889]
TIMESTAMP: DEC/26/2001 [md5sum:7357b15a3b2f7637d27ec54aaf2ce83a]
04/07/90 E. Correia
WK#:56        MV#:1,12
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violini unisoni e Viola
0 19
Group memberships: score
score: part 1 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Larghetto
F#4    2        e     u
measure 1
B4     2        e     u  [      (
A#4    2        e     u  =      )
B4     2        e     u  =      (
A#4    2        e     u  ]      )
B4     2        e     d  [      (
C#5    2        e     d  =
D5     2        e     d  =      )
A#4    2        e     d  ]      i
measure 2
B4     2        e     u  [      i
G4     2        e     u  =      (
F#4    2        e     u  =
E#4    2        e     u  ]      )
F#4    2        e     u  [      (
D#4    2        e     u  =      )
E4     2        e     u  =      i
C#4    2        e     u  ]      i
measure 3
D4     2        e     u  [      +i
B3     2        e     u  =      (
A#3    2        e     u  =
B3     2        e     u  ]      )
G4     2        e     u  [
E4     2        e     u  =
A#4    2        e     u  =
B4     2        e     u  ]
measure 4
F#4    6        q.    u
F#4    2        e     u
B3     4        q     u
rest   2        e
F#4    2        e     u         p
measure 5
B4     2        e     u  [      (
A#4    2        e     u  =      )
B4     2        e     u  =      (
A#4    2        e     u  ]      )
B4     2        e     d  [      (
C#5    2        e     d  =
D5     2        e     d  =      )
A#4    2        e     d  ]      i
measure 6
B4     2        e     u  [      i
G4     2        e     u  =      (
F#4    2        e     u  =
E#4    2        e     u  ]      )
F#4    2        e     u  [      (
D#4    2        e     u  =      )
E4     2        e     u  =      i
C#4    2        e     u  ]      i
measure 7
D4     2        e     u  [      i
B3     2        e     u  =      (
A#3    2        e     u  =
B3     2        e     u  ]      )
E4     2        e     u  [
D4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
measure 8
G3     4        q     u
E4     3        e.    u  [      t
F#4    1        s     u  ]\
F#4    4        q     u
rest   2        e
F#4    2        e     u
measure 9
B4     2        e     u  [      (
A#4    2        e     u  =      )
B4     2        e     u  =      (
A#4    2        e     u  ]      )
B4     2        e     u  [      (
C#5    2        e     u  =
D5     2        e     u  =      )
F#4    2        e     u  ]
measure 10
G4     2        e     u  [      (
D#4    2        e     u  =
E4     2        e     u  =      )
G#4    2        e     u  ]      i
A4     2        e     u  [      (
E#4    2        e     u  =
F#4    2        e     u  =      )
A#4    2        e     u  ]      i
measure 11
B4     4        q     d
C#5    2        e     d  [
D5     2        e     d  ]
F#4    4        q     u
F#4    2        e     u  [
A4     2        e     u  ]      +
measure 12
B4     2        e     u  [
G4     2        e     u  =
E4     2        e     u  =
C#5    2        e     u  ]
D5     2        e     u  [
D4     2        e     u  =
F#4    2        e     u  =
A4     2        e     u  ]
measure 13
B4     2        e     u  [
G4     2        e     u  =
E4     2        e     u  =
C#5    2        e     u  ]
D5     8-       h     d        -
measure 14
D5    12        h.    d
rest   2        e
D4     2        e     u
measure 15
E4     2        e     u  [      (
D4     2        e     u  =
E4     2        e     u  =      )
F#4    2        e     u  ]
G4     2        e     u  [      (
F#4    2        e     u  =
G4     2        e     u  =      )
A4     2        e     u  ]
measure 16
B4     2        e     d  [      (
A4     2        e     d  =
B4     2        e     d  =      )
C5     2        e     d  ]
D5     2        e     u  [
F#4    2        e     u  =
G4     2        e     u  =
C4     2        e     u  ]
measure 17
D4     4        q     u
G4     2        e     u  [
F#4    2        e     u  ]
G4     2        e     d  [
B4     2        e     d  =      f
D5     2        e     d  =
G5     2        e     d  ]
measure 18
E5     2        e     d  [
G4     2        e     d  =
F#4    2        e     d  =
F#5    2        e     d  ]
G5     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
A5     2        e     d  ]
measure 19
B4     2        e     d  [
G5     2        e     d  =
A4     2        e     d  =
F#5    2        e     d  ]
G3     4        q     u
rest   2        e
*               G +     p
B3     2        e     u
measure 20
E4     2        e     u  [      (
D#4    2        e     u  =      )
E4     2        e     u  =      (
D#4    2        e     u  ]      )
E4     2        e     u  [      (
F#4    2        e     u  =
G4     2        e     u  =      )
D#4    2        e     u  ]      i
measure 21
E4     2        e     u  [      i
C5     2        e     u  =      (
B4     2        e     u  =
A#4    2        e     u  ]      )
B4     2        e     u  [      (
G#4    2        e     u  =      )
A4     2        e     u  =      i
F#4    2        e     u  ]      i
measure 22
G4     2        e     u  [      &i
E4     2        e     u  =      (
D#4    2        e     u  =
E4     2        e     u  ]      )
C4     2        e     u  [
A3     2        e     u  =
B3     2        e     u  =
G3     2        e     u  ]
measure 23
A3     8        h     u         &t
B3     4        q     u
rest   2        e
B4     2        e     u
measure 24
C5     2        e     u  [      (
G#4    2        e     u  =
A4     2        e     u  =      )
C#5    2        e     u  ]
D5     2        e     u  [      (
A#4    2        e     u  =
B4     2        e     u  =      )
D#5    2        e     u  ]
measure 25
E5     2        e     d  [
B4     2        e     d  =
C5     2        e     d  =
G#4    2        e     d  ]
A4     2        e     u  [      (
F#4    2        e     u  =
G4     2        e     u  =      )
D#4    2        e     u  ]
measure 26
E4     2        e     u  [
C4     2        e     u  =      (
B3     2        e     u  =
A#3    2        e     u  ]      )
B3     2        e     u  [
D#4    2        e     u  ]
E4     4-       q     u        -
measure 27
E4     4        q     u
D#4    4        q     u         &t
E4     4        q     u
rest   4        q
measure 28
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u
measure 29
F#4    2        e     u  [
D4     2        e     u  =
B3     2        e     u  =
G#4    2        e     u  ]
A4     2        e     u  [
E4     2        e     u  =
A3     2        e     u  =
B3     2        e     u  ]
measure 30
C#4    2        e     u  [
A4     2        e     u  =
D4     2        e     u  =
B3     2        e     u  ]
E4     2        e     u  [
G#4    2        e     u  ]
A4     4-       q     u        -
measure 31
A4     4        q     u
G#4    4        q     u
rest   2        e
A4     2        e     d  [      f
C#5    2        e     d  =
E5     2        e     d  ]
measure 32
F#5    2        e     d  [
A4     2        e     d  =
G#4    2        e     d  =
G#5    2        e     d  ]
A5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
B5     2        e     d  ]
measure 33
C#5    2        e     d  [
A5     2        e     d  =
B4     2        e     d  =
G#5    2        e     d  ]
A3     4        q     u
rest   2        e
C#5    2        e     d
measure 34
F#5    2        e     d  [      (
E#5    2        e     d  =      )
F#5    2        e     d  =      (
E#5    2        e     d  ]      )
F#5    2        e     d  [      (
G#5    2        e     d  =
A5     2        e     d  =      )
*               G +     p
C#4    2        e     u  ]
measure 35
F#4    2        e     u  [      (
E#4    2        e     u  =      )
F#4    2        e     u  =      (
E#4    2        e     u  ]      )
F#4    2        e     u  [      (
G#4    2        e     u  =
A4     2        e     u  =      )
E#4    2        e     u  ]      i
measure 36
F#4    2        e     u  [      i
D4     2        e     u  =      (
C#4    2        e     u  =
B#3    2        e     u  ]      )
C#4    2        e     u  [      (
A#3    2        e     u  =      )
B3     2        e     u  =      i
G#3    2        e     u  ]      i
measure 37
A3     2        e     u  [      &(
D4     2        e     u  =
C#4    2        e     u  =      &)
F#4    2        e     u  ]
E#4    2        e     u  [      (
B4     2        e     u  =
A4     2        e     u  =      &)
D5     2        e     u  ]
measure 38
C#5    2        e     u  [      (
E#4    2        e     u  =
F#4    2        e     u  =      )
D4     2        e     u  ]
C#4    2        e     u  [      (
F#4    2        e     u  =
E#4    2        e     u  =      )
B4     2        e     u  ]
measure 39
A4     2        e     d  [      (
D5     2        e     d  =
C#5    2        e     d  =      )
F#5    2        e     d  ]
E#5    2        e     d  [      (
A5     2        e     d  =
G#5    2        e     d  =      )
B4     2        e     d  ]
measure 40
A4     2        e     u  [      (
E#4    2        e     u  =
F#4    2        e     u  =      )
D4     2        e     u  ]
C#4    4        q     u
rest   2        e
C#4    2        e     u
measure 41
D4     2        e     u  [      (
A#3    2        e     u  =
B3     2        e     u  =      )
D#4    2        e     u  ]
E4     2        e     u  [      (
B#3    2        e     u  =
C#4    2        e     u  =      )
E#4    2        e     u  ]
measure 42
F#4    2        e     u  [      &(
C#4    2        e     u  =
B3     2        e     u  =      &)
G#4    2        e     u  ]
A4     2        e     u  [      &(
E#4    2        e     u  =
F#4    2        e     u  =      &)
A#4    2        e     u  ]
measure 43
B4     2        e     u  [
F#4    2        e     u  =
E4     2        e     u  =      +
C#5    2        e     u  ]
D5     2        e     u  [      (
A#4    2        e     u  =
B4     2        e     u  =      )
D4     2        e     u  ]
measure 44
G3     6        q.    u
G4     2        e     u
F#4    2        e     u  [      (
B4     2        e     u  =
A#4    2        e     u  =      )
E5     2        e     u  ]
measure 45
D5     2        e     d  [
G5     2        e     d  =      (
F#5    2        e     d  =
E#5    2        e     d  ]      )
F#5    2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      i
A#4    2        e     d  ]      i
measure 46
B4     2        e     u  [      (
D5     2        e     u  =      +
C#5    2        e     u  =      )
E#4    2        e     u  ]
F#4    4        q     u
rest   2        e
A4     2        e     u         +
measure 47
B4     2        e     u  [
G4     2        e     u  =
E4     2        e     u  =
C#5    2        e     u  ]
D5     4        q     d
D4     4-       q     u        -
measure 48
D4     4        q     u
C#4    4        q     u         &t
D4     4        q     u
rest   2        e
F#5    2        e     d         f
measure 49
B5     2        e     d  [      (
A#5    2        e     d  =      )
B5     2        e     d  =      (
A#5    2        e     d  ]      )
B5     2        e     d  [      (
C#6    2        e     d  =
D6     2        e     d  =      )
F#4    2        e     u  ]      p
measure 50
B4     2        e     u  [      (
A#4    2        e     u  =      )
B4     2        e     u  =      (
A#4    2        e     u  ]      )
B4     2        e     d  [      (
C#5    2        e     d  =
D5     2        e     d  =      )
A#4    2        e     d  ]      i
measure 51
B4     2        e     u  [      i
G4     2        e     u  =      (
F#4    2        e     u  =
E#4    2        e     u  ]      )
F#4    2        e     u  [      (
D#4    2        e     u  =      )
E4     2        e     u  =      i
C#4    2        e     u  ]      i
measure 52
D4     2        e     u  [      &i
B3     2        e     u  =      (
A#3    2        e     u  =
B3     2        e     u  ]      )
E4     2        e     u  [
D4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
measure 53
G3     4        q     u
rest   2        e
B4     2        e     u
A#4    2        e     d  [      (
D5     2        e     d  =
C#5    2        e     d  =      )
E5     2        e     d  ]
measure 54
D5     2        e     d  [      (
G5     2        e     d  =
F#5    2        e     d  =      )
B4     2        e     d  ]
A#4    4        q     u
rest   2        e
F#4    2        e     u
measure 55
G4     2        e     u  [      (
E4     2        e     u  =
C#4    2        e     u  =      )
A#4    2        e     u  ]
B4     6        q.    u
A4     2        e     u
measure 56
G4     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  =
D#4    2        e     u  ]
E4     2        e     u  [
C#4    2        e     u  =
D4     2        e     u  =
B3     2        e     u  ]
measure 57
F#4    8        h     u
B3     4        q     u
rest   2        e
D5     2        e     d
measure 58
C#5    2        e     u  [
A#4    2        e     u  =
B4     2        e     u  =
G4     2        e     u  ]
F#4    2        e     u  [      (
A#4    2        e     u  =
B4     2        e     u  =      )
E4     2        e     u  ]
measure 59
F#4    8        h     u
B3     4        q     u
rest   2        e
F#5    2        e     d         f
measure 60
B5     2        e     d  [      (
A#5    2        e     d  =      )
B5     2        e     d  =      (
A#5    2        e     d  ]      )
B5     2        e     d  [      (
C#6    2        e     d  =
D6     2        e     d  =      )
A#5    2        e     d  ]      i
measure 61
B5     2        e     d  [      i
G5     2        e     d  =      (
F#5    2        e     d  =
E#5    2        e     d  ]      )
F#5    2        e     d  [      (
D#5    2        e     d  =      )
E5     2        e     d  =      i
C#5    2        e     d  ]      i
measure 62
D5     2        e     u  [      &i
A#4    2        e     u  =      (
B4     2        e     u  =
G4     2        e     u  ]      )
F#4    2        e     u  [
A#4    2        e     u  =
B4     2        e     u  =
E4     2        e     u  ]
measure 63
D4     2        e     u  [
B4     2        e     u  =
C#4    2        e     u  =
A#4    2        e     u  ]
B3     4        q     u         F
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-12/3} [KHM:224382889]
TIMESTAMP: DEC/26/2001 [md5sum:f1960e346cf09d5cc27e354c8e105164]
04/07/90 E. Correia
WK#:56        MV#:1,12
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Basso
0 19 B
Group memberships: score
score: part 2 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Larghetto
rest   2        e
measure 1
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest   8        h
rest   4        q
rest   2        e
F#3    2        e     d                    The
measure 5
B3     2        e     d  [                 peo-
A#3    2        e     d  ]                 -
B3     2        e     d                    ple
A#3    2        e     d                    that
B3     2        e     d  [                 walk-
C#4    2        e     d  ]                 -
D4     2        e     d                    ed
A#3    2        e     d                    in
measure 6
B3     2        e     d  [                 dark-
G3     2        e     d  =                 -
F#3    2        e     d  =                 -
E#3    2        e     d  ]                 -
F#3    2        e     d  [                 -
D#3    2        e     d  ]                 -
E3     2        e     d                    ness,
C#3    2        e     u                    that
measure 7
D3     2        e     u  [      +          walk-
B2     2        e     u  ]                 -
A#2    2        e     u                    ed
B2     2        e     u                    in
E3     2        e     d  [                 dark-
D3     2        e     d  =                 -
G3     2        e     d  =                 -
F#3    2        e     d  ]                 -
measure 8
G2     8        h     d                    -
F#2    4        q     d                    ness,
rest   4        q
measure 9
rest   8        h
rest   4        q
rest   2        e
F#3    2        e     d                    the
measure 10
G3     2        e     d  [                 peo-
D#3    2        e     d  ]                 -
E3     2        e     d                    ple
G#3    2        e     d                    that
A3     2        e     d  [                 walk-
E#3    2        e     d  ]                 -
F#3    2        e     d                    ed,
A#3    2        e     d                    that
measure 11
B3     4        q     d                    walk-
C#4    2        e     d                    ed
D4     2        e     d                    in
F#3    4        q     d                    dark-
F#3    2        e     d                    ness
A3     2        e     d         +          have
measure 12
B3     2        e     d  [                 seen_
G3     2        e     d  ]                 _
E3     2        e     d                    a
C#4    2        e     d                    great
D4     4        q     d                    light,
rest   2        e
A3     2        e     d                    have
measure 13
B3     2        e     d  [                 seen_
G3     2        e     d  ]                 _
E3     2        e     d                    a
C#4    2        e     d                    great
D4     8-       h     d        -           light,_
measure 14
D4    12        h.    d                    _
rest   2        e
D3     2        e     u                    the
measure 15
E3     2        e     d  [                 peo-
D3     2        e     d  ]                 -
E3     2        e     d                    ple
F#3    2        e     d                    that
G3     2        e     d  [                 walk-
F#3    2        e     d  ]                 -
G3     2        e     d                    ed,
A3     2        e     d                    that
measure 16
B3     2        e     d  [                 walk-
A3     2        e     d  ]                 -
B3     2        e     d                    ed
C4     2        e     d                    in
D4     2        e     d  [                 dark-
F#3    2        e     d  ]                 -
G3     2        e     d                    ness
C3     2        e     u                    have
measure 17
D3     4        q     u                    seen
B3     2        e     d                    a
A3     1        s     d  [[                great_
G3     1        s     d  ]]                _
G3     8        h     d                    light.
measure 18
rest  16
measure 19
rest   8        h
rest   4        q
rest   2        e
B2     2        e     u                    The
measure 20
E3     2        e     d  [                 peo-
D#3    2        e     d  ]                 -
E3     2        e     d                    ple
D#3    2        e     u                    that
E3     2        e     d  [                 walk-
F#3    2        e     d  ]                 -
G3     2        e     d                    ed,
D#3    2        e     u                    that
measure 21
E3     2        e     d  [                 walk-
C4     2        e     d  ]                 -
B3     2        e     d                    ed
A#3    2        e     d                    in
B3     2        e     d  [                 dark-
G#3    2        e     d  ]                 -
A3     2        e     d                    ness,
F#3    2        e     d                    that
measure 22
G3     2        e     d         +          walk-
E3     2        e     d  [                 ed_
D#3    2        e     d  ]                 _
E3     2        e     d                    in
C3     2        e     u  [                 dark-
A2     2        e     u  =                 -
B2     2        e     u  =                 -
G2     2        e     u  ]                 -
measure 23
A2     8        h     u                    -
B2     4        q     u                    ness,
rest   2        e
B3     2        e     d                    the
measure 24
C4     2        e     d  [                 peo-
G#3    2        e     d  ]                 -
A3     2        e     d                    ple
C#4    2        e     d                    that
D4     2        e     d  [                 walk-
A#3    2        e     d  ]                 -
B3     2        e     d                    ed
D#4    2        e     d                    in
measure 25
E4     2        e     d  [                 dark-
B3     2        e     d  =                 -
C4     2        e     d  =                 -
G#3    2        e     d  ]                 -
A3     2        e     d  [                 -
F#3    2        e     d  =                 -
G3     2        e     d  =                 -
D#3    2        e     d  ]                 -
measure 26
E3     2        e     u  [                 -
C3     2        e     u  =                 -
B2     2        e     u  =                 -
A#2    2        e     u  ]                 -
B2     2        e     d  [                 -
A3     2        e     d  ]      +          -
G3     2        e     d                    ness
F#3    2        e     d                    have
measure 27
G3     4        q     d                    seen
F#3    3        e.    d                    a
E3     1        s     d                    great
E3     4        q     d                    light,
rest   2        e
E3     2        e     d                    have
measure 28
F#3    2        e     d  [                 seen_
D3     2        e     d  ]                 _
B2     2        e     u                    a
G#3    2        e     d                    great
A3     8-       h     d        -           light,_
measure 29
A3     4        q     d                    _
E3     2        e     d                    a
B3     2        e     d                    great
C#4    6        q.    d                    light,_
D4     2        e     d                    _
measure 30
E4     2        e     d  [                 _
D4     1        s     d  =[                _
C#4    1        s     d  ]]                _
B3     1        s     d  [[                _
A3     1        s     d  ==                _
G#3    1        s     d  ==                _
F#3    1        s     d  ]]                _
E3     2        e     d  [                 _
G#3    2        e     d  =                 _
A3     2        e     d  ]                 _
D4     2        e     d                    have
measure 31
C#4    4        q     d                    seen
B3     2        e     d                    a
A3     2        e     d                    great
A3     8        h     d                    light.
measure 32
rest  16
measure 33
rest  16
measure 34
rest   8        h
rest   4        q
rest   2        e
C#3    2        e     u                    And
measure 35
F#3    2        e     d  [                 they_
E#3    2        e     d  ]                 _
F#3    2        e     d  [                 that_
E#3    2        e     d  ]                 _
F#3    2        e     d  [                 dwell,_
G#3    2        e     d  =                 _
A3     2        e     d  ]                 _
E#3    2        e     d                    that
measure 36
F#3    2        e     d  [                 dwell_
D3     2        e     d  ]                 _
C#3    2        e     u                    in
B#2    2        e     u                    the
C#3    2        e     u  [                 land_
A#2    2        e     u  ]                 _
B2     2        e     u                    of
G#2    2        e     u                    the
measure 37
A2     2        e     u  [      +          sha-
D3     2        e     u  =                 -
C#3    2        e     u  =                 -
F#3    2        e     u  ]                 -
E#3    2        e     d  [                 -
B3     2        e     d  =                 -
A3     2        e     d  =                 -
D4     2        e     d  ]                 -
measure 38
C#4    2        e     d  [                 -
E#3    2        e     d  ]                 -
F#3    2        e     d                    dow
D3     2        e     u                    of
C#3    8-       h     u        -           death,_
measure 39
C#3   16        w     u                    _
measure 40
rest   8        h
rest   4        q
rest   2        e
C#3    2        e     u                    and
measure 41
D3     2        e     u  [                 they_
A#2    2        e     u  =                 _
B2     2        e     u  ]                 _
D#3    2        e     u                    that
E3     2        e     u  [                 dwell,_
B#2    2        e     u  =                 _
C#3    2        e     u  ]                 _
E#3    2        e     d                    that
measure 42
F#3    2        e     u  [                 dwell_
C#3    2        e     u  ]                 _
B2     2        e     u         +          in
G#3    2        e     d                    the
A3     2        e     d  [                 land,_
E#3    2        e     d  =                 _
F#3    2        e     d  ]                 _
A#3    2        e     d                    that
measure 43
B3     2        e     d  [                 dwell_
F#3    2        e     d  ]                 _
E3     2        e     d         +          in
C#4    2        e     d                    the
D4     2        e     d  [                 land_
A#3    2        e     d  ]                 _
B3     2        e     d                    of
D3     2        e     u                    the
measure 44
G3     4        q     d                    sha-
G3     3        e.    d                    dow
F#3    1        s     d                    of
F#3    8-       h     d        -           death,_
measure 45
F#3   16        w     d                    _
measure 46
rest   8        h
rest   4        q
rest   2        e
A3     2        e     d                    up-
measure 47
B3     2        e     d  [                 on_
G3     2        e     d  ]                 _
E3     2        e     d  [                 them_
C#4    2        e     d  ]                 _
D4     2        e     d                    hath
C#4    1        s     d  [[                the_
B3     1        s     d  ]]                _
A3     2        e     d  [                 light_
G3     2        e     d  ]                 _
measure 48
F#3    4        q     d         (          shi-
E3     3        e.    d  [      )          -
D3     1        s     d  ]\                -
D3     4        q     d                    ned,
rest   4        q
measure 49
rest   8        h
rest   4        q
rest   2        e
F#3    2        e     d                    and
measure 50
B3     2        e     d  [                 they_
A#3    2        e     d  ]                 _
B3     2        e     d  [                 that_
A#3    2        e     d  ]                 _
B3     2        e     d  [                 dwell,_
C#4    2        e     d  =                 _
D4     2        e     d  ]                 _
A#3    2        e     d                    that
measure 51
B3     2        e     d  [                 dwell_
G3     2        e     d  ]                 _
F#3    2        e     d                    in
E#3    2        e     d                    the
F#3    2        e     d  [                 land_
D#3    2        e     d  ]                 _
E3     2        e     d                    of
C#3    2        e     u                    the
measure 52
D3     2        e     u  [      +          sha-
B2     2        e     u  =                 -
A#2    2        e     u  =                 -
B2     2        e     u  ]                 -
E3     2        e     d  [                 -
D3     2        e     d  =                 -
G3     2        e     d  =                 -
F#3    2        e     d  ]                 -
measure 53
E3     4        q     d                    -
E3     3        e.    d                    dow
F#3    1        s     d                    of
F#3    8        h     d                    death,
measure 54
rest   8        h
rest   4        q
rest   2        e
F#3    2        e     d                    up-
measure 55
G3     2        e     d  [                 on_
E3     2        e     d  ]                 _
C#3    2        e     d  [                 them_
A#3    2        e     d  ]                 _
B3     6        q.    d                    hath
A3     2        e     d                    the
measure 56
G3     2        e     d  [                 light_
E3     2        e     d  =                 _
F#3    2        e     d  =                 _
D#3    2        e     d  ]                 _
E3     2        e     u  [                 _
C#3    2        e     u  =                 _
D3     2        e     u  =                 _
B2     2        e     u  ]                 _
measure 57
F#3    8        h     d                    shi-
B2     4        q     u                    ned,
rest   2        e
D4     2        e     d                    up-
measure 58
C#4    2        e     d  [                 on_
A#3    2        e     d  ]                 _
B3     2        e     d  [                 them_
G3     2        e     d  ]                 _
F#3    2        e     d                    hath
A#3    2        e     d                    the
B3     2        e     d  [                 light_
E3     2        e     d  ]                 _
measure 59
F#3    8        h     d                    shi-
B2     4        q     u                    ned.
rest   4        q
measure 60
rest  16
measure 61
rest  16
measure 62
rest  16
measure 63
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-12/4} [KHM:224382889]
TIMESTAMP: DEC/26/2001 [md5sum:3651c258654a5f502cb72f18c3fa37f4]
04/07/90 E. Correia
WK#:56        MV#:1,12
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
0 19
Group memberships: score
score: part 3 of 3
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:1/1   C:22   D:Larghetto
F#3    1        e     d
measure 1
B3     1        e     d  [      (
A#3    1        e     d  =      )
B3     1        e     d  =      (
A#3    1        e     d  ]      )
B3     1        e     d  [      (
C#4    1        e     d  =
D4     1        e     d  =      )
A#3    1        e     d  ]      i
measure 2
B3     1        e     d  [      i
G3     1        e     d  =      (
F#3    1        e     d  =
E#3    1        e     d  ]      )
F#3    1        e     d  [      (
D#3    1        e     d  =      )
E3     1        e     d  =      i
C#3    1        e     d  ]      i
measure 3
D3     1        e     u  [      +i
B2     1        e     u  =      (
A#2    1        e     u  =
B2     1        e     u  ]      )
G3     1        e     d  [
E3     1        e     d  =
A#3    1        e     d  =
B3     1        e     d  ]
measure 4
F#3    3        q.    d
F#3    1        e     d
B2     2        q     u
rest   1        e
F#3    1        e     d         p
measure 5
B3     1        e     d  [      (
A#3    1        e     d  =      )
B3     1        e     d  =      (
A#3    1        e     d  ]      )
B3     1        e     d  [      (
C#4    1        e     d  =
D4     1        e     d  =      )
A#3    1        e     d  ]      i
measure 6
B3     1        e     d  [      i
G3     1        e     d  =      (
F#3    1        e     d  =
E#3    1        e     d  ]      )
F#3    1        e     d  [      (
D#3    1        e     d  =      )
E3     1        e     d  =      i
C#3    1        e     d  ]      i
measure 7
D3     1        e     u  [      +i
B2     1        e     u  =      (
A#2    1        e     u  =
B2     1        e     u  ]      )
E3     1        e     d  [
D3     1        e     d  =
G3     1        e     d  =
F#3    1        e     d  ]
measure 8
G2     4        h     u
F#2    2        q     u
rest   2        q
measure 9
rest   4        h
rest   2        q
rest   1        e
F#3    1        e     d
measure 10
G3     1        e     d  [      (
D#3    1        e     d  =
E3     1        e     d  =      )
G#3    1        e     d  ]      i
A3     1        e     d  [      (
E#3    1        e     d  =
F#3    1        e     d  =      )
A#3    1        e     d  ]      i
measure 11
B3     2        q     d
C#4    1        e     d  [
D4     1        e     d  ]
F#3    2        q     d
F#3    1        e     d  [
A3     1        e     d  ]      +
measure 12
B3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  =
C#4    1        e     d  ]
D4     1        e     d  [
D3     1        e     d  =
F#3    1        e     d  =
A3     1        e     d  ]
measure 13
B3     1        e     d  [
G3     1        e     d  =
E3     1        e     d  =
C#4    1        e     d  ]
D4     2        q     d
rest   1        e
D3     1        e     d
measure 14
G3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  =
F#3    1        e     d  ]
G3     1        e     d  [
A3     1        e     d  =
B3     1        e     d  =
B2     1        e     d  ]
measure 15
C3     1        e     u  [
B2     1        e     u  =
C3     1        e     u  =
A2     1        e     u  ]
B2     1        e     u  [
A2     1        e     u  =
B2     1        e     u  =
F#2    1        e     u  ]
measure 16
G2     1        e     u  [
F#2    1        e     u  =
G2     1        e     u  =
A2     1        e     u  ]
B2     1        e     u  [
A2     1        e     u  =
B2     1        e     u  =
C3     1        e     u  ]
measure 17
D3     2        q     u
D2     2        q     u
G2     2        q     u
rest   1        e
B2     1        e     u         f
measure 18
C3     2        q     u
D3     2        q     u
E3     2        q     d
F#3    2        q     d
measure 19
G3     1        e     d  [
E3     1        e     d  =
C3     1        e     d  =
D3     1        e     d  ]
G2     2        q     u
rest   1        e
B2     1        e     u         p
measure 20
E3     1        e     d  [      (
D#3    1        e     d  =      )
E3     1        e     d  =      (
D#3    1        e     d  ]      )
E3     1        e     d  [      (
F#3    1        e     d  =
G3     1        e     d  =      )
D#3    1        e     d  ]      i
measure 21
E3     1        e     d  [      i
C4     1        e     d  =      (
B3     1        e     d  =
A#3    1        e     d  ]      )
B3     1        e     d  [      (
G#3    1        e     d  =      )
A3     1        e     d  =      i
F#3    1        e     d  ]      i
measure 22
G3     1        e     d  [      +i
E3     1        e     d  =      (
D#3    1        e     d  =
E3     1        e     d  ]      )
C3     1        e     u  [
A2     1        e     u  =
B2     1        e     u  =
G2     1        e     u  ]
measure 23
A2     4        h     u
B2     2        q     u
rest   1        e
B3     1        e     d
measure 24
C4     1        e     d  [      (
G#3    1        e     d  =
A3     1        e     d  =      )
C#4    1        e     d  ]
D4     1        e     d  [      (
A#3    1        e     d  =
B3     1        e     d  =      )
D#4    1        e     d  ]
measure 25
E4     1        e     d  [
B3     1        e     d  =
C4     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  =
D#3    1        e     d  ]
measure 26
E3     1        e     u  [
C3     1        e     u  =
B2     1        e     u  =
A#2    1        e     u  ]
B2     1        e     u  [
D#3    1        e     u  =
E3     1        e     u  =
A2     1        e     u  ]
measure 27
B2     2        q     u
B2     2        q     u
E2     2        q     u
rest   1        e
E3     1        e     d
measure 28
F#3    1        e     d  [
D3     1        e     d  =
B2     1        e     d  =
G#3    1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C#4    1        e     d  =
C#3    1        e     d  ]
measure 29
D3     1        e     u  [
B2     1        e     u  =
E3     1        e     u  =
E2     1        e     u  ]
A2     3        q.    u
B2     1        e     u
measure 30
C#3    1        e     u  [
A2     1        e     u  =
D3     1        e     u  =
B2     1        e     u  ]
C#3    1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
D3     1        e     d  ]
measure 31
E3     1        e     u  [
D3     1        e     u  =
E3     1        e     u  =
E2     1        e     u  ]
A2     2        q     u
rest   1        e
C#3    1        e     u         f
measure 32
D3     2        q     u
E3     2        q     d
F#3    2        q     d
G#3    2        q     d
measure 33
A3     1        e     d  [
F#3    1        e     d  =
D3     1        e     d  =
E3     1        e     d  ]
A2     2        q     u
rest   2        q
measure 34
rest   4        h
rest   2        q
rest   1        e
C#3    1        e     u         &p
measure 35
F#3    1        e     d  [      (
E#3    1        e     d  =      )
F#3    1        e     d  =      (
E#3    1        e     d  ]      )
F#3    1        e     d  [      (
G#3    1        e     d  =
A3     1        e     d  =      )
E#3    1        e     d  ]      i
measure 36
F#3    1        e     d  [      i
D3     1        e     d  =      (
C#3    1        e     d  =
B#2    1        e     d  ]      )
C#3    1        e     u  [      (
A#2    1        e     u  =      )
B2     1        e     u  =      i
G#2    1        e     u  ]      i
measure 37
A2     1        e     u  [      +
D3     1        e     u  =
C#3    1        e     u  =
F#3    1        e     u  ]
E#3    1        e     d  [
B3     1        e     d  =
A3     1        e     d  =
D4     1        e     d  ]
measure 38
C#4    1        e     d  [
E#3    1        e     d  =
F#3    1        e     d  =
D3     1        e     d  ]
C#3    4-       h     u        -
measure 39
C#3    8-       w     u        -
measure 40
C#3    4-       h     u        -
C#3    2        q     u
rest   1        e
C#3    1        e     u
measure 41
D3     1        e     u  [      (
A#2    1        e     u  =
B2     1        e     u  =      )
D#3    1        e     u  ]
E3     1        e     d  [      (
B#2    1        e     d  =
C#3    1        e     d  =      )
E#3    1        e     d  ]
measure 42
F#3    1        e     d  [      &(
C#3    1        e     d  =
B2     1        e     d  =      &)
G#3    1        e     d  ]
A3     1        e     d  [      &(
E#3    1        e     d  =
F#3    1        e     d  =      &)
A#3    1        e     d  ]
measure 43
B3     1        e     d  [
F#3    1        e     d  =
E3     1        e     d  =      +
C#4    1        e     d  ]
D4     1        e     d  [      (
A#3    1        e     d  =
B3     1        e     d  =      )
D3     1        e     d  ]
measure 44
G2     4        h     u
F#2    4-       h     u        -
measure 45
F#2    8-       w     u        -
measure 46
F#2    4-       h     u        -
F#2    1        e     u  [
F#3    1        e     u  =
D3     1        e     u  =
F#3    1        e     u  ]
measure 47
G3     1        e     d  [
E3     1        e     d  =
A2     1        e     d  =
G2     1        e     d  ]
F#2    1        e     u  [
E2     1        e     u  =
F#2    1        e     u  =
G2     1        e     u  ]
measure 48
A2     1        e     u  [
G2     1        e     u  ]
A2     2        q     u
D3     2        q     u
rest   1        e
D3     1        e     u         f
measure 49
D4     2        q     d
C#4    2        q     d
B3     2        q     d
rest   1        e
F#3    1        e     d         &p
measure 50
B3     1        e     d  [      (
A#3    1        e     d  =      )
B3     1        e     d  =      (
A#3    1        e     d  ]      )
B3     1        e     d  [      (
C#4    1        e     d  =
D4     1        e     d  =      )
A#3    1        e     d  ]      i
measure 51
B3     1        e     d  [      i
G3     1        e     d  =      (
F#3    1        e     d  =
E#3    1        e     d  ]      )
F#3    1        e     d  [      (
D#3    1        e     d  =      )
E3     1        e     d  =      i
C#3    1        e     d  ]      i
measure 52
D3     1        e     u  [      &i
B2     1        e     u  =      (
A#2    1        e     u  =
B2     1        e     u  ]      )
E3     1        e     d  [
D3     1        e     d  =
G3     1        e     d  =
F#3    1        e     d  ]
measure 53
G2     4        h     u
F#2    4-       h     u        -
measure 54
F#2    4-       h     u        -
F#2    2        q     u
rest   1        e
F#3    1        e     d
measure 55
G3     1        e     d  [
E3     1        e     d  =
C#3    1        e     d  =
A#3    1        e     d  ]
B3     3        q.    d
A3     1        e     d
measure 56
G3     1        e     d  [
E3     1        e     d  =
F#3    1        e     d  =
D#3    1        e     d  ]
E3     1        e     u  [
C#3    1        e     u  =
D3     1        e     u  =
B2     1        e     u  ]
measure 57
F#3    4        h     d
B2     2        q     u
rest   1        e
D4     1        e     d
measure 58
C#4    1        e     d  [
A#3    1        e     d  =
B3     1        e     d  =
G3     1        e     d  ]
F#3    1        e     d  [
A#3    1        e     d  =
B3     1        e     d  =
E3     1        e     d  ]
measure 59
F#3    4        h     d
B2     1        e     d  [
B3     1        e     d  =      &f
F#3    1        e     d  =
D3     1        e     d  ]
measure 60
B2     2        q     u
rest   1        e
C#4    1        e     d
D4     1        e     d  [
A#3    1        e     d  =
B3     1        e     d  =
F#3    1        e     d  ]
measure 61
B2     3        q.    u
C#3    1        e     u
A#2    3        q.    u
F#3    1        e     d
measure 62
B3     1        e     d  [
F#3    1        e     d  =
G3     1        e     d  =
E3     1        e     d  ]
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  =
E3     1        e     d  ]
measure 63
F#3    2        q     d
F#2    2        q     u
B2     2        q     u         F
rest   2        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
