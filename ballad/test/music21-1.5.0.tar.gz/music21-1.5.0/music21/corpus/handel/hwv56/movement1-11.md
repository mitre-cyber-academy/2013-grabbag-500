&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-11/1} [KHM:617210105]
TIMESTAMP: DEC/26/2001 [md5sum:15a807ddb9516a902dc8b3635d6a09c8]
04/07/90 E. Correia
WK#:56        MV#:1,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
0 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:1/1   C:4   D:Andante larghetto
B3     2        s     u  [[     (&pp
C#4    2        s     u  ==     )
B3     2        s     u  ==     (
C#4    2        s     u  ]]     )
B3     2        s     u  [[     (
C#4    2        s     u  ==     )
B3     2        s     u  ==     (
C#4    2        s     u  ]]     )
D4     2        s     u  [[     (
E4     2        s     u  ==     )
D4     2        s     u  ==     (
E4     2        s     u  ]]     )
D4     2        s     u  [[     (
E4     2        s     u  ==     )
D4     2        s     u  ==     (
E4     2        s     u  ]]     )
measure 2
F#4    2        s     u  [[     (
G4     2        s     u  ==     )
F#4    2        s     u  ==     (
G4     2        s     u  ]]     )
F#4    2        s     u  [[     (
G4     2        s     u  ==     )
F#4    2        s     u  ==     (
G4     2        s     u  ]]     )
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
measure 3
B3     4        e     u  [
E#4    2        s     u  =[     (
F#4    2        s     u  ]]     )
E#4    2        s     u  [[     (
F#4    2        s     u  ==     )
E#4    2        s     u  ==     (
F#4    2        s     u  ]]     )
E#4    2        s     u  [[
F#4    2        s     u  ==
E#4    2        s     u  ==
F#4    2        s     u  ]]
E#4    2        s     u  [[
F#4    2        s     u  ==
E#4    2        s     u  ==
F#4    2        s     u  ]]
measure 4
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
measure 5
F#4    4        e     u  [
E4     3        s.    u  =[
D4     1        t     u  ]]\
C#4    6        e.    u  [      &t
B3     2        s     u  ]\
B3     8        q     u
rest   8        q
measure 6
B3     2        s     u  [[     p(
C#4    2        s     u  ==      )
B3     2        s     u  ==      (
C#4    2        s     u  ]]      )
B3     2        s     u  [[      (
C#4    2        s     u  ==      )
B3     2        s     u  ==      (
C#4    2        s     u  ]]      )
D4     2        s     u  [[      (
E4     2        s     u  ==      )
D4     2        s     u  ==      (
E4     2        s     u  ]]      )
D4     2        s     u  [[      (
E4     2        s     u  ==      )
D4     2        s     u  ==      (
E4     2        s     u  ]]      )
measure 7
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
measure 8
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ]]
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ]]
C5     2        s     d  [[     (
B4     2        s     d  ==     )
C5     2        s     d  ==     (
B4     2        s     d  ]]     )
C5     2        s     d  [[     (
B4     2        s     d  ==     )
C5     2        s     d  ==     (
B4     2        s     d  ]]     )
measure 9
B4     2        s     u  [[
A4     2        s     u  ==
B4     2        s     u  ==
A4     2        s     u  ]]
B4     2        s     u  [[
A4     2        s     u  ==
B4     2        s     u  ==
A4     2        s     u  ]]
B4     2        s     d  [[
C#5    2        s     d  ==     +
B4     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
C#5    2        s     d  ==
B4     2        s     d  ==
C#5    2        s     d  ]]
measure 10
G#4    2        s     u  [[
A#4    2        s     u  ==
G#4    2        s     u  ==
A#4    2        s     u  ]]
G#4    2        s     u  [[
A#4    2        s     u  ==
G#4    2        s     u  ==
A#4    2        s     u  ]]
F#4    4        e     u  [
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]
measure 11
F#4    4        e     u  [
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]
G4     4        e     u  [      +
G4     4        e     u  =
G4     4        e     u  =
E4     4        e     u  ]
measure 12
F#4    4        e     u  [
F#4    4        e     u  =
D5     4        e     u  =
D5     4        e     u  ]
D5     4        e     d  [
D5     4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]
measure 13
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
D5     4        e     d  [
D5     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
measure 14
F#5    4        e     d  [
F#5    4        e     d  =
F#5    4        e     d  =
F#5    4        e     d  ]
F#5    4        e     d  [
F#5    4        e     d  =
F#5    4        e     d  =
F#5    4        e     d  ]
measure 15
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
measure 16
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
measure 17
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
C#5    4        e     d  [
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]
measure 18
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  =
D5     4        e     d  ]
measure 19
C#5    8        q     d
B4     6        e.    u  [      &t
A4     2        s     u  ]\
A4     4        e     u  [      (
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]      )
measure 20
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
C#5    4        e     d  [      (
B4     4        e     d  =      )
B4     4        e     d  =      (
C#5    4        e     d  ]      )
measure 21
D5     4        e     d  [      (
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]      )
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
measure 22
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
B4     8        q     u
F#5    8        q     d
measure 23
rest   8        q
E#5    8        q     d
F#5   16        h     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-11/2} [KHM:617210105]
TIMESTAMP: DEC/26/2001 [md5sum:7dc965bd03bf96c2092a49f98c175aed]
04/07/90 E. Correia
WK#:56        MV#:1,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
0 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:1/1   C:4   D:Andante larghetto
rest  16        h
B3     2        s     u  [[     (&pp
C#4    2        s     u  ==     )
B3     2        s     u  ==     (
C#4    2        s     u  ]]     )
B3     2        s     u  [[     (
C#4    2        s     u  ==     )
B3     2        s     u  ==     (
C#4    2        s     u  ]]     )
measure 2
D#4    2        s     u  [[
E4     2        s     u  ==
D#4    2        s     u  ==
E4     2        s     u  ]]
D#4    2        s     u  [[
E4     2        s     u  ==
D#4    2        s     u  ==
E4     2        s     u  ]]
D#4    2        s     u  [[
E4     2        s     u  ==
D#4    2        s     u  ==
E4     2        s     u  ]]
D#4    2        s     u  [[
E4     2        s     u  ==
D#4    2        s     u  ==
F#4    2        s     u  ]]
measure 3
E#4    2        s     u  [[
F#4    2        s     u  =]
B3     4        e     u  ]
B3     4        e     u  [
B3     4        e     u  ]
G#3    4        e     u  [
G#3    4        e     u  =
G#3    4        e     u  =
G#3    4        e     u  ]
measure 4
F#4    2        s     u  [[     (
E4     2        s     u  ==     )
F#4    2        s     u  ==     (
E4     2        s     u  ]]     )
F#4    2        s     u  [[     (
E4     2        s     u  ==     )
F#4    2        s     u  ==     (
E4     2        s     u  ]]     )
F#4    2        s     u  [[     (
E4     2        s     u  ==     )
F#4    2        s     u  ==     (
E4     2        s     u  ]]     )
F#4    2        s     u  [[     (
E4     2        s     u  ==     )
F#4    2        s     u  ==     (
E4     2        s     u  ]]     )
measure 5
D4     4        e     u  [
C#4    3        s.    u  =[
B3     1        t     u  ]]\
A#3    6        e.    u  [
B3     2        s     u  ]\
B3     8        q     u
rest   8        q
measure 6
rest  16        h
B3     2        s     u  [[     p(
C#4    2        s     u  ==      )
B3     2        s     u  ==      (
C#4    2        s     u  ]]      )
B3     2        s     u  [[
C#4    2        s     u  ==
B3     2        s     u  ==
C#4    2        s     u  ]]
measure 7
D4     2        s     u  [[
E4     2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[
E4     2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[
E4     2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[
E4     2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
measure 8
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ]]
A4     2        s     u  [[
B4     2        s     u  ==
A4     2        s     u  ==
B4     2        s     u  ]]
measure 9
G4     2        s     u  [[
A4     2        s     u  ==
G4     2        s     u  ==
A4     2        s     u  ]]
G4     2        s     u  [[
A4     2        s     u  ==
G4     2        s     u  ==
A4     2        s     u  ]]
G#4    2        s     u  [[
A4     2        s     u  ==
G#4    2        s     u  ==
A4     2        s     u  ]]
G#4    2        s     u  [[
A4     2        s     u  ==
G#4    2        s     u  ==
A4     2        s     u  ]]
measure 10
B4     2        s     d  [[
C#5    2        s     d  ==
B4     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
C#5    2        s     d  ==
B4     2        s     d  ==
C#5    2        s     d  ]]
A#4    4        e     u  [
A#4    4        e     u  =
A#4    4        e     u  =
A#4    4        e     u  ]
measure 11
A4     4        e     u  [      +
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
A4     4        e     d  ]
measure 12
A4     4        e     u  [
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 13
A3     4        e     u  [
A3     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 14
F#4    4        e     u  [
F#4    4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
A4     4        e     u  [
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
measure 15
A4     4        e     u  [
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
A4     4        e     u  [
G#4    2        s     u  =[
F#4    2        s     u  ]]
G#4    4        e     u  [
G#4    4        e     u  ]
measure 16
C#5    4        e     d  [
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]
A4     4        e     u  [
A4     4        e     u  =
B4     4        e     u  =
B4     4        e     u  ]
measure 17
A4     4        e     u  [
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
A4     4        e     u  [
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
measure 18
B4     4        e     u  [
B4     4        e     u  =
B4     4        e     u  =
B4     4        e     u  ]
B4     4        e     u  [
B4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
measure 19
A4     8        q     u
G#4    6        e.    u  [
A4     2        s     u  ]\
E4     4        e     u  [      (
E4     4        e     u  =
E4     4        e     u  =
E4     4        e     u  ]      )
measure 20
A4     4        e     u  [      (
A4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]      )
F#4    4        e     u  [      (
G#4    4        e     u  =      )
G#4    4        e     u  =      (
F#4    4        e     u  ]      )
measure 21
F#4    4        e     u  [      (
F#4    4        e     u  =      )
G#4    4        e     u  =      (
G#4    4        e     u  ]      )
G#4    4        e     u  [      (
G#4    4        e     u  =
G#4    4        e     u  =
G#4    4        e     u  ]      )
measure 22
F#4    4        e     u  [      (
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]      )
F#4    8        q     u
D5     8        q     d
measure 23
rest   8        q
G#4    8        q     u
A#4   16        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-11/3} [KHM:617210105]
TIMESTAMP: DEC/26/2001 [md5sum:4e37d17552498d76287e228d47dec108]
04/07/90 E. Correia
WK#:56        MV#:1,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
0 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Andante larghetto
B3     1        s     u  [[     (&pp
A#3    1        s     u  ==     )
B3     1        s     u  ==     (
A#3    1        s     u  ]]     )
B3     1        s     u  [[     (
A#3    1        s     u  ==     )
B3     1        s     u  ==     (
A#3    1        s     u  ]]     )
B3     1        s     u  [[     (
C#4    1        s     u  ==     )
B3     1        s     u  ==     (
C#4    1        s     u  ]]     )
B3     1        s     u  [[     (
C#4    1        s     u  ==     )
B3     1        s     u  ==     (
C#4    1        s     u  ]]     )
measure 2
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
B3     4        q     u
rest   4        q
measure 3
B3     2        e     u  [
G#3    2        e     u  =
G#3    2        e     u  =
G#3    2        e     u  ]
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 4
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
C#4    4        q     u
rest   4        q
measure 5
B3     2        e     u  [
C#4    2        e     u  =
F#3    2        e     u  =
F#3    2        e     u  ]
F#3    4        q     u
rest   4        q
measure 6
rest   8        h
B3     2        e     u  [      &p
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 7
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
measure 8
D#4    2        e     d  [
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]
F#4    2        e     d  [
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
measure 9
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 10
E#4    2        e     d  [
E#4    2        e     d  =
E#4    2        e     d  =
E#4    2        e     d  ]
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
measure 11
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
measure 12
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
B3     2        e     u  [
B3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 13
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
B3     2        e     d  [
B4     2        e     d  =
C#4    2        e     d  =
C#4    2        e     d  ]
measure 14
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 15
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
F#4    2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 16
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
G#4    2        e     d  =
G#4    2        e     d  ]
measure 17
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 18
F#4    2        e     d  [
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
G#4    2        e     d  [
G#4    2        e     d  =
E4     2        e     d  =
F#4    2        e     d  ]
measure 19
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
measure 20
F#4    2        e     d  [
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
measure 21
B3     2        e     u  [
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]
E#4    2        e     d  [
E#4    2        e     d  =
E#4    2        e     d  =
E#4    2        e     d  ]
measure 22
C#4    2        e     u  [
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]
D4     4        q     d
F#4    4        q     d
measure 23
rest   4        q
C#4    4        q     u
C#4    8        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-11/4} [KHM:617210105]
TIMESTAMP: DEC/26/2001 [md5sum:fec3bd5f8f8871b91509b0a11a4409c6]
04/07/90 E. Correia
WK#:56        MV#:1,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Basso
0 72 B
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Andante larghetto
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest   8        h
rest   4        q
F#3    3        e.    d                    For
F#3    1        s     d                    be-
measure 6
B3     4        q     d                    hold!
rest   4        q
B3     4        q     d                    dark-
F#3    2        e     d                    ness
F#3    2        e     d                    shall
measure 7
D3     4        q     d                    co-
F#3    2        e     d                    ver
F#3    2        e     d                    the
B2     4        q     u                    earth,
rest   4        q
measure 8
rest   4        q
A3     2        e     d                    and
A3     2        e     d                    gross
D#3    4        q     u                    dark-
D#3    2        e     u                    ness
D#3    2        e     u                    the
measure 9
E3     2        e     d                    peo-
E3     6        q.    d                    ple,
rest   4        q
B3     2        e     d                    and
D4     2        e     d                    gross
measure 10
E#3    4        q     d                    dark-
E#3    2        e     d                    ness
E#3    2        e     d                    the
F#3    2        e     d                    peo-
F#3    6        q.    d                    ple:
measure 11
rest   4        q
A3     2        e     d                    But
B3     2        e     d                    the
G3     4        q     d                    Lord
G3     2        e     d                    shall
A3     2        e     d                    a-
measure 12
F#3    4-       q     d        -           rise_
F#3    1        s     d  [[                _
E3     1        s     d  ==                _
F#3    1        s     d  ==                _
D3     1        s     d  ]]                _
G3     4-       q     d        -           _
G3     1        s     d  [[                _
F#3    1        s     d  ==                _
G3     1        s     d  ==                _
E3     1        s     d  ]]                _
measure 13
A3     4-       q     d        -           _
A3     1        s     d  [[                _
G3     1        s     d  ==                _
A3     1        s     d  ==                _
F#3    1        s     d  ]]                _
B3     1        s     d  [[                _
A3     1        s     d  ==                _
B3     1        s     d  ==                _
G3     1        s     d  =]                _
C#4    3        e.    d  ]                 _
C#4    1        s     d                    up-
measure 14
D4     4        q     d                    on
D3     4        q     u                    thee,
rest   4        q
F#3    2        e     d                    and
D3     2        e     u                    His
measure 15
A3     8-       h     d        -           glo-
A3     1        s     d  [[                -
C#4    1        s     d  ==                -
B3     1        s     d  ==                -
A3     1        s     d  ]]                -
G#3    1        s     d  [[                -
F#3    1        s     d  ==                -
E3     1        s     d  ==                -
D3     1        s     d  =]                -
measure 16
C#3    2        e     d  ]                 -
A2     2        e     u                    ry
E3     2        e     d                    shall
E3     2        e     d                    be
F#3    4        q     d                    seen
G#3    4        q     d                    up-
measure 17
A3     4        q     d                    on
E3     4        q     d                    thee,
rest   4        q
A3     2        e     d                    and
C#4    2        e     d                    His
measure 18
B3     2        e     d  [                 glo-
D4     1        s     d  =[                -
C#4    1        s     d  ]]                -
B3     1        s     d  [[                -
A3     1        s     d  ==                -
G#3    1        s     d  ==                -
F#3    1        s     d  =]                -
E3     2        e     d  ]                 -
G#3    2        e     d                    ry
A3     2        e     d                    shall
D3     2        e     u                    be
measure 19
E3     6        q.    d                    seen
E3     2        e     d                    up-
A2     4        q     u                    on
A2     4        q     u                    thee.
measure 20
rest   4        q
A3     2        e     d                    And
A3     2        e     d                    the
A3     2        e     d                    Gen-
G#3    4        q     d                    tiles
A3     2        e     d                    shall
measure 21
B3     4        q     d                    come
G#3    2        e     d                    to
F#3    2        e     d                    thy
E#3    4        q     d                    light,
rest   2        e
C#3    2        e     u                    and
measure 22
C#4    4        q     d                    kings
A3     2        e     d                    to
F#3    2        e     d                    the
D3     4        q     u                    bright-
B2     4        q     u                    ness
measure 23
C#3    6        q.    u                    of
C#3    2        e     u                    thy
F#3    4        q     d                    ri-
F#3    4        q     d                    sing.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-11/5} [KHM:617210105]
TIMESTAMP: DEC/26/2001 [md5sum:e1051dbd1af00fec67b9c54f6ff61f71]
04/07/90 E. Correia
WK#:56        MV#:1,11
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
0 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Andante larghetto
B3     1        s     d  [[     (&pp
A#3    1        s     d  ==     )
B3     1        s     d  ==     (
A#3    1        s     d  ]]     )
B3     1        s     d  [[     (
A#3    1        s     d  ==     )
B3     1        s     d  ==     (
A#3    1        s     d  ]]     )
B3     2        e     d  [
B2     2        e     d  ]
rest   4        q
measure 2
f2                  4+ 2
A3     2        e     u  [      +
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]
A2     4        q     u
rest   4        q
measure 3
f1              6+
G#2    2        e     u  [
G#2    2        e     u  =
G#2    2        e     u  =
G#2    2        e     u  ]
G#2    4        q     u
rest   4        q
measure 4
A#2    2        e     u  [
A#2    2        e     u  =
A#2    2        e     u  =
A#2    2        e     u  ]
A#2    4        q     u
rest   4        q
measure 5
B2     2        e     u  [
E3     2        e     u  =
F#3    2        e     u  =
F#2    2        e     u  ]
B2     4        q     u
rest   4        q
measure 6
B3     1        s     d  [[     p(
A#3    1        s     d  ==      )
B3     1        s     d  ==      (
A#3    1        s     d  ]]      )
B3     1        s     d  [[      (
A#3    1        s     d  ==      )
B3     1        s     d  ==      (
A#3    1        s     d  ]]      )
B3     2        e     d  [
B2     2        e     d  =
B2     2        e     d  =
B2     2        e     d  ]
measure 7
B2     2        e     u  [
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]
B2     2        e     u  [
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]
measure 8
A2     2        e     d  [
A2     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
D#3    2        e     u  [
D#3    2        e     u  =
D#3    2        e     u  =
D#3    2        e     u  ]
measure 9
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
f2              4+ 2
D3     2        e     u  [      +
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
measure 10
f1              #
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 11
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
B2     2        e     u  [
B2     2        e     u  =
B2     2        e     u  =
C#3    2        e     u  ]
measure 12
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 13
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 14
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
measure 15
f1              6
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
f1              7
B2     2        e     u  [
B2     2        e     u  =
f1              6+
B2     2        e     u  =
B2     2        e     u  ]
measure 16
A2     2        e     u  [
A2     2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
D3     2        e     u  [
D3     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]
measure 17
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
A2     2        e     u  [
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]
measure 18
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
D3     2        e     u  [
D3     2        e     u  =
C#3    2        e     u  =
D3     2        e     u  ]
measure 19
f2              6 4
E3     2        e     d  [
E3     2        e     d  =
f2              5 #
E3     2        e     d  =
E3     2        e     d  ]
A2     2        e     u  [
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]
measure 20
F#2    2        e     u  [
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  ]
f1              7
B2     2        e     u  [
B2     2        e     u  =
f1              6+
B2     2        e     u  =
B2     2        e     u  ]
measure 21
B2     2        e     u  [
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]
f1              #
C#3    2        e     u  [
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]
measure 22
f1              6
A2     2        e     u  [
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]
D3     4        q     u
B2     4        q     u
measure 23
C#3    8        h     u
f1              #
F#2    8        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
