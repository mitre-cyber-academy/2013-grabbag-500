&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/1} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:fbdf847cc7f583d888cbce7c0a0d4f98]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest   4        q
F5     2        e     d  [
F5     1        s     d  =[
F5     1        s     d  ]]
G5     2        e     d  [
G5     1        s     d  =[
G5     1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
measure 4
F5     2        e     d  [
F5     2        e     d  ]
Bf4    2        e     d  [
Bf4    1        s     d  =[
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
measure 5
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
measure 6
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     2        e     d  [
G5     1        s     d  =[
F5     1        s     d  ]]
Ef5    2        e     d  [
D5     2        e     d  ]
measure 7
C5     4        q     d
C6     2        e     d  [
C6     1        s     d  =[
C6     1        s     d  ]]
D6     2        e     d  [
D6     1        s     d  =[
D6     1        s     d  ]]
D6     2        e     d  [
D6     2        e     d  ]
measure 8
C6     2        e     d  [
C6     2        e     d  ]
C6     2        e     d  [
C6     1        s     d  =[
C6     1        s     d  ]]
D6     2        e     d  [
D6     1        s     d  =[
D6     1        s     d  ]]
D6     2        e     d  [
D6     2        e     d  ]
measure 9
C6     2        e     d  [
C6     2        e     d  ]
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
A5     4        q     d
A5     2        e     d  [
A5     2        e     d  ]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
Bf5    1        s     d  ==
A5     1        s     d  ==
Bf5    1        s     d  ]]
measure 12
C6     3        e.    d  [
A4     1        s     u  =\
A4     2        e     u  =
A4     2        e     u  ]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
measure 13
F5     3        e.    d  [
C5     1        s     d  =\
C5     2        e     d  =
C5     2        e     d  ]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 14
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
Bf5    1        s     d  ==
C6     1        s     d  ]]
A5     2        e     d  [
Bf5    2        e     d  ]
G5     4        q     d         &t
measure 15
A5     2        e     d  [
C5     1        s     d  =[
D5     1        s     d  ]]
Ef5    1        s     d  [[     +
D5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
measure 16
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
measure 17
D4     1        s     u  [[
Ef4    1        s     u  ==
D4     1        s     u  ==
Ef4    1        s     u  ]]
F4     1        s     u  [[
F4     1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
measure 18
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
D4     1        s     u  [[
Ef4    1        s     u  ==
D4     1        s     u  ==
Ef4    1        s     u  ]]
F4     1        s     u  [[
F4     1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
measure 19
Bf4    2        e     u  [
F4     2        e     u  ]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
G5     1        s     d  ==
F5     1        s     d  ==
G5     1        s     d  ]]
measure 20
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
F5     1        s     d  ==
Ef5    1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
measure 21
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     2        e     d  [
G5     1        s     d  =[
F5     1        s     d  ]]
Ef5    2        e     d  [
D5     2        e     d  ]
measure 22
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
Ef5    1        s     d  [[
D5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]
D5     2        e     d  [
Bf5    2        e     d  ]
A5     4        q     d         &t
measure 23
Bf5    2        e     d  [
Bf4    2        e     d  ]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 24
Bf5    2        e     d  [
F5     2        e     d  ]
F5     4-       q     d        -
F5     2        e     d  [
Ef5    1        s     d  =[
D5     1        s     d  ]]
C5     4        q     d         t
measure 25
Bf4    4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/2} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:921d7d5592b5c4429f5e22181d122f2d]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest   4        q
D5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
Ef5    2        e     d  [
Ef5    1        s     d  =[
Ef5    1        s     d  ]]
Ef5    2        e     d  [
Ef5    2        e     d  ]
measure 4
D5     2        e     d  [
D5     2        e     d  ]
F4     2        e     u  [
F4     1        s     u  =[
A4     1        s     u  ]]
Bf4    3        e.    u  [
Bf4    1        s     u  =\
Bf4    2        e     u  =
Bf4    2        e     u  ]
measure 5
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     3        e.    d  [
C5     1        s     d  ]\
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Ef5    1        s     d  ]]
measure 6
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ]]
Bf4    2        e     u  [
Bf4    1        s     u  =[
Bf4    1        s     u  ]]
A4     2        e     u  [
Bf4    2        e     u  ]
measure 7
A4     4        q     u
A5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    1        s     d  =[
Bf5    1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 8
A5     2        e     d  [
A5     2        e     d  ]
A5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
Bf5    2        e     d  [
Bf5    1        s     d  =[
Bf5    1        s     d  ]]
Bf5    2        e     d  [
Bf5    2        e     d  ]
measure 9
A5     2        e     d  [
A5     2        e     d  ]
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
C5     4        q     d
C5     2        e     d  [
C5     2        e     d  ]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
C5     1        s     d  ==
Bf4    1        s     d  ]]
measure 12
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F5     3        e.    d  [
C5     1        s     d  =\
C5     2        e     d  =
C5     2        e     d  ]
measure 13
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F5     2        e     u  [
F4     1        s     u  =[
F4     1        s     u  ]]
F4     2        e     u  [
F4     2        e     u  ]
measure 14
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
F5     2        e     d  [
D5     2        e     d  ]
E5     4        q     d
measure 15
F5     2        e     d  [
A4     1        s     d  =[
Bf4    1        s     d  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
C5     1        s     d  ==
A4     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
measure 16
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 17
Bf5    3        e.    d  [
F5     1        s     d  =\
F5     2        e     d  =
F5     2-       e     d  ]     -
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
measure 18
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
measure 19
D4     1        s     u  [[
Ef4    1        s     u  ==
D4     1        s     u  ==
Ef4    1        s     u  ]]
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
G4     1        s     u  ]]
F4     3        e.    u  [
F4     1        s     u  =\
Bf4    2        e     u  =
Bf4    2        e     u  ]
measure 20
F4     1        s     u  [[
G4     1        s     u  ==
F4     1        s     u  ==
G4     1        s     u  ]]
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     3        e.    d  [
C5     1        s     d  ]\
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
Ef5    1        s     d  ]]
measure 21
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     u  [[
A4     1        s     u  ==
Bf4    1        s     u  ==
A4     1        s     u  ]]
Bf4    2        e     u  [
Bf4    1        s     u  =[
Bf4    1        s     u  ]]
A4     2        e     u  [
Bf4    2        e     u  ]
measure 22
A4     1        s     u  [[
Bf4    1        s     u  ==
A4     1        s     u  ==
Bf4    1        s     u  ]]
C5     1        s     d  [[
Bf4    1        s     d  ==
C5     1        s     d  ==
A4     1        s     d  ]]
Bf4    2        e     d  [
G5     2        e     d  ]
C5     4        q     d
measure 23
D5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
Ef5    1        s     d  ]]
F5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
Bf5    2        e     d  [
F5     2        e     d  ]
F5     4-       q     d        -
measure 24
F5     1        s     d  [[
Ef5    1        s     d  ==
D5     1        s     d  ==
C5     1        s     d  ]]
Bf4    1        s     d  [[
C5     1        s     d  ==
Bf4    1        s     d  ==
C5     1        s     d  ]]
A4     2        e     u
Bf4    4        q     d
A4     2        e     u
measure 25
Bf4    4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/3} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:582841ab210e88e3ed1db98a307aa43e]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:13   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest   4        q
Bf4    2        e     d  [
Bf4    1        s     d  =[
Bf4    1        s     d  ]]
Bf4    2        e     d  [
Bf4    1        s     d  =[
Bf4    1        s     d  ]]
Bf4    2        e     d  [
Bf4    2        e     d  ]
measure 4
Bf4    2        e     d  [
Bf4    2        e     d  ]
D4     2        e     d  [
D4     1        s     d  =[
Ef4    1        s     d  ]]
F4     3        e.    d  [
F4     1        s     d  =\
F4     2        e     d  =
F4     2        e     d  ]
measure 5
C4     3        e.    d  [
C4     1        s     d  =\
C4     2        e     d  =
C4     2        e     d  ]
G4     3        e.    d  [
G4     1        s     d  =\
G4     2        e     d  =
G4     2        e     d  ]
measure 6
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
F4     3        e.    d  [
F4     1        s     d  =\
C4     2        e     d  =
F4     2        e     d  ]
measure 7
F4     4        q     d
F4     2        e     d  [
F4     1        s     d  =[
F4     1        s     d  ]]
F4     2        e     d  [
F4     1        s     d  =[
F4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
measure 8
F4     2        e     d  [
F4     2        e     d  ]
F4     2        e     d  [
F4     1        s     d  =[
F4     1        s     d  ]]
F4     2        e     d  [
F4     1        s     d  =[
F4     1        s     d  ]]
F4     2        e     d  [
F4     2        e     d  ]
measure 9
F4     2        e     d  [
F4     2        e     d  ]
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
F4     4        q     d
F4     2        e     d  [
F4     2        e     d  ]
A4     1        s     d  [[
G4     1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ]]
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ]]
measure 12
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ]]
A4     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
Bf4    1        s     d  ]]
C5     2        e     d  [
F4     1        s     d  =[
G4     1        s     d  ]]
A4     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ]]
measure 13
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ]]
A4     1        s     d  [[
Bf4    1        s     d  ==
A4     1        s     d  ==
G4     1        s     d  ]]
C5     2        e     d  [
C4     1        s     d  =[
C4     1        s     d  ]]
C4     2        e     d  [
C4     2        e     d  ]
measure 14
G4     3        e.    d  [
G4     1        s     d  =\
C5     2        e     d  =
C5     2        e     d  ]
F4     2        e     d  [
F4     2        e     d  ]
C5     4        q     d
measure 15
C5     2        e     d  [
C5     1        s     d  =[
Bf4    1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
F4     4        q     d
Bf4    2        e     d  [
Bf4    2        e     d  ]
measure 16
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
F3     3        e.    u  [
F3     1        s     u  =\
F3     2        e     u  =
F4     2        e     u  ]
measure 17
F4     1        s     d  [[
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
Bf4    2        e     d  [
D4     2        e     d  ]
D4     1        s     d  [[
Ef4    1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ]]
measure 18
F4     2        e     d  [
Bf3    1        s     d  =[
C4     1        s     d  ]]
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
F3     2        e     u  [
Bf3    1        s     u  =[
C4     1        s     u  ]]
D4     1        s     d  [[
Ef4    1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]
measure 19
Bf3    1        s     u  [[
C4     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]
D4     1        s     d  [[
Ef4    1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]
D4     3        e.    d  [
C4     1        s     d  =\
Bf3    2        e     d  =
F4     2        e     d  ]
measure 20
C4     3        e.    d  [
C4     1        s     d  =\
C4     2        e     d  =
C4     2        e     d  ]
G4     3        e.    d  [
G4     1        s     d  =\
G4     2        e     d  =
G4     2        e     d  ]
measure 21
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
F4     3        e.    d  [
F4     1        s     d  =\
C4     2        e     d  =
F4     2        e     d  ]
measure 22
F4     2        e     d  [
F4     1        s     d  =[
F4     1        s     d  ]]
A4     2        e     d  [
F4     2        e     d  ]
F4     2        e     d  [
G4     2        e     d  ]
F4     4        q     d
measure 23
F4     2        e     d  [
F4     2        e     d  ]
D4     1        s     d  [[
Ef4    1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
Bf4    2        e     d  [
F4     2        e     d  ]
measure 24
D4     1        s     d  [[
Ef4    1        s     d  ==
F4     1        s     d  ==
Ef4    1        s     d  ]]
F4     1        s     d  [[
G4     1        s     d  ==
F4     1        s     d  ==
G4     1        s     d  ]]
C4     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
F4     2        e     d  ]
measure 25
D4     4        q     d
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/4} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:88ab3685c90301fe9ba404f46d679aa5]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest   4        q
Bf4    2        e     d                    Great
Bf4    1        s     d                    was
Bf4    1        s     d                    the
Bf4    2        e     d                    com-
Bf4    1        s     d                    pa-
Bf4    1        s     d                    ny
Bf4    2        e     d                    of
Bf4    2        e     d                    the
measure 4
Bf4    2        e     d                    prea-
Bf4    2        e     d                    chers,
Bf4    2        e     d                    great
Bf4    1        s     d                    was
C5     1        s     d                    the
D5     1        s     d  [[                com-
Ef5    1        s     d  ==                -
D5     1        s     d  ==                -
Ef5    1        s     d  ]]                -
F5     1        s     d  [[                -
G5     1        s     d  ==                -
F5     1        s     d  ==                -
G5     1        s     d  ]]                -
measure 5
A4     1        s     u  [[                -
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
C5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
D5     1        s     d  ]]                -
Ef5    1        s     d  [[                -
D5     1        s     d  ==                -
Ef5    1        s     d  ==                -
D5     1        s     d  ]]                -
C5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
Ef5    1        s     d  ]]                -
measure 6
D5     3        e.    d  [                 -
Ef5    1        s     d  ]\                -
D5     1        s     d  [[                -
C5     1        s     d  ==                -
D5     1        s     d  ==                -
C5     1        s     d  =]                -
Bf4    2        e     d  ]                 -
Bf4    1        s     d                    pa-
Bf4    1        s     d                    ny
Ef5    2        e     d                    of
D5     2        e     d                    the
measure 7
C5     4        q     d                    prea-
C5     4        q     d                    chers,
rest   8        h
measure 8
rest   4        q
C5     2        e     d                    great
C5     1        s     d                    was
C5     1        s     d                    the
D5     2        e     d                    com-
D5     1        s     d                    pa-
D5     1        s     d                    ny
D5     2        e     d                    of
D5     2        e     d                    the
measure 9
C5     2        e     d                    prea-
C5     2        e     d                    chers.
rest   2        e
F4     2        e     u                    The
F4     8        h     u                    Lord
measure 10
F4     6        q.    u                    gave
G4     2        e     u                    the
A4     8        h     u                    word;
measure 11
C5     4        q     d                    Great
C5     2        e     d                    was
C5     2        e     d                    the
F4     1        s     u  [[                com-
G4     1        s     u  ==                -
F4     1        s     u  ==                -
G4     1        s     u  ]]                -
A4     1        s     u  [[                -
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
Bf4    1        s     u  =]                -
measure 12
C5     3        e.    u  ]                 -
A4     1        s     u                    pa-
A4     2        e     u                    ny,
A4     2        e     u                    the
A4     1        s     u  [[                com-
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
C5     1        s     d  [[                -
C5     1        s     d  ==                -
D5     1        s     d  ==                -
E5     1        s     d  =]                -
measure 13
F5     3        e.    d  ]                 -
C5     1        s     d                    pa-
C5     2        e     d                    ny,
C5     2        e     d                    the
A4     1        s     u  [[                com-
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
C5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
D5     1        s     d  =]                -
measure 14
E5     3        e.    d  ]                 -
D5     1        s     d                    pa-
C5     4        q     d                    ny
A4     2        e     u                    of
D5     2        e     d                    the
C5     4        q     d                    prea-
measure 15
C5     4        q     d                    chers,
rest   4        q
D5     4        q     d                    great
D5     2        e     d                    was
Bf4    2        e     d                    the
measure 16
F4     2        e     u                    com-
F4     1        s     u                    pa-
F4     1        s     u                    ny
F4     2        e     u                    of
G4     1        s     u  [[                the_
A4     1        s     u  ]]                _
Bf4    2        e     d                    prea-
F4     2        e     u                    chers,
rest   4        q
measure 17
F5     4        q     d                    great
F5     2        e     d                    was
F5     2        e     d                    the
F4     2        e     u                    com-
G4     1        s     u                    pa-
A4     1        s     u                    ny
Bf4    2        e     d                    of
F4     2        e     u                    the
measure 18
F5     2        e     d                    prea-
F5     2        e     d                    chers,
Bf4    2        e     d                    of
F5     2        e     d                    the
F5     2        e     d                    prea-
Bf4    2        e     d                    chers,
rest   4        q
measure 19
F5     4        q     d                    great
F5     2        e     d                    was
F5     2        e     d                    the
D5     1        s     d  [[                com-
Ef5    1        s     d  ==                -
D5     1        s     d  ==                -
Ef5    1        s     d  ]]                -
F5     1        s     d  [[                -
G5     1        s     d  ==                -
F5     1        s     d  ==                -
G5     1        s     d  ]]                -
measure 20
A4     1        s     u  [[                -
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
Bf4    1        s     u  ]]                -
C5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
D5     1        s     d  ]]                -
Ef5    1        s     d  [[                -
D5     1        s     d  ==                -
Ef5    1        s     d  ==                -
D5     1        s     d  ]]                -
C5     1        s     d  [[                -
D5     1        s     d  ==                -
C5     1        s     d  ==                -
Ef5    1        s     d  ]]                -
measure 21
D5     3        e.    d  [                 -
Ef5    1        s     d  ]\                -
D5     1        s     d  [[                -
C5     1        s     d  ==                -
D5     1        s     d  ==                -
C5     1        s     d  =]                -
Bf4    2        e     d  ]                 -
Bf4    1        s     d                    pa-
Bf4    1        s     d                    ny
Ef5    2        e     d                    of
D5     2        e     d                    the
measure 22
C5     4        q     d                    prea-
C5     4        q     d                    chers,
Bf4    2        e     d                    of
Bf4    2        e     d                    the
A4     4        q     u                    prea-
measure 23
Bf4    4        q     d                    chers.
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/5} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:9f2050914991ac45bb5dde8e2a88e2ba]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest   4        q
F4     2        e     u                    Great
F4     1        s     u                    was
F4     1        s     u                    the
G4     2        e     u                    com-
G4     1        s     u                    pa-
G4     1        s     u                    ny
G4     2        e     u                    of
G4     2        e     u                    the
measure 4
F4     2        e     u                    prea-
F4     2        e     u                    chers,
F4     2        e     u                    great
F4     1        s     u                    was
F4     1        s     u                    the
F4     3        e.    u                    com-
F4     1        s     u                    pa-
F4     2        e     u                    ny,
F4     2        e     u                    the
measure 5
F4     3        e.    u                    com-
C4     1        s     u                    pa-
C4     2        e     u                    ny,
F4     2        e     u                    the
Ef4    1        s     u  [[                com-
F4     1        s     u  ==                -
Ef4    1        s     u  ==                -
F4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
G4     1        s     u  ==                -
A4     1        s     u  =]                -
measure 6
Bf4    3        e.    u  ]                 -
Bf4    1        s     u                    pa-
Bf4    2        e     u                    ny,
Bf4    2        e     u                    the
Bf4    2        e     u                    com-
Bf4    1        s     u                    pa-
Bf4    1        s     u                    ny
A4     2        e     u                    of
Bf4    2        e     u                    the
measure 7
A4     4        q     u                    prea-
A4     4        q     u                    chers,
rest   8        h
measure 8
rest   4        q
A4     2        e     u                    great
A4     1        s     u                    was
A4     1        s     u                    the
Bf4    2        e     u                    com-
Bf4    1        s     u                    pa-
Bf4    1        s     u                    ny
Bf4    2        e     u                    of
Bf4    2        e     u                    the
measure 9
A4     2        e     u                    prea-
A4     2        e     u                    chers.
rest   2        e
F4     2        e     u                    The
F4     8        h     u                    Lord
measure 10
F4     6        q.    u                    gave
G4     2        e     u                    the
A4     8        h     u                    word;
measure 11
A4     4        q     u                    Great
A4     2        e     u                    was
A4     2        e     u                    the
A4     1        s     u  [[                com-
G4     1        s     u  ==                -
A4     1        s     u  ==                -
G4     1        s     u  ]]                -
F4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
G4     1        s     u  =]                -
measure 12
A4     3        e.    u  ]                 -
F4     1        s     u                    pa-
F4     2        e     u                    ny,
F4     2        e     u                    the
F4     1        s     u  [[                com-
G4     1        s     u  ==                -
F4     1        s     u  ==                -
G4     1        s     u  ]]                -
A4     1        s     u  [[                -
Bf4    1        s     u  ==                -
A4     1        s     u  ==                -
G4     1        s     u  =]                -
measure 13
A4     3        e.    u  ]                 -
A4     1        s     u                    pa-
A4     2        e     u                    ny,
A4     2        e     u                    the
C4     2        e     u                    com-
C4     1        s     u                    pa-
C4     1        s     u                    ny
F4     2        e     u                    of
A4     2        e     u                    the
measure 14
G4     4        q     u                    prea-
G4     4        q     u                    chers,
F4     2        e     u                    of
Bf4    2        e     u                    the
G4     4        q     u                    prea-
measure 15
A4     4        q     u                    chers,
rest   4        q
Bf4    4        q     u                    great
Bf4    2        e     u                    was
Bf4    2        e     u                    the
measure 16
Bf3    1        s     u  [[                com-
C4     1        s     u  ==                -
Bf3    1        s     u  ==                -
C4     1        s     u  ]]                -
Bf3    1        s     u  [[                -
C4     1        s     u  ==                -
Bf3    1        s     u  ==                -
C4     1        s     u  ]]                -
D4     1        s     u  [[                -
Ef4    1        s     u  ==                -
D4     1        s     u  ==                -
Ef4    1        s     u  ]]                -
F4     1        s     u  [[                -
F4     1        s     u  ==                -
G4     1        s     u  ==                -
A4     1        s     u  =]                -
measure 17
Bf4    3        e.    u  ]                 -
F4     1        s     u                    pa-
F4     2        e     u                    ny,
F4     2        e     u                    the
Bf3    1        s     u  [[                com-
C4     1        s     u  ==                -
Bf3    1        s     u  ==                -
C4     1        s     u  ]]                -
D4     1        s     u  [[                -
Ef4    1        s     u  ==                -
D4     1        s     u  ==                -
Ef4    1        s     u  ]]                -
measure 18
D4     1        s     u  [[                -
Ef4    1        s     u  ==                -
D4     1        s     u  ==                -
Ef4    1        s     u  ]]                -
F4     1        s     u  [[                -
F4     1        s     u  ==                -
G4     1        s     u  ==                -
A4     1        s     u  =]                -
Bf4    3        e.    u  ]                 -
F4     1        s     u                    pa-
F4     2        e     u                    ny,
F4     2        e     u                    the
measure 19
D4     1        s     u  [[                com-
Ef4    1        s     u  ==                -
D4     1        s     u  ==                -
Ef4    1        s     u  ]]                -
F4     1        s     u  [[                -
G4     1        s     u  ==                -
F4     1        s     u  ==                -
G4     1        s     u  =]                -
F4     3        e.    u  ]                 -
F4     1        s     u                    pa-
F4     2        e     u                    ny,
F4     2        e     u                    the
measure 20
F4     3        e.    u                    com-
C4     1        s     u                    pa-
C4     2        e     u                    ny,
F4     2        e     u                    the
Ef4    1        s     u  [[                com-
F4     1        s     u  ==                -
Ef4    1        s     u  ==                -
F4     1        s     u  ]]                -
G4     1        s     u  [[                -
A4     1        s     u  ==                -
G4     1        s     u  ==                -
A4     1        s     u  =]                -
measure 21
Bf4    3        e.    u  ]                 -
Bf4    1        s     u                    pa-
Bf4    2        e     u                    ny,
Bf4    2        e     u                    the
Bf4    2        e     u                    com-
Bf4    1        s     u                    pa-
Bf4    1        s     u                    ny
A4     2        e     u                    of
Bf4    2        e     u                    the
measure 22
A4     4        q     u                    prea-
A4     4        q     u                    chers,
F4     2        e     u                    of
G4     2        e     u                    the
F4     4        q     u                    prea-
measure 23
F4     4        q     u                    chers.
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/6} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:bbb2f747748cc1c53225de1ff1528867]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:34   D:Andante allegro
rest   4        q
rest   2        e
Bf3    2        e     d                    The
Bf3    8        h     d                    Lord
measure 2
Bf3    6        q.    d                    gave
C4     2        e     d                    the
D4     8        h     d                    word;
measure 3
rest   4        q
D4     2        e     d                    Great
D4     1        s     d                    was
D4     1        s     d                    the
Ef4    2        e     d                    com-
Ef4    1        s     d                    pa-
Ef4    1        s     d                    ny
Ef4    2        e     d                    of
Ef4    2        e     d                    the
measure 4
D4     2        e     d                    prea-
D4     2        e     d                    chers,
D4     2        e     d                    great
D4     1        s     d                    was
D4     1        s     d                    the
Bf3    3        e.    d                    com-
Bf3    1        s     d                    pa-
Bf3    2        e     d                    ny,
Bf3    2        e     d                    the
measure 5
F3     1        s     u  [[                com-
G3     1        s     u  ==                -
F3     1        s     u  ==                -
G3     1        s     u  ]]                -
A3     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
Bf3    1        s     d  =]                -
C4     3        e.    d  ]                 -
C4     1        s     d                    pa-
C4     2        e     d                    ny,
C4     2        e     d                    the
measure 6
Bf3    1        s     d  [[                com-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
Ef4    1        s     d  ==                -
D4     1        s     d  ==                -
Ef4    1        s     d  =]                -
F4     2        e     d  ]                 -
G4     1        s     d                    pa-
F4     1        s     d                    ny
Ef4    2        e     d                    of
F4     2        e     d                    the
measure 7
F4     4        q     d                    prea-
F4     4        q     d                    chers,
rest   8        h
measure 8
rest   4        q
F4     2        e     d                    great
F4     1        s     d                    was
F4     1        s     d                    the
F4     2        e     d                    com-
F4     1        s     d                    pa-
F4     1        s     d                    ny
F4     2        e     d                    of
F4     2        e     d                    the
measure 9
F4     2        e     d                    prea-
F4     2        e     d                    chers.
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
F4     4        q     d                    Great
F4     2        e     d                    was
F4     2        e     d                    the
C4     3        e.    d                    com-
C4     1        s     d                    pa-
C4     2        e     d                    ny,
C4     2        e     d                    the
measure 12
A3     1        s     u  [[                com-
Bf3    1        s     u  ==                -
A3     1        s     u  ==                -
Bf3    1        s     u  ]]                -
C4     1        s     d  [[                -
C4     1        s     d  ==                -
D4     1        s     d  ==                -
E4     1        s     d  =]                -
F4     3        e.    d  ]                 -
C4     1        s     d                    pa-
C4     2        e     d                    ny,
C4     2        e     d                    the
measure 13
A3     1        s     u  [[                com-
Bf3    1        s     u  ==                -
A3     1        s     u  ==                -
Bf3    1        s     u  ]]                -
C4     1        s     d  [[                -
C4     1        s     d  ==                -
D4     1        s     d  ==                -
E4     1        s     d  =]                -
F4     2        e     d  ]                 -
F4     1        s     d                    pa-
F4     1        s     d                    ny
F4     2        e     d                    of
F4     2        e     d                    the
measure 14
E4     4        q     d                    prea-
E4     4        q     d                    chers,
F4     2        e     d                    of
F4     2        e     d                    the
E4     4        q     d                    prea-
measure 15
F4     4        q     d                    chers,
rest   4        q
F4     4        q     d                    great
F4     2        e     d                    was
F4     2        e     d                    the
measure 16
D4     2        e     d                    com-
D4     1        s     d                    pa-
Ef4    1        s     d                    ny
F4     2        e     d                    of
F4     2        e     d                    the
F4     2        e     d                    prea-
D4     2        e     d                    chers,
rest   4        q
measure 17
D4     4        q     d                    great
D4     2        e     d                    was
D4     2        e     d                    the
F4     2        e     d                    com-
F4     1        s     d                    pa-
Ef4    1        s     d                    ny
D4     2        e     d                    of
C4     2        e     d                    the
measure 18
Bf3    2        e     d                    prea-
Bf3    2        e     d                    chers,
rest   2        e
D4     2        e     d                    the
Bf3    1        s     d  [[                com-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
Ef4    1        s     d  ==                -
D4     1        s     d  ==                -
Ef4    1        s     d  ]]                -
measure 19
Bf3    1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
Ef4    1        s     d  ==                -
D4     1        s     d  ==                -
Ef4    1        s     d  =]                -
D4     3        e.    d  ]                 -
C4     1        s     d                    pa-
Bf3    2        e     d                    ny,
Bf3    2        e     d                    the
measure 20
F3     1        s     u  [[                com-
G3     1        s     u  ==                -
F3     1        s     u  ==                -
G3     1        s     u  ]]                -
A3     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
Bf3    1        s     d  =]                -
C4     3        e.    d  ]                 -
C4     1        s     d                    pa-
C4     2        e     d                    ny,
C4     2        e     d                    the
measure 21
Bf3    1        s     d  [[                com-
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  ]]                -
D4     1        s     d  [[                -
Ef4    1        s     d  ==                -
D4     1        s     d  ==                -
Ef4    1        s     d  =]                -
F4     2        e     d  ]                 -
G4     1        s     d                    pa-
F4     1        s     d                    ny
Ef4    2        e     d                    of
F4     2        e     d                    the
measure 22
F4     4        q     d                    prea-
C4     4        q     d                    chers,
D4     2        e     d                    of
Ef4    2        e     d                    the
C4     4        q     d                    prea-
measure 23
D4     4        q     d                    chers.
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/7} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:2019a173adeb12f401c59db27541109e]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Andante allegro
rest   4        q
rest   2        e
Bf3    2        e     d                    The
Bf3    8        h     d                    Lord
measure 2
Bf3    6        q.    d                    gave
C4     2        e     d                    the
D4     8        h     d                    word;
measure 3
rest   4        q
Bf3    2        e     d                    Great
Bf3    1        s     d                    was
Bf3    1        s     d                    the
G3     2        e     d                    com-
G3     1        s     d                    pa-
G3     1        s     d                    ny
Ef3    2        e     d                    of
Ef3    2        e     d                    the
measure 4
Bf3    2        e     d                    prea-
Bf3    2        e     d                    chers,
Bf3    2        e     d                    great
Bf3    1        s     d                    was
Bf3    1        s     d                    the
Bf2    1        s     u  [[                com-
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
D3     1        s     d  [[                -
Ef3    1        s     d  ==                -
D3     1        s     d  ==                -
Ef3    1        s     d  =]                -
measure 5
F3     3        e.    d  ]                 -
F3     1        s     d                    pa-
F3     2        e     d                    ny,
F3     2        e     d                    the
C3     1        s     u  [[                com-
D3     1        s     u  ==                -
C3     1        s     u  ==                -
D3     1        s     u  ]]                -
Ef3    1        s     d  [[                -
F3     1        s     d  ==                -
Ef3    1        s     d  ==                -
F3     1        s     d  ]]                -
measure 6
G3     1        s     d  [[                -
A3     1        s     d  ==                -
G3     1        s     d  ==                -
A3     1        s     d  ]]                -
Bf3    1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  =]                -
D4     2        e     d  ]                 -
Ef4    1        s     d                    pa-
D4     1        s     d                    ny
C4     2        e     d                    of
Bf3    2        e     d                    the
measure 7
F3     4        q     d                    prea-
F3     4        q     d                    chers,
rest   8        h
measure 8
rest   4        q
F3     2        e     d                    great
F3     1        s     d                    was
F3     1        s     d                    the
D3     2        e     d                    com-
D3     1        s     d                    pa-
D3     1        s     d                    ny
Bf2    2        e     u                    of
Bf2    2        e     u                    the
measure 9
F3     2        e     d                    prea-
F3     2        e     d                    chers.
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
F3     4        q     d                    Great
F3     2        e     d                    was
F3     2        e     d                    the
F3     3        e.    d                    com-
F3     1        s     d                    pa-
F3     2        e     d                    ny,
F3     2        e     d                    the
measure 12
F3     1        s     d  [[                com-
G3     1        s     d  ==                -
F3     1        s     d  ==                -
G3     1        s     d  ]]                -
A3     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
Bf3    1        s     d  =]                -
C4     3        e.    d  ]                 -
F3     1        s     d                    pa-
F3     2        e     d                    ny,
F3     2        e     d                    the
measure 13
F3     1        s     d  [[                com-
G3     1        s     d  ==                -
F3     1        s     d  ==                -
G3     1        s     d  ]]                -
A3     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
G3     1        s     d  ]]                -
F3     1        s     d  [[                -
G3     1        s     d  ==                -
F3     1        s     d  ==                -
G3     1        s     d  ]]                -
A3     1        s     d  [[                -
Bf3    1        s     d  ==                -
A3     1        s     d  ==                -
Bf3    1        s     d  =]                -
measure 14
C4     3        e.    d  ]                 -
C4     1        s     d                    pa-
C4     4        q     d                    ny
D4     2        e     d                    of
Bf3    2        e     d                    the
C4     4        q     d                    prea-
measure 15
F3     4        q     d                    chers,
rest   4        q
Bf3    4        q     d                    great
Bf3    2        e     d                    was
Bf3    2        e     d                    the
measure 16
Bf3    3        e.    d                    com-
Bf2    1        s     u                    pa-
Bf2    2        e     u                    ny,
Bf2    2        e     u                    the
Bf2    1        s     u  [[                com-
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
Bf2    1        s     u  [[                -
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
measure 17
D3     1        s     d  [[                -
Ef3    1        s     d  ==                -
D3     1        s     d  ==                -
Ef3    1        s     d  ]]                -
F3     1        s     d  [[                -
F3     1        s     d  ==                -
G3     1        s     d  ==                -
A3     1        s     d  =]                -
Bf3    3        e.    d  ]                 -
F3     1        s     d                    pa-
F3     2        e     d                    ny,
F3     2        e     d                    the
measure 18
Bf2    1        s     u  [[                com-
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
Bf2    1        s     u  [[                -
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
D3     1        s     d  [[                -
Ef3    1        s     d  ==                -
D3     1        s     d  ==                -
Ef3    1        s     d  ]]                -
F3     1        s     d  [[                -
F3     1        s     d  ==                -
G3     1        s     d  ==                -
A3     1        s     d  =]                -
measure 19
Bf3    3        e.    d  ]                 -
Bf3    1        s     d                    pa-
Bf3    2        e     d                    ny,
Bf3    2        e     d                    the
Bf2    1        s     u  [[                com-
C3     1        s     u  ==                -
Bf2    1        s     u  ==                -
C3     1        s     u  ]]                -
D3     1        s     d  [[                -
Ef3    1        s     d  ==                -
D3     1        s     d  ==                -
Ef3    1        s     d  =]                -
measure 20
F3     3        e.    d  ]                 -
F3     1        s     d                    pa-
F3     2        e     d                    ny,
F3     2        e     d                    the
C3     1        s     u  [[                com-
D3     1        s     u  ==                -
C3     1        s     u  ==                -
D3     1        s     u  ]]                -
Ef3    1        s     d  [[                -
F3     1        s     d  ==                -
Ef3    1        s     d  ==                -
F3     1        s     d  ]]                -
measure 21
G3     1        s     d  [[                -
A3     1        s     d  ==                -
G3     1        s     d  ==                -
A3     1        s     d  ]]                -
Bf3    1        s     d  [[                -
C4     1        s     d  ==                -
Bf3    1        s     d  ==                -
C4     1        s     d  =]                -
D4     2        e     d  ]                 -
Ef4    1        s     d                    pa-
D4     1        s     d                    ny
C4     2        e     d                    of
Bf3    2        e     d                    the
measure 22
F3     4        q     d                    prea-
F3     4        q     d                    chers,
Bf3    2        e     d                    of
Ef3    2        e     d                    the
F3     4        q     d                    prea-
measure 23
Bf2    4        q     u                    chers.
rest   4        q
rest   8        h
measure 24
rest  16
measure 25
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-15/8} [KHM:1265058347]
TIMESTAMP: DEC/26/2001 [md5sum:310e7a0e7db0c3b160cfff20bc302095]
06/11/90 E. Correia
WK#:56        MV#:2,15
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:-2   Q:4   T:1/1   C:22   D:Andante allegro
Bf2    4        q     u
rest   4        q
rest   8        h
measure 2
rest  16
measure 3
rest   4        q
Bf3    2        e     d  [
Bf3    1        s     d  =[
Bf3    1        s     d  ]]
G3     2        e     d  [
G3     1        s     d  =[
G3     1        s     d  ]]
Ef3    2        e     d  [
Ef3    2        e     d  ]
measure 4
Bf3    2        e     d  [
Bf3    2        e     d  ]
Bf3    2        e     d  [
Bf3    1        s     d  =[
Bf3    1        s     d  ]]
Bf2    1        s     u  [[
C3     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ]]
D3     1        s     d  [[
Ef3    1        s     d  ==
D3     1        s     d  ==
Ef3    1        s     d  ]]
measure 5
F3     3        e.    d  [
F3     1        s     d  =\
F3     2        e     d  =
F3     2        e     d  ]
C3     1        s     u  [[
D3     1        s     u  ==
C3     1        s     u  ==
D3     1        s     u  ]]
Ef3    1        s     d  [[
F3     1        s     d  ==
Ef3    1        s     d  ==
F3     1        s     d  ]]
measure 6
G3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ]]
Bf3    1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]
D4     2        e     d  [
Ef4    1        s     d  =[
D4     1        s     d  ]]
C4     2        e     d  [
Bf3    2        e     d  ]
measure 7
F3     2        e     d  [
F3     2        e     d  ]
F3     2        e     d  [
F3     1        s     d  =[
F3     1        s     d  ]]
D3     2        e     d  [
D3     1        s     d  =[
D3     1        s     d  ]]
Bf2    2        e     u  [
Bf2    2        e     u  ]
measure 8
F3     2        e     d  [
F3     2        e     d  ]
F3     2        e     d  [
F3     1        s     d  =[
F3     1        s     d  ]]
D3     2        e     d  [
D3     1        s     d  =[
D3     1        s     d  ]]
Bf2    2        e     u  [
Bf2    2        e     u  ]
measure 9
F3     2        e     d  [
F2     2        e     u  ]
rest   4        q
rest   8        h
measure 10
rest  16
measure 11
F3     4        q     d
F3     2        e     d  [
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 12
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 13
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     1        s     d  [[
G3     1        s     d  ==
F3     1        s     d  ==
G3     1        s     d  ]]
A3     1        s     d  [[
Bf3    1        s     d  ==
A3     1        s     d  ==
Bf3    1        s     d  ]]
measure 14
C4     2        e     d  [
C3     2        e     d  =
C3     2        e     d  =
C4     2        e     d  ]
D4     2        e     d  [
Bf3    2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
measure 15
F3     4        q     d
rest   4        q
Bf3    4        q     d
Bf3    2        e     d  [
Bf3    2        e     d  ]
measure 16
Bf3    2        e     d  [
Bf2    2        e     d  =
Bf2    2        e     d  =
Bf2    2        e     d  ]
Bf2    1        s     u  [[
C3     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ]]
Bf2    1        s     u  [[
C3     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ]]
measure 17
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
measure 18
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
measure 19
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
Bf2    1        s     u  [[
C3     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ]]
D3     1        s     d  [[
Ef3    1        s     d  ==
D3     1        s     d  ==
Ef3    1        s     d  ]]
measure 20
F3     3        e.    d  [
F3     1        s     d  =\
F3     2        e     d  =
F3     2        e     d  ]
C3     1        s     u  [[
D3     1        s     u  ==
C3     1        s     u  ==
D3     1        s     u  ]]
Ef3    1        s     d  [[
F3     1        s     d  ==
Ef3    1        s     d  ==
F3     1        s     d  ]]
measure 21
G3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
A3     1        s     d  ]]
Bf3    1        s     d  [[
C4     1        s     d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]
D4     2        e     d  [
Ef4    1        s     d  =[
D4     1        s     d  ]]
C4     2        e     d  [
Bf3    2        e     d  ]
measure 22
F3     2        e     d  [
F3     1        s     d  =[
F3     1        s     d  ]]
F3     4        q     d
Bf3    2        e     d  [
Ef3    2        e     d  ]
F3     4        q     d
measure 23
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
Bf2    2        e     u  [
Bf2    2        e     u  =
Bf2    2        e     u  =
Bf2    2        e     u  ]
measure 24
Bf2    1        s     u  [[
C3     1        s     u  ==
Bf2    1        s     u  ==
C3     1        s     u  ]]
D3     1        s     d  [[
Ef3    1        s     d  ==
D3     1        s     d  ==
Ef3    1        s     d  ]]
F3     2        e     u  [
Bf3    2        e     u  =
F3     2        e     u  =
F2     2        e     u  ]
measure 25
Bf2    4        q     u
rest   4        q
rest   8        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
