&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/1} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:13c3cfb9fa242b4b4b5209db4ca8b077]
04/27/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Andante allegro
D6     4        q     d
G5     2        e     d  [
G5     2        e     d  ]
C6     2        e     d  [
C6     2        e     d  =
C6     2        e     d  =
C6     2        e     d  ]
measure 2
C6     2        e     d  [
B5     2        e     d  ]
rest   4        q
rest   2        e
E5     2        e     d  [
A5     2        e     d  =
F#5    2        e     d  ]
measure 3
D5     2        e     d  [
D5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 4
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
B5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 5
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
G5     2        e     d
E5     4        q     d
A5     2        e     d
measure 6
F#5    2        e     d  [
D5     2        e     d  ]
G5     4-       q     d        -
G5     2        e     d  [
A5     2        e     d  =
F#5    3        e.    d  =      &t
G5     1        s     d  ]\
measure 7
G5     4        q     d
rest   4        q
rest   8        h
measure 8
rest   2        e
D5     2        e     d  [      p
G5     2        e     d  =
D5     2        e     d  ]
B4     4        q     d
rest   4        q
measure 9
rest   2        e
E5     2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 10
rest   2        e
F#4    2        e     u  [
A4     2        e     u  =
F#4    2        e     u  ]
B4     4        q     u
rest   4        q
measure 11
rest   2        e
G4     2        e     u  [
B4     2        e     u  =
G4     2        e     u  ]
C5     4        q     d
rest   4        q
measure 12
rest   2        e
D5     2        e     d  [
F#5    2        e     d  =
D5     2        e     d  ]
rest   2        e
G4     2        e     u
G5     4        q     d
measure 13
rest   2        e
E5     2        e     d
A5     4        q     d
rest   2        e
D5     2        e     d
G5     4        q     d
measure 14
rest  16
measure 15
rest   4        q
G4     4        q     u
rest   4        q
C5     4        q     d
measure 16
rest   4        q
A4     4        q     u
rest   4        q
D5     4        q     d
measure 17
rest   4        q
B4     4        q     u
rest   4        q
E5     4        q     d
measure 18
rest   4        q
A4     4        q     u
rest   4        q
A5     4        q     d
measure 19
rest   2        e
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  ]
rest   2        e
A4     2        e     u
D5     4        q     d
measure 20
rest  16
measure 21
rest   4        q
B4     4        q     d
rest   4        q
E5     4        q     d
measure 22
rest   4        q
C#5    4        q     d
rest   4        q
F#5    4        q     d
measure 23
rest   4        q
D5     4        q     d
rest   4        q
G5     4        q     d
measure 24
rest   4        q
E5     4        q     d
rest   4        q
D5     4        q     d
measure 25
D5     4        q     d
rest   4        q
E5     4        q     d
rest   4        q
measure 26
E5     4        q     d
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
rest   1        s
C#5    1        s     d  [[      f
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 33
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 34
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 35
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 36
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
B5     1        s     d  [[
C#6    1        s     d  ==
B5     1        s     d  ==
C#6    1        s     d  ]]
D6     2        e     d  [
A5     2        e     d  ]
D6     4-       q     d        -
measure 37
D6     4        q     d
C#6    4        q     d         i
D6     4        q     d         i
rest   4        q
measure 38
rest   8        h
rest   2        e
D5     2        e     d         p
G5     4        q     d
measure 39
rest   2        e
E5     2        e     d  [
A5     2        e     d  =
D5     2        e     d  ]
D5     4        q     d
G5     4        q     d
measure 40
rest   4        q
E5     4        q     d
rest   4        q
A5     4        q     d
measure 41
A4     4        q     u
rest   4        q
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest   8        h
rest   1        s
D5     1        s     d  [[     &f
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 49
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 50
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 51
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 52
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
G5     1        s     d  ]]
measure 53
C6     1        s     d  [[
B5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
C6     1        s     d  [[
B5     1        s     d  ==
C6     1        s     d  ==
D6     1        s     d  ]]
B5     4        q     d
rest   4        q
measure 54
rest  16
measure 55
rest   8        h
rest   2        e
D5     2        e     d  [      p
E5     2        e     d  =
G5     2        e     d  ]
measure 56
A5     2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  ]
C6     2        e     d  [
C5     2        e     d  ]
G5     4        q     d
measure 57
rest   2        e
C5     2        e     d  [
C5     2        e     d  =
B4     2        e     d  ]
rest   2        e
G4     2        e     u
C5     4        q     d
measure 58
rest   4        q
A5     4        q     d
rest   4        q
F5     4        q     d
measure 59
rest   4        q
D5     4        q     d
rest   4        q
E5     4        q     d
measure 60
rest   4        q
E5     4        q     d
rest   2        e
D5     2        e     d  [
C5     3        e.    d  =      &t
B4     1        s     d  ]\
measure 61
A4     2        e     u  [
D4     2        e     u  ]
D5     4        q     d
rest   8        h
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest  16
measure 66
rest  16
measure 67
rest   8        h
rest   1        s
E5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
F5     1        s     d  ]]
measure 68
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
measure 69
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
measure 70
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
G5     1        s     d  [[
F5     1        s     d  ==
G5     1        s     d  ==
F5     1        s     d  ]]
E5     1        s     d  [[
F5     1        s     d  ==
E5     1        s     d  ==
F5     1        s     d  ]]
measure 71
G5     1        s     d  [[
F#5    1        s     d  ==     +
G5     1        s     d  ==
A5     1        s     d  ]]
G5     2        e     d  [
C6     2-       e     d  ]     -
C6     1        s     d  [[
B5     1        s     d  ==
C6     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 72
A5     6        q.    d         &t
A5     2        e     d
B5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 73
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     2        e     d  [
G4     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 74
C6     2        e     d  [
C6     2        e     d  =
C6     2        e     d  =
C6     2        e     d  ]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
measure 75
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
B5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
C6     1        s     d  [[
B5     1        s     d  ==
C6     1        s     d  ==
D6     1        s     d  ]]
C6     1        s     d  [[
D6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 76
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
E6     1        s     d  ]]
D6     1        s     d  [[
E6     1        s     d  ==
C6     1        s     d  ==
D6     1        s     d  ]]
measure 77
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
C6     1        s     d  [[
B5     1        s     d  ==
C6     1        s     d  ==
D6     1        s     d  ]]
C6     1        s     d  [[
D6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 78
A5     2        e     d  [
D5     2        e     d  ]
rest   4        q
rest   4        q
G5     2        e     d  [
F5     2        e     d  ]
measure 79
E5     1        s     d  [[
F5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
A4     2        e     u  [
D4     2        e     u  =
G4     3        e.    u  =
B4     1        s     u  ]\
measure 80
A4     3        e.    d  [
C5     1        s     d  =\
B4     3        e.    d  =
D5     1        s     d  ]\
C5     3        e.    d  [
E5     1        s     d  =\
A4     3        e.    d  =
C5     1        s     d  ]\
measure 81
B4     3        e.    d  [
D5     1        s     d  =\
C5     3        e.    d  =
E5     1        s     d  ]\
D5     8-       h     d        -
measure 82
D5     4        q     d
C6     3        e.    d  [
A5     1        s     d  ]\
B5     3        e.    d  [
G5     1        s     d  =\
C6     3        e.    d  =
A5     1        s     d  ]\
measure 83
D6     3        e.    d  [
D6     1        s     d  =\
C6     3        e.    d  =
B5     1        s     d  ]\
A5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 84
A5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
A5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 85
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 86
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
measure 87
D6     1        s     d  [[
C6     1        s     d  ==
D6     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
measure 88
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    1        s     u  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
G5     2        e     d  [
E5     2        e     d  ]
measure 89
F#5    6        q.    d         &t
F#5    2        e     d
G5     2        e     d  [
D5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
measure 90
E5     2        e     d  [
D5     2        e     d  ]
C5     4-       q     d        -
C5     2        e     d
B4     4        q     u
A4     2        e     u
measure 91
A4     6        q.    u         &t
A4     2        e     u
B4     1        s     u  [[
D4     1        s     u  ==
E4     1        s     u  ==
F#4    1        s     u  ]]
G4     1        s     u  [[
A4     1        s     u  ==
B4     1        s     u  ==
C5     1        s     u  ]]
measure 92
D5     6        q.    d
G4     2        e     u
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 93
C5     2        e     d  [
B4     2        e     d  ]
G5     4-       q     d        -
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 94
G5     2        e     d  [
D5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 95
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
B5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 96
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 97
E5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
A4     2        e     u  [
D4     2        e     u  ]
D5     4-       q     d        -
measure 98
D5     2        e     d  [
G4     2        e     d  ]
C5     4-       q     d        -
C5     2        e     d  [
D5     2        e     d  =
B4     2        e     d  =
A4     2        e     d  ]
measure 99
A4     6        q.    u         &t
G4     2        e     u
G4     8        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/2} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:af23cfea3f6b15f87247f2baea2e1e0e]
04/07/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Andante allegro
B4     4        q     u
rest   4        q
rest   8        h
measure 2
D5     4        q     d
G4     2        e     u  [
G4     2        e     u  ]
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 3
B4     1        s     u  [[
A4     1        s     u  ==
B4     1        s     u  ==
C5     1        s     u  ]]
B4     1        s     u  [[
C5     1        s     u  ==
A4     1        s     u  ==
B4     1        s     u  ]]
G4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
G4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
B4     1        s     u  ]]
measure 4
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
B4     1        s     u  ]]
A4     1        s     u  [[
C5     1        s     u  ==
B4     1        s     u  ==
C5     1        s     u  ]]
measure 5
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
B4     2        e     u  [
G4     2        e     u  ]
C5     4-       q     d        -
measure 6
C5     2        e     d  [
D5     2        e     d  =
B4     2        e     d  =
A4     2        e     d  ]
B4     4        q     u
A4     3        e.    u  [
G4     1        s     u  ]\
measure 7
G4     4        q     u
rest   4        q
rest   8        h
measure 8
rest   2        e
B4     2        e     d  [      &p
D5     2        e     d  =
B4     2        e     d  ]
D4     4        q     u
rest   4        q
measure 9
rest   2        e
C5     2        e     d  [
E5     2        e     d  =
C5     2        e     d  ]
C4     4        q     u
rest   4        q
measure 10
rest   2        e
D4     2        e     u  [
F#4    2        e     u  =
D4     2        e     u  ]
D5     4        q     d
rest   4        q
measure 11
rest   2        e
E4     2        e     u  [
G4     2        e     u  =
E4     2        e     u  ]
E5     4        q     d
rest   4        q
measure 12
rest   2        e
A4     2        e     d  [
D5     2        e     d  =
A4     2        e     d  ]
rest   2        e
D4     2        e     u
D5     4        q     d
measure 13
rest   2        e
C5     2        e     d
C5     4        q     d
rest   2        e
B4     2        e     u
B4     4        q     u
measure 14
rest  16
measure 15
rest   4        q
E4     4        q     u
rest   4        q
A4     4        q     u
measure 16
rest   4        q
F#4    4        q     u
rest   4        q
B4     4        q     u
measure 17
rest   4        q
G4     4        q     u
rest   4        q
C5     4        q     d
measure 18
rest   4        q
F#4    4        q     u
rest   4        q
D5     4        q     d
measure 19
rest   2        e
D5     2        e     d  [
C#5    2        e     d  =
C#5    2        e     d  ]
rest   2        e
D5     2        e     d
F#5    4        q     d
measure 20
rest  16
measure 21
rest   4        q
D4     4        q     u
rest   4        q
G4     4        q     u
measure 22
rest   4        q
E4     4        q     u
rest   4        q
A4     4        q     u
measure 23
rest   4        q
F#4    4        q     u
rest   4        q
B4     4        q     u
measure 24
rest   4        q
C#5    4        q     d
rest   4        q
A4     4        q     u
measure 25
B4     4        q     u
rest   4        q
B4     4        q     u
rest   4        q
measure 26
C#5    4        q     d
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
rest   1        s
A4     1        s     d  [[     &f
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
measure 33
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
measure 34
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
measure 35
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
measure 36
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 37
E5     4        q     d         i
E5     4        q     d         i
F#5    4        q     d         i
rest   4        q
measure 38
rest   8        h
rest   2        e
A4     2        e     u         &p
D5     4        q     d
measure 39
rest   2        e
C5     2        e     d  [
C5     2        e     d  =
A4     2        e     d  ]
B4     4        q     u
B4     4        q     u
measure 40
rest   4        q
G4     4        q     u
rest   4        q
C5     4        q     d
measure 41
F#4    4        q     u
rest   4        q
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest   8        h
rest   1        s
F#5    1        s     d  [[     &f
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 49
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 50
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 51
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 52
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
D5     1        s     d  ]]
measure 53
E5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
G5     4        q     d
rest   4        q
measure 54
rest  16
measure 55
rest   8        h
rest   2        e
B4     2        e     d  [      &p
C5     2        e     d  =
E5     2        e     d  ]
measure 56
C5     2        e     d  [
B4     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
G4     2        e     u  [
G4     2        e     u  ]
E5     4        q     d
measure 57
rest   2        e
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  ]
rest   2        e
E4     2        e     u
G4     4        q     u
measure 58
rest   4        q
F4     4        q     u
rest   4        q
A4     4        q     u
measure 59
rest   4        q
B4     4        q     u
rest   4        q
B4     4        q     u
measure 60
rest   4        q
C5     4        q     d
rest   2        e
B4     2        e     u
A4     1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 61
F#4    2        e     u  [
F#4    2        e     u  ]
G4     4        q     u
rest   8        h
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest  16
measure 66
rest  16
measure 67
rest   8        h
rest   1        s
C5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ]]
F5     1        s     d  [[
E5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ]]
measure 68
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 69
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 70
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
measure 71
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
E5     1        s     d  ]]
F#5    1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
F#5    1        s     d  ]]
D5     2        e     d  [
G5     2        e     d  ]
measure 72
G5     4        q     d
F#5    4        q     d
G5     2        e     d  [
D5     2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]
measure 73
G4     4        q     u
rest   4        q
D6     4        q     d
G5     2        e     d  [
G5     2        e     d  ]
measure 74
G5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
measure 75
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[
B5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 76
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
F#5    1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
C6     1        s     d  ]]
B5     1        s     d  [[
C6     1        s     d  ==
A5     1        s     d  ==
B5     1        s     d  ]]
measure 77
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 78
F#5    2        e     d  [
F#5    2        e     d  ]
rest   4        q
rest   4        q
D5     2        e     d  [
B4     2        e     d  ]
measure 79
G4     2        e     u  [
B4     2        e     u  ]
A4     1        s     u  [[
B4     1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
F#4    2        e     u  [
F#4    2        e     u  ]
rest   4        q
measure 80
rest   4        q
D5     3        e.    d  [
F#5    1        s     d  ]\
E5     3        e.    d  [
G5     1        s     d  =\
F#5    3        e.    d  =
A5     1        s     d  ]\
measure 81
G5     3        e.    d  [
B5     1        s     d  =\
A5     3        e.    d  =
G5     1        s     d  ]\
F#5    3        e.    d  [
E5     1        s     d  ]\
D5     4        q     d
measure 82
rest   4        q
A5     3        e.    d  [
F#5    1        s     d  ]\
D5     3        e.    d  [
G4     1        s     d  =\
F#5    3        e.    d  =
A4     1        s     d  ]\
measure 83
G5     3        e.    d  [
B5     1        s     d  =\
A5     3        e.    d  =
G5     1        s     d  ]\
F#5    1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
D5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 84
F#5    1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
D5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
F#5    1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 85
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 86
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
A5     1        s     d  ]]
measure 87
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
measure 88
E5     1        s     d  [[
D5     1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
B4     1        s     d  ]]
A4     1        s     d  [[
C5     1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
B4     2        e     d  [
C5     2        e     d  ]
measure 89
A4     6        q.    u
A4     2        e     u
B4     2        e     d  [
B4     2        e     d  =
D5     2        e     d  =
B4     2        e     d  ]
measure 90
G4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
A4     2        e     u
G4     4        q     u
G4     2        e     u
measure 91
F#4    6        q.    u
F#4    2        e     u
G4     3        e.    u  [
D4     1        s     u  ]\
E4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
measure 92
B4     4        q     u
G5     4-       q     d        -
G5     2        e     d  [
G4     2        e     d  ]
F#4    4        q     u
measure 93
D6     4        q     d
rest   2        e
G5     2        e     d
C6     2        e     d  [
C6     2        e     d  =
C6     2        e     d  =
C6     2        e     d  ]
measure 94
C6     2        e     d  [
B5     2        e     d  ]
rest   4        q
rest   4        q
E5     2        e     d  [
D5     2        e     d  ]
measure 95
C5     1        s     d  [[
B4     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
C5     1        s     d  [[
D5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
A4     1        s     u  ==
B4     1        s     u  ]]
A4     1        s     u  [[
C5     1        s     u  ==
B4     1        s     u  ==
C5     1        s     u  ]]
measure 96
D5     1        s     d  [[
C5     1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
C5     1        s     d  ==
D5     1        s     d  ]]
B4     1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
B4     1        s     d  [[
C5     1        s     d  ==
A4     1        s     d  ==
B4     1        s     d  ]]
measure 97
C5     1        s     d  [[
D5     1        s     d  ==
B4     1        s     d  ==
C5     1        s     d  ]]
A4     1        s     u  [[
B4     1        s     u  ==
G4     1        s     u  ==
A4     1        s     u  ]]
F#4    4        q     u
rest   2        e
D4     2        e     u
measure 98
G4     6        q.    u
E4     2        e     u
F#4    4        q     u
G4     4-       q     u        -
measure 99
G4     4        q     u
F#4    4        q     u
G4     8        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/3} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:586ee2acd76a1213950adfc3e5dc2058]
04/07/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:13   D:Andante allegro
G4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
E4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
F#4    2        e     d  ]
measure 2
G4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
E4     2        e     d  [
A4     2        e     d  =
D4     2        e     d  =
A4     2        e     d  ]
measure 3
G4     2        e     d  [
G4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
C5     4        q     d
rest   4        q
measure 4
E4     4        q     d
rest   4        q
F#4    4        q     d
rest   4        q
measure 5
F#4    4        q     d
rest   4        q
G4     4        q     d
A4     4        q     d
measure 6
A4     2        e     d  [
B4     2        e     d  =
G4     2        e     d  =
E4     2        e     d  ]
D4     6        q.    d
C5     2        e     d
measure 7
B4     4        q     d
rest   4        q
rest   8        h
measure 8
rest   2        e
G4     2        e     d  [      &p
B4     2        e     d  =
G4     2        e     d  ]
G3     4        q     u
rest   4        q
measure 9
rest   2        e
G4     2        e     d  [
C5     2        e     d  =
C4     2        e     d  ]
E4     4        q     d
rest   4        q
measure 10
rest   2        e
A3     2        e     d  [
D4     2        e     d  =
A4     2        e     d  ]
F#4    4        q     d
rest   4        q
measure 11
rest   2        e
B3     2        e     d  [
E4     2        e     d  =
B4     2        e     d  ]
G4     4        q     d
rest   4        q
measure 12
rest   2        e
D4     2        e     d  [
A4     2        e     d  =
F#4    2        e     d  ]
rest   2        e
B3     2        e     u
B4     4        q     d
measure 13
rest   2        e
E4     2        e     d
D4     4        q     d
rest   2        e
D4     2        e     d
D4     4        q     d
measure 14
rest  16
measure 15
rest   4        q
C4     4        q     u
rest   4        q
E4     4        q     d
measure 16
rest   4        q
D4     4        q     d
rest   4        q
F#4    4        q     d
measure 17
rest   4        q
E4     4        q     d
rest   4        q
G4     4        q     d
measure 18
rest   4        q
D4     4        q     d
rest   4        q
A4     4        q     d
measure 19
rest   2        e
B3     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
rest   2        e
F#4    2        e     d
A4     4        q     d
measure 20
rest  16
measure 21
rest   4        q
G3     4        q     u
rest   4        q
B3     4        q     u
measure 22
rest   4        q
A3     4        q     u
rest   4        q
C#4    4        q     u
measure 23
rest   4        q
B3     4        q     u
rest   4        q
D4     4        q     d
measure 24
rest   4        q
A4     4        q     d
rest   4        q
F#4    4        q     d
measure 25
G4     4        q     d
rest   4        q
G4     4        q     d
rest   4        q
measure 26
A4     4        q     d
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
D5     3        e.    d  [      &f
A4     1        s     d  ]\
A4     4        q     d
rest   8        h
measure 34
D5     3        e.    d  [
A4     1        s     d  ]\
A4     4        q     d
rest   8        h
measure 35
rest   2        e
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
D5     4        q     d
rest   2        e
D5     2        e     d
measure 36
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
G4     2        e     d  ]
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 37
B4     4        q     d         i
A4     4        q     d         i
A4     4        q     d         i
rest   4        q
measure 38
rest   8        h
rest   2        e
F#4    2        e     d         &p
B4     4        q     d
measure 39
rest   2        e
A4     2        e     d  [
D4     2        e     d  =
F#4    2        e     d  ]
G4     4        q     d
D4     4        q     d
measure 40
rest   4        q
C4     4        q     u
rest   4        q
E4     4        q     d
measure 41
D4     4        q     d
rest   4        q
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
G4     3        e.    d  [      &f
D4     1        s     d  ]\
D4     4        q     d
rest   8        h
measure 50
G4     3        e.    d  [
D4     1        s     d  ]\
D4     4        q     d
rest   8        h
measure 51
rest   2        e
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
D5     4        q     d
rest   2        e
D4     2        e     d
measure 52
G4     2        e     d  [
G4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
C5     2        e     d  [
C5     2        e     d  ]
rest   2        e
G4     2        e     d
measure 53
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
F#4    2        e     d  ]
D5     4        q     d
rest   4        q
measure 54
rest  16
measure 55
rest   8        h
rest   2        e
G4     2        e     d  [      &p
G4     2        e     d  =
C5     2        e     d  ]
measure 56
A4     4        q     d
F4     2        e     d  [
F4     2        e     d  ]
G4     2        e     d  [
G4     2        e     d  ]
C5     4        q     d
measure 57
rest   2        e
F4     2        e     d  [
G3     2        e     d  =
G3     2        e     d  ]
rest   2        e
C4     2        e     u
E4     4        q     d
measure 58
rest   4        q
C5     4        q     d
rest   4        q
D4     4        q     d
measure 59
rest   4        q
G4     4        q     d
rest   4        q
G4     4        q     d
measure 60
rest   4        q
A4     4        q     d
rest   2        e
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  ]
measure 61
F#4    2        e     d  [
F#4    2        e     d  ]
D4     4        q     d
rest   8        h
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest  16
measure 66
rest  16
measure 67
rest  16
measure 68
C5     3        e.    d  [
G4     1        s     d  ]\
G4     4        q     d
rest   8        h
measure 69
C5     3        e.    d  [
G4     1        s     d  ]\
G4     4        q     d
rest   8        h
measure 70
rest   2        e
C5     2        e     d  [
G4     2        e     d  =
G4     2        e     d  ]
C5     4        q     d
rest   2        e
G4     2        e     d
measure 71
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
E4     2        e     d  ]
A4     4        q     d
G4     2        e     d  [
D4     2        e     d  ]
measure 72
D5     6        q.    d
D5     2        e     d
D4     2        e     d  [
G4     2        e     d  =
D4     2        e     d  =
G4     2        e     d  ]
measure 73
G4     1        s     d  [[
F#4    1        s     d  ==
E4     1        s     d  ==
F#4    1        s     d  ]]
G4     1        s     d  [[
F#4    1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
D4     4        q     d
B4     2        e     d  [
B4     2        e     d  ]
measure 74
E4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
D4     2        e     d  ]
D4     4        q     d
D4     2        e     d  [
D4     2        e     d  ]
measure 75
E4     4        q     d
C5     2        e     d  [
C5     2        e     d  ]
A4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 76
D5     4        q     d
D5     2        e     d  [
D5     2        e     d  ]
D4     4        q     d
F#4    2        e     d  [
F#4    2        e     d  ]
measure 77
G4     4        q     d
rest   2        e
G4     2        e     d
A4     6        q.    d
D5     2        e     d
measure 78
D5     2        e     d  [
A4     2        e     d  ]
rest   4        q
rest   4        q
G4     2        e     d  [
D4     2        e     d  ]
measure 79
E4     2        e     d  [
G4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
A3     2        e     d  [
D4     2        e     d  ]
rest   4        q
measure 80
rest  16
measure 81
rest   8        h
rest   4        q
F#4    3        e.    d  [
A4     1        s     d  ]\
measure 82
G4     3        e.    d  [
B4     1        s     d  =\
A4     3        e.    d  =
C5     1        s     d  ]\
B4     3        e.    d  [
D4     1        s     d  =\
C4     3        e.    d  =
E4     1        s     d  ]\
measure 83
D4     3        e.    d  [
D4     1        s     d  =\
E4     3        e.    d  =
E4     1        s     d  ]\
F#4    2        e     d  [
D4     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 84
D5     4        q     d
D4     2        e     d  [
D5     2        e     d  ]
D5     2        e     d  [
A4     2        e     d  ]
rest   4        q
measure 85
G4     3        e.    d  [
D4     1        s     d  ]\
D4     4        q     d
rest   8        h
measure 86
G4     3        e.    d  [
D4     1        s     d  ]\
D4     4        q     d
rest   8        h
measure 87
rest   2        e
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  ]
D5     4        q     d
rest   2        e
G4     2        e     d
measure 88
G4     2        e     d  [
G4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
F#4    2        e     d  [
D4     2        e     d  ]
rest   2        e
G4     2        e     d
measure 89
D4     6        q.    d
D4     2        e     d
D4     2        e     d  [
D4     2        e     d  =
B4     2        e     d  =
D4     2        e     d  ]
measure 90
E4     2        e     d  [
G4     2        e     d  =
C4     2        e     d  =
E4     2        e     d  ]
D4     2        e     d
D4     4        q     d
E4     2        e     d
measure 91
D4     6        q.    d
D4     2        e     d
D4     8        h     d
measure 92
G4     6        q.    d
D4     2        e     d
E4     2        e     d  [
A3     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 93
G4     4        q     d
D4     2        e     d  [
B4     2        e     d  ]
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 94
G4     4        q     d
D5     2        e     d  [
B4     2        e     d  ]
G4     1        s     d  [[
F#4    1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]
G4     2        e     d  [
G4     2        e     d  ]
measure 95
E4     4        q     d
rest   2        e
E4     2        e     d
F#4    4        q     d
D5     4        q     d
measure 96
rest   2        e
F#4    2        e     d  [
B4     2        e     d  =
F#4    2        e     d  ]
G4     4        q     d
rest   2        e
E4     2        e     d
measure 97
E4     4        q     d
rest   2        e
E4     2        e     d
F#4    4        q     d
rest   2        e
F#4    2        e     d
measure 98
E4     6        q.    d
C4     2        e     u
A3     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
measure 99
A3     4        q     u
D4     4        q     d
B3     8        h     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/4} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:e4caa1951e3a8eeab5b3affd02d40ed5]
07/09/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
D5     4        q     d                    For
G4     2        e     u                    un-
G4     2        e     u                    to
C5     2        e     d                    us
C5     2        e     d                    a
C5     2        e     d                    child
C5     2        e     d                    is
measure 8
C5     2        e     d  [                 born,_
B4     2        e     d  ]                 _
rest   4        q
rest   4        q
G4     2        e     u                    un-
F#4    2        e     u                    to
measure 9
E4     4        q     u                    us
rest   4        q
rest   2        e
E4     2        e     u                    a
A4     2        e     u                    son
G4     2        e     u                    is
measure 10
F#4    2        e     u                    gi-
F#4    2        e     u                    ven,
rest   4        q
rest   4        q
B4     2        e     u                    un-
A4     2        e     u                    to
measure 11
G4     4        q     u                    us
rest   4        q
rest   2        e
G4     2        e     u                    a
C5     2        e     d                    son
B4     2        e     u                    is
measure 12
A4     2        e     u                    gi-
A4     2        e     u                    ven,
rest   4        q
rest   8        h
measure 13
rest   8        h
D5     4        q     d                    for
G4     2        e     u                    un-
G4     2        e     u                    to
measure 14
C5     2        e     d                    us
C5     2        e     d                    a
C5     2        e     d                    child
C5     2        e     d                    is
B4     1        s     d  [[                born,_
A4     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
C5     1        s     d  ==                _
A4     1        s     d  ==                _
B4     1        s     d  ]]                _
measure 15
G4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
B4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
C5     1        s     d  [[                _
B4     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
measure 16
A4     1        s     u  [[                _
G4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
A4     1        s     u  [[                _
C5     1        s     u  ==                _
B4     1        s     u  ==                _
C5     1        s     u  ]]                _
D5     1        s     d  [[                _
C5     1        s     d  ==                _
D5     1        s     d  ==                _
E5     1        s     d  ]]                _
D5     1        s     d  [[                _
E5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
measure 17
B4     1        s     d  [[                _
A4     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
D5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
E5     1        s     d  [[                _
D5     1        s     d  ==                _
E5     1        s     d  ==                _
F#5    1        s     d  ]]                _
E5     1        s     d  [[                _
F#5    1        s     d  ==                _
G5     1        s     d  ==                _
A5     1        s     d  ]]                _
measure 18
F#5    4        q     d                    _
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest   4        q
A4     3        e.    u                    and
C#5    1        s     d                    the
B4     3        e.    d                    go-
D5     1        s     d                    vern-
C#5    3        e.    d                    ment
E5     1        s     d                    shall
measure 29
D5     3        e.    d                    be
F#5    1        s     d                    up-
E5     3        e.    d                    on
G5     1        s     d                    his
F#5    2        e     d  [                 shoul-
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
C#5    2        e     d  [                 -
B4     2        e     d  ]                 -
measure 30
A4    16        w     u                    -
measure 31
A4     3        e.    u                    der,
D5     1        s     d                    up-
C#5    3        e.    d                    on
E5     1        s     d                    his
D5     3        e.    d                    shoul-
F#5    1        s     d                    der,
E5     3        e.    d                    and
D5     1        s     d                    his
measure 32
C#5    4        q     d                    name
D5     2        e     d                    shall
D5     2        e     d                    be
C#5    2        e     d                    cal-
C#5    2        e     d                    led,
rest   4        q
measure 33
D5     3        e.    d                    Won-
A4     1        s     u                    der-
A4     4        q     u                    ful,
rest   8        h
measure 34
D5     3        e.    d                    Coun-
A4     1        s     u                    sel-
A4     4        q     u                    lor,
rest   8        h
measure 35
rest   2        e
A4     2        e     u                    the
A4     2        e     u                    migh-
A4     2        e     u                    ty
D5     4        q     d                    God,
rest   2        e
D5     2        e     d                    the
measure 36
D5     2        e     d                    e-
D5     2        e     d                    ver-
G5     2        e     d                    last-
G5     2        e     d                    ing
F#5    2        e     d                    Fa-
F#5    2        e     d                    ther,
rest   2        e
D5     2        e     d                    the
measure 37
D5     4        q     d         i          Prince
C#5    4        q     d         i          of
D5     4        q     d         i          Peace.
rest   4        q
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest   4        q
D5     2        e     d                    Un-
B4     2        e     u                    to
G4     2        e     u                    us
E5     2        e     d                    a
C5     2        e     d                    child
A4     2        e     u                    is
measure 42
F#4    4        q     u                    born,
rest   4        q
rest   8        h
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest   4        q
A4     2        e     u                    and
D5     2        e     d                    his
B4     4        q     u                    name
rest   4        q
measure 48
rest   4        q
D5     2        e     d                    shall
G5     2        e     d                    be
F#5    2        e     d                    cal-
D5     2        e     d                    led,
rest   4        q
measure 49
D5     3        e.    d                    Won-
C5     1        s     d                    der-
B4     4        q     u                    ful,
rest   8        h
measure 50
D5     3        e.    d                    Coun-
C5     1        s     d                    sel-
B4     4        q     u                    lor,
rest   8        h
measure 51
rest   2        e
D5     2        e     d                    the
D5     2        e     d                    migh-
D5     2        e     d                    ty
G5     4        q     d                    God,
rest   2        e
D5     2        e     d                    the
measure 52
D5     2        e     d                    e-
D5     2        e     d                    ver-
G5     2        e     d                    last-
G5     2        e     d                    ing
E5     2        e     d                    Fa-
E5     2        e     d                    ther,
rest   2        e
G5     2        e     d                    the
measure 53
C5     6        q.    d                    Prince
C5     2        e     d                    of
B4     4        q     u                    Peace.
rest   4        q
measure 54
rest   8        h
D5     4        q     d                    For
G4     2        e     u                    un-
G4     2        e     u                    to
measure 55
C5     2        e     d                    us
C5     2        e     d                    a
C5     2        e     d                    child
C5     2        e     d                    is
C5     2        e     d  [                 born,_
B4     2        e     d  ]                 _
rest   4        q
measure 56
rest  16
measure 57
rest  16
measure 58
rest  16
measure 59
rest   8        h
rest   4        q
B4     2        e     u                    un-
B4     2        e     u                    to
measure 60
C5     4        q     d                    us
rest   4        q
rest   2        e
D5     2        e     d                    a
C5     3        e.    d                    son
B4     1        s     u                    is
measure 61
A4     2        e     u                    gi-
A4     2        e     u                    ven,
rest   4        q
rest   8        h
measure 62
rest  16
measure 63
rest   4        q
G4     3        e.    u                    and
B4     1        s     u                    the
A4     3        e.    u                    go-
C5     1        s     d                    vern-
B4     3        e.    u                    ment
D5     1        s     d                    shall
measure 64
C5     3        e.    d                    be,
E5     1        s     d                    shall
D5     3        e.    d                    be
F5     1        s     d                    up-
E5     1        s     d  [[                on_
D5     1        s     d  =]                _
C5     2        e     d  =                 _
E5     2        e     d  ]                 _
F#5    2        e     d                    his
measure 65
G5     4        q     d                    shoul-
G4     4        q     u                    der,
rest   8        h
measure 66
rest   8        h
rest   4        q
D5     2        e     d                    and
G5     2        e     d                    his
measure 67
E5     4        q     d                    name
G5     2        e     d                    shall
D5     2        e     d                    be
E5     2        e     d                    cal-
C5     2        e     d                    led,
rest   4        q
measure 68
C5     3        e.    d                    Won-
G4     1        s     u                    der-
G4     4        q     u                    ful
rest   8        h
measure 69
C5     3        e.    d                    Coun-
G4     1        s     u                    sel-
G4     4        q     u                    lor,
rest   8        h
measure 70
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    migh-
G4     2        e     u                    ty
C5     4        q     d                    God,
rest   2        e
C5     2        e     d                    the
measure 71
C5     2        e     d                    e-
C5     2        e     d                    ver-
C5     2        e     d                    last-
C5     2        e     d                    ing
C5     4        q     d                    Fa-
B4     4        q     u                    ther,
measure 72
A4     6        q.    u                    Prince
A4     2        e     u                    of
B4     4        q     u                    Peace.
rest   4        q
measure 73
rest   8        h
D5     4        q     d                    For
G4     2        e     u                    un-
G4     2        e     u                    to
measure 74
C5     2        e     d                    us
C5     2        e     d                    a
C5     2        e     d                    child
C5     2        e     d                    is
B4     1        s     u  [[                born,_
A4     1        s     u  ==                _
B4     1        s     u  ==                _
C5     1        s     u  ]]                _
B4     1        s     u  [[                _
C5     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
measure 75
G4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
B4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
C5     1        s     d  [[                _
B4     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
measure 76
A4     1        s     u  [[                _
G4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
A4     1        s     u  [[                _
C5     1        s     u  ==                _
B4     1        s     u  ==                _
C5     1        s     u  ]]                _
D5     1        s     d  [[                _
C5     1        s     d  ==                _
D5     1        s     d  ==                _
E5     1        s     d  ]]                _
D5     1        s     d  [[                _
E5     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
measure 77
B4     1        s     d  [[                _
A4     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
C5     1        s     d  ==                _
A4     1        s     d  ==                _
B4     1        s     d  ]]                _
C5     1        s     d  [[                _
B4     1        s     d  ==                _
C5     1        s     d  ==                _
D5     1        s     d  ]]                _
C5     1        s     d  [[                _
D5     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
measure 78
A4     4        q     u                    _
D5     2        e     d                    un-
C5     2        e     d                    to
B4     4        q     u                    us
rest   4        q
measure 79
rest   2        e
D5     2        e     d                    a
C5     2        e     d                    son
B4     2        e     u                    is
A4     2        e     u                    gi-
A4     2        e     u                    ven,
G4     3        e.    u                    and
B4     1        s     u                    the
measure 80
A4     3        e.    u                    go-
C5     1        s     d                    vern-
B4     3        e.    u                    ment,
D5     1        s     d                    the
C5     3        e.    d                    go-
E5     1        s     d                    vern-
A4     3        e.    u                    ment
C5     1        s     d                    shall
measure 81
B4     3        e.    u                    be
D5     1        s     d                    up-
C5     3        e.    d                    on
E5     1        s     d                    his
D5     8        h     d                    shoul-
measure 82
D5     4        q     d                    der,
C5     3        e.    d                    and
A4     1        s     u                    the
B4     3        e.    u                    go-
G4     1        s     u                    vern-
C5     3        e.    d                    ment
A4     1        s     u                    shall
measure 83
D5     3        e.    d                    be
D5     1        s     d                    up-
C5     3        e.    d                    on
B4     1        s     u                    his
A4     2        e     u                    shoul-
A4     2        e     u                    der,
D5     2        e     d                    and
D5     2        e     d                    his
measure 84
D5     4        q     d                    name
D5     2        e     d                    shall
D5     2        e     d                    be
D5     2        e     d                    cal-
D5     2        e     d                    led,
rest   4        q
measure 85
D5     3        e.    d                    Won-
C5     1        s     d                    der-
B4     4        q     d                    ful,
rest   8        h
measure 86
D5     3        e.    d                    Coun-
C5     1        s     d                    sel-
B4     4        q     d                    lor,
rest   8        h
measure 87
rest   2        e
D5     2        e     d                    the
D5     2        e     d                    migh-
D5     2        e     d                    ty
G5     4        q     d                    God,
rest   2        e
G5     2        e     d                    the
measure 88
E5     2        e     d                    e-
D5     2        e     d                    ver-
C5     2        e     d                    last-
B4     2        e     u                    ing
A4     2        e     u                    Fa-
A4     2        e     u                    ther,
rest   2        e
C5     2        e     d                    the
measure 89
A4     6        q.    u                    Prince
A4     2        e     u                    of
B4     4        q     u                    Peace,
rest   2        e
B4     2        e     u                    the
measure 90
E5     2        e     d                    e-
D5     2        e     d                    ver-
C5     2        e     d                    last-
C5     2        e     d                    ing
C5     2        e     d                    Fa-
B4     4        q     u                    ther,
A4     2        e     u                    the
measure 91
A4     6        q.    u                    Prince
A4     2        e     u                    of
G4     8        h     u                    Peace.
measure 92
rest  16
measure 93
rest  16
measure 94
rest  16
measure 95
rest  16
measure 96
rest  16
measure 97
rest  16
measure 98
rest  16
measure 99
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/5} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:77f2e36dc18d00ff99f6f8d1f824a753]
07/09/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest   8        h
A4     4        q     u                    For
D4     2        e     u                    un-
D4     2        e     u                    to
measure 19
G4     2        e     u                    us
G4     2        e     u                    a
G4     2        e     u                    child
G4     2        e     u                    is
G4     2        e     u  [                 born,_
F#4    2        e     u  ]                 _
rest   4        q
measure 20
rest   8        h
rest   4        q
D4     2        e     u                    un-
C#4    2        e     u                    to
measure 21
B3     4        q     u                    us
rest   4        q
rest   2        e
B3     2        e     u                    a
E4     2        e     u                    son
D4     2        e     u                    is
measure 22
C#4    2        e     u                    gi-
C#4    2        e     u                    ven,
rest   4        q
rest   4        q
F#4    2        e     u                    un-
E4     2        e     u                    to
measure 23
D4     4        q     u                    us
rest   4        q
rest   2        e
D4     2        e     u                    a
G4     2        e     u                    son
F#4    2        e     u                    is
measure 24
E4     2        e     u                    gi-
E4     2        e     u                    ven,
rest   4        q
rest   4        q
A4     2        e     u                    un-
F#4    2        e     u                    to
measure 25
D4     4        q     u                    us
rest   4        q
rest   2        e
B4     2        e     u                    a
G4     2        e     u                    son
E4     2        e     u                    is
measure 26
C#4    2        e     u                    gi-
C#4    2        e     u                    ven,
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest   4        q
C#4    3        e.    u                    and
E4     1        s     u                    the
D4     3        e.    u                    go-
F#4    1        s     u                    vern-
E4     3        e.    u                    ment
G4     1        s     u                    shall
measure 31
F#4    3        e.    u                    be
A4     1        s     u                    up-
G4     3        e.    u                    on
E4     1        s     u                    his
A4     3        e.    u                    shoul-
F#4    1        s     u                    der,
B4     3        e.    u                    and
G4     1        s     u                    his
measure 32
E4     4        q     u                    name
A4     2        e     u                    shall
A4     2        e     u                    be
A4     2        e     u                    cal-
A4     2        e     u                    led,
rest   4        q
measure 33
A4     3        e.    u                    Won-
G4     1        s     u                    der-
F#4    4        q     u                    ful,
rest   8        h
measure 34
A4     3        e.    u                    Coun-
G4     1        s     u                    sel-
F#4    4        q     u                    lor,
rest   8        h
measure 35
rest   2        e
F#4    2        e     u                    the
F#4    2        e     u                    migh-
F#4    2        e     u                    ty
A4     4        q     u                    God,
rest   2        e
A4     2        e     u                    the
measure 36
B4     2        e     u                    e-
B4     2        e     u                    ver-
B4     2        e     u                    last-
B4     2        e     u                    ing
A4     2        e     u                    Fa-
A4     2        e     u                    ther,
rest   2        e
A4     2        e     u                    the
measure 37
B4     4        q     u                    Prince
A4     4        q     u                    of
A4     4        q     u                    Peace.
D4     2        e     u                    Un-
D4     2        e     u                    to
measure 38
G4     2        e     u                    us
G4     2        e     u                    a
G4     2        e     u                    child
G4     2        e     u                    is
G4     2        e     u  [                 born,_
F#4    2        e     u  ]                 _
rest   4        q
measure 39
rest   8        h
rest   4        q
G4     2        e     u                    un-
F#4    2        e     u                    to
measure 40
E4     4        q     u                    us
rest   4        q
rest   2        e
E4     2        e     u                    a
A4     2        e     u                    son
G4     2        e     u                    is
measure 41
F#4    2        e     u                    gi-
F#4    2        e     u                    ven,
rest   4        q
rest   8        h
measure 42
rest  16
measure 43
rest   4        q
D4     3        e.    u                    and
F#4    1        s     u                    the
E4     3        e.    u                    go-
G4     1        s     u                    vern-
F#4    3        e.    u                    ment
A4     1        s     u                    shall
measure 44
G4     3        e.    u                    be
B4     1        s     u                    up-
A4     3        e.    u                    on
C5     1        s     d                    his
B4     2        e     u  [                 shoul-
A4     1        s     u  =[                -
G4     1        s     u  ]]                -
F#4    2        e     u  [                 -
E4     2        e     u  ]                 -
measure 45
D4    16-       w     u        -           -
measure 46
D4     8-       h     u        -           -
D4     2        e     u  [                 -
E4     1        s     u  =[                -
D4     1        s     u  ]]                -
C4     2        e     u  [                 -
B3     2        e     u  ]                 -
measure 47
A3     4        q     u                    -
A3     4        q     u                    der,
rest   4        q
D4     2        e     u                    and
G4     2        e     u                    his
measure 48
F#4    4        q     u                    name
G4     2        e     u                    shall
B4     2        e     u                    be
A4     2        e     u                    cal-
A4     2        e     u                    led,
rest   4        q
measure 49
B4     3        e.    u                    Won-
A4     1        s     u                    der-
G4     4        q     u                    ful,
rest   8        h
measure 50
B4     3        e.    u                    Coun-
A4     1        s     u                    sel-
G4     4        q     u                    lor,
rest   8        h
measure 51
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    migh-
G4     2        e     u                    ty
G4     4        q     u                    God,
rest   2        e
G4     2        e     u                    the
measure 52
G4     2        e     u                    e-
G4     2        e     u                    ver-
B4     2        e     u                    last-
B4     2        e     u                    ing
G4     2        e     u                    Fa-
G4     2        e     u                    ther,
rest   2        e
G4     2        e     u                    the
measure 53
G4     6        q.    u                    Prince
F#4    2        e     u                    of
G4     4        q     u                    Peace.
rest   4        q
measure 54
rest  16
measure 55
rest  16
measure 56
rest   8        h
G4     4        q     u                    For
C4     2        e     u                    un-
C4     2        e     u                    to
measure 57
F4     2        e     u                    us
F4     2        e     u                    a
F4     2        e     u                    child
F4     2        e     u                    is
E4     1        s     u  [[                born,_
D4     1        s     u  ==                _
E4     1        s     u  ==                _
F4     1        s     u  ]]                _
E4     1        s     u  [[                _
F4     1        s     u  ==                _
D4     1        s     u  ==                _
E4     1        s     u  ]]                _
measure 58
C4     1        s     u  [[                _
B3     1        s     u  ==                _
C4     1        s     u  ==                _
D4     1        s     u  ]]                _
C4     1        s     u  [[                _
E4     1        s     u  ==                _
D4     1        s     u  ==                _
E4     1        s     u  ]]                _
F4     1        s     u  [[                _
E4     1        s     u  ==                _
F4     1        s     u  ==                _
G4     1        s     u  ]]                _
F4     1        s     u  [[                _
G4     1        s     u  ==                _
E4     1        s     u  ==                _
F4     1        s     u  ]]                _
measure 59
D4     1        s     u  [[                _
C4     1        s     u  ==                _
D4     1        s     u  ==                _
E4     1        s     u  ]]                _
D4     1        s     u  [[                _
F4     1        s     u  ==                _
E4     1        s     u  ==                _
F4     1        s     u  ]]                _
G4     1        s     u  [[                _
F4     1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
F4     1        s     u  ==                _
G4     1        s     u  ]]                _
measure 60
E4     1        s     u  [[                _
D4     1        s     u  ==                _
E4     1        s     u  ==                _
F#4    1        s     u  ]]     +          _
E4     1        s     u  [[                _
G4     1        s     u  ==                _
F#4    1        s     u  ==                _
G4     1        s     u  ]]                _
A4     1        s     u  [[                _
G4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
A4     1        s     u  [[                _
B4     1        s     u  ==                _
A4     1        s     u  ==                _
G4     1        s     u  ]]                _
measure 61
F#4    4        q     u                    _
rest   4        q
rest   8        h
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest   4        q
B3     3        e.    u                    and
D4     1        s     u                    the
C4     3        e.    u                    go-
E4     1        s     u                    vern-
D4     3        e.    u                    ment
F4     1        s     u                    shall
measure 66
E4     3        e.    u                    be
G4     1        s     u                    up-
F4     3        e.    u                    on
E4     1        s     u                    his
D4     2        e     u                    shoul-
D4     2        e     u                    der,
G4     2        e     u                    and
G4     2        e     u                    his
measure 67
G4     4        q     u                    name
G4     2        e     u                    shall
G4     2        e     u                    be
G4     2        e     u                    cal-
G4     2        e     u                    led,
rest   4        q
measure 68
G4     3        e.    u                    Won-
F4     1        s     u                    der-
E4     4        q     u                    ful,
rest   8        h
measure 69
G4     3        e.    u                    Coun-
F4     1        s     u                    sel-
E4     4        q     u                    lor,
rest   8        h
measure 70
rest   2        e
E4     2        e     u                    the
E4     2        e     u                    migh-
E4     2        e     u                    ty
G4     4        q     u                    God,
rest   2        e
G4     2        e     u                    the
measure 71
G4     2        e     u                    e-
G4     2        e     u                    ver-
G4     2        e     u                    last-
G4     2        e     u                    ing
F#4    4        q     u                    Fa-
D4     2        e     u  [                 ther,_
G4     2        e     u  ]                 _
measure 72
G4     4        q     u                    Prince
F#4    4        q     u                    of
G4     4        q     u                    Peace.
rest   4        q
measure 73
rest   8        h
G4     4        q     u                    For
G4     2        e     u                    un-
G4     2        e     u                    to
measure 74
G4     2        e     u                    us
G4     2        e     u                    a
F#4    2        e     u                    child
F#4    2        e     u                    is
G4     1        s     u  [[                born,_
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
F#4    1        s     u  ==                _
G4     1        s     u  ]]                _
measure 75
E4     1        s     u  [[                _
D4     1        s     u  ==                _
E4     1        s     u  ==                _
F#4    1        s     u  ]]                _
E4     1        s     u  [[                _
G4     1        s     u  ==                _
F#4    1        s     u  ==                _
G4     1        s     u  ]]                _
A4     1        s     u  [[                _
G4     1        s     u  ==                _
A4     1        s     u  ==                _
B4     1        s     u  ]]                _
A4     1        s     u  [[                _
B4     1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
measure 76
F#4    1        s     u  [[                _
E4     1        s     u  ==                _
F#4    1        s     u  ==                _
G4     1        s     u  ]]                _
F#4    1        s     u  [[                _
A4     1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
B4     1        s     d  [[                _
A4     1        s     d  ==                _
B4     1        s     d  ==                _
C5     1        s     d  ]]                _
B4     1        s     d  [[                _
C5     1        s     d  ==                _
A4     1        s     d  ==                _
B4     1        s     d  ]]                _
measure 77
G4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
G4     1        s     u  [[                _
A4     1        s     u  ==                _
F#4    1        s     u  ==                _
G4     1        s     u  ]]                _
E4     1        s     u  [[                _
D4     1        s     u  ==                _
E4     1        s     u  ==                _
F#4    1        s     u  ]]                _
E4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
A4     1        s     u  ]]                _
measure 78
F#4    4        q     u                    _
A4     2        e     u                    un-
A4     2        e     u                    to
G4     4        q     u                    us
rest   4        q
measure 79
rest   2        e
B4     2        e     u                    a
A4     2        e     u                    son
G4     2        e     u                    is
F#4    2        e     u                    gi-
F#4    2        e     u                    ven,
rest   4        q
measure 80
rest   4        q
D4     3        e.    u                    and
F#4    1        s     u                    the
E4     3        e.    u                    go-
G4     1        s     u                    vern-
F#4    3        e.    u                    ment
A4     1        s     u                    shall
measure 81
G4     3        e.    u                    be
B4     1        s     u                    up-
A4     3        e.    u                    on
G4     1        s     u                    his
F#4    3        e.    u  [                 shoul-
E4     1        s     u  ]\                -
D4     4        q     u                    der,
measure 82
rest   4        q
F#4    3        e.    u                    and
F#4    1        s     u                    the
D4     3        e.    u                    go-
G4     1        s     u                    vern-
F#4    3        e.    u                    ment
A4     1        s     u                    shall
measure 83
G4     3        e.    u                    be
G4     1        s     u                    up-
A4     3        e.    u                    on
G4     1        s     u                    his
F#4    2        e     u                    shoul-
F#4    2        e     u                    der,
G4     2        e     u                    and
B4     2        e     u                    his
measure 84
A4     4        q     u                    name
G4     2        e     u                    shall
B4     2        e     u                    be
A4     2        e     u                    cal-
A4     2        e     u                    led,
rest   4        q
measure 85
B4     3        e.    u                    Won-
A4     1        s     u                    der-
G4     4        q     u                    ful,
rest   8        h
measure 86
B4     3        e.    u                    Coun-
A4     1        s     u                    sel-
G4     4        q     u                    lor,
rest   8        h
measure 87
rest   2        e
G4     2        e     u                    the
G4     2        e     u                    migh-
G4     2        e     u                    ty
G4     4        q     u                    God,
rest   2        e
G4     2        e     u                    the
measure 88
G4     2        e     u                    e-
B4     2        e     u                    ver-
A4     2        e     u                    last-
G4     2        e     u                    ing
F#4    2        e     u                    Fa-
F#4    2        e     u                    ther,
rest   2        e
G4     2        e     u                    the
measure 89
F#4    6        q.    u                    Prince
F#4    2        e     u                    of
G4     4        q     u                    Peace,
rest   2        e
G4     2        e     u                    the
measure 90
G4     2        e     u                    e-
G4     2        e     u                    ver-
F#4    2        e     u                    last-
G4     2        e     u                    ing
A4     2        e     u                    Fa-
G4     4        q     u                    ther,
G4     2        e     u                    the
measure 91
F#4    6        q.    u                    Prince
D4     2        e     u                    of
D4     8        h     u                    Peace.
measure 92
rest  16
measure 93
rest  16
measure 94
rest  16
measure 95
rest  16
measure 96
rest  16
measure 97
rest  16
measure 98
rest  16
measure 99
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/6} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:898ba6e9adb78c445d055673e2e3b128]
07/09/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:34   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest   8        h
D4     4        q     d                    For
G3     2        e     u                    un-
G3     2        e     u                    to
measure 13
C4     2        e     d                    us
C4     2        e     d                    a
C4     2        e     d                    child
C4     2        e     d                    is
C4     2        e     d  [                 born,_
B3     2        e     d  ]                 _
rest   4        q
measure 14
rest   8        h
rest   4        q
G3     2        e     u                    un-
F#3    2        e     u                    to
measure 15
E3     4        q     u                    us
rest   4        q
rest   2        e
E3     2        e     u                    a
A3     2        e     u                    son
G3     2        e     u                    is
measure 16
F#3    2        e     u                    gi-
F#3    2        e     u                    ven,
rest   4        q
rest   4        q
B3     2        e     u                    un-
A3     2        e     u                    to
measure 17
G3     4        q     u                    us
rest   4        q
rest   2        e
G3     2        e     u                    a
C4     2        e     d                    son
B3     2        e     d                    is
measure 18
A3     2        e     u                    gi-
A3     2        e     u                    ven,
rest   4        q
rest   8        h
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest  16
measure 23
rest  16
measure 24
rest  16
measure 25
rest  16
measure 26
rest   4        q
A3     3        e.    u                    and
C#4    1        s     d                    the
B3     3        e.    d                    go-
D4     1        s     d                    vern-
C#4    3        e.    d                    ment
E4     1        s     d                    shall
measure 27
D4     3        e.    d                    be
F#4    1        s     d                    up-
E4     3        e.    d                    on
G4     1        s     d                    his
F#4    2        e     d  [                 shoul-
E4     1        s     d  =[                -
D4     1        s     d  ]]                -
C#4    2        e     d  [                 -
B3     2        e     d  ]                 -
measure 28
A3    16        w     u                    -
measure 29
A3     8        h     u                    der,
rest   8        h
measure 30
rest  16
measure 31
rest   8        h
rest   4        q
E4     3        e.    d                    and
G4     1        s     d                    his
measure 32
A3     4        q     u                    name
D4     2        e     d                    shall
F#4    2        e     d                    be
E4     2        e     d                    cal-
E4     2        e     d                    led,
rest   4        q
measure 33
F#4    3        e.    d                    Won-
E4     1        s     d                    der-
D4     4        q     d                    ful,
rest   8        h
measure 34
F#4    3        e.    d                    Coun-
E4     1        s     d                    sel-
D4     4        q     d                    lor,
rest   8        h
measure 35
rest   2        e
D4     2        e     d                    the
D4     2        e     d                    migh-
D4     2        e     d                    ty
F#4    4        q     d                    God,
rest   2        e
F#4    2        e     d                    the
measure 36
G4     2        e     d                    e-
G4     2        e     d                    ver-
D4     2        e     d                    last-
D4     2        e     d                    ing
F#4    2        e     d                    Fa-
F#4    2        e     d                    ther,
rest   2        e
F#4    2        e     d                    the
measure 37
E4     4        q     d                    Prince
E4     4        q     d                    of
F#4    4        q     d                    Peace.
rest   4        q
measure 38
rest   8        h
D4     4        q     d                    For
G3     2        e     u                    un-
G3     2        e     u                    to
measure 39
C4     2        e     d                    us
C4     2        e     d                    a
C4     2        e     d                    child
C4     2        e     d                    is
B3     1        s     d  [[                born,_
A3     1        s     d  ==                _
B3     1        s     d  ==                _
C4     1        s     d  ]]                _
B3     1        s     d  [[                _
C4     1        s     d  ==                _
A3     1        s     d  ==                _
B3     1        s     d  ]]                _
measure 40
G3     1        s     u  [[                _
F#3    1        s     u  ==                _
G3     1        s     u  ==                _
A3     1        s     u  ]]                _
G3     1        s     u  [[                _
B3     1        s     u  ==                _
A3     1        s     u  ==                _
B3     1        s     u  ]]                _
C4     1        s     d  [[                _
B3     1        s     d  ==                _
C4     1        s     d  ==                _
D4     1        s     d  ]]                _
C4     1        s     d  [[                _
D4     1        s     d  ==                _
B3     1        s     d  ==                _
C4     1        s     d  ]]                _
measure 41
A3     4        q     u                    _
rest   4        q
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest   4        q
F#4    2        e     d                    and
F#4    2        e     d                    his
G4     4        q     d                    name
rest   4        q
measure 48
rest   4        q
D4     2        e     d                    shall
D4     2        e     d                    be
F#4    2        e     d                    cal-
F#4    2        e     d                    led,
rest   4        q
measure 49
G4     3        e.    d                    Won-
D4     1        s     d                    der-
D4     4        q     d                    ful,
rest   8        h
measure 50
G4     3        e.    d                    Coun-
D4     1        s     d                    sel-
D4     4        q     d                    lor,
rest   8        h
measure 51
rest   2        e
B3     2        e     d                    the
B3     2        e     d                    migh-
B3     2        e     d                    ty
D4     4        q     d                    God,
rest   2        e
B3     2        e     d                    the
measure 52
B3     2        e     d                    e-
B3     2        e     d                    ver-
D4     2        e     d                    last-
D4     2        e     d                    ing
E4     2        e     d                    Fa-
E4     2        e     d                    ther,
rest   2        e
D4     2        e     d                    the
measure 53
E4     6        q.    d                    Price
C4     2        e     d                    of
D4     4        q     d                    Peace.
G3     2        e     u                    Un-
G3     2        e     u                    to
measure 54
C4     2        e     d                    us
C4     2        e     d                    a
C4     2        e     d                    child
C4     2        e     d                    is
C4     2        e     d  [                 born,_
B3     2        e     d  ]                 _
rest   4        q
measure 55
rest  16
measure 56
rest  16
measure 57
rest  16
measure 58
rest  16
measure 59
rest   8        h
rest   4        q
E4     2        e     d                    un-
D4     2        e     d                    to
measure 60
C4     4        q     d                    us
rest   4        q
rest   2        e
B3     2        e     d                    a
C4     2        e     d                    son
C4     2        e     d                    is
measure 61
D4     2        e     d                    gi-
D4     2        e     d                    ven,
G3     3        e.    u                    and
B3     1        s     u                    the
A3     3        e.    u                    go-
C4     1        s     d                    vern-
B3     3        e.    d                    ment
D4     1        s     d                    shall
measure 62
C4     3        e.    d                    be,
E4     1        s     d                    shall
D4     3        e.    d                    be
F4     1        s     d                    up-
E4     1        s     d  [[                on_
D4     1        s     d  =]                _
C4     2        e     d  =                 _
E4     2        e     d  ]                 _
F#4    2        e     d                    his
measure 63
G4     4        q     d                    shoul-
G3     4        q     u                    der,
rest   8        h
measure 64
rest  16
measure 65
rest  16
measure 66
rest   8        h
rest   4        q
D4     2        e     d                    and
D4     2        e     d                    his
measure 67
E4     4        q     d                    name
C4     2        e     d                    shall
B3     2        e     d                    be
C4     2        e     d                    cal-
C4     2        e     d                    led,
rest   4        q
measure 68
E4     3        e.    d                    Won-
D4     1        s     d                    der-
C4     4        q     d                    ful,
rest   8        h
measure 69
E4     3        e.    d                    Coun-
D4     1        s     d                    sel-
C4     4        q     d                    lor,
rest   8        h
measure 70
rest   2        e
C4     2        e     d                    the
C4     2        e     d                    migh-
C4     2        e     d                    ty
E4     4        q     d                    God,
rest   2        e
E4     2        e     d                    the
measure 71
E4     2        e     d                    e-
E4     2        e     d                    ver-
E4     2        e     d                    last-
E4     2        e     d                    ing
A3     4        q     u                    Fa-
B3     2        e     d  [                 ther,_
C4     2        e     d  ]                 _
measure 72
D4     6        q.    d                    Prince
D4     2        e     d                    of
D4     4        q     d                    Peace.
rest   4        q
measure 73
rest   8        h
D4     4        q     d                    For
D4     2        e     d                    un-
D4     2        e     d                    to
measure 74
E4     2        e     d                    us
E4     2        e     d                    a
D4     2        e     d                    child
D4     2        e     d                    is
D4     4        q     d                    born,
D4     2        e     d                    un-
D4     2        e     d                    to
measure 75
E4     4        q     d                    us
rest   4        q
rest   2        e
E4     2        e     d                    a
E4     2        e     d                    son
E4     2        e     d                    is
measure 76
F#4    2        e     d                    gi-
F#4    2        e     d                    ven,
rest   4        q
rest   4        q
F#4    2        e     d                    un-
F#4    2        e     d                    to
measure 77
G4     4        q     d                    us
rest   2        e
E4     2        e     d                    a
C4     6        q.    d                    son
D4     2        e     d                    is
measure 78
D4     2        e     d                    gi-
D4     2        e     d                    ven,
D4     2        e     d                    un-
F#4    2        e     d                    to
D4     4        q     d                    us
rest   4        q
measure 79
rest   2        e
E4     2        e     d                    a
E4     2        e     d                    son
E4     2        e     d                    is
A3     2        e     u                    gi-
A3     2        e     u                    ven,
rest   4        q
measure 80
rest  16
measure 81
rest   8        h
rest   4        q
F#3    3        e.    u                    and
A3     1        s     u                    the
measure 82
G3     3        e.    u                    go-
B3     1        s     u                    vern-
A3     3        e.    u                    ment,
C4     1        s     d                    the
B3     3        e.    d                    go-
D4     1        s     d                    vern-
C4     3        e.    d                    ment
E4     1        s     d                    shall
measure 83
D4     3        e.    d                    be
B3     1        s     d                    up-
E4     3        e.    d                    on
E4     1        s     d                    his
F#4    2        e     d                    shoul-
D4     2        e     d                    der,
D4     2        e     d                    and
G4     2        e     d                    his
measure 84
F#4    4        q     d                    name
D4     2        e     d                    shall
G4     2        e     d                    be
F#4    2        e     d                    cal-
F#4    2        e     d                    led,
rest   4        q
measure 85
G4     3        e.    d                    Won-
D4     1        s     d                    der-
D4     4        q     d                    ful,
rest   8        h
measure 86
G4     3        e.    d                    Coun-
D4     1        s     d                    sel-
D4     4        q     d                    lor,
rest   8        h
measure 87
rest   2        e
B3     2        e     d                    the
B3     2        e     d                    migh-
B3     2        e     d                    ty
D4     4        q     d                    God,
rest   2        e
D4     2        e     d                    the
measure 88
E4     2        e     d                    e-
E4     2        e     d                    ver-
E4     2        e     d                    last-
E4     2        e     d                    ing
A3     2        e     u                    Fa-
A3     2        e     u                    ther,
rest   2        e
E4     2        e     d                    the
measure 89
A3     6        q.    u                    Prince
D4     2        e     d                    of
D4     4        q     d                    Peace,
rest   2        e
D4     2        e     d                    the
measure 90
E4     2        e     d                    e-
B3     2        e     d                    ver-
C4     2        e     d                    last-
E4     2        e     d                    ing
D4     2        e     d                    Fa-
D4     4        q     d                    ther,
E4     2        e     d                    the
measure 91
D4     6        q.    d                    Prince
C4     2        e     d                    of
B3     8        h     d                    Peace.
measure 92
rest  16
measure 93
rest  16
measure 94
rest  16
measure 95
rest  16
measure 96
rest  16
measure 97
rest  16
measure 98
rest  16
measure 99
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/7} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:bbc42706f693141e32715ab279e0635f]
07/09/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:22   D:Andante allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
A3     4        q     d                    For
D3     2        e     u                    un-
D3     2        e     u                    to
measure 20
G3     2        e     d                    us
G3     2        e     d                    a
G3     2        e     d                    child
G3     2        e     d                    is
F#3    1        s     d  [[                born,_
E3     1        s     d  ==                _
F#3    1        s     d  ==                _
G3     1        s     d  ]]                _
F#3    1        s     d  [[                _
G3     1        s     d  ==                _
E3     1        s     d  ==                _
F#3    1        s     d  ]]                _
measure 21
D3     1        s     d  [[                _
C#3    1        s     d  ==                _
D3     1        s     d  ==                _
E3     1        s     d  ]]                _
D3     1        s     d  [[                _
F#3    1        s     d  ==                _
E3     1        s     d  ==                _
F#3    1        s     d  ]]                _
G3     1        s     d  [[                _
F#3    1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
G3     1        s     d  [[                _
A3     1        s     d  ==                _
F#3    1        s     d  ==                _
G3     1        s     d  ]]                _
measure 22
E3     1        s     d  [[                _
D3     1        s     d  ==                _
E3     1        s     d  ==                _
F#3    1        s     d  ]]                _
E3     1        s     d  [[                _
G3     1        s     d  ==                _
F#3    1        s     d  ==                _
G3     1        s     d  ]]                _
A3     1        s     d  [[                _
G3     1        s     d  ==                _
A3     1        s     d  ==                _
B3     1        s     d  ]]                _
A3     1        s     d  [[                _
B3     1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
measure 23
F#3    1        s     d  [[                _
E3     1        s     d  ==                _
F#3    1        s     d  ==                _
G3     1        s     d  ]]                _
F#3    1        s     d  [[                _
A3     1        s     d  ==                _
G3     1        s     d  ==                _
A3     1        s     d  ]]                _
B3     1        s     d  [[                _
A3     1        s     d  ==                _
B3     1        s     d  ==                _
C#4    1        s     d  ]]                _
B3     1        s     d  [[                _
C#4    1        s     d  ==                _
D4     1        s     d  ==                _
E4     1        s     d  ]]                _
measure 24
C#4    4        q     d                    _
E4     2        e     d                    un-
C#4    2        e     d                    to
A3     4        q     d                    us,
rest   4        q
measure 25
rest   2        e
D4     2        e     d                    a
B3     2        e     d                    son
G3     2        e     d                    is
E3     2        e     d                    gi-
E3     2        e     d                    ven,
rest   4        q
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest   4        q
A2     3        e.    u                    and
C#3    1        s     u                    the
B2     3        e.    u                    go-
D3     1        s     u                    vern-
C#3    3        e.    u                    ment
E3     1        s     d                    shall
measure 31
D3     3        e.    u                    be
F#3    1        s     d                    up-
E3     3        e.    d                    on
G3     1        s     d                    his
F#3    3        e.    d                    shoul-
A3     1        s     d                    der,
G3     3        e.    d                    and
B3     1        s     d                    his
measure 32
A3     4        q     d                    name
F#3    2        e     d                    shall
D3     2        e     u                    be
A3     2        e     d                    cal-
A2     2        e     u                    led,
rest   4        q
measure 33
D4     3        e.    d                    Won-
D3     1        s     u                    der-
D3     4        q     u                    ful,
rest   8        h
measure 34
D4     3        e.    d                    Coun-
D3     1        s     u                    sel-
D3     4        q     u                    lor,
rest   8        h
measure 35
rest   2        e
D3     2        e     u                    the
D3     2        e     u                    migh-
D3     2        e     u                    ty
D4     4        q     d                    God,
rest   2        e
D4     2        e     d                    the
measure 36
B3     2        e     d                    e-
B3     2        e     d                    ver-
G3     2        e     d                    last-
G3     2        e     d                    ing
D4     2        e     d                    Fa-
D4     2        e     d                    ther,
rest   2        e
F#3    2        e     d                    the
measure 37
G3     4        q     d                    Prince
A3     4        q     d                    of
D3     4        q     u                    Peace.
rest   4        q
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest   4        q
B3     2        e     d                    Un-
G3     2        e     d                    to
E3     2        e     d                    us
C4     2        e     d                    a
A3     2        e     d                    son
F#3    2        e     d                    is
measure 43
D3     2        e     u                    gi-
D3     2        e     u                    ven,
rest   4        q
rest   8        h
measure 44
rest  16
measure 45
rest   4        q
D3     3        e.    u                    and
F#3    1        s     d                    the
E3     3        e.    d                    go-
G3     1        s     d                    vern-
F#3    3        e.    d                    ment
A3     1        s     d                    shall
measure 46
G3     3        e.    d                    be
B3     1        s     d                    up-
A3     3        e.    d                    on
C4     1        s     d                    his
B3     2        e     d  [                 shoul-
C4     1        s     d  =[                -
B3     1        s     d  ]]                -
A3     2        e     d  [                 -
G3     2        e     d  ]                 -
measure 47
F#3    4        q     d                    -
D3     4        q     u                    der,
rest   4        q
B3     2        e     d                    and
G3     2        e     d                    his
measure 48
D4     4        q     d                    name
B3     2        e     d                    shall
G3     2        e     d                    be
D4     2        e     d                    cal-
D3     2        e     u                    led,
rest   4        q
measure 49
G3     3        e.    d                    Won-
G3     1        s     d                    der-
G3     4        q     d                    ful,
rest   8        h
measure 50
G3     3        e.    d                    Coun-
G3     1        s     d                    sel-
G3     4        q     d                    lor,
rest   8        h
measure 51
rest   2        e
G3     2        e     d                    the
G3     2        e     d                    migh-
G3     2        e     d                    ty
B3     4        q     d                    God,
rest   2        e
G3     2        e     d                    the
measure 52
G3     2        e     d                    e-
G3     2        e     d                    ver-
G3     2        e     d                    last-
G3     2        e     d                    ing
C4     2        e     d                    Fa-
C4     2        e     d                    ther,
rest   2        e
B3     2        e     d                    the
measure 53
A3     6        q.    d                    Prince
A3     2        e     d                    of
G3     4        q     d                    Peace.
rest   4        q
measure 54
rest  16
measure 55
rest   8        h
G3     4        q     d                    For
C3     2        e     u                    un-
C3     2        e     u                    to
measure 56
F3     2        e     d                    us
F3     2        e     d                    a
F3     2        e     d                    child
F3     2        e     d                    is
F3     2        e     d  [                 born,_
E3     2        e     d  ]                 _
rest   4        q
measure 57
rest   8        h
rest   4        q
C4     2        e     d                    un-
B3     2        e     d                    to
measure 58
A3     4        q     d                    us
rest   4        q
rest   2        e
A3     2        e     d                    a
D4     2        e     d                    son
C4     2        e     d                    is
measure 59
B3     2        e     d                    gi-
B3     2        e     d                    ven,
rest   4        q
rest   8        h
measure 60
rest  16
measure 61
rest  16
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest   4        q
G3     3        e.    d                    and
B3     1        s     d                    the
A3     3        e.    d                    go-
C4     1        s     d                    vern-
B3     3        e.    d                    ment
D4     1        s     d                    shall
measure 66
C4     3        e.    d                    be
E3     1        s     d                    up-
A3     3        e.    d                    on
C4     1        s     d                    his
B3     2        e     d                    shoul-
G3     2        e     d                    der,
B3     2        e     d                    and
B3     2        e     d                    his
measure 67
C4     4        q     d                    name
E3     2        e     d                    shall
G3     2        e     d                    be
C4     2        e     d                    cal-
C3     2        e     u                    led,
rest   4        q
measure 68
C4     3        e.    d                    Won-
C3     1        s     u                    der-
C3     4        q     u                    ful,
rest   8        h
measure 69
C4     3        e.    d                    Coun-
C3     1        s     u                    sel-
C3     4        q     u                    lor,
rest   8        h
measure 70
rest   2        e
C3     2        e     u                    the
C3     2        e     u                    migh-
C3     2        e     u                    ty
C4     4        q     d                    God,
rest   2        e
C4     2        e     d                    the
measure 71
C4     2        e     d                    e-
C4     2        e     d                    ver-
C4     2        e     d                    last-
C4     2        e     d                    ing
D3     4        q     u                    Fa-
G3     4        q     d                    ther,
measure 72
D3     6        q.    u                    Prince
D3     2        e     u                    of
G3     4        q     d                    Peace.
G3     2        e     d                    Un-
G3     2        e     d                    to
measure 73
C4     2        e     d                    us
C4     2        e     d                    a
C4     2        e     d                    child
C4     2        e     d                    is
C4     2        e     d  [                 born,_
B3     2        e     d  ]                 _
B3     2        e     d                    un-
B3     2        e     d                    to
measure 74
A3     2        e     d                    us
A3     2        e     d                    a
D3     2        e     u                    child
D3     2        e     u                    is
G3     4        q     d                    born,
G3     2        e     d                    un-
G3     2        e     d                    to
measure 75
C4     4        q     d                    us
rest   4        q
rest   2        e
A3     2        e     d                    a
A3     2        e     d                    son
A3     2        e     d                    is
measure 76
D4     2        e     d                    gi-
D4     2        e     d                    ven,
rest   4        q
rest   4        q
B3     2        e     d                    un-
D3     2        e     u                    to
measure 77
E3     4        q     d                    us
rest   2        e
E3     2        e     d                    a
A3     6        q.    d                    son
G3     2        e     d                    is
measure 78
D4     2        e     d                    gi-
D4     2        e     d                    ven,
F#3    2        e     d                    un-
D3     2        e     d                    to
G3     4        q     d                    us
rest   4        q
measure 79
rest   2        e
C3     2        e     u                    a
C3     2        e     u                    son
C3     2        e     u                    is
D3     2        e     u                    gi-
D3     2        e     u                    ven,
rest   4        q
measure 80
rest  16
measure 81
rest   8        h
rest   4        q
D3     3        e.    d                    and
F#3    1        s     d                    the
measure 82
E3     3        e.    d                    go-
G3     1        s     d                    vern-
F#3    3        e.    d                    ment,
A3     1        s     d                    the
G3     3        e.    d                    go-
B3     1        s     d                    vern-
A3     3        e.    d                    ment
C4     1        s     d                    shall
measure 83
B3     3        e.    d                    be
G3     1        s     d                    up-
C4     3        e.    d                    on
A3     1        s     d                    his
D4     2        e     d                    shoul-
D3     2        e     u                    der,
B3     2        e     d                    and
G3     2        e     d                    his
measure 84
D4     4        q     d                    name
B3     2        e     d                    shall
G3     2        e     d                    be
D4     2        e     d                    cal-
D3     2        e     u                    led,
rest   4        q
measure 85
G3     3        e.    d                    Won-
G3     1        s     d                    der-
G3     4        q     d                    ful,
rest   8        h
measure 86
G3     3        e.    d                    Coun-
G3     1        s     d                    sel-
G3     4        q     d                    lor,
rest   8        h
measure 87
rest   2        e
G3     2        e     d                    the
G3     2        e     d                    migh-
G3     2        e     d                    ty
B3     4        q     d                    God,
rest   2        e
B2     2        e     u                    the
measure 88
C3     2        e     u                    e-
C3     2        e     u                    ver-
C3     2        e     u                    last-
C3     2        e     u                    ing
D3     2        e     u                    Fa-
D3     2        e     u                    ther,
rest   2        e
C3     2        e     u                    the
measure 89
D3     6        q.    u                    Prince
D3     2        e     u                    of
G3     4        q     d                    Peace,
rest   2        e
G3     2        e     d                    the
measure 90
C4     2        e     d                    e-
B3     2        e     d                    ver-
A3     2        e     d                    last-
G3     2        e     d                    ing
F#3    2        e     d                    Fa-
G3     4        q     d                    ther,
C3     2        e     u                    the
measure 91
D3     6        q.    u                    Prince
D3     2        e     u                    of
G2     8        h     u                    Peace.
measure 92
rest  16
measure 93
rest  16
measure 94
rest  16
measure 95
rest  16
measure 96
rest  16
measure 97
rest  16
measure 98
rest  16
measure 99
rest  16
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-13/8} [KHM:1436298264]
TIMESTAMP: DEC/26/2001 [md5sum:13bd17f8ee7191b3891265bdbc02b4aa]
07/09/90 E. Correia
WK#:56        MV#:1,13
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:22   D:Andante allegro
G3     2        e     d  [
A3     2        e     d  =
f1              6
B3     2        e     d  =
B2     2        e     d  ]
A2     2        e     d  [
G3     2        e     d  =
f2              6 5
F#3    2        e     d  =
D3     2        e     d  ]
measure 2
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
B2     2        e     d  ]
A2     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 3
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
C3     4        q     u
rest   4        q
measure 4
A2     4        q     u
rest   4        q
D3     4        q     u
rest   4        q
measure 5
B2     4        q     u
rest   4        q
E3     4        q     d
C3     2        e     u  [
A2     2        e     u  ]
measure 6
D3     2        e     u  [
B2     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]
D3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
D2     2        e     u  ]
measure 7
G3     2        e     d  [
*               G +     p
A3     2        e     d  =
B3     2        e     d  =
B2     2        e     d  ]
A2     2        e     d  [
G3     2        e     d  =
f2              6 5
F#3    2        e     d  =
D3     2        e     d  ]
measure 8
G3     4        q     d
rest   4        q
rest   2        e
G3     2        e     d  [
B3     2        e     d  =
G3     2        e     d  ]
measure 9
C4     4        q     d
rest   4        q
rest   2        e
A2     2        e     u  [
C3     2        e     u  =
A2     2        e     u  ]
measure 10
D3     4        q     u
rest   4        q
rest   2        e
B2     2        e     u  [
D3     2        e     u  =
B2     2        e     u  ]
measure 11
E3     4        q     d
rest   4        q
rest   2        e
E3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  ]
measure 12
F#3    2        e     d  [
D3     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]
B3     4        q     d
B2     2        e     u  [
E3     2        e     u  ]
measure 13
A2     2        e     u  [
G3     2        e     u  =
F#3    2        e     u  =
D3     2        e     u  ]
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
measure 14
A2     2        e     u  [
G3     2        e     u  =
F#3    2        e     u  =
D3     2        e     u  ]
G3     4        q     d
G2     2        e     u  [
B2     2        e     u  ]
measure 15
C3     4        q     u
rest   4        q
A2     4        q     u
rest   4        q
measure 16
D3     4        q     u
rest   4        q
B2     4        q     u
rest   4        q
measure 17
E3     4        q     d
rest   4        q
C3     4        q     u
rest   4        q
measure 18
D3     4        q     d
rest   2        e
E3     2        e     d
F#3    2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
B3     2        e     d  ]
measure 19
E3     4        q     d
rest   2        e
E3     2        e     d
D3     4        q     u
F#2    2        e     u  [
B2     2        e     u  ]
measure 20
E2     2        e     u  [
D3     2        e     u  =
C#3    2        e     u  =
A2     2        e     u  ]
D3     4        q     u
rest   4        q
measure 21
G2     4        q     u
rest   4        q
E2     4        q     u
rest   4        q
measure 22
f1              #
A2     4        q     u
rest   4        q
F#2    4        q     u
rest   4        q
measure 23
B2     4        q     u
rest   4        q
G2     4        q     u
rest   4        q
measure 24
A2     2        e     d  [
E3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
F#3    2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 25
G3     2        e     d  [
B2     2        e     d  =
D3     2        e     d  =
B2     2        e     d  ]
G2     2        e     d  [
G3     2        e     d  =
E3     2        e     d  =
G3     2        e     d  ]
measure 26
A3     4        q     d
F#3    4        q     d
G3     4        q     d
f1              6+
E3     4        q     d
measure 27
F#3    4        q     d
C#3    4        q     u
D3     4        q     u
f1              6+
E3     4        q     d
measure 28
f1              6
F#3    2        e     d  [
D3     2        e     d  ]
f1              #
A3     4-       q     d        -
f2              4 2
A3     4        q     d
f2              4+ 2
G3     4        q     d
measure 29
f1              6
F#3    4        q     d
C#3    4        q     u
D3     4        q     u
E3     4        q     d
measure 30
C#3    4        q     u
A2     3        e.    u  [
C#3    1        s     u  ]\
B2     3        e.    u  [
D3     1        s     u  =\
C#3    3        e.    u  =
E3     1        s     u  ]\
measure 31
D3     3        e.    d  [
F#3    1        s     d  =\
E3     3        e.    d  =
G3     1        s     d  ]\
F#3    3        e.    d  [
A3     1        s     d  =\
G3     3        e.    d  =
B3     1        s     d  ]\
measure 32
f1              #
A3     4        q     d
F#3    2        e     d  [
D3     2        e     d  ]
A3     2        e     d  [
A2     2        e     d  ]
rest   4        q
measure 33
D4     3        e.    d  [      &f
D3     1        s     d  ]\
D3     4        q     u
rest   8        h
measure 34
D4     3        e.    d  [
D3     1        s     d  ]\
D3     4        q     u
rest   8        h
measure 35
rest   2        e
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  ]
D4     4        q     d
rest   2        e
D4     2        e     d
measure 36
B3     2        e     d  [
B3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
D4     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 37
G3     4        q     d
A3     4        q     d
D3     4        q     u
rest   2        e
F#3    2        e     d         p
measure 38
E3     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  =
A3     2        e     d  ]
D3     4        q     u
B2     2        e     u  [
G2     2        e     u  ]
measure 39
A2     2        e     u  [
G3     2        e     u  =
F#3    2        e     u  =
D3     2        e     u  ]
G3     4        q     d
G2     4        q     u
measure 40
C3     4        q     u
rest   4        q
A2     4        q     u
rest   4        q
measure 41
D3     4        q     u
B2     4        q     u
E3     2        e     u  [
C3     2        e     u  =
A2     2        e     u  =
C3     2        e     u  ]
measure 42
D3     4        q     u
G2     4        q     u
C3     6        q.    u
A2     2        e     u
measure 43
B2     2        e     u  [
G2     2        e     u  ]
f1     4        b
f2              4 2
D3     8        h     u
f2              4 2
C3     4        q     u
measure 44
f1              6
B2     4        q     u
F#3    4        q     d
G3     2        e     u  [
G2     2        e     u  ]
A2     4        q     u
measure 45
B2     2        e     u  [
G2     2        e     u  ]
f1     4        #
f2              4 2
D3     8        h     u
f2              4 2
C3     4        q     u
measure 46
B2     4        q     u
F#2    4        q     u
G2     4        q     u
C3     4        q     u
measure 47
D3     4        q     u
D2     4        q     u
G2     4        q     u
B3     2        e     d  [
G3     2        e     d  ]
measure 48
D4     4        q     d
B3     2        e     d  [
G3     2        e     d  ]
D4     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 49
G3     3        e.    d  [      &f
G2     1        s     u  ]\
G2     4        q     u
rest   8        h
measure 50
G3     3        e.    d  [
G2     1        s     u  ]\
G2     4        q     u
rest   8        h
measure 51
rest   2        e
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  ]
f1              6
B3     4        q     d
rest   2        e
G3     2        e     d
measure 52
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
C4     2        e     d  [
C3     2        e     d  ]
rest   2        e
B3     2        e     d
measure 53
A3     6        q.    d
A3     2        e     d
G3     4        q     d
B2     2        e     u  [      p
E3     2        e     u  ]
measure 54
A2     2        e     u  [
G3     2        e     u  =
F#3    2        e     u  =
D3     2        e     u  ]
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
B2     2        e     d  ]
measure 55
A2     2        e     u  [
G3     2        e     u  =
F#3    2        e     u  =
D3     2        e     u  ]
G3     4        q     d
C3     2        e     u  [
C3     2        e     u  ]
measure 56
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 57
D3     4        q     u
rest   2        e
G3     2        e     d
C3     4        q     u
rest   4        q
measure 58
F3     4        q     d
rest   4        q
f1              n
D3     4        q     u
rest   4        q
measure 59
G3     4        q     d
rest   4        q
E3     4        q     d
rest   4        q
measure 60
A3     4        q     d
rest   4        q
A2     4        q     u
rest   2        e
C3     2        e     u
measure 61
D3     4        q     u
B2     4        q     u
F#2    4        q     u
G2     4        q     u
measure 62
E3     4        q     d
B2     4        q     u
C3     4        q     u
A2     4        q     u
measure 63
G2     4        q     u
G3     4        q     d
F3     4        q     d
D3     4        q     u
measure 64
E3     4        q     d
B2     4        q     u
C3     4        q     u
A2     4        q     u
measure 65
B2     4        q     u
G2     4        q     u
A2     4        q     u
B2     4        q     u
measure 66
C3     4        q     u
F3     4        q     d
G3     4        q     d
B3     4        q     d
measure 67
C4     2        e     d  [
C3     2        e     d  =
E3     2        e     d  =
G3     2        e     d  ]
C4     2        e     d  [
C3     2        e     d  ]
rest   4        q
measure 68
C4     3        e.    d  [
C3     1        s     u  ]\
C3     4        q     u
rest   8        h
measure 69
C4     3        e.    d  [
C3     1        s     u  ]\
C3     4        q     u
rest   8        h
measure 70
rest   2        e
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  ]
C4     4        q     d
rest   2        e
C4     2        e     d
measure 71
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
D3     4        q     u
G2     4        q     u
measure 72
D3     6        q.    u
D3     2        e     u
G2     4        q     u
G3     2        e     d  [
G3     2        e     d  ]
measure 73
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
C4     2        e     d  [
B3     2        e     d  =
f1              6
B3     2        e     d  =
B3     2        e     d  ]
measure 74
A3     2        e     d  [
A3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
G3     4        q     d
G3     2        e     d  [
G3     2        e     d  ]
measure 75
C4     4        q     d
rest   4        q
rest   2        e
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  ]
measure 76
D4     2        e     d  [
D3     2        e     d  ]
rest   4        q
rest   4        q
B3     2        e     d  [
D3     2        e     d  ]
measure 77
E3     4        q     d
rest   2        e
E3     2        e     d
A3     6        q.    d
G3     2        e     d
measure 78
D4     2        e     d  [
D3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
measure 79
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
D3     2        e     u  [
D3     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
measure 80
F#3    2        e     d  [
D3     2        e     d  ]
G3     4        q     d
C3     4        q     u
D3     4        q     u
measure 81
G2     4        q     u
C3     4        q     u
D3     4        q     u
D3     3        e.    d  [
F#3    1        s     d  ]\
measure 82
E3     3        e.    d  [
G3     1        s     d  =\
F#3    3        e.    d  =
A3     1        s     d  ]\
G3     3        e.    d  [
B3     1        s     d  =\
A3     3        e.    d  =
C4     1        s     d  ]\
measure 83
f1              6
B3     3        e.    d  [
G3     1        s     d  =\
C4     3        e.    d  =
A3     1        s     d  ]\
D4     2        e     d  [
D3     2        e     d  =
B2     2        e     d  =
G2     2        e     d  ]
measure 84
D3     2        e     d  [
D4     2        e     d  =
B3     2        e     d  =
G3     2        e     d  ]
D4     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 85
G3     3        e.    d  [
G2     1        s     u  ]\
G2     4        q     u
rest   8        h
measure 86
G3     3        e.    d  [
G2     1        s     u  ]\
G2     4        q     u
rest   8        h
measure 87
rest   2        e
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  ]
B3     4        q     d
rest   2        e
B2     2        e     u
measure 88
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
C3     2        e     u
measure 89
D3     6        q.    u
D3     2        e     u
G3     4        q     d
rest   2        e
G3     2        e     d
measure 90
C4     2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
F#3    2        e     d
G3     4        q     d
C3     2        e     u
measure 91
D3     4        q     u
D2     4        q     u
G2     8        h     u
measure 92
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
B2     2        e     d  ]
A2     2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
D3     2        e     d  ]
measure 93
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
E3     2        e     u  ]
A2     2        e     d  [
A3     2        e     d  =
D4     2        e     d  =
D3     2        e     d  ]
measure 94
G3     2        e     u  [
G2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
C3     2        e     u  [
B2     2        e     u  =
C3     2        e     u  =
E3     2        e     u  ]
measure 95
A2     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
C4     2        e     d  ]
D4     4        q     d
D3     4        q     u
measure 96
rest   2        e
B3     2        e     d  [
C4     2        e     d  =
D4     2        e     d  ]
E4     4        q     d
E3     2        e     d  [
G3     2        e     d  ]
measure 97
A3     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
C3     2        e     d  ]
D3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
B2     2        e     u  ]
measure 98
E3     2        e     u  [
D3     2        e     u  =
E3     2        e     u  =
A2     2        e     u  ]
D3     4        q     u
G3     2        e     d  [
C3     2        e     d  ]
measure 99
D3     4        q     u
D2     4        q     u
G2     8        h     u
mheavy2
/END
/eof
