&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/01} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:1adee4d26fe230b5177e7c09d5d88f19]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba I
1 23
Group memberships: score
score: part 1 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 15
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 16
A5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
A5     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   4        q
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 20
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
measure 21
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
D5     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
measure 22
F#4    4        q     u
rest   4        q
rest   8        h
measure 23
rest  16
measure 24
rest  16
measure 25
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
E5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
D5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
A5     1        s     d  =[
G5     1        s     d  ]]
measure 26
F#5    4        q     d
rest   2        e
F#5    2        e     d
G#5    4        q     d
A5     4-       q     d        -
measure 27
A5     2        e     d  [
A5     2        e     d  ]
G#5    4        q     d
A5     4        q     d
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 28
A5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
F#5    1        s     d  [[
F#5    1        s     d  ]]
E5     2        e     d  [
E5     2        e     d  ]
rest   4        q
measure 29
D5     8        h     d
E5     4        q     d
F#5    4        q     d
measure 30
G5     4        q     d
G5     8        h     d
F#5    4        q     d
measure 31
E5     8        h     d
D5     8-       h     d        -
measure 32
D5     8        h     d
rest   2        e
F#5    1        s     d  [[
F#5    1        s     d  ]]
F#5    2        e     d  [
F#5    2        e     d  ]
measure 33
G5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
A4     4        q     u
rest   4        q
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
A5     4        q     d
measure 38
A5     4        q     d
G5     4        q     d
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
measure 39
D5     6        q.    d
E5     2        e     d
F#5    4        q     d
G#5    4        q     d
measure 40
A5     6        q.    d
A5     2        e     d
D5     4        q     d
G5     4        q     d         +
measure 41
F#5    8        h     d
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest   4        q
rest   2        e
E5     2        e     d
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 53
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 54
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
A5     4        q     d
A5     8-       h     d        -
measure 56
A5    16-       w     d        -
measure 57
A5     4-       q     d        -
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     4        q     d
D5     4        q     d
measure 58
D5    16-       w     d        -
measure 59
D5    16-       w     d        -
measure 60
D5     4        q     d
D5     4        q     d
E5     4        q     d
E5     4        q     d
measure 61
E5    16-       w     d        -
measure 62
E5    16-       w     d        -
measure 63
E5     8        h     d
F#5    4        q     d
F#5    4        q     d
measure 64
F#5   16-       w     d        -
measure 65
F#5   16-       w     d        -
measure 66
F#5    6        q.    d
F#5    2        e     d
G5     4        q     d
G5     4        q     d
measure 67
G5    16-       w     d        -
measure 68
G5     6        q.    d
G5     2        e     d
F#5    2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
measure 69
E5     8        h     d
rest   8        h
measure 70
rest  16
measure 71
rest  16
measure 72
rest  16
measure 73
rest  16
measure 74
rest   8        h
D4     4        q     u
D4     4        q     u
measure 75
D4    16-       w     u        -
measure 76
D4     6        q.    u
D4     2        e     u
D4     4        q     u
D4     4        q     u
measure 77
D4    16-       w     u        -
measure 78
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
F#4    2        e     u  [
A4     2        e     u  ]
D5     4        q     d
A5     4        q     d
measure 79
D6     4        q     d
F#5    4        q     d
B5     4        q     d
D5     4        q     d
measure 80
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
E5     6        q.    d
D5     2        e     d
measure 81
D5     4        q     d
rest   4        q
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
measure 82
A5     4        q     d
rest   2        e
A5     2        e     d
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
measure 83
A5     4        q     d
rest   4        q
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
measure 84
A5     4        q     d
rest   2        e
A5     2        e     d
F#5    4        q     d
F#5    3        e.    d  [
G5     1        s     d  ]\
measure 85
A5     4        q     d
rest   4        q
rest   4        q
A4     4        q     u
measure 86
D5     4        q     d
F#5    4        q     d
B5     4        q     d
D5     4        q     d
measure 87
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
E5     6        q.    d
D5     2        e     d
measure 88
D5     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
F#4    2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
D5     4        q     d
D5     4        q     d
measure 89
D5     2        e     d  [
F#5    2        e     d  =
A5     2        e     d  =
F#5    2        e     d  ]
D5     4        q     d
D5     4        q     d
measure 90
D5     2        e     d  [
F#5    2        e     d  =
A5     2        e     d  =
F#5    2        e     d  ]
D5     4        q     d
D5     4        q     d
measure 91
D5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
F#5    2        e     d  ]
D5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
measure 92
D5     2        e     d  [
D5     2        e     d  ]
rest   4        q
rest   4        q
F#5    4        q     d
measure 93
D5    12        h.    d
D5     4        q     d
measure 94
D5    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/02} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:b0a1bfcf17875afe5cd22e9b2edcc2e0]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba II
1 23
Group memberships: score
score: part 2 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 15
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 16
F#5    2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
E5     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     u  [
A4     2        e     u  ]
rest   4        q
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   4        q
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
measure 20
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
F#4    1        s     u  [[
F#4    1        s     u  ]]
measure 21
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
A4     2        e     u  [
F#4    1        s     u  =[
F#4    1        s     u  ]]
F#4    2        e     u  [
F#4    1        s     u  =[
F#4    1        s     u  ]]
F#4    2        e     u  [
F#4    1        s     u  =[
F#4    1        s     u  ]]
measure 22
D4     4        q     u
rest   4        q
rest   8        h
measure 23
rest  16
measure 24
rest  16
measure 25
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
F#4    2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
A4     2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
measure 26
A4     4        q     u
rest   2        e
D5     2        e     d
E5     6        q.    d
E5     2        e     d
measure 27
D5     2        e     d  [
A4     2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
E5     4        q     d
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 28
D5     2        e     d  [
A4     2        e     d  ]
rest   2        e
F#4    1        s     u  [[
F#4    1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
rest   4        q
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
measure 33
D5     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
F#4    4        q     u
rest   4        q
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
F#5    4        q     d
measure 38
E5     4        q     d
D5     4        q     d
D5     4        q     d
A4     4        q     u
measure 39
A4     6        q.    u
E5     2        e     d
A4     4        q     u
D5     4        q     d
measure 40
E5     6        q.    d
F#5    2        e     d
D5     4        q     d
E5     4        q     d
measure 41
A4     8        h     u
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest   4        q
rest   2        e
A4     2        e     u
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     2        e     u
measure 53
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 54
A4     2        e     u  [
A4     2        e     u  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
E5     2        e     d
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 56
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 57
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
rest   8        h
measure 58
rest  16
measure 59
rest  16
measure 60
rest  16
measure 61
rest  16
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest  16
measure 66
rest  16
measure 67
rest   8        h
D5     4        q     d
D5     4        q     d
measure 68
E5     6        q.    d
E5     2        e     d
D5     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 69
A4     8        h     u
rest   8        h
measure 70
rest  16
measure 71
rest  16
measure 72
rest  16
measure 73
rest  16
measure 74
rest   8        h
D4     4        q     u
D4     4        q     u
measure 75
D4    16-       w     u        -
measure 76
D4     6        q.    u
D4     2        e     u
D4     4        q     u
D4     4        q     u
measure 77
D4    16-       w     u        -
measure 78
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
F#4    4        q     u
D5     4        q     d
measure 79
F#5    4        q     d
D5     4        q     d
D5     4        q     d
D5     4        q     d
measure 80
E5     4        q     d
D5     2        e     d  [
A4     2        e     d  ]
A4     2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
measure 81
F#4    4        q     u
rest   4        q
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
measure 82
F#5    4        q     d
rest   2        e
F#5    2        e     d
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
measure 83
F#5    4        q     d
rest   4        q
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
measure 84
F#5    4        q     d
rest   2        e
F#5    2        e     d
D5     4        q     d
D5     3        e.    d  [
E5     1        s     d  ]\
measure 85
F#5    4        q     d
rest   4        q
rest   4        q
F#4    4        q     u
measure 86
F#4    2        e     u  [
D4     2        e     u  =
A4     2        e     u  =
F#4    2        e     u  ]
D5     4        q     d
A4     4        q     u
measure 87
E5     4        q     d
D5     2        e     d  [
A4     2        e     d  ]
A4     2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
A4     2        e     u  [
A4     2        e     u  ]
measure 88
F#4    4        q     u
rest   2        e
F#4    2        e     u
D4     2        e     u  [
D4     2        e     u  ]
rest   2        e
A4     2        e     u
measure 89
D4     2        e     d  [
D5     2        e     d  =
F#5    2        e     d  =
D5     2        e     d  ]
D4     4        q     u
D4     4        q     u
measure 90
D4     2        e     d  [
D5     2        e     d  =
F#5    2        e     d  =
D5     2        e     d  ]
D4     4        q     u
D4     4        q     u
measure 91
D4     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
D4     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 92
D4     2        e     u  [
F#4    2        e     u  ]
rest   4        q
rest   4        q
A4     4        q     u
measure 93
D4    12        h.    u
D4     4        q     u
measure 94
F#4   16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/03} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:5d305ab487ceb4b07cf259448c18cfca]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Timpani
1 23
Group memberships: score
score: part 3 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:4   T:1/1   C:22   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest  16
measure 8
rest  16
measure 9
rest  16
measure 10
rest  16
measure 11
rest  16
measure 12
rest  16
measure 13
rest  16
measure 14
rest   8        h
rest   4        q
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
measure 15
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
measure 16
D3     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
A2     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
D3     2        e     u  [
A2     2        e     u  ]
rest   4        q
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   4        q
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
measure 20
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
measure 21
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
measure 22
D3     4        q     u
rest   4        q
rest   8        h
measure 23
rest  16
measure 24
rest  16
measure 25
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
A2     2        e     u  [
A2     2        e     u  ]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
A2     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
measure 26
D3     2        e     u  [
A2     2        e     u  ]
D3     6        q.    u
D3     2        e     u
A2     4        q     u
measure 27
rest   2        e
D3     2        e     u  [
D3     3        e.    u  =
D3     1        s     u  ]\
A2     4        q     u
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
measure 28
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
A2     2        e     u  [
A2     2        e     u  ]
rest   4        q
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
measure 33
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
D3     4        q     u
rest   4        q
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
D3     4        q     u
measure 38
A2     4        q     u
D3     4        q     u
A2     6        q.    u
A2     2        e     u
measure 39
D3     6        q.    u
A2     2        e     u
D3     4        q     u
D3     4        q     u
measure 40
A2     6        q.    u
D3     2        e     u
D3     4        q     u
A2     4        q     u
measure 41
D3     8        h     u
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest   4        q
rest   2        e
A2     2        e     u
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 53
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
measure 54
D3     2        e     u  [
A2     2        e     u  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
A2     2        e     u
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 56
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     1        s     u  [[
A2     1        s     u  ]]
measure 57
D3     2        e     u  [
A2     2        e     u  ]
rest   4        q
rest   8        h
measure 58
rest  16
measure 59
rest  16
measure 60
rest  16
measure 61
rest  16
measure 62
rest  16
measure 63
rest  16
measure 64
rest  16
measure 65
rest  16
measure 66
rest  16
measure 67
rest   8        h
D3     4        q     u
D3     4        q     u
measure 68
A2     6        q.    u
A2     2        e     u
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
measure 69
A2     8        h     u
rest   8        h
measure 70
rest  16
measure 71
rest  16
measure 72
rest  16
measure 73
rest  16
measure 74
rest  16
measure 75
rest   4        q
rest   2        e
D3     2        e     u
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     2        e     u
measure 76
D3     2        e     u  [
D3     2        e     u  ]
rest   4        q
rest   8        h
measure 77
rest   4        q
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
measure 78
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
measure 79
D3     4        q     u
D3     3        e.    u  [
D3     1        s     u  ]\
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
measure 80
A2     4        q     u
D3     4        q     u
A2     6        q.    u
A2     2        e     u
measure 81
D3     4        q     u
rest   4        q
D3     4        q     u
D3     3        e.    u  [
D3     1        s     u  ]\
measure 82
D3     4        q     u
rest   2        e
D3     2        e     u
D3     4        q     u
D3     3        e.    u  [
D3     1        s     u  ]\
measure 83
D3     4        q     u
rest   4        q
D3     4        q     u
D3     4        q     u
measure 84
D3     4        q     u
rest   2        e
D3     2        e     u
D3     4        q     u
D3     3        e.    u  [
D3     1        s     u  ]\
measure 85
D3     4        q     u
rest   4        q
rest   4        q
D3     4        q     u
measure 86
D3     4        q     u
D3     4        q     u
D3     4        q     u
D3     4        q     u
measure 87
A2     4        q     u
D3     2        e     u  [
D3     2        e     u  ]
A2     6        q.    u
A2     2        e     u
measure 88
D3     4        q     u
rest   2        e
D3     2        e     u
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     2        e     u
measure 89
D3     4        q     u
rest   2        e
D3     2        e     u
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     2        e     u
measure 90
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
D3     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
measure 91
D3     4        q     u
rest   2        e
D3     1        s     u  [[
D3     1        s     u  ]]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
D3     2        e     u  [
D3     1        s     u  =[
D3     1        s     u  ]]
measure 92
D3     2        e     u  [
D3     2        e     u  ]
rest   4        q
rest   4        q
D3     4        q     u
measure 93
D3    12        h.    u
D3     4        q     u
measure 94
D3    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/04} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:cc1cd57e3190326e0e25261f1189a31b]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 4 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
D5     6        q.    d
A5     2        e     d
B5     2        e     d  [
A5     2        e     d  ]
rest   4        q
measure 2
D6     6        q.    d
F#5    2        e     d
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     2        e     d
measure 3
G5     2        e     d  [
F#5    2        e     d  ]
E5     4        q     d
D5     2        e     d  [
A4     2        e     d  =
B4     2        e     d  =
C#5    2        e     d  ]
measure 4
D5     4        q     d
rest   4        q
D5     6        q.    d
A4     2        e     u
measure 5
F#4    2        e     u  [
D4     2        e     u  ]
rest   4        q
D6     6        q.    d
A5     2        e     d
measure 6
D5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
measure 7
rest   4        q
rest   2        e
E5     2        e     d
F#5    2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  ]
measure 8
E5     4        q     d
rest   4        q
A5     6        q.    d
E5     2        e     d
measure 9
C#5    4        q     d
rest   4        q
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
measure 10
rest   2        e
C#6    1        s     d  [[
C#6    1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
C#6    1        s     d  [[
C#6    1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
measure 11
F#5    2        e     d
A5     4        q     d
G#5    2        e     d
A5     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
measure 12
A4     8        h     u
B4     4        q     d
C#5    4        q     d
measure 13
D5     2        e     u  [
D4     2        e     u  ]
D5     8        h     d
C#5    4        q     d
measure 14
B4     8        h     d         &t
A4     4        q     u
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 15
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 16
D6     2        e     d  [
C#6    1        s     d  =[
C#6    1        s     d  ]]
C#6    2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   4        q
measure 17
D4     8        h     u
E4     4        q     u
F#4    4        q     u
measure 18
G4     2        e     u  [
G3     2        e     u  ]
G4     8        h     u
F#4    4        q     u
measure 19
E4     8        h     u         &t
D4     4        q     u
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 20
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
D6     1        s     d  [[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
D6     1        s     d  [[
A5     1        s     d  ]]
measure 21
B5     2        e     d  [
D6     1        s     d  =[
D6     1        s     d  ]]
D6     2        e     d  [
D6     1        s     d  =[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
rest   4        q
measure 22
D5     8        h     d
E5     4        q     d
F#5    4        q     d
measure 23
G5     2        e     d  [
G4     2        e     d  ]
G5     8        h     d
F#5    4        q     d
measure 24
E5     8        h     d         &t
D5     4        q     d
rest   2        e
D6     1        s     d  [[
D6     1        s     d  ]]
measure 25
C#6    2        e     d  [
A5     2        e     d  ]
rest   2        e
F#5    1        s     d  [[
E5     1        s     d  ]]
D5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
A5     1        s     d  =[
G5     1        s     d  ]]
measure 26
F#5    4        q     d
rest   2        e
D6     1        s     d  [[
C#6    1        s     d  ]]
B5     2        e     d  [
G#5    1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
measure 27
D5     2        e     d  [
C#5    2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
A5     2        e     d  [
E5     2        e     d  ]
measure 28
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
D6     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
A5     2        e     d  [
E5     2        e     d  ]
measure 29
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
F#5    2        e     d  [
D5     2        e     d  ]
rest   2        e
C#6    1        s     d  [[
C#6    1        s     d  ]]
D6     2        e     d  [
A5     2        e     d  ]
measure 30
D5     2        e     d  [
B4     1        s     d  =[
B4     1        s     d  ]]
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
C#6    1        s     d  [[
C#6    1        s     d  ]]
D6     2        e     d  [
D6     2        e     d  ]
measure 31
D6     2        e     d  [
D6     2        e     d  =
C#6    3        e.    d  =      &t
C#6    1        s     d  ]\
D6     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 32
rest   2        e
B5     2        e     d  [
B5     2        e     d  =
B5     2        e     d  ]
A5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 33
G5     2        e     d  [
G5     1        s     d  =[
G5     1        s     d  ]]
B5     2        e     d  [
B5     2        e     d  ]
A5     4        q     d
A4     4        q     u
measure 34
A4     4        q     u
G4     4        q     u
F#4    4        q     u
E4     3        e.    u  [      &t
D4     1        s     u  ]\
measure 35
D4    12        h.    u
A4     4        q     u
measure 36
A4     4        q     u
G4     4        q     u
F#4    4        q     u
E4     3        e.    u  [      &t
D4     1        s     u  ]\
measure 37
D4    12        h.    u
A5     4        q     d
measure 38
A5     4        q     d
G5     4        q     d
F#5    4        q     d
E5     3        e.    d  [      &t
D5     1        s     d  ]\
measure 39
D5     6        q.    d
E5     2        e     d
F#5    4        q     d
G#5    4        q     d
measure 40
A5     6        q.    d
A5     2        e     d
B5     4        q     d
C#6    4        q     d
measure 41
D6     8        h     d
rest   8        h
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
D4     4        q     u
measure 44
A4     4        q     u
C#4    4        q     u
F#4    4        q     u
A3     4        q     u
measure 45
D4     4        q     u
C#4    2        e     u  [
B3     2        e     u  ]
C#4    4        q     u         &(
B3     3        e.    u  [      &)t
A3     1        s     u  ]\
measure 46
A3     4        q     u
rest   4        q
rest   2        e
A3     2        e     u  [
D4     2        e     u  =
D4     2        e     u  ]
measure 47
D4     4        q     u
rest   2        e
B3     2        e     u
E4     2        e     u  [
C#4    2        e     u  ]
D4     4-       q     u        -
measure 48
D4     4        q     u
C#4    4        q     u
D4     4        q     u
D5     4        q     d
measure 49
A5     4        q     d
C#5    4        q     d
F#5    4        q     d
A4     4        q     u
measure 50
D5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
C#5    4        q     d
B4     3        e.    u  [      &t
A4     1        s     u  ]\
measure 51
A4     8        h     u
rest   8        h
measure 52
rest   4        q
rest   2        e
A5     2        e     d
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     2        e     d
measure 53
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 54
D6     2        e     d  [
C#6    2        e     d  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
A5     2        e     d
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     2        e     d
measure 56
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 57
D6     2        e     d  [
C#6    2        e     d  ]
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
A5     2        e     d
B5     2        e     d  [
A5     2        e     d  =
D6     2        e     d  =
A5     2        e     d  ]
measure 59
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 60
B5     2        e     d  [
A5     2        e     d  ]
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
B5     2        e     d
C#6    2        e     d  [
B5     2        e     d  =
E5     2        e     d  =
B5     2        e     d  ]
measure 62
C#6    2        e     d  [
B5     2        e     d  ]
E5     2        e     d  [
B5     1        s     d  =[
B5     1        s     d  ]]
C#6    2        e     d  [
B5     2        e     d  ]
rest   2        e
B5     1        s     d  [[
B5     1        s     d  ]]
measure 63
C#6    2        e     d  [
B5     2        e     d  ]
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
C#6    2        e     d
D6     2        e     d  [
C#6    2        e     d  =
F#5    2        e     d  =
C#6    2        e     d  ]
measure 65
D6     2        e     d  [
C#6    2        e     d  ]
F#5    2        e     d  [
C#6    1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
C#6    2        e     d  ]
rest   2        e
C#6    1        s     d  [[
C#6    1        s     d  ]]
measure 66
D6     4        q     d
D5     4        q     d
rest   8        h
measure 67
rest   8        h
D6     4        q     d
D6     4        q     d
measure 68
A5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  =
G5     2        e     d  ]
F#5    2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
measure 69
E5     8        h     d
rest   8        h
measure 70
rest  16
measure 71
rest   8        h
rest   4        q
A5     4        q     d
measure 72
D6     4        q     d
F#5    4        q     d
B5     4        q     d
D5     4        q     d
measure 73
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
F#5    4        q     d         &(
E5     3        e.    d  [      &)t
D5     1        s     d  ]\
measure 74
D5     8        h     d
D4     4        q     u         i
D4     4        q     u         i
measure 75
D4     4        q     u         &i
rest   2        e
A5     2        e     d
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
measure 76
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
D4     2        e     u         i
D4     4        q     u         i
D4     4        q     u         i
measure 77
D4     4        q     u         i
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     1        s     d  [[
A5     1        s     d  ]]
measure 78
B5     2        e     d  [
A5     2        e     d  ]
rest   4        q
rest   4        q
A5     4        q     d
measure 79
D6     4        q     d
F#5    4        q     d
B5     4        q     d
D5     4        q     d
measure 80
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
E5     6        q.    d         t
A5     2        e     d
measure 81
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
measure 82
A5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
measure 83
A5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
measure 84
A5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
measure 85
A5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
D6     4        q     d
A5     4        q     d
measure 86
D6     4        q     d
F#5    4        q     d
B5     4        q     d
D5     4        q     d
measure 87
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 88
D5     4        q     d
rest   2        e
A5     2        e     d
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
measure 89
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
B5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
measure 90
B5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
D6     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
B5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
D6     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
measure 91
B5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
D6     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
B5     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
D6     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
measure 92
B5     2        e     d  [
A5     2        e     d  ]
rest   4        q
rest   4        q
A5     4        q     d
measure 93
B5    12        h.    d
B5     4        q     d
measure 94
A5    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 05
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/05} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:2feadb7942e39e9daaf62beff2438289]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 5 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
A4     6        q.    u
F#5    2        e     d
G5     2        e     d  [
F#5    2        e     d  ]
rest   4        q
measure 2
F#5    4        q     d
A4     2        e     d  [
D5     2        e     d  ]
C#5    2        e     d  [
D5     2        e     d  ]
rest   2        e
A4     2        e     u
measure 3
C#5    2        e     d
D5     4        q     d
C#5    2        e     d
D5     2        e     u  [
F#4    2        e     u  =
G4     2        e     u  =
E4     2        e     u  ]
measure 4
F#4    4        q     u
rest   4        q
D4     6        q.    u
F#4    2        e     u
measure 5
D4     2        e     u  [
A3     2        e     u  ]
rest   4        q
D5     6        q.    d
D5     2        e     d
measure 6
B4     2        e     u  [
A4     1        s     u  =[
A4     1        s     u  ]]
B4     2        e     u  [
A4     2        e     u  ]
rest   2        e
F#5    1        s     d  [[
F#5    1        s     d  ]]
G5     2        e     d  [
D5     2        e     d  ]
measure 7
rest   4        q
rest   2        e
C#5    2        e     d
D5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
D5     2        e     d  ]
measure 8
C#5    4        q     d
rest   4        q
A4     6        q.    u
C#5    2        e     d
measure 9
A4     4        q     u
rest   4        q
rest   2        e
C#5    1        s     d  [[
C#5    1        s     d  ]]
D5     2        e     d  [
C#5    2        e     d  ]
measure 10
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
measure 11
A4     2        e     d  [
E5     2        e     d  ]
D5     4        q     d
C#5    2        e     d  [
C#5    1        s     d  =[
C#5    1        s     d  ]]
D5     2        e     d  [
C#5    2        e     d  ]
measure 12
A4     8        h     u
B4     4        q     d
C#5    4        q     d
measure 13
D5     2        e     u  [
D4     2        e     u  ]
D5     8        h     d
C#5    4        q     d
measure 14
B4     8        h     d         &t
A4     4        q     u
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 15
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 16
F#5    2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
E5     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
measure 17
D4     8        h     u
E4     4        q     u
F#4    4        q     u
measure 18
G4     2        e     u  [
G3     2        e     u  ]
G4     8        h     u
F#4    4        q     u
measure 19
E4     8        h     u         &t
D4     4        q     u
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
measure 20
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     1        s     d  [[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     1        s     d  [[
D5     1        s     d  ]]
measure 21
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
A5     1        s     d  =[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   4        q
measure 22
rest   8        h
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
F#4    2        e     u  [
D4     2        e     u  ]
measure 23
rest   2        e
D4     1        s     u  [[
D4     1        s     u  ]]
B4     2        e     d  [
B4     2        e     d  ]
E4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     1        s     u  [[
A4     1        s     u  ]]
measure 24
G4     2        e     u  [
E4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  ]
A4     2        e     d  [
A5     1        s     d  =[
A5     1        s     d  ]]
F#5    2        e     d  [
D5     2        e     d  ]
measure 25
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
C#5    2        e     d  [
C#6    1        s     d  =[
C#6    1        s     d  ]]
D6     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
A4     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
measure 26
A4     2        e     d  [
A5     1        s     d  =[
G5     1        s     d  ]]
F#5    2        e     d  [
B5     1        s     d  =[
A5     1        s     d  ]]
G#5    2        e     d  [
E5     2        e     d  ]
A5     4-       q     d        -
measure 27
A5     4        q     d
G#5    4        q     d
A5     2        e     d  [
C#5    1        s     d  =[
C#5    1        s     d  ]]
E5     2        e     d  [
C#5    2        e     d  ]
measure 28
rest   2        e
F#5    1        s     d  [[
F#5    1        s     d  ]]
A5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
C#5    1        s     d  [[
C#5    1        s     d  ]]
E5     2        e     d  [
C#5    2        e     d  ]
measure 29
rest   2        e
F#4    1        s     u  [[
F#4    1        s     u  ]]
A4     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
A5     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
A4     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 30
G5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
B4     2        e     u  [
G4     1        s     u  =[
G4     1        s     u  ]]
E4     2        e     u  [
E5     1        s     u  =[
E5     1        s     u  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 31
B5     2        e     d  [
G5     2        e     d  =
E5     3        e.    d  =
E5     1        s     d  ]\
A5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
A4     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
measure 32
G5     2        e     d  [
G5     2        e     d  =
G5     2        e     d  =
G5     2        e     d  ]
F#5    2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
D5     2        e     d  [
A4     2        e     d  ]
measure 33
D5     2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
F#5    4        q     d
F#4    4        q     u
measure 34
E4     4        q     u
D4     8        h     u
C#4    4        q     u
measure 35
D4    12        h.    u
F#4    4        q     u
measure 36
E4     4        q     u
D4     8        h     u
C#4    3        e.    u  [
D4     1        s     u  ]\
measure 37
A3    12        h.    u
F#5    4        q     d
measure 38
E5     4        q     d
D5     4        q     d
D5     4        q     d
C#5    4        q     d
measure 39
A4     6        q.    u
C#5    2        e     d
D5     4        q     d
D5     4        q     d
measure 40
C#5    6        q.    d
D5     2        e     d
D5     4        q     d
G5     4        q     d
measure 41
F#5    8        h     d
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest   4        q
A4     4        q     u
D5     4        q     d
F#4    4        q     u
measure 47
B4     4        q     d
D4     4        q     u
G4     4        q     u
F#4    2        e     u  [
E4     2        e     u  ]
measure 48
F#4    4        q     u
E4     3        e.    u  [      &t
D4     1        s     u  ]\
D4     2        e     u  [
A4     2        e     u  =
F#4    2        e     u  =
D4     2        e     u  ]
measure 49
rest   2        e
E4     2        e     u  [
A4     2        e     u  =
E4     2        e     u  ]
rest   2        e
D4     2        e     u  [
C#4    2        e     u  =
A3     2        e     u  ]
measure 50
D4     2        e     u  [
B4     2        e     u  ]
A4     8        h     u
G#4    4        q     u
measure 51
A4     4        q     u
E4     4        q     u
rest   8        h
measure 52
rest   4        q
rest   2        e
E5     2        e     d
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 53
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 54
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
E5     2        e     d
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 56
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
F#5    2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     1        s     d  [[
E5     1        s     d  ]]
measure 57
F#5    2        e     d  [
E5     2        e     d  ]
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
D5     2        e     d
G5     2        e     d  [
F#5    2        e     d  =
A5     2        e     d  =
F#5    2        e     d  ]
measure 59
D5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
measure 60
G5     2        e     d  [
F#5    2        e     d  ]
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
E5     2        e     d
A5     2        e     d  [
G#5    2        e     d  =
B4     2        e     d  =
G#5    2        e     d  ]
measure 62
A5     2        e     d  [
G#5    2        e     d  ]
E5     2        e     d  [
G#5    1        s     d  =[
G#5    1        s     d  ]]
A5     2        e     d  [
G#5    2        e     d  ]
rest   2        e
G#5    1        s     d  [[
G#5    1        s     d  ]]
measure 63
A5     2        e     d  [
G#5    2        e     d  ]
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
F#5    2        e     d
B5     2        e     d  [
A#5    2        e     d  =
C#5    2        e     d  =
F#5    2        e     d  ]
measure 65
B5     2        e     d  [
A#5    2        e     d  ]
C#5    2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
B5     2        e     d  [
A#5    2        e     d  ]
rest   2        e
F#5    1        s     d  [[
F#5    1        s     d  ]]
measure 66
B5     4        q     d
F#5    4        q     d
rest   8        h
measure 67
rest   8        h
D5     4        q     d
D5     4        q     d
measure 68
E5     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
E5     2        e     d  ]
D5     2        e     d  [
C#5    2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 69
C#5    8        h     d
rest   2        e
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 70
A4     4        q     u
rest   4        q
rest   2        e
F#5    2        e     d  [
G#5    2        e     d  =
A5     2        e     d  ]
measure 71
D5     2        e     d  [
C#5    2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     u  [
E4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 72
F#4    6        q.    u
E4     2        e     u
D4     6        q.    u
D5     2        e     d
measure 73
D5     2        e     d  [
C#5    2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
D5     4        q     d
C#5    4        q     d
measure 74
D5     8        h     d
D4     4        q     u         i
D4     4        q     u         i
measure 75
D4     4        q     u         i
rest   2        e
D5     2        e     d
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     2        e     d
measure 76
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D4     2        e     u         i
D4     4        q     u         i
D4     4        q     u         i
measure 77
D4     4        q     u         &i
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     1        s     d  [[
D5     1        s     d  ]]
measure 78
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     2        e     d
F#5    1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 79
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     1        s     u  [[
A4     1        s     u  ==
B4     1        s     u  ==
G4     1        s     u  ]]
A4     2        e     d  [
A5     2        e     d  ]
measure 80
C#6    4        q     d
D6     2        e     d  [
D6     2        e     d  ]
D6     4        q     d
C#6    4        q     d
measure 81
D6     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
D5     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
D5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
measure 82
F#5    2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
G5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
measure 83
F#5    2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
G5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
measure 84
F#5    2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
G5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
measure 85
F#5    2        e     d  [
D5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
G5     1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 86
D5     1        s     d  [[
C#5    1        s     d  ==
D5     1        s     d  ==
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     1        s     u  [[
A4     1        s     u  ==
B4     1        s     u  ==
G4     1        s     u  ]]
A4     2        e     d  [
A5     2        e     d  ]
measure 87
C#5    4        q     d
D5     4        q     d
D5     4        q     d
C#5    4        q     d
measure 88
D5     4        q     d
rest   2        e
D5     2        e     d
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     2        e     d
measure 89
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     2        e     d
G5     2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     2        e     d
measure 90
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 91
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
G5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
measure 92
G5     2        e     d  [
F#5    2        e     d  ]
rest   4        q
rest   4        q
F#5    4        q     d
measure 93
G5    12        h.    d
G5     4        q     d
measure 94
F#5   16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 06
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/06} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:8ec3ef4597d99273c54bc17d111a56dd]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 6 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Allegro
F#4    2        e     d  [
G4     2        e     d  =
A4     2        e     d  =
D4     2        e     d  ]
D5     2        e     d  [
D4     2        e     d  ]
rest   4        q
measure 2
A4     6        q.    d
A4     2        e     d
G4     2        e     d  [
A4     2        e     d  ]
rest   2        e
D4     2        e     d
measure 3
G4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
E4     2        e     d  ]
F#4    4        q     d
rest   4        q
measure 4
rest   8        h
D4     6        q.    d
D4     2        e     d
measure 5
A3     2        e     u  [
F#3    2        e     u  ]
rest   4        q
D4     6        q.    d
D4     2        e     d
measure 6
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
measure 7
rest   4        q
rest   2        e
A4     2        e     d
A4     2        e     d  [
A4     2        e     d  =
E4     2        e     d  =
A4     2        e     d  ]
measure 8
A4     4        q     d
rest   4        q
A4     6        q.    d
A4     2        e     d
measure 9
E4     4        q     d
rest   4        q
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
measure 10
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
measure 11
D5     2        e     d  [
A4     2        e     d  ]
B4     4        q     d
E4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
measure 12
A4     8        h     d
B4     4        q     d
C#5    4        q     d
measure 13
D5     2        e     d  [
D4     2        e     d  ]
D5     8        h     d
C#5    4        q     d
measure 14
B4     8        h     d
A4     4        q     d
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
measure 15
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
measure 16
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
C#5    1        s     d  =[
C#5    1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
rest   4        q
measure 17
D4     8        h     d
E4     4        q     d
F#4    4        q     d
measure 18
G4     2        e     d  [
G3     2        e     d  ]
G4     8        h     d
F#4    4        q     d
measure 19
E4     8        h     d
D4     4        q     d
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 20
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D4     1        s     d  [[
F#4    1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D4     1        s     d  [[
F#4    1        s     d  ]]
measure 21
D5     2        e     d  [
D5     1        s     d  =[
A4     1        s     d  ]]
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
rest   4        q
measure 22
rest   4        q
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
C#4    2        e     u  [
A3     2        e     u  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 23
B3     2        e     u  [
B3     2        e     u  ]
rest   2        e
E4     1        s     d  [[
E4     1        s     d  ]]
C#4    2        e     u  [
A3     2        e     u  ]
D4     4-       q     d        -
measure 24
D4     4        q     d
C#4    4        q     d
D4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
A4     2        e     d  [
F#4    2        e     d  ]
measure 25
rest   2        e
C#5    1        s     d  [[
C#5    1        s     d  ]]
A4     2        e     d  [
C#5    1        s     d  =[
A4     1        s     d  ]]
F#4    2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
C#5    2        e     d  [
C#5    1        s     d  =[
C#5    1        s     d  ]]
measure 26
F#4    2        e     d  [
F#4    1        s     d  =[
E4     1        s     d  ]]
D4     2        e     d  [
F#4    2        e     d  ]
B4     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]
measure 27
F#4    2        e     d  [
F#4    2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
E4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
C#5    2        e     d  [
A4     2        e     d  ]
measure 28
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
F#4    2        e     d  [
D4     2        e     d  ]
rest   2        e
E4     1        s     d  [[
E4     1        s     d  ]]
C#4    2        e     u  [
A3     2        e     u  ]
measure 29
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
D5     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
E4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
F#4    2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
measure 30
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
G4     2        e     d  [
G4     1        s     d  =[
G4     1        s     d  ]]
C#4    2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
D5     2        e     d  [
F#4    1        s     d  =[
D4     1        s     d  ]]
measure 31
E4     2        e     d  [
B4     2        e     d  =
C#4    2        e     d  =
A4     2        e     d  ]
A4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
D4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
measure 32
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
D4     2        e     d  [
E4     2        e     d  ]
F#4    2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
A4     2        e     d  [
F#4    2        e     d  ]
measure 33
G4     2        e     d  [
G4     1        s     d  =[
G4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
D4     4        q     d
D4     4        q     d
measure 34
A3     4        q     u
D4     4        q     d
A3     4        q     u
C#4    4        q     d
measure 35
A3    12        h.    u
D4     4        q     d
measure 36
A3     4        q     u
D3     4        q     u
A3     4        q     u
G3     3        e.    u  [
F#3    1        s     u  ]\
measure 37
F#3   12        h.    u
D5     4        q     d
measure 38
A4     4        q     d
D4     4        q     d
A4     4        q     d
E4     4        q     d
measure 39
F#4    6        q.    d
G4     2        e     d
A4     4        q     d
B4     4        q     d
measure 40
E4     6        q.    d
F#4    2        e     d
G4     4        q     d
G4     4        q     d
measure 41
A4     8        h     d
rest   8        h
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
D4     4        q     d
measure 44
A4     4        q     d
C#4    4        q     d
F#4    4        q     d
A3     4        q     u
measure 45
D4     4        q     d
C#4    2        e     u  [
B3     2        e     u  ]
C#4    4        q     u
B3     3        e.    u  [
A3     1        s     u  ]\
measure 46
A3     4        q     u
A4     4        q     d
D5     4        q     d
F#4    4        q     d
measure 47
B4     4        q     d
D4     4        q     d
G4     4        q     d
F#4    2        e     d  [
E4     2        e     d  ]
measure 48
F#4    4        q     d
E4     3        e.    d  [
D4     1        s     d  ]\
D4     4        q     d
rest   2        e
F#4    2        e     d
measure 49
E4     2        e     d  [
C#4    2        e     d  ]
rest   2        e
A4     2        e     d
A4     2        e     d  [
D4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 50
F#4    2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
F#4    2        e     d  ]
E4     4        q     d
E4     4        q     d
measure 51
E4     4        q     d
C#4    4        q     d
rest   8        h
measure 52
rest   4        q
rest   2        e
A4     2        e     d
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 53
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
measure 54
A4     2        e     d  [
A4     2        e     d  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
A4     2        e     d
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 56
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     1        s     d  [[
A4     1        s     d  ]]
measure 57
A4     2        e     d  [
A4     2        e     d  ]
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
D4     2        e     d
D4     2        e     d  [
D4     2        e     d  =
F#4    2        e     d  =
D4     2        e     d  ]
measure 59
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 60
D4     2        e     d  [
D4     2        e     d  ]
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
E4     2        e     d
E4     2        e     d  [
E4     2        e     d  =
G#4    2        e     d  =
E4     2        e     d  ]
measure 62
E4     2        e     d  [
E4     2        e     d  ]
G#4    2        e     d  [
E4     1        s     d  =[
E4     1        s     d  ]]
E4     2        e     d  [
E4     2        e     d  ]
rest   2        e
E4     1        s     d  [[
E4     1        s     d  ]]
measure 63
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
F#4    2        e     d
F#4    2        e     d  [
F#4    2        e     d  =
A#4    2        e     d  =
F#4    2        e     d  ]
measure 65
F#4    2        e     d  [
F#4    2        e     d  ]
A#4    2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
F#4    2        e     d  [
F#4    2        e     d  ]
rest   2        e
F#4    1        s     d  [[
F#4    1        s     d  ]]
measure 66
F#4    4        q     d
F#4    4        q     d
rest   8        h
measure 67
rest   8        h
G4     4        q     d
G4     4        q     d
measure 68
E4     6        q.    d
A4     2        e     d
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 69
A4     8        h     d
rest   8        h
measure 70
rest   2        e
A4     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  ]
F#4    2        e     d  [
A4     2        e     d  =
E4     2        e     d  =
A4     2        e     d  ]
measure 71
A4     4        q     d
G#4    4        q     d
A4     4        q     d
rest   4        q
measure 72
rest   2        e
A3     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
B3     6        q.    u
A4     2        e     d
measure 73
G4     4        q     d
A4     2        e     d  [
B4     2        e     d  ]
A4     8        h     d
measure 74
A4     8        h     d
D4     4        q     d         i
D4     4        q     d         i
measure 75
D4     4        q     d         i
rest   2        e
D4     2        e     d
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D4     2        e     d
measure 76
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D4     2        e     d         &i
D4     4        q     d         &i
D4     4        q     d         &i
measure 77
D4     4        q     d         &i
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 78
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
F#4    2        e     d
A4     4        q     d
D4     4        q     d
measure 79
F#4    4        q     d
F#4    4        q     d
D4     4        q     d
D4     4        q     d
measure 80
E4     4        q     d
A4     4        q     d
A4     4        q     d
A4     4        q     d
measure 81
A4     4        q     d
rest   4        q
F#4    2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
measure 82
A4     4        q     d
rest   2        e
A4     2        e     d
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
measure 83
D5     4        q     d
rest   4        q
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
measure 84
D5     4        q     d
rest   2        e
A4     2        e     d
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
measure 85
A4     4        q     d
rest   2        e
A4     2        e     d
A4     4        q     d
D4     4        q     d
measure 86
F#4    2        e     d  [
D4     2        e     d  =
A4     2        e     d  =
F#4    2        e     d  ]
D4     4        q     d
A4     4        q     d
measure 87
E4     4        q     d
A4     2        e     d  [
A4     2        e     d  ]
A4     4        q     d
E4     4        q     d
measure 88
F#4    4        q     d
rest   2        e
A4     2        e     d
D5     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     2        e     d
measure 89
D5     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     2        e     d
D5     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     2        e     d
measure 90
D5     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
A4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
A4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
measure 91
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
A4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
A4     2        e     d  [
F#4    1        s     d  =[
F#4    1        s     d  ]]
measure 92
D4     2        e     d  [
D4     2        e     d  ]
rest   4        q
rest   4        q
D4     4        q     d
measure 93
D4    12        h.    d
D4     4        q     d
measure 94
D4    16        w     d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 07
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/07} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:cff03f68ac015f5e9aec3bfe2ea4fb30]
06/12/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 7 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
D5     6        q.    d                    Hal-
A4     2        e     u                    le-
B4     2        e     d                    lu-
A4     2        e     u                    jah,
rest   4        q
measure 5
D5     6        q.    d                    Hal-
A4     2        e     u                    le-
B4     2        e     d                    lu-
A4     2        e     u                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 6
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     2        e     d                    Hal-
measure 7
C#5    2        e     d         (          le-
D5     4        q     d         )          -
C#5    2        e     d                    lu-
D5     4        q     d                    jah,
rest   4        q
measure 8
E5     6        q.    d                    Hal-
A4     2        e     u                    le-
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   4        q
measure 9
E5     6        q.    d                    Hal-
A4     2        e     u                    le-
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
measure 10
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   2        e
E5     2        e     d                    Hal-
measure 11
F#5    2        e     d  [                 le-
E5     2        e     d  ]                 -
D5     4        q     d                    lu-
C#5    4        q     d                    jah,
rest   4        q
measure 12
A4     8        h     u                    for
B4     4        q     d                    the
C#5    4        q     d                    Lord
measure 13
D5     2        e     d                    God
D4     2        e     u                    om-
D5     6        q.    d                    ni-
D5     2        e     d                    po-
C#5    4        q     d                    tent
measure 14
B4     8        h     d                    reign-
A4     4        q     u                    eth,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
measure 15
D5     2        e     d                    lu-
C#5    2        e     d                    jah,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
D5     2        e     d                    lu-
C#5    2        e     d                    jah,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
measure 16
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   2        e
E5     1        s     d                    Hal-
E5     1        s     d                    le-
F#5    2        e     d                    lu-
E5     2        e     d                    jah,
rest   4        q
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   4        q
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 20
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 21
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   4        q
measure 22
D5     8        h     d                    for
E5     4        q     d                    the
F#5    4        q     d                    Lord
measure 23
G5     2        e     d                    God
G4     2        e     u                    om-
G5     6        q.    d                    ni-
G5     2        e     d                    po-
F#5    4        q     d                    tent
measure 24
E5     8        h     d                    reign-
D5     4        q     d                    eth,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 25
C#5    2        e     d                    lu-
A4     2        e     u                    jah,
rest   2        e
C#5    1        s     d                    Hal-
C#5    1        s     d                    le-
D5     2        e     d                    lu-
D5     1        s     d                    jah,
D5     1        s     d                    Hal-
E5     2        e     d                    le-
E5     2        e     d                    lu-
measure 26
A4     4        q     u                    jah,
rest   2        e
D5     1        s     d                    Hal-
C#5    1        s     d                    le-
B4     2        e     d                    lu-
B4     2        e     d                    jah,
rest   2        e
E5     2        e     d                    Hal-
measure 27
D5     2        e     d  [                 le-
C#5    2        e     d  ]                 -
D5     2        e     d  [                 lu-
E5     1        s     d  =[                -
D5     1        s     d  ]]                -
C#5    2        e     d                    jah,
C#5    1        s     d                    Hal-
C#5    1        s     d                    le-
E5     2        e     d                    lu-
C#5    2        e     d                    jah,
measure 28
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
D5     2        e     d                    lu-
A4     2        e     u                    jah
rest   2        e
C#5    1        s     d                    Hal-
C#5    1        s     d                    le-
E5     2        e     d                    lu-
C#5    2        e     d                    jah,
measure 29
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
F#5    2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
C#5    1        s     d                    Hal-
C#5    1        s     d                    le-
D5     2        e     d                    lu-
A4     2        e     u                    jah,
measure 30
rest   2        e
B4     1        s     d                    Hal-
B4     1        s     d                    le-
E5     2        e     d                    lu-
E5     2        e     d                    jah,
rest   2        e
C#5    1        s     d                    Hal-
C#5    1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,Hal-
measure 31
D5     4        q     d                    le-
C#5    4        q     d                    lu-
D5     4        q     d                    jah,
D5     4        q     d                    Hal-
measure 32
D5     4        q     d                    le-
D5     4        q     d                    lu-
D5     8        h     d                    jah!
measure 33
rest   8        h
rest   4        q
A4     4        q     u                    The
measure 34
A4     4        q     u                    king-
G4     4        q     u                    dom
F#4    4        q     u                    of
E4     3        e.    u  [                 this_
D4     1        s     u  ]\                _
measure 35
D4    16        w     u                    world
measure 36
rest   8        h
F#4    4        q     u                    is
E4     3        e.    u  [                 be-
D4     1        s     u  ]\                -
measure 37
D4    12        h.    u                    come
F#5    4        q     d                    the
measure 38
E5     4        q     d                    king-
D5     4        q     d                    dom
D5     4        q     d                    of
C#5    4        q     d                    our
measure 39
D5     6        q.    d                    Lord
C#5    2        e     d                    and
D5     4        q     d                    of
D5     4        q     d                    his
measure 40
C#5    6        q.    d                    Christ,
A4     2        e     u                    and
B4     4        q     d                    of
C#5    4        q     d                    his
measure 41
D5     8        h     d                    Christ,
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest   8        h
rest   4        q
D5     4        q     d                    and
measure 49
A5     4        q     d                    He
C#5    4        q     d                    shall
F#5    4        q     d                    reign
A4     4        q     u                    for
measure 50
D5     4        q     d                    e-
C#5    2        e     d                    ver
B4     2        e     d                    and
C#5    4        q     d         (          e-
B4     3        e.    u  [                 -
A4     1        s     u  ]\     )          -
measure 51
A4     8        h     u                    ver.
A4     4        q     u                    King
A4     4        q     u                    of
measure 52
A4    16-       w     u        -           Kings,_
measure 53
A4    16        w     u                    _
measure 54
rest   4        q
A4     4        q     u                    and
A4     4        q     u                    Lord
A4     4        q     u                    of
measure 55
A4    16-       w     u        -           Lords,_
measure 56
A4    16        w     u                    _
measure 57
rest   8        h
D5     4        q     d                    King
D5     4        q     d                    of
measure 58
D5    16-       w     d        -           Kings,_
measure 59
D5    16-       w     d        -           _
measure 60
D5     4        q     d                    _
D5     4        q     d                    and
E5     4        q     d                    Lord
E5     4        q     d                    of
measure 61
E5    16-       w     d        -           Lords,_
measure 62
E5    16-       w     d        -           _
measure 63
E5     8        h     d                    _
F#5    4        q     d                    King
F#5    4        q     d                    of
measure 64
F#5   16-       w     d        -           Kings,_
measure 65
F#5   16-       w     d        -           _
measure 66
F#5    6        q.    d                    _
F#5    2        e     d                    and
G5     4        q     d                    Lord
G5     4        q     d                    of
measure 67
G5    16-       w     d        -           Lords,_
measure 68
G5     6        q.    d                    _
G5     2        e     d                    and
F#5    2        e     d  [                 Lord_
E5     2        e     d  ]                 _
F#5    2        e     d  [                 of_
G5     2        e     d  ]                 _
measure 69
E5     8        h     d                    Lords,
rest   2        e
C#5    2        e     d                    and
D5     2        e     d                    He
E5     2        e     d                    shall
measure 70
A4     4        q     u                    reign,
rest   4        q
rest   8        h
measure 71
rest   8        h
rest   4        q
A4     4        q     u                    and
measure 72
D5     4        q     d                    He
F#4    4        q     u                    shall
B4     4        q     d                    reign
D4     4        q     u                    for
measure 73
G4     4        q     u                    e-
F#4    2        e     u                    ver
E4     2        e     u                    and
F#4    4        q     u         (          e-
E4     3        e.    u  [                 -
D4     1        s     u  ]\     )          -
measure 74
D4     8        h     u                    ver,
rest   8        h
measure 75
rest   4        q
rest   2        e
D5     2        e     d                    for
G5     2        e     d                    e-
F#5    2        e     d                    ver
rest   2        e
D5     2        e     d                    and
measure 76
G5     2        e     d                    e-
F#5    2        e     d                    ver,
rest   4        q
rest   8        h
measure 77
rest   4        q
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
G5     2        e     d                    lu-
F#5    2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 78
G5     2        e     d                    lu-
F#5    2        e     d                    jah,
rest   2        e
A4     2        e     u                    and
A4     4        q     u                    He
D5     4        q     d                    shall
measure 79
F#5    4        q     d                    reign
D5     4        q     d                    for
D5     4        q     d                    e-
A4     2        e     u                    ver,
A4     2        e     u                    for
measure 80
C#5    4        q     d                    e-
D5     2        e     d                    ver
D5     2        e     d                    and
D5     4        q     d         (          e-
C#5    4        q     d         )          -
measure 81
D5     4        q     d                    ver,
rest   4        q
A4     4        q     u                    King
A4     4        q     u                    of
measure 82
D5     4        q     d                    Kings,
rest   2        e
A4     2        e     u                    and
A4     4        q     u                    Lord
A4     4        q     u                    of
measure 83
D5     4        q     d                    Lords,
rest   4        q
A4     4        q     u                    King
A4     4        q     u                    of
measure 84
D5     4        q     d                    Kings,
rest   2        e
A4     2        e     u                    and
A4     4        q     u                    Lord
A4     4        q     u                    of
measure 85
D5     4        q     d                    Lords,
rest   4        q
rest   4        q
A4     4        q     u                    and
measure 86
D5     4        q     d                    He
F#5    4        q     d                    shall
B4     4        q     d                    reign
D5     4        q     d                    for
measure 87
G5     4        q     d                    e-
F#5    2        e     d                    ver
E5     2        e     d                    and
E5     8        h     d                    e-
measure 88
D5     4        q     d                    ver,
rest   4        q
D5     4        q     d                    King
D5     4        q     d                    of
measure 89
D5     4        q     d                    Kings,
rest   2        e
D5     2        e     d                    and
D5     4        q     d                    Lord
D5     4        q     d                    of
measure 90
D5     4        q     d                    Lords,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 91
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   2        e
D5     1        s     d                    Hal-
D5     1        s     d                    le-
measure 92
D5     2        e     d                    lu-
D5     2        e     d                    jah,
rest   4        q
rest   4        q
D5     4        q     d                    Hal-
measure 93
D5    12        h.    d                    le-
D5     4        q     d                    lu-
measure 94
D5    16        w     d                    jah.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 08
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/08} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:395f7f17f687bb72f3b58ff4c78d47af]
06/24/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 8 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
A4     6        q.    u                    Hal-
A4     2        e     u                    le-
G4     2        e     u                    lu-
F#4    2        e     u                    jah,
rest   4        q
measure 5
A4     6        q.    u                    Hal-
A4     2        e     u                    le-
G4     2        e     u                    lu-
F#4    2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 6
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     2        e     u                    Hal-
measure 7
G4     2        e     u  [                 le-
F#4    2        e     u  =                 -
E4     2        e     u  ]                 -
E4     2        e     u                    lu-
F#4    4        q     u                    jah,
rest   4        q
measure 8
A4     6        q.    u                    Hal-
A4     2        e     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
measure 9
A4     6        q.    u                    Hal-
A4     2        e     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 10
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     2        e     u                    Hal-
measure 11
A4     6        q.    u                    le-
G#4    2        e     u                    lu-
A4     4        q     u                    jah,
rest   4        q
measure 12
A4     8        h     u                    for
B3     4        q     u                    the
C#4    4        q     u                    Lord
measure 13
D4     2        e     u                    God
D4     2        e     u                    om-
D4     6        q.    u                    ni-
D4     2        e     u                    po-
C#4    4        q     u                    tent
measure 14
B3     8        h     u                    reign-
A3     4        q     u                    eth,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 15
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 16
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
measure 17
D4     8        h     u                    for
E4     4        q     u                    the
F#4    4        q     u                    Lord
measure 18
G4     2        e     u                    God
G3     2        e     u                    om-
G4     6        q.    u                    ni-
G4     2        e     u                    po-
F#4    4        q     u                    tent
measure 19
E4     8        h     u                    reign-
D4     4        q     u                    eth,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 20
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 21
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
measure 22
rest  16
measure 23
rest   8        h
rest   4        q
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 24
G4     2        e     u                    lu-
E4     2        e     u                    jah,Hal-
A4     2        e     u                    le-
A4     2        e     u                    lu-
A4     2        e     u                    jah,
A4     1        s     u                    Hal-
A4     1        s     u                    le-
F#4    2        e     u                    lu-
D4     2        e     u                    jah,
measure 25
rest   2        e
E4     1        s     u                    Hal-
E4     1        s     u                    le-
C#4    2        e     u                    lu-
A3     2        e     u                    jah,
rest   2        e
G4     1        s     u  [[                Hal-
F#4    1        s     u  ]]                -
E4     2        e     u                    le-
A4     1        s     u  [[                lu-
G4     1        s     u  ]]                -
measure 26
F#4    4        q     u                    jah,
rest   2        e
B4     1        s     u                    Hal-
A4     1        s     u                    le-
G#4    2        e     u                    lu-
E4     2        e     u                    jah,Hal-
A4     4-       q     u        -           le-
measure 27
A4     4        q     u                    -
G#4    4        q     u                    lu-
A4     4        q     u                    jah,
rest   2        e
E4     1        s     u                    Hal-
E4     1        s     u                    le-
measure 28
A4     2        e     u                    lu-
F#4    2        e     u                    jah,
rest   2        e
F#4    1        s     u                    Hal-
F#4    1        s     u                    le-
E4     2        e     u                    lu-
C#4    2        e     u                    jah,
rest   4        q
measure 29
D4     8        h     u                    for
E4     4        q     u                    the
F#4    4        q     u                    Lord
measure 30
G4     2        e     u                    God
G3     2        e     u                    om-
G4     6        q.    u                    ni-
G4     2        e     u                    po-
F#4    4        q     u                    tent
measure 31
E4     8        h     u                    reign-
D4     2        e     u                    eth,
A4     1        s     u                    Hal-
A4     1        s     u                    le-
F#4    2        e     u                    lu-
D4     2        e     u                    jah,
measure 32
rest   2        e
B4     2        e     u                    Hal-
B4     2        e     u                    le-
B4     2        e     u                    lu-
A4     8        h     u                    jah!
measure 33
rest   8        h
rest   4        q
F#4    4        q     u                    The
measure 34
E4     4        q     u                    king-
D4     4        q     u                    dom
D4     4        q     u                    of
C#4    4        q     u                    this
measure 35
D4    16        w     u                    world
measure 36
rest   4        q
D4     8        h     u                    is
C#4    4        q     u                    be-
measure 37
D4    12        h.    u                    come
A4     4        q     u                    the
measure 38
A4     4        q     u                    king-
D4     4        q     u                    dom
F#4    4        q     u                    of
E4     3        e.    u  [                 our_
D4     1        s     u  ]\                _
measure 39
D4     6        q.    u                    Lord
E4     2        e     u                    and
F#4    4        q     u                    of
G#4    4        q     u                    his
measure 40
A4     6        q.    u                    Christ,
A4     2        e     u                    and
G4     4        q     u         +          of
G4     4        q     u                    his
measure 41
A4     8        h     u                    Christ,
rest   8        h
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest   4        q
A4     4        q     u                    and
D4     4        q     u                    He
F#4    4        q     u                    shall
measure 47
B4     4        q     u                    reign
D4     4        q     u                    for
G4     4        q     u                    e-
F#4    2        e     u                    ver
E4     2        e     u                    and
measure 48
F#4    4        q     u         (          e-
E4     3        e.    u  [                 -
D4     1        s     u  ]\     )          -
D4     2        e     u                    ver,
A4     2        e     u                    for
F#4    2        e     u                    e-
D4     2        e     u                    ver
measure 49
rest   2        e
E4     2        e     u                    and
A4     2        e     u                    e-
E4     2        e     u                    ver,
rest   4        q
rest   2        e
C#4    2        e     u                    for
measure 50
D4     2        e     u  [                 e-
B4     2        e     u  ]                 -
A4     8        h     u                    ver
G#4    4        q     u                    and
measure 51
A4     4        q     u                    e-
E4     4        q     u                    ver,
A4     4        q     u                    King
A4     4        q     u                    of
measure 52
A4    16-       w     u        -           Kings,_
measure 53
A4    16        w     u                    _
measure 54
rest   4        q
A4     4        q     u                    and
A4     4        q     u                    Lord
A4     4        q     u                    of
measure 55
A4    16-       w     u        -           Lords,_
measure 56
A4    16-       w     u        -           _
measure 57
A4     8        h     u                    _
rest   8        h
measure 58
rest   4        q
rest   2        e
A4     2        e     u                    for
B4     2        e     u                    e-
A4     2        e     u                    ver
rest   2        e
A4     2        e     u                    and
measure 59
B4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 60
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
E4     2        e     u                    for
A4     2        e     u                    e-
G#4    2        e     u                    ver
rest   2        e
E4     2        e     u                    and
measure 62
A4     2        e     u                    e-
G#4    2        e     u                    ver,
rest   2        e
E4     1        s     u                    Hal-
E4     1        s     u                    le-
A4     2        e     u                    lu-
G#4    2        e     u                    jah,
rest   2        e
E4     1        s     u                    Hal-
E4     1        s     u                    le-
measure 63
A4     2        e     u                    lu-
G#4    2        e     u                    jah,
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
F#4    2        e     u                    for
B4     2        e     u                    e-
A#4    2        e     u                    ver
rest   2        e
F#4    2        e     u                    and
measure 65
B4     2        e     u                    e-
A#4    2        e     u                    ver,
rest   2        e
F#4    1        s     u                    Hal-
F#4    1        s     u                    le-
B4     2        e     u                    lu-
A#4    2        e     u                    jah,
rest   2        e
F#4    1        s     u                    Hal-
F#4    1        s     u                    le-
measure 66
B4     4        q     u                    lu-
F#4    4        q     u                    jah,
rest   8        h
measure 67
rest   8        h
B4     4        q     u                    King
B4     4        q     u                    of
measure 68
A4     6        q.    u                    Kings,
A4     2        e     u                    and
A4     4        q     u                    Lord
A4     4        q     u                    of
measure 69
A4     8        h     u                    Lords
rest   8        h
measure 70
rest   8        h
rest   2        e
F#4    2        e     u                    and
G#4    2        e     u                    He
A4     2        e     u                    shall
measure 71
D4     2        e     u  [                 reign,_
C#4    2        e     u  ]                 _
D4     2        e     u  [                 _
E4     1        s     u  =[                _
D4     1        s     u  =]                _
C#4    2        e     u  ]                 _
E4     2        e     u                    and
A4     2        e     u                    He
G4     2        e     u         +          shall
measure 72
F#4    6        q.    u         (          reign_
E4     2        e     u                    _
D4     6        q.    u         )          _
D4     2        e     u                    for
measure 73
D4     2        e     u  [                 e-
C#4    2        e     u  ]                 -
D4     2        e     u                    ver
D4     2        e     u                    and
D4     4        q     u         (          e-
C#4    4        q     u         )          -
measure 74
D4     8        h     u                    ver,
D4     4        q     u                    King
D4     4        q     u                    of
measure 75
D4     4        q     u                    Kings,
rest   2        e
A4     2        e     u                    for
B4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
A4     2        e     u                    and
measure 76
B4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
D4     2        e     u                    and
D4     4        q     u                    He
D4     4        q     u                    shall
measure 77
D4     4        q     u                    reign,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 78
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
rest   4        q
A4     4        q     u                    and
measure 79
D4     4        q     d                    He
&
 D5    4        q     u
&
A4     4        q     u                    shall
B4     4        q     u                    reign
D4     4        q     u                    for
measure 80
G4     4        q     u                    e-
F#4    2        e     u                    ver
E4     2        e     u                    and
E4     8        h     u                    e-
measure 81
F#4    4        q     u                    ver,
rest   4        q
F#4    4        q     u                    King
F#4    3        e.    u  [                 of_
G4     1        s     u  ]\                _
measure 82
A4     4        q     u                    Kings,
rest   2        e
F#4    2        e     u                    and
F#4    4        q     u                    Lord
F#4    3        e.    u  [                 of_
G4     1        s     u  ]\                _
measure 83
A4     4        q     u                    Lords,
rest   4        q
F#4    4        q     u                    King
F#4    4        q     u                    of
measure 84
A4     4        q     u                    Kings,
rest   2        e
F#4    2        e     u                    and
F#4    4        q     u                    Lord
F#4    3        e.    u  [                 of_
G4     1        s     u  ]\                _
measure 85
A4     4        q     u                    Lords,
rest   4        q
rest   4        q
F#4    4        q     u                    and
measure 86
F#4    4        q     u                    He
F#4    4        q     u                    shall
D4     4        q     u                    reign
A4     4        q     u                    for
measure 87
E4     4        q     u                    e-
A4     2        e     u                    ver
A4     2        e     u                    and
A4     8        h     u                    e-
measure 88
A4     4        q     u                    ver,
rest   2        e
A4     2        e     u                    for
B4     2        e     u                    e-
A4     2        e     u                    ver
rest   2        e
A4     2        e     u                    and
measure 89
B4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
A4     2        e     u                    for
B4     2        e     u                    e-
A4     2        e     u                    ver
rest   2        e
A4     2        e     u                    and
measure 90
B4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 91
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   2        e
A4     1        s     u                    Hal-
A4     1        s     u                    le-
measure 92
B4     2        e     u                    lu-
A4     2        e     u                    jah,
rest   4        q
rest   4        q
F#4    4        q     u                    Hal-
measure 93
G4    12        h.    u                    le-
G4     4        q     u                    lu-
measure 94
F#4   16        w     u                    jah.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 09
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/09} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:81fcd9b110bb21b7375059c5753c27c7]
06/24/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 9 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:34   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
F#4    6        q.    d                    Hal-
D4     2        e     d                    le-
D4     2        e     d                    lu-
D4     2        e     d                    jah,
rest   4        q
measure 5
F#4    6        q.    d                    Hal-
F#4    2        e     d                    le-
D4     2        e     d                    lu-
D4     2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 6
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     2        e     d                    Hal-
measure 7
E4     2        e     d         (          le-
A3     4        q     u         )          -
A3     2        e     u                    lu-
A3     4        q     u                    jah,
rest   4        q
measure 8
C#4    6        q.    d                    Hal-
E4     2        e     d                    le-
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   4        q
measure 9
C#4    6        q.    d                    Hal-
E4     2        e     d                    le-
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
measure 10
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   2        e
E4     2        e     d                    Hal-
measure 11
D4     2        e     d  [                 le-
E4     2        e     d  =                 -
F#4    2        e     d  ]                 -
D4     2        e     d                    lu-
E4     4        q     d                    jah,
rest   4        q
measure 12
A3     8        h     u                    for
B3     4        q     d                    the
C#4    4        q     d                    Lord
measure 13
D4     2        e     d                    God
D3     2        e     u                    om-
D4     6        q.    d                    ni-
D4     2        e     d                    po-
C#4    4        q     d                    tent
measure 14
B3     8        h     u                    reign-
A3     4        q     u                    eth,
rest   2        e
A3     1        s     u                    Hal-
A3     1        s     u                    le-
measure 15
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
measure 16
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   4        q
measure 17
D4     8        h     d                    for
E4     4        q     d                    the
F#4    4        q     d                    Lord
measure 18
G4     2        e     d                    God
G3     2        e     u                    om-
G3     6        q.    u                    ni-
G3     2        e     u                    po-
F#3    4        q     u                    tent
measure 19
E3     8        h     u                    reign-
D3     4        q     u                    eth,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 20
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 21
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   4        q
measure 22
rest   4        q
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     u                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 23
B3     2        e     d                    lu-
B3     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     u                    jah,Hal-
D4     4-       q     d        -           le-
measure 24
D4     4        q     d                    -
C#4    4        q     d                    lu-
D4     2        e     d                    jah,
F#4    1        s     d                    Hal-
F#4    1        s     d                    le-
A4     2        e     d                    lu-
F#4    2        e     d                    jah,
measure 25
A3     8        h     u                    for
B3     4        q     u                    the
C#4    4        q     d                    Lord
measure 26
D4     2        e     d                    God
D3     2        e     u                    om-
D4     6        q.    d                    ni-
D4     2        e     d                    po-
C#4    4        q     d                    tent
measure 27
B3     8        h     u                    reign-
A3     2        e     u                    eth,
E4     1        s     d                    Hal-
E4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     u                    jah,
measure 28
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
F#4    2        e     d                    lu-
D4     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     u                    jah,
measure 29
D4     8        h     d                    for
E4     4        q     d                    the
F#4    4        q     d                    Lord
measure 30
G4     2        e     d                    God
G3     2        e     u                    om-
G4     6        q.    d                    ni-
G4     2        e     d                    po-
F#4    4        q     d                    tent
measure 31
E4     8        h     d                    reign-
D4     6        q.    d                    eth,
F#4    2        e     d                    Hal-
measure 32
G4     6        q.    d                    le-
G4     2        e     d                    lu-
F#4    8        h     d                    jah!
measure 33
rest   8        h
rest   4        q
D4     4        q     d                    The
measure 34
A3     4        q     u                    king-
D3     4        q     u                    dom
A3     6        q.    u                    of
A3     2        e     u                    this
measure 35
A3    16        w     u                    world
measure 36
rest   8        h
A3     4        q     u                    is
G3     3        e.    u  [                 be-
F#3    1        s     u  ]\                -
measure 37
F#3   12        h.    u                    come
D4     4        q     d                    the
measure 38
E4     4        q     d                    king-
G4     4        q     d                    dom
A3     6        q.    u                    of
A3     2        e     u                    our
measure 39
A3     6        q.    u                    Lord
G3     2        e     u                    and
A3     4        q     u                    of
D4     4        q     d                    his
measure 40
E4     6        q.    d                    Christ,
D4     2        e     d                    and
D4     4        q     d                    of
E4     4        q     d                    his
measure 41
F#4    8        h     d                    Christ,
rest   8        h
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
D4     4        q     d                    and
measure 44
A4     4        q     d                    He
C#4    4        q     d                    shall
F#4    4        q     d                    reign
A3     4        q     u                    for
measure 45
D4     4        q     d                    e-
C#4    2        e     d                    ver
B3     2        e     d                    and
C#4    4        q     d         (          e-
B3     3        e.    u  [                 -
A3     1        s     u  ]\     )          -
measure 46
A3     4        q     u                    ver,
rest   4        q
rest   2        e
A3     2        e     u                    and
D4     2        e     d                    He
D4     2        e     d                    shall
measure 47
D4     4        q     d                    reign
rest   2        e
B3     2        e     d                    for
E4     2        e     d  [                 e-
C#4    2        e     d  ]                 -
D4     2        e     d                    ver
D4     2        e     d                    and
measure 48
D4     4        q     d         (          e-
C#4    4        q     d         )          -
D4     4        q     d                    ver,
rest   4        q
measure 49
rest   8        h
rest   2        e
D4     2        e     d                    and
C#4    2        e     d                    He
A3     2        e     u                    shall
measure 50
F#4    2        e     d         (          reign_
E4     4        q     d         )          _
F#4    2        e     d                    for
E4     2        e     d                    e-
E4     2        e     d                    ver
rest   2        e
E4     2        e     d                    and
measure 51
E4     4        q     d                    e-
C#4    4        q     d                    ver,
rest   8        h
measure 52
rest   4        q
rest   2        e
E4     2        e     d                    for
F#4    2        e     d                    e-
E4     2        e     d                    ver
rest   2        e
E4     2        e     d                    and
measure 53
F#4    2        e     d                    e-
E4     2        e     d                    ver,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
measure 54
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
E4     2        e     d                    for
F#4    2        e     d                    e-
E4     2        e     d                    ver
rest   2        e
E4     2        e     d                    and
measure 56
F#4    2        e     d                    e-
E4     2        e     d                    ver,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   2        e
E4     1        s     d                    Hal-
E4     1        s     d                    le-
measure 57
F#4    2        e     d                    lu-
E4     2        e     d                    jah,
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
D4     2        e     d                    for
G4     2        e     d                    e-
F#4    2        e     d                    ver
rest   2        e
D4     2        e     d                    and
measure 59
G4     2        e     d                    e-
F#4    2        e     d                    ver,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 60
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
B3     2        e     d                    for
C#4    2        e     d                    e-
B3     2        e     d                    ver
rest   2        e
B3     2        e     d                    and
measure 62
C#4    2        e     d                    e-
B3     2        e     d                    ver,
rest   2        e
B3     1        s     d                    Hal-
B3     1        s     d                    le-
C#4    2        e     d                    lu-
B3     2        e     d                    jah,
rest   2        e
B3     1        s     d                    Hal-
B3     1        s     d                    le-
measure 63
C#4    2        e     d                    lu-
B3     2        e     d                    jah,
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
C#4    2        e     d                    for
D4     2        e     d                    e-
C#4    2        e     d                    ver
rest   2        e
C#4    2        e     d                    and
measure 65
D4     2        e     d                    e-
C#4    2        e     d                    ver,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
C#4    2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 66
D4     4        q     d                    lu-
D4     4        q     d                    jah,
rest   8        h
measure 67
rest   8        h
D4     4        q     d                    King
D4     4        q     d                    of
measure 68
E4     6        q.    d                    Kings,
E4     2        e     d                    and
D4     2        e     d  [                 Lord_
C#4    2        e     d  ]                 _
D4     2        e     d  [                 of_
E4     2        e     d  ]                 _
measure 69
C#4    8        h     d                    Lords,
rest   8        h
measure 70
rest   2        e
A3     2        e     u                    and
B3     2        e     u                    He
C#4    2        e     d                    shall
F#3    2        e     u                    reign,
A3     2        e     u                    and
A3     4-       q     u        -           He_
measure 71
A3     4        q     u                    _
G#3    4        q     u                    shall
A3     4        q     u                    reign,
rest   4        q
measure 72
rest   2        e
A3     2        e     u                    and
D4     2        e     d                    He
C#4    2        e     d                    shall
B3     6        q.    d                    reign
A3     2        e     u                    for
measure 73
G3     4        q     u                    e-
A3     2        e     u                    ver
B3     2        e     u                    and
A3     8        h     u                    e-
measure 74
A3     8        h     u                    ver,
D4     4        q     d                    King
D4     4        q     d                    of
measure 75
D4    16-       w     d        -           Kings,_
measure 76
D4     6        q.    d                    _
D4     2        e     d                    and
D4     4        q     d                    He
D4     4        q     d                    shall
measure 77
D4    16-       w     d        -           reign,_
measure 78
D4     4        q     d                    _
rest   2        e
F#4    2        e     d                    and
F#4    4        q     d                    He
D4     4        q     d                    shall
measure 79
D4     4        q     d                    reign
D4     4        q     d                    for
B3     4        q     u                    e-
A3     2        e     u                    ver,
A3     2        e     u                    for
measure 80
G3     4        q     u                    e-
A3     2        e     u                    ver
A3     2        e     u                    and
A3     8        h     u                    e-
measure 81
A3     4        q     u                    ver,
rest   4        q
D4     4        q     d                    King
D4     3        e.    d  [                 of_
E4     1        s     d  ]\                _
measure 82
F#4    4        q     d                    Kings,
rest   2        e
D4     2        e     d                    and
D4     4        q     d                    Lord
D4     3        e.    d  [                 of_
E4     1        s     d  ]\                _
measure 83
F#4    4        q     d                    Lords,
rest   4        q
D4     4        q     d                    King
D4     4        q     d                    of
measure 84
F#4    4        q     d                    Kings,
rest   2        e
D4     2        e     d                    and
D4     4        q     d                    Lord
D4     3        e.    d  [                 of_
E4     1        s     d  ]\                _
measure 85
F#4    4        q     d                    Lords,
rest   4        q
rest   4        q
D4     4        q     d                    and
measure 86
D4     4        q     d                    He
A3     4        q     u                    shall
B3     4        q     u                    reign
A3     4        q     u                    for
measure 87
C#4    4        q     d                    e-
D4     2        e     d                    ver
D4     2        e     d                    and
D4     4        q     d         (          e-
C#4    4        q     d         )          -
measure 88
F#4    4        q     d                    ver,
rest   2        e
D4     2        e     d                    and
G4     2        e     d                    e-
F#4    2        e     d                    ver
rest   2        e
D4     2        e     d                    and
measure 89
G4     2        e     d                    e-
F#4    2        e     d                    ver,
rest   2        e
D4     2        e     d                    for
G4     2        e     d                    e-
F#4    2        e     d                    ver
rest   2        e
D4     2        e     d                    and
measure 90
G4     2        e     d                    e-
F#4    2        e     d                    ver,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 91
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 92
G4     2        e     d                    lu-
F#4    2        e     d                    jah,
rest   4        q
rest   4        q
A3     4        q     u                    Hal-
measure 93
B3    12        h.    u                    le-
B3     4        q     u                    lu-
measure 94
A3    16        w     u                    jah.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 10
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/10} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:6837f79c3cb60e972648f7286d78a35c]
06/24/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 10 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
D3     6        q.    d                    Hal-
F#3    2        e     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   4        q
measure 5
D3     6        q.    d                    Hal-
F#3    2        e     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 6
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    2        e     d                    Hal-
measure 7
E3     2        e     d  [                 le-
D3     2        e     d  =                 -
A3     2        e     d  ]                 -
A3     2        e     d                    lu-
D3     4        q     d                    jah,
rest   4        q
measure 8
A3     6        q.    d                    Hal-
C#4    2        e     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   4        q
measure 9
A3     6        q.    d                    Hal-
C#4    2        e     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 10
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    2        e     d                    Hal-
measure 11
D4     2        e     d  [                 le-
C#4    2        e     d  ]                 -
B3     4        q     d                    lu-
A3     4        q     d                    jah,
rest   4        q
measure 12
A3     8        h     d                    for
B3     4        q     d                    the
C#4    4        q     d                    Lord
measure 13
D4     2        e     d                    God
D3     2        e     d                    om-
D4     6        q.    d                    ni-
D4     2        e     d                    po-
C#4    4        q     d                    tent
measure 14
B3     8        h     d                    reign-
A3     4        q     d                    eth,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 15
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 16
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   4        q
measure 17
D3     8        h     d                    for
E3     4        q     d                    the
F#3    4        q     d                    Lord
measure 18
G3     2        e     d                    God
G2     2        e     u                    om-
G3     6        q.    d                    ni-
G3     2        e     d                    po-
F#3    4        q     d                    tent
measure 19
E3     8        h     d                    reign-
D3     4        q     d                    eth,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 20
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 21
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   4        q
measure 22
rest  16
measure 23
rest  16
measure 24
rest   4        q
rest   2        e
A3     1        s     d                    Hal-
A3     1        s     d                    le-
F#3    2        e     d                    lu-
D3     2        e     d                    jah,
rest   4        q
measure 25
A3     8        h     d                    for
B3     4        q     d                    the
C#4    4        q     d                    Lord
measure 26
D4     2        e     d                    God
D3     2        e     d                    om-
D4     6        q.    d                    ni-
D4     2        e     d                    po-
C#4    4        q     d                    tent
measure 27
B3     8        h     d                    reign-
A3     4        q     d                    eth,
rest   2        e
A3     1        s     d                    Hal-
A3     1        s     d                    le-
measure 28
F#3    2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     d                    jah,
rest   4        q
measure 29
rest   4        q
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
C#4    2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 30
B3     2        e     d                    lu-
G3     2        e     d                    jah,
rest   2        e
E3     1        s     d                    Hal-
E3     1        s     d                    le-
A3     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
B3     1        s     d                    Hal-
B3     1        s     d                    le-
measure 31
G3     2        e     d                    lu-
E3     2        e     d                    jah,Hal-
A3     3        e.    d                    le-
G3     1        s     d                    lu-
F#3    4        q     d                    jah,
rest   2        e
D4     1        s     d                    Hal-
D4     1        s     d                    le-
measure 32
B3     2        e     d                    lu-
G3     2        e     d                    jah,Hal-
B3     2        e     d                    le-
C#4    2        e     d                    lu-
D4     8        h     d                    jah!
measure 33
rest   8        h
rest   4        q
D3     4        q     d                    The
measure 34
C#3    4        q     u                    King-
B2     4        q     u                    dom
A2     4        q     u                    of
G3     3        e.    d  [                 this_
F#3    1        s     d  ]\                _
measure 35
F#3   16        w     d                    world
measure 36
rest   8        h
A2     6        q.    u                    is
A2     2        e     u                    be-
measure 37
D3    12        h.    d                    come
D4     4        q     d                    the
measure 38
C#4    4        q     d                    king-
B3     4        q     d                    dom
A3     4        q     d                    of
G3     3        e.    d  [                 our_
F#3    1        s     d  ]\                _
measure 39
F#3    6        q.    d                    Lord
E3     2        e     d                    and
D3     4        q     d                    of
B3     4        q     d                    his
measure 40
A3     6        q.    d                    Christ,
F#3    2        e     d                    and
G3     4        q     d                    of
E3     4        q     d                    his
measure 41
D3     6        q.    d                    Christ,
A3     2        e     d                    and
D4     4        q     d                    He
F#3    4        q     d                    shall
measure 42
B3     4        q     d                    reign
D3     4        q     d                    for
G3     4        q     d                    e-
F#3    2        e     d                    ver
E3     2        e     d                    and
measure 43
E3     8        h     d         t          e-
D3     4        q     d                    ver,
rest   4        q
measure 44
rest   4        q
rest   2        e
A3     2        e     d                    for
D4     2        e     d                    e-
D3     2        e     d                    ver
rest   2        e
F#3    2        e     d                    and
measure 45
B3     2        e     d  [                 e-
G#3    2        e     d  ]                 -
A3     4        q     d                    ver,
rest   2        e
E3     2        e     d                    and
D3     2        e     d                    He
E3     2        e     d                    shall
measure 46
C#3    2        e     u                    reign,
A3     2        e     d                    and
G3     2        e     d                    He
A3     2        e     d                    shall
F#3    4        q     d                    reign
rest   2        e
F#3    2        e     d                    for
measure 47
G3     2        e     d                    e-
D3     2        e     d                    ver,
rest   4        q
rest   4        q
rest   2        e
G3     2        e     d                    for
measure 48
A3     2        e     d                    e-
A2     2        e     u                    ver
rest   2        e
A3     2        e     d                    and
F#3    2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
D4     2        e     d                    for
measure 49
C#4    2        e     d                    e-
A3     2        e     d                    ver
rest   2        e
C#4    2        e     d                    and
D4     2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
F#3    2        e     d                    for
measure 50
B3     2        e     d  [                 e-
G#3    2        e     d  ]                 -
A3     2        e     d                    ver,
D3     2        e     d                    for
E3     2        e     d                    e-
E3     2        e     d                    ver
rest   2        e
E3     2        e     d                    and
measure 51
C#3    4        q     u                    e-
A2     4        q     u                    ver,
rest   8        h
measure 52
rest   4        q
rest   2        e
C#4    2        e     d                    for
D4     2        e     d                    e-
A3     2        e     d                    ver
rest   2        e
C#4    2        e     d                    and
measure 53
D4     2        e     d                    e-
A3     2        e     d                    ver,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 54
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
C#4    2        e     d                    for
D4     2        e     d                    e-
A3     2        e     d                    ver
rest   2        e
C#4    2        e     d                    and
measure 56
D4     2        e     d                    e-
A3     2        e     d                    ver,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   2        e
C#4    1        s     d                    Hal-
C#4    1        s     d                    le-
measure 57
D4     2        e     d                    lu-
A3     2        e     d                    jah,
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
F#3    2        e     d                    for
G3     2        e     d                    e-
D3     2        e     d                    ver
rest   2        e
F#3    2        e     d                    and
measure 59
G3     2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 60
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
G#3    2        e     d                    for
A3     2        e     d                    e-
E3     2        e     d                    ver
rest   2        e
G#3    2        e     d                    and
measure 62
A3     2        e     d                    e-
E3     2        e     d                    ver,
rest   2        e
G#3    1        s     d                    Hal-
G#3    1        s     d                    le-
A3     2        e     d                    lu-
E3     2        e     d                    jah,
rest   2        e
G#3    1        s     d                    Hal-
G#3    1        s     d                    le-
measure 63
A3     2        e     d                    lu-
E3     2        e     d                    jah,
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
A#3    2        e     d                    for
B3     2        e     d                    e-
F#3    2        e     d                    ver
rest   2        e
A#3    2        e     d                    and
measure 65
B3     2        e     d                    e-
F#3    2        e     d                    ver,
rest   2        e
A#3    1        s     d                    Hal-
A#3    1        s     d                    le-
B3     2        e     d                    lu-
F#3    2        e     d                    jah,
rest   2        e
A#3    1        s     d                    Hal-
A#3    1        s     d                    le-
measure 66
B3     4        q     d                    lu-
B2     4        q     u                    jah,
rest   8        h
measure 67
rest   8        h
B3     4        q     d                    King
B3     4        q     d                    of
measure 68
C#4    6        q.    d                    Kings,
C#4    2        e     d                    and
D4     4        q     d                    Lord
D3     4        q     d                    of
measure 69
A3     6        q.    d                    Lords,
A2     2        e     u                    and
A3     4        q     d                    He
C#3    4        q     u                    shall
measure 70
F#3    4        q     d                    reign
A2     4        q     u                    for
D3     4        q     d                    e-
C#3    2        e     u                    ver
C#3    2        e     u                    and
measure 71
B2     8        h     u                    e-
A2     4        q     u                    ver,
rest   4        q
measure 72
rest   8        h
rest   2        e
D3     2        e     d                    and
G3     2        e     d                    He
F#3    2        e     d                    shall
measure 73
E3     4        q     d                    reign
F#3    2        e     d  [                 for_
G3     2        e     d  ]                 _
A3     4        q     d                    e-
G3     2        e     d                    ver
A3     2        e     d                    and
measure 74
F#3    4        q     d                    e-
D3     4        q     d                    ver,
D4     4        q     d                    King
D4     4        q     d                    of
measure 75
D4     4        q     d                    Kings,
rest   2        e
F#3    2        e     d                    for
G3     2        e     d                    e-
D3     2        e     d                    ver
rest   2        e
F#3    2        e     d                    and
measure 76
G3     2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
D4     2        e     d                    and
D4     4        q     d                    He
D4     4        q     d                    shall
measure 77
D4     4        q     d                    reign,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 78
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
D3     2        e     d                    and
D4     4        q     d                    He
F#3    4        q     d                    shall
measure 79
B3     4        q     d                    reign
D3     4        q     d                    for
G3     4        q     d                    e-
F#3    2        e     d                    ver,
F#3    2        e     d                    for
measure 80
E3     4        q     d                    e-
D3     2        e     d                    ver
D3     2        e     d                    and
A3     8        h     d                    e-
measure 81
D3     4        q     d                    ver,
rest   4        q
D3     4        q     d                    King
D3     4        q     d                    of
measure 82
D4     4        q     d                    Kings,
rest   2        e
D3     2        e     d                    and
D3     4        q     d                    Lord
D3     4        q     d                    of
measure 83
D4     4        q     d                    Lords,
rest   4        q
D3     4        q     d                    King
D3     4        q     d                    of
measure 84
D4     4        q     d                    Kings,
rest   2        e
D3     2        e     d                    and
D3     4        q     d                    Lord
D3     4        q     d                    of
measure 85
D4     4        q     d                    Lords,
rest   2        e
D3     2        e     d                    and
D4     4        q     d                    He
F#3    4        q     d                    shall
measure 86
B3     4        q     d                    reign
D3     4        q     d                    for
G3     4        q     d                    e-
F#3    2        e     d                    ver
F#3    2        e     d                    and
measure 87
E3     4        q     d                    e-
D3     2        e     d                    ver,
D3     2        e     d                    and
A3     8        h     d                    e-
measure 88
D3     4        q     d                    ver,
rest   2        e
F#3    2        e     d                    for
G3     2        e     d                    e-
D3     2        e     d                    ver
rest   2        e
F#3    2        e     d                    and
measure 89
G3     2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
F#3    2        e     d                    for
G3     2        e     d                    e-
D3     2        e     d                    ver
rest   2        e
F#3    2        e     d                    and
measure 90
G3     2        e     d                    e-
D3     2        e     d                    ver,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 91
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   2        e
F#3    1        s     d                    Hal-
F#3    1        s     d                    le-
measure 92
G3     2        e     d                    lu-
D3     2        e     d                    jah,
rest   4        q
rest   4        q
D3     4        q     d                    Hal-
measure 93
G3    12        h.    d                    le-
G3     4        q     d                    lu-
measure 94
D3    16        w     d                    jah.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 11
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/2-21/11} [KHM:2846311357]
TIMESTAMP: DEC/26/2001 [md5sum:af862b46d9b308f95c0b71a45c831c79]
06/24/90 E. Correia
WK#:56        MV#:2,21
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 11 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Allegro
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
G3     2        e     d  [
D3     2        e     d  =
F#3    2        e     d  =
A3     2        e     d  ]
measure 2
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
D3     2        e     d  ]
E3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 3
E3     2        e     d  [
D3     2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
D3     4        q     d
rest   4        q
measure 4
D3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
F#3    2        e     d  ]
G3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 5
D3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  =
F#3    2        e     d  ]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 6
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
f1              6
F#3    2        e     d
measure 7
E3     2        e     d  [
D3     2        e     d  =
A3     2        e     d  =
A2     2        e     d  ]
D3     2        e     d  [
F#3    2        e     d  =
E3     2        e     d  =
D3     2        e     d  ]
measure 8
A3     6        q.    d
C#4    2        e     d
D4     2        e     d  [
A3     2        e     d  ]
rest   4        q
measure 9
A3     6        q.    d
C#4    2        e     d
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
measure 10
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    2        e     d
measure 11
D4     2        e     d  [
C#4    2        e     d  ]
f1     2        7
f1              6
B3     4        q     d
A3     4        q     d
rest   4        q
measure 12
*               D       Tasto solo
A3     8        h     d
B3     4        q     d
C#4    4        q     d
measure 13
D4     2        e     d  [
D3     2        e     d  ]
D4     8        h     d
C#4    4        q     d
measure 14
B3     8        h     d
A3     4        q     d
rest   2        e
*               D       Tutti
f1              6
C#4    1        s     d  [[
C#4    1        s     d  ]]
measure 15
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
measure 16
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
rest   4        q
measure 17
*               D       Tasto solo
D3     8        h     d
E3     4        q     d
F#3    4        q     d
measure 18
G3     2        e     d  [
G2     2        e     d  ]
G3     8        h     d
F#3    4        q     d
measure 19
E3     8        h     d
D3     4        q     d
rest   2        e
*               D       (Tutti)
f1              6
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 20
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 21
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   4        q
$ C:15
measure 22
D5     6        q.    d
$ C:12
D4     1        s     d  [[
D4     1        s     d  ]]
f1              6
C#4    2        e     d  [
A3     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 23
f1              6
B3     2        e     d  [
B3     2        e     d  ]
rest   2        e
E4     1        s     d  [[
E4     1        s     d  ]]
f2              6 5
C#4    2        e     d  [
A3     2        e     d  ]
D4     4-       q     d        -
measure 24
D4     4        q     d
C#4    2        e     d  [
$ C:22
A3     1        s     d  =[
A3     1        s     d  ]]
F#3    2        e     d  [
D3     2        e     d  =
D4     2        e     d  =
D3     2        e     d  ]
measure 25
A3     8        h     d
B3     4        q     d
C#4    4        q     d
measure 26
D4     2        e     d  [
D3     2        e     d  ]
D4     8        h     d
C#4    4        q     d
measure 27
B3     8        h     d
A3     4        q     d
rest   2        e
A3     1        s     d  [[
A3     1        s     d  ]]
measure 28
F#3    2        e     d  [
D3     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
C#4    2        e     d  [
A3     2        e     d  =
C#4    2        e     d  =
A3     2        e     d  ]
measure 29
D4     6        q.    d
D4     1        s     d  [[
D4     1        s     d  ]]
C#4    2        e     d  [
A3     2        e     d  ]
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 30
B3     2        e     d  [
G3     2        e     d  ]
rest   2        e
E3     1        s     d  [[
E3     1        s     d  ]]
A3     2        e     d  [
A3     2        e     d  ]
rest   2        e
B3     1        s     d  [[
B3     1        s     d  ]]
measure 31
G3     2        e     d  [
E3     2        e     d  =
A3     3        e.    d  =
G3     1        s     d  ]\
F#3    4        q     d
rest   2        e
D4     1        s     d  [[
D4     1        s     d  ]]
measure 32
B3     2        e     d  [
G3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
D4     2        e     d  [
D3     1        s     d  =[
D3     1        s     d  ]]
D3     2        e     d  [
D3     2        e     d  ]
measure 33
B2     2        e     u  [
B2     1        s     u  =[
B2     1        s     u  ]]
G2     2        e     u  [
G2     2        e     u  ]
D3     4        q     d
D3     4        q     d
measure 34
C#3    4        q     u
B2     4        q     u
A2     4        q     u
f2              4 2
G3     4        q     d
measure 35
f1              6
F#3   12        h.    d
D3     4        q     d
measure 36
C#3    4        q     u
B2     4        q     u
A2     6        q.    u
A2     2        e     u
measure 37
D3    12        h.    d
D4     4        q     d
measure 38
f1              6
C#4    4        q     d
f1              6
B3     4        q     d
f2              6 4
A3     4        q     d
f2              5 3
G3     4        q     d
measure 39
F#3    6        q.    d
E3     2        e     d
D3     4        q     d
f1              6+
B3     4        q     d
measure 40
A3     6        q.    d
F#3    2        e     d
G3     4        q     d
E3     4        q     d
measure 41
D3     6        q.    d
*               D       Tasto solo
A3     2        e     d
D4     4        q     d
F#3    4        q     d
measure 42
B3     4        q     d
D3     4        q     d
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 43
E3     8        h     d
D3     4        q     d
$ C:13
D4     4        q     d
measure 44
A4     4        q     d
C#4    2        e     d  [
$ C:22
*               D       (Tutti)
A3     2        e     d  ]
D4     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 45
B3     2        e     d  [
G#3    2        e     d  ]
A3     4        q     d
rest   2        e
f2              6 4
E3     2        e     d  [
f2              4+ 2
D3     2        e     d  =
E3     2        e     d  ]
measure 46
C#3    2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
F#3    4        q     d
rest   2        e
F#3    2        e     d
measure 47
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
B3     2        e     d
E4     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  =
G3     2        e     d  ]
measure 48
A3     2        e     d  [
A2     2        e     d  ]
rest   2        e
A3     2        e     d
F#3    2        e     d  [
D3     2        e     d  ]
rest   2        e
D4     2        e     d
measure 49
C#4    2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    2        e     d
D4     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 50
B3     2        e     d  [
G#3    2        e     d  =
A3     2        e     d  =
D3     2        e     d  ]
E3     2        e     d  [
E2     2        e     u  ]
rest   2        e
E3     2        e     d
measure 51
C#3    4        q     u
A2     4        q     u
rest   8        h
measure 52
rest   4        q
rest   2        e
C#4    2        e     d
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    2        e     d
measure 53
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
measure 54
D4     2        e     d  [
A3     2        e     d  ]
rest   4        q
rest   8        h
measure 55
rest   4        q
rest   2        e
C#4    2        e     d
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    2        e     d
measure 56
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
rest   2        e
C#4    1        s     d  [[
C#4    1        s     d  ]]
measure 57
D4     2        e     d  [
A3     2        e     d  ]
rest   4        q
rest   8        h
measure 58
rest   4        q
rest   2        e
F#3    2        e     d
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 59
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 60
G3     2        e     d  [
D3     2        e     d  ]
rest   4        q
rest   8        h
measure 61
rest   4        q
rest   2        e
G#3    2        e     d
A3     2        e     d  [
E3     2        e     d  ]
rest   2        e
G#3    2        e     d
measure 62
A3     2        e     d  [
E3     2        e     d  ]
rest   2        e
G#3    1        s     d  [[
G#3    1        s     d  ]]
A3     2        e     d  [
E3     2        e     d  ]
rest   2        e
G#3    1        s     d  [[
G#3    1        s     d  ]]
measure 63
A3     2        e     d  [
E3     2        e     d  ]
rest   4        q
rest   8        h
measure 64
rest   4        q
rest   2        e
A#3    2        e     d
B3     2        e     d  [
F#3    2        e     d  ]
rest   2        e
A#3    2        e     d
measure 65
B3     2        e     d  [
F#3    2        e     d  ]
rest   2        e
A#3    1        s     d  [[
A#3    1        s     d  ]]
B3     2        e     d  [
F#3    2        e     d  ]
rest   2        e
A#3    1        s     d  [[
A#3    1        s     d  ]]
measure 66
B3     4        q     d
B2     4        q     u
rest   8        h
measure 67
rest   8        h
B3     4        q     d
B3     4        q     d
measure 68
C#4    6        q.    d
C#4    2        e     d
D4     4        q     d
D3     4        q     d
measure 69
A3     6        q.    d
A2     2        e     u
A3     4        q     d
C#3    4        q     u
measure 70
F#3    4        q     d
A2     4        q     u
D3     4        q     d
C#3    4        q     u
measure 71
B2     8        h     u
A2     2        e     d  [
$ C:15
E4     2        e     d  =
A4     2        e     d  =
G4     2        e     d  ]
measure 72
F#4    2        e     d  [
$ C:12
A3     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
B3     2        e     d  [
$ C:22
D3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 73
E3     4        q     d
F#3    2        e     d  [
G3     2        e     d  ]
A3     4        q     d
G3     2        e     d  [
A3     2        e     d  ]
measure 74
F#3    4        q     d
D3     4        q     d
rest   8        h
measure 75
rest   4        q
rest   2        e
F#3    2        e     d
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 76
G3     2        e     d  [
D3     2        e     d  ]
rest   4        q
rest   8        h
measure 77
rest   4        q
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 78
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
D4     4        q     d
F#3    4        q     d
measure 79
B3     4        q     d
D3     4        q     d
G3     4        q     d
F#3    2        e     d  [
F#3    2        e     d  ]
measure 80
E3     4        q     d
D3     2        e     d  [
D3     2        e     d  ]
A3     8        h     d
measure 81
D3     4        q     d
rest   4        q
D3     4        q     d
D3     4        q     d
measure 82
D4     4        q     d
rest   2        e
D3     2        e     d
D3     4        q     d
D3     4        q     d
measure 83
D4     4        q     d
rest   4        q
D3     4        q     d
D3     4        q     d
measure 84
D4     4        q     d
rest   2        e
D3     2        e     d
D3     4        q     d
D3     4        q     d
measure 85
D4     4        q     d
rest   2        e
D3     2        e     d
D4     4        q     d
F#3    4        q     d
measure 86
B3     4        q     d
D3     4        q     d
G3     4        q     d
F#3    2        e     d  [
F#3    2        e     d  ]
measure 87
E3     4        q     d
D3     2        e     d  [
D3     2        e     d  ]
A3     8        h     d
measure 88
D3     4        q     d
rest   2        e
F#3    2        e     d
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 89
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    2        e     d
measure 90
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 91
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
G3     2        e     d  [
D3     2        e     d  ]
rest   2        e
F#3    1        s     d  [[
F#3    1        s     d  ]]
measure 92
G3     2        e     d  [
D3     2        e     d  ]
rest   4        q
rest   4        q
D3     4        q     d
measure 93
G2    12        h.    u
G2     4        q     u
measure 94
D2    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
