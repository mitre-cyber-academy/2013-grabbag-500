&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/1} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:c2bb919240d751b324ae635e36177d17]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Tromba
1 19
Group memberships: score
score: part 1 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:3/4   C:4   D:Pomposo, ma non allegro
D4     3        e.    u  [
D4     1        s     u  ]\
measure 1
F#4    4        q     u
rest   2        e
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 2
A4     4        q     u
rest   2        e
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 3
D5     6        q.    d
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  ]
measure 4
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 5
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 6
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 7
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         t
E5     2        e     d
measure 8
E5     8        h     d
E5     4        q     d
measure 9
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 10
E5     8        h     d
A5     4        q     d
measure 11
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 12
A5     8        h     d
G5     4        q     d         +
measure 13
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 14
E5     8        h     d
A5     4        q     d
measure 15
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 16
A5     8        h     d
A5     4        q     d
measure 17
E5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 18
G5     8        h     d
G5     4        q     d
measure 19
D5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 20
F#5    4        q     d
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 21
F#5    2        e     d  [
G5     2        e     d  ]
A5     8-       h     d        -
measure 22
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 23
F#5    2        e     d  [
G5     2        e     d  ]
A5     8-       h     d        -
measure 24
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 25
F#5    2        e     d  [
D5     2        e     d  ]
G5     4        q     d
G5     4        q     d
measure 26
G5     6        q.    d
A5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 27
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 28
D5     8        h     d
rest   4        q
mdouble 29      A
rest  12
measure 30
rest   4        q
rest   4        q
D4     3        e.    u  [
D4     1        s     u  ]\
measure 31
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 32
A4     4        q     u
rest   4        q
rest   4        q
measure 33
rest  12
measure 34
rest   4        q
rest   4        q
A4     4        q     u
measure 35
D5     3        e.    d  [
E5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  =\
F#5    3        e.    d  =
G5     1        s     d  ]\
measure 36
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 37
D5     4        q     d
E5     4        q     d
F#5    4        q     d
measure 38
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 39
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         &t
E5     2        e     d
measure 40
E5     8        h     d
rest   4        q
measure 41
rest  12
measure 42
rest  12
measure 43
rest  12
measure 44
rest  12
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
A4     4        q     u
measure 47
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 48
E5     6        q.    d
E5     2        e     d  [
E5     3        e.    d  =
E5     1        s     d  ]\
measure 49
A5     6        q.    d
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 50
E5    12-       h.    d        -
measure 51
E5    12-       h.    d        -
measure 52
E5    12-       h.    d        -
measure 53
E5    12-       h.    d        -
measure 54
E5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 55
F#5    2        e     d  [
G#5    2        e     d  ]
A5     8-       h     d        -
measure 56
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 57
F#5    2        e     d  [
G5     2        e     d  =      +
A5     2        e     d  =
E5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
measure 58
F#5    4        q     d         &t
E5     4        q     d
rest   4        q
measure 59
rest  12
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
measure 68
rest   4        q
rest   4        q
A5     4        q     d         &f
measure 69
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 70
A5     8        h     d
G5     4        q     d         +
measure 71
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 72
E5     8        h     d
A5     4        q     d
measure 73
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 74
A5     4        q     d
rest   4        q
rest   4        q
measure 75
A5     4        q     d
rest   4        q
rest   4        q
measure 76
A5     4        q     d
rest   4        q
rest   4        q
measure 77
A5     4        q     d
rest   4        q
rest   4        q
measure 78
A5    12-       h.    d        -
measure 79
A5    12-       h.    d        -
measure 80
A5     8        h     d
G5     4        q     d
measure 81
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 82
E5     8        h     d
rest   4        q
measure 83
rest  12
measure 84
rest   4        q
rest   4        q
D4     3        e.    u  [
D4     1        s     u  ]\
measure 85
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 86
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 87
D5     6        q.    d
D5     2        e     d  [
D5     3        e.    d  =
D5     1        s     d  ]\
measure 88
F#5    6        q.    d
F#5    2        e     d  [
F#5    3        e.    d  =
F#5    1        s     d  ]\
measure 89
A5     6        q.    d
A5     2        e     d  [
A5     3        e.    d  =
A5     1        s     d  ]\
measure 90
F#5    4        q     d
D5     4        q     d
D5     4        q     d
measure 91
D5    12-       h.    d        -
measure 92
D5    12-       h.    d        -
measure 93
D5    12-       h.    d        -
measure 94
D5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 95
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 96
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 97
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 98
rest   4        q
rest   4        q
A5     4        q     d
measure 99
E5     3        e.    d  [
F#5    1        s     d  =\
E5     3        e.    d  =
F#5    1        s     d  =\
E5     3        e.    d  =
F#5    1        s     d  ]\
measure 100
G5     6        q.    d
A5     2        e     d  [
G5     2        e     d  =
A5     2        e     d  ]
measure 101
D5     3        e.    d  [
E5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  =\
D5     3        e.    d  =
E5     1        s     d  ]\
measure 102
F#5    3        e.    d  [
G5     1        s     d  =\
F#5    3        e.    d  =
G5     1        s     d  =\
F#5    3        e.    d  =
G5     1        s     d  ]\
measure 103
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 104
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 105
G5    12-       h.    d        -
measure 106
G5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  =
E5     2        e     d  ]
measure 107
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         &t
E5     2        e     d
measure 108
E5     8        h     d
rest   4        q
measure 109
rest  12
measure 110
rest   4        q
rest   4        q
G5     4        q     d
measure 111
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 112
E5     8        h     d
A5     4        q     d
measure 113
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 114
A5     4        q     d
rest   4        q
rest   4        q
measure 115
A5     4        q     d
rest   4        q
rest   4        q
measure 116
A5     4        q     d
rest   4        q
rest   4        q
measure 117
A5     4        q     d
rest   4        q
rest   4        q
measure 118
A5     4        q     d
E5     6        q.    d
G5     2        e     d         +
measure 119
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 120
D5     8        h     d
rest   4        q
measure 121
rest   4        q
D5     4        q     d
D5     4        q     d
measure 122
D5    12        h.    d
measure 123
rest   4        q
E5     4        q     d
E5     4        q     d
measure 124
E5    12        h.    d
measure 125
rest   4        q
F#5    4        q     d
F#5    4        q     d
measure 126
F#5   12        h.    d
measure 127
rest   4        q
D5     4        q     d
G5     4        q     d
measure 128
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 129
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 130
A5     4        q     d
rest   4        q
rest   4        q
measure 131
A5     4        q     d
rest   4        q
rest   4        q
measure 132
A5     4        q     d
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 133
F#5    2        e     d  [
G5     2        e     d  ]
A5     8-       h     d        -
measure 134
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 135
F#5    2        e     d  [
D5     2        e     d  ]
G5     6        q.    d
G5     2        e     d
measure 136
G5     6        q.    d
A5     2        e     d
F#5    4        q     d
measure 137
G5     4        q     d
E5     6        q.    d
D5     2        e     d
measure 138
D5    12        h.    d         F
measure 139
rest  12
measure 140
rest   4        q
rest   4        q
D4     3        e.    u  [      f
D4     1        s     u  ]\
measure 141
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 142
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 143
D5     6        q.    d
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  ]
measure 144
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 145
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 146
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 147
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         &t
E5     2        e     d
measure 148
E5     4        q     d
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 149
F#5    2        e     d  [
G5     2        e     d  ]
A5     8-       h     d        -
measure 150
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 151
F#5    2        e     d  [
G5     2        e     d  ]
A5     8-       h     d        -
measure 152
A5     6        q.    d
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 153
F#5    2        e     d  [
D5     2        e     d  ]
G5     4        q     d
G5     4        q     d
measure 154
G5     6        q.    d
A5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 155
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 156
*               C       (Fine)
D5     8        h     d         F
mdouble
rest   4        q
measure 157
rest  12
measure 158
rest  12
measure 159
rest  12
measure 160
rest  12
measure 161
rest  12
measure 162
rest  12
measure 163
rest  12
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest  12
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
rest  12
measure 174
rest  12
measure 175
rest  12
measure 176
rest  12
measure 177
rest  12
measure 178
rest  12
measure 179
rest  12
measure 180
rest  12
measure 181
rest  12
measure 182
rest  12
measure 183
rest  12
measure 184
rest  12
measure 185
rest  12
measure 186
rest  12
measure 187
rest  12
measure 188
rest  12
measure 189
rest  12
measure 190
rest  12
measure 191
rest  12
measure 192
rest  12
measure 193
rest  12
measure 194
rest  12
measure 195
rest  12
measure 196
rest  12
measure 197
rest  12
measure 198
rest  12
measure 199
rest  12
measure 200
rest  12
measure 201
rest  12
measure 202
rest  12
measure 203
rest  12
measure 204
rest  12
measure 205
rest  12
measure 206
rest  12
measure 207
rest  12
measure 208
rest  12
measure 209
rest  12
measure 210
rest  12
measure 211
rest  12
measure 212
rest  12
measure 213
rest  12
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/2} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:9b499f20bf72972d7a426075f025a32f]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino I
1 19
Group memberships: score
score: part 2 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:3/4   C:4   D:Pomposo, ma non allegro
D4     3        e.    u  [
D4     1        s     u  ]\
measure 1
F#4    4        q     u
rest   2        e
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 2
A4     4        q     u
rest   2        e
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 3
D5     6        q.    d
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  ]
measure 4
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 5
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 6
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 7
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         t
E5     2        e     d
measure 8
E5     8        h     d
rest   4        q
measure 9
rest  12
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
rest  12
measure 19
rest  12
measure 20
rest  12
measure 21
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 22
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 23
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 24
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 25
F#5    2        e     d  [
D5     2        e     d  ]
G5     4        q     d
G5     4        q     d
measure 26
G5     6        q.    d
A5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 27
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 28
D5     8        h     d
rest   4        q
mdouble 29      A
rest  12
measure 30
rest   4        q
rest   4        q
D4     3        e.    u  [
D4     1        s     u  ]\
measure 31
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 32
A4     4        q     u
rest   4        q
rest   4        q
measure 33
rest  12
measure 34
rest  12
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
rest   4        q
rest   4        q
A5     4        q     d         f
measure 41
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 42
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 43
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         &t
E5     2        e     d
measure 44
E5     8        h     d
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
A4     4        q     u
measure 47
C#5    6        q.    d
C#5    2        e     d  [
C#5    3        e.    d  =
C#5    1        s     d  ]\
measure 48
E5     6        q.    d
E5     2        e     d  [
E5     3        e.    d  =
E5     1        s     d  ]\
measure 49
A5     6        q.    d
G#5    2        e     d  [
A5     2        e     d  =
B5     2        e     d  ]
measure 50
G#5    3        e.    d  [      &t
F#5    1        s     d  =\
E5     2        e     d  =
B4     2        e     d  =
A4     2        e     d  =
B4     2        e     d  ]
measure 51
C#5    2        e     d  [
D5     2        e     d  ]
E5     4        q     d
rest   4        q
measure 52
rest   4        q
rest   2        e
B4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  ]
measure 53
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
B4     2        e     d  =
A4     2        e     d  =
B4     2        e     d  ]
measure 54
C#5    2        e     d  [
D5     2        e     d  ]
E5     4        q     d
rest   4        q
measure 55
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 56
F#5    2        e     d  [
G#5    2        e     d  ]
A5     8-       h     d        -
measure 57
A5     6        q.    d
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  ]      +
measure 58
F#5    4        q     d         &t
E5     4        q     d
rest   4        q
measure 59
rest  12
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
measure 68
rest   4        q
rest   4        q
A5     4        q     d         f
measure 69
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 70
A5     8        h     d
G5     4        q     d         +
measure 71
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 72
E5     8        h     d
A5     4        q     d
measure 73
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 74
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      &t
G#5    1        s     d  ]\
measure 75
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      &t
G#5    1        s     d  ]\
measure 76
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      &t
G#5    1        s     d  ]\
measure 77
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      &t
G#5    1        s     d  ]\
measure 78
A5     4        q     d
rest   4        q
rest   4        q
measure 79
rest  12
measure 80
rest   4        q
rest   4        q
G5     4        q     d
measure 81
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 82
E5     8        h     d
rest   4        q
measure 83
rest  12
measure 84
rest   4        q
rest   4        q
D4     3        e.    u  [
D4     1        s     u  ]\
measure 85
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 86
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 87
D5     6        q.    d
D5     2        e     d  [
D5     3        e.    d  =
D5     1        s     d  ]\
measure 88
F#5    6        q.    d
F#5    2        e     d  [
F#5    3        e.    d  =
F#5    1        s     d  ]\
measure 89
A5     6        q.    d
A5     2        e     d  [
A5     3        e.    d  =
A5     1        s     d  ]\
measure 90
D6     4        q     d
rest   2        e
A5     2        e     d  [
G5     2        e     d  =
A5     2        e     d  ]
measure 91
B5     2        e     d  [
C#6    2        e     d  ]
D6     4        q     d
rest   4        q
measure 92
rest   4        q
rest   2        e
A5     2        e     d  [
G5     2        e     d  =
A5     2        e     d  ]
measure 93
B5     2        e     d  [
C#6    2        e     d  =
D6     2        e     d  =
A5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
measure 94
B5     2        e     d  [
C#6    2        e     d  ]
D6     4        q     d
rest   4        q
measure 95
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 96
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 97
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 98
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 99
rest  12
measure 100
rest  12
measure 101
rest  12
measure 102
rest  12
measure 103
rest  12
measure 104
rest  12
measure 105
rest  12
measure 106
rest  12
measure 107
rest  12
measure 108
rest   4        q
rest   4        q
G5     4        q     d
measure 109
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 110
E5     8        h     d
rest   4        q
measure 111
rest  12
measure 112
rest   4        q
rest   4        q
A5     4        q     d
measure 113
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 114
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      t
G#5    1        s     d  ]\
measure 115
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      t
G#5    1        s     d  ]\
measure 116
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      t
G#5    1        s     d  ]\
measure 117
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      &t
G#5    1        s     d  ]\
measure 118
A5     2        e     d  [
F#5    2        e     d  ]
G5     6        q.    d         +
E5     2        e     d
measure 119
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 120
D5     4        q     d
rest   2        e
A4     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  ]
measure 121
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  =
C#5    2        e     d  ]
measure 122
B4     6        q.    d
B4     2        e     d  [
C#5    2        e     d  =
D5     2        e     d  ]
measure 123
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 124
C#5    6        q.    d
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 125
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 126
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 127
G5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  =
C#6    2        e     d  ]
measure 128
D6     6        q.    d
F#5    2        e     d  [
E5     2        e     d  =
D5     2        e     d  ]
measure 129
G#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
G#5    2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 130
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      t
G#5    1        s     d  ]\
measure 131
A5     4        q     d
D6     2        e     d  [      (
B5     2        e     d  =      )
A5     3        e.    d  =      t
G#5    1        s     d  ]\
measure 132
A5     4        q     d
rest   4        q
rest   4        q
measure 133
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 134
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 135
rest   2        e
D5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  ]
measure 136
C#6    6        q.    d         &t
B5     1        s     d  [[
C#6    1        s     d  ]]
D6     4        q     d
measure 137
rest  12
measure 138
rest  12
measure 139
rest  12
measure 140
rest   4        q
rest   4        q
D4     3        e.    u  [      f
D4     1        s     u  ]\
measure 141
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 142
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 143
D5     6        q.    d
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  ]
measure 144
A5     6        q.    d
G5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 145
D5     6        q.    d
D5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 146
G5     6        q.    d
F#5    2        e     d  [
G5     2        e     d  =
E5     2        e     d  ]
measure 147
F#5    2        e     d  [
G5     2        e     d  ]
F#5    6        q.    d         &t
E5     2        e     d
measure 148
E5     4        q     d
rest   4        q
rest   4        q
measure 149
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 150
F#5    2        e     d  [
G5     2        e     d  ]
A5     4        q     d
rest   4        q
measure 151
rest   4        q
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 152
F#5    2        e     d  [
G5     2        e     d  =
A5     2        e     d  =
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 153
F#5    2        e     d  [
D5     2        e     d  ]
G5     4        q     d         i
G5     4        q     d         i
measure 154
G5     6        q.    d
A5     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  ]
measure 155
F#5    2        e     d  [
G5     2        e     d  ]
E5     6        q.    d         &t
D5     2        e     d
measure 156
*               C       (Fine)
D5     8        h     d         F
mdouble
rest   4        q
measure 157
rest  12
measure 158
rest  12
measure 159
rest  12
measure 160
rest  12
measure 161
rest  12
measure 162
rest  12
measure 163
rest  12
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest  12
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
rest  12
measure 174
rest  12
measure 175
rest  12
measure 176
rest  12
measure 177
rest  12
measure 178
rest  12
measure 179
rest  12
measure 180
rest  12
measure 181
rest  12
measure 182
rest  12
measure 183
rest  12
measure 184
rest  12
measure 185
rest  12
measure 186
rest  12
measure 187
rest  12
measure 188
rest  12
measure 189
rest  12
measure 190
rest  12
measure 191
rest  12
measure 192
rest  12
measure 193
rest  12
measure 194
rest  12
measure 195
rest  12
measure 196
rest  12
measure 197
rest  12
measure 198
rest  12
measure 199
rest  12
measure 200
rest  12
measure 201
rest  12
measure 202
rest  12
measure 203
rest  12
measure 204
rest  12
measure 205
rest  12
measure 206
rest  12
measure 207
rest  12
measure 208
rest  12
measure 209
rest  12
measure 210
rest  12
measure 211
rest  12
measure 212
rest  12
measure 213
rest  12
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/3} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:b6c5e5f99958a5d5e8ed9ab65a515bf3]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Violino II
1 19
Group memberships: score
score: part 3 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:3/4   C:4   D:Pomposo, ma non allegro
A3     3        e.    u  [
A3     1        s     u  ]\
measure 1
D4     4        q     u
rest   2        e
D4     2        e     u  [
D4     3        e.    u  =
D4     1        s     u  ]\
measure 2
E4     4        q     u
rest   2        e
E4     2        e     u  [
E4     3        e.    u  =
E4     1        s     u  ]\
measure 3
F#4    6        q.    u
G4     2        e     u  [
F#4    2        e     u  =
E4     2        e     u  ]
measure 4
D4     6        q.    u
A4     2        e     u  [
B4     2        e     u  =
C#5    2        e     u  ]
measure 5
F#4    6        q.    u
F#4    2        e     u  [
G4     2        e     u  =
A4     2        e     u  ]
measure 6
B4     6        q.    d
B4     2        e     d  [
E5     2        e     d  =
A4     2        e     d  ]
measure 7
D5     2        e     d  [
E5     2        e     d  ]
D5     6        q.    d
C#5    2        e     d
measure 8
C#5    8        h     d
rest   4        q
measure 9
rest  12
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
rest  12
measure 19
rest  12
measure 20
rest  12
measure 21
rest   4        q
rest   2        e
A4     2        e     u  [
B4     2        e     u  =
A4     2        e     u  ]
measure 22
A4     4        q     u
E5     4        q     d
rest   4        q
measure 23
rest   4        q
rest   2        e
A4     2        e     u  [
B4     2        e     u  =
A4     2        e     u  ]
measure 24
A4     6        q.    u
C#5    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  ]
measure 25
A4     4        q     u
D5     4        q     d
B4     4        q     d
measure 26
C#5    6        q.    d
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  ]
measure 27
D5     2        e     d  [
B4     2        e     d  ]
C#5    6        q.    d
D5     2        e     d
measure 28
D5     8        h     d
rest   4        q
mdouble 29      A
rest  12
measure 30
rest   4        q
rest   4        q
A3     3        e.    u  [
A3     1        s     u  ]\
measure 31
D4     6        q.    u
D4     2        e     u  [
D4     3        e.    u  =
D4     1        s     u  ]\
measure 32
E4     4        q     u
rest   4        q
rest   4        q
measure 33
rest  12
measure 34
rest  12
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
rest   4        q
rest   4        q
F#4    4        q     u         &f
measure 41
F#4    6        q.    u
F#4    2        e     u  [
G4     2        e     u  =
A4     2        e     u  ]
measure 42
B4     4        q     d
A4     4        q     u
C#5    4        q     d
measure 43
D5     2        e     d  [
E5     2        e     d  ]
D5     6        q.    d
C#5    2        e     d
measure 44
C#5    8        h     d
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
E4     4        q     u
measure 47
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 48
B4     6        q.    d
B4     2        e     d  [
B4     3        e.    d  =
B4     1        s     d  ]\
measure 49
C#5    6        q.    d
B4     2        e     u  [
A4     2        e     u  =
F#4    2        e     u  ]
measure 50
B4     4        q     u
E4     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  =
G#4    2        e     u  ]
measure 51
A4     4        q     u
B4     4        q     u
rest   4        q
measure 52
rest   4        q
rest   2        e
E4     2        e     u  [
F#4    2        e     u  =
G#4    2        e     u  ]
measure 53
A4     4        q     u
B4     2        e     u  [
G#4    2        e     u  =
F#4    2        e     u  =
G#4    2        e     u  ]
measure 54
A4     4        q     u
B4     4        q     d
rest   4        q
measure 55
rest   4        q
rest   2        e
A4     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  ]
measure 56
D5     4        q     d
E5     4        q     d
rest   4        q
measure 57
rest   4        q
rest   2        e
C#5    2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 58
D5     4        q     d
C#5    4        q     d
rest   4        q
measure 59
rest  12
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
measure 68
rest   4        q
rest   4        q
C#5    4        q     d         &f
measure 69
B4     2        e     u  [
A4     2        e     u  =
G#4    2        e     u  =
B4     2        e     u  =
A4     2        e     u  =
G#4    2        e     u  ]
measure 70
A4     8        h     u
A4     4        q     u
measure 71
A4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
D5     2        e     u  =
C#5    2        e     u  =
B4     2        e     u  ]
measure 72
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  =
E5     2        e     d  =
D5     2        e     d  =
C#5    2        e     d  ]
measure 73
B4     8        h     u
B4     4        q     u
measure 74
A4     4        q     u
rest   4        q
B4     4        q     u
measure 75
A4     4        q     u
rest   4        q
B4     4        q     u
measure 76
A4     4        q     u
rest   4        q
B4     4        q     u
measure 77
A4     4        q     u
rest   4        q
B4     4        q     u
measure 78
A4     4        q     u
rest   4        q
rest   4        q
measure 79
rest  12
measure 80
rest   4        q
rest   4        q
A4     4        q     u
measure 81
A4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
D5     2        e     u  =
C#5    2        e     u  =
B4     2        e     u  ]
measure 82
C#5    8        h     d
rest   4        q
measure 83
rest  12
measure 84
rest   4        q
rest   4        q
A3     3        e.    u  [
A3     1        s     u  ]\
measure 85
D4     6        q.    u
D4     2        e     u  [
D4     3        e.    u  =
D4     1        s     u  ]\
measure 86
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 87
G4     4        q     u
B4     6        q.    d
B4     2        e     d
measure 88
A4     6        q.    u
A4     2        e     u  [
A4     3        e.    u  =
A4     1        s     u  ]\
measure 89
F#4    6        q.    u
F#4    2        e     u  [
F#4    3        e.    u  =
F#4    1        s     u  ]\
measure 90
A4     4        q     u
rest   4        q
rest   2        e
D5     2        e     d
measure 91
G4     4        q     u
A4     4        q     u
rest   4        q
measure 92
rest   4        q
rest   4        q
rest   2        e
D5     2        e     d
measure 93
G4     4        q     u
A4     2        e     u  [
F#4    2        e     u  =
E4     2        e     u  =
F#4    2        e     u  ]
measure 94
G4     4        q     u
A4     4        q     u
rest   4        q
measure 95
rest   4        q
rest   4        q
A4     4        q     u
measure 96
A4     2        e     u  [
B4     2        e     u  ]
C#5    4        q     d
rest   4        q
measure 97
rest   4        q
rest   4        q
A4     4        q     u
measure 98
A4     2        e     u  [
B4     2        e     u  ]
C#5    4        q     d
rest   4        q
measure 99
rest  12
measure 100
rest  12
measure 101
rest  12
measure 102
rest  12
measure 103
rest  12
measure 104
rest  12
measure 105
rest  12
measure 106
rest  12
measure 107
rest  12
measure 108
rest   4        q
rest   4        q
C#5    4        q     d
measure 109
A4     4        q     u
A4     4        q     u
B4     4        q     u
measure 110
C#5    8        h     d
rest   4        q
measure 111
rest  12
measure 112
rest   4        q
rest   4        q
E4     4        q     u
measure 113
B4     8        h     u
B4     4        q     u
measure 114
A4     4        q     u
rest   4
B4     4        q     u
measure 115
A4     4        q     u
rest   4        q
B4     4        q     u
measure 116
A4     4        q     u
rest   4        q
B4     4        q     u
measure 117
A4     4        q     u
rest   4        q
B4     4        q     u
measure 118
A4     4        q     u
rest   4        q
C#5    4        q     d
measure 119
A4     4        q     u
B4     4        q     u
A4     4        q     u
measure 120
A4     8        h     u
E4     4        q     u
measure 121
F#4    2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  =
E4     2        e     u  ]
measure 122
D4     6        q.    u
D4     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  ]
measure 123
G4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  =
F#4    2        e     u  ]
measure 124
E4     6        q.    u
E4     2        e     u  [
F#4    2        e     u  =
G4     2        e     u  ]
measure 125
A4     2        e     u  [
B4     2        e     u  =
C#5    2        e     u  =
B4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 126
F#4    6        q.    u
F#4    2        e     u  [
G4     2        e     u  =
A4     2        e     u  ]
measure 127
B4     4        q     u
A4     4        q     u
G4     4        q     u
measure 128
A4     4        q     u
rest   4        q
A4     4        q     u
measure 129
B4     4        q     u
B4     4        q     u
B4     4        q     u
measure 130
A4     4        q     u
rest   4        q
B4     4        q     u
measure 131
A4     4        q     u
rest   4        q
B4     4        q     u
measure 132
A4     4        q     u
rest   4        q
rest   4        q
measure 133
rest   4        q
rest   4        q
rest   2        e
A4     2        e     u
measure 134
A4     4        q     u
E5     4        q     d
rest   4        q
measure 135
rest   2        e
B4     2        e     d
B4     4        q     d
C#5    2        e     d  [
D5     2        e     d  ]
measure 136
E5     8        h     d
D5     4        q     d
measure 137
rest  12
measure 138
rest  12
measure 139
rest  12
measure 140
rest   4        q
rest   4        q
A3     3        e.    u  [      &f
A3     1        s     u  ]\
measure 141
D4     6        q.    u
D4     2        e     u  [
D4     3        e.    u  =
D4     1        s     u  ]\
measure 142
E4     6        q.    u
E4     2        e     u  [
E4     3        e.    u  =
E4     1        s     u  ]\
measure 143
F#4    6        q.    u
G4     2        e     u  [
F#4    2        e     u  =
E4     2        e     u  ]
measure 144
D4     6        q.    u
A4     2        e     u  [
B4     2        e     u  =
C#5    2        e     u  ]
measure 145
F#4    6        q.    u
F#4    2        e     u  [
G4     2        e     u  =
A4     2        e     u  ]
measure 146
B4     6        q.    d
B4     2        e     d  [
E5     2        e     d  =
A4     2        e     d  ]
measure 147
D5     2        e     d  [
E5     2        e     d  ]
D5     6        q.    d
C#5    2        e     d
measure 148
C#5    4        q     d
rest   4        q
rest   4        q
measure 149
rest   4        q
rest   2        e
A4     2        e     u  [
B4     2        e     u  =
A4     2        e     u  ]
measure 150
A4     4        q     u
E5     4        q     d
rest   4        q
measure 151
rest   4        q
rest   2        e
A4     2        e     u  [
B4     2        e     u  =
A4     2        e     u  ]
measure 152
A4     6        q.    u
A4     2        e     u  [
B4     2        e     u  =
C#5    2        e     u  ]
measure 153
A4     4        q     u
D5     4        q     d         &i
B4     4        q     d         &i
measure 154
C#5    6        q.    d
E5     2        e     d  [
D5     2        e     d  =
C#5    2        e     d  ]
measure 155
D5     2        e     d  [
B4     2        e     d  ]
C#5    6        q.    d
D5     2        e     d
measure 156
*               C       (Fine)
D5     8        h     d         F
mdouble
rest   4        q
measure 157
rest  12
measure 158
rest  12
measure 159
rest  12
measure 160
rest  12
measure 161
rest  12
measure 162
rest  12
measure 163
rest  12
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest  12
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
rest  12
measure 174
rest  12
measure 175
rest  12
measure 176
rest  12
measure 177
rest  12
measure 178
rest  12
measure 179
rest  12
measure 180
rest  12
measure 181
rest  12
measure 182
rest  12
measure 183
rest  12
measure 184
rest  12
measure 185
rest  12
measure 186
rest  12
measure 187
rest  12
measure 188
rest  12
measure 189
rest  12
measure 190
rest  12
measure 191
rest  12
measure 192
rest  12
measure 193
rest  12
measure 194
rest  12
measure 195
rest  12
measure 196
rest  12
measure 197
rest  12
measure 198
rest  12
measure 199
rest  12
measure 200
rest  12
measure 201
rest  12
measure 202
rest  12
measure 203
rest  12
measure 204
rest  12
measure 205
rest  12
measure 206
rest  12
measure 207
rest  12
measure 208
rest  12
measure 209
rest  12
measure 210
rest  12
measure 211
rest  12
measure 212
rest  12
measure 213
rest  12
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/4} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:1dbf731e4d3ca6ad5344d199dbfa03d1]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Viola
1 19
Group memberships: score
score: part 4 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:3/4   C:13   D:Pomposo, ma non allegro
F#3    3        e.    u  [
F#3    1        s     u  ]\
measure 1
A3     4        q     u
rest   2        e
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 2
A3     4        q     u
rest   2        e
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 3
F#3    6        q.    u
D4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  ]
measure 4
F#4    6        q.    d
D4     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 5
B3     6        q.    u
C#4    2        e     u  [
B3     2        e     u  =
A3     2        e     u  ]
measure 6
G3     6        q.    u
B4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 7
A4     2        e     d  [
A4     2        e     d  ]
A4     4        q     d
A4     4        q     d
measure 8
A4     8        h     d
rest   4        q
measure 9
rest  12
measure 10
rest  12
measure 11
rest  12
measure 12
rest  12
measure 13
rest  12
measure 14
rest  12
measure 15
rest  12
measure 16
rest  12
measure 17
rest  12
measure 18
rest  12
measure 19
rest  12
measure 20
rest  12
measure 21
rest   4        q
rest   2        e
C#4    2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 22
D4     4        q     d
E4     4        q     d
rest   4        q
measure 23
rest   4        q
rest   2        e
C#4    2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 24
D4     4        q     d
E4     4        q     d
A4     4        q     d
measure 25
A4     2        e     d  [
F#4    2        e     d  ]
G4     4        q     d
G4     4        q     d
measure 26
E4     6        q.    d
A4     2        e     d
A4     4        q     d
measure 27
rest   2        e
E4     2        e     d
A4     4        q     d
A4     4        q     d
measure 28
F#4    8        h     d
rest   4        q
mdouble 29      A
rest  12
measure 30
rest   4        q
rest   4        q
F#3    3        e.    u  [
F#3    1        s     u  ]\
measure 31
A3     6        q.    u
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 32
A3     4        q     u
rest   4        q
rest   4        q
measure 33
rest  12
measure 34
rest  12
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
rest   4        q
rest   4        q
C#4    4        q     d         &f
measure 41
D4     6        q.    d
C#4    2        e     d
B3     4        q     u
measure 42
B3     4        q     u
E4     4        q     d
A4     4        q     d
measure 43
A4     2        e     d  [
A4     2        e     d  ]
A4     4        q     d
A4     4        q     d
measure 44
A4     8        h     d
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
C#4    4        q     d
measure 47
E4     6        q.    d
E4     2        e     d  [
E4     3        e.    d  =
E4     1        s     d  ]\
measure 48
E4     6        q.    d
E4     2        e     d  [
E4     3        e.    d  =
E4     1        s     d  ]\
measure 49
C#4    4        q     d
A3     6        q.    u
A3     2        e     u
measure 50
E3     4        q     u
B3     6        q.    u
E4     2        e     d
measure 51
E4     4        q     d
E4     4        q     d
rest   4        q
measure 52
rest   4        q
rest   4        q
E3     4        q     u
measure 53
E4     4        q     d
E4     4        q     d
E4     4        q     d
measure 54
E4     2        e     d  [
F#4    2        e     d  ]
G#4    4        q     d
rest   4        q
measure 55
rest   4        q
rest   4        q
A3     4        q     u
measure 56
A4     2        e     d  [
B4     2        e     d  ]
C#5    4        q     d
rest   4        q
measure 57
rest   4        q
rest   4        q
A4     4        q     d
measure 58
A4     4        q     d
A4     4        q     d
rest   4        q
measure 59
rest  12
measure 60
rest  12
measure 61
rest  12
measure 62
rest  12
measure 63
rest  12
measure 64
rest  12
measure 65
rest  12
measure 66
rest  12
measure 67
rest  12
measure 68
rest   4        q
rest   4        q
E4     4        q     d         &f
measure 69
E4     8        h     d
E4     4        q     d
measure 70
E4     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  =
E4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
measure 71
D4     8        h     d
D4     4        q     d
measure 72
A4     8        h     d
E4     4        q     d
measure 73
D4     8        h     d
D4     4        q     d
measure 74
E4     4        q     d
rest   4        q
D4     4        q     d
measure 75
E4     4        q     d
rest   4        q
D4     4        q     d
measure 76
E4     4        q     d
rest   4        q
D4     4        q     d
measure 77
E4     4        q     d
rest   4        q
D4     4        q     d
measure 78
E4     4        q     d
rest   4        q
rest   4        q
measure 79
rest  12
measure 80
rest   4        q
rest   4        q
E4     4        q     d
measure 81
D4     8        h     d
A3     4        q     u
measure 82
A3     8        h     u
rest   4        q
measure 83
rest  12
measure 84
rest   4        q
rest   4        q
F#3    3        e.    u  [
F#3    1        s     u  ]\
measure 85
A3     6        q.    u
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 86
D4     6        q.    d
D4     2        e     d  [
D4     3        e.    d  =
D4     1        s     d  ]\
measure 87
D4     4        q     d
G4     6        q.    d
G4     2        e     d
measure 88
F#4    6        q.    d
F#4    2        e     d  [
F#4    3        e.    d  =
F#4    1        s     d  ]\
measure 89
F#4    6        q.    d
F#4    2        e     d  [
F#4    3        e.    d  =
F#4    1        s     d  ]\
measure 90
F#4    4        q     d
rest   4        q
rest   2        e
F#4    2        e     d
measure 91
D4     2        e     d  [
E4     2        e     d  ]
F#4    4        q     d
rest   4        q
measure 92
rest   4        q
rest   4        q
rest   2        e
F#4    2        e     d
measure 93
D4     2        e     d  [
E4     2        e     d  ]
F#4    4        q     d
A3     4        q     u
measure 94
D4     2        e     d  [
E4     2        e     d  ]
F#4    4        q     d
rest   4        q
measure 95
rest   4        q
rest   2        e
A3     2        e     u  [
B3     2        e     u  =
C#4    2        e     u  ]
measure 96
D4     4        q     d
E4     4        q     d
rest   4        q
measure 97
rest   4        q
rest   2        e
A3     2        e     u  [
B3     2        e     u  =
C#4    2        e     u  ]
measure 98
D4     4        q     d
E4     4        q     d
rest   4        q
measure 99
rest  12
measure 100
rest  12
measure 101
rest  12
measure 102
rest  12
measure 103
rest  12
measure 104
rest  12
measure 105
rest  12
measure 106
rest  12
measure 107
rest  12
measure 108
rest   4        q
rest   4        q
E4     4        q     d
measure 109
F#4    2        e     d  [
G4     2        e     d  ]
A4     4        q     d
G#4    4        q     d
measure 110
A4     8        h     d
rest   4        q
measure 111
rest  12
measure 112
rest   4        q
rest   4        q
E4     4        q     d
measure 113
E4     8        h     d
E4     4        q     d
measure 114
E4     4        q     d
rest   4        q
D4     4        q     d
measure 115
E4     4        q     d
rest   4        q
D4     4        q     d
measure 116
E4     4        q     d
rest   4        q
D4     4        q     d
measure 117
E4     4        q     d
rest   4        q
D4     4        q     d
measure 118
E4     4        q     d
rest   4        q
E4     4        q     d
measure 119
D4     4        q     d
D4     4        q     d
C#4    4        q     d
measure 120
F#4    8        h     d
C#4    4        q     d
measure 121
A3     4        q     u
rest   4        q
A3     4        q     u
measure 122
B3     4        q     u
D4     2        e     u  [
C#4    2        e     u  =
B3     2        e     u  =
A3     2        e     u  ]
measure 123
B3     4        q     u
rest   4        q
B3     4        q     u
measure 124
C#4    2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  ]
measure 125
C#4    4        q     d
rest   4        q
C#4    4        q     d
measure 126
D4     2        e     d  [
E4     2        e     d  =
F#4    2        e     d  =
E4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  ]
measure 127
D4     6        q.    d
A3     2        e     u
E4     4        q     d
measure 128
F#4    4        q     d
rest   4        q
F#4    4        q     d
measure 129
E4     4        q     d
E4     4        q     d
E4     4        q     d
measure 130
E4     4        q     d
rest   4        q
D4     4        q     d
measure 131
E4     4        q     d
rest   4        q
D4     4        q     d
measure 132
E4     4        q     d
rest   4        q
rest   4        q
measure 133
rest   4        q
rest   4        q
rest   2        e
E4     2        e     d
measure 134
D4     4        q     d
E4     4        q     d
rest   4        q
measure 135
rest   2        e
F#4    2        e     d
G4     6        q.    d
G4     2        e     d
measure 136
C#4    8        h     d
F#4    4        q     d
measure 137
rest  12
measure 138
rest  12
measure 139
rest  12
measure 140
rest   4        q
rest   4        q
F#3    3        e.    u  [      &f
F#3    1        s     u  ]\
measure 141
A3     6        q.    u
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 142
A3     6        q.    u
A3     2        e     u  [
A3     3        e.    u  =
A3     1        s     u  ]\
measure 143
F#3    6        q.    u
D4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  ]
measure 144
F#3    6        q.    u
D4     2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 145
B3     6        q.    u
C#4    2        e     u  [
B3     2        e     u  =
A3     2        e     u  ]
measure 146
G3     6        q.    u
B4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 147
A4     2        e     d  [
A4     2        e     d  ]
A4     4        q     d
A4     4        q     d
measure 148
A4     4        q     d
rest   4        q
rest   4        q
measure 149
rest   4        q
rest   2        e
C#4    2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 150
D4     4        q     d
E4     4        q     d
rest   4        q
measure 151
rest   4        q
rest   2        e
C#4    2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
measure 152
D4     4        q     d
E4     4        q     d
A4     4        q     d
measure 153
A4     2        e     d  [
F#4    2        e     d  ]
G4     4        q     d         &i
G4     4        q     d         &i
measure 154
E4     6        q.    d
A4     2        e     d
A4     4        q     d
measure 155
rest   2        e
E4     2        e     d
A3     4        q     u
A4     4        q     d
measure 156
*               C       (Fine)
F#4    8        h     d         F
mdouble
rest   4        q
measure 157
rest  12
measure 158
rest  12
measure 159
rest  12
measure 160
rest  12
measure 161
rest  12
measure 162
rest  12
measure 163
rest  12
measure 164
rest  12
measure 165
rest  12
measure 166
rest  12
measure 167
rest  12
measure 168
rest  12
measure 169
rest  12
measure 170
rest  12
measure 171
rest  12
measure 172
rest  12
measure 173
rest  12
measure 174
rest  12
measure 175
rest  12
measure 176
rest  12
measure 177
rest  12
measure 178
rest  12
measure 179
rest  12
measure 180
rest  12
measure 181
rest  12
measure 182
rest  12
measure 183
rest  12
measure 184
rest  12
measure 185
rest  12
measure 186
rest  12
measure 187
rest  12
measure 188
rest  12
measure 189
rest  12
measure 190
rest  12
measure 191
rest  12
measure 192
rest  12
measure 193
rest  12
measure 194
rest  12
measure 195
rest  12
measure 196
rest  12
measure 197
rest  12
measure 198
rest  12
measure 199
rest  12
measure 200
rest  12
measure 201
rest  12
measure 202
rest  12
measure 203
rest  12
measure 204
rest  12
measure 205
rest  12
measure 206
rest  12
measure 207
rest  12
measure 208
rest  12
measure 209
rest  12
measure 210
rest  12
measure 211
rest  12
measure 212
rest  12
measure 213
rest  12
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/5} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:afbe308755228d48503f8f2d715c2131]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Basso
1 19 B
Group memberships: score
score: part 5 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:12   T:3/4   C:22   D:Pomposo, ma non allegro
rest  12        q
measure 1
rest  36
measure 2
rest  36
measure 3
rest  36
measure 4
rest  36
measure 5
rest  36
measure 6
rest  36
measure 7
rest  36
measure 8
rest  36
measure 9
rest  36
measure 10
rest  36
measure 11
rest  36
measure 12
rest  36
measure 13
rest  36
measure 14
rest  36
measure 15
rest  36
measure 16
rest  36
measure 17
rest  36
measure 18
rest  36
measure 19
rest  36
measure 20
rest  36
measure 21
rest  36
measure 22
rest  36
measure 23
rest  36
measure 24
rest  36
measure 25
rest  36
measure 26
rest  36
measure 27
rest  36
measure 28
rest  12        q
rest  12        q
D3    12        q     d                    The
mdouble 29      A
F#3   12        q     d                    trum-
F#3   12        q     d                    pet
A3    12        q     d                    shall
measure 30
D4    36-       h.    d        -           sound,_
measure 31
D4    24        h     d                    _
rest  12        q
measure 32
rest  12        q
A3    12        q     d                    and
A3    12        q     d                    the
measure 33
D3    12        q     d                    dead
D3     6        e     d  [                 shall_
E3     6        e     d  ]                 _
F#3    6        e     d  [                 be_
G3     6        e     d  ]                 _
measure 34
A3    24        h     d                    rais'd,
rest  12        q
measure 35
rest  36
measure 36
rest  12        q
A3    12        q     d                    and
A3    12        q     d                    the
measure 37
B3    12        q     d                    dead
C#4   12        q     d                    shall
D4    12        q     d                    be
measure 38
E4     6        e     d  [                 rais'd_
D4     6        e     d  =                 _
E4     6        e     d  =                 _
A3     6        e     d  ]                 _
B3     6        e     d  [      (          in-
C#4    6        e     d  ]      )          -
measure 39
D4     6        e     d  [      (          cor-
C#4    6        e     d  ]                 -
D4    12        q     d         )          -
D3    12        q     d                    rup-
measure 40
A3    12        q     d                    ti-
A3    12        q     d                    ble,
rest  12        q
measure 41
rest  36
measure 42
rest  36
measure 43
rest  36
measure 44
rest  12        q
rest  12        q
E3    12        q     d                    the
measure 45
A3    12        q     d                    trum-
A3     6        e     d  [                 pet_
B3     6        e     d  ]                 _
C#4    6        e     d  [                 shall_
D4     6        e     d  ]                 _
measure 46
E4    36-       h.    d        -           sound,_
measure 47
E4    24        h     d                    _
rest  12        q
measure 48
rest  12        q
E4     6        e     d  [                 and_
D4     6        e     d  ]                 _
C#4    6        e     d  [                 the_
B3     6        e     d  ]                 _
measure 49
A3     6        e     d  [                 dead_
G#3    6        e     d  ]                 _
A3     6        e     d  [                 shall_
B3     6        e     d  ]                 _
C#4    6        e     d  [                 be_
D4     6        e     d  ]                 _
measure 50
E4    36        h.    d                    rais'd
measure 51
rest  12        q
rest  12        q
B3    12        q     d                    in-
measure 52
C#4    6        e     d  [      (          cor-
D4     6        e     d  ]                 -
E4    12        q     d         )          -
G#3   12        q     d                    rup-
measure 53
A3    12        q     d                    ti-
E3    12        q     d                    ble,
rest  12        q
measure 54
rest  12        q
rest  12        q
C#4   12        q     d                    in-
measure 55
D4    12        q     d         (          cor-
C#4   12        q     d         )          -
A3    12        q     d                    rup-
measure 56
D4    12        q     d                    ti-
A3    12        q     d                    ble,
rest  12        q
measure 57
rest  36
measure 58
rest  12        q
rest  12        q
E4    12        q     d                    and
measure 59
B3    12        q     d                    we
B3    12        q     d                    shall
C#4   12        q     d                    be
measure 60
D4     6        e     d  [                 chang'd,_
C#4    6        e     d  =                 _
D4     6        e     d  =                 _
E4     6        e     d  =                 _
D4     6        e     d  =                 _
E4     6        e     d  ]                 _
measure 61
F#3    6        e     d  [                 _
E3     6        e     d  =                 _
F#3    6        e     d  =                 _
G#3    6        e     d  =                 _
F#3    6        e     d  =                 _
G#3    6        e     d  ]                 _
measure 62
A3     6        e     d  [                 _
G#3    6        e     d  =                 _
A3     6        e     d  =                 _
B3     6        e     d  =                 _
A3     6        e     d  =                 _
B3     6        e     d  ]                 _
measure 63
C#4    6        e     d  [                 _
B3     6        e     d  =                 _
C#4    6        e     d  =                 _
D4     6        e     d  =                 _
C#4    6        e     d  =                 _
D4     6        e     d  ]                 _
measure 64
E3     6        e     d  [                 _
D3     6        e     d  =                 _
E3     6        e     d  =                 _
F#3    6        e     d  =                 _
E3     6        e     d  =                 _
F#3    6        e     d  ]                 _
measure 65
G#3    6        e     d  [                 _
F#3    6        e     d  =                 _
G#3    6        e     d  =                 _
A3     6        e     d  =                 _
G#3    6        e     d  =                 _
A3     6        e     d  ]                 _
measure 66
B3    24        h     d                    _
C#4   12        q     d                    and
measure 67
D4    12        q     d                    we
E4    12        q     d                    shall
E3    12        q     d                    be
measure 68
A3    36        h.    d                    chang'd.
measure 69
rest  36
measure 70
rest  36
measure 71
rest  36
measure 72
rest  36
measure 73
rest  36
measure 74
rest  36
measure 75
rest  36
measure 76
rest  36
measure 77
rest  36
measure 78
rest  12        q
rest  12        q
A3    12        q     d                    The
measure 79
D4    12        q     d                    trum-
D3     6        e     d  [                 pet_
E3     6        e     d  ]                 _
F#3    6        e     d  [                 shall_
G3     6        e     d  ]                 _
measure 80
A3    36-       h.    d        -           sound,_
measure 81
A3    36        h.    d                    _
measure 82
rest  12        q
rest  12        q
A3    12        q     d                    the
measure 83
B3    12        q     d                    trum-
G3     6        e     d  [                 pet_
A3     6        e     d  ]                 _
B3     6        e     d  [                 shall_
C#4    6        e     d  ]                 _
measure 84
D4    36-       h.    d        -           sound,_
measure 85
D4    36        h.    d                    _
measure 86
rest  12        q
F#3   12        q     d                    and
F#3   12        q     d                    the
measure 87
B3    12        q     d                    dead
G3     6        e     d  [                 shall_
A3     6        e     d  ]                 _
B3     6        e     d  [                 be_
C#4    6        e     d  ]                 _
measure 88
D4    36-       h.    d        -           rais'd_
measure 89
D4    36-       h.    d        -           _
measure 90
D4    36        h.    d                    _
measure 91
rest  12        q
rest  12        q
A3    12        q     d                    in-
measure 92
B3     6        e     d  [      (          cor-
C#4    6        e     d  ]                 -
D4    12        q     d         )          -
F#3   12        q     d                    rup-
measure 93
G3    12        q     d                    ti-
D3    12        q     d                    ble,
rest  12        q
measure 94
rest  12        q
rest  12        q
A3    12        q     d                    in-
measure 95
D4    12        q     d         (          cor-
C#4   12        q     d         )          -
A3    12        q     d                    rup-
measure 96
D4    12        q     d                    ti-
A3    12        q     d                    ble,
rest  12        q
measure 97
rest  36
measure 98
rest  36
measure 99
rest  12        q
rest  12        q
A3    12        q     d                    and
measure 100
E3    12        q     d                    we
E3    18        q.    d                    shall
F#3    6        e     d                    be
measure 101
G3    24        h     d                    chang'd,
G3    12        q     d                    be
measure 102
D3     9        e.    d  [                 chang'd,_
E3     3        s     d  =\                _
D3     9        e.    d  =                 _
E3     3        s     d  =\                _
D3     9        e.    d  =                 _
E3     3        s     d  ]\                _
measure 103
F#3    9        e.    d  [                 _
G3     3        s     d  =\                _
F#3    9        e.    d  =                 _
G3     3        s     d  =\                _
A3     9        e.    d  =                 _
F#3    3        s     d  ]\                _
measure 104
B3     9        e.    d  [                 _
C#4    3        s     d  =\                _
B3     6        e     d  =                 _
A3     6        e     d  =                 _
G3     6        e     d  =                 _
F#3    6        e     d  ]                 _
measure 105
E3     6        e     d  [                 _
F#3    6        e     d  =                 _
E3     6        e     d  =                 _
D3     6        e     d  =                 _
C#3    6        e     d  =                 _
B2     6        e     d  ]                 _
measure 106
A2    24        h     u                    _
C#4   12        q     d                    and
measure 107
D4     6        e     d  [                 we_
C#4    6        e     d  ]                 _
D4    12        q     d                    shall
D3    12        q     d                    be
measure 108
A3    36        h.    d                    chang'd,
measure 109
rest  36
measure 110
rest  12        q
rest  12        q
C#4   12        q     d                    and
measure 111
D4    12        q     d                    we
D3    12        q     d                    shall
D4    12        q     d                    be
measure 112
C#4    6        e     d  [                 chang'd,_
B3     6        e     d  =                 _
A3     6        e     d  =                 _
C#4    6        e     d  =                 _
B3     6        e     d  =                 _
A3     6        e     d  ]                 _
measure 113
D4    18        q.    d                    _
E4     6        e     d  [                 _
D4     6        e     d  =                 _
E4     6        e     d  ]                 _
measure 114
C#4   12        q     d                    _
rest  12        q
B3    12        q     d                    we
measure 115
C#4   12        q     d                    shall
rest  12        q
B3    12        q     d                    be
measure 116
C#4   18        q.    d                    chang'd,_
D4     6        e     d  [                 _
C#4    6        e     d  =                 _
B3     6        e     d  ]                 _
measure 117
C#4   18        q.    d                    _
D4     6        e     d  [                 _
C#4    6        e     d  =                 _
B3     6        e     d  ]                 _
measure 118
C#4    6        e     d  [                 _
D4     6        e     d  ]                 _
E4    12        q     d                    _
A3    12        q     d                    and
measure 119
D4    12        q     d                    we
G3    12        q     d                    shall
A3    12        q     d                    be
measure 120
D3    24        h     d                    chang'd,
rest  12        q
measure 121
rest  12        q
rest  12        q
F#3   12        q     d                    and
measure 122
G3    12        q     d                    we
B3     6        e     d  [                 shall_
A3     6        e     d  ]                 _
G3     6        e     d  [                 be_
F#3    6        e     d  ]                 _
measure 123
E3    18        q.    d                    chang'd,_
E3     6        e     d  [                 _
F#3    6        e     d  =                 _
G3     6        e     d  ]                 _
measure 124
A3     6        e     d  [                 _
B3     6        e     d  =                 _
C#4    6        e     d  =                 _
B3     6        e     d  =                 _
A3     6        e     d  =                 _
G3     6        e     d  ]                 _
measure 125
F#3   18        q.    d                    _
F#3    6        e     d  [                 _
G3     6        e     d  =                 _
A3     6        e     d  ]                 _
measure 126
B3     6        e     d  [                 _
C#4    6        e     d  =                 _
D4     6        e     d  =                 _
C#4    6        e     d  =                 _
B3     6        e     d  =                 _
A3     6        e     d  ]                 _
measure 127
G3    12        q     d                    _
F#3   12        q     d                    _
E3    12        q     d                    _
measure 128
D3    12        q     d                    _
rest  12        q
D3    12        q     d                    and
measure 129
D4    12        q     d                    we
D4    12        q     d                    shall
D4    12        q     d                    be
measure 130
C#4   12        q     d                    chang'd,
rest  12        q
B3    12        q     d                    we
measure 131
C#4   12        q     d                    shall
rest  12        q
B3    12        q     d                    be
measure 132
C#4    6        e     d  [                 chang'd,_
B3     6        e     d  =                 _
A3     6        e     d  =                 _
C#4    6        e     d  =                 _
B3     6        e     d  =                 _
C#4    6        e     d  ]                 _
measure 133
D4     6        e     d  [                 _
B3     6        e     d  =                 _
C#4    6        e     d  =                 _
A3     6        e     d  =                 _
B3     6        e     d  =                 _
C#4    6        e     d  ]                 _
measure 134
D4     6        e     d  [                 _
B3     6        e     d  =                 _
C#4    6        e     d  =                 _
A3     6        e     d  =                 _
B3     6        e     d  =                 _
C#4    6        e     d  ]                 _
measure 135
D4     6        e     d  [                 _
B3     6        e     d  =                 _
E4     6        e     d  =                 _
D4     6        e     d  =                 _
C#4    6        e     d  =                 _
B3     6        e     d  ]                 _
measure 136
A3    24        h     d                    _
B3    12        q     d                    and
measure 137
G3    12        q     d                    we
A3    12        q     d                    shall
A2    12        q     u                    be
measure 138
B2    36        h.    u         F          chang'd,
measure 139
*               D +     Adagio
G3    12        q     d                    we
A3    18        q.    d                    shall
A3     6        e     d                    be
measure 140
D3    36        h.    d                    chang'd.
measure 141
rest  36
measure 142
rest  36
measure 143
rest  36
measure 144
rest  36
measure 145
rest  36
measure 146
rest  36
measure 147
rest  36
measure 148
rest  36
measure 149
rest  36
measure 150
rest  36
measure 151
rest  36
measure 152
rest  36
measure 153
rest  36
measure 154
rest  36
measure 155
rest  36
measure 156
*               C       (Fine)
rest  12        q
rest  12        q
mdouble
F#3   12        q     d                    For
measure 157
B3    24        h     d                    this
C#4   12        q     d                    cor-
measure 158
A#3   24        h     d                    rup-
G#3    6        e     d                    ti-
F#3    6        e     d                    ble
measure 159
B3    12        q     d                    must
A3    18        q.    d         (+         put_
B3     6        e     d         )          _
measure 160
G3    24        h     d                    on
F#3   12-       q     d        -           in-
measure 161
F#3    6        e     d  [                 -
G3     6        e     d  ]                 -
E3    24        h     d                    cor-
measure 162
F#3   12        q     d                    rup-
F#3   12        q     d                    tion,
rest  12        q
measure 163
rest  36
measure 164
rest  12        q
rest  12        q
F#3   12        q     d                    for
measure 165
D4    24        h     d                    this
C#4   12        q     d                    cor-
measure 166
A#3   24        h     d                    rup-
F#3    6        e     d                    ti-
F#3    6        e     d                    ble
measure 167
B3    24        h     d                    must
F#3   12        q     d                    put
measure 168
G3    36        h.    d                    on,
measure 169
rest  12        q
A3    12        q     d                    must
E3    12        q     d                    put
measure 170
F#3   12        q     d                    on,_
D4    24-       h     d        -           _
measure 171
D4     6        e     d  [                 _
C#4    6        e     d  =                 _
B3     6        e     d  =                 _
A3     6        e     d  =                 _
G3     6        e     d  =                 _
F#3    6        e     d  ]                 _
measure 172
E3    12        q     d                    _
C#4   24-       h     d        -           _
measure 173
C#4    6        e     d  [                 _
B3     6        e     d  =                 _
A#3    6        e     d  =                 _
G#3    6        e     d  =                 _
F#3    6        e     d  =                 _
E3     6        e     d  ]                 _
measure 174
D3    12        q     d                    _
D3    12        q     d                    must
E3    12        q     d                    put
measure 175
F#3   12        q     d                    on,
F#3   12        q     d                    must
G#3   12        q     d                    put
measure 176
A#3   24        h     d                    on
B3    12-       q     d        -           in-
measure 177
B3     6        e     d  [                 -
C#4    6        e     d  ]                 -
A#3   24        h     d                    cor-
measure 178
B3    12        q     d                    rup-
B3    12        q     d                    tion,
rest  12        q
measure 179
rest  36
measure 180
rest  36
measure 181
rest  12        q
B3    12        q     d                    and
D4    12        q     d                    this
measure 182
C#4   12        q     d         (          mor-
G#3   12        q     d         )          -
A3    12        q     d                    tal
measure 183
E#3   12        q     d                    must
F#3    9        e.    d  [                 put_
E#3    3        s     d  =\                _
F#3    6        e     d  =                 _
G#3    6        e     d  ]                 _
measure 184
C#3   24        h     u                    on
rest  12        q
measure 185
rest  12        q
C#4   12        q     d                    im-
F#3   12        q     d                    mor-
measure 186
D4    18        q.    d                    ta-
C#4    6        e     d  [                 -
B3     6        e     d  =                 -
A3     6        e     d  ]                 -
measure 187
G#3    6        e     d  [                 -
F#3    6        e     d  =                 -
E3     6        e     d  =                 -
B3     6        e     d  =                 -
C#4    6        e     d  =                 -
D4     6        e     d  ]                 -
measure 188
C#4   18        q.    d                    -
B3     6        e     d  [                 -
A3     6        e     d  =                 -
G#3    6        e     d  ]                 -
measure 189
F#3    6        e     d  [                 -
E3     6        e     d  =                 -
D3     6        e     d  =                 -
A3     6        e     d  =                 -
B3     6        e     d  =                 -
C#4    6        e     d  ]                 -
measure 190
B3    18        q.    d                    -
A3     6        e     d  [                 -
G#3    6        e     d  =                 -
F#3    6        e     d  ]                 -
measure 191
E#3    6        e     d  [                 -
D#3    6        e     d  =                 -
C#3    6        e     d  =                 -
G#3    6        e     d  =                 -
A3     6        e     d  =                 -
B3     6        e     d  ]                 -
measure 192
A3     6        e     d  [                 -
G#3    6        e     d  =                 -
F#3    6        e     d  =                 -
A3     6        e     d  =                 -
B3     6        e     d  =                 -
C#4    6        e     d  ]                 -
measure 193
B3     6        e     d  [                 -
A3     6        e     d  =                 -
G#3    6        e     d  =                 -
B3     6        e     d  =                 -
C#4    6        e     d  =                 -
D4     6        e     d  ]                 -
measure 194
C#4   18        q.    d                    -
F#3    6        e     d                    li-
F#3   12        q     d                    ty,
measure 195
rest  12        q
D4    12        q     d                    and
C#4   12        q     d                    this
measure 196
B3     6        e     d  [                 mor-
A#3    6        e     d  ]                 -
B3    24        h     d                    tal
measure 197
B3     6        e     d  [                 must_
A#3    6        e     d  ]                 _
B3    24        h     d                    put
measure 198
C#3   36        h.    u                    on
measure 199
rest  12        q
F#3   12        q     d                    im-
F#3   12        q     d                    mor-
measure 200
F#3   36-       h.    d        -           ta-
measure 201
F#3   12        q     d                    -
G#3    6        e     d  [                 -
F#3    6        e     d  =                 -
E#3    6        e     d  =                 -
F#3    6        e     d  ]                 -
measure 202
G#3   36-       h.    d        -           -
measure 203
G#3   12        q     d                    -
A3     6        e     d  [                 -
G#3    6        e     d  =                 -
F#3    6        e     d  =                 -
G#3    6        e     d  ]                 -
measure 204
A3    36-       h.    d        -           -
measure 205
A3    12        q     d                    -
B3     6        e     d  [                 -
A3     6        e     d  =                 -
G#3    6        e     d  =                 -
A3     6        e     d  ]                 -
measure 206
B3    36-       h.    d        -           -
measure 207
B3    12        q     d                    -
C#4    6        e     d  [                 -
B3     6        e     d  =                 -
A3     6        e     d  =                 -
G#3    6        e     d  ]                 -
measure 208
A3    12        q     d                    -
B3     6        e     d  [                 -
A3     6        e     d  =                 -
G#3    6        e     d  =                 -
F#3    6        e     d  ]                 -
measure 209
C#4   18        q.    d                    -
C#3    6        e     u                    li-
C#3   12        q     u                    ty,
measure 210
rest  36
measure 211
*               D +     Adagio
F#3   12        q     d                    im-
B3    24        h     d                    mor-
measure 212
A3     4        e  3  d  [      (*         ta-
G#3    4        e  3  d  =                 -
F#3    4        e  3  d  ]       !         -
C#3   18        q.    u         )          -
C#3    6        e     u                    li-
measure 213
F#3   24        h     d                    ty.
D3    12        q     d                    The
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-04/6} [KHM:2769854306]
TIMESTAMP: DEC/26/2001 [md5sum:cb83bfdd3dd9792fcf61a931857ba363]
06/24/90 E. Correia
WK#:56        MV#:3,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Air
Bassi
1 19
Group memberships: score
score: part 6 of 6
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:3/4   C:22   D:Pomposo, ma non allegro
D3     3        e.    u  [
D3     1        s     u  ]\
measure 1
D3     4        q     u
rest   2        e
D3     2        e     u  [
D3     3        e.    u  =
D3     1        s     u  ]\
measure 2
C#3    4        q     u
rest   2        e
C#3    2        e     u  [
C#3    3        e.    u  =
C#3    1        s     u  ]\
measure 3
B2     4        q     u
rest   2        e
B2     2        e     u  [
A2     2        e     u  =
G2     2        e     u  ]
measure 4
F#2    6        q.    u
F#3    2        e     d  [
G3     2        e     d  =
A3     2        e     d  ]
measure 5
B3     6        q.    d
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  ]
measure 6
E3     8        h     d
C#4    4        q     d
measure 7
D4     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
D3     4        q     d
measure 8
A3     6        q.    d
B3     2        e     d  [
C#4    2        e     d  =
A3     2        e     d  ]
measure 9
D4     8        h     d
D4     4        q     d
measure 10
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 11
B3     8        h     d
D4     4        q     d
measure 12
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 13
D4     8        h     d
D4     4        q     d
measure 14
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 15
B3     8        h     d
D4     4        q     d
measure 16
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  ]
measure 17
C#4    6        q.    d
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  ]
measure 18
E3     2        e     d  [
F#3    2        e     d  =
E3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  =
F#3    2        e     d  ]
measure 19
G3     6        q.    d
G3     2        e     d  [
F#3    2        e     d  =
E3     2        e     d  ]
measure 20
D3     4        q     d
rest   4        q
rest   4        q
measure 21
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 22
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 23
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 24
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 25
D4     4        q     d
B3     4        q     d
E4     4        q     d
measure 26
A3     6        q.    d
C#4    2        e     d
D4     4        q     d
measure 27
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 28
D3     8        h     u
rest   4        q
mdouble 29      A
rest  12
measure 30
rest   4        q
rest   4        q
D3     3        e.    u  [
D3     1        s     u  ]\
measure 31
D3     6        q.    u
D3     2        e     u  [
D3     3        e.    u  =
D3     1        s     u  ]\
measure 32
C#3    6        q.    u
C#3    2        e     u  [
C#3    3        e.    u  =
C#3    1        s     u  ]\
measure 33
B2     6        q.    u
B2     2        e     u  [
B2     3        e.    u  =
B2     1        s     u  ]\
measure 34
A2     6        q.    u
B2     2        e     u  [
A2     3        e.    u  =
G2     1        s     u  ]\
measure 35
F#2    4        q     u
B2     8        h     u
measure 36
A2     4        q     u
A3     4        q     d
A3     4        q     d
measure 37
B3     4        q     d
C#4    4        q     d
D4     4        q     d
measure 38
E4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  =
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 39
D4     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
D3     4        q     d
measure 40
A3     6        q.    d
G3     2        e     d  [
A3     2        e     d  =
F#3    2        e     d  ]
measure 41
B3     2        e     d  [
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 42
E3     4        q     d
C#4    4        q     d
A3     4        q     d
measure 43
D4     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
D3     4        q     d
measure 44
A3     8        h     d
rest   4        q
measure 45
rest  12
measure 46
rest   4        q
rest   4        q
A2     4        q     u
measure 47
A3     6        q.    d
A3     2        e     d  [
A3     3        e.    d  =
A3     1        s     d  ]\
measure 48
G#3    6        q.    d
G#3    2        e     d  [
G#3    3        e.    d  =
G#3    1        s     d  ]\
measure 49
F#3    6        q.    d
F#3    2        e     d  [
F#3    3        e.    d  =
F#3    1        s     d  ]\
measure 50
E3     4        q     d
G#3    4        q     d
E3     4        q     d
measure 51
A3     4        q     d
G#3    4        q     d
E3     4        q     d
measure 52
A3     4        q     d
G#3    4        q     d
E3     4        q     d
measure 53
A3     4        q     d
E3     4        q     d
G#3    4        q     d
measure 54
A3     4        q     d
E3     4        q     d
C#4    4        q     d
measure 55
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 56
D4     4        q     d
A3     4        q     d
C#4    4        q     d
measure 57
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 58
D4     4        q     d
A3     4        q     d
C#3    4        q     u
measure 59
E3     8        h     d
E3     4        q     d
measure 60
B2     6        q.    u
C#3    2        e     u  [
B2     2        e     u  =
C#3    2        e     u  ]
measure 61
D3     6        q.    d
E3     2        e     d  [
D3     2        e     d  =
E3     2        e     d  ]
measure 62
F#3    4        q     d
F#3    4        q     d
D3     4        q     d
measure 63
A2     6        q.    u
B2     2        e     u  [
A2     2        e     u  =
B2     2        e     u  ]
measure 64
C#3    6        q.    u
D3     2        e     u  [
C#3    2        e     u  =
D3     2        e     u  ]
measure 65
E3     4        q     d
C#3    4        q     u
A2     4        q     u
measure 66
G#2    4        q     u
E2     4        q     u
C#3    4        q     u
measure 67
D3     4        q     d
E3     4        q     d
E2     4        q     u
measure 68
A2     4        q     u
C#3    4        q     u
A2     4        q     u         &f
measure 69
E3     8        h     d
D4     4        q     d
measure 70
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 71
D4     8        h     d
D4     4        q     d
measure 72
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 73
B3     8        h     d
D4     4        q     d
measure 74
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 75
f1              6
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 76
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 77
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 78
C#4    4        q     d
A3     4        q     d
A3     4        q     d
measure 79
D4     4        q     d
D3     2        e     d  [
E3     2        e     d  =
F#3    2        e     d  =
G3     2        e     d  ]
measure 80
A3     8        h     d
C#3    4        q     u
measure 81
D3     8        h     d
D2     4        q     u
measure 82
A2     4        q     u
A3     4        q     d
F#3    4        q     d
measure 83
G3     6        q.    d
F#3    2        e     d
E3     4        q     d
measure 84
D3     8        h     d
D3     3        e.    d  [
D3     1        s     d  ]\
measure 85
D3     6        q.    d
D3     2        e     d  [
D3     3        e.    d  =
D3     1        s     d  ]\
measure 86
D3     4        q     d
F#3    4        q     d
F#3    4        q     d
measure 87
B3     4        q     d
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 88
D4     6        q.    d
D3     2        e     d  [
D3     3        e.    d  =
D3     1        s     d  ]\
measure 89
D3     6        q.    d
D3     2        e     d  [
D3     3        e.    d  =
D3     1        s     d  ]\
measure 90
D3     4        q     d
rest   2        e
F#3    2        e     d  [
E3     2        e     d  =
F#3    2        e     d  ]
measure 91
G3     4        q     d
F#3    4        q     d
D3     4        q     d
measure 92
B3     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
F#3    4        q     d
measure 93
G3     4        q     d
D3     4        q     d
F#3    4        q     d
measure 94
G3     4        q     d
D3     4        q     d
A3     4        q     d
measure 95
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 96
D4     4        q     d
A3     4        q     d
C#4    4        q     d
measure 97
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 98
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 99
rest   4        q
rest   4        q
A3     4        q     d
measure 100
E3     4        q     d
E3     6        q.    d
F#3    2        e     d
measure 101
G3     8        h     d
G3     4        q     d
measure 102
D3     6        q.    d
E3     2        e     d  [
D3     3        e.    d  =
E3     1        s     d  ]\
measure 103
F#3    3        e.    d  [
G3     1        s     d  =\
F#3    3        e.    d  =
G3     1        s     d  =\
A3     3        e.    d  =
F#3    1        s     d  ]\
measure 104
B3     3        e.    d  [
C#4    1        s     d  =\
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 105
E3     2        e     d  [
F#3    2        e     d  =
E3     2        e     d  =
D3     2        e     d  =
C#3    2        e     d  =
B2     2        e     d  ]
measure 106
A2     8        h     u
C#4    4        q     d
measure 107
D4     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
D3     4        q     d
measure 108
A3     4        q     d
C#4    4        q     d
A3     4        q     d
measure 109
D4     4        q     d
F#3    4        q     d
B3     4        q     d
measure 110
A3     4        q     d
C#4    4        q     d
A3     4        q     d
measure 111
D4     4        q     d
D3     4        q     d
D4     4        q     d
measure 112
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 113
D4     6        q.    d
E4     2        e     d  [
D4     2        e     d  =
E4     2        e     d  ]
measure 114
C#4    4        q     d
rest   4        q
B3     4        q     d
measure 115
C#4    4        q     d
rest   4        q
B3     4        q     d
measure 116
C#4    4        q     d
rest   4        q
B3     4        q     d
measure 117
C#4    4        q     d
rest   4        q
B3     4        q     d
measure 118
C#4    2        e     d  [
D4     2        e     d  ]
E4     4        q     d
A3     4        q     d
measure 119
D4     4        q     d
G3     4        q     d
A3     4        q     d
measure 120
D3     4        q     d
F#3    4        q     d
A3     4        q     d
measure 121
F#3    4        q     d
D3     4        q     d
F#3    4        q     d
measure 122
G3     4        q     d
B3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 123
E3     6        q.    d
E3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  ]
measure 124
A3     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]
measure 125
F#3    6        q.    d
F#3    2        e     d  [
G3     2        e     d  =
A3     2        e     d  ]
measure 126
B3     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  ]
measure 127
G3     4        q     d
F#3    4        q     d
E3     4        q     d
measure 128
D3     4        q     d
rest   4        q
D3     4        q     d
measure 129
f2              4+ 2
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 130
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 131
C#4    4        q     d
rest   4        q
f1              6+
B3     4        q     d
measure 132
C#4    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 133
D4     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  =
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 134
D4     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  =
A3     2        e     d  =
B3     2        e     d  =
C#4    2        e     d  ]
measure 135
D4     2        e     d  [
B3     2        e     d  =
E4     2        e     d  =
D4     2        e     d  =
C#4    2        e     d  =
B3     2        e     d  ]
measure 136
A3     8        h     d
B3     4        q     d
measure 137
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 138
B2    12        h.    u         F
measure 139
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 140
D2     8        h     u
D3     3        e.    u  [      &f
D3     1        s     u  ]\
measure 141
D3     6        q.    u
D3     2        e     u  [
D3     3        e.    u  =
D3     1        s     u  ]\
measure 142
C#3    6        q.    u
C#3    2        e     u  [
C#3    3        e.    u  =
C#3    1        s     u  ]\
measure 143
B2     6        q.    u
B2     2        e     u  [
A2     2        e     u  =
G2     2        e     u  ]
measure 144
F#2    6        q.    u
F#3    2        e     d  [
G3     2        e     d  =
A3     2        e     d  ]
measure 145
B3     2        e     d  [
C#4    2        e     d  =
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  =
F#3    2        e     d  ]
measure 146
E3     4        q     d
D4     4        q     d
C#4    4        q     d
measure 147
D4     2        e     d  [
C#4    2        e     d  ]
D4     4        q     d
D3     4        q     d
measure 148
A3     4        q     d
rest   4        q
rest   4        q
measure 149
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 150
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 151
rest   4        q
rest   2        e
C#4    2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 152
D4     4        q     d
C#4    4        q     d
A3     4        q     d
measure 153
D4     4        q     d
B3     4        q     d
E4     4        q     d
measure 154
A3     6        q.    d
C#4    2        e     d
D4     4        q     d
measure 155
G3     4        q     d
A3     4        q     d
A2     4        q     u
measure 156
*               C       (Fine)
D3     8        h     d         F
mdouble
rest   4        q
measure 157
B2     4        q     u         &p
D3     4        q     d
E3     4        q     d
measure 158
F#3    8        h     d
E3     4        q     d
measure 159
D3     4        q     d
C#3    8        h     u
measure 160
B2     8        h     u
A2     4        q     u
measure 161
G2    12        h.    u
measure 162
F#2    4        q     u
F#3    4        q     d
E3     4        q     d
measure 163
D3     4        q     d
D3     4        q     d
C#3    4        q     u
measure 164
B2     8        h     u
rest   4        q
measure 165
rest   4        q
B2     4        q     u
E3     4        q     d
measure 166
F#3   12        h.    d
measure 167
D3     4        q     d
B2     4        q     u
D3     4        q     d
measure 168
E3     4        q     d
B2     4        q     u
D3     4        q     d
measure 169
C#3   12        h.    u
measure 170
D3     4        q     d
F#3    2        e     d  [
E3     2        e     d  =
D3     2        e     d  =
C#3    2        e     d  ]
measure 171
B2     4        q     u
D3     4        q     d
B2     4        q     u
measure 172
C#3    4        q     u
E3     4        q     d
C#3    4        q     u
measure 173
F#3    4        q     d
F#2    4        q     u
A#2    4        q     u
measure 174
B2     4        q     u
B2     4        q     u
C#3    4        q     u
measure 175
D3     4        q     d
D3     4        q     d
E3     4        q     d
measure 176
F#3    8        h     d
G3     4        q     d
measure 177
E3     4        q     d
F#3    4        q     d
F#2    4        q     u
measure 178
B2     4        q     u
B2     4        q     u
C#3    4        q     u
measure 179
D3     4        q     d
E3     4        q     d
F#3    4        q     d
measure 180
G3     4        q     d
E3     4        q     d
F#3    4        q     d
measure 181
B2     8        h     u
B3     4        q     d
measure 182
C#4    4        q     d
G#3    4        q     d
A3     4        q     d
measure 183
E#3    4        q     d
F#3    8        h     d
measure 184
C#3    4        q     u
C#4    4        q     d
B3     4        q     d
measure 185
A3     8        h     d
A2     4        q     u
measure 186
B2     4        q     u
C#3    4        q     u
D3     4        q     d
measure 187
E3     4        q     d
G#2    4        q     u
E2     4        q     u
measure 188
A2     4        q     u
B2     4        q     u
C#3    4        q     u
measure 189
D3     4        q     d
F#3    4        q     d
D3     4        q     d
measure 190
G#2    4        q     u
A2     4        q     u
B2     4        q     u
measure 191
C#3    4        q     u
E#3    4        q     d
C#3    4        q     u
measure 192
F#3    4        q     d
A2     4        q     u
F#2    4        q     u
measure 193
G#2    4        q     u
B2     4        q     u
G#2    4        q     u
measure 194
A2     4        q     u
A3     4        q     d
F#3    4        q     d
measure 195
B3     4        q     d
B2     4        q     u
C#3    4        q     u
measure 196
D3    12        h.    d
measure 197
B2    12        h.    u
measure 198
E#2    4        q     u
f1              #
C#3    4        q     u
B2     4        q     u
measure 199
f1              6
A2     8        h     u
G#2    4        q     u
measure 200
F#2    4        q     u
D3     4        q     u
C#3    4        q     u
measure 201
B2     8        h     u
rest   4        q
measure 202
rest   4        q
B2     4        q     u
G#2    4        q     u
measure 203
C#3    8        h     u
rest   4        q
measure 204
rest   4        q
C#3    4        q     u
A2     4        q     u
measure 205
D3     8        h     u
rest   4        q
measure 206
rest   4        q
D3     4        q     u
B2     4        q     u
measure 207
C#3    8        h     u
E#3    4        q     d
measure 208
F#3    4        q     d
E3     4        q     d         +
D3     4        q     d
measure 209
C#3    8        h     u
B2     4        q     u
measure 210
A2     4        q     u
G#2    4        q     u
F#2    4        q     u
measure 211
D3     8        h     u
B2     4        q     u
measure 212
C#3   12        h.    u
measure 213
F#2    8        h     u
rest   4        q
*               B       Dal Segno
mdouble         A
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
