&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-08/1} [KHM:866574218]
TIMESTAMP: DEC/26/2001 [md5sum:0c195336f3fa9d46fc9c944142ed6114]
04/07/90 E. Correia
WK#:56        MV#:1,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitativo
Contr'alto
1 20 A
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
D4     2        e     u                    Be-
F#4    4        q     u                    hold,
rest   2        e
F#4    2        e     u                    a
measure 2
F#4    2        e     u                    vir-
F#4    2        e     u                    gin
E4     2        e     u                    shall
D4     2        e     u                    con-
G4     4        q     u                    ceive,
rest   4        q
measure 3
rest   2        e
G4     2        e     u                    and
A4     2        e     u                    bear
E4     2        e     u                    a
F#4    4        q     u                    son,
rest   4        q
measure 4
F#4    2        e     u                    and
F#4    2        e     u                    shall
G#4    2        e     u                    call
A4     2        e     u                    his
D4     4        q     u                    name
rest   2        e
B3     2        e     u                    E-
measure 5
E4     3        e.    u                    ma-
E4     1        s     u                    nu-
E4     4        q     u                    el,
rest   8        h
measure 6
F#4    4        q     u                    God
rest   2        e
A4     2        e     u                    with
E4     4        q     u                    us.
rest   4        q
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-08/2} [KHM:866574218]
TIMESTAMP: DEC/26/2001 [md5sum:404e8ebc43c46342e05ad6ccf8783953]
04/07/90 E. Correia
WK#:56        MV#:1,8
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitativo
Bassi
1 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:1   T:1/1   C:22
D3     4-       w     u        -
measure 2
f2     2        5 3
f3              7 4 2
D3     4-       w     u        -
measure 3
f3     2        7 4 2
f2              5 3
D3     4-       w     u        -
measure 4
D3     2        h     u
f1              6+
B2     2        h     u
measure 5
A2     4        w     u
measure 6
f1              #
D3     2        h     u
f1              #
E3     1        q     d
A2     1        q     u
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
