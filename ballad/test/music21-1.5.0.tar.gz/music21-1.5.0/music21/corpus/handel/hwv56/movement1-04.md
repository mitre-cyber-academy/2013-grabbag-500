&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/1} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:e823973e164286281772c31ec308f860]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:4   D:Allegro
rest   2        q
C#5    2        q     d
A4     2        q     u
measure 2
E5     3        q.    d
D5     1        e     d
C#5    2        q     d
measure 3
F#5    2        q     d
F#5    2        q     d
G#5    2        q     d
measure 4
A5     4        h     d
E5     2        q     d
measure 5
D5     3        q.    d
F#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  ]
measure 6
C#5    3        q.    d
E5     1        e     d  [
D5     1        e     d  =
C#5    1        e     d  ]
measure 7
B4     2        q     d
E5     4-       h     d        -
measure 8
E5     2        q     d
D5     4-       h     d        -
measure 9
D5     3        q.    d
E5     1        e     d
C#5    2-       q     d        -
measure 10
C#5    1        e     d  [
B4     1        e     d  ]
B4     3        q.    u         &t
A4     1        e     u
measure 11
A4     4        h     u
rest   2        q
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
E5     2        q     d
A5     2        q     d
measure 15
G#5    3        q.    d
F#5    1        e     d
E5     2        q     d
measure 16
D6     2        q     d
D6     2        q     d
B5     2        q     d
measure 17
C#6    4        h     d
rest   2        q
measure 18
rest   6
measure 19
rest   6
measure 20
rest   6
measure 21
rest   6
measure 22
rest   6
measure 23
rest   6
measure 24
rest   6
measure 25
rest   6
measure 26
rest   6
measure 27
rest   6
measure 28
rest   6
measure 29
rest   6
measure 30
rest   6
measure 31
rest   6
measure 32
rest   6
measure 33
rest   2        q
B5     2        q     d
G#5    2        q     d
measure 34
F#5    3        q.    d
F#5    1        e     d
B5     2        q     d
measure 35
A5     2        q     d
A5     2        q     d
A5     2        q     d
measure 36
G#5    3        q.    d
E5     1        e     d
F#5    2        q     d
measure 37
G#5    2        q     d
F#5    4        h     d
measure 38
G#5    3        q.    d
B5     1        e     d  [
A5     1        e     d  =
G#5    1        e     d  ]
measure 39
F#5    3        q.    d
A5     1        e     d  [
G#5    1        e     d  =
F#5    1        e     d  ]
measure 40
E5     2        q     d
A5     4-       h     d        -
measure 41
A5     3        q.    d
B5     1        e     d
G#5    2-       q     d        -
measure 42
G#5    1        e     d  [
F#5    1        e     d  ]
F#5    4        h     d         &t
measure 43
E5     4        h     d
rest   2        q
measure 44
rest   6
measure 45
rest   6
measure 46
rest   2        q
B4     2        q     u
E5     2        q     d
measure 47
C#5    2        q     d
rest   2        q
rest   2        q
measure 48
rest   6
measure 49
rest   6
measure 50
rest   2        q
A5     2        q     d
D6     2        q     d
measure 51
C#6    1        e     d  [
B5     1        e     d  ]
A5     2        q     d
rest   2        q
measure 52
rest   6
measure 53
rest   2        q
A5     2        q     d
D6     2        q     d
measure 54
C#6    1        e     d  [
B5     1        e     d  ]
A5     2        q     d
D6     2        q     d
measure 55
C#6    1        e     d  [
B5     1        e     d  ]
A5     2        q     d
C#6    2        q     d
measure 56
D6     3        q.    d
C#6    1        e     d  [
D6     1        e     d  =
E6     1        e     d  ]
measure 57
C#6    1        e     d  [
E5     1        e     d  =
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  =
D5     1        e     d  ]
measure 58
E5     4        h     d
E5     2        q     d
measure 59
E5     6        h.    d
measure 60
E5     6        h.    d
measure 61
E5     4        h     d
E5     2        q     d
measure 62
F#5    4        h     d
F#5    2        q     d
measure 63
E5     4        h     d
rest   2        q
measure 64
rest   6
measure 65
rest   6
measure 66
rest   6
measure 67
rest   6
measure 68
rest   6
measure 69
rest   2        q
D#5    2        q     d
G#5    2        q     d
measure 70
F#5    1        e     d  [
E5     1        e     d  ]
D#5    2        q     d
G#5    2        q     d
measure 71
F#5    1        e     d  [
E5     1        e     d  ]
D#5    2        q     d
B5     2        q     d
measure 72
B5     4        h     d
A#5    2        q     d
measure 73
B5     2        q     d
D#5    2        q     d
B4     2        q     u
measure 74
F#5    3        q.    d
E5     1        e     d
D#5    2        q     d
measure 75
G#5    2        q     d
G#5    2        q     d
A#5    2        q     d
measure 76
B5     2        q     d
F#5    2        q     d
B5     2        q     d
measure 77
A#5    3        q.    d
G#5    1        e     d
F#5    2        q     d
measure 78
B5     2        q     d
E5     2        q     d
F#5    2        q     d
measure 79
D#5    2        q     d
F#5    2        q     d
B5     2        q     d
measure 80
A#5    1        e     d  [
G#5    1        e     d  ]
F#5    2        q     d
B5     2        q     d
measure 81
C#6    1        e     d  [
B5     1        e     d  ]
A#5    2        q     d
B5     2        q     d
measure 82
C#6    1        e     d  [
B5     1        e     d  ]
A#5    2        q     d
B5     2        q     d
measure 83
C#6    2        q     d
F#5    2        q     d
F#5    2        q     d
measure 84
F#5    6        h.    d
measure 85
F#5    4        h     d
F#5    2        q     d
measure 86
F#5    4        h     d
E5     2        q     d
measure 87
D#5    3        q.    d         &t
C#5    1        e     d
B4     2        q     u
measure 88
rest   6
measure 89
rest   6
measure 90
rest   6
measure 91
rest   6
measure 92
rest   6
measure 93
rest   2        q
B4     2        q     u
B4     2        q     u
measure 94
B4     6-       h.    u        -
measure 95
B4     6-       h.    u        -
measure 96
B4     2        q     u
B5     2        q     d
B5     2        q     d
measure 97
B5     6-       h.    d        -
measure 98
B5     4        h     d
B5     2-       q     d        -
measure 99
B5     2        q     d
A5     4-       h     d        -
measure 100
A5     4        h     d
G#5    2        q     d
measure 101
F#5    2        q     d
F#5    3        q.    d
F#5    1        e     d
measure 102
G#5    2        q     d
E5     2        q     d
A5     2        q     d
measure 103
G#5    1        e     d  [
F#5    1        e     d  ]
E5     2        q     d
rest   2        q
measure 104
rest   2        q
E4     2        q     u
C#4    2        q     u
measure 105
B3     2        q     u
rest   2        q
rest   2        q
measure 106
rest   2        q
E5     2        q     d
E5     2        q     d
measure 107
E5     2        q     d
C#5    2        q     d
A4     2        q     u
measure 108
E5     3        q.    d
D5     1        e     d
C#5    2        q     d
measure 109
F#5    2        q     d
F#5    2        q     d
G#5    2        q     d
measure 110
A5     6        h.    d
measure 111
rest   2        q
rest   2        q
E5     2        q     d
measure 112
D5     3        q.    d
F#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  ]
measure 113
C#5    3        q.    d
E5     1        e     d  [
D5     1        e     d  =
C#5    1        e     d  ]
measure 114
B4     2        q     u
B4     2        q     u
rest   2        q
measure 115
rest   6
measure 116
rest   6
measure 117
rest   6
measure 118
rest   2        q
E5     2        q     d
A5     2        q     d
measure 119
G#5    1        e     d  [
F#5    1        e     d  ]
E5     2        q     d
rest   2        q
measure 120
rest   2        q
rest   2        q
A5     2        q     d
measure 121
G#5    1        e     d  [
F#5    1        e     d  ]
E5     2        q     d
A5     2        q     d
measure 122
G#5    1        e     d  [
F#5    1        e     d  ]
E5     2        q     d
B5     2        q     d
measure 123
A5     6        h.    d
measure 124
G#5    2        q     d
E5     2        q     d
E5     2        q     d
measure 125
E5     6        h.    d
measure 126
E5     4        h     d
E5     2        q     d
measure 127
E5     3        q.    d
D5     1        e     d
C#5    2        q     d
measure 128
D5     2        q     d
B4     3        q.    u         &t
A4     1        e     u
measure 129
A4     2        q     u
A5     2        q     d
A5     2        q     d
measure 130
A5     6-       h.    d        -
measure 131
A5     6-       h.    d        -
measure 132
A5     6-       h.    d        -
measure 133
A5     6        h.    d
measure 134
A5     2        q     d
E5     2        q     d
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
E5     2        q     d
measure 136
F#5    6-       h.    d        -
measure 137
F#5    4        h     d
F#5    2        q     d
measure 138
E5     6        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/2} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:974a30883995ba938a9df7a73d620785]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:4   D:Allegro
rest   2        q
E4     2        q     u
C#5    2        q     d
measure 2
B4     2        q     u
G#4    2        q     u
C#5    2        q     d
measure 3
A4     2        q     u
D5     2        q     d
B4     2        q     u
measure 4
E5     2        q     d
C#5    4-       h     d        -
measure 5
C#5    2        q     d
B4     4-       h     u        -
measure 6
B4     2        q     u
A4     2        q     u
A4     2        q     u
measure 7
G#4    3        q.    u
B4     1        e     u  [
A4     1        e     u  =
G#4    1        e     u  ]
measure 8
F#4    3        q.    u
A4     1        e     u  [
G#4    1        e     u  =
F#4    1        e     u  ]
measure 9
E4     2        q     u
G#4    2        q     u
A4     2        q     u
measure 10
A4     4        h     u
G#4    2        q     u
measure 11
A4     4        h     u
rest   2        q
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
A4     2        q     u
C#5    2        q     d
measure 15
B4     3        q.    u
B4     1        e     u
A5     2        q     d
measure 16
A5     2        q     d
A5     2        q     d
E5     2        q     d
measure 17
E5     4        h     d
rest   2        q
measure 18
rest   6
measure 19
rest   6
measure 20
rest   6
measure 21
rest   6
measure 22
rest   6
measure 23
rest   6
measure 24
rest   6
measure 25
rest   6
measure 26
rest   6
measure 27
rest   6
measure 28
rest   6
measure 29
rest   6
measure 30
rest   6
measure 31
rest   6
measure 32
rest   6
measure 33
rest   2        q
B4     2        q     u
E5     2        q     d
measure 34
D#5    3        q.    d
D#5    1        e     d
E5     2        q     d
measure 35
E5     2        q     d
E5     2        q     d
F#5    2        q     d
measure 36
B4     3        q.    u
C#5    1        e     d
D#5    2        q     d
measure 37
E5     4        h     d
D#5    2        q     d
measure 38
E5     2        q     d
B4     2        q     u
E5     2-       q     d        -
measure 39
E5     2        q     d
D#5    4        h     d
measure 40
C#5    3        q.    d
E5     1        e     d  [
D#5    1        e     d  =
C#5    1        e     d  ]
measure 41
B4     2        q     d
D#5    2        q     d
E5     2        q     d
measure 42
E5     4        h     d
D#5    2        q     d
measure 43
E5     4        h     d
rest   2        q
measure 44
rest   6
measure 45
rest   6
measure 46
rest   2        q
E4     2        q     u
G#4    2        q     u
measure 47
E4     2        q     u
rest   2        q
rest   2        q
measure 48
rest   6
measure 49
rest   6
measure 50
rest   2        q
D5     2        q     d
F#5    2        q     d
measure 51
E5     1        e     d  [
D5     1        e     d  ]
C#5    2        q     d
rest   2        q
measure 52
rest   6
measure 53
rest   2        q
C#5    2        q     d
F#5    2        q     d
measure 54
E5     1        e     d  [
D5     1        e     d  ]
C#5    2        q     d
F#5    2        q     d
measure 55
E5     1        e     d  [
D5     1        e     d  ]
C#5    2        q     d
A5     2        q     d
measure 56
A5     2        q     d
G#5    4        h     d
measure 57
A5     2        q     d
C#5    1        e     u  [
B4     1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
measure 58
G#4    1        e     u  [
E4     1        e     u  =
F#4    1        e     u  =
G#4    1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
measure 59
G#4    2        q     u
G#5    2        q     d
C#6    2        q     d
measure 60
B5     1        e     d  [
A5     1        e     d  ]
G#5    2        q     d
C#6    2        q     d
measure 61
B5     1        e     d  [
A5     1        e     d  ]
G#5    2        q     d
C#6    2        q     d
measure 62
D6     4        h     d
D6     2        q     d
measure 63
C#6    4        h     d
rest   2        q
measure 64
rest   6
measure 65
rest   6
measure 66
rest   6
measure 67
rest   6
measure 68
rest   6
measure 69
rest   2        q
B4     2        q     u
E5     2        q     d
measure 70
D#5    1        e     d  [
C#5    1        e     d  ]
B4     2        q     u
E5     2        q     d
measure 71
D#5    1        e     d  [
C#5    1        e     d  ]
B4     2        q     u
D#5    2        q     d
measure 72
E5     6        h.    d
measure 73
D#5    2        q     d
B4     2        q     u
F#4    2        q     u
measure 74
D#5    3        q.    d
C#5    1        e     d
B4     2        q     u
measure 75
B4     2        q     u
B4     2        q     u
E5     2        q     d
measure 76
D#5    2        q     d
B4     2        q     u
D#5    2        q     d
measure 77
C#5    3        q.    d
C#5    1        e     d
D#5    2        q     d
measure 78
E5     2        q     d
B4     2        q     u
C#5    2        q     d
measure 79
F#4    2        q     u
B4     2        q     u
D#5    2        q     d
measure 80
C#5    1        e     d  [
B4     1        e     d  ]
A#4    2        q     u
F#5    2        q     d
measure 81
F#5    3        q.    d
E5     1        e     d
D#5    2        q     d
measure 82
F#5    3        q.    d
E5     1        e     d
D#5    2        q     d
measure 83
F#5    2        q     d
F#5    2        q     d
F#5    2        q     d
measure 84
F#5    6        h.    d
measure 85
F#5    4        h     d
F#5    2        q     d
measure 86
F#5    4        h     d
E5     2        q     d
measure 87
D#5    2        q     d
B4     2        q     u
F#4    2        q     u
measure 88
E4     3        q.    u
G#4    1        e     u  [
F#4    1        e     u  =
E4     1        e     u  ]
measure 89
D#4    1        e     u  [
C#4    1        e     u  ]
B3     2        q     u
rest   2        q
measure 90
rest   6
measure 91
rest   2        q
B3     2        q     u
E4     2        q     u
measure 92
D#4    1        e     u  [
C#4    1        e     u  ]
B3     2        q     u
D#4    2        q     u
measure 93
E4     2        q     u
F#4    3        q.    u
F#4    1        e     u
measure 94
B3     2        q     u
B3     2        q     u
rest   2        q
measure 95
rest   2        q
B4     2        q     u
B4     2        q     u
measure 96
B4     4        h     u
A4     2        q     u
measure 97
G#4    4        h     u
G#4    2        q     u
measure 98
F#4    4        h     u
rest   2        q
measure 99
rest   2        q
E5     2        q     d
F#5    2        q     d
measure 100
B4     4        h     u
E5     2-       q     d        -
measure 101
E5     1        e     d  [
F#5    1        e     d  ]
D#5    3        q.    d
D#5    1        e     d
measure 102
E5     2        q     d
E4     2        q     u
C#4    2        q     u
measure 103
B3     2        q     u
B4     2        q     u
E5     2        q     d
measure 104
C#5    1        e     d  [
B4     1        e     d  ]
A4     2        q     u
rest   2        q
measure 105
rest   2        q
rest   2        q
G#4    2        q     u
measure 106
A4     2        q     u
B4     3        q.    u
B4     1        e     u
measure 107
A4     2        q     u
C#5    2        q     d
A4     2        q     u
measure 108
E5     3        q.    d
D5     1        e     d
C#5    2        q     d
measure 109
F#5    2        q     d
F#5    2        q     d
G#5    2        q     d
measure 110
A5     2        q     d
E4     2        q     u
A4     2        q     u
measure 111
G#4    3        q.    u
F#4    1        e     u
E4     2        q     u
measure 112
A4     2        q     u
A4     2        q     u
E4     2        q     u
measure 113
E4     4        h     u
A4     2        q     u
measure 114
G#4    3        q.    u
B4     1        e     u  [
A4     1        e     u  =
G#4    1        e     u  ]
measure 115
F#4    3        q.    u
A4     1        e     u  [
G#4    1        e     u  =
F#4    1        e     u  ]
measure 116
E4     2        q     u
E4     2        q     u
A4     2        q     u
measure 117
G#4    2        q     u
G#4    2        q     u
rest   2        q
measure 118
rest   6
measure 119
rest   2        q
B4     2        q     u
E5     2        q     d
measure 120
C#5    1        e     d  [
B4     1        e     d  ]
A4     2        q     u
C#5    2        q     d
measure 121
B4     1        e     u  [
A4     1        e     u  ]
G#4    2        q     u
C#5    2        q     d
measure 122
B4     1        e     u  [
A4     1        e     u  ]
G#4    2        q     u
E5     2        q     d
measure 123
C#5    6        h.    d
measure 124
B4     2        q     u
E5     2        q     d
E5     2        q     d
measure 125
E5     2        q     d
G#4    2        q     u
C#5    2        q     d
measure 126
B4     2        q     u
G#4    2        q     u
B4     2        q     u
measure 127
C#5    3        q.    d
B4     1        e     u
A4     2        q     u
measure 128
A4     2        q     u
G#4    3        q.    u
A4     1        e     u
measure 129
A4     2        q     u
A5     2        q     d
A5     2        q     d
measure 130
A5     2        q     d
C#5    2        q     d
F#5    2        q     d
measure 131
E5     2        q     d
C#5    2        q     d
F#5    2        q     d
measure 132
E5     1        e     d  [
D5     1        e     d  ]
C#5    2        q     d
F#5    2        q     d
measure 133
E5     2        q     d
C#5    2        q     d
F#5    2        q     d
measure 134
E5     1        e     d  [
D5     1        e     d  ]
C#5    2        q     d
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
C#5    2        q     d
measure 136
D5     6-       h.    d        -
measure 137
D5     4        h     d
D5     2        q     d
measure 138
C#5    6        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/3} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:d21936b2b7c6cc36ea9e64a71fee0dda]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:13   D:Allegro
rest   2        q
A4     2        q     d
E4     2        q     d
measure 2
E4     4        h     d
E4     2        q     d
measure 3
D5     2        q     d
D4     2        q     d
E4     2        q     d
measure 4
E4     2        q     d
A4     4        h     d
measure 5
A4     2        q     d
E4     4        h     d
measure 6
E4     4        h     d
E4     2        q     d
measure 7
E4     4        h     d
E4     2        q     d
measure 8
C#4    2        q     d
D4     4        h     d
measure 9
B4     2        q     d
B3     2        q     u
F#4    2        q     d
measure 10
F#4    2        q     d
B3     2        q     u
E4     2        q     d
measure 11
C#4    4        h     u
rest   2        q
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
C#4    2        q     u
E4     2        q     d
measure 15
E4     3        q.    d
E4     1        e     d
A4     2        q     d
measure 16
A4     2        q     d
A4     2        q     d
B4     2        q     d
measure 17
A4     4        h     d
rest   2        q
measure 18
rest   6
measure 19
rest   6
measure 20
rest   6
measure 21
rest   6
measure 22
rest   6
measure 23
rest   6
measure 24
rest   6
measure 25
rest   6
measure 26
rest   6
measure 27
rest   6
measure 28
rest   6
measure 29
rest   6
measure 30
rest   6
measure 31
rest   6
measure 32
rest   6
measure 33
rest   2        q
E4     2        q     d
B4     2        q     d
measure 34
B4     3        q.    d
B4     1        e     d
B4     2        q     d
measure 35
C#5    2        q     d
C#5    2        q     d
B4     2        q     d
measure 36
B4     3        q.    d
B4     1        e     d
A4     2        q     d
measure 37
B4     2        q     d
B4     4        h     d
measure 38
B4     4        h     d
B4     2        q     d
measure 39
B4     3        q.    d
C#5    1        e     d  [
B4     1        e     d  =
A4     1        e     d  ]
measure 40
G#4    2        q     d
F#4    2        q     d
F#4    2        q     d
measure 41
F#4    2        q     d
F#4    2        q     d
E4     2        q     d
measure 42
C#5    2        q     d
F#4    2        q     d
B4     2        q     d
measure 43
G#4    4        h     d
rest   2        q
measure 44
rest   6
measure 45
rest   6
measure 46
rest   2        q
B3     2        q     u
B3     2        q     u
measure 47
A4     2        q     d
rest   2        q
rest   2        q
measure 48
rest   6
measure 49
rest   6
measure 50
rest   2        q
A4     2        q     d
A4     2        q     d
measure 51
A4     2        q     d
E4     2        q     d
rest   2        q
measure 52
rest   6
measure 53
rest   2        q
A4     2        q     d
A4     2        q     d
measure 54
A4     4        h     d
A3     2        q     u
measure 55
A4     4        h     d
A4     2        q     d
measure 56
F#4    2        q     d
D4     4        h     d
measure 57
E4     6        h.    d
measure 58
rest   1        e
G#4    1        e     d  [
A4     1        e     d  =
B4     1        e     d  =
C#5    1        e     d  =
D5     1        e     d  ]
measure 59
B4     2        q     d
B4     2        q     d
A4     2        q     d
measure 60
B4     2        q     d
B4     2        q     d
A4     2        q     d
measure 61
B4     2        q     d
B4     2        q     d
A4     2        q     d
measure 62
A4     4        h     d
A4     2        q     d
measure 63
A4     4        h     d
rest   2        q
measure 64
rest   6
measure 65
rest   6
measure 66
rest   6
measure 67
rest   6
measure 68
rest   6
measure 69
rest   2        q
F#4    2        q     d
E4     2        q     d
measure 70
F#4    4        h     d
B3     2        q     u
measure 71
F#4    4        h     d
F#4    2        q     d
measure 72
E4     4        h     d
E4     2        q     d
measure 73
F#4    6        h.    d
measure 74
rest   2        q
B4     2        q     d
F#4    2        q     d
measure 75
G#4    2        q     d
F#4    2        q     d
E4     2        q     d
measure 76
F#4    2        q     d
F#4    2        q     d
F#4    2        q     d
measure 77
F#4    3        q.    d
F#4    1        e     d
B4     2        q     d
measure 78
B4     2        q     d
G#4    2        q     d
F#4    2        q     d
measure 79
B4     2        q     d
rest   2        q
rest   2        q
measure 80
rest   2        q
C#5    2        q     d
D#5    2        q     d
measure 81
F#4    4        h     d
F#4    2        q     d
measure 82
F#4    4        h     d
F#4    2        q     d
measure 83
F#4    2        q     d
A#4    2        q     d
F#4    2        q     d
measure 84
rest   2        q
D#4    2        q     d
B3     2        q     u
measure 85
F#4    3        q.    d
E4     1        e     d
D#4    2        q     d
measure 86
G#4    2        q     d
G#4    2        q     d
A#4    2        q     d
measure 87
B4     4        h     d
D#4    2        q     d
measure 88
C#4    2        q     u
G#3    2        q     u
A#3    2        q     u
measure 89
B3     2        q     u
B3     2        q     u
E4     2        q     d
measure 90
D#4    1        e     d  [
C#4    1        e     d  ]
B3     2        q     u
rest   2        q
measure 91
rest   6
measure 92
rest   2        q
rest   2        q
B3     2        q     u
measure 93
B3     2        q     u
A3     3        q.    u
A3     1        e     u
measure 94
G#3    2        q     u
G#3    2        q     u
E3     2        q     u
measure 95
B3     3        q.    u
A3     1        e     u
G#3    2        q     u
measure 96
C#4    2        q     u
D#4    3        q.    d
D#4    1        e     d
measure 97
E4     4        h     d
E4     2        q     d
measure 98
D#4    3        q.    d
F#4    1        e     d  [
E4     1        e     d  =
D#4    1        e     d  ]
measure 99
C#4    3        q.    u
E4     1        e     d  [
D#4    1        e     d  =
C#4    1        e     d  ]
measure 100
B3     2        q     u
B4     2        q     d
B4     2        q     d
measure 101
C#5    2        q     d
B4     2        q     d
B4     2        q     d
measure 102
B4     2        q     d
rest   2        q
rest   2        q
measure 103
rest   2        q
B4     2        q     d
G#4    2        q     d
measure 104
E4     2        q     d
E4     2        q     d
A4     2        q     d
measure 105
G#4    1        e     d  [
F#4    1        e     d  ]
E4     2        q     d
E4     2        q     d
measure 106
E4     1        e     d  [
D4     1        e     d  ]
D4     3        q.    d
D4     1        e     d
measure 107
C#4    2        q     u
E4     2        q     d
A4     2        q     d
measure 108
rest   6
measure 109
rest   6
measure 110
rest   2        q
A3     2        q     u
C#4    2        q     u
measure 111
B3     3        q.    u
B3     1        e     u
C#4    2        q     u
measure 112
D4     2        q     d
D4     2        q     d
B3     2        q     u
measure 113
C#4    4        h     u
rest   2        q
measure 114
rest   6
measure 115
rest   6
measure 116
rest   2        q
rest   2        q
E4     2        q     d
measure 117
D4     3        q.    d
F#4    1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
measure 118
C#4    3        q.    u
E4     1        e     d  [
D4     1        e     d  =
C#4    1        e     d  ]
measure 119
B3     2        q     u
G#3    2        q     u
G#3    2        q     u
measure 120
E4     1        e     d  [
D4     1        e     d  ]
C#4    2        q     u
C#4    2        q     u
measure 121
E4     2        q     d
B3     2        q     u
E4     2        q     d
measure 122
E4     2        q     d
B3     2        q     u
B3     2        q     u
measure 123
E4     6        h.    d
measure 124
E4     4        h     d
rest   2        q
measure 125
rest   2        q
B4     2        q     d
A4     2        q     d
measure 126
E4     2        q     d
B3     2        q     u
E4     2        q     d
measure 127
A4     4        h     d
E4     2        q     d
measure 128
F#4    2        q     d
B3     2        q     u
E4     2        q     d
measure 129
C#4    4        h     u
rest   2        q
measure 130
rest   2        q
E4     2        q     d
D4     2        q     d
measure 131
E4     2        q     d
E4     2        q     d
D4     2        q     d
measure 132
E4     2        q     d
E4     2        q     d
D4     2        q     d
measure 133
E4     2        q     d
E4     2        q     d
D4     2        q     d
measure 134
E4     2        q     d
A4     2        q     d
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
A4     2        q     d
measure 136
A4     6-       h.    d        -
measure 137
A4     4        h     d
A4     2        q     d
measure 138
A4     6        h.    d
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/4} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:71ddc51606bbace683aa6718b6399fe8]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:4   D:Allegro
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
rest   6
measure 5
rest   6
measure 6
rest   6
measure 7
rest   6
measure 8
rest   6
measure 9
rest   6
measure 10
rest   6
measure 11
rest   6
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
E5     2        q     d                    And
C#5    2        q     d                    the
measure 15
B4     3        q.    u                    glo-
B4     1        e     u                    ry,
E5     2        q     d                    the
measure 16
D5     2        q     d                    glory
D5     2        q     d                    of
E5     2        q     d                    the
measure 17
C#5    4        h     d                    Lord
rest   2        q
measure 18
rest   6
measure 19
rest   6
measure 20
rest   2        q
rest   2        q
B4     2        q     u                    shall
measure 21
A4     3        q.    u                    be
C#5    1        e     d  [                 re-
B4     1        e     d  =                 -
A4     1        e     d  ]                 -
measure 22
G#4    3        q.    u                    vea-
B4     1        e     u  [                 -
A4     1        e     u  =                 -
G#4    1        e     u  ]                 -
measure 23
F#4    2        q     u                    -
F#4    2        q     u                    led,
rest   2        q
measure 24
rest   6
measure 25
rest   2        q
G#4    2        q     u                    and
E4     2        q     u                    the
measure 26
B4     3        q.    u                    glo-
A4     1        e     u                    ry,
G#4    2        q     u                    the
measure 27
C#5    2        q     d                    glory
C#5    2        q     d                    of
D#5    2        q     d                    the
measure 28
E5     6        h.    d                    Lord
measure 29
rest   6
measure 30
rest   6
measure 31
rest   2        q
rest   2        q
B4     2        q     u                    shall
measure 32
A4     3        q.    u                    be
C#5    1        e     u  [                 re-
B4     1        e     u  =                 -
A4     1        e     u  ]                 -
measure 33
G#4    2        q     u                    veal'd,
B4     2        q     u                    and
E5     2        q     d                    the
measure 34
D#5    3        q.    d                    glo-
D#5    1        e     d                    ry,
E5     2        q     d                    the
measure 35
C#5    2        q     d                    glory
C#5    2        q     d                    of
B4     2        q     u                    the
measure 36
B4     3        q.    u                    Lord
C#5    1        e     d                    shall
D#5    2        q     d                    be
measure 37
E5     2        q     d                    re-
E5     2        q     d         (          vea-
D#5    2        q     d         )          -
measure 38
E5     6        h.    d                    led.
measure 39
rest   6
measure 40
rest   6
measure 41
rest   6
measure 42
rest   6
measure 43
rest   6
measure 44
rest   6
measure 45
rest   6
measure 46
rest   6
measure 47
rest   6
measure 48
rest   6
measure 49
rest   6
measure 50
rest   6
measure 51
rest   6
measure 52
rest   6
measure 53
rest   2        q
A4     2        q     u                    And
D5     2        q     d                    all
measure 54
C#5    1        e     d  [      (          flesh_
B4     1        e     d  ]                 _
A4     2        q     u         )          _
D5     2        q     d                    shall
measure 55
C#5    1        e     d  [                 see_
B4     1        e     d  ]                 _
A4     2        q     u                    it
C#5    2        q     d                    to-
measure 56
D5     6        h.    d                    ge-
measure 57
C#5    6        h.    d                    ther,
measure 58
E5     4        h     d                    for
E5     2        q     d                    the
measure 59
E5     6        h.    d                    mouth
measure 60
E5     4        h     d                    of
E5     2        q     d                    the
measure 61
E5     4        h     d                    Lord
E5     2        q     d                    hath
measure 62
F#5    4        h     d                    spo-
F#5    2        q     d                    ken
measure 63
E5     4        h     d                    it,
rest   2        q
measure 64
rest   6
measure 65
rest   6
measure 66
rest   6
measure 67
rest   6
measure 68
rest   6
measure 69
rest   2        q
B4     2        q     u                    and
E5     2        q     d                    all
measure 70
D#5    1        e     d  [      (          flesh_
C#5    1        e     d  ]                 _
B4     2        q     u         )          _
E5     2        q     d                    shall
measure 71
D#5    1        e     d  [                 see_
C#5    1        e     d  ]                 _
B4     2        q     u                    it
D#5    2        q     d                    to-
measure 72
E5     6        h.    d                    ge-
measure 73
D#5    6        h.    d                    ther.
measure 74
rest   6
measure 75
rest   6
measure 76
rest   2        q
F#4    2        q     u                    And
B4     2        q     u                    the
measure 77
A#4    3        q.    u                    glo-
G#4    1        e     u                    ry,
F#4    2        q     u                    the
measure 78
B4     2        q     u                    glory
E5     2        q     d                    of
C#5    2        q     d                    the
measure 79
D#5    4        h     d                    Lord,
rest   2        q
measure 80
rest   2        q
C#5    2        q     d                    and
D#5    2        q     d                    all
measure 81
C#5    1        e     d  [      (          flesh_
B4     1        e     d  ]                 _
A#4    2        q     u         )          _
B4     2        q     u                    shall
measure 82
C#5    1        e     d  [                 see_
B4     1        e     d  ]                 _
A#4    2        q     u                    it
B4     2        q     u                    to-
measure 83
C#5    2        q     d                    ge-
C#5    2        q     d                    ther,
F#5    2        q     d                    the
measure 84
F#5    6        h.    d                    mouth
measure 85
F#5    4        h     d                    of
F#5    2        q     d                    the
measure 86
F#5    4        h     d                    Lord
E5     2        q     d                    hath
measure 87
D#5    3        q.    d                    spo-
C#5    1        e     d                    ken
B4     2        q     u                    it,
measure 88
rest   6
measure 89
rest   6
measure 90
rest   6
measure 91
rest   6
measure 92
rest   6
measure 93
rest   2        q
B4     2        q     u                    for
B4     2        q     u                    the
measure 94
B4     6        h.    u                    mouth
measure 95
B4     4        h     u                    of
B4     2        q     u                    the
measure 96
B4     4        h     u                    Lord
A4     2        q     u                    hath
measure 97
G#4    4        h     u                    spo-
G#4    2        q     u                    ken
measure 98
F#4    4        h     u                    it,
rest   2        q
measure 99
rest   2        q
E5     2        q     d         (          hath_
F#5    2        q     d         )          _
measure 100
B4     4        h     u                    spo-
E5     2-       q     d        -           -
measure 101
E5     1        e     d  [                 -
F#5    1        e     d  ]                 -
D#5    3        q.    d                    -
D#5    1        e     d                    ken
measure 102
E5     4        h     d                    it,
rest   2        q
measure 103
rest   6
measure 104
rest   6
measure 105
rest   6
measure 106
rest   2        q
E5     2        q     d                    and
E5     2        q     d                    the
measure 107
E5     2        q     d                    glo-
C#5    2        q     d                    ry,
A4     2        q     u                    the
measure 108
E5     3        q.    d                    glo-
D5     1        e     d                    ry,
C#5    2        q     d                    the
measure 109
F#5    2        q     d                    glory
F#5    2        q     d                    of
G#5    2        q     d                    the
measure 110
A5     6        h.    d                    Lord
measure 111
rest   2        q
rest   2        q
E5     2        q     d                    shall
measure 112
D5     3        q.    d                    be
F#5    1        e     d  [                 re-
E5     1        e     d  =                 -
D5     1        e     d  ]                 -
measure 113
C#5    3        q.    d                    vea-
E5     1        e     d  [                 -
D5     1        e     d  =                 -
C#5    1        e     d  ]                 -
measure 114
B4     2        q     u                    -
B4     2        q     u                    led,
rest   2        q
measure 115
rest   6
measure 116
rest   6
measure 117
rest   6
measure 118
rest   6
measure 119
rest   2        q
B4     2        q     u                    and
E5     2        q     d                    all
measure 120
C#5    1        e     d  [      (          flesh_
B4     1        e     d  ]                 _
A4     2        q     u         )          _
C#5    2        q     d                    shall
measure 121
B4     1        e     u  [                 see_
A4     1        e     u  ]                 _
G#4    2        q     u                    it
C#5    2        q     d                    to-
measure 122
B4     1        e     u  [                 ge-
A4     1        e     u  ]                 -
G#4    2        q     u                    ther,
E5     2        q     d                    to-
measure 123
C#5    6        h.    d                    ge-
measure 124
B4     2        q     u                    ther,
E5     2        q     d                    for
E5     2        q     d                    the
measure 125
E5     6        h.    d                    mouth
measure 126
E5     4        h     d                    of
E5     2        q     d                    the
measure 127
E5     3        q.    d         (          Lord_
D5     1        e     d                    _
C#5    2        q     d         )          _
measure 128
D5     2        q     d                    hath
B4     3        q.    u                    spo-
A4     1        e     u                    ken
measure 129
A4     2        q     u                    it,
A4     2        q     u                    for
A4     2        q     u                    the
measure 130
A4     6        h.    u                    mouth
measure 131
A4     6        h.    u                    of
measure 132
A4     6        h.    u                    the
measure 133
A4     6-       h.    u        -           Lord_
measure 134
A4     4        h     u                    _
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
C#5    2        q     d                    hath
measure 136
D5     6-       h.    d        -           spo-
measure 137
D5     4        h     d                    -
D5     2        q     d                    ken
measure 138
C#5    6        h.    d                    it.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/5} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:f9a64d20917612b75b83e1e9a55c1e1f]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:4   D:Allegro
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
rest   6
measure 5
rest   6
measure 6
rest   6
measure 7
rest   6
measure 8
rest   6
measure 9
rest   6
measure 10
rest   6
measure 11
rest   2        q
C#4    2        q     u                    And
A3     2        q     u                    the
measure 12
E4     3        q.    u                    glo-
D4     1        e     u                    ry,
C#4    2        q     u                    the
measure 13
F#4    2        q     u                    glory
F#4    2        q     u                    of
G#4    2        q     u                    the
measure 14
A4     6        h.    u                    Lord,
measure 15
rest   2        q
rest   2        q
A4     2        q     u                    the
measure 16
A4     2        q     u                    glory
A4     2        q     u                    of
E4     2        q     u                    the
measure 17
E4     4        h     u                    Lord
rest   2        q
measure 18
rest   6
measure 19
rest   6
measure 20
rest   6
measure 21
rest   6
measure 22
rest   6
measure 23
rest   6
measure 24
rest   6
measure 25
rest   2        q
rest   2        q
E4     2        q     u                    shall
measure 26
D#4    3        q.    u                    be
F#4    1        e     u  [                 re-
E4     1        e     u  =                 -
D#4    1        e     u  ]                 -
measure 27
C#4    2        q     u                    vea-
A4     4        h     u                    led,
measure 28
G#4    3        q.    u                    be
B4     1        e     u  [                 re-
A4     1        e     u  =                 -
G#4    1        e     u  ]                 -
measure 29
F#4    2        q     u                    vea-
B4     4-       h     u        -           -
measure 30
B4     2        q     u                    -
A4     4-       h     u        -           -
measure 31
A4     2        q     u                    -
G#4    4-       h     u        -           -
measure 32
G#4    2        q     u                    -
F#4    4        h     u                    -
measure 33
B3     2        q     u                    led,
B3     2        q     u                    and
B3     2        q     u                    the
measure 34
B4     3        q.    u                    glo-
B4     1        e     u                    ry,
B4     2        q     u                    the
measure 35
A4     2        q     u                    glory
A4     2        q     u                    of
A4     2        q     u                    the
measure 36
G#4    3        q.    u                    Lord
E4     1        e     u                    shall
F#4    2        q     u                    be
measure 37
G#4    2        q     u                    re-
F#4    4        h     u                    vea-
measure 38
G#4    6        h.    u                    led.
measure 39
rest   6
measure 40
rest   6
measure 41
rest   6
measure 42
rest   6
measure 43
rest   2        q
E4     2        q     u                    And
A4     2        q     u                    all
measure 44
G#4    1        e     u  [      (          flesh_
F#4    1        e     u  ]                 _
E4     2        q     u         )          _
A4     2        q     u                    shall
measure 45
G#4    1        e     u  [                 see_
F#4    1        e     u  ]                 _
E4     2        q     u                    it
A4     2        q     u                    to-
measure 46
G#4    1        e     u  [                 ge-
F#4    1        e     u  ]                 -
E4     2        q     u                    ther,
rest   2        q
measure 47
rest   6
measure 48
rest   6
measure 49
rest   6
measure 50
rest   6
measure 51
rest   6
measure 52
rest   6
measure 53
rest   2        q
C#4    2        q     u                    and
F#4    2        q     u                    all
measure 54
E4     1        e     u  [      (          flesh_
D4     1        e     u  ]                 _
C#4    2        q     u         )          _
F#4    2        q     u                    shall
measure 55
E4     1        e     u  [                 see_
D4     1        e     u  ]                 _
C#4    2        q     u                    it
A4     2        q     u                    to-
measure 56
A4     2        q     u         (          ge-
G#4    4        h     u         )          -
measure 57
A4     6        h.    u                    ther,
measure 58
rest   6
measure 59
rest   2        q
G#4    2        q     u                    and
A4     2        q     u                    all
measure 60
E4     4        h     u                    flesh
E4     2        q     u                    shall
measure 61
B4     2        q     u                    see
B4     2        q     u                    it
A4     2        q     u                    to-
measure 62
A4     6        h.    u                    ge-
measure 63
A4     2        q     u                    ther,
E4     2        q     u                    and
A4     2        q     u                    all
measure 64
G#4    1        e     u  [      (          flesh,_
F#4    1        e     u  ]                 _
E4     2        q     u         )          _
rest   2        q
measure 65
rest   2        q
F#4    2        q     u                    and
B4     2        q     u                    all
measure 66
A4     1        e     u  [      (          flesh_
G#4    1        e     u  ]                 _
F#4    2        q     u         )          _
F#4    2        q     u                    shall
measure 67
G#4    2        q     u                    see
G#4    2        q     u                    it
A#4    2        q     u                    to-
measure 68
B4     4        h     u                    ge-
F#4    2        q     u                    ther,
measure 69
rest   2        q
D#4    2        q     u                    and
G#4    2        q     u                    all
measure 70
F#4    1        e     u  [      (          flesh_
E4     1        e     u  ]                 _
D#4    2        q     u         )          _
G#4    2        q     u                    shall
measure 71
F#4    1        e     u  [                 see_
E4     1        e     u  ]                 _
D#4    2        q     u                    it
B4     2        q     u                    to-
measure 72
B4     4        h     u         (          ge-
A#4    2        q     u         )          -
measure 73
B4     6        h.    u                    ther.
measure 74
rest   6
measure 75
rest   6
measure 76
rest   2        q
F#4    2        q     u                    And
F#4    2        q     u                    the
measure 77
F#4    3        q.    u                    glo-
F#4    1        e     u                    ry,
B3     2        q     u                    the
measure 78
E4     2        q     u                    glory
E4     2        q     u                    of
F#4    2        q     u                    the
measure 79
F#4    2        q     u                    Lord,
F#4    2        q     u                    and
B4     2        q     u                    all
measure 80
A#4    1        e     u  [      (          flesh_
G#4    1        e     u  ]                 _
F#4    2        q     u         )          _
F#4    2        q     u                    shall
measure 81
F#4    6        h.    u                    see
measure 82
F#4    4        h     u                    it
F#4    2        q     u                    to-
measure 83
F#4    2        q     u                    ge-
F#4    2        q     u                    ther,
rest   2        q
measure 84
rest   2        q
D#4    2        q     u                    and
B3     2        q     u                    the
measure 85
F#4    3        q.    u                    glo-
E4     1        e     u                    ry,
D#4    2        q     u                    the
measure 86
G#4    2        q     u                    glory
G#4    2        q     u                    of
A#4    2        q     u                    the
measure 87
B4     4        h     u                    Lord
F#4    2        q     u                    shall
measure 88
E4     3        q.    u                    be
G#4    1        e     u  [                 re-
F#4    1        e     u  =                 -
E4     1        e     u  ]                 -
measure 89
D#4    1        e     u  [                 vea-
C#4    1        e     u  ]                 -
B3     2        q     u                    led,
rest   2        q
measure 90
rest   6
measure 91
rest   2        q
B3     2        q     u                    and
E4     2        q     u                    all
measure 92
D#4    1        e     u  [      (          flesh_
C#4    1        e     u  ]                 _
B3     2        q     u         )          _
D#4    2        q     u                    shall
measure 93
E4     2        q     u                    see
F#4    3        q.    u                    it
F#4    1        e     u                    to-
measure 94
B3     2        q     u                    ge-
B3     2        q     u                    ther,
rest   2        q
measure 95
rest   6
measure 96
rest   2        q
B4     2        q     u                    for
B4     2        q     u                    the
measure 97
B4     6        h.    u                    mouth
measure 98
B4     4        h     u                    of
B4     2        q     u                    the
measure 99
B4     2        q     u                    Lord_
A4     4-       h     u        -           _
measure 100
A4     4        h     u                    _
G#4    2        q     u                    _
measure 101
F#4    2        q     u                    hath
F#4    3        q.    u                    spo-
F#4    1        e     u                    ken
measure 102
G#4    2        q     u                    it,
E4     2        q     u                    and
A4     2        q     u                    all
measure 103
G#4    1        e     u  [      (          flesh_
F#4    1        e     u  ]                 _
E4     2        q     u         )          _
rest   2        q
measure 104
rest   6
measure 105
rest   2        q
rest   2        q
G#4    2        q     u                    shall
measure 106
A4     2        q     u                    see
B4     3        q.    u                    it
B4     1        e     u                    to-
measure 107
E4     2        q     u                    ge-
E4     2        q     u                    ther,
rest   2        q
measure 108
rest   6
measure 109
rest   6
measure 110
rest   2        q
E4     2        q     u                    and
A4     2        q     u                    the
measure 111
G#4    3        q.    u                    glo-
F#4    1        e     u                    ry,
E4     2        q     u                    the
measure 112
A4     2        q     u                    glory
A4     2        q     u                    of
E4     2        q     u                    the
measure 113
E4     4        h     u                    Lord
A4     2        q     u                    shall
measure 114
G#4    3        q.    u                    be
B4     1        e     u  [                 re-
A4     1        e     u  =                 -
G#4    1        e     u  ]                 -
measure 115
F#4    3        q.    u                    vea-
A4     1        e     u  [                 -
G#4    1        e     u  =                 -
F#4    1        e     u  ]                 -
measure 116
E4     2        q     u                    -
E4     2        q     u                    led,
A4     2        q     u                    re-
measure 117
G#4    2        q     u                    vea-
G#4    2        q     u                    led,
rest   2        q
measure 118
rest   2        q
E4     2        q     u                    and
A4     2        q     u                    all
measure 119
G#4    1        e     u  [      (          flesh_
F#4    1        e     u  ]                 _
E4     2        q     u         )          _
rest   2        q
measure 120
rest   2        q
rest   2        q
A4     2        q     u                    shall
measure 121
G#4    1        e     u  [                 see_
F#4    1        e     u  ]                 _
E4     2        q     u                    it
A4     2        q     u                    to-
measure 122
G#4    1        e     u  [                 ge-
F#4    1        e     u  ]                 -
E4     2        q     u                    ther,
B4     2        q     u                    to-
measure 123
A4     6        h.    u                    ge-
measure 124
G#4    6        h.    u                    ther,
measure 125
rest   2        q
G#4    2        q     u                    for
A4     2        q     u                    the
measure 126
E4     2        q     u                    mouth
B3     2        q     u                    of
E4     2        q     u                    the
measure 127
A4     6        h.    u                    Lord
measure 128
A4     2        q     u                    hath
G#4    3        q.    u                    spo-
A4     1        e     u                    ken
measure 129
A4     2        q     u                    it,
A4     2        q     u                    for
A4     2        q     u                    the
measure 130
A4     6        h.    u                    mouth
measure 131
A4     6        h.    u                    of
measure 132
A4     6        h.    u                    the
measure 133
A4     6-       h.    u        -           Lord_
measure 134
A4     4        h     u                    _
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
A4     2        q     u                    hath
measure 136
A4     6-       h.    u        -           spo-
measure 137
A4     4        h     u                    -
A4     2        q     u                    ken
measure 138
A4     6        h.    u                    it.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/6} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:53764ccd44ca9306ba82170af4582e0a]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:34   D:Allegro
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
rest   6
measure 5
rest   6
measure 6
rest   6
measure 7
rest   6
measure 8
rest   6
measure 9
rest   6
measure 10
rest   6
measure 11
rest   6
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
E4     2        q     d                    And
E4     2        q     d                    the
measure 15
G#3    3        q.    u                    glo-
G#3    1        e     u                    ry,
A3     2        q     u                    the
measure 16
A3     2        q     u                    glory
A3     2        q     u                    of
B3     2        q     u                    the
measure 17
C#4    4        h     d                    Lord
E4     2        q     d                    shall
measure 18
D4     3        q.    d                    be
F#4    1        e     d  [                 re-
E4     1        e     d  =                 -
D4     1        e     d  ]                 -
measure 19
C#4    3        q.    d                    vea-
E4     1        e     d  [                 -
D4     1        e     d  =                 -
C#4    1        e     d  ]                 -
measure 20
B3     2        q     d                    -
B3     2        q     d                    led,
rest   2        q
measure 21
rest   6
measure 22
rest   2        q
G#3    2        q     u                    and
E3     2        q     u                    the
measure 23
B3     3        q.    u                    glo-
A3     1        e     u                    ry,
G#3    2        q     u                    the
measure 24
C#4    2        q     d                    glory
C#4    2        q     d                    of
D#4    2        q     d                    the
measure 25
E4     6        h.    d                    Lord
measure 26
rest   6
measure 27
rest   6
measure 28
rest   2        q
rest   2        q
E4     2        q     d                    shall
measure 29
D#4    3        q.    d                    be
F#4    1        e     d  [                 re-
E4     1        e     d  =                 -
D#4    1        e     d  ]                 -
measure 30
C#4    3        q.    d                    vea-
E4     1        e     d  [                 -
D#4    1        e     d  =                 -
C#4    1        e     d  ]                 -
measure 31
B3     2        q     d                    -
B3     2        q     d                    led,
rest   2        q
measure 32
rest   6
measure 33
rest   2        q
E4     2        q     d                    and
G#4    2        q     d                    the
measure 34
F#4    3        q.    d                    glo-
F#4    1        e     d                    ry,
E4     2        q     d                    the
measure 35
E4     2        q     d                    glory
E4     2        q     d                    of
F#4    2        q     d                    the
measure 36
E4     3        q.    d                    Lord
B3     1        e     u                    shall
A3     2        q     u                    be
measure 37
B3     2        q     u                    re-
B3     4        h     u                    vea-
measure 38
B3     6        h.    u                    led.
measure 39
rest   6
measure 40
rest   6
measure 41
rest   6
measure 42
rest   6
measure 43
rest   6
measure 44
rest   6
measure 45
rest   6
measure 46
rest   6
measure 47
rest   2        q
A3     2        q     u                    And
D4     2        q     d                    all
measure 48
C#4    1        e     d  [      (          flesh_
B3     1        e     d  ]                 _
A3     2        q     u         )          _
D4     2        q     d                    shall
measure 49
C#4    1        e     d  [                 see_
B3     1        e     d  ]                 _
A3     2        q     u                    it
D4     2        q     d                    to-
measure 50
C#4    1        e     d  [                 ge-
B3     1        e     d  ]                 -
A3     2        q     u                    ther,
rest   2        q
measure 51
A3     6        h.    u                    for
measure 52
A3     6        h.    u                    the
measure 53
A3     6        h.    u                    mouth
measure 54
A3     4        h     u                    of
A3     2        q     u                    the
measure 55
A3     4        h     u                    Lord
A3     2        q     u                    hath
measure 56
F#4    2        q     d                    spo-
D4     4        h     d                    ken
measure 57
E4     6        h.    d                    it,
measure 58
rest   6
measure 59
rest   2        q
B3     2        q     d                    and
C#4    2        q     d                    all
measure 60
B3     1        e     u  [      (          flesh_
A3     1        e     u  ]                 _
G#3    2        q     u         )          _
C#4    2        q     d                    shall
measure 61
B3     1        e     u  [                 see_
A3     1        e     u  ]                 _
G#3    2        q     u                    it
C#4    2        q     d                    to-
measure 62
D4     6        h.    d                    ge-
measure 63
C#4    4        h     d                    ther,
rest   2        q
measure 64
rest   2        q
B3     2        q     d                    and
E4     2        q     d                    all
measure 65
D#4    1        e     d  [      (          flesh_
C#4    1        e     d  ]                 _
B3     2        q     d         )          _
B3     2        q     d                    shall
measure 66
C#4    2        q     d                    see
C#4    2        q     d                    it
D#4    2        q     d                    to-
measure 67
E4     6        h.    d                    ge-
measure 68
D#4    4        h     d                    ther,
B3     2        q     d                    the
measure 69
B3     6        h.    d                    mouth
measure 70
B3     4        h     d                    of
B3     2        q     d                    the
measure 71
B3     4        h     d                    Lord
F#4    2        q     d                    hath
measure 72
E4     4        h     d                    spo-
E4     2        q     d                    ken
measure 73
F#4    6        h.    d                    it.
measure 74
rest   6
measure 75
rest   6
measure 76
rest   2        q
B3     2        q     d                    And
D#4    2        q     d                    the
measure 77
C#4    3        q.    d                    glo-
C#4    1        e     d                    ry,
D#4    2        q     d                    the
measure 78
E4     2        q     d                    glory
B3     2        q     d                    of
C#4    2        q     d                    the
measure 79
B3     2        q     d                    Lord,
B3     2        q     d                    and
D#4    2        q     d                    all
measure 80
C#4    1        e     d  [      (          flesh_
B3     1        e     d  ]                 _
A#3    2        q     u         )          _
B3     2        q     d                    shall
measure 81
C#4    2        q     d                    see
C#4    2        q     d                    it,
D#4    2        q     d                    shall
measure 82
C#4    2        q     d                    see
C#4    2        q     d                    it
D#4    2        q     d                    to-
measure 83
C#4    2        q     d                    ge-
A#3    2        q     u                    ther,
rest   2        q
measure 84
rest   6
measure 85
rest   6
measure 86
rest   6
measure 87
rest   6
measure 88
rest   6
measure 89
rest   2        q
B3     2        q     d                    and
E4     2        q     d                    all
measure 90
D#4    1        e     d  [      (          flesh_
C#4    1        e     d  ]                 _
B3     2        q     d         )          _
rest   2        q
measure 91
rest   6
measure 92
rest   2        q
rest   2        q
B3     2        q     u                    shall
measure 93
B3     2        q     u                    see
A3     3        q.    u                    it
A3     1        e     u                    to-
measure 94
G#3    2        q     u                    ge-
G#3    2        q     u                    ther,
E3     2        q     u                    the
measure 95
B3     3        q.    u                    glo-
A3     1        e     u                    ry,
G#3    2        q     u                    the
measure 96
C#4    2        q     d                    glory
D#4    3        q.    d                    of
D#4    1        e     d                    the
measure 97
E4     4        h     d                    Lord
E4     2        q     d                    shall
measure 98
D#4    3        q.    d                    be
F#4    1        e     d  [                 re-
E4     1        e     d  =                 -
D#4    1        e     d  ]                 -
measure 99
C#4    3        q.    d                    vea-
E4     1        e     d  [                 -
D#4    1        e     d  =                 -
C#4    1        e     d  ]                 -
measure 100
B3     6        h.    d                    -
measure 101
C#4    2        q     d                    -
B3     4        h     d                    -
measure 102
B3     2        q     d                    led,
rest   2        q
rest   2        q
measure 103
rest   2        q
B3     2        q     d                    and
E4     2        q     d                    all
measure 104
C#4    1        e     d  [      (          flesh_
B3     1        e     d  ]                 _
A3     2        q     u         )          _
rest   2        q
measure 105
rest   2        q
rest   2        q
E4     2        q     d                    shall
measure 106
E4     1        e     d  [                 see_
D4     1        e     d  ]                 _
D4     3        q.    d                    it
D4     1        e     d                    to-
measure 107
C#4    2        q     d                    ge-
C#4    2        q     d                    ther,
rest   2        q
measure 108
rest   6
measure 109
rest   6
measure 110
rest   2        q
A3     2        q     u                    and
C#4    2        q     d                    the
measure 111
B3     3        q.    d                    glo-
B3     1        e     d                    ry,
C#4    2        q     d                    the
measure 112
D4     2        q     d                    glory
D4     2        q     d                    of
B3     2        q     d                    the
measure 113
C#4    4        h     d                    Lord
rest   2        q
measure 114
rest   6
measure 115
rest   6
measure 116
rest   2        q
rest   2        q
E4     2        q     d                    shall
measure 117
D4     3        q.    d                    be
F#4    1        e     d  [                 re-
E4     1        e     d  =                 -
D4     1        e     d  ]                 -
measure 118
C#4    3        q.    d                    vea-
E4     1        e     d  [                 -
D4     1        e     d  =                 -
C#4    1        e     d  ]                 -
measure 119
B3     2        q     d                    led,
G#3    2        q     u                    and
G#3    2        q     u                    all
measure 120
E4     1        e     d  [      (          flesh_
D4     1        e     d  ]                 _
C#4    2        q     d         )          _
C#4    2        q     d                    shall
measure 121
E4     2        q     d                    see
B3     2        q     d                    it
E4     2        q     d                    to-
measure 122
E4     2        q     d                    ge-
B3     2        q     d                    ther,
B3     2        q     d                    to-
measure 123
E4     6        h.    d                    ge-
measure 124
E4     6        h.    d                    ther,
measure 125
rest   2        q
B3     2        q     d                    for
C#4    2        q     d                    the
measure 126
B3     2        q     u                    mouth
G#3    2        q     u                    of
B3     2        q     u                    the
measure 127
C#4    3        q.    d         (          Lord_
D4     1        e     d                    _
E4     2        q     d         )          _
measure 128
F#4    2        q     d                    hath
B3     2        q     d                    spo-
E4     2        q     d                    ken
measure 129
C#4    4        h     d                    it,
rest   2        q
measure 130
rest   2        q
C#4    2        q     d                    for
F#4    2        q     d                    the
measure 131
E4     2        q     d                    mouth
C#4    2        q     d                    of
F#4    2        q     d                    the
measure 132
E4     1        e     d  [      (          Lord,_
D4     1        e     d  ]                 _
C#4    2        q     d         )          _
F#4    2        q     d                    the
measure 133
E4     2        q     d                    mouth
C#4    2        q     d                    of
F#4    2        q     d                    the
measure 134
E4     1        e     d  [      (          Lord_
D4     1        e     d  ]                 _
C#4    2        q     d         )          _
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
E4     2        q     d                    hath
measure 136
F#4    6-       h.    d        -           spo-
measure 137
F#4    4        h     d                    -
F#4    2        q     d                    ken
measure 138
E4     6        h.    d                    it.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/7} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:93cedce19dc26923319560a51e17345a]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:22   D:Allegro
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
rest   6
measure 5
rest   6
measure 6
rest   6
measure 7
rest   6
measure 8
rest   6
measure 9
rest   6
measure 10
rest   6
measure 11
rest   6
measure 12
rest   6
measure 13
rest   6
measure 14
rest   2        q
C#3    2        q     u                    And
A2     2        q     u                    the
measure 15
E3     3        q.    d                    glo-
D3     1        e     u                    ry,
C#3    2        q     u                    the
measure 16
F#3    2        q     d                    glory
F#3    2        q     d                    of
G#3    2        q     d                    the
measure 17
A3     4        h     d                    Lord
rest   2        q
measure 18
rest   6
measure 19
rest   2        q
rest   2        q
A3     2        q     d                    shall
measure 20
G#3    3        q.    d                    be
B3     1        e     d  [                 re-
A3     1        e     d  =                 -
G#3    1        e     d  ]                 -
measure 21
F#3    3        q.    d                    vea-
A3     1        e     d  [                 -
G#3    1        e     d  =                 -
F#3    1        e     d  ]                 -
measure 22
E3     2        q     d                    -
E3     2        q     d                    led,
rest   2        q
measure 23
rest   2        q
rest   2        q
B3     2        q     d                    shall
measure 24
A3     3        q.    d                    be
C#4    1        e     d  [                 re-
B3     1        e     d  =                 -
A3     1        e     d  ]                 -
measure 25
G#3    2        q     d                    vea-
E3     2        q     d                    led,
rest   2        q
measure 26
rest   6
measure 27
rest   6
measure 28
rest   6
measure 29
rest   6
measure 30
rest   6
measure 31
rest   6
measure 32
rest   6
measure 33
rest   2        q
G#3    2        q     d                    and
E3     2        q     d                    the
measure 34
B3     3        q.    d                    glo-
A3     1        e     d                    ry,
G#3    2        q     d                    the
measure 35
C#4    2        q     d                    glory
C#4    2        q     d                    of
D#4    2        q     d                    the
measure 36
E4     3        q.    d                    Lord
G#3    1        e     d                    shall
F#3    2        q     d                    be
measure 37
E3     2        q     d                    re-
B3     4        h     d                    vea-
measure 38
E3     6        h.    d                    led.
measure 39
rest   6
measure 40
rest   6
measure 41
rest   6
measure 42
rest   6
measure 43
rest   6
measure 44
rest   6
measure 45
rest   6
measure 46
rest   6
measure 47
rest   6
measure 48
rest   6
measure 49
rest   6
measure 50
rest   6
measure 51
A3     6        h.    d                    for
measure 52
A3     6        h.    d                    the
measure 53
A3     6        h.    d                    mouth
measure 54
A3     4        h     d                    of
A3     2        q     d                    the
measure 55
A3     4        h     d                    Lord
A3     2        q     d                    hath
measure 56
B3     4        h     d                    spo-
B3     2        q     d                    ken
measure 57
A3     6        h.    d                    it,
measure 58
rest   6
measure 59
rest   2        q
E3     2        q     d                    and
A3     2        q     d                    all
measure 60
G#3    1        e     d  [      (          flesh_
F#3    1        e     d  ]                 _
E3     2        q     d         )          _
A3     2        q     d                    shall
measure 61
G#3    1        e     d  [                 see_
F#3    1        e     d  ]                 _
E3     2        q     d                    it
A3     2        q     d                    to-
measure 62
D4     6        h.    d                    ge-
measure 63
A3     4        h     d                    ther,
rest   2        q
measure 64
rest   6
measure 65
rest   6
measure 66
rest   6
measure 67
rest   6
measure 68
B3     4        h     d                    for
B3     2        q     d                    the
measure 69
B3     6        h.    d                    mouth
measure 70
B3     4        h     d                    of
B3     2        q     d                    the
measure 71
B3     4        h     d                    Lord
B3     2        q     d                    hath
measure 72
C#4    4        h     d                    spo-
C#4    2        q     d                    ken
measure 73
B3     6        h.    d                    it.
measure 74
rest   6
measure 75
rest   6
measure 76
rest   2        q
D#3    2        q     u                    And
B2     2        q     u                    the
measure 77
F#3    3        q.    d                    glo-
E3     1        e     d                    ry,
D#3    2        q     u                    the
measure 78
G#3    2        q     d                    glory
G#3    2        q     d                    of
A#3    2        q     d                    the
measure 79
B3     4        h     d                    Lord,
rest   2        q
measure 80
rest   2        q
F#3    2        q     d                    and
B3     2        q     d                    all
measure 81
A#3    1        e     d  [      (          flesh_
G#3    1        e     d  ]                 _
F#3    2        q     d         )          _
B3     2        q     d                    shall
measure 82
A#3    1        e     d  [                 see_
G#3    1        e     d  ]                 _
F#3    2        q     d                    it
B3     2        q     d                    to-
measure 83
A#3    2        q     d                    ge-
F#3    2        q     d                    ther,
rest   2        q
measure 84
rest   6
measure 85
rest   6
measure 86
rest   6
measure 87
rest   6
measure 88
rest   6
measure 89
rest   6
measure 90
rest   2        q
B2     2        q     u                    and
E3     2        q     d                    all
measure 91
D#3    1        e     u  [      (          flesh_
C#3    1        e     u  ]                 _
B2     2        q     u         )          _
rest   2        q
measure 92
rest   2        q
rest   2        q
B2     2        q     u                    shall
measure 93
C#3    2        q     u                    see
D#3    3        q.    u                    it
D#3    1        e     u                    to-
measure 94
E3     2        q     d                    ge-
E3     2        q     d                    ther,
rest   2        q
measure 95
rest   6
measure 96
rest   6
measure 97
rest   2        q
G#3    2        q     d                    and
E3     2        q     d                    the
measure 98
B2     3        q.    u                    glo-
A2     1        e     u                    ry,
G#2    2        q     u                    the
measure 99
C#3    2        q     u                    glory
C#3    2        q     u                    of
D#3    2        q     u                    the
measure 100
E3     3        q.    d                    Lord
F#3    1        e     d                    shall
G#3    2        q     d                    be
measure 101
A3     2        q     d                    re-
B3     2        q     d         (          vea-
B2     2        q     u         )          -
measure 102
E3     4        h     d                    led,
rest   2        q
measure 103
rest   6
measure 104
rest   2        q
E3     2        q     d                    and
A3     2        q     d                    all
measure 105
G#3    1        e     d  [      (          flesh_
F#3    1        e     d  ]                 _
E3     2        q     d         )          _
E3     2        q     d                    shall
measure 106
F#3    2        q     d                    see
G#3    3        q.    d                    it
G#3    1        e     d                    to-
measure 107
A3     2        q     d                    ge-
A3     2        q     d                    ther,
rest   2        q
measure 108
rest   6
measure 109
rest   6
measure 110
rest   2        q
C#3    2        q     u                    and
A2     2        q     u                    the
measure 111
E3     3        q.    d                    glo-
D3     1        e     u                    ry,
C#3    2        q     u                    the
measure 112
F#3    2        q     d                    glory
F#3    2        q     d                    of
G#3    2        q     d                    the
measure 113
A3     4        h     d                    Lord
rest   2        q
measure 114
rest   2        q
rest   2        q
E3     2        q     d                    shall
measure 115
D3     3        q.    u                    be
F#3    1        e     d  [                 re-
E3     1        e     d  =                 -
D3     1        e     d  ]                 -
measure 116
C#3    3        q.    u                    vea-
E3     1        e     u  [                 -
D3     1        e     u  =                 -
C#3    1        e     u  ]                 -
measure 117
B2     2        q     u                    -
B2     2        q     u                    led,
E3     2        q     d                    re-
measure 118
A3     6        h.    d                    vea-
measure 119
E3     2        q     d                    led,
E3     2        q     d                    for
E3     2        q     d                    the
measure 120
E3     6        h.    d                    mouth
measure 121
E3     4        h     d                    of
E3     2        q     d                    the
measure 122
E3     4        h     d                    Lord
G#3    2        q     d                    hath
measure 123
A3     4        h     d                    spo-
A3     2        q     d                    ken
measure 124
E3     6        h.    d                    it,
measure 125
rest   2        q
E3     2        q     d                    for
A3     2        q     d                    the
measure 126
G#3    2        q     d                    mouth
E3     2        q     d                    of
G#3    2        q     d                    the
measure 127
A3     6        h.    d                    Lord
measure 128
D3     2        q     u                    hath
E3     3        q.    d                    spo-
E3     1        e     d                    ken
measure 129
A2     4        h     u                    it,
rest   2        q
measure 130
rest   2        q
A3     2        q     d                    for
D4     2        q     d                    the
measure 131
C#4    2        q     d                    mouth
A3     2        q     d                    of
D4     2        q     d                    the
measure 132
C#4    1        e     d  [      (          Lord,_
B3     1        e     d  ]                 _
A3     2        q     d         )          _
D4     2        q     d                    the
measure 133
C#4    2        q     d                    mouth
A3     2        q     d                    of
D4     2        q     d                    the
measure 134
C#4    1        e     d  [      (          Lord_
B3     1        e     d  ]                 _
A3     2        q     d         )          _
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
A3     2        q     d                    hath
measure 136
D4     6-       h.    d        -           spo-
measure 137
D4     4        h     d                    -
D3     2        q     u                    ken
measure 138
A3     6        h.    d                    it.
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-04/8} [KHM:282553498]
TIMESTAMP: DEC/26/2001 [md5sum:6a9e08e1d61f6bfef89bd9a747e21a0c]
04/04/90 E. Correia
WK#:56        MV#:1,4
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:3   Q:2   T:3/4   C:22   D:Allegro
A2     4        h     u
A3     2        q     d
measure 2
G#3    2        q     d
E3     2        q     d
A3     2        q     d
measure 3
D4     2        q     d
B3     2        q     d
E4     2        q     d
measure 4
C#4    2        q     d
A3     2        q     d
C#4    2        q     d
measure 5
F#3    2        q     d
G#3    2        q     d
E3     2        q     d
measure 6
A3     2        q     d
A2     2        q     u
C#3    2        q     u
measure 7
E3     4        h     d
C#4    2        q     d
measure 8
A3     2        q     d
F#3    2        q     d
B3     2        q     d
measure 9
G#3    2        q     d
E3     2        q     d
F#3    2        q     d
measure 10
D3     2        q     u
E3     2        q     d
E2     2        q     u
measure 11
A2     4        h     u
rest   2        q
measure 12
rest   2        q
f1              6
C#3    2        q     u
A2     2        q     u
measure 13
D3     2        q     u
B2     2        q     u
E3     2        q     d
measure 14
A2     2        q     u
C#3    2        q     u
A2     2        q     u
measure 15
E3     3        q.    d
D3     1        e     u
C#3    2        q     u
measure 16
F#3    2        q     d
F#3    2        q     d
G#3    2        q     d
measure 17
A3     2        q     d
A2     2        q     u
C#3    2        q     u
measure 18
F#3    2        q     d
F#2    2        q     u
G#2    2        q     u
measure 19
A2     2        q     u
C#3    2        q     u
A2     2        q     u
measure 20
E3     2        q     d
G#3    2        q     d
E3     2        q     d
measure 21
F#3    2        q     d
D#3    4        h     u
measure 22
E3     4        h     d
E3     2        q     d
measure 23
D#3    2        q     u
B2     2        q     u
E3     2        q     d
measure 24
A2     2        q     u
F#2    2        q     u
B2     2        q     u
measure 25
E3     2        q     d
E2     2        q     u
C#3    2        q     u
measure 26
D#3    2        q     u
B2     2        q     u
E3     2        q     d
measure 27
A2     2        q     u
F#2    2        q     u
B2     2        q     u
measure 28
E2     2        q     u
E3     2        q     d
G#3    2        q     d
measure 29
B3     4        h     d
G#3    2        q     d
measure 30
E3     2        q     d
F#3    2        q     d
E3     2        q     d
measure 31
D#3    2        q     u
E3     2        q     d
B2     2        q     u
measure 32
C#3    2        q     u
D#3    4        h     u
measure 33
E3     2        q     d
G#3    2        q     d
E3     2        q     d
measure 34
B3     3        q.    d
A3     1        e     d
G#3    2        q     d
measure 35
C#4    2        q     d
C#3    2        q     u
D#3    2        q     u
measure 36
E3     3        q.    d
G#2    1        e     u
F#2    2        q     u
measure 37
E2     2        q     u
B2     4        h     u
measure 38
E2     2        q     u
E3     2        q     d
G#3    2        q     d
measure 39
B3     2        q     d
B2     2        q     u
B3     2        q     d
measure 40
C#4    2        q     d
F#3    2        q     d
E3     2        q     d
measure 41
D#3    2        q     u
B2     2        q     u
C#3    2        q     u
measure 42
A2     2        q     u
B2     4        h     u
measure 43
E3     2        q     d
C#3    2        q     u
A2     2        q     u
measure 44
E3     2        q     d
C#3    2        q     u
A2     2        q     u
measure 45
E3     2        q     d
C#4    2        q     d
A3     2        q     d
measure 46
E4     2        q     d
G#3    2        q     d
E3     2        q     d
measure 47
A3     4        h     d
G#3    2        q     d
measure 48
A3     2        q     d
F#3    2        q     d
D3     2        q     u
measure 49
A3     2        q     d
F#3    2        q     d
D3     2        q     u
measure 50
A3     2        q     d
F#3    2        q     d
D3     2        q     u
measure 51
A3     6        h.    d
measure 52
A3     6        h.    d
measure 53
A3     6        h.    d
measure 54
A3     4        h     d
A3     2        q     d
measure 55
A3     4        h     d
A3     2        q     d
measure 56
B3     4        h     d
B3     2        q     d
measure 57
A3     6        h.    d
measure 58
rest   6
measure 59
rest   2        q
E3     2        q     d
A3     2        q     d
measure 60
G#3    1        e     d  [
F#3    1        e     d  ]
E3     2        q     d
A3     2        q     d
measure 61
G#3    1        e     d  [
F#3    1        e     d  ]
E3     2        q     d
A3     2        q     d
measure 62
D3     1        e     d  [
C#3    1        e     d  =
D3     1        e     d  =
E3     1        e     d  =
F#3    1        e     d  =
G#3    1        e     d  ]
measure 63
A3     2        q     d
C#3    2        q     u
A2     2        q     u
measure 64
E3     2        q     d
G#3    2        q     d
E3     2        q     d
measure 65
B3     2        q     d
A3     2        q     d
G#3    2        q     d
measure 66
F#3    2        q     d
A3     2        q     d
B3     2        q     d
measure 67
E3     2        q     d
D#3    2        q     u
C#3    2        q     u
measure 68
B2     4        h     u
B2     2        q     u
measure 69
B3     6        h.    d
measure 70
B3     4        h     d
B3     2        q     d
measure 71
B3     4        h     d
B3     2        q     d
measure 72
C#4    4        h     d
C#4    2        q     d
measure 73
B3     6        h.    d
measure 74
rest   2        q
B3     2        q     d
D#4    2        q     d
measure 75
E4     2        q     d
D#4    2        q     d
f1              6+
C#4    2        q     d
measure 76
B3     2        q     d
D#3    2        q     u
B2     2        q     u
measure 77
F#3    3        q.    d
E3     1        e     d
D#3    2        q     u
measure 78
G#3    2        q     d
G#3    2        q     d
A#3    2        q     d
measure 79
B3     2        q     d
D#3    2        q     u
B2     2        q     u
measure 80
F#3    2        q     d
F#3    2        q     d
B2     2        q     u
measure 81
F#3    4        h     d
B3     2        q     d
measure 82
A#3    1        e     d  [
G#3    1        e     d  ]
F#3    2        q     d
B3     2        q     d
measure 83
f1              6
A#3    2        q     d
f1              #
F#3    2        q     d
rest   2        q
$ C:13
measure 84
rest   2        q
f1              6
D#4    2        q     d
B3     2        q     u
measure 85
F#4    3        q.    d
E4     1        e     d
f1              6
D#4    2        q     d
measure 86
G#4    2        q     d
G#4    2        q     d
A#4    2        q     d
measure 87
B4     2        q     d
B3     2        q     u
F#4    2        q     u
measure 88
E4     3        q.    u
G#4    1        e     u  [
F#4    1        e     u  =
E4     1        e     u  ]
measure 89
D#4    2        q     u
&
This data was in the original part, but
  is not reflected in the score printed
  by CCARH
D#4    2        q     d
measure 88
C#4    2        q     d
G#3    2        q     d
A#3    2        q     d
measure 89
B3     2        q     d
&
$ C:22   q
f1              6
G#3    2        q     d
E3     2        q     d
measure 90
B3     2        q     d
B2     2        q     u
E3     2        q     d
measure 91
D#3    2        q     u
B2     2        q     u
G#3    2        q     d
measure 92
B3     4        h     d
B2     2        q     u
measure 93
C#3    2        q     u
D#3    3        q.    u
D#3    1        e     u
measure 94
E3     2        q     d
G#3    2        q     d
E3     2        q     d
$ C:12
measure 95
B3     3        q.    d
A3     1        e     u
G#3    2        q     u
measure 96
C#4    2        q     d
D#4    3        q.    d
D#4    1        e     d
measure 97
E4     2        q     d
$ C:22
G#2    2        q     u
E2     2        q     u
measure 98
B2     3        q.    u
A2     1        e     u
G#2    2        q     u
measure 99
C#3    2        q     u
C#3    2        q     u
D#3    2        q     u
measure 100
E3     3        q.    d
F#3    1        e     d
G#3    2        q     d
measure 101
A3     2        q     d
B3     2        q     d
B2     2        q     u
measure 102
E3     2        q     d
C#3    2        q     u
A2     2        q     u
measure 103
E3     2        q     d
G#3    2        q     d
E3     2        q     d
measure 104
A3     2        q     d
C#3    2        q     u
A2     2        q     u
measure 105
E3     4        h     d
E3     2        q     d
measure 106
F#3    2        q     d
G#3    4        h     d
measure 107
A3     2        q     d
A2     2        q     u
$ C:15
A4     2        q     d
measure 108
E5     3        q.    d
D5     1        e     d
C#5    2        q     d
measure 109
F#5    2        q     d
F#5    2        q     d
G#5    2        q     d
measure 110
A5     2        q     d
$ C:22
C#3    2        q     u
A2     2        q     u
measure 111
E3     3        q.    d
D3     1        e     u
C#3    2        q     u
measure 112
F#3    2        q     d
F#3    2        q     d
G#3    2        q     d
measure 113
A3     4        h     d
A2     2        q     u
measure 114
E3     2        q     d
E2     2        q     u
E3     2        q     d
measure 115
D3     3        q.    u
F#3    1        e     d  [
E3     1        e     d  =
D3     1        e     d  ]
measure 116
C#3    3        q.    u
E3     1        e     d  [
D3     1        e     d  =
C#3    1        e     d  ]
measure 117
B2     2        q     u
B2     2        q     u
E3     2        q     d
measure 118
A3     4        h     d
A2     2        q     u
measure 119
E3     2        q     d
E3     2        q     d
E3     2        q     d
measure 120
E3     6        h.    d
measure 121
E3     4        h     d
E3     2        q     d
measure 122
E3     4        h     d
G#3    2        q     d
measure 123
A3     4        h     d
A2     2        q     u
measure 124
E3     4        h     d
rest   2        q
measure 125
rest   2        q
E3     2        q     d
A3     2        q     d
measure 126
G#3    2        q     d
E3     2        q     d
G#3    2        q     d
measure 127
A3     6        h.    d
measure 128
D3     2        q     u
E3     2        q     d
E2     2        q     u
measure 129
A2     4        h     u
rest   2        q
measure 130
rest   2        q
A3     2        q     d
D4     2        q     d
measure 131
C#4    2        q     d
A3     2        q     d
D4     2        q     d
measure 132
C#4    1        e     d  [
B3     1        e     d  ]
A3     2        q     d
D4     2        q     d
measure 133
C#4    2        q     d
A3     2        q     d
D4     2        q     d
measure 134
C#4    1        e     d  [
B3     1        e     d  ]
A3     2        q     d
rest   2        q
measure 135
rest   2        q
rest   2        q
$ D:Adagio
A3     2        q     d
measure 136
D3     6-       h.    u        -
measure 137
D3     4        h     u
D3     2        q     u
measure 138
A2     6        h.    u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
