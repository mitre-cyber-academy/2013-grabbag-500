&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/01} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:8c8145c5ca7967622755bb183dd57684]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba I
1 23
Group memberships: score
score: part 1 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
F#5    8        h     d
A5     4        q     d
measure 2
D6     6        q.    d
D6     2        e     d
A5     8        h     d
measure 3
G5     4        q     d
F#5    4        q     d
E5     8        h     d
measure 4
rest   4        q
E5     4        q     d
E5     6        q.    d
E5     2        e     d
measure 5
D5     6        q.    d
D5     2        e     d
D5     6        q.    d
E5     2        e     d
measure 6
F#5    4        q     d
F#5    8        h     d
E5     4        q     d
measure 7
F#5    8        h     d
rest   2        e
$ D:Andante
F#5    2        e     d  [
F#5    2        e     d  =
F#5    2        e     d  ]
measure 8
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D5     2        e     d
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 9
F#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
F#5    2        e     d
G5     4        q     d
rest   2        e
G5     2        e     d
measure 10
F#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
A5     2        e     d
G#5    2        e     d  [
G#5    2        e     d  ]
rest   2        e
B5     2        e     d
measure 11
A5     4        q     d
E5     4        q     d
rest   8        h
measure 12
$ D:Largo
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   2        e
$ D:Andante
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  ]
measure 20
G5     2        e     d  [
G5     2        e     d  ]
rest   2        e
G5     2        e     d
F#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
F#5    2        e     d
measure 21
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
G5     2        e     d
E5     4        q     d
rest   2        e
A5     2        e     d
measure 22
A5     2        e     d  [
G5     2        e     d  ]
rest   2        e
G5     2        e     d
G5     2        e     d  [
G5     2        e     d  ]
rest   2        e
G5     2        e     d
measure 23
F#5    4        q     d
F#5    4        q     d
rest   8        h
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest  16
measure 53
rest   8        h
rest   4        q
A3     2        e     u  [
A3     1        s     u  =[
A3     1        s     u  ]]
measure 54
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 55
D4     2        e     u  [
A3     1        s     u  =[
A3     1        s     u  ]]
A3     2        e     u  [
A3     2        e     u  ]
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
F#4    2        e     u  [
F#4    1        s     u  =[
F#4    1        s     u  ]]
measure 56
A4     2        e     u  [
F#4    2        e     u  ]
rest   4        q
D5     2        e     d  [
A4     2        e     d  ]
rest   4        q
measure 57
F#5    2        e     d  [
D5     2        e     d  ]
rest   2        e
F#5    2        e     d
A5     2        e     d  [
F#5    1        s     d  =[
F#5    1        s     d  ]]
D5     2        e     d  [
G5     2        e     d  ]
measure 58
F#5    4        q     d
rest   2        e
A5     2        e     d
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     2        e     d  [
A5     2        e     d  ]
measure 59
D5     2        e     d  [
E5     1        s     d  =[
F#5    1        s     d  ]]
G5     2        e     d  [
E5     2        e     d  ]
F#5    3        e.    d  [
E5     1        s     d  ]\
D5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
measure 60
E5     4        q     d
D5     4-       q     d        -
D5     2        e     d  [
E5     1        s     d  =[
F#5    1        s     d  ]]
G5     2        e     d  [
G5     2        e     d  ]
measure 61
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    4        q     d
rest   8        h
measure 62
rest  16
measure 63
rest   8        h
rest   4        q
rest   2        e
A5     2        e     d
measure 64
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  ]
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 65
F#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
F#5    2        e     d
G5     2        e     d  [
G5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 66
A5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
B5     2        e     d  [
B5     2        e     d  ]
rest   2        e
A5     2        e     d
measure 67
A5     2        e     d  [
E5     1        s     d  =[
E5     1        s     d  ]]
E5     2        e     d  [
A5     2        e     d  ]
A5     4        q     d
G5     2        e     d  [
E5     2        e     d  ]
measure 68
F#5    4        q     d
E5     3        e.    d  [
D5     1        s     d  ]\
D5     4        q     d
$ D:Adagio
rest   2        e
E5     2        e     d
measure 69
F#5    8        h     d
A5     4        q     d
A5     4        q     d
measure 70
A5     8        h     d
G#5    8        h     d
measure 71
A5    16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/02} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:8d49d7bd148995ff81b4b2b108c189eb]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tromba II
1 23
Group memberships: score
score: part 2 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
D5     8        h     d
E5     4        q     d
measure 2
F#5    6        q.    d
F#5    2        e     d
D5     8        h     d
measure 3
E5     4        q     d
A4     4        q     u
A4     8        h     u
measure 4
rest   4        q
E5     4        q     d
F#4    6        q.    u
F#4    2        e     u
measure 5
F#4    6        q.    u
F#4    2        e     u
F#4    4        q     u
F#4    4        q     u
measure 6
F#4    4        q     u
F#4    4        q     u
D4     4        q     u
E5     4        q     d
measure 7
F#4    8        h     u
rest   2        e
$ D:Andante
F#4    2        e     u  [
F#4    2        e     u  =
F#4    2        e     u  ]
measure 8
F#4    2        e     u  [
F#4    2        e     u  ]
rest   2        e
F#4    2        e     u
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
A4     2        e     u
measure 9
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
D5     2        e     d
E5     4        q     d
rest   2        e
E5     2        e     d
measure 10
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D5     2        e     d
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 11
E5     4        q     d
A4     4        q     u
rest   8        h
measure 12
$ D:Largo
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   2        e
$ D:Andante
F#5    2        e     d  [
F#5    2        e     d  =
F#5    2        e     d  ]
measure 20
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D5     2        e     d
measure 21
D4     2        e     u  [
D4     2        e     u  ]
rest   2        e
D4     2        e     u
A4     4        q     u
rest   2        e
E5     2        e     d
measure 22
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D5     2        e     d
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 23
D5     4        q     d
D5     4        q     d
rest   8        h
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest  16
measure 53
rest   8        h
rest   4        q
A3     2        e     u  [
A3     1        s     u  =[
A3     1        s     u  ]]
measure 54
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 55
D4     2        e     u  [
A3     1        s     u  =[
A3     1        s     u  ]]
A3     2        e     u  [
A3     2        e     u  ]
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
D4     2        e     u  [
D4     1        s     u  =[
D4     1        s     u  ]]
measure 56
F#4    2        e     u  [
D4     2        e     u  ]
rest   4        q
A4     2        e     u  [
F#4    2        e     u  ]
rest   4        q
measure 57
D5     2        e     d  [
A4     2        e     d  ]
rest   2        e
D5     2        e     d
F#5    2        e     d  [
D5     1        s     d  =[
D5     1        s     d  ]]
D4     2        e     u  [
D5     2        e     u  ]
measure 58
D5     4        q     d
rest   4        q
rest   4        q
rest   2        e
A4     2        e     u
measure 59
F#4    4        q     u
rest   2        e
A4     2        e     u
A4     2        e     u  [
F#4    2        e     u  ]
rest   2        e
D4     2        e     u
measure 60
A4     4        q     u
rest   2        e
F#4    2        e     u
D4     2        e     u  [
D4     2        e     u  =
D5     2        e     u  =
D5     2        e     u  ]
measure 61
A4     2        e     u  [
D4     2        e     u  ]
D5     4        q     d
rest   8        h
measure 62
rest  16
measure 63
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u
measure 64
D5     2        e     d  [
D5     2        e     d  ]
rest   4        q
rest   4        q
rest   2        e
A4     2        e     u
measure 65
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
D5     2        e     d
D5     2        e     d  [
E5     2        e     d  ]
rest   2        e
A4     2        e     u
measure 66
E5     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
F#5    2        e     d  ]
D5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
measure 67
E5     2        e     d  [
A4     1        s     d  =[
A4     1        s     d  ]]
A4     2        e     d  [
E5     2        e     d  ]
F#5    4        q     d
D5     2        e     d  [
E5     2        e     d  ]
measure 68
D5     4        q     d
A4     3        e.    u  [
A4     1        s     u  ]\
F#4    4        q     u
$ D:Adagio
rest   2        e
A4     2        e     u
measure 69
A4     8        h     u
E5     4        q     d
E5     4        q     d
measure 70
D5    16        w     d
measure 71
E5    16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/03} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:d985d8011aa1b6467b6ecdf4bbb8c614]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Timpani
1 23
Group memberships: score
score: part 3 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Largo
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
rest  16
measure 5
rest  16
measure 6
rest  16
measure 7
rest   8        h
rest   2        e
$ D:Andante
rest   2        e
rest   4        q
measure 8
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
A2     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 9
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
A2     4        q     u
rest   2        e
A2     2        e     u
measure 10
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
A2     2        e     u
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
measure 11
A2     4        q     u
A2     4        q     u
rest   8        h
measure 12
$ D:Largo
rest  16
measure 13
rest  16
measure 14
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest   8        h
rest   2        e
$ D:Andante
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
measure 20
A2     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
measure 21
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
A2     4        q     u
rest   2        e
A2     2        e     u
measure 22
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
A2     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 23
D3     4        q     d
D3     4        q     d
rest   8        h
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest  16
measure 35
rest  16
measure 36
rest  16
measure 37
rest  16
measure 38
rest  16
measure 39
rest  16
measure 40
rest  16
measure 41
rest  16
measure 42
rest  16
measure 43
rest  16
measure 44
rest  16
measure 45
rest  16
measure 46
rest  16
measure 47
rest  16
measure 48
rest  16
measure 49
rest  16
measure 50
rest  16
measure 51
rest  16
measure 52
rest  16
measure 53
rest   8        h
rest   4        q
A2     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
measure 54
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 55
D3     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
A2     2        e     u  [
A2     2        e     u  ]
D3     4        q     d
rest   4        q
measure 56
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 57
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
D3     2        e     d  [
D3     1        s     d  =[
D3     1        s     d  ]]
D3     2        e     d  [
D3     2        e     d  ]
measure 58
D3     4        q     d
rest   4        q
rest   4        q
rest   2        e
A2     2        e     u
measure 59
D3     4        q     d
rest   2        e
A2     2        e     u
D3     4        q     d
rest   2        e
D3     2        e     d
measure 60
A2     4        q     u
rest   2        e
D3     2        e     d
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 61
D3     4        q     d
D3     4        q     d
rest   8        h
measure 62
rest  16
measure 63
rest   8        h
rest   4        q
rest   2        e
D3     2        e     d
measure 64
D3     2        e     d  [
D3     2        e     d  ]
rest   4        q
rest   4        q
rest   2        e
A2     2        e     u
measure 65
A2     2        e     u  [
D3     2        e     u  ]
rest   2        e
D3     2        e     d
D3     2        e     u  [
A2     2        e     u  ]
rest   2        e
A2     2        e     u
measure 66
A2     2        e     u  [
A2     2        e     u  =
D3     2        e     u  =
D3     2        e     u  ]
D3     2        e     d  [
D3     2        e     d  ]
rest   2        e
A2     2        e     u
measure 67
A2     2        e     u  [
A2     1        s     u  =[
A2     1        s     u  ]]
A2     2        e     u  [
A2     2        e     u  ]
D3     4        q     d
D3     2        e     d  [
D3     2        e     d  ]
measure 68
A2     4        q     u
A2     3        e.    u  [
A2     1        s     u  ]\
D3     4        q     d
$ D:Adagio
rest   2        e
A2     2        e     u
measure 69
D3     8        h     d
A2     4        q     u
A2     4        q     u
measure 70
D3    12        h.    d
D3     4        q     d
measure 71
A2    16        w     u
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/04} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:1d21fe9dd47c9386b286f66c258d6261]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 4 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
F#5    8        h     d
A5     4        q     d
measure 2
D6     6        q.    d
D6     2        e     d
A5     8        h     d
measure 3
G5     4        q     d
F#5    4        q     d
E5     8        h     d
measure 4
rest   4        q
E5     4        q     d
A#5    6        q.    d
A#5    2        e     d
measure 5
B5     6        q.    d
B5     2        e     d
B5     4        q     d
D6     4        q     d
measure 6
C#6    6        q.    d
D6     2        e     d
B5     6        q.    d
B5     2        e     d
measure 7
A#5    8        h     d
rest   2        e
$ D:Andante
C#6    2        e     d  [
C#6    2        e     d  =
C#6    2        e     d  ]
measure 8
D6     2        e     d  [
D6     1        s     d  =[
C#6    1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 9
F#4    2        e     u  [
F#5    1        s     d  =[
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G4     2        e     u  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
measure 10
A4     2        e     u  [
A5     1        s     d  =[
G5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     2        e     d  [
B5     1        s     d  =[
A5     1        s     d  ]]
G#5    1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
measure 11
C#5    2        e     u  [
B4     1        s     u  =[
A4     1        s     u  ]]
G#4    1        s     u  [[
F#4    1        s     u  ==
E4     1        s     u  ==
D4     1        s     u  ]]
C#4    4        q     u
rest   4        q
measure 12
$ D:Largo
rest   4        q
C#6    8        h     d
B5     4        q     d
measure 13
A5     6        q.    d
A5     2        e     d
E5     8        h     d
measure 14
D5     4        q     d
C#5    4        q     d
B4     8        h     d
measure 15
rest   4        q
B5     4        q     d
B5     6        q.    d
B5     2        e     d
measure 16
A5     6        q.    d
A5     2        e     d
A5     4        q     d
C#6    4        q     d
measure 17
D6     8        h     d
rest   4        q
F#5    4        q     d
measure 18
F#5    8        h     d
E#5    6        q.    d
E#5    2        e     d
measure 19
F#5    8        h     d
rest   2        e
$ D:Andante
F#5    2        e     d  [
F#5    2        e     d  =
F#5    2        e     d  ]
measure 20
G5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
A4     2        e     u  [
A5     1        s     d  =[
G5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 21
B4     2        e     u  [
B5     1        s     d  =[
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    2        e     d  [
C#6    1        s     d  =[
B5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 22
D5     2        e     d  [
D6     1        s     d  =[
C#6    1        s     d  ]]
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     2        e     d  [
E6     1        s     d  =[
D6     1        s     d  ]]
C#6    1        s     d  [[
B5     1        s     d  ==
A5     1        s     d  ==
G5     1        s     d  ]]
measure 23
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    4        q     u
rest   4        q
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest   4        q
A4     2        e     u  [
B4     1        s     u  =[
C#5    1        s     u  ]]
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 29
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 30
F#4    4        q     u
rest   2        e
A4     2        e     u
B4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
E4     2        e     u  [
A4     2        e     u  ]
measure 31
D4     2        e     u
D5     4        q     d
C#5    2        e     d
F#4    2        e     u  [
B4     2        e     u  =
E4     2        e     u  =
A4     2        e     u  ]
measure 32
D5     4        q     d
D5     2        e     d  [
D5     2        e     d  ]
D5     2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
B4     2        e     d  ]
measure 33
C#5    2        e     d  [
E5     2        e     d  ]
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
E5     2        e     d  [
C#5    1        s     d  =[
D5     1        s     d  ]]
E5     2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
measure 34
B4     2        e     d  [
B4     2        e     d  ]
rest   4        q
E4     2        e     u  [
F#4    1        s     u  =[
G#4    1        s     u  ]]
A4     1        s     d  [[
B4     1        s     d  ==
C#5    1        s     d  ==
D5     1        s     d  ]]
measure 35
E5     1        s     d  [[
A4     1        s     d  ==
B4     1        s     d  ==
C#5    1        s     d  ]]
D5     1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G#5    1        s     d  ]]
A5     2        e     d  [
E5     2        e     d  ]
G#4    2        e     u  [
F#4    1        s     u  =[
E4     1        s     u  ]]
measure 36
A4     2        e     u  [
G#4    1        s     u  =[
F#4    1        s     u  ]]
E4     1        s     u  [[
D4     1        s     u  ==
C#4    1        s     u  ==
B3     1        s     u  ]]
A3     2        e     u  [
A3     2        e     u  ]
rest   4        q
measure 37
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d
measure 38
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     2        e     d  [
E5     2        e     d  ]
A4     2        e     u
D5     4        q     d
C#5    2        e     d
measure 39
B4     2        e     d  [
B5     1        s     d  =[
A5     1        s     d  ]]
G#5    1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    4        q     d
rest   4        q
measure 40
rest   8        h
rest   4        q
A5     2        e     d  [
B5     1        s     d  =[
C#6    1        s     d  ]]
measure 41
D6     2        e     d  [
D6     2        e     d  =
D6     2        e     d  =
D6     2        e     d  ]
D6     2        e     d  [
C#6    1        s     d  =[
B5     1        s     d  ]]
A5     2        e     d  [
G5     2        e     d  ]
measure 42
F#5    4        q     d
rest   4        q
rest   4        q
A4     4-       q     u        -
measure 43
A4     2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
E4     2        e     u  [
D4     2-       e     u  ]     -
D4     2        e     u  [
E4     1        s     u  =[
D4     1        s     u  ]]
C#4    2        e     u  [
C#4    2        e     u  ]
measure 44
D4     4        q     u
rest   4        q
rest   8        h
measure 45
rest   8        h
rest   4        q
rest   2        e
A5     2        e     d
measure 46
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     2        e     d  [
A5     2        e     d  ]
D5     2        e     d
D6     4        q     d
C#6    2        e     d
measure 47
D6     1        s     d  [[
C#6    1        s     d  ==
B5     1        s     d  ==
A5     1        s     d  ]]
G#5    2        e     d  [
E5     2-       e     d  ]     -
E5     2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
D5     4-       q     d        -
measure 48
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
C#5    2        e     d  [
D5     1        s     d  =[
C#5    1        s     d  ]]
B4     2        e     d  [
A5     2        e     d  =
G#5    3        e.    d  =      &t
G#5    1        s     d  ]\
measure 49
A5     1        s     d  [[
E5     1        s     d  ==
A5     1        s     d  ==
C#6    1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
A4     1        s     d  ==
C#6    1        s     d  ]]
C#6    1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
C#6    1        s     d  ]]
B5     1        s     d  [[
B4     1        s     d  ==
F#5    1        s     d  ==
A#5    1        s     d  ]]
measure 50
B5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
F#5    1        s     d  ==
B4     1        s     d  ==
B5     1        s     d  ]]
B5     1        s     d  [[
G#5    1        s     d  ==
C#5    1        s     d  ==
B5     1        s     d  ]]
A5     1        s     d  [[     +
C#5    1        s     d  ==
F#5    1        s     d  ==
B5     1        s     d  ]]
measure 51
G#5    1        s     d  [[
C#5    1        s     d  ==
G#4    1        s     d  ==
G#5    1        s     d  ]]
G#5    1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
G#5    1        s     d  ]]
F#5    1        s     d  [[
F#4    1        s     d  ==
A4     1        s     d  ==
C#5    1        s     d  ]]
F#5    2        e     d  [
G5     1        s     d  =[
A5     1        s     d  ]]
measure 52
B5     1        s     d  [[
G5     1        s     d  ==
B5     1        s     d  ==
D6     1        s     d  ]]
B5     1        s     d  [[
G5     1        s     d  ==
B5     1        s     d  ==
D6     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
E5     1        s     d  ==
A5     1        s     d  ]]
E5     1        s     d  [[
C#5    1        s     d  ==
E5     1        s     d  ==
A5     1        s     d  ]]
measure 53
D5     1        s     d  [[
F#5    1        s     d  ==
A5     1        s     d  ==
D6     1        s     d  ]]
C#6    1        s     d  [[
E5     1        s     d  ==
A5     1        s     d  ==
D6     1        s     d  ]]
C#6    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
measure 54
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
B4     1        s     u  [[
G4     1        s     u  ==
B4     1        s     u  ==
D5     1        s     u  ]]
B4     1        s     u  [[
G4     1        s     u  ==
B4     1        s     u  ==
D5     1        s     u  ]]
measure 55
A4     1        s     u  [[
F#4    1        s     u  ==
A4     1        s     u  ==
D5     1        s     u  ]]
C#5    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
D5     1        s     u  [[
A4     1        s     u  ==
F#4    1        s     u  ==
A4     1        s     u  ]]
A4     1        s     u  [[
F#4    1        s     u  ==
D4     1        s     u  ==
D5     1        s     u  ]]
measure 56
D5     1        s     u  [[
A4     1        s     u  ==
F#4    1        s     u  ==
A4     1        s     u  ]]
D5     1        s     u  [[
A4     1        s     u  ==
F#4    1        s     u  ==
A4     1        s     u  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
A5     1        s     d  ]]
measure 57
A5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
A5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
D6     1        s     d  ]]
D6     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
B5     1        s     d  [[
G5     1        s     d  ==
B5     1        s     d  ==
D6     1        s     d  ]]
measure 58
D6     1        s     d  [[
A5     1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
D5     2        e     d  [
A5     2        e     d  ]
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     2        e     d  [
A5     2        e     d  ]
measure 59
D5     2        e     d
D6     4        q     d
C#6    2        e     d
D6     2        e     d  [
A5     2        e     d  ]
B5     2        e     d  [
C#6    1        s     d  =[
D6     1        s     d  ]]
measure 60
C#6    4        q     d
D6     2        e     d  [
D5     2-       e     d  ]     -
D5     2        e     d  [
E5     1        s     d  =[
F#5    1        s     d  ]]
G5     2        e     d  [
G5     2-       e     d  ]     -
measure 61
G5     2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
F#5    2        e     d  [
A4     2        e     d  ]
B4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
E4     2        e     u  [
A4     2        e     u  ]
measure 62
A4     1        s     u  [[
G4     1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
D4     2        e     u  [
G5     2        e     d  ]
G5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    2        e     d  [
F#5    2        e     d  ]
measure 63
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     2        e     d  [
E5     2        e     d  ]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
A4     2        e     u  [
A4     2        e     u  ]
measure 64
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
B4     2        e     d
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
C#5    2        e     d
measure 65
F#5    2        e     d  [
F#5    2        e     d  ]
rest   2        e
D5     2        e     d
G5     2        e     d  [
G5     2        e     d  ]
rest   2        e
E5     2        e     d
measure 66
A5     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
B5     1        s     d  [[
A5     1        s     d  ==
G5     1        s     d  ==
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
measure 67
A4     2        e     d  [
A5     2        e     d  ]
rest   2        e
A5     2        e     d
A5     4        q     d
B5     2        e     d  [
D6     2        e     d  ]
measure 68
D6     4        q     d
C#6    4        q     d         &t
D6     4        q     d
$ D:Adagio
rest   2        e
E5     2        e     d
measure 69
F#5    8        h     d
A5     4        q     d
A5     4        q     d
measure 70
A5     8        h     d
G#5    8        h     d         &t
measure 71
A5    16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 05
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/05} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:9ce9df3e865c48f03833cab28345abb1]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 5 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
D5     8        h     d
E5     4        q     d
measure 2
F#5    6        q.    d
F#5    2        e     d
D5     8        h     d
measure 3
C#5    4        q     d
D5     4        q     d
C#5    8        h     d
measure 4
rest   4        q
C#5    4        q     d
C#5    6        q.    d
C#5    2        e     d
measure 5
D5     6        q.    d
D5     2        e     d
D5     6        q.    d
E5     2        e     d
measure 6
F#5    4        q     d
F#5    8        h     d
E5     4        q     d
measure 7
F#5    8        h     d
rest   2        e
$ D:Andante
A#5    2        e     d  [
A#5    2        e     d  =
A#5    2        e     d  ]
measure 8
F#5    2        e     d  [
F#5    1        s     d  =[
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
D5     1        s     d  ]]
C#5    2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
measure 9
D4     2        e     u  [
D5     1        s     d  =[
C#5    1        s     d  ]]
B4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
E4     2        e     u  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
measure 10
F#4    2        e     u  [
F#5    1        s     d  =[
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
G#4    2        e     u  [
G#5    1        s     d  =[
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
measure 11
A4     2        e     u  [
G#4    1        s     u  =[
F#4    1        s     u  ]]
E4     1        s     u  [[
D4     1        s     u  ==
C#4    1        s     u  ==
B3     1        s     u  ]]
A3     4        q     u
rest   4        q
measure 12
$ D:Largo
rest   4        q
E5     8        h     d
E5     4        q     d
measure 13
F#5    6        q.    d
C#5    2        e     d
A4     8        h     u
measure 14
G#4    4        q     u
A4     4        q     u
G#4    8        h     u
measure 15
rest   4        q
G#5    4        q     d
E#5    6        q.    d
E#5    2        e     d
measure 16
C#5    6        q.    d
C#5    2        e     d
C#5    4        q     d
A5     4        q     d
measure 17
F#5    8        h     d
rest   4        q
A4     4        q     u
measure 18
G#4    8        h     u
G#4    6        q.    u
G#4    2        e     u
measure 19
A4     8        h     u
rest   2        e
$ D:Andante
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  ]
measure 20
C#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    1        s     u  [[
B4     1        s     u  ==
A4     1        s     u  ==
G4     1        s     u  ]]
F#4    2        e     u  [
F#5    1        s     d  =[
E5     1        s     d  ]]
D5     1        s     d  [[
C#5    1        s     d  ==
B4     1        s     d  ==
A4     1        s     d  ]]
measure 21
G4     2        e     u  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
A4     2        e     u  [
A5     1        s     d  =[
G5     1        s     d  ]]
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 22
B4     2        e     d  [
B5     1        s     d  =[
A5     1        s     d  ]]
G5     1        s     d  [[
F#5    1        s     d  ==
E5     1        s     d  ==
D5     1        s     d  ]]
C#5    2        e     d  [
C#6    1        s     d  =[
B5     1        s     d  ]]
A5     1        s     d  [[
G5     1        s     d  ==
F#5    1        s     d  ==
E5     1        s     d  ]]
measure 23
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     1        s     u  [[
G4     1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
D4     4        q     u
rest   4        q
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest   4        q
A4     2        e     u  [
B4     1        s     u  =[
C#5    1        s     u  ]]
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 29
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     u  [
G4     2        e     u  ]
measure 30
F#4    4        q     u
rest   4        q
rest   8        h
measure 31
rest  16
measure 32
rest   8        h
E5     6        q.    d
F#5    1        s     d  [[
G#5    1        s     d  ]]
measure 33
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  =
A5     2        e     d  ]
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  =
A5     2        e     d  ]
measure 34
A5     2        e     d  [
G#5    1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
D5     2        e     d  ]
C#5    4        q     d
rest   4        q
measure 35
rest   2        e
E5     2        e     d
F#5    2        e     d  [
E5     1        s     d  =[
D5     1        s     d  ]]
C#5    2        e     d  [
B4     2        e     d  ]
rest   2        e
B4     2        e     d
measure 36
E4     2        e     u  [
A4     2        e     u  ]
rest   4        q
rest   4        q
rest   2        e
E4     2        e     u
measure 37
F#4    1        s     u  [[
E4     1        s     u  ==
D4     1        s     u  ==
C#4    1        s     u  ]]
B3     2        e     u  [
E4     2        e     u  ]
A3     2        e     u
A4     4        q     u
G#4    2        e     u
measure 38
F#4    2        e     u  [
F#4    2        e     u  =
G#4    3        e.    u  =
G#4    1        s     u  ]\
A4     2        e     u  [
G#4    1        s     u  =[
F#4    1        s     u  ]]
E4     2        e     u  [
E5     2        e     d  ]
measure 39
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     2        e     d  [
E5     2        e     d  ]
E5     4        q     d
rest   4        q
measure 40
rest   4        q
D5     2        e     d  [
F#5    1        s     d  =[
G5     1        s     d  ]]
A5     2        e     d  [
A5     2        e     d  =
A5     2        e     d  =
A5     2        e     d  ]
measure 41
A5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
D5     2        e     d  ]
E5     4        q     d
A5     4-       q     d        -
measure 42
A5     2        e     d  [
G5     1        s     d  =[
F#5    1        s     d  ]]
E5     2        e     d  [
D5     2        e     d  ]
E5     4        q     d
rest   4        q
measure 43
rest   4        q
rest   2        e
A4     2        e     u
B4     1        s     u  [[
A4     1        s     u  ==
G4     1        s     u  ==
F#4    1        s     u  ]]
E4     2        e     u  [
A4     2        e     u  ]
measure 44
D4     2        e     u  [
E4     1        s     u  =[
F#4    1        s     u  ]]
G4     2        e     u  [
F#4    1        s     u  =[
E4     1        s     u  ]]
F#4    2        e     u  [
G4     1        s     u  =[
A4     1        s     u  ]]
B4     2        e     u  [
A4     1        s     u  =[
G4     1        s     u  ]]
measure 45
A4     2        e     u  [
G4     1        s     u  =[
F#4    1        s     u  ]]
G4     1        s     u  [[
F#4    1        s     u  ==
G4     1        s     u  ==
E4     1        s     u  ]]
F#4    4        q     u
rest   4        q
measure 46
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d
measure 47
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     4        q     d
rest   4        q
A4     2        e     d  [
C#5    1        s     d  =[
D5     1        s     d  ]]
measure 48
E5     2        e     d  [
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]
E5     2        e     d  [
E5     2        e     d  =
E5     3        e.    d  =
D5     1        s     d  ]\
measure 49
C#5    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
A5     1        s     d  [[
E5     1        s     d  ==
C#5    1        s     d  ==
A4     1        s     d  ]]
F#4    1        s     d  [[
F#5    1        s     d  ==
A5     1        s     d  ==
F#5    1        s     d  ]]
D5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
measure 50
B4     1        s     d  [[
D5     1        s     d  ==
F#5    1        s     d  ==
D5     1        s     d  ]]
B4     1        s     d  [[
D5     1        s     d  ==
G#5    1        s     d  ==
D5     1        s     d  ]]
C#5    1        s     d  [[
E#5    1        s     d  ==
G#5    1        s     d  ==     +
E#5    1        s     d  ]]
C#5    1        s     d  [[
F#5    1        s     d  ==
A5     1        s     d  ==
F#5    1        s     d  ]]
measure 51
F#5    2        e     d  [
F#5    2        e     d  =
E#5    2        e     d  =
E#5    2        e     d  ]
F#5    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
F#5    1        s     d  ]]
A5     2        e     d  [
D5     2        e     d  ]
measure 52
D5     1        s     d  [[
B4     1        s     d  ==
D5     1        s     d  ==
B5     1        s     d  ]]
G5     1        s     d  [[
D5     1        s     d  ==
G5     1        s     d  ==
B5     1        s     d  ]]
C#5    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
C#5    1        s     d  [[
A4     1        s     d  ==
C#5    1        s     d  ==
E5     1        s     d  ]]
measure 53
A5     1        s     d  [[
D5     1        s     d  ==
F#5    1        s     d  ==
A5     1        s     d  ]]
G5     2        e     d  [
F#5    2        e     d  ]
E5     1        s     d  [[
C#5    1        s     d  ==
A4     1        s     d  ==
C#5    1        s     d  ]]
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
measure 54
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
G4     1        s     u  [[
D4     1        s     u  ==
G4     1        s     u  ==
B4     1        s     u  ]]
G4     1        s     u  [[
D4     1        s     u  ==
G4     1        s     u  ==
B4     1        s     u  ]]
measure 55
F#4    1        s     u  [[
D4     1        s     u  ==
A4     1        s     u  ==
B4     1        s     u  ]]
E4     1        s     u  [[
C#4    1        s     u  ==
E4     1        s     u  ==
A4     1        s     u  ]]
A4     1        s     u  [[
F#4    1        s     u  ==
D4     1        s     u  ==
D5     1        s     u  ]]
D5     1        s     d  [[
A4     1        s     d  ==
F#4    1        s     d  ==
F#5    1        s     d  ]]
measure 56
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
D5     1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
A5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
measure 57
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
F#5    1        s     d  ]]
F#5    1        s     d  [[
D5     1        s     d  ==
A4     1        s     d  ==
F#5    1        s     d  ]]
G5     1        s     d  [[
D5     1        s     d  ==
G5     1        s     d  ==
B5     1        s     d  ]]
measure 58
A5     1        s     d  [[
F#5    1        s     d  ==
D5     1        s     d  ==
F#5    1        s     d  ]]
D4     4        q     u
rest   8        h
measure 59
rest   4        q
rest   2        e
E5     2        e     d
F#5    1        s     d  [[
E5     1        s     d  ==
D5     1        s     d  ==
C#5    1        s     d  ]]
B4     2        e     d  [
E5     2        e     d  ]
measure 60
A4     1        s     d  [[
E5     1        s     d  ==
F#5    1        s     d  ==
G5     1        s     d  ]]
A5     2        e     d  [
A4     2        e     d  ]
A4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
B4     2        e     u  ]
measure 61
A4     4        q     u
rest   2        e
F#4    2        e     u
G4     1        s     u  [[
F#4    1        s     u  ==
E4     1        s     u  ==
D4     1        s     u  ]]
C#4    2        e     u  [
C#5    2        e     u  ]
measure 62
D5     2        e     d  [
D5     2        e     d  ]
rest   2        e
D5     2        e     d
C#5    2        e     d  [
C#5    2        e     d  ]
rest   2        e
C#5    2        e     d
measure 63
B4     2        e     d  [
B4     2        e     d  ]
rest   2        e
C#5    2        e     d
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
D4     2        e     u
measure 64
A4     1        s     u  [[
G4     1        s     u  ==
F#4    1        s     u  ==
E4     1        s     u  ]]
D4     2        e     u  [
D4     2        e     u  ]
G4     2        e     u  [
G4     2        e     u  ]
rest   2        e
E4     2        e     u
measure 65
A4     2        e     u  [
A4     2        e     u  ]
rest   2        e
F#4    2        e     u
B4     2        e     d  [
B4     2        e     d  ]
rest   2        e
A4     2        e     u
measure 66
E5     2        e     d  [
E5     2        e     d  ]
rest   2        e
F#5    2        e     d
F#5    2        e     d  [
B4     2        e     d  =
B4     2        e     d  =
E5     2        e     d  ]
measure 67
E5     1        s     d  [[
D5     1        s     d  ==
C#5    1        s     d  ==
B4     1        s     d  ]]
A4     2        e     d  [
E5     2        e     d  ]
F#5    4        q     d
G5     2        e     d  [
E5     2        e     d  ]
measure 68
F#5    4        q     d
E5     4        q     d
F#5    4        q     d
$ D:Adagio
rest   2        e
C#5    2        e     d
measure 69
A4     8        h     u
E5     4        q     d
E5     4        q     d
measure 70
D5    16        w     d
measure 71
C#5   16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 06
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/06} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:4aa5fdfed3c8275464b70c7638edb834]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 6 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:13   D:Largo
rest   4        q
A4     8        h     d
A4     4        q     d
measure 2
F#4    6        q.    d
F#4    2        e     d
F#4    8        h     d
measure 3
G4     4        q     d
A4     4        q     d
A4     8        h     d
measure 4
rest   4        q
A4     2        e     d  [
E4     2        e     d  ]
E4     6        q.    d
E4     2        e     d
measure 5
D4     6        q.    d
F#4    2        e     d
F#4    4        q     d
F#4    4        q     d
measure 6
F#4    4        q     d
C#4    4        q     d
D4     4        q     d
B3     2        e     d  [
B4     2        e     d  ]
measure 7
C#5    8        h     d
rest   2        e
$ D:Andante
F#4    2        e     d  [
F#4    2        e     d  =
F#4    2        e     d  ]
measure 8
F#4    2        e     d  [
F#4    2        e     d  ]
rest   2        e
F#4    2        e     d
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 9
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
D5     2        e     d
C#5    4        q     d
rest   2        e
C#5    2        e     d
measure 10
D5     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     2        e     d
E4     2        e     d  [
E4     2        e     d  ]
rest   2        e
E4     2        e     d
measure 11
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
E4     4        q     d
rest   4        q
measure 12
$ D:Largo
rest   4        q
A4     8        h     d
B4     4        q     d
measure 13
C#5    6        q.    d
F#4    2        e     d
E4     8        h     d
measure 14
B4     4        q     d
E4     4        q     d
E4     8        h     d
measure 15
rest   4        q
E4     4        q     d
G#4    6        q.    d
G#4    2        e     d
measure 16
A4     6        q.    d
F#4    2        e     d
F#4    4        q     d
F#4    4        q     d
measure 17
D4     8        h     d
rest   4        q
C#4    4        q     d
measure 18
C#4    8        h     d
C#4    6        q.    d
C#4    2        e     d
measure 19
C#4    8        h     d
rest   2        e
$ D:Andante
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  ]
measure 20
G4     2        e     d  [
G4     2        e     d  ]
rest   2        e
C#5    2        e     d
D5     2        e     d  [
D4     2        e     d  ]
rest   2        e
D4     2        e     d
measure 21
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
G4     2        e     d
E4     4        q     d
rest   2        e
A4     2        e     d
measure 22
A4     2        e     d  [
G4     2        e     d  ]
rest   2        e
G4     2        e     d
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 23
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
A4     4        q     d
rest   4        q
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest   4        q
A4     2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 29
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     d  [
G4     2        e     d  ]
measure 30
F#4    4        q     d
rest   4        q
rest   4        q
rest   2        e
A3     2        e     u
measure 31
B3     1        s     u  [[
A3     1        s     u  ==
G3     1        s     u  ==
F#3    1        s     u  ]]
E3     2        e     u  [
A3     2        e     u  ]
D3     2        e     u
D4     4        q     d
C#4    2        e     d
measure 32
F#3    2        e     u  [
B3     2        e     u  =
G#3    3        e.    u  =
G#3    1        s     u  ]\
A3     4        q     u
rest   4        q
measure 33
rest   2        e
C#4    2        e     u
D4     2        e     u  [
C#4    1        s     u  =[
B3     1        s     u  ]]
C#4    2        e     u  [
A3     1        s     u  =[
B3     1        s     u  ]]
C#4    2        e     u  [
B3     1        s     u  =[
A3     1        s     u  ]]
measure 34
E4     2        e     d  [
E4     2        e     d  ]
rest   4        q
rest   2        e
E4     2        e     d
F#4    2        e     d  [
E4     1        s     d  =[
D4     1        s     d  ]]
measure 35
C#4    2        e     u  [
A3     2        e     u  ]
rest   2        e
A3     2        e     u
E4     1        s     d  [[
F#4    1        s     d  ==
G#4    1        s     d  ==
A4     1        s     d  ]]
B4     2        e     d  [
G#4    2        e     d  ]
measure 36
E4     4        q     d
rest   4        q
rest   4        q
rest   2        e
E4     2        e     d
measure 37
F#4    1        s     d  [[
E4     1        s     d  ==
D4     1        s     d  ==
C#4    1        s     d  ]]
B3     2        e     d  [
E4     2        e     d  ]
A3     1        s     d  [[
B3     1        s     d  ==
C#4    1        s     d  ==
D4     1        s     d  ]]
E4     2        e     d  [
E4     2        e     d  ]
measure 38
A4     2        e     d  [
B4     1        s     d  =[
A4     1        s     d  ]]
G#4    1        s     d  [[
F#4    1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
C#4    2        e     d  [
D4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 39
A4     2        e     d  [
F#4    2        e     d  =
G#4    2        e     d  =
G#4    2        e     d  ]
A4     4        q     d
rest   4        q
measure 40
rest  16
measure 41
rest   8        h
rest   4        q
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
measure 42
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     u  [
C#4    1        s     u  =[
B3     1        s     u  ]]
A3     2        e     u  [
G3     2        e     u  ]
measure 43
F#3    4        q     u
rest   2        e
F#3    2        e     u
G3     4        q     u
A3     4        q     u
measure 44
F#4    2        e     d  [
E4     1        s     d  =[
D4     1        s     d  ]]
E4     2        e     d  [
D4     1        s     d  =[
C#4    1        s     d  ]]
D4     4        q     d
rest   4        q
measure 45
rest  16
measure 46
rest  16
measure 47
rest   4        q
rest   2        e
G#4    2        e     d
A4     1        s     d  [[
G#4    1        s     d  ==
F#4    1        s     d  ==
E4     1        s     d  ]]
D4     2        e     d  [
C#4    2        e     d  ]
measure 48
B3     4        q     u
A3     2        e     u  [
A4     2        e     d  ]
A4     2        e     d  [
G#4    1        s     d  =[
F#4    1        s     d  ]]
E4     2        e     d  [
E4     2        e     d  ]
measure 49
E4     4        q     d
C#5    2        e     d  [
C#5    2        e     d  ]
A4     2        e     d  [
A4     2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
measure 50
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
G#4    2        e     d  [
G#4    2        e     d  =
F#4    2        e     d  =
C#4    2        e     d  ]
measure 51
C#4    2        e     d  [
C#4    2        e     d  =
C#4    2        e     d  =
C#4    2        e     d  ]
A4     2        e     d  [
F#4    2        e     d  ]
D4     2        e     d  [
E4     1        s     d  =[
F#4    1        s     d  ]]
measure 52
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 53
F#4    2        e     d  [
F#4    2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
A3     4        q     u
A3     2        e     u  [
B3     1        s     u  =[
C#4    1        s     u  ]]
measure 54
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 55
D4     2        e     u  [
C#4    1        s     u  =[
B3     1        s     u  ]]
A3     2        e     u  [
G3     2        e     u  ]
F#3    4        q     u
rest   4        q
measure 56
A4     2        e     d  [
D4     2        e     d  ]
rest   4        q
D5     2        e     d  [
F#4    2        e     d  ]
rest   4        q
measure 57
D5     2        e     d  [
F#4    2        e     d  ]
rest   4        q
A4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  ]
measure 58
F#4    4        q     d
rest   4        q
rest   4        q
rest   2        e
C#4    2        e     d
measure 59
D4     2        e     d  [
E4     1        s     d  =[
F#4    1        s     d  ]]
G4     2        e     d  [
A4     1        s     d  =[
G4     1        s     d  ]]
A4     1        s     d  [[
G4     1        s     d  ==
F#4    1        s     d  ==
E4     1        s     d  ]]
D4     2        e     d  [
G4     1        s     d  =[
F#4    1        s     d  ]]
measure 60
E4     4        q     d
rest   2        e
F#4    2        e     d
F#4    2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 61
D4     4        q     d
rest   2        e
D4     2        e     d
G4     2        e     d  [
G4     2        e     d  ]
A4     1        s     d  [[
G4     1        s     d  ==
F#4    1        s     d  ==
E4     1        s     d  ]]
measure 62
D4     2        e     d  [
D4     2        e     d  ]
rest   2        e
B4     2        e     d
A4     2        e     d  [
A4     2        e     d  ]
rest   2        e
A4     2        e     d
measure 63
G4     2        e     d  [
G4     2        e     d  ]
rest   2        e
G4     2        e     d
F#4    2        e     d  [
F#4    2        e     d  ]
rest   2        e
F#4    2        e     d
measure 64
D4     2        e     u  [
A3     2        e     u  ]
rest   2        e
B3     2        e     u
B3     1        s     u  [[
A3     1        s     u  ==
G3     1        s     u  ==
F#3    1        s     u  ]]
E3     2        e     u  [
C#4    2        e     u  ]
measure 65
C#4    1        s     u  [[
B3     1        s     u  ==
A3     1        s     u  ==
G3     1        s     u  ]]
F#3    2        e     u  [
D4     2        e     u  ]
D4     1        s     u  [[
C#4    1        s     u  ==
B3     1        s     u  ==
A3     1        s     u  ]]
G3     2        e     u  [
E4     2        e     u  ]
measure 66
E4     1        s     d  [[
D4     1        s     d  ==
C#4    1        s     d  ==
B3     1        s     d  ]]
A3     2        e     d  [
F#4    2        e     d  ]
F#4    1        s     d  [[
E4     1        s     d  ==
D4     1        s     d  ==
C#4    1        s     d  ]]
B3     1        s     u  [[
A3     1        s     u  ==
G3     1        s     u  ==
F#3    1        s     u  ]]
measure 67
E3     2        e     u  [
A3     1        s     u  =[
B3     1        s     u  ]]
C#4    1        s     d  [[
D4     1        s     d  ==
E4     1        s     d  ==
C#4    1        s     d  ]]
A4     4        q     d
D4     2        e     d  [
B4     2        e     d  ]
measure 68
A4     4        q     d
A4     4        q     d
A4     4        q     d
$ D:Adagio
rest   2        e
A4     2        e     d
measure 69
F#4    8        h     d
E4     4        q     d
A4     4        q     d
measure 70
B4    16        w     d
measure 71
E4    16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 07
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/07} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:eb13647a5ab1df6bae0543029e433e13]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 7 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
D5     8        h     d                    Wor-
A4     4        q     u                    thy
measure 2
D5     6        q.    d                    is
D5     2        e     d                    the
A4     8        h     u                    Lamb,
measure 3
C#5    4        q     d                    that
D5     4        q     d                    was
C#5    8        h     d                    slain,
measure 4
rest   4        q
C#5    4        q     d                    and
C#5    6        q.    d                    hath
C#5    2        e     d                    re-
measure 5
D5     6        q.    d                    dee-
D5     2        e     d                    med
D5     6        q.    d                    us
E5     2        e     d                    to
measure 6
F#5    4        q     d                    God
F#5    8        h     d                    by
E5     4        q     d                    his
measure 7
F#5    8        h     d                    blood,
rest   2        e
$ D:Andante
C#5    2        e     d                    to
C#5    2        e     d                    re-
C#5    2        e     d                    ceive
measure 8
D5     2        e     d                    po-
D5     2        e     d                    wer,
rest   2        e
D5     2        e     d                    and
E5     2        e     d                    ri-
E5     2        e     d                    ches,
rest   2        e
E5     2        e     d                    and
measure 9
F#5    2        e     d                    wis-
F#5    2        e     d                    dom,
rest   2        e
D5     2        e     d                    and
C#5    4        q     d                    strength,
rest   2        e
C#5    2        e     d                    and
measure 10
D5     2        e     d                    ho-
D5     2        e     d                    nour,
rest   2        e
D5     2        e     d                    and
B4     2        e     d                    glo-
B4     2        e     d                    ry,
rest   2        e
E5     2        e     d                    and
measure 11
C#5    4        q     d                    bles-
C#5    4        q     d                    sing.
rest   8        h
measure 12
$ D:Largo
rest   4        q
C#5    8        h     d                    Wor-
B4     4        q     d                    thy
measure 13
A4     6        q.    u                    is
A4     2        e     u                    the
E5     8        h     d                    Lamb,
measure 14
D5     4        q     d                    that
C#5    4        q     d                    was
B4     8        h     d                    slain,
measure 15
rest   4        q
B4     4        q     d                    and
B4     6        q.    d                    hath
B4     2        e     d                    re-
measure 16
A4     6        q.    u                    dee-
A4     2        e     u                    med
A4     4        q     u                    us
C#5    4        q     d                    to
measure 17
D5     8        h     d                    God,
rest   4        q
C#5    4        q     d                    to
measure 18
C#5    8        h     d                    God
C#5    6        q.    d                    by
G#4    2        e     u                    his
measure 19
A4     8        h     u                    blood,
rest   2        e
$ D:Andante
D5     2        e     d                    to
D5     2        e     d                    re-
D5     2        e     d                    ceive
measure 20
C#5    2        e     d                    po-
C#5    2        e     d                    wer,
rest   2        e
C#5    2        e     d                    and
D5     2        e     d                    ri-
D5     2        e     d                    ches,
rest   2        e
D5     2        e     d                    and
measure 21
B4     2        e     d                    wis-
B4     2        e     d                    dom,
rest   2        e
E5     2        e     d                    and
C#5    4        q     d                    strength,
rest   2        e
C#5    2        e     d                    and
measure 22
D5     2        e     d                    ho-
D5     2        e     d                    nour,
rest   2        e
D5     2        e     d                    and
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
A4     2        e     u                    and
measure 23
F#5    4        q     d                    bles-
D5     4        q     d                    sing.
rest   8        h
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest   4        q
A4     2        e     u                    Bles-
B4     1        s     d                    sing
C#5    1        s     d                    and
D5     2        e     d                    ho-
D5     2        e     d                    nour,
D5     2        e     d                    glory
D5     2        e     d                    and
measure 29
D5     2        e     d                    pow'r
D5     2        e     d                    be
D5     2        e     d                    un-
D5     2        e     d                    to
D5     2        e     d                    him,
C#5    1        s     d  [[                be_
B4     1        s     d  ]]                _
A4     2        e     u                    un-
G4     2        e     u                    to
measure 30
F#4    4        q     u                    him,
rest   2        e
A4     2        e     u                    that
B4     1        s     u  [[                sit-
A4     1        s     u  ]]                -
G4     1        s     u                    teth
F#4    1        s     u                    up-
E4     2        e     u                    on
A4     2        e     u                    the
measure 31
D4     2        e     u                    throne,_
D5     4        q     d                    _
C#5    2        e     d                    _
F#4    2        e     u  [                 _
B4     2        e     u  =                 _
E4     2        e     u  ]                 _
A4     2        e     u                    and
measure 32
D5     4        q     d                    un-
D5     2        e     d                    to
D5     2        e     d                    the
D5     2        e     d  [                 Lamb,_
E5     1        s     d  =[                _
D5     1        s     d  ]]                _
C#5    2        e     d  [                 _
B4     2        e     d  =                 _
measure 33
C#5    2        e     d  ]                 _
E5     2        e     d                    for
F#5    2        e     d                    e-
E5     1        s     d                    ver
D5     1        s     d                    and
E5     2        e     d                    e-
C#5    1        s     d                    ver,
D5     1        s     d                    for
E5     2        e     d                    e-
D5     1        s     d                    ver
C#5    1        s     d                    and
measure 34
B4     2        e     d                    e-
B4     2        e     d                    ver,
rest   4        q
E4     2        e     u  [                 glo-
F#4    1        s     u  =[                -
G#4    1        s     u  ]]                -
A4     1        s     d  [[                -
B4     1        s     d  ==                -
C#5    1        s     d  ==                -
D5     1        s     d  ]]                -
measure 35
E5     1        s     d  [[                -
A4     1        s     d  ==                -
B4     1        s     d  ==                -
C#5    1        s     d  ]]                -
D5     1        s     d  [[                -
E5     1        s     d  ==                -
F#5    1        s     d  ==                -
G#5    1        s     d  =]                -
A5     2        e     d  ]                 -
E5     2        e     d                    ry!
rest   4        q
measure 36
rest  16
measure 37
rest   8        h
rest   4        q
rest   2        e
E5     2        e     d                    that
measure 38
F#5    1        s     d  [[                sit-
E5     1        s     d  ]]                -
D5     1        s     d                    teth
C#5    1        s     d                    up-
B4     2        e     d                    on
E5     2        e     d                    the
A4     2        e     u         (          throne,_
D5     4        q     d         )          _
C#5    2        e     d                    and
measure 39
B4     4        q     d                    un-
B4     2        e     d                    to
B4     2        e     d                    the
C#5    4        q     d                    Lamb.
rest   4        q
measure 40
rest   8        h
rest   4        q
A4     2        e     u                    Bles-
B4     1        s     d                    sing
C#5    1        s     d                    and
measure 41
D5     2        e     d                    ho-
D5     2        e     d                    nour,
D5     2        e     d                    glory
D5     2        e     d                    and
D5     2        e     d                    pow'r
C#5    1        s     d  [[                be_
B4     1        s     d  ]]                _
A4     2        e     u                    un-
G4     2        e     u                    to
measure 42
F#4    4        q     u                    him,
rest   4        q
rest   4        q
A4     4-       q     u        -           glo-
measure 43
A4     2        e     u                    -
G4     1        s     u                    ry
F#4    1        s     u                    be
E4     2        e     u                    un-
D4     2        e     u                    to
D5     4        q     d                    him,
rest   4        q
measure 44
rest  16
measure 45
rest   8        h
rest   4        q
rest   2        e
A4     2        e     u                    that
measure 46
B4     1        s     u  [[                sit-
A4     1        s     u  ]]                -
G4     1        s     u                    teth
F#4    1        s     u                    up-
E4     2        e     u                    on
A4     2        e     u                    the
D4     2        e     u         (          throne,_
D5     4        q     d         )          _
C#5    2        e     d                    that
measure 47
D5     1        s     d  [[                sit-
C#5    1        s     d  ]]                -
B4     1        s     d                    teth
A4     1        s     u                    up-
G#4    2        e     u                    on
E5     2        e     d                    the
E5     2        e     d  [                 throne_
D5     1        s     d  =[                _
C#5    1        s     d  ]]                _
D5     4-       q     d        -           _
measure 48
D5     2        e     d                    _
C#5    1        s     d  [[                for_
B4     1        s     d  ]]                _
C#5    2        e     d                    e-
D5     1        s     d                    ver
C#5    1        s     d                    and
B4     8        h     d                    e-
measure 49
A4     4        q     u                    ver,
C#5    4-       q     d        -           and_
C#5    4        q     d                    _
B4     2        e     u  [                 un-
A#4    2        e     u  ]                 -
measure 50
B4     6        q.    u                    to
B4     2        e     u                    the
B4     4        q     u                    Lamb
A4     3        e.    u  [      +          for_
B4     1        s     u  ]\                _
measure 51
G#4    8        h     u                    e-
A4     4        q     u                    ver,
D5     2        e     d                    bles-
D5     1        s     d                    sing
D5     1        s     d                    and
measure 52
D5     2        e     d                    ho-
B4     2        e     d                    nour,
B4     2        e     d                    glory
D5     2        e     d                    and
C#5    2        e     d                    pow'r
E5     2        e     d                    be
C#5    2        e     d                    un-
B4     1        s     u  [[                to_
A4     1        s     u  ]]                _
measure 53
D5     2        e     d                    him,
D5     2        e     d                    be
C#5    2        e     d                    un-
D5     2        e     d                    to
C#5    4        q     d                    him,
rest   4        q
measure 54
rest  16
measure 55
rest  16
measure 56
D5     2        e     d                    bles-
A4     2        e     u                    sing,
rest   4        q
D5     2        e     d                    ho-
A4     2        e     u                    nour,
rest   4        q
measure 57
D5     2        e     d                    glo-
A4     2        e     u                    ry
rest   2        e
D5     2        e     d                    and
D5     2        e     d                    po-
D5     1        s     d                    wer
D5     1        s     d                    be
D5     2        e     d                    un-
D5     2        e     d                    to
measure 58
D5     4        q     d                    him,
rest   2        e
A4     2        e     u                    that
B4     1        s     u  [[                sit-
A4     1        s     u  ]]                -
G4     1        s     u                    teth
F#4    1        s     u                    up-
E4     2        e     u                    on
A4     2        e     u                    the
measure 59
D4     2        e     u                    throne,_
D5     4        q     d                    _
C#5    2        e     d         (          _
D5     2        e     d         )          _
A4     2        e     u                    up-
B4     2        e     d                    on
C#5    1        s     d  [[                the_
D5     1        s     d  ]]                _
measure 60
C#5    4        q     d                    throne,
D5     4        q     d                    and
D5     2        e     d  [                 un-
E5     1        s     d  =[                -
F#5    1        s     d  ]]                -
G5     2        e     d                    to
G5     2        e     d                    the
measure 61
G5     2        e     d  [      (          Lamb,_
F#5    1        s     d  =[                _
E5     1        s     d  ]]                _
F#5    4        q     d         )          _
rest   8        h
measure 62
rest   4        q
rest   2        e
G5     2        e     d                    for
G5     1        s     d  [[                e-
F#5    1        s     d  ==                -
E5     1        s     d  ==                -
D5     1        s     d  ]]                -
C#5    2        e     d                    ver,
F#5    2        e     d                    for
measure 63
F#5    1        s     d  [[                e-
E5     1        s     d  ==                -
D5     1        s     d  ==                -
C#5    1        s     d  ]]                -
B4     2        e     d                    ver
E5     2        e     d                    and
E5     1        s     d  [[                e-
D5     1        s     d  ==                -
C#5    1        s     d  ==                -
B4     1        s     d  ]]                -
A4     2        e     u                    ver,
A4     2        e     u                    for
measure 64
D5     2        e     d                    e-
D5     2        e     d                    ver
rest   2        e
B4     2        e     d                    and
E5     2        e     d                    e-
E5     2        e     d                    ver,
rest   2        e
C#5    2        e     d                    for
measure 65
F#5    2        e     d                    e-
F#5    2        e     d                    ver
rest   2        e
D5     2        e     d                    and
G5     2        e     d                    e-
G5     2        e     d                    ver,
rest   2        e
E5     2        e     d                    for
measure 66
E5     2        e     d                    e-
E5     2        e     d                    ver
rest   2        e
D5     2        e     d                    and
D5     2        e     d                    e-
D5     2        e     d                    ver,
rest   2        e
E5     2        e     d                    for
measure 67
E5     1        s     d  [[                e-
D5     1        s     d  ==                -
C#5    1        s     d  ==                -
B4     1        s     d  ]]                -
A4     2        e     u                    ver,
E5     2        e     d                    for
F#5    4        q     d                    e-
G5     2        e     d                    ver
E5     2        e     d                    and
measure 68
F#5    4        q     d         (          e-
E5     3        e.    d  [                 -
D5     1        s     d  ]\     )          -
D5     4        q     d                    ver,
$ D:Adagio
rest   2        e
C#5    2        e     d                    for
measure 69
D5     8        h     d                    e-
E5     4        q     d                    ver
E5     4        q     d                    and
measure 70
D5    16        w     d                    e-
measure 71
C#5   16        w     d                    ver.
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 08
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/08} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:cc4c6db5be665b5054779697a59ccf3d]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 8 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:4   D:Largo
rest   4        q
A4     8        h     u                    Wor-
A4     4        q     u                    thy
measure 2
F#4    6        q.    u                    is
F#4    2        e     u                    the
A4     8        h     u                    Lamb,
measure 3
G4     4        q     u                    that
F#4    4        q     u                    was
E4     8        h     u                    slain,
measure 4
rest   4        q
A4     4        q     u                    and
A#4    6        q.    u                    hath
A#4    2        e     u                    re-
measure 5
B4     6        q.    u                    dee-
F#4    2        e     u                    med
F#4    4        q     u                    us
F#4    4        q     u                    to
measure 6
F#4    8        h     u                    God
B4     6        q.    u                    by
B4     2        e     u                    his
measure 7
A#4    8        h     u                    blood,
rest   2        e
$ D:Andante
F#4    2        e     u                    to
F#4    2        e     u                    re-
F#4    2        e     u                    ceive
measure 8
F#4    2        e     u                    po-
F#4    2        e     u                    wer,
rest   2        e
F#4    2        e     u                    and
A4     2        e     u                    ri-
A4     2        e     u                    ches,
rest   2        e
A4     2        e     u                    and
measure 9
A4     2        e     u                    wis-
A4     2        e     u                    dom,
rest   2        e
A4     2        e     u                    and
G4     4        q     u                    strength,
rest   2        e
G4     2        e     u                    and
measure 10
F#4    2        e     u                    ho-
F#4    2        e     u                    nour,
rest   2        e
F#4    2        e     u                    and
E4     2        e     u                    glo-
E4     2        e     u                    ry,
rest   2        e
E4     2        e     u                    and
measure 11
E4     4        q     u                    bles-
E4     4        q     u                    sing.
rest   8        h
measure 12
$ D:Largo
rest   4        q
A4     8        h     u                    Wor-
E4     4        q     u                    thy
measure 13
F#4    6        q.    u                    is
F#4    2        e     u                    the
A4     8        h     u                    Lamb,
measure 14
G#4    4        q     u                    that
A4     4        q     u                    was
G#4    8        h     u                    slain,
measure 15
rest   4        q
G#4    4        q     u                    and
E#4    6        q.    u                    hath
E#4    2        e     u                    re-
measure 16
F#4    6        q.    u                    dee-
F#4    2        e     u                    med
F#4    4        q     u                    us
A4     4        q     u                    to
measure 17
F#4    8        h     u                    God,
rest   4        q
A4     4        q     u                    to
measure 18
G#4    8        h     u                    God
G#4    6        q.    u                    by
E#4    2        e     u                    his
measure 19
F#4    8        h     u                    blood,
rest   2        e
$ D:Andante
A4     2        e     u                    to
A4     2        e     u                    re-
A4     2        e     u                    ceive
measure 20
G4     2        e     u                    po-
G4     2        e     u                    wer,
rest   2        e
G4     2        e     u                    and
A4     2        e     u                    ri-
A4     2        e     u                    ches,
rest   2        e
A4     2        e     u                    and
measure 21
G4     2        e     u                    wis-
G4     2        e     u                    dom,
rest   2        e
B4     2        e     u                    and
A4     4        q     u                    strength,
rest   2        e
A4     2        e     u                    and
measure 22
A4     2        e     u                    ho-
G4     2        e     u                    nour,
rest   2        e
G4     2        e     u                    and
A4     2        e     u                    glo-
A4     2        e     u                    ry,
rest   2        e
A4     2        e     u                    and
measure 23
A4     4        q     u                    bles-
A4     4        q     u                    sing.
rest   8        h
mdouble 24
$ D:Larghetto
rest  16
measure 25
rest  16
measure 26
rest  16
measure 27
rest  16
measure 28
rest  16
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest   8        h
E4     6        q.    u                    Bles-
F#4    1        s     u                    sing
G#4    1        s     u                    and
measure 33
A4     2        e     u                    ho-
A4     2        e     u                    nour,
A4     2        e     u                    glory
A4     2        e     u                    and
A4     2        e     u                    pow'r
A4     2        e     u                    be
A4     2        e     u                    un-
A4     2        e     u                    to
measure 34
A4     2        e     u                    him,
G#4    1        s     u  [[                be_
F#4    1        s     u  ]]                _
E4     2        e     u                    un-
D4     2        e     u                    to
C#4    4        q     u                    him
rest   4        q
measure 35
rest   2        e
E4     2        e     u                    for
F#4    2        e     u                    e-
E4     1        s     u                    ver
D4     1        s     u                    and
C#4    2        e     u                    e-
B3     2        e     u                    ver,
rest   2        e
B3     2        e     u                    for
measure 36
E4     2        e     u                    e-
A3     2        e     u                    ver,
rest   4        q
rest   4        q
rest   2        e
E4     2        e     u                    that
measure 37
F#4    1        s     u  [[                sit-
E4     1        s     u  ]]                -
D4     1        s     u                    teth
C#4    1        s     u                    up-
B3     2        e     u                    on
E4     2        e     u                    the
A3     2        e     u                    throne,_
A4     4        q     u                    _
G#4    2        e     u                    _
measure 38
F#4    2        e     u                    _
F#4    2        e     u                    up-
G#4    3        e.    u                    on
G#4    1        s     u                    the
A4     2        e     u  [                 throne,_
G#4    1        s     u  =[                _
F#4    1        s     u  =]                _
E4     2        e     u  ]                 _
A4     2        e     u                    and
measure 39
A4     4        q     u                    un-
G#4    2        e     u                    to
G#4    2        e     u                    the
A4     4        q     u                    Lamb.
rest   4        q
measure 40
rest   4        q
D4     2        e     u                    Bles-
F#4    1        s     u                    sing
G4     1        s     u                    and
A4     2        e     u                    ho-
A4     2        e     u                    nour,
A4     2        e     u                    glory
A4     2        e     u                    and
measure 41
A4     2        e     u                    pow'r
G4     1        s     u  [[                be_
F#4    1        s     u  ]]                _
E4     2        e     u                    un-
D4     2        e     u                    to
E4     4        q     u                    him,
A4     4-       q     u        -           glo-
measure 42
A4     2        e     u                    -
G4     1        s     u                    ry
F#4    1        s     u                    be
E4     2        e     u                    un-
D4     2        e     u                    to
E4     4        q     u                    him,
rest   4        q
measure 43
rest   4        q
rest   2        e
A4     2        e     u                    that
B4     1        s     u  [[                sit-
A4     1        s     u  ]]                -
G4     1        s     u                    teth
F#4    1        s     u                    up-
E4     2        e     u                    on
A4     2        e     u                    the
measure 44
D4     2        e     u  [                 throne,_
E4     1        s     u  =[                _
F#4    1        s     u  ]]                _
G4     2        e     u  [                 _
F#4    1        s     u  =[                _
E4     1        s     u  ]]                _
F#4    2        e     u  [                 _
G4     1        s     u  =[                _
A4     1        s     u  ]]                _
B4     2        e     u  [                 _
A4     1        s     u  =[                _
G4     1        s     u  ]]                _
measure 45
A4     2        e     u  [                 _
G4     1        s     u  =[                _
F#4    1        s     u  ]]                _
G4     1        s     u  [[                _
F#4    1        s     u  ==                _
G4     1        s     u  ==                _
E4     1        s     u  ]]                _
F#4    4        q     u                    _
rest   4        q
measure 46
rest   8        h
rest   4        q
rest   2        e
E4     2        e     u                    that
measure 47
F#4    1        s     u  [[                sit-
E4     1        s     u  ]]                -
D4     1        s     u                    teth
C#4    1        s     u                    up-
B3     2        e     u                    on
G#4    2        e     u                    the
A4     6        q.    u                    throne
A3     2        e     u                    for
measure 48
B3     4        q     u                    e-
A3     2        e     u                    ver
A4     2        e     u                    and
A4     4        q     u         (          e-
G#4    4        q     u         )          -
measure 49
A4     4        q     u                    ver,
A4     4-       q     u        -           and_
A4     4        q     u                    _
F#4    4        q     u                    un-
measure 50
F#4    6        q.    u                    to
G#4    2        e     u                    the
G#4    4        q     u                    Lamb
F#4    4-       q     u        -           for_
measure 51
F#4    4        q     u                    _
E#4    4        q     u                    e-
F#4    4        q     u                    ver,
F#4    2        e     u                    bles-
G4     1        s     u         +          sing
A4     1        s     u                    and
measure 52
B4     2        e     u                    ho-
G4     2        e     u                    nour,
G4     2        e     u                    glory
B4     2        e     u                    and
A4     2        e     u                    pow'r
A4     2        e     u                    be
A4     2        e     u                    un-
A4     2        e     u                    to
measure 53
A4     2        e     u                    him,
A4     2        e     u                    be
G4     2        e     u                    un-
F#4    2        e     u                    to
E4     4        q     u                    him,
A3     2        e     u                    bles-
B3     1        s     u                    sing
C#4    1        s     u                    and
measure 54
D4     2        e     u                    ho-
D4     2        e     u                    nour,
D4     2        e     u                    glory
D4     2        e     u                    and
D4     2        e     u                    pow'r
D4     2        e     u                    be
D4     2        e     u                    un-
D4     2        e     u                    to
measure 55
D4     2        e     u                    him,
C#4    1        s     u  [[                be_
B3     1        s     u  ]]                _
A3     2        e     u                    un-
G3     2        e     u                    to
F#3    4        q     u                    him,
rest   4        q
measure 56
A4     2        e     u                    bles-
F#4    2        e     u                    sing,
rest   4        q
A4     2        e     u                    ho-
F#4    2        e     u                    nour,
rest   4        q
measure 57
A4     2        e     u                    glo-
F#4    2        e     u                    ry
rest   2        e
A4     2        e     u                    and
A4     2        e     u                    po-
A4     1        s     u                    wer
A4     1        s     u                    be
G4     2        e     u                    un-
B4     2        e     u                    to
measure 58
A4     4        q     u                    him,
rest   2        e
A4     2        e     u                    that
B4     1        s     u  [[                sit-
A4     1        s     u  ]]                -
G4     1        s     u                    teth
F#4    1        s     u                    up-
E4     2        e     u                    on
A4     2        e     u                    the
measure 59
D4     2        e     u  [                 throne,_
E4     1        s     u  =[                _
F#4    1        s     u  ]]                _
G4     2        e     u  [                 _
A4     1        s     u  =[                _
G4     1        s     u  ]]                _
A4     1        s     u  [[                _
G4     1        s     u  ==                _
F#4    1        s     u  ==                _
E4     1        s     u  ]]                _
D4     2        e     u  [                 _
G4     1        s     u  =[                _
F#4    1        s     u  ]]                _
measure 60
E4     2        e     u  [                 _
F#4    1        s     u  =[                _
G4     1        s     u  =]                _
A4     2        e     u  ]                 _
A4     2        e     u                    and
A4     4        q     u                    un-
G4     2        e     u                    to
G4     2        e     u                    the
measure 61
A4     4        q     u                    Lamb,
rest   2        e
A4     2        e     u                    for
B4     1        s     u  [[                e-
A4     1        s     u  ==                -
G4     1        s     u  ==                -
F#4    1        s     u  ]]                -
E4     2        e     u                    ver,
A4     2        e     u                    for
measure 62
A4     1        s     u  [[                e-
G4     1        s     u  ==                -
F#4    1        s     u  ==                -
E4     1        s     u  ]]                -
D4     2        e     u                    ver,
B4     2        e     u                    for
A4     2        e     u                    e-
A4     2        e     u                    ver,
rest   2        e
A4     2        e     u                    for
measure 63
G4     2        e     u                    e-
G4     2        e     u                    ver
rest   2        e
G4     2        e     u                    and
F#4    2        e     u                    e-
F#4    2        e     u                    ver,
rest   2        e
F#4    2        e     u                    for
measure 64
A4     1        s     u  [[                e-
G4     1        s     u  ==                -
F#4    1        s     u  ==                -
E4     1        s     u  ]]                -
D4     2        e     u                    ver
D4     2        e     u                    and
G4     2        e     u                    e-
G4     2        e     u                    ver,
rest   2        e
E4     2        e     u                    for
measure 65
A4     2        e     u                    e-
A4     2        e     u                    ver
rest   2        e
F#4    2        e     u                    and
B4     2        e     u                    e-
B4     2        e     u                    ver,
rest   2        e
A4     2        e     u                    for
measure 66
A4     2        e     u                    e-
A4     2        e     u                    ver
rest   2        e
A4     2        e     u                    and
B4     1        s     u  [[                e-
A4     1        s     u  ==                -
G4     1        s     u  ==                -
F#4    1        s     u  ]]                -
E4     1        s     u  [[                -
D4     1        s     u  ==                -
C#4    1        s     u  ==                -
B3     1        s     u  =]                -
measure 67
A3     2        e     u  ]                 -
A3     2        e     u                    ver,
rest   2        e
A4     2        e     u                    for
A4     4        q     u                    e-
G4     2        e     u                    ver
B4     2        e     u                    and
measure 68
A4     8        h     u                    e-
A4     4        q     u                    ver,
$ D:Adagio
rest   2        e
A4     2        e     u                    for
measure 69
A4     8        h     u                    e-
A4     4        q     u                    ver
A4     4        q     u                    and
measure 70
A4     8        h     u         (          e-
G#4    8        h     u         )          -
measure 71
A4    16        w     u                    ver.
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 09
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/09} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:328b26de5d8c395b904392a5b516affe]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 9 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:34   D:Largo
rest   4        q
F#4    8        h     d                    Wor-
E4     4        q     d                    thy
measure 2
D4     6        q.    d                    is
D4     2        e     d                    the
D4     8        h     d                    Lamb,
measure 3
E4     4        q     d                    that
A3     4        q     u                    was
C#4    8        h     d                    slain,
measure 4
rest   4        q
E4     4        q     d                    and
E4     6        q.    d                    hath
E4     2        e     d                    re-
measure 5
D4     6        q.    d                    dee-
D4     2        e     d                    med
D4     4        q     d                    us
D4     4        q     d                    to
measure 6
C#4    8        h     d                    God
D4     4        q     d                    by
B3     4        q     d                    his
measure 7
C#4    8        h     d                    blood,
rest   2        e
$ D:Andante
A#3    2        e     u                    to
A#3    2        e     u                    re-
A#3    2        e     u                    ceive
measure 8
B3     2        e     d                    po-
B3     2        e     d                    wer,
rest   2        e
B3     2        e     d                    and
E4     2        e     d                    ri-
E4     2        e     d                    ches,
rest   2        e
E4     2        e     d                    and
measure 9
D4     2        e     d                    wis-
D4     2        e     d                    dom,
rest   2        e
F#4    2        e     d                    and
E4     4        q     d                    strength,
rest   2        e
E4     2        e     d                    and
measure 10
A3     2        e     u                    ho-
A3     2        e     u                    nour,
rest   2        e
A3     2        e     u                    and
B3     2        e     u                    glo-
B3     2        e     u                    ry,
rest   2        e
B3     2        e     u                    and
measure 11
C#4    4        q     d                    bles-
C#4    4        q     d                    sing.
rest   8        h
measure 12
$ D:Largo
rest   4        q
E4     8        h     d                    Wor-
E4     4        q     d                    thy
measure 13
C#4    6        q.    d                    is
C#4    2        e     d                    the
E4     8        h     d                    Lamb,
measure 14
B3     4        q     d                    that
E4     4        q     d                    was
E4     8        h     d                    slain,
measure 15
rest   4        q
E3     4        q     u                    and
G#3    6        q.    u                    hath
C#4    2        e     d                    re-
measure 16
C#4    6        q.    d                    dee-
C#4    2        e     d                    med
C#4    4        q     d                    us
F#4    4        q     d                    to
measure 17
D4     8        h     d                    God,
rest   4        q
F#4    4        q     d                    to
measure 18
F#4    8        h     d                    God
E#4    6        q.    d                    by
C#4    2        e     d                    his
measure 19
C#4    8        h     d                    blood,
rest   2        e
$ D:Andante
F#4    2        e     d                    to
F#4    2        e     d                    re-
F#4    2        e     d                    ceive
measure 20
E4     2        e     d                    po-
E4     2        e     d                    wer,
rest   2        e
E4     2        e     d                    and
D4     2        e     d                    ri-
D4     2        e     d                    ches,
rest   2        e
F#4    2        e     d                    and
measure 21
D4     2        e     d                    wis-
D4     2        e     d                    dom,
rest   2        e
G4     2        e     d                    and
E4     4        q     d                    strength,
rest   2        e
F#4    2        e     d                    and
measure 22
F#4    2        e     d                    ho-
D4     2        e     d                    nour,
rest   2        e
D4     2        e     d                    and
E4     2        e     d                    glo-
E4     2        e     d                    ry,
rest   2        e
E4     2        e     d                    and
measure 23
F#4    4        q     d                    bles-
F#4    4        q     d                    sing.
rest   8        h
mdouble 24
$ D:Larghetto
A3     6        q.    u                    Bles-
B3     1        s     u                    sing
C#4    1        s     d                    and
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
measure 25
D4     2        e     d                    pow'r
D4     2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
D4     2        e     d                    him,
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     u                    un-
G3     2        e     u                    to
measure 26
F#3    4        q     u                    him,
rest   2        e
A3     2        e     u                    that
B3     1        s     u  [[                sit-
A3     1        s     u  ]]                -
G3     1        s     u                    teth
F#3    1        s     u                    up-
E3     2        e     u                    on
A3     2        e     u                    the
measure 27
D3     2        e     u         (          throne,_
D4     4        q     d         )          _
C#4    2        e     d                    and
B3     2        e     u  [                 un-
A3     2        e     u  ]                 -
B3     3        e.    u                    to
A3     1        s     u                    the
measure 28
A3     4        q     u                    Lamb,
rest   4        q
rest   8        h
measure 29
rest  16
measure 30
rest   8        h
rest   4        q
rest   2        e
A3     2        e     u                    that
measure 31
B3     1        s     u  [[                sit-
A3     1        s     u  ]]                -
G3     1        s     u                    teth
F#3    1        s     u                    up-
E3     2        e     u                    on
A3     2        e     u                    the
D3     2        e     u         (          throne,_
D4     4        q     d         )          _
C#4    2        e     d                    and
measure 32
F#3    2        e     u  [                 un-
B3     2        e     u  ]                 -
G#3    3        e.    u                    to
G#3    1        s     u                    the
A3     4        q     u                    Lamb,
rest   4        q
measure 33
rest   2        e
C#4    2        e     d                    for
D4     2        e     d                    e-
C#4    1        s     d                    ver
B3     1        s     d                    and
C#4    2        e     d                    e-
A3     1        s     u                    ver,
B3     1        s     u                    for
C#4    2        e     d                    e-
B3     1        s     u                    ver
A3     1        s     u                    and
measure 34
E4     2        e     d                    e-
E4     2        e     d                    ver,
rest   4        q
rest   2        e
E4     2        e     d                    for
F#4    2        e     d                    e-
E4     1        s     d                    ver
D4     1        s     d                    and
measure 35
C#4    2        e     d                    e-
A3     2        e     u                    ver,
rest   4        q
rest   2        e
E4     2        e     d                    for
G#4    2        e     d                    e-
F#4    1        s     d                    ver
E4     1        s     d                    and
measure 36
A4     2        e     d  [                 e-
G#4    1        s     d  =[                -
F#4    1        s     d  ]]                -
E4     1        s     d  [[                -
D4     1        s     d  ==                -
C#4    1        s     d  ==                -
B3     1        s     d  =]                -
A3     2        e     d  ]                 -
A3     2        e     u                    ver,
rest   4        q
measure 37
rest  16
measure 38
rest   8        h
rest   4        q
rest   2        e
E4     2        e     d                    and
measure 39
F#4    1        s     d  [[                un-
E4     1        s     d  ==                -
D4     1        s     d  ==                -
C#4    1        s     d  ]]                -
B3     2        e     d                    to
E4     2        e     d                    the
E4     4        q     d                    Lamb.
rest   4        q
measure 40
rest  16
measure 41
rest   8        h
rest   4        q
A3     2        e     u                    Bles-
B3     1        s     u                    sing
C#4    1        s     d                    and
measure 42
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
D4     2        e     d                    pow'r
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     u                    un-
G3     2        e     u                    to
measure 43
F#3    4        q     u                    him,
rest   2        e
F#3    2        e     u                    and
G3     4        q     u                    un-
A3     2        e     u                    to
C#4    2        e     d                    the
measure 44
D4     4        q     d                    Lamb.
rest   4        q
rest   8        h
measure 45
rest  16
measure 46
rest  16
measure 47
rest   8        h
rest   4        q
A3     2        e     u                    Bles-
C#4    1        s     d                    sing
D4     1        s     d                    and
measure 48
E4     2        e     d                    ho-
E4     2        e     d                    nour,
E4     2        e     d                    glory
E4     2        e     d                    and
E4     2        e     d                    pow'r
E4     2        e     d                    be
E4     3        e.    d                    un-
D4     1        s     d                    to
measure 49
C#4    4        q     d                    him,
C#4    2        e     d                    bles-
D4     1        s     d                    sing
E4     1        s     d                    and
F#4    2        e     d                    ho-
F#4    2        e     d                    nour,
F#4    2        e     d                    glory
F#4    2        e     d                    and
measure 50
F#4    2        e     d                    pow'r
F#4    2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
C#4    4        q     d                    him
C#4    4        q     d                    for
measure 51
C#4    8        h     d                    e-
C#4    4        q     d                    ver,
D4     2        e     d                    bles-
E4     1        s     d                    sing
F#4    1        s     d                    and
measure 52
G4     2        e     d                    ho-
G4     2        e     d                    nour,
G4     2        e     d                    glory
G4     2        e     d                    and
G4     2        e     d                    pow'r
G4     2        e     d                    be
G4     2        e     d                    un-
G4     2        e     d                    to
measure 53
F#4    2        e     d                    him,
F#4    2        e     d                    be
E4     2        e     d                    un-
D4     2        e     d                    to
A3     4        q     u                    him,
A3     2        e     u                    bles-
B3     1        s     u                    sing
C#4    1        s     d                    and
measure 54
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
D4     2        e     d                    pow'r
D4     2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
measure 55
D4     2        e     d                    him,
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     u                    un-
G3     2        e     u                    to
F#3    4        q     u                    him,
rest   4        q
measure 56
F#4    2        e     d                    bles-
D4     2        e     d                    sing,
rest   4        q
F#4    2        e     d                    ho-
D4     2        e     d                    nour,
rest   4        q
measure 57
F#4    2        e     d                    glo-
D4     2        e     d                    ry
rest   2        e
F#4    2        e     d                    and
F#4    2        e     d                    po-
F#4    1        s     d                    wer
F#4    1        s     d                    be
D4     2        e     d                    un-
G4     2        e     d                    to
measure 58
F#4    4        q     d                    him,
rest   4        q
rest   8        h
measure 59
rest   4        q
rest   2        e
E4     2        e     d                    that
F#4    1        s     d  [[                sit-
E4     1        s     d  ]]                -
D4     1        s     d                    teth
C#4    1        s     d                    up-
B3     2        e     d                    on
E4     2        e     d                    the
measure 60
A3     4        q     u                    throne,
rest   2        e
F#4    2        e     d                    and
F#4    2        e     d  [                 un-
D4     2        e     d  ]                 -
D4     2        e     d                    to
D4     2        e     d                    the
measure 61
D4     4        q     d                    Lamb,
rest   2        e
F#4    2        e     d                    for
G4     1        s     d  [[                e-
F#4    1        s     d  ==                -
E4     1        s     d  ==                -
D4     1        s     d  ]]                -
C#4    2        e     d                    ver,
C#4    2        e     d                    for
measure 62
D4     2        e     d                    e-
D4     2        e     d                    ver,
rest   2        e
D4     2        e     d                    for
C#4    2        e     d                    e-
C#4    2        e     d                    ver,
rest   2        e
C#4    2        e     d                    for
measure 63
B3     2        e     d                    e-
B3     2        e     d                    ver
rest   2        e
C#4    2        e     d                    and
A3     2        e     u                    e-
A3     2        e     u                    ver,
rest   2        e
D4     2        e     d                    for
measure 64
D4     2        e     d                    e-
A3     2        e     u                    ver
rest   2        e
B3     2        e     u                    and
B3     1        s     u  [[                e-
A3     1        s     u  ==                -
G3     1        s     u  ==                -
F#3    1        s     u  ]]                -
E3     2        e     u                    ver,
C#4    2        e     d                    for
measure 65
C#4    1        s     u  [[                e-
B3     1        s     u  ==                -
A3     1        s     u  ==                -
G3     1        s     u  ]]                -
F#3    2        e     u                    ver
D4     2        e     d                    and
D4     1        s     d  [[                e-
C#4    1        s     d  ==                -
B3     1        s     d  ==                -
A3     1        s     d  ]]                -
G3     2        e     u                    ver,
E4     2        e     d                    for
measure 66
E4     1        s     d  [[                e-
D4     1        s     d  ==                -
C#4    1        s     d  ==                -
B3     1        s     d  ]]                -
A3     2        e     u                    ver
F#4    2        e     d                    and
F#4    2        e     d                    e-
B3     2        e     d                    ver,
rest   2        e
C#4    2        e     d                    for
measure 67
C#4    1        s     d  [[                e-
B3     1        s     d  ==                -
A3     1        s     d  ==                -
B3     1        s     d  ]]                -
C#4    2        e     d                    ver,
E4     2        e     d                    for
D4     4        q     d                    e-
D4     2        e     d                    ver
D4     2        e     d                    and
measure 68
D4     4        q     d         (          e-
C#4    4        q     d         )          -
F#4    4        q     d                    ver,
$ D:Adagio
rest   2        e
E4     2        e     d                    for
measure 69
F#4    8        h     d                    e-
E4     4        q     d                    ver
E4     4        q     d                    and
measure 70
F#4    8        h     d         (          e-
D4     8        h     d         )          -
measure 71
E4    16        w     d                    ver.
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 10
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/10} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:bff2a06aaaba60995d42a2f4ce92c188]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 10 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Largo
rest   4        q
D4     8        h     d                    Wor-
C#4    4        q     d                    thy
measure 2
B3     6        q.    d                    is
B3     2        e     d                    the
F#3    8        h     d                    Lamb,
measure 3
E3     4        q     d                    that
D3     4        q     d                    was
A3     8        h     d                    slain,
measure 4
rest   4        q
G3     4        q     d                    and
F#3    6        q.    d                    hath
F#3    2        e     d                    re-
measure 5
B3     6        q.    d                    dee-
B3     2        e     d                    med
B3     4        q     d                    us
B3     4        q     d                    to
measure 6
A3     8        h     d                    God
G3     6        q.    d                    by
G3     2        e     d                    his
measure 7
F#3    8        h     d                    blood,
rest   2        e
$ D:Andante
F#3    2        e     d                    to
F#3    2        e     d                    re-
F#3    2        e     d                    ceive
measure 8
B3     2        e     d                    po-
B3     2        e     d                    wer,
rest   2        e
B3     2        e     d                    and
C#4    2        e     d                    ri-
C#4    2        e     d                    ches,
rest   2        e
C#4    2        e     d                    and
measure 9
D4     2        e     d                    wis-
D3     2        e     d                    dom,
rest   2        e
D3     2        e     d                    and
E3     4        q     d                    strength,
rest   2        e
E3     2        e     d                    and
measure 10
F#3    2        e     d                    ho-
F#3    2        e     d                    nour,
rest   2        e
F#3    2        e     d                    and
G#3    2        e     d                    glo-
G#3    2        e     d                    ry,
rest   2        e
G#3    2        e     d                    and
measure 11
A3     4        q     d                    bles-
A2     4        q     u                    sing.
rest   8        h
measure 12
$ D:Largo
rest   4        q
A3     8        h     d                    Wor-
G#3    4        q     d                    thy
measure 13
F#3    6        q.    d                    is
F#3    2        e     d                    the
C#4    8        h     d                    Lamb,
measure 14
B3     4        q     d                    that
A3     4        q     d                    was
E3     8        h     d                    slain,
measure 15
rest   4        q
D3     4        q     d                    and
C#3    6        q.    u                    hath
C#3    2        e     u                    re-
measure 16
F#3    6        q.    d                    dee-
F#3    2        e     d                    med
F#3    4        q     d                    us
F#3    4        q     d                    to
measure 17
B3     8        h     d                    God,
rest   4        q
F#3    4        q     d                    to
measure 18
C#4    8        h     d                    God
C#3    6        q.    u                    by
C#3    2        e     u                    his
measure 19
F#3    8        h     d                    blood,
rest   2        e
$ D:Andante
D3     2        e     d                    to
D3     2        e     d                    re-
D3     2        e     d                    ceive
measure 20
E3     2        e     d                    po-
E3     2        e     d                    wer,
rest   2        e
E3     2        e     d                    and
F#3    2        e     d                    ri-
F#3    2        e     d                    ches,
rest   2        e
F#3    2        e     d                    and
measure 21
G3     2        e     d                    wis-
G3     2        e     d                    dom,
rest   2        e
G3     2        e     d                    and
A3     4        q     d                    strength,
rest   2        e
A3     2        e     d                    and
measure 22
B3     2        e     d                    ho-
B3     2        e     d                    nour,
rest   2        e
B3     2        e     d                    and
C#4    2        e     d                    glo-
C#4    2        e     d                    ry,
rest   2        e
C#4    2        e     d                    and
measure 23
D4     4        q     d                    bles-
D3     4        q     d                    sing.
rest   8        h
mdouble 24
$ D:Larghetto
A3     6        q.    d                    Bles-
B3     1        s     d                    sing
C#4    1        s     d                    and
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
measure 25
D4     2        e     d                    pow'r
D4     2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
D4     2        e     d                    him,
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     d                    un-
G3     2        e     d                    to
measure 26
F#3    4        q     d                    him,
rest   2        e
A3     2        e     d                    that
B3     1        s     d  [[                sit-
A3     1        s     d  ]]                -
G3     1        s     d                    teth
F#3    1        s     d                    up-
E3     2        e     d                    on
A3     2        e     d                    the
measure 27
D3     2        e     d         (          throne,_
D4     4        q     d         )          _
C#4    2        e     d                    and
B3     2        e     d  [                 un-
A3     2        e     d  ]                 -
B3     3        e.    d                    to
A3     1        s     d                    the
measure 28
A3     4        q     d                    Lamb.
rest   4        q
rest   8        h
measure 29
rest  16
measure 30
rest  16
measure 31
rest  16
measure 32
rest  16
measure 33
rest  16
measure 34
rest   4        q
E3     2        e     d                    Bles-
F#3    1        s     d                    sing
G#3    1        s     d                    and
A3     2        e     d                    ho-
A3     2        e     d                    nour,
A3     2        e     d                    glory
A3     2        e     d                    and
measure 35
A3     2        e     d                    pow'r
A3     2        e     d                    be
A3     2        e     d                    un-
A3     2        e     d                    to
A3     2        e     d                    him,
G#3    1        s     d  [[                be_
F#3    1        s     d  ]]                _
E3     2        e     d                    un-
D3     2        e     d                    to
measure 36
C#3    4        q     u                    him,
rest   2        e
E3     2        e     d                    that
F#3    1        s     d  [[                sit-
E3     1        s     d  ]]                -
D3     1        s     d                    teth
C#3    1        s     u                    up-
B2     2        e     u                    on
E3     2        e     d                    the
measure 37
A2     2        e     u                    throne,_
A3     4        q     d                    _
G#3    2-       e     d        -           _
G#3    2        e     d                    _
F#3    2        e     d                    up-
E3     3        e.    d                    on
E3     1        s     d                    the
measure 38
D3     2        e     d                    throne,
D3     2        e     d                    up-
E3     3        e.    d                    on
E3     1        s     d                    the
F#3    3        e.    d  [                 throne,_
G#3    1        s     d  =\                _
A3     2        e     d  ]                 _
A3     2        e     d                    and
measure 39
D3     4        q     d                    un-
E3     2        e     d                    to
E3     2        e     d                    the
A2     4        q     u                    Lamb.
A3     2        e     d                    Bles-
B3     1        s     d                    sing
C#4    1        s     d                    and
measure 40
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
D4     2        e     d                    pow'r
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     d                    un-
G3     2        e     d                    to
measure 41
F#3    4        q     d                    him
rest   2        e
B3     2        e     d                    for
A3     2        e     d                    e-
A3     2        e     d                    ver,
rest   4        q
measure 42
rest  16
measure 43
rest   8        h
rest   4        q
rest   2        e
A3     2        e     d                    that
measure 44
B3     1        s     d  [[                sit-
A3     1        s     d  ]]                -
G3     1        s     d                    teth
F#3    1        s     d                    up-
E3     2        e     d                    on
A3     2        e     d                    the
D3     2        e     d  [                 throne,_
E3     1        s     d  =[                _
F#3    1        s     d  ]]                _
G3     2        e     d  [                 _
F#3    1        s     d  =[                _
E3     1        s     d  ]]                _
measure 45
F#3    2        e     d  [                 _
G3     1        s     d  =[                _
A3     1        s     d  ]]                _
B3     1        s     d  [[                _
A3     1        s     d  ==                _
B3     1        s     d  ==                _
C#4    1        s     d  ]]                _
D4     2        e     d  [                 _
A3     2        e     d  ]                 _
D4     4-       q     d        -           _
measure 46
D4     4        q     d                    _
C#4    4        q     d                    _
B3     4        q     d                    _
A3     4        q     d                    and
measure 47
D3     4        q     d                    un-
E3     2        e     d                    to
E3     2        e     d                    the
F#3    6        q.    d                    Lamb
F#3    2        e     d                    for
measure 48
G#3    4        q     d                    e-
A3     2        e     d                    ver
A3     2        e     d                    and
E3     8        h     d                    e-
measure 49
A2     4        q     u                    ver,
A3     2        e     d                    bles-
B3     1        s     d                    sing
C#4    1        s     d                    and
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
measure 50
D4     2        e     d                    pow'r
D4     2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
E#3    4        q     d                    him
F#3    4        q     d                    for
measure 51
C#3    8        h     u                    e-
F#3    4        q     d                    ver,
rest   4        q
measure 52
rest  16
measure 53
rest   8        h
rest   4        q
A3     2        e     d                    bles-
B3     1        s     d                    sing
C#4    1        s     d                    and
measure 54
D4     2        e     d                    ho-
D4     2        e     d                    nour,
D4     2        e     d                    glory
D4     2        e     d                    and
D4     2        e     d                    pow'r
D4     2        e     d                    be
D4     2        e     d                    un-
D4     2        e     d                    to
measure 55
D4     2        e     d                    him,
C#4    1        s     d  [[                be_
B3     1        s     d  ]]                _
A3     2        e     d                    un-
G3     2        e     d                    to
F#3    4        q     d                    him,
rest   4        q
measure 56
D4     2        e     d                    bles-
D3     2        e     d                    sing,
rest   4        q
D4     2        e     d                    ho-
D3     2        e     d                    nour,
rest   4        q
measure 57
D4     2        e     d                    glo-
D3     2        e     d                    ry
rest   2        e
D3     2        e     d                    and
D4     2        e     d                    po-
D4     1        s     d                    wer
D4     1        s     d                    be
B3     2        e     d                    un-
G3     2        e     d                    to
measure 58
D4     4        q     d                    him,
rest   4        q
rest   4        q
rest   2        e
A3     2        e     d                    that
measure 59
B3     1        s     d  [[                sit-
A3     1        s     d  ]]                -
G3     1        s     d                    teth
F#3    1        s     d                    up-
E3     2        e     d                    on
A3     2        e     d                    the
D3     4        q     d                    throne,
G3     4-       q     d        -           and_
measure 60
G3     2        e     d                    _
F#3    1        s     d  [[                un-
E3     1        s     d  ]]                -
F#3    2        e     d                    to
D3     2        e     d                    the
B3     2        e     d                    Lamb,
B3     2        e     d                    un-
B3     2        e     d                    to
A3     1        s     d  [[                the_
G3     1        s     d  ]]                _
measure 61
D4     4        q     d                    Lamb,
rest   4        q
rest   4        q
rest   2        e
F#3    2        e     d                    for
measure 62
B3     2        e     d                    e-
B3     2        e     d                    ver,
rest   2        e
E3     2        e     d                    for
A3     2        e     d                    e-
A3     2        e     d                    ver,
rest   2        e
D3     2        e     d                    for
measure 63
G3     2        e     d                    e-
G3     2        e     d                    ver
rest   2        e
E3     2        e     d                    and
F#3    2        e     d                    e-
F#3    2        e     d                    ver,
rest   2        e
F#3    2        e     d                    for
measure 64
F#3    1        s     d  [[                e-
E3     1        s     d  ==                -
D3     1        s     d  ==                -
C#3    1        s     d  ]]                -
B2     2        e     u                    ver
G3     2        e     d                    and
G3     1        s     d  [[                e-
F#3    1        s     d  ==                -
E3     1        s     d  ==                -
D3     1        s     d  ]]                -
C#3    2        e     u                    ver,
A3     2        e     d                    for
measure 65
A3     1        s     d  [[                e-
G3     1        s     d  ==                -
F#3    1        s     d  ==                -
E3     1        s     d  ]]                -
D3     2        e     d                    ver
B3     2        e     d                    and
B3     1        s     d  [[                e-
A3     1        s     d  ==                -
G3     1        s     d  ==                -
F#3    1        s     d  ]]                -
E3     2        e     d                    ver,
C#4    2        e     d                    for
measure 66
C#4    1        s     d  [[                e-
B3     1        s     d  ==                -
A3     1        s     d  ==                -
G3     1        s     d  ]]                -
F#3    2        e     d                    ver
D4     2        e     d                    and
D4     1        s     d  [[                e-
C#4    1        s     d  ==                -
B3     1        s     d  ==                -
A3     1        s     d  ]]                -
G3     1        s     d  [[                -
F#3    1        s     d  ==                -
E3     1        s     d  ==                -
D3     1        s     d  =]                -
measure 67
C#3    2        e     d  ]                 -
C#3    2        e     u                    ver,
rest   2        e
C#4    2        e     d                    for
D4     4        q     d                    e-
B3     2        e     d                    ver
G3     2        e     d                    and
measure 68
A3     8        h     d                    e-
D3     4        q     d                    ver,
$ D:Adagio
rest   2        e
A3     2        e     d                    for
measure 69
D4     8        h     d                    e-
C#4    4        q     d                    ver
C#4    4        q     d                    and
measure 70
B3    16        w     d                    e-
measure 71
A3    16        w     d                    ver.
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 11
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-09/11} [KHM:3599406355]
TIMESTAMP: DEC/26/2001 [md5sum:c21b0e947585a1203929131e69ce6572]
06/26/90 E. Correia
WK#:56        MV#:3,9
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 11 of 11
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:1/1   C:22   D:Largo
D3     4        q     u
D3     8        h     u
C#3    4        q     u
measure 2
B2     6        q.    u
B3     2        e     d
f1              6
F#3    8        h     d
measure 3
f1              6
E3     4        q     d
D3     4        q     d
A3     8        h     d
measure 4
rest   4        q
f2              4 3
G3     4        q     d
f2              7 #
F#3    6        q.    d
F#3    2        e     d
measure 5
B3     6        q.    d
B3     2        e     d
B3     4        q     d
B3     4        q     d
measure 6
f1              6
A3     8        h     d
f1              7
G3     6        q.    d
f1              6
G3     2        e     d
measure 7
f1              #
F#3    8        h     d
rest   2        e
$ D:Andante
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  ]
measure 8
B3     2        e     d  [
B3     2        e     d  ]
rest   2        e
B3     2        e     d
C#4    2        e     d  [
C#4    2        e     d  ]
rest   2        e
C#4    2        e     d
measure 9
D4     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
E3     4        q     d
rest   2        e
E3     2        e     d
measure 10
F#3    2        e     d  [
F#3    2        e     d  ]
rest   2        e
F#3    2        e     d
G#3    2        e     d  [
G#3    2        e     d  ]
rest   2        e
G#3    2        e     d
measure 11
A3     4        q     d
A2     4        q     u
rest   8        h
measure 12
$ D:Largo
A2     4        q     u
A3     8        h     d
f1              6
G#3    4        q     d
measure 13
F#3    6        q.    d
F#3    2        e     d
f1              6
C#3    8        h     u
measure 14
f1              6+
B2     4        q     u
A2     4        q     u
f1              #
E3     8        h     d
measure 15
rest   4        q
f2              4+ 2
D3     4        q     u
f2              7 #
C#3    6        q.    u
C#3    2        e     u
measure 16
F#3    6        q.    d
F#3    2        e     d
F#3    4        q     d
F#3    4        q     d
measure 17
B3     8        h     d
rest   4        q
F#3    4        q     d
measure 18
f1              4
C#4    8        h     d
f1              #
C#3    6        q.    u
C#3    2        e     u
measure 19
F#3    8        h     d
rest   2        e
$ D:Andante
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  ]
measure 20
f1              6
E3     2        e     d  [
E3     2        e     d  ]
rest   2        e
E3     2        e     d
f1              6
F#3    2        e     d  [
F#3    2        e     d  ]
rest   2        e
F#3    2        e     d
measure 21
G3     2        e     d  [
G3     2        e     d  ]
rest   2        e
G3     2        e     d
A3     4        q     d
rest   2        e
f1              6
A3     2        e     d
measure 22
f1              7
B3     2        e     d  [
f1              6
B3     2        e     d  ]
rest   2        e
B3     2        e     d
f1              6
C#4    2        e     d  [
C#4    2        e     d  ]
rest   2        e
C#4    2        e     d
measure 23
D4     4        q     d
D3     4        q     d
rest   8        h
mdouble 24
$ D:Larghetto
*               D       Tasto solo
A3     6        q.    d
B3     1        s     d  [[
C#4    1        s     d  ]]
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 25
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
A3     2        e     d  [
G3     2        e     d  ]
measure 26
F#3    4        q     d
rest   2        e
A3     2        e     d
B3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F#3    1        s     d  ]]
E3     2        e     d  [
A3     2        e     d  ]
measure 27
D3     2        e     d
D4     4        q     d
C#4    2        e     d
B3     2        e     d  [
A3     2        e     d  ]
B3     4        q     d
measure 28
A3     4        q     d
$ C:15
*               D       Tasto solo
A4     2        e     d  [
B4     1        s     d  =[
C#5    1        s     d  ]]
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
measure 29
D5     2        e     d  [
D5     2        e     d  =
D5     2        e     d  =
D5     2        e     d  ]
D5     2        e     d  [
C#5    1        s     d  =[
B4     1        s     d  ]]
A4     2        e     d  [
G4     2        e     d  ]
measure 30
F#4    4        q     u
rest   2        e
A4     2        e     d
B4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s     d  ]]
E4     2        e     d  [
$ C:12
A3     2        e     d  ]
measure 31
B3     1        s     u  [[
A3     1        s     u  ==
G3     1        s     u  ==
F#3    1        s     u  ]]
E3     2        e     u  [
A3     2        e     u  ]
D3     2        e     u
f1     2        3
f1              2
D4     4        q     d
f1              6
C#4    2        e     d
measure 32
F#3    2        e     u  [
B3     2        e     u  =
G#3    3        e.    u  =
G#3    1        s     u  ]\
f1     4        4
f1              3
A3     8        h     d
measure 33
rest   2        e
f1              6
C#4    2        e     d
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
C#4    2        e     d  [
A3     1        s     d  =[
B3     1        s     d  ]]
C#4    2        e     d  [
B3     1        s     d  =[
A3     1        s     d  ]]
measure 34
f1     2        4
f1              #
E4     4        q     d
$ C:22
E3     2        e     d  [
F#3    1        s     d  =[
G#3    1        s     d  ]]
f2              5 3
A3     2        e     d  [
A3     2        e     d  =
f2              6 4
A3     2        e     d  =
A3     2        e     d  ]
measure 35
f2              5 3
A3     2        e     d  [
A3     2        e     d  =
f2              6 4
A3     2        e     d  =
A3     2        e     d  ]
A3     2        e     d  [
G#3    1        s     d  =[
F#3    1        s     d  ]]
f1              #
E3     2        e     d  [
D3     2        e     d  ]
measure 36
C#3    4        q     u
rest   2        e
E3     2        e     d
F#3    1        s     d  [[
E3     1        s     d  ==
D3     1        s     d  ==
C#3    1        s     d  ]]
B2     2        e     d  [
E3     2        e     d  ]
measure 37
A2     2        e     u
A3     4        q     d
G#3    2-       e     d        -
G#3    2        e     d  [
F#3    2        e     d  ]
E3     3        e.    d  [
E3     1        s     d  ]\
measure 38
D3     2        e     d  [
D3     2        e     d  =
E3     3        e.    d  =
E3     1        s     d  ]\
F#3    3        e.    d  [
G#3    1        s     d  =\
f1              4
A3     2        e     d  =
f1              3
A3     2        e     d  ]
measure 39
D3     4        q     d
E3     2        e     d  [
E3     2        e     d  ]
A2     4        q     u
A3     2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
measure 40
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
A3     2        e     d  [
G3     2        e     d  ]
measure 41
F#3    4        q     d
rest   2        e
B3     2        e     d
A3     2        e     d  [
A2     2        e     u  ]
$ C:12
A3     2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
measure 42
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
A3     2        e     u  [
G3     2        e     u  ]
measure 43
F#3    4        q     u
rest   2        e
F#3    2        e     u
G3     4        q     u
A3     2        e     d  [
$ C:22
A3     2        e     d  ]
measure 44
B3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F#3    1        s     d  ]]
E3     2        e     d  [
A3     2        e     d  ]
D3     2        e     d  [
E3     1        s     d  =[
F#3    1        s     d  ]]
G3     2        e     d  [
F#3    1        s     d  =[
E3     1        s     d  ]]
measure 45
F#3    2        e     d  [
G3     1        s     d  =[
A3     1        s     d  ]]
B3     1        s     d  [[
A3     1        s     d  ==
B3     1        s     d  ==
C#4    1        s     d  ]]
D4     2        e     d  [
A3     2        e     d  ]
D4     4-       q     d        -
measure 46
D4     4        q     d
C#4    4        q     d
B3     4        q     d
A3     4        q     d
measure 47
D3     4        q     d
E3     2        e     d  [
E3     2        e     d  ]
F#3    6        q.    d
F#3    2        e     d
measure 48
G#3    4        q     d
A3     2        e     d  [
A3     2        e     d  ]
E3     4        q     d
E2     4        q     u
measure 49
A2     4        q     u
A3     2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
f1              7
D4     2        e     d  [
D4     2        e     d  =
f1              6
D4     2        e     d  =
D4     2        e     d  ]
measure 50
f1              6
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
f3              6 5 #
E#3    4        q     d
F#3    4        q     d
measure 51
f1     4        4
f1              #
C#3    8        h     u
F#3    4        q     d
$ C:12
D4     2        e     d  [
E4     1        s     d  =[
F#4    1        s     d  ]]
measure 52
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
f2              4 2
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 53
F#4    2        e     d  [
F#4    2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
A3     4        q     d
$ C:22
*               D       Tasto solo
A3     2        e     d  [
B3     1        s     d  =[
C#4    1        s     d  ]]
measure 54
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
f2              6 4
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 55
D4     2        e     d  [
C#4    1        s     d  =[
B3     1        s     d  ]]
A3     2        e     d  [
G3     2        e     d  ]
F#3    4        q     d
rest   4        q
measure 56
D4     2        e     d  [
D3     2        e     d  ]
rest   4        q
D4     2        e     d  [
D3     2        e     d  ]
rest   4        q
measure 57
D4     2        e     d  [
D3     2        e     d  ]
rest   2        e
D3     2        e     d
D4     2        e     d  [
D4     1        s     d  =[
D4     1        s     d  ]]
B3     2        e     d  [
G3     2        e     d  ]
measure 58
D4     4        q     d
$ C:15
rest   2        e
A4     2        e     d
B4     1        s     d  [[
A4     1        s     d  ==
G4     1        s     d  ==
F#4    1        s     d  ]]
E4     2        e     d  [
$ C:22
A3     2        e     d  ]
measure 59
B3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F#3    1        s     d  ]]
E3     2        e     d  [
A3     2        e     d  ]
D3     4        q     d
G3     4-       q     d        -
measure 60
G3     2        e     d  [
F#3    1        s     d  =[
E3     1        s     d  ]]
F#3    2        e     d  [
D3     2        e     d  ]
B3     2        e     d  [
B3     2        e     d  ]
B3     2        e     d  [
A3     1        s     d  =[
G3     1        s     d  ]]
measure 61
D4     6        q.    d
$ C:15
F#4    2        e     d
G4     1        s     d  [[
F#4    1        s     d  ==
E4     1        s     d  ==
D4     1        s     d  ]]
C#4    2        e     d  [
$ C:22
F#3    2        e     d  ]
measure 62
B3     2        e     d  [
B3     2        e     d  ]
rest   2        e
E3     2        e     d
A3     2        e     d  [
A3     2        e     d  ]
rest   2        e
D3     2        e     d
measure 63
G3     2        e     d  [
G3     2        e     d  ]
rest   2        e
E3     2        e     d
F#3    2        e     d  [
F#3    2        e     d  ]
rest   2        e
F#3    2        e     d
measure 64
F#3    1        s     d  [[
E3     1        s     d  ==
D3     1        s     d  ==
C#3    1        s     d  ]]
B2     2        e     d  [
G3     2        e     d  ]
G3     1        s     d  [[
F#3    1        s     d  ==
E3     1        s     d  ==
D3     1        s     d  ]]
C#3    2        e     d  [
A3     2        e     d  ]
measure 65
A3     1        s     d  [[
G3     1        s     d  ==
F#3    1        s     d  ==
E3     1        s     d  ]]
D3     2        e     d  [
B3     2        e     d  ]
B3     1        s     d  [[
A3     1        s     d  ==
G3     1        s     d  ==
F#3    1        s     d  ]]
E3     2        e     d  [
C#4    2        e     d  ]
measure 66
C#4    1        s     d  [[
B3     1        s     d  ==
A3     1        s     d  ==
G3     1        s     d  ]]
F#3    2        e     d  [
D4     2        e     d  ]
D4     1        s     d  [[
C#4    1        s     d  ==
B3     1        s     d  ==
A3     1        s     d  ]]
G3     1        s     d  [[
F#3    1        s     d  ==
E3     1        s     d  ==
D3     1        s     d  ]]
measure 67
C#3    4        q     u
rest   2        e
C#4    2        e     d
D4     4        q     d
B3     2        e     d  [
G3     2        e     d  ]
measure 68
f2              6 4
A3     4        q     d
f2              5 3
A2     4        q     u
D3     4        q     d
$ D:Adagio
rest   2        e
A3     2        e     d
measure 69
D4     8        h     d
f1              6
C#4    4        q     d
C#4    4        q     d
measure 70
f1     8        7
f1              6+
B3    16        w     d
measure 71
A3    16        w     d
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
