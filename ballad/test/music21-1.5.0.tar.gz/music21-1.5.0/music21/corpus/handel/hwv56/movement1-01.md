&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-01/1} [KHM:2644056620]
TIMESTAMP: DEC/26/2001 [md5sum:4f6ed14a230330a4ad7ab49a82c68255]
04/04/90 E. Correia
WK#:56        MV#:1,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Sinfonia
Violino I
0 24
Group memberships: score
score: part 1 of 4
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Grave
E4     6        q.    u
C5     2        e     d
B4     6        q.    u
A4     2        e     u
measure 2
D#5    6        q.    d         &t
C#5    1        s     d  [[
B4     1        s     d  ]]
G5     6        q.    d
G5     2        e     d
measure 3
G5     6        q.    d
F#5    2        e     d
F#5    6        q.    d         &t
E5     2        e     d
measure 4
D#5    6        q.    d
F#5    2        e     d
G5     6        q.    d
B5     2        e     d
measure 5
E5     6        q.    d
A4     2        e     u
G4     6        q.    u         &t
F#4    2        e     u
measure 6
F#4    6        q.    u
A4     2        e     u
D5     6        q.    d
D5     2        e     d
measure 7
D5     6        q.    d
E5     2        e     d
C5     6        q.    d         &t
B4     2        e     u
measure 8
B4     8-       h     u        -
B4     3        e.    u  [
B4     1        s     u  =\
B4     3        e.    u  =
B4     1        s     u  ]\
measure 9
E5     6        q.    d
F#5    2        e     d
F#5    6        q.    d         &t
E5     1        s     d  [[
F#5    1        s     d  ]]
measure 10
G5     6        q.    d
G4     2        e     u
F#4    4        q     u
B4     4        q     u
measure 11
E5     6        q.    d
B4     2        e     u
A4     6        q.    u         &t
B4     2        e     u
measure 12      start-end1
B4     8-       h     u        -
B4     3        e.    u  [
B3     1        s     u  =\
C#4    3        e.    u  =
D#4    1        s     u  ]\
mheavy2 13      :| stop-end1 start-end2
B4    16        w     d
mdouble 14      stop-end2
$ T:1/1   D:Allegro moderato
rest   4        q
B5     4        q     d
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
measure 15
F#5    4        q     d
B4     4        q     d
F#5    4        q     d
G#5    4        q     d         t
measure 16
A5     4        q     d
E5     4        q     d
A5     8-       h     d        -
measure 17
A5     2        e     d  [
B5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
F#5    2        e     d  [
B5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  ]
measure 18
G5     4        q     d
E5     4        q     d
B5     8-       h     d        -
measure 19
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
A5     4        q     d
G5     2        e     d  [
F#5    2        e     d  ]
measure 20
G5     8-       h     d        -
G5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
E5     2        e     d  ]
measure 21
F#5    4        q     d
B5     8        h     d
A#5    4        q     d         &t
measure 22
B5     2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
D#5    2        e     d  ]
E5     2        e     d  [
E4     2        e     d  ]
E5     4-       q     d        -
measure 23
E5     4        q     d
D5     2        e     d  [      +
C5     2        e     d  ]      +
D5     4        q     d
C5     2        e     d  [
B4     2        e     d  ]
measure 24
C5     6        q.    d
B4     2        e     u
A4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
E4     2        e     u  ]
measure 25
D#5    4        q     d
E5     8        h     d
D#5    4        q     d         &t
measure 26
E5     4        q     d
B4     4        q     u
rest   8        h
measure 27
rest  16
measure 28
rest   8        h
rest   2        e
G4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  ]
measure 29
C5     2        e     d  [
D5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
A4     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 30
B4     4        q     u
G4     4        q     u
rest   8        h
measure 31
rest  16
measure 32
rest   4        q
D6     4        q     d
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
measure 33
A5     4        q     d
D5     4        q     d
rest   8        h
measure 34
rest   4        q
E5     4        q     d
C5     4        q     d
B4     2        e     u  [
A4     2        e     u  ]
measure 35
B4     4        q     u
E4     4        q     u
rest   8        h
measure 36
rest   4        q
F#5    4        q     d
D5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 37
C#5    4        q     d
F#4    4        q     u
C#5    4        q     d
D#5    4        q     d         &t
measure 38
E5     4        q     d
B4     4        q     d
E5     8-       h     d        -
measure 39
E5     2        e     d  [
F#5    2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
C#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 40
D#5    2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
D#5    2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
G5     2        e     d  ]
measure 41
E5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
E5     2        e     d  [
A5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
measure 42
F#5    2        e     d  [
B5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  ]
F#5    2        e     d  [
B5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  ]
measure 43
G5     2        e     d  [
C6     2        e     d  =
B5     2        e     d  =
C6     2        e     d  ]
G5     2        e     d  [
C6     2        e     d  =
B5     2        e     d  =
C6     2        e     d  ]
measure 44
A5     2        e     d  [
D6     2        e     d  =
C6     2        e     d  =
D6     2        e     d  ]
A5     2        e     d  [
D6     2        e     d  =
C6     2        e     d  =
D6     2        e     d  ]
measure 45
B5     4        q     d
C6     2        e     d  [
B5     2        e     d  ]
A5     2        e     d  [
G5     2        e     d  =
F#5    2        e     d  =
E5     2        e     d  ]
measure 46
D5     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
C5     2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 47
F#4    8        h     u
A4     8        h     u
measure 48
rest   4        q
D5     4        q     d
B4     4        q     u
A4     2        e     u  [
G4     2        e     u  ]
measure 49
A4     4        q     u
D4     4        q     u
rest   8        h
measure 50
rest   4        q
D6     4        q     d
B5     4        q     d
A5     2        e     d  [
G5     2        e     d  ]
measure 51
A5     4        q     d
D5     4        q     d
G5     8-       h     d        -
measure 52
G5     4        q     d
F5     2        e     d  [
E5     2        e     d  ]
F5     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
measure 53
E5     6        q.    d
D5     2        e     d
E5     2        e     d  [
F#5    2        e     d  =      +
G5     2        e     d  =
A5     2        e     d  ]
measure 54
F#5    4        q     d
G5     8        h     d
F#5    4        q     d         &t
measure 55
G5     8        h     d
rest   2        e
C5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 56
F5     2        e     d  [
G5     2        e     d  =
E5     2        e     d  =
F5     2        e     d  ]
D5     2        e     d  [
G5     2        e     d  =
F5     2        e     d  =
G5     2        e     d  ]
measure 57
E5     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  =      +
G#4    2        e     u  ]
A4     8-       h     u        -
measure 58
A4     8        h     u
G#4    8        h     u         &t
measure 59
A4     2        e     d  [
E5     2        e     d  =
F#5    2        e     d  =
G#5    2        e     d  ]
A5     8-       h     d        -
measure 60
A5     8        h     d
G#5    8        h     d         &t
measure 61
A5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
C5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 62
A4     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
F#4    2        e     u  [
D5     2        e     u  =
C5     2        e     u  =
D5     2        e     u  ]
measure 63
B4     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
B4     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
measure 64
G4     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
G4     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
measure 65
A4     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
A4     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
measure 66
F#4    2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
D#4    2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
measure 67
G4     2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
E4     2        e     u  [
E5     2        e     u  =
D5     2        e     u  =
E5     2        e     u  ]
measure 68
C#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
C#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 69
D#5    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  =
D#5    2        e     d  ]
E5     2        e     d  [
F#5    2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
measure 70
B5     4        q     d
F#5    4        q     d
D#5    4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 71
G5     8        h     d
E5     8-       h     d        -
measure 72
E5     4        q     d
E5     4        q     d
D#5    4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 73
G5     4        q     d
G4     4        q     u
E4     8-       h     u        -
measure 74
E4     4        q     u
D#4    4        q     u
B4     8        h     u
measure 75
rest   4        q
F#5    4        q     d
D#5    4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 76
G5     4        q     d
G4     4        q     u
G5     8-       h     d        -
measure 77
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
A5     8-       h     d        -
measure 78
A5     4        q     d
G5     2        e     d  [
F#5    2        e     d  ]
B5     8        h     d
measure 79
rest   4        q
B5     4        q     d
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
measure 80
C6     4        q     d
C5     4        q     d
C6     8-       h     d        -
measure 81
C6     4        q     d
B5     8        h     d
A5     4        q     d
measure 82
B5     4        q     d
F#5    4        q     d
G5     4        q     d
E5     4-       q     d        -
measure 83
E5     8        h     d
D#5    8        h     d         &t
measure 84
E5     4        q     d
B4     4        q     d
C5     8-       h     d        -
measure 85
C5     8        h     d
B4     8-       h     d        -
measure 86
B4     2        e     d  [
C5     2        e     d  =
B4     2        e     d  =
C5     2        e     d  ]
A4     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 87
D#5    4        q     d
B5     4        q     d
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
measure 88
F#5    4        q     d
B4     4        q     d
F#5    4        q     d
G#5    4        q     d         &t
measure 89
A5     4        q     d
E5     4        q     d
A5     8-       h     d        -
measure 90
A5     2        e     d  [
B5     2        e     d  =
G5     2        e     d  =
A5     2        e     d  ]
F#5    2        e     d  [
B5     2        e     d  =
A5     2        e     d  =
B5     2        e     d  ]
measure 91
E5     8-       h     d        -
E5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 92
C5     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
G#4    2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 93
A4     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
B4     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 94
C5     2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
B4     2        e     d  ]
A4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
E4     2        e     u  ]
measure 95
D#5    8        h     d
rest   4        q
B4     4        q     u
measure 96
E5     6        q.    d
D5     1        s     d  [[     +
C5     1        s     d  ]]
B4     4        q     u
A4     4        q     u
measure 97
G4     6        q.    u
A4     2        e     u
F#4    6        q.    u         &t
E4     2        e     u
measure 98
E4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-01/2} [KHM:2644056620]
TIMESTAMP: DEC/26/2001 [md5sum:d1cf05718743604fcbb973c6ba1693b1]
04/04/90 E. Correia
WK#:56        MV#:1,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Sinfonia
Violino II
0 24
Group memberships: score
score: part 2 of 4
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:4   D:Grave
B3     6        q.    u
A4     2        e     u
G4     6        q.    u
F#4    2        e     u
measure 2
F#4    6        q.    u
E4     2        e     u
B4     6        q.    u
B4     2        e     u
measure 3
C#5    6        q.    d
C#5    2        e     d
C#5    6        q.    d
A#4    2        e     u
measure 4
F#4    6        q.    u
D#4    2        e     u
B3     6        q.    u
D4     2        e     u
measure 5
E4     8        h     u
E4     4        q     u
C#4    4        q     u
measure 6
A3     6        q.    u
F#4    2        e     u
F#4    6        q.    u
F#4    2        e     u
measure 7
B4     6        q.    u
B4     2        e     u
A4     4        q     u
A4     4        q     u
measure 8
A4     3        e.    u  [
A4     1        s     u  =\
G4     3        e.    u  =
F#4    1        s     u  ]\
G4     4        q     u
F#4    4        q     u
measure 9
E4     4        q     u
C5     4        q     d
C5     6        q.    d
B4     1        s     u  [[
A4     1        s     u  ]]
measure 10
B4     6        q.    u
B3     2        e     u
B3     6        q.    u
F#4    2        e     u
measure 11
G4     6        q.    u
G4     2        e     u
E4     6        q.    u
D#4    2        e     u
measure 12      start-end1
D#4    8        h     u
rest   8        h
mheavy2 13      :| stop-end1 start-end2
D#4   16        w     u
mdouble 14      stop-end2
$ T:1/1   D:Allegro moderato
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest   4        q
E5     4        q     d
D5     4        q     d
C#5    2        e     d  [
B4     2        e     d  ]
measure 19
C#5    4        q     d
F#4    4        q     u
C#5    4        q     d
D#5    4        q     d
measure 20
E5     4        q     d
B4     4        q     d
E5     8-       h     d        -
measure 21
E5     2        e     d  [
F#5    2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
C#5    2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 22
D#5    4        q     d
F#4    4        q     u
B4     4        q     u
A4     2        e     u  [
G4     2        e     u  ]
measure 23
A4     4        q     u
F#4    8        h     u
E4     4        q     u
measure 24
E4     4        q     u
G#4    4        q     u
A4     2        e     u  [
B4     2        e     u  ]
C5     4        q     d
measure 25
B4     6        q.    u
C5     2        e     d
A4     4        q     u
F#4    4        q     u
measure 26
B4     4        q     u
G4     4-       q     u        -
G4     2        e     u  [
E4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
measure 27
A4     2        e     u  [
B4     2        e     u  =
G4     2        e     u  =
A4     2        e     u  ]
F#4    2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
measure 28
G4     4        q     u
E4     2        e     u  [
F#4    2        e     u  ]
G4     8-       h     u        -
measure 29
G4     8        h     u
F#4    8        h     u
measure 30
G4     4        q     u
D5     4        q     d
G5     8-       h     d        -
measure 31
G5     8        h     d
F#5    8        h     d
measure 32
G5     8        h     d
G4     8        h     u
measure 33
F#4    8        h     u
D5     8-       h     d        -
measure 34
D5     4        q     d
C5     4        q     d
E4     4        q     u
A4     4        q     u
measure 35
rest   8        h
E5     8        h     d
measure 36
C#4    4        q     u
D4     4        q     u
rest   8        h
measure 37
rest   4        q
F#4    4        q     u
F#4    4        q     u
F#4    4        q     u
measure 38
B4     6        q.    u
A4     2        e     u
G4     2        e     u  [
F#4    2        e     u  =
E4     2        e     u  =
D4     2        e     u  ]
measure 39
C#4    4        q     u
B4     8        h     d
A#4    4        q     u
measure 40
B4     4        q     u
D#5    4        q     d
rest   2        e
D#5    2        e     d  [
D#5    2        e     d  =
D#5    2        e     d  ]
measure 41
E5     4        q     d
E4     4        q     u
rest   2        e
E5     2        e     d  [
D5     2        e     d  =      +
E5     2        e     d  ]
measure 42
A4     4        q     u
F#4    4        q     u
rest   2        e
F#5    2        e     d  [
E5     2        e     d  =
F#5    2        e     d  ]
measure 43
G5     4        q     d
E5     4        q     d
rest   2        e
E5     2        e     d  [
D5     2        e     d  =
E5     2        e     d  ]
measure 44
A4     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
A4     2        e     d  [
F#5    2        e     d  =
E5     2        e     d  =
F#5    2        e     d  ]
measure 45
D5     4        q     d
E5     2        e     d  [
D5     2        e     d  ]
C5     2        e     d  [
B4     2        e     d  =
A4     2        e     d  =
C5     2        e     d  ]
measure 46
D4     4        q     u
G4     4        q     u
A4     8        h     u
measure 47
rest   4        q
A4     4        q     u
F#4    4        q     u
E4     2        e     u  [
D4     2        e     u  ]
measure 48
B4     4        q     u
B3     4        q     u
rest   4        q
G4     4        q     u
measure 49
F#4    4        q     u
A5     4        q     d
F#5    4        q     d
E5     2        e     d  [
D5     2        e     d  ]
measure 50
B5     4        q     d
B4     4        q     u
rest   4        q
G4     4        q     u
measure 51
F#4    8        h     u
D5     4        q     d
C5     2        e     d  [
B4     2        e     d  ]
measure 52
C5     4        q     d
A4     4        q     u
C5     4        q     d
G4     4        q     u
measure 53
G4     4        q     u
G4     4-       q     u        -
G4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  =
C5     2        e     u  ]
measure 54
A4     4        q     u
D5     4        q     d
C5     4        q     d
A4     4        q     u
measure 55
D4     2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
C5     8-       h     d        -
measure 56
C5     8        h     d
B4     8        h     d
measure 57
C5     4        q     d
rest   4        q
rest   2        e
A4     2        e     u  [
B4     2        e     u  =
C5     2        e     u  ]
measure 58
D5     2        e     d  [
E5     2        e     d  =
C5     2        e     d  =
D5     2        e     d  ]
B4     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
E5     2        e     d  ]
measure 59
C5     6        q.    d
B4     2        e     d
A4     2        e     d  [
E5     2        e     d  =
D5     2        e     d  =
C5     2        e     d  ]
measure 60
B4    12        h.    d
B4     4        q     d
measure 61
E5     4        q     d
A4     4        q     u
E4     4        q     u
A4     4        q     u
measure 62
A4     4        q     u
A4     4        q     u
A3     4        q     u
A4     4        q     u
measure 63
G4     4        q     u
D4     4        q     u
D4     4        q     u
F#4    4        q     u
measure 64
G4     8        h     u
C4     8        h     u
measure 65
rest   4        q
A4     4        q     u
A4     4        q     u
F#4    4        q     u
measure 66
B3     8        h     u
F#4    8        h     u
measure 67
E4     4        q     u
D#4    4        q     u
E4     4        q     u
B4     4        q     u
measure 68
E4     4        q     u
A4     4        q     u
C#5    4        q     d
F#4    4        q     u
measure 69
F#4    2        e     u  [
D#4    2        e     u  =
E4     2        e     u  =
F#4    2        e     u  ]
G4     2        e     u  [
A4     2        e     u  =
B4     2        e     u  =
C5     2        e     u  ]      +
measure 70
B4     4        q     u
D#5    4        q     d
B4     4        q     u
F#4    4        q     u
measure 71
rest   4        q
B5     4        q     d
G5     4        q     d
F#5    2        e     d  [
E5     2        e     d  ]
measure 72
F#5    4        q     d
B4     4        q     u
rest   8        h
measure 73
rest   4        q
B4     4        q     u
G4     4        q     u
F#4    2        e     u  [
E4     2        e     u  ]
measure 74
F#4    8        h     u
E4     8        h     u
measure 75
A4    12        h.    u
A4     4        q     u
measure 76
G4     4        q     u
D#4    4        q     u
B4     4        q     u
A4     2        e     u  [
G4     2        e     u  ]
measure 77
E5    12        h.    d
E4     4        q     u
measure 78
F#4   12        h.    u
E4     2        e     u  [
D4     2        e     u  ]
measure 79
G4     8        h     u
B4     4        q     u
E5     4-       q     d        -
measure 80
E5     4        q     d
C5     4        q     d
A4     4        q     u
E5     4        q     d
measure 81
F#5    8        h     d
E5     8        h     d
measure 82
D#5    8        h     d
B4     2        e     u  [
G4     2        e     u  =
A4     2        e     u  =
B4     2        e     u  ]
measure 83
C5     4        q     d
B4     4        q     u
A4     4        q     u
F#4    4        q     u
measure 84
B4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
E4     2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
A4     2        e     u  ]
measure 85
F#4    2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
A4     2        e     u  ]
D4     2        e     u  [
G4     2        e     u  =
F#4    2        e     u  =
G4     2        e     u  ]
measure 86
E4     8-       h     u        -
E4     2        e     u  [
A4     2        e     u  =
G4     2        e     u  =
A4     2        e     u  ]
measure 87
B4     8        h     u
rest   8        h
measure 88
rest   4        q
B4     4        q     u
B4     4        q     u
B4     4        q     u
measure 89
E5     6        q.    d
D5     2        e     d
C5     2        e     u  [
B4     2        e     u  =
A4     2        e     u  =
G4     2        e     u  ]
measure 90
F#4    4        q     u
E5     8        h     d
D#5    4        q     d
measure 91
E5     2        e     d  [
A4     2        e     d  =
G#4    2        e     d  =
A4     2        e     d  ]
B4     4        q     u
B4     4        q     u
measure 92
E4     2        e     u  [
C5     2        e     u  =
B4     2        e     u  =
C5     2        e     u  ]
D4     4        q     u
G#4    4        q     u
measure 93
A4     2        e     u  [
C5     2        e     u  =
B4     2        e     u  =
C5     2        e     u  ]
E4     4        q     u
B4     4        q     u
measure 94
E4     4        q     u
E4     4        q     u
A4     4        q     u
C5     4        q     d
measure 95
F#4    8        h     u
rest   4        q
D#4    4        q     u
measure 96
B4     8        h     u
E4     4        q     u
E4     4        q     u
measure 97
E4     8        h     u
D#4    8        h     u
measure 98
E4    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-01/3} [KHM:2644056620]
TIMESTAMP: DEC/26/2001 [md5sum:c31d82f7e2f493457f53e933a3325fac]
04/04/90 E. Correia
WK#:56        MV#:1,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Sinfonia
Viola
0 24
Group memberships: score
score: part 3 of 4
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:13   D:Grave
G3     6        q.    u
A3     2        e     u
B3     6        q.    u
B3     2        e     u
measure 2
B3     6        q.    u
B4     2        e     d
B4     6        q.    d
G4     2        e     d
measure 3
E4     6        q.    d
F#4    2        e     d
F#4    6        q.    d
C#5    2        e     d
measure 4
B4     6        q.    d
B4     2        e     d
D4     6        q.    d
G4     2        e     d
measure 5
G4     8        h     d
A3     4        q     u
E4     4        q     d
measure 6
D4     8        h     d
D4     6        q.    d
D4     2        e     d
measure 7
E4     8        h     d
E4     4        q     d
F#4    4        q     d
measure 8
F#4    3        e.    d  [
F#4    1        s     d  =\
E4     3        e.    d  =
D#4    1        s     d  ]\
E4     4        q     d
B3     4        q     u
measure 9
G4     4        q     d
A4     4        q     d
A3     4        q     u
C4     4        q     u
measure 10
E4     6        q.    d
E4     2        e     d
F#4    6        q.    d
B3     2        e     u
measure 11
B3     4        q     u
A3     2        e     u  [
G3     2        e     u  ]
A3     6        q.    u
F#4    2        e     d
measure 12      start-end1
F#4    8        h     d
rest   8        h
mheavy2 13      :| stop-end1 start-end2
F#4   16        w     d
mdouble 14      stop-end2
$ T:1/1   D:Allegro moderato
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest   4        q
B4     4        q     d
B3     4        q     u
B4     4        q     d
measure 23
A4     4        q     d
B4     4        q     d
A4     4        q     d
E4     4        q     d
measure 24
E4     6        q.    d
D4     2        e     d
C4     2        e     u  [
B3     2        e     u  ]
A3     4        q     u
measure 25
F#4    4        q     d
E4     4        q     d
F#4    6        q.    d
B3     2        e     u
measure 26
G3     4        q     u
E3     4        q     u
E4     8-       h     d        -
measure 27
E4     8        h     d
D#4    8        h     d
measure 28
E4     4        q     d
G4     2        e     d  [
F#4    2        e     d  ]
G4     8-       h     d        -
measure 29
G4     8        h     d
F#4    8        h     d
measure 30
G4     4        q     d
B4     2        e     d  [
A4     2        e     d  ]
B4     2        e     d  [
B3     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 31
E4     2        e     d  [
F#4    2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
C4     4        q     d
A4     4        q     d
measure 32
D4     4        q     d
B4     4        q     d
D5     4        q     d
G4     4        q     d
measure 33
D5     8        h     d
A4     4        q     d
G4     2        e     d  [
F#4    2        e     d  ]
measure 34
E4     8        h     d
A3     8        h     u
measure 35
rest   8        h
B4     8        h     d
measure 36
A#4    4        q     d
B4     4        q     d
rest   8        h
measure 37
rest   4        q
E4     4        q     d
C#4    4        q     u
B3     2        e     u  [
A#3    2        e     u  ]
measure 38
B3     4        q     u
B4     8        h     d
E4     4        q     d
measure 39
F#4    4        q     d
F#4    8        h     d
F#4    4        q     d
measure 40
F#4    4        q     d
B3     4        q     u
rest   2        e
B4     2        e     d  [
B4     2        e     d  =
B4     2        e     d  ]
measure 41
E4     8        h     d
rest   2        e
C#5    2        e     d  [
B4     2        e     d  =
C#5    2        e     d  ]
measure 42
F#4    4        q     d
B3     4        q     u
rest   2        e
D#4    2        e     d  [
C#4    2        e     d  =
D#4    2        e     d  ]
measure 43
B3     4        q     u
E4     4        q     d
rest   4        q
G4     4        q     d
measure 44
D5     4        q     d
A4     4        q     d
D5     4        q     d
D4     4        q     d
measure 45
G4     8        h     d
E4     4        q     d
F#4    4        q     d
measure 46
G4     4        q     d
G4     4        q     d
C4     4        q     d
E4     4        q     d
measure 47
A3     8        h     u
D4     8        h     d
measure 48
rest   4        q
G4     4        q     d
D4     4        q     d
D4     4        q     d
measure 49
D4     4        q     d
F#4    4        q     d
A4     4        q     d
G4     2        e     d  [
F#4    2        e     d  ]
measure 50
G4     8        h     d
D4     8        h     d
measure 51
rest   4        q
A4     4        q     d
G4     4        q     d
D4     4        q     d
measure 52
C4     4        q     d
D4     4        q     d
C4     4        q     d
D4     4        q     d
measure 53
C4     4        q     u
B3     4        q     u
C4     8        h     u
measure 54
D4     4        q     d
D4     4        q     d
A4     4        q     d
D5     4        q     d
measure 55
D5     4        q     d
D4     4        q     d
G4     4        q     d
C5     4        q     d
measure 56
A4     4        q     d
G4     4        q     d
G4     4        q     d
G4     4        q     d
measure 57
C4     4        q     u
B3     4        q     u
E4     4        q     d
E4     4        q     d
measure 58
D4     4        q     d
E4     4        q     d
E4     4        q     d
E4     4        q     d
measure 59
A4     4        q     d
E4     4        q     d
E4     4        q     d
A4     4        q     d
measure 60
B4     4        q     d
E4     4        q     d
D4     4        q     d
B4     4        q     d
measure 61
A4     4        q     d
E4     4        q     d
A4     4        q     d
E4     4        q     d
measure 62
F#4    4        q     d
D4     4        q     d
D4     4        q     d
D4     4        q     d
measure 63
D4     4        q     d
G4     4        q     d
G4     4        q     d
D4     4        q     d
measure 64
B3     4        q     u
E4     4        q     d
E4     8        h     d
measure 65
rest   4        q
D4     4        q     d
D4     4        q     d
F#4    4        q     d
measure 66
F#4   12        h.    d
D#4    4        q     d
measure 67
B3     4        q     u
F#4    4        q     d
B3     4        q     u
E4     4        q     d
measure 68
E4     4        q     d
F#4    4        q     d
F#4    4        q     d
A#4    4        q     d
measure 69
F#4    4        q     d
B3     4        q     u
B3     4        q     u
E4     4        q     d
measure 70
F#4    4        q     d
B4     4        q     d
F#4    4        q     d
D#4    4        q     d
measure 71
B4     8        h     d
B3     8        h     u
measure 72
B4     8        h     d
F#4    4        q     d
D#4    4        q     d
measure 73
B3     8        h     u
B3     8-       h     u        -
measure 74
B3     4        q     u
B3     4        q     u
B3     4        q     u
A3     2        e     u  [
G3     2        e     u  ]
measure 75
F#3    8        h     u
B3     8        h     u
measure 76
E4     4        q     d
D#4    4        q     d
E4     8-       h     d        -
measure 77
E4     4        q     d
G4     4        q     d
A4     8-       h     d        -
measure 78
A4     4        q     d
A4     4        q     d
B4     8-       h     d        -
measure 79
B4     4        q     d
G4     4        q     d
E4     4        q     d
G4     4        q     d
measure 80
A4     4        q     d
E4     4        q     d
E4     4        q     d
A4     4        q     d
measure 81
A4     4        q     d
B4     4        q     d
C5     4        q     d
E4     4        q     d
measure 82
F#4    8        h     d
E4     8        h     d
measure 83
F#4    4        q     d
G4     4        q     d
A4     4        q     d
B4     4        q     d
measure 84
B3     4        q     u
E4     4-       q     d        -
E4     2        e     d  [
C4     2        e     d  =
B3     2        e     d  =
C4     2        e     d  ]
measure 85
A3     4        q     u
D4     4-       q     d        -
D4     2        e     u  [
B3     2        e     u  =
A3     2        e     u  =
B3     2        e     u  ]
measure 86
G3     4        q     u
G4     4        q     d
A4     6        q.    d
A4     2        e     d
measure 87
F#4    8        h     d
rest   8        h
measure 88
rest   4        q
G4     4        q     d
F#4    4        q     d
E4     4        q     d
measure 89
E4     4        q     d
A4     4        q     d
E4     4        q     d
F#4    4        q     d
measure 90
B3     4        q     u
B3     4        q     u
F#4    4        q     d
F#4    4        q     d
measure 91
A4     4        q     d
E4     4        q     d
E4     4        q     d
E4     4        q     d
measure 92
A4     8        h     d
D4     8        h     d
measure 93
E4     8        h     d
E4     8        h     d
measure 94
A4     4        q     d
A4     4        q     d
E4     4        q     d
E4     4        q     d
measure 95
B4     8        h     d
rest   4        q
F#4    4        q     d
measure 96
E4     8        h     d
E4     4        q     d
C4     4        q     d
measure 97
B3    12        h.    u
A3     4        q     u
measure 98
G3    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-01/4} [KHM:2644056620]
TIMESTAMP: DEC/26/2001 [md5sum:e636f554402d18690dda2090447968db]
04/04/90 E. Correia
WK#:56        MV#:1,1
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Sinfonia
Bassi
0 24
Group memberships: score
score: part 4 of 4
&
Tranfer from old stage2 to new stage2
&
$ K:1   Q:4   T:1/1   C:22   D:Grave
E3     8        h     d
rest   8        h
measure 2
B2     6        q.    u
G3     2        e     d
F#3    6        q.    d
E3     2        e     d
measure 3
A#3    6        q.    d
A#3    2        e     d
A#3    6        q.    d
F#3    2        e     d
measure 4
B3     6        q.    d
B2     2        e     u
B2     6        q.    u
G2     2        e     u
measure 5
C3     8        h     u
C#3    4        q     u
A2     4        q     u
measure 6
D3     8        h     u
B2     6        q.    u
B3     2        e     d
measure 7
G#3    8        h     d
A3     4        q     d
F#3    4        q     d
measure 8
D#3    6        q.    u
B2     2        e     u
E3     4        q     d
D3     4        q     u
measure 9
C3     4        q     u
A2     4        q     u
A3     6        q.    d
G3     1        s     d  [[
F#3    1        s     d  ]]
measure 10
E3     6        q.    d
E3     2        e     d
D3     6        q.    u
D3     2        e     u
measure 11
C3     6        q.    u
C3     2        e     u
C3     6        q.    u
B2     2        e     u
measure 12      start-end1
B2     6        q.    u
A3     2        e     d
G3     4        q     d
F#3    4        q     d
mheavy2 13      :| stop-end1 start-end2
B2    16        w     u
mdouble 14      stop-end2
$ T:1/1   D:Allegro moderato
rest  16
measure 15
rest  16
measure 16
rest  16
measure 17
rest  16
measure 18
rest  16
measure 19
rest  16
measure 20
rest  16
measure 21
rest  16
measure 22
rest   4        q
B3     4        q     d
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 23
F#3    4        q     d
B2     4        q     u
F#3    4        q     d
G#3    4        q     d
measure 24
A3     4        q     d
E3     4        q     d
A3     8-       h     d        -
measure 25
A3     2        e     d  [
B3     2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
F#3    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
B3     2        e     d  ]
measure 26
G3     4        q     d
E3     4        q     d
$ C:12
E4     8-       h     d        -
measure 27
E4     8        h     d
D#4    8        h     d
measure 28
E4     8        h     d
rest   8        h
measure 29
rest  16
measure 30
rest   8        h
$ C:22
rest   2        e
G3     2        e     d  [
A3     2        e     d  =
B3     2        e     d  ]
measure 31
C4     2        e     d  [
D4     2        e     d  =
B3     2        e     d  =
C4     2        e     d  ]
A3     2        e     d  [
D4     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 32
B3     4        q     d
G3     4        q     d
rest   8        h
measure 33
rest   4        q
G3     4        q     d
F#3    4        q     d
E3     2        e     d  [
D3     2        e     d  ]
measure 34
E3     4        q     d
A2     4        q     u
rest   8        h
measure 35
rest   4        q
A3     4        q     d
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 36
F#3    4        q     d
B2     4        q     u
rest   8        h
measure 37
rest   4        q
B3     4        q     d
A3     4        q     d
G3     2        e     d  [
F#3    2        e     d  ]
measure 38
G3     6        q.    d
F#3    2        e     d
E3     2        e     u  [
D3     2        e     u  =
C#3    2        e     u  =
B2     2        e     u  ]
measure 39
A#2    4        q     u
B2     4        q     u
F#3    4        q     d
F#2    4        q     u
measure 40
B2     4        q     u
B3     8        h     d
B2     4        q     u
measure 41
C3     8        h     u
C#3    8        h     u
measure 42
D3     8        h     u
D#3    8        h     u
measure 43
E3     8        h     d
rest   4        q
E3     4        q     d
measure 44
F#3    8        h     d
rest   4        q
F#3    4        q     d
measure 45
G3     8        h     d
A3     8        h     d
measure 46
B3     4        q     d
C4     2        e     d  [
B3     2        e     d  ]
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  ]
measure 47
D3    16-       w     d        -
measure 48
D3    16-       w     d        -
measure 49
D3    16-       w     d        -
measure 50
D3    16-       w     d        -
measure 51
D3     4        q     u
D4     4        q     d
B3     4        q     d
A3     2        e     d  [
G3     2        e     d  ]
measure 52
A3     4        q     d
D3     4        q     d
A3     4        q     d
B3     4        q     d
measure 53
C4     4        q     d
G3     4        q     d
C4     8-       h     d        -
measure 54
C4     2        e     d  [
D4     2        e     d  =
B3     2        e     d  =
C4     2        e     d  ]
A3     2        e     d  [
D4     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
measure 55
B3     4        q     d
G3     4        q     d
E3     4        q     d
D3     2        e     u  [
C3     2        e     u  ]
measure 56
D3     4        q     u
G2     4        q     u
rest   8        h
measure 57
rest   4        q
E3     4        q     d
C3     4        q     u
B2     2        e     u  [
A2     2        e     u  ]
measure 58
B2     4        q     u
E2     4        q     u
rest   8        h
measure 59
rest   4        q
E4     4        q     d
C4     4        q     d
B3     2        e     d  [
A3     2        e     d  ]
measure 60
D4     2        e     d  [
E4     2        e     d  =
C4     2        e     d  =
D4     2        e     d  ]
B3     2        e     d  [
E4     2        e     d  =
D4     2        e     d  =
E4     2        e     d  ]
measure 61
C4     4        q     d
C3     4        q     u
A2     4        q     u
C3     4        q     u
measure 62
F#2    4        q     u
F#3    4        q     d
D3     4        q     d
F#3    4        q     d
measure 63
G3     4        q     d
G2     4        q     u
G3     4        q     d
F#3    4        q     d
measure 64
E3     8        h     d
E2     8        h     u
measure 65
F#2    8        h     u
F#3    8        h     d
measure 66
D#3    8        h     u
B2     8        h     u
measure 67
E3     4        q     d
F#3    4        q     d
G3     4        q     d
G#3    4        q     d
measure 68
A3     8        h     d
A#3    8        h     d
measure 69
B3     4        q     d
A3     4        q     d         +
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 70
D#3    4        q     u
B2     4        q     u
B3     8        h     d
measure 71
B2    16-       w     u        -
measure 72
B2    16-       w     u        -
measure 73
B2    16-       w     u        -
measure 74
B2     4        q     u
B3     4        q     d
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 75
F#3    4        q     d
B2     4        q     u
B3     8-       h     d        -
measure 76
B3     4        q     d
B3     4        q     d
G3     4        q     d
F#3    2        e     d  [
E3     2        e     d  ]
measure 77
C4    12        h.    d
B3     2        e     d  [
A3     2        e     d  ]
measure 78
D4    12        h.    d
C4     2        e     d  [
B3     2        e     d  ]
measure 79
E4     8        h     d
rest   8        h
measure 80
rest   4        q
E4     4        q     d
C4     4        q     d
B3     2        e     d  [
A3     2        e     d  ]
measure 81
D4     8        h     d
C4     8        h     d
measure 82
B3     8        h     d
rest   2        e
E3     2        e     d  [
F#3    2        e     d  =
G3     2        e     d  ]
measure 83
A3     2        e     d  [
B3     2        e     d  =
G3     2        e     d  =
A3     2        e     d  ]
F#3    2        e     d  [
B3     2        e     d  =
A3     2        e     d  =
B3     2        e     d  ]
measure 84
G3     4        q     d
E3     4        q     d
A3     8        h     d
measure 85
D3     4        q     d
F#3    4        q     d
G3     4        q     d
G2     4        q     u
measure 86
C3     8        h     u
C4     8        h     d
measure 87
B3     8        h     d
rest   8        h
measure 88
rest   4        q
E4     4        q     d
D4     4        q     d
C4     2        e     d  [
B3     2        e     d  ]
measure 89
C4     6        q.    d
B3     2        e     d
A3     2        e     d  [
G3     2        e     d  =
F#3    2        e     d  =
E3     2        e     d  ]
measure 90
D#3    4        q     d
E3     4        q     d
B3     4        q     d
B2     4        q     u
measure 91
C3     4        q     u
E3     4        q     d
G#2    8        h     u
measure 92
A2     8        h     u
B2     8        h     u
measure 93
C3     8        h     u
G#2    8        h     u
measure 94
A2     8        h     u
C3     8        h     u
measure 95
B2     8        h     u
rest   4        q
f2              4+ 2
A2     4        q     u
measure 96
G2    12        h.    u
A2     4        q     u
measure 97
B2    16        w     u
measure 98
E2    16        w     u
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&