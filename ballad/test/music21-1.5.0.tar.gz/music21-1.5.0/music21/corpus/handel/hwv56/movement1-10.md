&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/1} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:d6ca7ea2a9d6c0b7b76860cce366abd1]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
1 23
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4
A5     4        e     d         f
measure 1
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 2
F#5    8        q     d         (
G5     4        e     d         )
E5     8        q     d
C#4    4        e     u
measure 3
D4     8        q     u         (
E4     4        e     u         )
C#4    4        e     u  [
D4     4        e     u  =
E4     4        e     u  ]
measure 4
F#4    4        e     u  [      (
G4     4        e     u  =      )
F#4    4        e     u  ]
E4     8        q     u
rest   4        e
measure 5
rest   8        q
rest   4        e
rest   8        q
E5     4        e     d
measure 6
A4     8        q     u         (
B4     4        e     u         )
G#4    4        e     u  [
A4     4        e     u  =
B4     4        e     u  ]
measure 7
C#5    8        q     d         (
D5     4        e     d         )
B4     4        e     d  [
C#5    4        e     d  =
D5     4        e     d  ]
measure 8
E5     4        e     d  [
F#5    4        e     d  =
E5     4        e     d  ]
D5     4        e     d  [
C#5    4        e     d  ]
B4     1        t     d  [[[    (
C#5    1        t     d  ==]
D5     2        s     d  ]]     )
measure 9
C#5    8        q     d
B5     1        t     d  [[[    (
C#6    1        t     d  ==]
D6     2        s     d  ]]     )
C#6    2        s     d  [[     (
B5     2        s     d  =]     )
A5     4        e     d  ]
rest   4        e
measure 10
rest   8        q
D5     1        t     d  [[[    (
E5     1        t     d  ==]
F#5    2        s     d  ]]     )
E5     2        s     d  [[     (
D5     2        s     d  =]     )
C#5    4        e     d  ]
E5     1        t     d  [[[    &(
F#5    1        t     d  ==]
G5     2        s     d  ]]     &)
measure 11
F#5    2        s     d  [[
E5     2        s     d  ==
D5     2        s     d  ==
F#5    2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ]]
G#5    2        s     d  [[
F#5    2        s     d  ==
E5     2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ]]
measure 12
A5     2        s     d  [[
G#5    2        s     d  ==
F#5    2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
B5     2        s     d  [[
A5     2        s     d  ==
G#5    2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ==
D6     2        s     d  ]]
measure 13
C#6    2        s     d  [[     (
B5     2        s     d  =]     )
A5     4        e     d  ]
B5     1        t     d  [[[    (
C#6    1        t     d  ==]
D6     2        s     d  ]]     )
C#6    2        s     d  [[     (
B5     2        s     d  =]     )
A5     4        e     d  ]
rest   4        e
measure 14
rest   8        q
D5     1        t     d  [[[    (
E5     1        t     d  ==]
F#5    2        s     d  ]]     )
E5     2        s     d  [[     (
D5     2        s     d  =]     )
C#5    4        e     d  =
A5     4        e     d  ]
measure 15
A5    12-       q.    d        -
A5     8        q     d
A5     4        e     d
measure 16
A5     2        s     d  [[     (
G#5    2        s     d  =]     )
F#5    4        e     d  =
A5     4        e     d  ]
G#5    2        s     d  [[
A5     2        s     d  ==
B5     2        s     d  ==
A5     2        s     d  ==
G#5    2        s     d  ==
F#5    2        s     d  ]]
measure 17
E5     4        e     d
A5     8-       q     d        -
A5     8        q     d
G#5    4        e     d
measure 18
A5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ==
C#5    2        s     d  ==
B4     2        s     d  ]]
A4     4        e     d  [
E5     4        e     d  =
A5     4        e     d  ]
measure 19
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 20
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      &t
E5     2        s     d  =[
E5     2        s     d  ==
F#5    2        s     d  ==
E5     2        s     d  ]]
measure 21
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 22
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
C#5    2        s     d  [[     (
D5     2        s     d  =]     )
C#5    4        e     d  =
E5     4        e     d  ]
measure 23
rest   8        q
E5     1        t     d  [[[    (
F#5    1        t     d  ==]
G5     2        s     d  ]]     )
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  ]
rest   4        e
measure 24
rest   8        q
G5     1        t     d  [[[    (
A5     1        t     d  ==]
B5     2        s     d  ]]     )
A5     2        s     d  [[     (
G5     2        s     d  ==     )
F#5    2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 25
D6     4        e     d  [      (
C#6    4        e     d  =
B5     4        e     d  ]      )
A5     4        e     d  [      (
G5     4        e     d  =
F#5    4        e     d  ]      )
measure 26
E4    12-       q.    u        -
E4     4        e     u  [
E5     4        e     u  =
E5     4        e     u  ]
measure 27
E5     2        s     d  [[
A5     2        s     d  ==
C#6    2        s     d  ==
A5     2        s     d  ==
E5     2        s     d  ==
A5     2        s     d  ]]
C#5    2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
C#5    2        s     d  ==
A4     2        s     d  ==
A5     2        s     d  ]]
measure 28
B5     4        e     d  [      (
A5     4        e     d  =
G5     4        e     d  ]      )
F#5    4        e     d  [      (
E5     4        e     d  =
D5     4        e     d  ]      )
measure 29
C4     2        s     u  [[     (
A4     2        s     u  ==     )
C5     2        s     u  ==     (
A4     2        s     u  ==     )
F#4    2        s     u  ==     (
A4     2        s     u  ]]     )
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
measure 30
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
measure 31
B4     8        q     u
G5     4        e     d
E5     8        q     d
C#6    4        e     d         +
measure 32
D6     4        e     d  [
A4     2        s     u  =[
G4     2        s     u  ==
F#4    2        s     u  ==
E4     2        s     u  ]]
D4     4        e     u  [
F#5    4        e     d  =
A5     4        e     d  ]
measure 33
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 34
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      t
E5     4        e     d  =
A4     4        e     d  ]
measure 35
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 36
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     2        s     d  [[
F#5    2        s     d  ==
E5     2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 37
D6     2        s     d  [[
C#6    2        s     d  ==
D6     2        s     d  ==
A3     2        s     u  ==
B3     2        s     u  ==
C4     2        s     u  ]]
B3     2        s     u  [[     (
A3     2        s     u  ==
G3     2        s     u  ==     )
B4     2        s     d  ==
C#5    2        s     d  ==     +
D5     2        s     d  ]]
measure 38
E5     2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
B3     2        s     u  ==
C#4    2        s     u  ==
D4     2        s     u  ]]
C#4    2        s     u  [[     (
B3     2        s     u  ==
A3     2        s     u  ==     )
C#5    2        s     d  ==
D5     2        s     d  ==
E5     2        s     d  ]]
measure 39
F#5    2        s     d  [[
E5     2        s     d  ==
F#5    2        s     d  ==
C#4    2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[     (
C#4    2        s     u  ==
B3     2        s     u  ==     )
D4     2        s     u  ==
E4     2        s     u  ==
F#4    2        s     u  ]]
measure 40
E4     2        s     u  [[     (
D4     2        s     u  ==
C#4    2        s     u  ==     )
E4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[     (
E4     2        s     u  ==
D4     2        s     u  ==     )
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 41
D6     4        e     d  [      (
C#6    4        e     d  =
B5     4        e     d  ]      )
A5     4        e     d  [      (
G5     4        e     d  =
F#5    4        e     d  ]      )
measure 42
E4    12        q.    u         t
E4    12        q.    u         t
measure 43
E4     8        q     u         t
D5     4        e     d
C#5    2        s     d  [[
E5     2        s     d  ==
A4     2        s     d  ==
G5     2        s     d  ==
F#5    2        s     d  ==
D5     2        s     d  ]]
measure 44
E5     2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
D5     2        s     u  ==
E4     2        s     u  ==
C#5    2        s     u  ]]
D5     4        e     u  [
D4     4        e     u  ]      F
rest   4        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/2} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:5be847beff59f764eec7ed5bb7e196d4]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
1 23
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4
A5     4        e     d         &f
measure 1
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 2
F#5    8        q     d         (
G5     4        e     d         )
E5     8        q     d
E5     4        e     d
measure 3
A4     4        e     u  [
B4     2        s     u  =[
A4     2        s     u  ==
G4     2        s     u  ==
F#4    2        s     u  ]]
E4     8        q     u
A4     4        e     u
measure 4
A4     8        q     u
A4     4        e     u
A4     8        q     u
A4     4        e     u
measure 5
D4     8        q     u
E4     4        e     u
C#4    4        e     u  [
D4     4        e     u  =
E4     4        e     u  ]
measure 6
F#4    8        q     u
D4     4        e     u
E4     4        e     u  [
F#4    4        e     u  =
G#4    4        e     u  ]
measure 7
A4     8        q     u
D4     4        e     u
E4     8        q     u
rest   4        e
measure 8
rest   8        q
rest   4        e
rest   8        q
G#4    4        e     u
measure 9
A4     8        q     u
G#5    1        t     d  [[[    (
A5     1        t     d  ==]
B5     2        s     d  ]]     )
A5     4        e     d  [
E5     4        e     d  ]
rest   4        e
measure 10
rest   8        q
B4     1        t     d  [[[    (
C#5    1        t     d  ==]
D5     2        s     d  ]]     )
C#5    2        s     d  [[     (
B4     2        s     d  =]     )
A4     4        e     d  ]
C#5    1        t     d  [[[    (
D5     1        t     d  ==]
E5     2        s     d  ]]     )
measure 11
D5     4        e     d  [
A4     2        s     d  =[
D5     2        s     d  ==
E5     2        s     d  ==
F#5    2        s     d  ]]
E5     4        e     d  [
B4     2        s     d  =[
E5     2        s     d  ==
F#5    2        s     d  ==
G#5    2        s     d  ]]
measure 12
F#5    4        e     d  [
C#5    2        s     d  =[
F#5    2        s     d  ==
G#5    2        s     d  ==
A5     2        s     d  ]]
E5     4        e     d  [
B4     2        s     d  =[
G#5    2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ]]
measure 13
A5     4        e     d  [
E5     4        e     d  ]
G#5    1        t     d  [[[    (
A5     1        t     d  ==]
B5     2        s     d  ]]     )
A5     4        e     d  [
E5     4        e     d  ]
rest   4        e
measure 14
rest   8        q
B4     1        t     d  [[[    (
C#5    1        t     d  ==]
D5     2        s     d  ]]     )
C#5    2        s     d  [[     (
B4     2        s     d  =]     )
A4     4        e     d  =
E5     4        e     d  ]
measure 15
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  =
F#5    4        e     d  ]
E5     2        s     d  [[     (
D5     2        s     d  =]     )
C#5    4        e     d  =
E5     4        e     d  ]
measure 16
D5    12-       q.    d        -
D5     8        q     d
D5     4        e     d
measure 17
C#5    2        s     d  [[
B4     2        s     d  ==
C#5    2        s     d  ==
E5     2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
B4     2        s     d  [[
A4     2        s     d  ==
B4     2        s     d  ==
C#5    2        s     d  ==
D5     2        s     d  ==
B4     2        s     d  ]]
measure 18
C#5    2        s     d  [[
D5     2        s     d  ==
C#5    2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ==
G#4    2        s     d  ]]
A4     2        s     d  [[
B4     2        s     d  ==
C#5    2        s     d  ==
D5     2        s     d  ==
E5     2        s     d  ==
C#5    2        s     d  ]]
measure 19
A4     8        q     u
B4     4        e     u
E4     8        q     u
A4     4        e     u
measure 20
D5     4        e     d  [      (
E5     4        e     d  =      )
D5     4        e     d  ]
D5     4        e     d  [
C#5    2        s     d  =[
C#5    2        s     d  ==
D5     2        s     d  ==
C#5    2        s     d  ]]
measure 21
D5     2        s     d  [[
G5     2        s     d  =]
F#5    4        e     d  =
D4     4        e     u  ]
C#5    2        s     d  [[
D5     2        s     d  =]
C#5    4        e     d  =
C#4    4        e     u  ]
measure 22
D5     2        s     d  [[     (
E5     2        s     d  ==
D5     2        s     d  ==     )
F#4    2        s     d  ==
G4     2        s     d  ==
F#4    2        s     d  ]]
E4     2        s     u  [[     (
F#4    2        s     u  =]     )
E4     4        e     u  =
C#5    4        e     u  ]
measure 23
rest   8        q
C#5    1        t     d  [[[    (
D5     1        t     d  ==]
E5     2        s     d  ]]     )
D5     4        e     d  [
A4     4        e     d  ]
rest   4        e
measure 24
rest   8        q
E5     1        t     d  [[[    (
F#5    1        t     d  ==]
G5     2        s     d  ]]     )
F#5    2        s     d  [[     (
E5     2        s     d  =]     )
D5     4        e     d  =
A5     4        e     d  ]
measure 25
F#5    8        q     d
G5     4        e     d
D5     8        q     d
D4     4        e     u
measure 26
D4    12-       q.    u        -
D4     4        e     u  [
D4     4        e     u  =
D4     4        e     u  ]
measure 27
C#4   12        q.    u
A4     2        s     d  [[
B4     2        s     d  ==
C#5    2        s     d  ==
A4     2        s     d  =]
A5     4        e     d  ]
measure 28
B5     4        e     d  [      (
A5     4        e     d  =
G5     4        e     d  ]      )
F#5    4        e     d  [      (
E5     4        e     d  =
D5     4        e     d  ]      )
measure 29
C4     2        s     u  [[     (
A4     2        s     u  ==     )
C5     2        s     u  ==     (
A4     2        s     u  ==     )
F#4    2        s     u  ==     (
A4     2        s     u  ]]     )
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
measure 30
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
C4     2        s     u  [[
A4     2        s     u  ==
C5     2        s     u  ==
A4     2        s     u  ==
F#4    2        s     u  ==
A4     2        s     u  ]]
measure 31
G4     8        q     u
B4     4        e     u
C#5    8        q     d         +
E5     4        e     d
measure 32
F#5    4        e     u  [
A4     2        s     u  =[
G4     2        s     u  ==
F#4    2        s     u  ==
E4     2        s     u  ]]
D4     4        e     u  [
F#5    4        e     d  =
A5     4        e     d  ]
measure 33
D5     8        q     d         (
E5     4        e     d         )
C#5    4        e     d  [
D5     4        e     d  =
E5     4        e     d  ]
measure 34
F#5    4        e     d  [      (
G5     4        e     d  =      )
F#5    4        e     d  ]
F#5    4        e     d  [      t
E5     4        e     d  =
A4     4        e     d  ]
measure 35
A5     2        s     d  [[     (
B5     2        s     d  ==
A5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
G5     2        s     d  [[     (
A5     2        s     d  ==
G5     2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
measure 36
F#5    2        s     d  [[     (
G5     2        s     d  ==
F#5    2        s     d  ==     )
A4     2        s     d  ==
B4     2        s     d  ==
A4     2        s     d  ]]
E5     2        s     d  [[
F#5    2        s     d  ==
E5     2        s     d  ==
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 37
D6     2        s     d  [[
C#6    2        s     d  ==
D6     2        s     d  ==
A3     2        s     u  ==
B3     2        s     u  ==
C4     2        s     u  ]]
B3     2        s     u  [[     (
A3     2        s     u  ==
G3     2        s     u  ==     )
B4     2        s     d  ==
C#5    2        s     d  ==     +
D5     2        s     d  ]]
measure 38
E5     2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
B3     2        s     u  ==
C#4    2        s     u  ==
D4     2        s     u  ]]
C#4    2        s     u  [[     (
B3     2        s     u  ==
A3     2        s     u  ==     )
C#5    2        s     d  ==
D5     2        s     d  ==
E5     2        s     d  ]]
measure 39
F#5    2        s     d  [[
E5     2        s     d  ==
F#5    2        s     d  ==
C#4    2        s     u  ==
D4     2        s     u  ==
E4     2        s     u  ]]
D4     2        s     u  [[     (
C#4    2        s     u  ==
B3     2        s     u  ==     )
D4     2        s     u  ==
E4     2        s     u  ==
F#4    2        s     u  ]]
measure 40
E4     2        s     u  [[     (
D4     2        s     u  ==
C#4    2        s     u  ==     )
E4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]
F#4    2        s     u  [[     (
E4     2        s     u  ==
D4     2        s     u  ==     )
A5     2        s     d  ==
B5     2        s     d  ==
C#6    2        s     d  ]]
measure 41
D6     4        e     d  [      (
C#6    4        e     d  =
B5     4        e     d  ]      )
A5     4        e     d  [      (
G5     4        e     d  =
F#5    4        e     d  ]      )
measure 42
E4    12        q.    u         t
E4    12        q.    u         t
measure 43
E4     8        q     u         t
D5     4        e     d
C#5    2        s     d  [[
E5     2        s     d  ==
A4     2        s     d  ==
G5     2        s     d  ==
F#5    2        s     d  ==
D5     2        s     d  ]]
measure 44
E5     2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
D5     2        s     u  ==
E4     2        s     u  ==
C#5    2        s     u  ]]
D5     4        e     u  [
D4     4        e     u  ]      F
rest   4        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/3} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:416c4f8adfeb336e5d03be4af76929f7]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
1 23
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:2   T:6/8   C:13
rest   1        e
measure 1
rest   6
measure 2
rest   2        q
rest   1        e
rest   2        q
C#4    1        e     u         &f
measure 3
D4     2        q     d
E4     1        e     d
C#4    1        e     d  [
D4     1        e     d  =
E4     1        e     d  ]
measure 4
F#4    1        e     d  [
G4     1        e     d  =
F#4    1        e     d  ]
E4     2        q     d
A4     1        e     d
measure 5
D4     2        q     d
E4     1        e     d
C#4    1        e     d  [
D4     1        e     d  =
E4     1        e     d  ]
measure 6
F#4    2        q     d
D4     1        e     d
E4     2        q     d
E4     1        e     d
measure 7
A3     2        q     u
B3     1        e     u
G#3    1        e     u  [
A3     1        e     u  =
B3     1        e     u  ]
measure 8
C#4    1        e     d  [
D4     1        e     d  =
C#4    1        e     d  ]
B3     1        e     d  [
B3     1        e     d  =
E4     1        e     d  ]
measure 9
E4     2        q     d
E4     1        e     d
A4     2        q     d
rest   1        e
measure 10
rest   2        q
D4     1        e     d
A4     2        q     d
A4     1        e     d
measure 11
A4     1        e     d  [
F#4    1        e     d  =
B4     1        e     d  ]
B4     1        e     d  [
G#4    1        e     d  =
C#5    1        e     d  ]
measure 12
C#5    1        e     d  [
A4     1        e     d  =
F#4    1        e     d  ]
B4     1        e     d  [
E4     1        e     d  =
E4     1        e     d  ]
measure 13
E4     2        q     d
E4     1        e     d
A4     2        q     d
rest   1        e
measure 14
rest   2        q
D4     1        e     d
A4     2        q     d
A4     1        e     d
measure 15
A4     3-       q.    d        -
A4     3        q.    d
measure 16
B4     3-       q.    d        -
B4     2        q     d
B4     1        e     d
measure 17
C#5    1        e     d
F#4    2        q     d
F#4    2        q     d
E4     1        e     d
measure 18
E4     2        q     d
E4     1        e     d
E4     2        q     d
E4     1        e     d
measure 19
F#4    2        q     d
E4     1        e     d
A4     2        q     d
A4     1        e     d
measure 20
A4     1        e     d  [
A4     1        e     d  =
A4     1        e     d  ]
A4     1        e     d  [
A4     1        e     d  =
A4     1        e     d  ]
measure 21
A4     1        e     d  [
A4     1        e     d  =
D4     1        e     d  ]
G4     1        e     d  [
G4     1        e     d  =
G4     1        e     d  ]
measure 22
A4     3        q.    d
A4     3        q.    d
measure 23
rest   2        q
A4     1        e     d
D4     1        e     d  [
F#4    1        e     d  ]
rest   1        e
measure 24
rest   2        q
G4     1        e     d
D5     1        e     d  [
A4     1        e     d  =
E4     1        e     d  ]
measure 25
D4     2        q     d
D4     1        e     d
D4     2        q     d
A3     1        e     u
measure 26
B3     3-       q.    u        -
B3     1        e     d  [
B4     1        e     d  =
B4     1        e     d  ]
measure 27
A4     3-       q.    d        -
A4     2        q     d
rest   1        e
measure 28
rest   2        q
rest   1        e
rest   2        q
F#4    1        e     d
measure 29
F#4    2        q     d
A4     1        e     d
F#4    2        q     d
A4     1        e     d
measure 30
F#4    2        q     d
A4     1        e     d
F#4    2        q     d
D4     1        e     d
measure 31
D4     2        q     d
E4     1        e     d
E4     2        q     d
A4     1        e     d
measure 32
A4     3        q.    d
A4     3        q.    d
measure 33
F#4    1        e     d  [
G4     1        e     d  =
E4     1        e     d  ]
A3     1        e     u  [
B3     1        e     u  =
C#4    1        e     u  ]
measure 34
D4     1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
A3     2        q     u
G3     1        e     u
measure 35
F#3    2        q     u
D4     1        e     d
E3     2        q     u
C#4    1        e     u
measure 36
D3     2        q     u
D4     1        e     d
C#4    2        q     d
A4     1        e     d
measure 37
F#4    2        q     d
D4     1        e     d
G3     1        e     u  [
B4     1        e     d  =
A4     1        e     d  ]
measure 38
G#4    2        q     d
G#3    1        e     u
A3     1        e     u  [
C#5    1        e     d  =
B4     1        e     d  ]
measure 39
A#4    2        q     d
A#3    1        e     u
B3     1        e     u  [
D4     1        e     u  =
B3     1        e     u  ]
measure 40
C#4    1        e     u  [
A3     1        e     u  =      +
C#4    1        e     u  ]
D4     1        e     d  [
F#4    1        e     d  =
D4     1        e     d  ]
measure 41
B4     1        e     d  [
A4     1        e     d  =
G4     1        e     d  ]
F#4    1        e     d  [
E4     1        e     d  =
D4     1        e     d  ]
measure 42
G#3    1        e     u  [
B3     1        e     u  =
A3     1        e     u  ]
G#3    1        e     u  [
B3     1        e     u  =
A3     1        e     u  ]
measure 43
G#3    1        e     u  [
B3     1        e     u  =
G#3    1        e     u  ]
A3     1        e     u  [
C#4    1        e     u  =
D4     1        e     u  ]
measure 44
G4     1        e     d  [
A4     1        e     d  =
A3     1        e     d  ]
D4     2        q     d
rest   1        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/4} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:292e7a03a569739d0c9f644c56171eaf]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
1 23 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4
A4     4        e     u                    O
measure 1
D5     8        q     d                    thou
E5     4        e     d                    that
C#5    4        e     d                    tell-
D5     4        e     d                    est
E5     4        e     d                    good
measure 2
F#5    4        e     d                    ti-
F#5    4        e     d                    dings
G5     4        e     d                    to
E5     4        e     d                    Zi-
E5     4        e     d                    on,
E5     4        e     d                    good
measure 3
A4     4        e     u  [                 ti-
B4     2        s     u  =[                -
A4     2        s     u  ]]                -
G4     2        s     u  [[                dings_
F#4    2        s     u  ]]                _
E4     8        q     u                    to
A4     4        e     u                    Je-
measure 4
A4     8        q     u                    ru-
A4     4        e     u                    sa-
A4    12        q.    u                    lem,
measure 5
rest   8        q
rest   4        e
rest   8        q
E5     4        e     d                    O
measure 6
A4     8        q     u                    thou
B4     4        e     u                    that
G#4    4        e     u                    tell-
A4     4        e     u                    est
B4     4        e     u                    good
measure 7
C#5    4        e     d                    ti-
C#5    4        e     d                    dings
D5     4        e     d                    to
B4     4        e     d                    Zi-
C#5    4        e     d                    on,
D5     4        e     d                    good
measure 8
E5     4        e     d                    ti-
F#5    4        e     d                    dings
E5     4        e     d                    to
D5     4        e     d                    Zi-
C#5    4        e     d                    on,
B4     1        t     d  [[[    (          a-
C#5    1        t     d  ==]               -
D5     2        s     d  ]]     )          -
measure 9
C#5    8        q     d                    rise,
rest   4        e
rest   8        q
D5     1        t     d  [[[               a-
E5     1        t     d  ==]               -
F#5    2        s     d  ]]                -
measure 10
E5     8        q     d                    rise,
rest   4        e
rest   8        q
C#5    4        e     d                    say
measure 11
A4     4        e     u                    un-
A4     4        e     u                    to
D5     4        e     d                    the
B4     4        e     u                    ci-
B4     4        e     u                    ties
E5     4        e     d                    of
measure 12
C#5    4        e     d                    Ju-
C#5    4        e     d                    dah,
C#5    4        e     d                    be-
E5     8        q     d                    hold
E5     4        e     d                    your
measure 13
E5     8        q     d                    God!
rest   4        e
rest   8        q
B4     1        t     d  [[[               be-
C#5    1        t     d  ==]               -
D5     2        s     d  ]]                -
measure 14
C#5    8        q     d                    hold!
rest   4        e
rest   8        q
E5     4        e     d                    the
measure 15
D5     2        s     d  [[                glo-
E5     2        s     d  =]                -
F#5    4        e     d  ]                 -
D5     4        e     d                    ry
C#5    2        s     d  [[                of_
D5     2        s     d  =]                _
E5     4        e     d  ]                 _
C#5    4        e     d                    the
measure 16
D5    12-       q.    d        -           Lord_
D5     8        q     d                    _
B4     4        e     u                    is
measure 17
C#5    4        e     d                    ri-
C#5    8        q     d                    sen
B4    12        q.    d                    up-
measure 18
C#5   12        q.    d                    on
C#5    8        q     d                    thee.
A4     4        e     u                    O
measure 19
D5     8        q     d                    thou
E5     4        e     d                    that
C#5    4        e     d                    tell-
D5     4        e     d                    est
E5     4        e     d                    good
measure 20
F#5    4        e     d                    ti-
G5     4        e     d                    dings
F#5    4        e     d                    to
F#5    4        e     d                    Zi-
E5     4        e     d                    on,
E5     4        e     d                    say
measure 21
D5     4        e     d                    un-
D5     4        e     d                    to
D5     4        e     d                    the
C#5    4        e     d                    ci-
C#5    4        e     d                    ties
C#5    4        e     d                    of
measure 22
D5    12        q.    d                    Ju-
C#5    8        q     d                    dah,
C#5    1        t     d  [[[    (          be-
D5     1        t     d  ==]               -
E5     2        s     d  ]]     )          -
measure 23
D5     8        q     d                    hold!
rest   4        e
rest   8        q
E5     1        t     d  [[[               be-
F#5    1        t     d  ==]               -
G5     2        s     d  ]]                -
measure 24
F#5    2        s     d  [[                hold!_
E5     2        s     d  =]                _
D5     4        e     d  ]                 _
rest   4        e
rest   8        q
A4     4        e     u                    the
measure 25
D5     4        e     d  [                 glo-
C#5    4        e     d  ]                 -
B4     4        e     u                    ry
A4     8        q     u                    of
A4     4        e     u                    the
measure 26
B4    12-       q.    u        -           Lord,_
B4     4        e     u                    _
B4     4        e     u                    of
B4     4        e     u                    the
measure 27
A4    12-       q.    u        -           Lord,_
A4     8        q     u                    _
rest   4        e
measure 28
rest   8        q
rest   4        e
rest   8        q
A4     4        e     u                    the
measure 29
A4     8        q     u                    glo-
A4     4        e     u                    ry
A4     8        q     u                    of
A4     4        e     u                    the
measure 30
A4    12-       q.    u        -           Lord_
A4     8        q     u                    _
A4     4        e     u                    is
measure 31
B4     8        q     u         (          ri-
E5     4        e     d         )          -
C#5    8        q     d                    sen
C#5    4        e     d                    up-
measure 32
D5    12        q.    d                    on
D5    12        q.    d                    thee.
measure 33
rest  24
measure 34
rest  24
measure 35
rest  24
measure 36
rest  24
measure 37
rest  24
measure 38
rest  24
measure 39
rest  24
measure 40
rest  24
measure 41
rest  24
measure 42
rest  24
measure 43
rest  24
measure 44
rest  24
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/5} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:be0f4688ae8516e6eb5e6602f2f635eb]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
1 23 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:4
D4     4        e     u                    _
measure 1
rest  24
measure 2
rest  24
measure 3
rest  24
measure 4
rest   8        q
rest   4        e
rest   8        q
A4     4        e     u                    O
measure 5
D4     8        q     u                    thou
E4     4        e     u                    that
C#4    4        e     u                    tell-
D4     4        e     u                    est
E4     4        e     u                    good
measure 6
F#4    4        e     u                    ti-
F#4    4        e     u                    dings
D4     4        e     u                    to
E4     4        e     u                    Zi-
F#4    4        e     u                    on,
G#4    4        e     u                    to
measure 7
A4     8        q     u         (          Zi-
D4     4        e     u         )          -
E4     8        q     u                    on,
rest   4        e
measure 8
rest   8        q
rest   4        e
rest   8        q
G#4    4        e     u                    a-
measure 9
A4     8        q     u                    rise,
rest   4        e
rest   8        q
A4     4        e     u                    a-
measure 10
A4     8        q     u                    rise,
rest   4        e
rest   8        q
A4     4        e     u                    say
measure 11
F#4    4        e     u                    un-
F#4    4        e     u                    to
F#4    4        e     u                    the
G#4    4        e     u                    ci-
G#4    4        e     u                    ties
G#4    4        e     u                    of
measure 12
A4     4        e     u                    Ju-
A4     4        e     u                    dah,
A4     4        e     u                    be-
E4     8        q     u                    hold
E4     4        e     u                    your
measure 13
E4     8        q     u                    God!
rest   4        e
rest   8        q
G#4    1        t     u  [[[               be-
A4     1        t     u  ==]               -
B4     2        s     u  ]]                -
measure 14
A4     8        q     u                    hold!
rest   4        e
rest   8        q
A4     4        e     u                    the
measure 15
A4     8        q     u                    glo-
A4     4        e     u                    ry
A4     8        q     u                    of
A4     4        e     u                    the
measure 16
A4     2        s     u  [[                Lord_
G#4    2        s     u  =]                _
F#4    4        e     u  =                 _
A4     4        e     u  ]                 _
G#4    2        s     u  [[                _
A4     2        s     u  ==                _
B4     2        s     u  ==                _
A4     2        s     u  ]]                _
G#4    2        s     u  [[                is_
F#4    2        s     u  ]]                _
measure 17
E4     4        e     u                    ri-
A4     8        q     u                    sen
A4     8        q     u         (          up-
G#4    4        e     u         )          -
measure 18
A4    12        q.    u                    on
A4     8        q     u                    thee.
E4     4        e     u                    O
measure 19
A4     8        q     u                    thou
B4     4        e     u                    that
A4     4        e     u                    tell-
A4     4        e     u                    est
A4     4        e     u                    good
measure 20
A4     4        e     u                    ti-
A4     4        e     u                    dings
A4     4        e     u                    to
A4     4        e     u                    Zi-
A4     4        e     u                    on,
A4     4        e     u                    say
measure 21
A4     4        e     u                    un-
A4     4        e     u                    to
A4     4        e     u                    the
G4     4        e     u                    ci-
G4     4        e     u                    ties
G4     4        e     u                    of
measure 22
A4    12        q.    u                    Ju-
A4     8        q     u                    dah,
A4     4        e     u                    be-
measure 23
A4     8        q     u                    hold!
rest   4        e
rest   8        q
G4     1        t     u  [[[               be-
A4     1        t     u  ==]               -
B4     2        s     u  ]]                -
measure 24
A4     2        s     u  [[                hold!_
G4     2        s     u  =]                _
F#4    4        e     u  ]                 _
rest   4        e
rest   8        q
A4     4        e     u                    the
measure 25
F#4    8        q     u                    glo-
G4     4        e     u                    ry
A4     4        e     u  [                 of_
G4     4        e     u  ]                 _
F#4    4        e     u                    the
measure 26
E4    12-       q.    u        -           Lord,_
E4     4        e     u                    _
E4     4        e     u                    of
E4     4        e     u                    the
measure 27
E4    12-       q.    u        -           Lord,_
E4     8        q     u                    _
A4     4        e     u                    the
measure 28
B4     4        e     u  [                 glo-
A4     4        e     u  ]                 -
G4     4        e     u                    ry
F#4    4        e     u  [                 of_
E4     4        e     u  ]                 _
D4     4        e     u                    the
measure 29
C4    24-       h.    u        -           Lord_
measure 30
C4    12-       q.    u        -           _
C4     8        q     u                    _
C4     4        e     u                    is
measure 31
B3     8        q     u         (          ri-
B4     4        e     u         )          -
A4     8        q     u                    sen
A4     4        e     u                    up-
measure 32
A4    12        q.    u                    on
A4    12        q.    u                    thee.
measure 33
rest  24
measure 34
rest  24
measure 35
rest  24
measure 36
rest  24
measure 37
rest  24
measure 38
rest  24
measure 39
rest  24
measure 40
rest  24
measure 41
rest  24
measure 42
rest  24
measure 43
rest  24
measure 44
rest  24
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/6} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:5589aff29e5649e419eb9cbe0d0965ff]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
1 23 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:8   T:6/8   C:34
rest   4        e
measure 1
rest  24
measure 2
rest   8        q
rest   4        e
rest   8        q
C#4    4        e     d                    O
measure 3
D4     8        q     d                    thou
E4     4        e     d                    that
C#4    4        e     d                    tell-
D4     4        e     d                    est
E4     4        e     d                    good
measure 4
F#4    4        e     d                    ti-
G4     4        e     d                    dings
F#4    4        e     d                    to
E4     4        e     d                    Zi-
E4     4        e     d                    on,
rest   4        e
measure 5
rest  24
measure 6
rest   8        q
rest   4        e
rest   8        q
E4     4        e     d                    O
measure 7
A3     8        q     u                    thou
B3     4        e     u                    that
G#3    4        e     u                    tell-
A3     4        e     u                    est
B3     4        e     u                    good
measure 8
C#4    4        e     d                    ti-
D4     4        e     d                    dings
C#4    4        e     d                    to
B3     4        e     d                    Zi-
B3     4        e     d                    on,
E4     4        e     d                    a-
measure 9
E4     8        q     d                    rise,
rest   4        e
rest   8        q
F#4    1        t     d  [[[               a-
E4     1        t     d  ==]               -
D4     2        s     d  ]]                -
measure 10
C#4    8        q     d                    rise,
rest   4        e
rest   8        q
E4     4        e     d                    say
measure 11
D4     4        e     d                    un-
D4     4        e     d                    to
D4     4        e     d                    the
E4     4        e     d                    ci-
E4     4        e     d                    ties
E4     4        e     d                    of
measure 12
F#4    4        e     d                    Ju-
F#4    4        e     d                    dah,
F#4    4        e     d                    be-
B3     8        q     d                    hold
B3     4        e     d                    your
measure 13
C#4    8        q     d                    God!
rest   4        e
rest   8        q
E4     4        e     d                    be-
measure 14
E4     8        q     d                    hold!
rest   4        e
rest   8        q
E4     4        e     d                    the
measure 15
F#4    2        s     d  [[                glo-
E4     2        s     d  =]                -
D4     4        e     d  ]                 -
F#4    4        e     d                    ry
E4     2        s     d  [[                of_
D4     2        s     d  =]                _
C#4    4        e     d  ]                 _
E4     4        e     d                    the
measure 16
D4    12-       q.    d        -           Lord_
D4     8        q     d                    _
D4     4        e     d                    is
measure 17
C#4    4        e     d                    ri-
F#4    8        q     d                    sen
F#4    8        q     d         (          up-
E4     4        e     d         )          -
measure 18
E4    12        q.    d                    on
E4     8        q     d                    thee.
C#4    4        e     d                    O
measure 19
D4     8        q     d                    thou
B3     4        e     d                    that
E4     4        e     d                    tell-
D4     4        e     d                    est
C#4    4        e     d                    good
measure 20
F#4    4        e     d                    ti-
E4     4        e     d                    dings
D4     4        e     d                    to
D4     4        e     d                    Zi-
C#4    4        e     d                    on,
C#4    4        e     d                    say
measure 21
D4     4        e     d                    un-
D4     4        e     d                    to
D4     4        e     d                    the
E4     4        e     d                    ci-
E4     4        e     d                    ties
E4     4        e     d                    of
measure 22
F#4   12        q.    d                    Ju-
E4     8        q     d                    dah,
E4     1        t     d  [[[    (          be-
F#4    1        t     d  ==]               -
G4     2        s     d  ]]     )          -
measure 23
F#4    8        q     d                    hold!
rest   4        e
rest   8        q
B3     4        e     d                    be-
measure 24
F#4    8        q     d                    hold!
rest   4        e
rest   8        q
E4     4        e     d                    the
measure 25
D4     8        q     d                    glo-
D4     4        e     d                    ry
D4     8        q     d                    of
D4     4        e     d                    the
measure 26
D4    12-       q.    d        -           Lord,_
D4     4        e     d                    _
D4     4        e     d                    of
D4     4        e     d                    the
measure 27
C#4   12-       q.    d        -           Lord,_
C#4    8        q     d                    _
rest   4        e
measure 28
rest   8        q
rest   4        e
rest   8        q
F#3    4        e     u                    the
measure 29
F#3    8        q     u                    glo-
F#3    4        e     u                    ry
F#3    8        q     u                    of
F#3    4        e     u                    the
measure 30
F#3   12-       q.    u        -           Lord_
F#3    8        q     u                    _
F#3    4        e     u                    is
measure 31
D4     8        q     d         (          ri-
G4     4        e     d         )          -
E4     8        q     d                    sen
E4     4        e     d                    up-
measure 32
F#4   12        q.    d                    on
F#4   12        q.    d                    thee.
measure 33
rest  24
measure 34
rest  24
measure 35
rest  24
measure 36
rest  24
measure 37
rest  24
measure 38
rest  24
measure 39
rest  24
measure 40
rest  24
measure 41
rest  24
measure 42
rest  24
measure 43
rest  24
measure 44
rest  24
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/7} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:c337a217a6168ce8362ab6695dbbcc56]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
1 23 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:6/8   C:22
rest   2        e
measure 1
rest   4        q
rest   2        e
rest   4        q
A3     2        e     d                    O
measure 2
D3     4        q     u                    thou
E3     2        e     d                    that
C#3    2        e     u                    tell-
D3     2        e     u                    est
E3     2        e     d                    good
measure 3
F#3    2        e     d                    ti-
F#3    2        e     d                    dings
G3     2        e     d                    to
A3     2        e     d                    Zi-
B3     2        e     d                    on,
C#4    2        e     d                    good
measure 4
D4     2        e     d  [                 ti-
E4     2        e     d  ]                 -
D4     2        e     d                    dings
C#4    4        q     d                    to
C#4    2        e     d                    Je-
measure 5
B3     4        q     d                    ru-
G#3    2        e     d                    sa-
A3     4        q     d                    lem,
rest   2        e
measure 6
rest  12
measure 7
rest  12
measure 8
rest   4        q
rest   2        e
rest   4        q
E3     2        e     d                    a-
measure 9
A3     4        q     d                    rise,
rest   2        e
rest   4        q
D3     2        e     u                    a-
measure 10
A3     4        q     d                    rise,
rest   2        e
rest   4        q
A2     2        e     u                    say
measure 11
D3     2        e     u                    un-
D3     2        e     u                    to
B2     2        e     u                    the
E3     2        e     d                    ci-
E3     2        e     d                    ties
C#3    2        e     u                    of
measure 12
F#3    2        e     d                    Ju-
F#3    2        e     d                    dah,
F#3    2        e     d                    be-
G#3    4        q     d                    hold
G#3    2        e     d                    your
measure 13
A3     4        q     d                    God!
rest   2        e
rest   4        q
E3     2        e     d                    be-
measure 14
A3     4        q     d                    hold!
rest   2        e
rest   4        q
C#4    2        e     d                    the
measure 15
D4     1        s     d  [[                glo-
C#4    1        s     d  =]                -
B3     2        e     d  ]                 -
D4     2        e     d                    ry
C#4    1        s     d  [[                of_
B3     1        s     d  =]                _
A3     2        e     d  ]                 _
C#4    2        e     d                    the
measure 16
B3     6-       q.    d        -           Lord_
B3     4        q     d                    _
E3     2        e     d                    is
measure 17
A3     2        e     d                    ri-
F#3    4        q     d                    sen
D3     4        q     d         (          up-
E3     2        e     d         )          -
measure 18
A3     6        q.    d                    on
A3     4        q     d                    thee.
A3     2        e     d                    O
measure 19
F#3    4        q     d                    thou
G3     2        e     d                    that
A3     2        e     d                    tell-
B3     2        e     d                    est
C#4    2        e     d                    good
measure 20
D4     2        e     d                    ti-
C#4    2        e     d                    dings
D4     2        e     d                    to
A3     2        e     d                    Zi-
A3     2        e     d                    on,
G3     2        e     d                    say
measure 21
F#3    2        e     d                    un-
F#3    2        e     d                    to
F#3    2        e     d                    the
E3     2        e     d                    ci-
E3     2        e     d                    ties
E3     2        e     d                    of
measure 22
D3     6        q.    u                    Ju-
A3     4        q     d                    dah,
A3     2        e     d                    be-
measure 23
D4     4        q     d                    hold!
rest   2        e
rest   4        q
G3     2        e     d                    be-
measure 24
D4     4        q     d                    hold!
rest   2        e
rest   4        q
C#4    2        e     d                    the
measure 25
B3     2        e     d  [                 glo-
A3     2        e     d  ]                 -
G3     2        e     d                    ry
F#3    2        e     d  [                 of_
E3     2        e     d  ]                 _
D3     2        e     u                    the
measure 26
G#2    6-       q.    u        -           Lord,_
G#2    2        e     u                    _
G#3    2        e     d                    of
G#3    2        e     d                    the
measure 27
A3     6-       q.    d        -           Lord,_
A3     4        q     d                    _
rest   2        e
measure 28
rest   4        q
rest   2        e
rest   4        q
D3     2        e     u                    the
measure 29
D3     4        q     u                    glo-
D3     2        e     u                    ry
D3     4        q     u                    of
D3     2        e     u                    the
measure 30
D3     6-       q.    u        -           Lord_
D3     4        q     u                    _
D3     2        e     u                    is
measure 31
G3     4        q     d         (          ri-
E3     2        e     d         )          -
A3     4        q     d                    sen
A3     2        e     d                    up-
measure 32
D3     6        q.    u                    on
D3     6        q.    u                    thee.
measure 33
rest  12
measure 34
rest  12
measure 35
rest  12
measure 36
rest  12
measure 37
rest  12
measure 38
rest  12
measure 39
rest  12
measure 40
rest  12
measure 41
rest  12
measure 42
rest  12
measure 43
rest  12
measure 44
rest  12
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-10/8} [KHM:1598576232]
TIMESTAMP: DEC/26/2001 [md5sum:92e86261aada216f0fa09db70af9131b]
04/07/90 E. Correia
WK#:56        MV#:1,10
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
1 23
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:2   Q:4   T:6/8   C:22
D2     2        e     u
measure 1
rest   4        q
rest   2        e
rest   4        q
A3     2        e     d         f
measure 2
D3     4        q     u
E3     2        e     d
C#3    2        e     d  [
D3     2        e     d  =
E3     2        e     d  ]
measure 3
F#3    4        q     d
G3     2        e     d
A3     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 4
D4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  ]
C#4    4        q     d
C#4    2        e     d
measure 5
B3     4        q     d
G#3    2        e     d
A3     4        q     d
$ C:15
E4     2        e     u
measure 6
F#4    4        q     u
D4     2        e     u
E4     2        e     u  [
F#4    2        e     u  ]
&
Below is an alternate reading of this section
  which was not used in the CCARH score or Bassi part
$ C:15
E5     1        e     u          |  This music parallels
measure 6                        |  the Soprano part
A4     2        q     u          |  instead of the
B4     1        e     u          |  Alto, as used
G#4    1        e     u  [       |  above
A4     1        e     u  ]       |
&
$ C:12
f1              #
E4     2        e     d
measure 7
A3     4        q     d
B3     2        e     d
f1              6
G#3    2        e     d  [
A3     2        e     d  =
B3     2        e     d  ]
measure 8
f1              6
C#4    2        e     d  [
D4     2        e     d  =
C#4    2        e     d  ]
B3     4        q     d
$ C:22
E3     2        e     d
measure 9
A3     4        q     d
rest   2        e
rest   4        q
D3     2        e     u
measure 10
A3     4        q     d
rest   2        e
rest   4        q
A2     2        e     u
measure 11
D3     4        q     u
B2     2        e     u
E3     4        q     d
C#3    2        e     u
measure 12
F#3    4        q     d
F#3    2        e     d
G#3    4        q     d
G#3    2        e     d
measure 13
A3     4        q     d
rest   2        e
rest   4        q
E3     2        e     d
measure 14
A3     4        q     d
rest   2        e
rest   4        q
C#4    2        e     d
measure 15
D4     1        s     d  [[
C#4    1        s     d  =]
B3     2        e     d  =
D4     2        e     d  ]
C#4    1        s     d  [[
B3     1        s     d  =]
A3     2        e     d  =
C#4    2        e     d  ]
measure 16
f1              7
B3     6-       q.    d        -
f1              6+
B3     4        q     d
E3     2        e     d
measure 17
A3     2        e     d
F#3    4        q     d
f2              6 5
D3     4        q     d
E3     2        e     d
measure 18
A2     6        q.    u
A2     4        q     u
A3     2        e     d
measure 19
F#3    4        q     d
G3     2        e     d
A3     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 20
D4     2        e     d  [
C#4    2        e     d  =
D4     2        e     d  ]
A3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  ]
measure 21
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  ]
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  ]
measure 22
D3     6        q.    u
A2     4        q     u
A3     2        e     d
measure 23
D4     4        q     d
rest   2        e
rest   4        q
G3     2        e     d
measure 24
D4     4        q     d
rest   2        e
rest   4        q
C#4    2        e     d
measure 25
B3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  ]
F#3    2        e     d  [
E3     2        e     d  =
D3     2        e     d  ]
measure 26
G#2    6-       q.    u        -
G#2    2        e     u  [
G#3    2        e     d  =
G#3    2        e     d  ]
measure 27
A3     6-       q.    d        -
A3     6        q.    d
measure 28
rest   4        q
rest   2        e
rest   4        q
f1              7n
D3     2        e     u
measure 29
D3     4        q     u
D3     2        e     u
D3     4        q     u
D3     2        e     u
measure 30
D3     6-       q.    u        -
D3     4        q     u
D3     2        e     u
measure 31
G3     4        q     d
E3     2        e     d
A3     4        q     d
A2     2        e     u
measure 32
D3     6-       q.    u        -
D3     4        q     u
D3     2        e     u
measure 33
F#3    2        e     d  [
G3     2        e     d  =
E3     2        e     d  ]
A3     2        e     d  [
B3     2        e     d  =
C#4    2        e     d  ]
measure 34
D4     2        e     d  [
E4     2        e     d  =
D4     2        e     d  ]
A3     4        q     d
G3     2        e     d
measure 35
F#3    4        q     d
D4     2        e     d
E3     4        q     d
C#4    2        e     d
measure 36
D3     4        q     d
D4     2        e     d
C#4    4        q     d
A3     2        e     d
measure 37
F#3    4        q     d
D3     2        e     d
G2     2        e     d  [
B3     2        e     d  =
A3     2        e     d  ]
measure 38
G#3    4        q     d
G#2    2        e     u
A2     2        e     u  [
C#4    2        e     d  =
B3     2        e     d  ]
measure 39
A#3    4        q     d
A#2    2        e     u
B2     2        e     u  [
D3     2        e     u  =
B2     2        e     u  ]
measure 40
C#3    2        e     u  [
A2     2        e     u  =      +
C#3    2        e     u  ]
D3     2        e     d  [
F#3    2        e     d  =
D3     2        e     d  ]
measure 41
B3     2        e     d  [
A3     2        e     d  =
G3     2        e     d  ]
F#3    2        e     d  [
E3     2        e     d  =
D3     2        e     d  ]
measure 42
f2              6 5
G#2    2        e     u  [
B2     2        e     u  =
A2     2        e     u  ]
f2              6 5
G#2    2        e     u  [
B2     2        e     u  =
A2     2        e     u  ]
measure 43
f2              6 5
G#2    2        e     u  [
B2     2        e     u  =
G#2    2        e     u  ]
A2     2        e     u  [
C#3    2        e     u  =
D3     2        e     u  ]
measure 44
G3     2        e     d  [
A3     2        e     d  =
A2     2        e     d  ]
D3     4        q     d         F
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
