&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-05/1} [KHM:3900402988]
TIMESTAMP: DEC/26/2001 [md5sum:5ea3d4c4f24bb3971c7d9bbd98e092f9]
06/24/90 E. Correia
WK#:56        MV#:3,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Contr'alto
1 20 A
Group memberships: score
score: part 1 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:4   T:1/1   C:4
rest   4        q
rest   2        e
F4     2        e     u                    Then
F4     2        e     u                    shall
F4     2        e     u                    be
F4     2        e     u                    brought
G4     2        e     u                    to
measure 2
A4     4        q     u                    pass
rest   2        e
Ef4    2        e     u                    the
G4     2        e     u                    say-
G4     2        e     u                    ing
G4     2        e     u                    that
F4     2        e     u                    is
measure 3
D4     2        e     u                    writ-
D4     2        e     u                    ten,
rest   4        q
F4     4        q     u                    Death
rest   4        q
measure 4
rest   2        e
F4     2        e     u                    is
Ef4    2        e     u                    swal-
D4     2        e     u                    low'd
G4     4        q     u                    up
rest   2        e
Bf4    2        e     u                    in
measure 5
Bf4    3        e.    u                    vic-
F4     1        s     u                    to-
F4     4        q     u                    ry.
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-05/2} [KHM:3900402988]
TIMESTAMP: DEC/26/2001 [md5sum:7acb09f0822b5ccd75fe4450711fe349]
06/24/90 E. Correia
WK#:56        MV#:3,5
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recitative
Bassi
1 20
Group memberships: score
score: part 2 of 2
&
Tranfer from old stage2 to new stage2
&
$ K:-1   Q:1   T:1/1   C:22
Bf2    4        w     u
measure 2
f2              6 f
C3     2        h     u
A2     2        h     u
measure 3
Bf2    2        h     u
f2              4 2
Af2    2-       h     u        -
measure 4
Af2    2        h     u
Ef2    2-       h     u        -
measure 5
Ef2    1        q     u
F2     1        q     u
Bf2    2        h     u
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
