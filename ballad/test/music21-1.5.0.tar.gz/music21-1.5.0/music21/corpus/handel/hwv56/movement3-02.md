&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/1} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:55b717b5bf7b4d2431d7d961fd2e6422]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino I
0 75
Group memberships: score
score: part 1 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:4   D:Grave
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest  16
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
G5     1        e     d
C6     2        q     d
B5     2        q     d
measure 8
C6     1        e     d  [
C5     1        e     d  =
E5     1        e     d  =
G5     1        e     d  ]
C6     2        q     d
B5     2        q     d
measure 9
C6     1        e     d  [
C5     1        e     d  =
E5     1        e     d  =
G5     1        e     d  ]
C6     2        q     d
B5     2        q     d
measure 10
C6     1        e     d  [
C5     1        e     d  =
E5     1        e     d  =
C5     1        e     d  ]
G5     1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
F#5    1        e     d  ]
measure 11
G5     1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
F#5    1        e     d  ]
G5     1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
F#5    1        e     d  ]
measure 12
G5     1        e     d  [
G5     1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
C6     1        e     d  [
G5     1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
measure 13
C6     1        e     d  [
G5     1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
C6     1        e     d  [
G5     1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
measure 14
C6     1        e     d  [
E5     1        e     d  =
F5     1        e     d  =
G5     1        e     d  ]
A5     1        e     d  [
B5     1        e     d  =
C6     1        e     d  =
D6     1        e     d  ]
measure 15
G5     2        q     d
C6     1        e     d  [
D6     1        e     d  ]
B5     3        q.    d         &t
B5     1        e     d
measure 16
C6     2        q     d
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest  16
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
A5     1        e     d  [
A5     1        e     d  ]
D6     2        q     d
C#6    2        q     d
measure 24
D6     1        e     d  [
D5     1        e     d  =
F5     1        e     d  =
A5     1        e     d  ]
D6     1        e     d  [
D6     1        e     d  =
C#6    1        e     d  =
C#6    1        e     d  ]
measure 25
D6     1        e     d  [
D5     1        e     d  =
F5     1        e     d  =
A5     1        e     d  ]
D6     2        q     d
C#6    2        q     d
measure 26
D6     1        e     d  [
D5     1        e     d  =
F5     1        e     d  =
A5     1        e     d  ]
G#5    1        e     d  [
G#5    1        e     d  =
A5     1        e     d  =
A5     1        e     d  ]
measure 27
B5     1        e     d  [
E5     1        e     d  =
G#5    1        e     d  =
B5     1        e     d  ]
C6     1        e     d  [
E5     1        e     d  =
E5     1        e     d  =
A5     1        e     d  ]
measure 28
G#5    1        e     d  [
E5     1        e     d  =
G#5    1        e     d  =
B5     1        e     d  ]
C6     1        e     d  [
G#5    1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
measure 29
G#5    1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
E5     1        e     d  ]
C5     2        q     d
C6     1        e     d  [
B5     1        e     d  ]
measure 30
B5     1        e     d  [
D6     1        e     d  =
C6     1        e     d  =
B5     1        e     d  ]
B5     3        q.    d
B5     1        e     d
measure 31
C6     1        e     d  [
A4     1        e     d  =
C5     1        e     d  =
E5     1        e     d  ]
A5     2        q     d
G#5    2        q     d
measure 32
A5     1        e     d  [
A4     1        e     d  =
C5     1        e     d  =
E5     1        e     d  ]
A5     2        q     d
B5     2        q     d
measure 33
C6     2        q     d
B5     1        e     d  [
A5     1        e     d  ]
G#5    3        q.    d         &t
G#5    1        e     d
measure 34
A5     1        e     d  [
E5     1        e     d  =
C6     1        e     d  =
B5     1        e     d  ]
A5     1        e     d  [
G#5    1        e     d  =
A5     1        e     d  =
B5     1        e     d  ]
measure 35
G#5    2        q     d
E5     4        h     d
A5     2        q     d
measure 36
G#5    1        e     d  [
E5     1        e     d  =
C6     1        e     d  =
A5     1        e     d  ]
G#5    3        q.    d         &t
A5     1        e     d
measure 37
A5     2        q     d
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/2} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:e59dd4aaae71b16a7247501d0f15f9b5]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Violino II
0 75
Group memberships: score
score: part 2 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:4   D:Grave
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest  16
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
E5     1        e     d
G5     2        q     d
D5     2        q     d
measure 8
E5     2        q     d
C5     1        e     d  [
C5     1        e     d  ]
G5     2        q     d
D5     2        q     d
measure 9
E5     2        q     d
C5     2        q     d
G5     2        q     d
D5     2        q     d
measure 10
E5     2        q     d
rest   1        e
E5     1        e     d
D5     2        q     d
C5     2        q     d
measure 11
B4     2        q     d
G4     2        q     u
D5     2        q     d
C5     2        q     d
measure 12
B4     3        q.    d
G5     1        e     d
G5     2        q     d
F5     2        q     d
measure 13
E5     2        q     d
C5     2        q     d
G5     2        q     d
F5     2        q     d
measure 14
E5     2        q     d
D5     1        e     d  [
C5     1        e     d  ]
C5     2        q     d
F5     2        q     d
measure 15
E5     1        e     d  [
F5     1        e     d  ]
G5     2        q     d
D5     3        q.    d
D5     1        e     d
measure 16
E5     2        q     d
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest  16
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
F5     1        e     d  [
F5     1        e     d  ]
A5     2        q     d
E5     2        q     d
measure 24
F5     1        e     d  [
A4     1        e     d  =
D5     1        e     d  =
F5     1        e     d  ]
A5     1        e     d  [
A5     1        e     d  =
E5     1        e     d  =
E5     1        e     d  ]
measure 25
F5     1        e     d  [
A4     1        e     d  =
D5     1        e     d  =
F5     1        e     d  ]
A5     2        q     d
E5     2        q     d
measure 26
F5     1        e     d  [
A4     1        e     d  =
D5     1        e     d  =
E5     1        e     d  ]
D5     1        e     d  [
D5     1        e     d  =
C5     1        e     d  =
A5     1        e     d  ]
measure 27
G#5    1        e     d  [
G#4    1        e     d  =
B4     1        e     d  =
G#5    1        e     d  ]
E5     1        e     d  [
A4     1        e     d  =
A4     1        e     d  =
E5     1        e     d  ]
measure 28
B4     1        e     d  [
G#5    1        e     d  =
B5     1        e     d  =
G#5    1        e     d  ]
E5     1        e     d  [
D5     1        e     d  =
C5     1        e     d  =
B4     1        e     d  ]
measure 29
B4     1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
E4     2        q     u
A5     2        q     d
measure 30
G#5    1        e     d  [
B5     1        e     d  ]
A5     2        q     d
A5     2        q     d
G#5    2        q     d
measure 31
A5     1        e     d  [
E4     1        e     u  =
A4     1        e     u  =
C5     1        e     u  ]
E5     2        q     d
B4     2        q     d
measure 32
C5     1        e     u  [
E4     1        e     u  =
A4     1        e     u  =
C5     1        e     u  ]
E5     2        q     d
G#5    2        q     d
measure 33
A5     1        e     d  [
E5     1        e     d  =
D5     1        e     d  =
F5     1        e     d  ]
B4     3        q.    d
B4     1        e     d
measure 34
C5     1        e     u  [
B4     1        e     u  =
A4     1        e     u  =
G#4    1        e     u  ]
E5     1        e     d  [
D5     1        e     d  =
E5     1        e     d  =
F5     1        e     d  ]
measure 35
B4     1        e     u  [
G#4    1        e     u  =
A4     1        e     u  =
B4     1        e     u  ]
C5     1        e     d  [
B4     1        e     d  =
A4     1        e     d  =
F5     1        e     d  ]
measure 36
B4     1        e     d  [
E5     1        e     d  =
E5     1        e     d  =
F5     1        e     d  ]
B4     3        q.    d
E5     1        e     d
measure 37
C5     2        q     d
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/3} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:035a757df9edc7a7242320b19a693906]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Viola
0 75
Group memberships: score
score: part 3 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:13   D:Grave
rest   8
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest  16
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
G4     1        e     d
G4     2        q     d
G4     2        q     d
measure 8
G4     2        q     d
G4     1        e     d  [
G4     1        e     d  ]
G4     2        q     d
G4     2        q     d
measure 9
G4     2        q     d
G4     2        q     d
G4     2        q     d
G4     2        q     d
measure 10
G4     2        q     d
rest   1        e
G4     1        e     d
G4     3        q.    d
F#4    1        e     d
measure 11
D5     2        q     d
C5     2        q     d
G4     3        q.    d
F#4    1        e     d
measure 12
D5     3        q.    d
D5     1        e     d
C5     2        q     d
F4     2        q     d         +
measure 13
G4     2        q     d
F4     2        q     d
G4     2        q     d
D4     2        q     d
measure 14
G4     2        q     d
F4     1        e     d  [
E4     1        e     d  ]
A4     2        q     d
A4     2        q     d
measure 15
G4     2        q     d
G4     2        q     d
G4     3        q.    d
G4     1        e     d
measure 16
G4     2        q     d
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   8
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest  16
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
D4     1        e     d  [
D4     1        e     d  ]
A3     2        q     u
A4     2        q     d
measure 24
A4     1        e     d  [
F4     1        e     d  =
A4     1        e     d  =
D5     1        e     d  ]
A4     1        e     d  [
A4     1        e     d  =
A4     1        e     d  =
A4     1        e     d  ]
measure 25
A4     1        e     d  [
F4     1        e     d  =
A4     1        e     d  =
D5     1        e     d  ]
A4     2        q     d
A4     2        q     d
measure 26
A4     1        e     d  [
F4     1        e     d  =
A4     1        e     d  =
A4     1        e     d  ]
B4     1        e     d  [
B4     1        e     d  =
E4     1        e     d  =
E4     1        e     d  ]
measure 27
E4     1        e     d  [
B4     1        e     d  =
E5     1        e     d  =
E4     1        e     d  ]
E4     2        q     d
E4     2        q     d
measure 28
E4     2        q     d
rest   1        e
E4     1        e     d
C4     1        e     d  [
D4     1        e     d  =
E4     1        e     d  =
F4     1        e     d  ]
measure 29
E4     1        e     d  [
B4     1        e     d  =
A4     1        e     d  =
E4     1        e     d  ]
A4     2        q     d
E4     2        q     d
measure 30
E4     3        q.    d
F4     1        e     d
E4     3        q.    d
E4     1        e     d
measure 31
E4     2        q     d
rest   1        e
A4     1        e     d
E4     2        q     d
E4     2        q     d
measure 32
E4     1        e     d  [
C4     1        e     d  =
E4     1        e     d  =
A4     1        e     d  ]
E4     2        q     d
E4     2        q     d
measure 33
E4     2        q     d
F4     2        q     d
E4     3        q.    d
E4     1        e     d
measure 34
E4     3        q.    d
D4     1        e     d
C4     1        e     d  [
D4     1        e     d  =
C4     1        e     d  =
B3     1        e     d  ]
measure 35
B3     2        q     u
rest   1        e
E4     1        e     d
E4     3        q.    d
D5     1        e     d
measure 36
B4     2        q     d
A4     2        q     d
E4     2        q     d
E4     2        q     d
measure 37
E4     2        q     d
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/4} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:831e5e1ff7fe5c19214feded62e30af4]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Soprano
0 75 S
Group memberships: score
score: part 4 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:4   D:Grave
rest   2        q
E4     4        h     u                    Since
E4     2        q     u                    by
measure 2
A4     4        h     u                    man
B4     4        h     d                    came
measure 3
C5     8        w     d                    death,
measure 4
rest   2        q
C#5    4        h     d                    since
C#5    2        q     d                    by
measure 5
D5     4        h     d                    man
D#5    4        h     d                    came
measure 6
E5    16        b     d                    death,
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
E5     1        e     d                    By
G5     2        q     d                    man
D5     2        q     d                    came
measure 8
E5     2        q     d                    al-
C5     1        e     d                    so
C5     1        e     d                    the
G5     2        q     d                    re-
D5     2        q     d                    sur-
measure 9
E5     2        q     d                    rec-
C5     2        q     d                    tion
G5     2        q     d                    of
D5     2        q     d                    the
measure 10
E5     2        q     d                    dead,
rest   1        e
E5     1        e     d                    by
D5     2        q     d                    man
C5     2        q     d                    came
measure 11
B4     2        q     d                    al-
E5     1        e     d                    so
E5     1        e     d                    the
D5     2        q     d                    re-
C5     2        q     d                    sur-
measure 12
B4     2        q     d                    rec-
B4     2        q     d                    tion
C5     1        e     u  [                 of_
G4     1        e     u  ]                 _
A4     1        e     u  [                 the_
B4     1        e     u  ]                 _
measure 13
C5     2        q     d                    dead,
C5     2        q     d                    by
C5     1        e     u  [                 man_
G4     1        e     u  ]                 _
A4     1        e     u  [                 came_
B4     1        e     u  ]                 _
measure 14
C5     2        q     d                    al-
B4     1        e     d                    so
C5     1        e     d                    the
A4     1        e     u  [                 re-
B4     1        e     u  ]                 -
C5     1        e     d  [                 sur-
D5     1        e     d  ]                 -
measure 15
E5     1        e     d  [                 rec-
F5     1        e     d  ]                 -
G5     2        q     d                    tion
D5     3        q.    d                    of
D5     1        e     d                    the
measure 16
E5     2        q     d                    dead.
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   2        q
G4     2        q     u                    For
G4     2        q     u                    as
G4     2        q     u                    in
measure 18
C#5    4        h     d                    A-
C#5    2        q     d                    dam
C#5    2        q     d                    all
measure 19
D5     8        w     d                    die,
measure 20
rest   2        q
F5     2        q     d                    for
F5     2        q     d                    as
F5     2        q     d                    in
measure 21
D5     4        h     d                    A-
D5     2        q     d                    dam
D5     2        q     d                    all
measure 22
D5     4        h     d         (          die,_
C#5    2        q     d                    _
B4     2        q     d                    _
C#5    8        w     d         )          _
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
A4     1        e     u                    Ev-
A4     1        e     u                    en
D5     2        q     d                    so
C#5    2        q     d                    in
measure 24
D5     2        q     d                    Christ
rest   1        e
D5     1        e     d                    shall
D5     1        e     d                    all
D5     1        e     d                    be
C#5    1        e     d                    made
C#5    1        e     d                    a-
measure 25
D5     2        q     d                    live,
A4     1        e     u                    ev-
A4     1        e     u                    en
D5     2        q     d                    so
C#5    2        q     d                    in
measure 26
D5     2        q     d                    Christ
rest   1        e
E5     1        e     d                    shall
D5     1        e     d                    all
D5     1        e     d                    be
C5     1        e     d         +          made
C5     1        e     d                    a-
measure 27
B4     2        q     d                    live,
E5     1        e     d                    ev-
E5     1        e     d                    en
E5     2        q     d                    so
C5     2        q     d                    in
measure 28
B4     2        q     d                    Christ
rest   1        e
B4     1        e     d                    shall
C5     1        e     d  [                 all,_
B4     1        e     d  =                 _
A4     1        e     d  =                 _
F5     1        e     d  ]                 _
measure 29
E5     2        q     d                    _
D5     1        e     d                    so
E5     1        e     d                    in
C5     2        q     d                    Christ
C5     1        e     d  [                 shall_
B4     1        e     d  ]                 _
measure 30
B4     1        e     d  [                 all_
D5     1        e     d  =                 _
C5     1        e     d  ]                 _
B4     1        e     d                    be
B4     3        q.    d                    made
B4     1        e     d                    a-
measure 31
C5     2        q     d                    live,
rest   1        e
C5     1        e     d                    e'en
E5     2        q     d                    so
B4     2        q     d                    in
measure 32
C5     3        q.    d                    Christ
C5     1        e     d                    shall
E5     2        q     d                    all,
B4     2        q     d                    shall
measure 33
C5     2        q     d                    all
B4     1        e     u  [                 be_
A4     1        e     u  ]                 _
G#4    3        q.    u                    made
G#4    1        e     u                    a-
measure 34
A4     4        h     u                    live.
rest   4        h
measure 35
rest   8
measure 36
rest   8
measure 37
rest   8
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/5} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:54a3ecba854cc9b58880459ef50505b3]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Alto
0 75 A
Group memberships: score
score: part 5 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:4   D:Grave
rest   2        q
C4     4        h     u                    Since
C4     2        q     u                    by
measure 2
D4     4        h     u                    man
F4     4        h     u                    came
measure 3
E4     8        w     u                    death,
measure 4
rest   2        q
E4     4        h     u                    since
E4     2        q     u                    by
measure 5
D4     4        h     u                    man
A4     4        h     u                    came
measure 6
A4     4        h     u         (          death,_
G#4    2        q     u                    _
F#4    2        q     u                    _
G#4    8        w     u         )          _
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
G4     1        e     u                    By
G4     2        q     u                    man
G4     2        q     u                    came
measure 8
E4     2        q     u                    al-
G4     1        e     u                    so
G4     1        e     u                    the
G4     2        q     u                    re-
G4     2        q     u                    sur-
measure 9
G4     2        q     u                    rec-
G4     2        q     u                    tion
G4     2        q     u                    of
G4     2        q     u                    the
measure 10
G4     2        q     u                    dead,
rest   1        e
G4     1        e     u                    by
G4     3        q.    u                    man
F#4    1        e     u                    came
measure 11
G4     2        q     u                    al-
G4     1        e     u                    so
G4     1        e     u                    the
G4     3        q.    u                    re-
F#4    1        e     u                    sur-
measure 12
G4     2        q     u                    rec-
G4     2        q     u                    tion
G4     2        q     u                    of
F4     2        q     u         +          the
measure 13
E4     2        q     u                    dead,
A4     2        q     u                    by
G4     2        q     u                    man
F4     2        q     u                    came
measure 14
G4     2        q     u                    al-
F4     1        e     u                    so
G4     1        e     u                    the
A4     2        q     u                    re-
A4     2        q     u                    sur-
measure 15
G4     2        q     u                    rec-
G4     2        q     u                    tion
G4     3        q.    u                    of
G4     1        e     u                    the
measure 16
G4     2        q     u                    dead.
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   2        q
D4     2        q     u                    For
D4     2        q     u                    as
D4     2        q     u                    in
measure 18
E4     4        h     u                    A-
E4     2        q     u                    dam
E4     2        q     u                    all
measure 19
F4     8        w     u                    die,
measure 20
rest   2        q
A4     2        q     u                    for
A4     2        q     u                    as
A4     2        q     u                    in
measure 21
A4     4        h     u                    A-
G4     2        q     u                    dam
G4     2        q     u                    all
measure 22
A4    16        b     u                    die,
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
F4     1        e     u                    Ev-
F4     1        e     u                    en
A4     2        q     u                    so
A4     2        q     u                    in
measure 24
A4     2        q     u                    Christ
rest   1        e
A4     1        e     u                    shall
A4     1        e     u                    all
A4     1        e     u                    be
A4     1        e     u                    made
A4     1        e     u                    a-
measure 25
A4     2        q     u                    live,
F4     1        e     u                    ev-
F4     1        e     u                    en
A4     2        q     u                    so
A4     2        q     u                    in
measure 26
A4     2        q     u                    Christ
rest   1        e
A4     1        e     u                    shall
G#4    1        e     u                    all
G#4    1        e     u                    be
A4     1        e     u                    made
A4     1        e     u                    a-
measure 27
G#4    2        q     u                    live,
G#4    1        e     u                    ev-
G#4    1        e     u                    en
A4     2        q     u                    so
A4     2        q     u                    in
measure 28
G#4    2        q     u                    Christ
rest   1        e
G#4    1        e     u                    shall
A4     1        e     u  [                 all,_
G#4    1        e     u  =                 _
A4     1        e     u  =                 _
B4     1        e     u  ]                 _
measure 29
G#4    2        q     u                    _
A4     1        e     u                    so
B4     1        e     u                    in
A4     3        q.    u                    Christ
A4     1        e     u                    shall
measure 30
G#4    1        e     u  [                 all_
B4     1        e     u  =                 _
A4     1        e     u  ]                 _
A4     1        e     u                    be
A4     2        q     u                    made
G#4    2        q     u                    a-
measure 31
A4     2        q     u                    live,
rest   1        e
A4     1        e     u                    e'en
A4     2        q     u                    so
G#4    2        q     u                    in
measure 32
A4     3        q.    u                    Christ
A4     1        e     u                    shall
A4     2        q     u                    all,
G#4    2        q     u                    shall
measure 33
A4     2        q     u                    all
F4     2        q     u                    be
E4     3        q.    u                    made
E4     1        e     u                    a-
measure 34
E4     4        h     u                    live.
rest   4        h
measure 35
rest   8
measure 36
rest   8
measure 37
rest   8
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 6
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/6} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:fff02a7957a485503ef55d32182fb499]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tenore
0 75 T
Group memberships: score
score: part 6 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:34   D:Grave
rest   2        q
A3     4        h     u                    Since
A3     2        q     u                    by
measure 2
A3     4        h     u                    man
D4     4        h     d                    came
measure 3
C4     8        w     d                    death,
measure 4
rest   2        q
Bf3    4        h     u                    since
Bf3    2        q     u                    by
measure 5
A3     6        h.    u                    man
B3     2        q     u         +          came
measure 6
C4     4        h     d         (          death,_
B3     2        q     u                    _
A3     2        q     u                    _
B3     8        w     u         )          _
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
C4     1        e     d                    By
C4     2        q     d                    man
B3     2        q     d                    came
measure 8
G4     2        q     d                    al-
E4     1        e     d                    so
E4     1        e     d                    the
C4     2        q     d                    re-
B3     2        q     d                    sur-
measure 9
C4     2        q     d                    rec-
E4     2        q     d                    tion
C4     2        q     d                    of
B3     2        q     d                    the
measure 10
C4     2        q     d                    dead,
rest   1        e
C4     1        e     d                    by
D4     2        q     d                    man
E4     1        e     d  [                 came_
C4     1        e     d  ]                 _
measure 11
D4     2        q     d                    al-
E4     1        e     d                    so
C4     1        e     d                    the
D4     2        q     d                    re-
E4     1        e     d  [                 sur-
C4     1        e     d  ]                 -
measure 12
D4     2        q     d                    rec-
D4     2        q     d                    tion
C4     2        q     d                    of
F3     2        q     u                    the
measure 13
G3     2        q     u                    dead,
F3     2        q     u                    by
C4     2        q     d                    man
F4     2        q     d                    came
measure 14
E4     2        q     d                    al-
D4     1        e     d                    so
C4     1        e     d                    the
C4     2        q     d                    re-
F4     2        q     d                    sur-
measure 15
E4     2        q     d                    rec-
C4     2        q     d                    tion
B3     3        q.    d                    of
B3     1        e     d                    the
measure 16
C4     2        q     d                    dead.
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   2        q
Bf3    2        q     d                    For
Bf3    2        q     d                    as
Bf3    2        q     d                    in
measure 18
G3     4        h     u                    A-
G3     2        q     u                    dam
G3     2        q     u                    all
measure 19
A3     8        w     u                    die,
measure 20
rest   2        q
D4     2        q     d                    for
D4     2        q     d                    as
D4     2        q     d                    in
measure 21
D4     4        h     d                    A-
D4     2        q     d                    dam
E4     2        q     d                    all
measure 22
F4     4        h     d         (          die,_
E4     2        q     d                    _
D4     2        q     d                    _
E4     8        w     d         )          _
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
D4     1        e     d                    Ev-
D4     1        e     d                    en
D4     2        q     d                    so
E4     2        q     d                    in
measure 24
F4     2        q     d                    Christ
rest   1        e
F4     1        e     d                    shall
F4     1        e     d                    all
F4     1        e     d                    be
E4     1        e     d                    made
E4     1        e     d                    a-
measure 25
F4     2        q     d                    live,
D4     1        e     d                    ev-
D4     1        e     d                    en
D4     2        q     d                    so
E4     2        q     d                    in
measure 26
F4     2        q     d                    Christ
rest   1        e
C4     1        e     d                    shall
D4     1        e     d                    all
D4     1        e     d                    be
E4     1        e     d                    made
E4     1        e     d                    a-
measure 27
E4     2        q     d                    live,
B3     1        e     d                    ev-
B3     1        e     d                    en
C4     2        q     d                    so
E4     2        q     d                    in
measure 28
E4     2        q     d                    Christ
rest   1        e
E4     1        e     d                    shall
E4     1        e     d  [                 all,_
D4     1        e     d  =                 _
E4     1        e     d  =                 _
F4     1        e     d  ]                 _
measure 29
B3     2        q     d                    _
A3     1        e     u                    so
E4     1        e     d                    in
E4     3        q.    d                    Christ
F4     1        e     d                    shall
measure 30
E4     3        q.    d                    all
F4     1        e     d                    be
E4     3        q.    d                    made
E4     1        e     d                    a-
measure 31
E4     2        q     d                    live,
rest   1        e
E4     1        e     d                    e'en
E4     2        q     d                    so
E4     2        q     d                    in
measure 32
E4     3        q.    d                    Christ
E4     1        e     d                    shall
E4     2        q     d                    all,
E4     2        q     d                    shall
measure 33
E4     2        q     d                    all
D4     1        e     d  [                 be_
C4     1        e     d  ]                 _
B3     3        q.    d                    made
B3     1        e     d                    a-
measure 34
C4     4        h     d                    live.
rest   4        h
measure 35
rest   8
measure 36
rest   8
measure 37
rest   8
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 7
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/7} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:72c953335a1d46167c9fc796226f6bc2]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Basso
0 75 B
Group memberships: score
score: part 7 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:22   D:Grave
rest   2        q
A2     4        h     u                    Since
A2     2        q     u                    by
measure 2
F3     4        h     d                    man
D3     4        h     d                    came
measure 3
A3     8        w     d                    death,
measure 4
rest   2        q
G3     4        h     d                    since
G3     2        q     d                    by
measure 5
F#3    4        h     d                    man
F3     4        h     d                    came
measure 6
E3    16        b     d                    death,
mdouble 7
$ T:1/1   D:Allegro
rest   2        q
rest   1        e
C3     1        e     u                    By
E3     2        q     d                    man
G3     2        q     d                    came
measure 8
C4     2        q     d                    al-
C3     1        e     u                    so
C3     1        e     u                    the
E3     2        q     d                    re-
G3     2        q     d                    sur-
measure 9
C4     2        q     d                    rec-
C3     2        q     u                    tion
E3     2        q     d                    of
G3     2        q     d                    the
measure 10
C4     2        q     d                    dead,
rest   1        e
C4     1        e     d                    by
B3     2        q     d                    man
A3     2        q     d                    came
measure 11
G3     2        q     d                    al-
C4     1        e     d                    so
C4     1        e     d                    the
B3     2        q     d                    re-
A3     2        q     d                    sur-
measure 12
G3     2        q     d                    rec-
F3     2        q     d                    tion
E3     2        q     d                    of
D3     2        q     d                    the
measure 13
C3     2        q     u                    dead,
F3     2        q     d                    by
E3     2        q     d                    man
D3     2        q     d                    came
measure 14
C3     2        q     u                    al-
D3     1        e     d                    so
E3     1        e     d                    the
F3     1        e     d  [                 re-
G3     1        e     d  ]                 -
A3     1        e     d  [                 sur-
B3     1        e     d  ]                 -
measure 15
C4     2        q     d                    rec-
E3     1        e     d  [                 tion_
F3     1        e     d  ]                 _
G3     3        q.    d                    of
G3     1        e     d                    the
measure 16
C3     2        q     u                    dead.
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
rest   2        q
G3     2        q     d                    For
G3     2        q     d                    as
G3     2        q     d                    in
measure 18
E3     4        h     d                    A-
E3     2        q     d                    dam
E3     2        q     d                    all
measure 19
D3     8        w     d                    die,
measure 20
rest   2        q
D3     2        q     d                    for
D3     2        q     d                    as
D3     2        q     d                    in
measure 21
Bf3    4        h     d                    A-
Bf3    2        q     d                    dam
Bf3    2        q     d                    all
measure 22
A3    16        b     d                    die,
mdouble 23
$ T:1/1   D:Allegro
rest   2        q
D3     1        e     d                    Ev-
D3     1        e     d                    en
F3     2        q     d                    so
A3     2        q     d                    in
measure 24
D4     2        q     d                    Christ
rest   1        e
D3     1        e     d                    shall
F3     1        e     d                    all
F3     1        e     d                    be
A3     1        e     d                    made
A3     1        e     d                    a-
measure 25
D4     2        q     d                    live,
D3     1        e     d                    ev-
D3     1        e     d                    en
F3     2        q     d                    so
A3     2        q     d                    in
measure 26
D4     2        q     d                    Christ
rest   1        e
C4     1        e     d                    shall
B3     1        e     d                    all
B3     1        e     d                    be
A3     1        e     d                    made
A3     1        e     d                    a-
measure 27
E4     2        q     d                    live,
E3     1        e     d                    ev-
E3     1        e     d                    en
A3     2        q     d                    so
C4     2        q     d                    in
measure 28
E4     2        q     d                    Christ
rest   1        e
E3     1        e     d                    shall
A2     1        e     u  [                 all_
B2     1        e     u  =                 _
C3     1        e     u  =                 _
D3     1        e     u  ]                 _
measure 29
E3     2        q     d                    _
F#3    1        e     d  [                 _
G#3    1        e     d  ]                 _
A3     1        e     d  [                 _
B3     1        e     d  =                 _
C4     1        e     d  =                 _
D4     1        e     d  ]                 _
measure 30
E4     1        e     d  [                 _
G#3    1        e     d  =                 _
A3     1        e     d  ]                 _
D3     1        e     d                    be
E3     3        q.    d                    made
E3     1        e     d                    a-
measure 31
A2     2        q     u                    live,
rest   1        e
A2     1        e     u                    e'en
C3     2        q     u                    so
E3     2        q     d                    in
measure 32
A3     3        q.    d                    Christ
A2     1        e     u                    shall
C3     2        q     u                    all,
E3     2        q     d                    shall
measure 33
A3     2        q     d                    all
D3     2        q     d                    be
E3     3        q.    d                    made
E3     1        e     d                    a-
measure 34
A2     4        h     u                    live.
rest   4        h
measure 35
rest   8
measure 36
rest   8
measure 37
rest   8
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 8
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/3-02/8} [KHM:3997147619]
TIMESTAMP: DEC/26/2001 [md5sum:183f8fa7852779bc0fedd93c5d8891ed]
06/24/90 E. Correia
WK#:56        MV#:3,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Chorus
Tutti Bassi
0 75
Group memberships: score
score: part 8 of 8
&
Tranfer from old stage2 to new stage2
&
$ K:0   Q:2   T:1/1   C:22   D:Grave
A2     2        q     u
rest   2        q
rest   4        h
measure 2
rest   8
measure 3
rest   8
measure 4
rest   8
measure 5
rest   8
measure 6
rest  16
mdouble 7
$ T:1/1   D:Allegro
C3     2        q     u
rest   1        e
C3     1        e     u
E3     2        q     d
G3     2        q     d
measure 8
C4     2        q     d
C3     1        e     u  [
C3     1        e     u  ]
E3     2        q     d
G3     2        q     d
measure 9
C4     2        q     d
C3     2        q     u
E3     2        q     d
G3     2        q     d
measure 10
C4     2        q     d
rest   1        e
C4     1        e     d
B3     2        q     d
A3     2        q     d
measure 11
G3     2        q     d
C4     1        e     d  [
C4     1        e     d  ]
B3     2        q     d
A3     2        q     d
measure 12
G3     2        q     d
F3     2        q     d
E3     2        q     d
D3     2        q     d
measure 13
C3     2        q     u
F3     2        q     d
E3     2        q     d
D3     2        q     d
measure 14
C3     2        q     u
D3     1        e     d  [
E3     1        e     d  ]
F3     1        e     d  [
G3     1        e     d  =
A3     1        e     d  =
B3     1        e     d  ]
measure 15
C4     2        q     d
E3     1        e     d  [
F3     1        e     d  ]
G3     2        q     d
G2     2        q     u
measure 16
C3     2        q     u
rest   2        q
rest   4        h
mdouble 17
$ T:1/1   D:Grave
f1              f
G2     4        h     u
rest   4        h
measure 18
rest   8
measure 19
rest   8
measure 20
rest   8
measure 21
rest   8
measure 22
rest  16
mdouble 23
$ T:1/1   D:Allegro
D3     3        q.    d
D3     1        e     d
f1              6
F3     2        q     d
f1              #
A3     2        q     d
measure 24
D4     2        q     d
rest   1        e
D3     1        e     d
f1              6
F3     1        e     d  [
F3     1        e     d  =
f1              #
A3     1        e     d  =
A3     1        e     d  ]
measure 25
D4     2        q     d
D3     2        q     d
f1              6
F3     2        q     d
f1              #
A3     2        q     d
measure 26
D4     3        q.    d
f1              6
C4     1        e     d
f1              6+
B3     1        e     d  [
B3     1        e     d  =
A3     1        e     d  =
A3     1        e     d  ]
measure 27
f1              #
E4     2        q     d
E3     2        q     d
A3     2        q     d
f1              6
C4     2        q     d
measure 28
f1              #
E4     2        q     d
rest   1        e
E3     1        e     d
A2     1        e     u  [
B2     1        e     u  =
f1              6
C3     1        e     u  =
D3     1        e     u  ]
measure 29
E3     2        q     d
F#3    1        e     d  [
G#3    1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C4     1        e     d  =
D4     1        e     d  ]
measure 30
E4     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
D3     1        e     d  ]
E3     2        q     d
E2     2        q     u
measure 31
A2     2        q     u
rest   1        e
A2     1        e     u
f1              6
C3     2        q     u
f1              #
E3     2        q     d
measure 32
A3     3        q.    d
A2     1        e     u
f1              6
C3     2        q     u
f1              #
E3     2        q     d
measure 33
A3     2        q     d
D3     2        q     d
E3     2        q     d
E2     2        q     u
measure 34
A2     3        q.    u
B2     1        e     u
C3     1        e     u  [
B2     1        e     u  =
C3     1        e     u  =
D3     1        e     u  ]
measure 35
E3     2        q     d
F#3    1        e     d  [
G#3    1        e     d  ]
A3     1        e     d  [
B3     1        e     d  =
C4     1        e     d  =
D4     1        e     d  ]
measure 36
E4     1        e     d  [
G#3    1        e     d  =
A3     1        e     d  =
D3     1        e     d  ]
E3     2        q     d
E2     2        q     u
measure 37
A2     2        q     u
rest   2        q
rest   4        h
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
