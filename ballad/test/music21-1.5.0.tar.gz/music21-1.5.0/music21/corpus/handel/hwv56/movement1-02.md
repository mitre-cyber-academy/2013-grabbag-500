&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 1
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-02/1} [KHM:2024933179]
TIMESTAMP: DEC/26/2001 [md5sum:38ce6303e627e880f0839bd97565e4ad]
04/04/90 E. Correia
WK#:56        MV#:1,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino I
1 72
Group memberships: score
score: part 1 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:8   T:1/1   C:4   D:Larghetto e piano
G#4    4        e     u  [      (.
G#4    4        e     u  =       .
G#4    4        e     u  =       .
G#4    4        e     u  ]      ).
B4     8-       q     u        -
B4     6        e.    u  [
A4     1        t     u  =[[
G#4    1        t     u  ]]]
measure 2
F#4    4        e     u  [      (
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]      )
A4     8-       q     u        -
A4     6        e.    u  [
G#4    1        t     u  =[[
F#4    1        t     u  ]]]
measure 3
E4     4        e     u  [
E4     3        s.    u  =[     t
D#4    1        t     u  ]]\
E4     4        e     u  [
A4     4        e     u  ]
G#4    8        q     u         (
F#4    6        e.    u  [      )t
E4     2        s     u  ]\
measure 4
E4     8        q     u
rest   8        q
B5     6        e.    d  [
A5     2        s     d  ]\
G#5    8        q     d
measure 5
G#4    4        e     u  [      (.
G#4    4        e     u  =       .
G#4    4        e     u  =       .
G#4    4        e     u  ]      ).
B4     8-       q     u        -
B4     6        e.    u  [
A4     1        t     u  =[[
G#4    1        t     u  ]]]
measure 6
F#4    4        e     u  [      (
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]      )
F#4    4        e     u  [      (
F#4    4        e     u  =      )
B4     4        e     u  =      (
B4     4        e     u  ]      )
measure 7
B4     6        e.    u  [
A4     2        s     u  ]\
G#4    8        q     u
G#5    6        e.    d  [
F#5    2        s     d  ]\
E5     8        q     d
measure 8
rest  32                        F
measure 9
G#4    4        e     u  [      (.
G#4    4        e     u  =       .
G#4    4        e     u  =       .
G#4    4        e     u  ]      ).
B4     4        e     u  [      (
B4     4        e     u  =
B4     4        e     u  =
B4     4        e     u  ]      )
measure 10
B4     4        e     u  [      (
B4     4        e     u  =
B4     4        e     u  =
B4     4        e     u  ]      )
A#4    4        e     u  [      (
A#4    4        e     u  =
A#4    4        e     u  =
A#4    4        e     u  ]      )
measure 11
B4     4        e     u  [      (
B4     4        e     u  =
B4     4        e     u  =
B4     4        e     u  ]      )
F#5    6        e.    d  [
E5     2        s     d  ]\
D#5    8        q     d
measure 12
rest  16        h
F#4    6        e.    u  [
E4     2        s     u  ]\
D#4    8        q     u
measure 13
rest  16        h
B4     6        e.    u  [
A4     2        s     u  ]\
G#4    8        q     u
measure 14
G#5    4        e     d  [      .(
G#5    4        e     d  =      .
G#5    4        e     d  =      .
G#5    4        e     d  ]      .)
B5     8-       q     d        -
B5     6        e.    d  [
A5     1        t     d  =[[
G#5    1        t     d  ]]]
measure 15
F#5    4        e     d  [      (
F#5    4        e     d  =
F#5    4        e     d  =
F#5    4        e     d  ]      )
F#5    4        e     d  [      (
F#5    4        e     d  =
F#5    4        e     d  =
F#5    4        e     d  ]      )
measure 16
E5     4        e     d  [      (
E5     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]      )
E4     4        e     u  [      (
E4     4        e     u  =
E4     4        e     u  =
E4     4        e     u  ]      )
measure 17
E4     4        e     u  [      (
E4     4        e     u  =
E4     4        e     u  =
E4     4        e     u  ]      )
E4     4        e     u  [      (
E4     4        e     u  =
E4     4        e     u  =
E4     4        e     u  ]      )
measure 18
F#5    4        e     d  [      (
F#5    4        e     d  =
F#5    4        e     d  =
F#5    4        e     d  ]      )
E5     4        e     d  [      (
E5     4        e     d  =
E5     4        e     d  =
C#5    4        e     d  ]      )
measure 19
D#5    4        e     d  [      (
D#5    4        e     d  =
D#5    4        e     d  =
D#5    4        e     d  ]      )
F#5    6        e.    d  [
E5     2        s     d  ]\
D#5    8        q     d
measure 20
rest  32
measure 21
D#5    4        e     d  [      (
D#5    4        e     d  =
D#5    4        e     d  =
D#5    4        e     d  ]      )
F#5    8-       q     d        -
F#5    6        e.    d  [
E5     1        t     d  =[[
D#5    1        t     d  ]]]
measure 22
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
measure 23
D#5    6        e.    d  [
C#5    2        s     d  ]\
B4     8        q     u
F#4    6        e.    u  [
E4     2        s     u  ]\
D#4    8        q     u
measure 24
E#4   32        w     u
measure 25
F#4    4        e     u  [      (
F#4    4        e     u  =
F#4    4        e     u  =
F#4    4        e     u  ]      )
C#5    8        q     d
rest   8        q
measure 26
rest  32
measure 27
D#5    4        e     d  [      (
D#5    4        e     d  =
D#5    4        e     d  =
D#5    4        e     d  ]      )
F#5    8-       q     d        -
F#5    6        e.    d  [
E5     1        t     d  =[[
D#5    1        t     d  ]]]
measure 28
C#5    4        e     d  [      (
C#5    4        e     d  =
C#5    4        e     d  =
C#5    4        e     d  ]      )
E5     8-       q     d        -
E5     6        e.    d  [
D#5    1        t     d  =[[
C#5    1        t     d  ]]]
measure 29
B4     4        e     u  [
B4     3        s.    u  =[     &t
A#4    1        t     u  ]]\
B4     4        e     d  [
E5     4        e     d  ]
D#5    8        q     d         (
C#5    6        e.    d  [      )t
B4     2        s     d  ]\
measure 30
B4     8        q     u
rest   8        q
rest  16        h
measure 31
F#5    8        q     d         f
rest   8        q
rest  16        h
measure 32
G#5    8        q     d
rest   8        q
rest  16        h
measure 33
D#5    8        q     d
rest   8        q
rest  16        h
measure 34
E5     8        q     d
rest   8        q
rest  16        h
measure 35
B5     8        q     d
rest   8        q
E5     8        q     d
rest   8        q
measure 36
D5     8        q     d
rest   8        q
rest  16        h
measure 37
G#5    8        q     d
A5     8        q     d
rest  16        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 2
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-02/2} [KHM:2024933179]
TIMESTAMP: DEC/26/2001 [md5sum:f757f9f30c043a7f0f8bc59395f800d6]
04/04/90 E. Correia
WK#:56        MV#:1,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Violino II
1 72
Group memberships: score
score: part 2 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:4   D:Larghetto e piano
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
measure 2
E4     2        e     u  [      (
E4     2        e     u  =      )
D#4    2        e     u  =      (
D#4    2        e     u  ]      )
D#4    2        e     u  [      (
D#4    2        e     u  =
D#4    2        e     u  =
D#4    2        e     u  ]      )
measure 3
E4     2        e     u  [      (
E4     2        e     u  =
E4     2        e     u  =
E4     2        e     u  ]      )
E4     2        e     u  [      (
E4     2        e     u  =      )
D#4    2        e     u  =      (
D#4    2        e     u  ]      )
measure 4
E4     4        q     u
rest   4        q
G#5    3        e.    d  [
F#5    1        s     d  ]\
E5     4        q     d
measure 5
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
E4     2        e     u  [      .(
E4     2        e     u  =      .
E4     2        e     u  =      .
E4     2        e     u  ]      .)
measure 6
E4     2        e     u  [      (
E4     2        e     u  =
E4     2        e     u  =
E4     2        e     u  ]      )
E4     2        e     u  [      (
E4     2        e     u  =      )
D#4    2        e     u  =      (
D#4    2        e     u  ]      )
measure 7
G#4    3        e.    u  [
F#4    1        s     u  ]\
E4     4        q     u
B4     3        e.    u  [
A4     1        s     u  ]\
G#4    4        q     u
measure 8
rest  16                        F
measure 9
E4     2        e     u  [      (
E4     2        e     u  =
E4     2        e     u  =
E4     2        e     u  ]      )
E4     2        e     u  [      (
E4     2        e     u  =
E4     2        e     u  =
E4     2        e     u  ]      )
measure 10
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
measure 11
F#4    2        e     u  [      (
F#4    2        e     u  =
F#4    2        e     u  =
F#4    2        e     u  ]      )
D#5    3        e.    d  [
C#5    1        s     d  ]\
B4     4        q     d
measure 12
rest   8        h
D#4    3        e.    u  [
C#4    1        s     u  ]\
B3     4        q     u
measure 13
rest   8        h
G#4    3        e.    u  [
F#4    1        s     u  ]\
E4     4        q     u
measure 14
B4     2        e     u  [      .(
B4     2        e     u  =      .
B4     2        e     u  =      .
B4     2        e     u  ]      .)
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
measure 15
E5     2        e     d  [      (
E5     2        e     d  =
E5     2        e     d  =
E5     2        e     d  ]      )
D#5    2        e     d  [      (
D#5    2        e     d  =
D#5    2        e     d  =
D#5    2        e     d  ]      )
measure 16
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
measure 17
C#5    2        e     d  [      (
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]      )
C#5    2        e     d  [      (
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]      )
measure 18
C#5    2        e     d  [      (
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]      )
C#5    2        e     u  [      (
C#5    2        e     u  =
C#5    2        e     u  =
F#4    2        e     u  ]      )
measure 19
F#4    2        e     u  [      (
F#4    2        e     u  =
F#4    2        e     u  =
F#4    2        e     u  ]      )
D#5    3        e.    d  [
C#5    1        s     d  ]\
B4     4        q     d
measure 20
rest  16
measure 21
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
measure 22
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
A#4    2        e     u  [      (
A#4    2        e     u  =
A#4    2        e     u  =
A#4    2        e     u  ]      )
measure 23
F#5    3        e.    d  [
E5     1        s     d  ]\
D#5    4        q     d
D#4    3        e.    u  [
C#4    1        s     u  ]\
B3     4        q     u
measure 24
B4    16        w     d
measure 25
A#4    2        e     u  [      (
A#4    2        e     u  =
A#4    2        e     u  =
A#4    2        e     u  ]      )
A#4    4        q     u
rest   4        q
measure 26
rest  16
measure 27
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
B4     2        e     u  [      (
B4     2        e     u  =
B4     2        e     u  =
B4     2        e     u  ]      )
measure 28
A#4    2        e     u  [      (
A#4    2        e     u  =
A#4    2        e     u  =
A#4    2        e     u  ]      )
A#4    2        e     u  [      (
A#4    2        e     u  =
A#4    2        e     u  =
A#4    2        e     u  ]      )
measure 29
F#4    2        e     u  [      (
F#4    2        e     u  =      )
B4     2        e     u  =      (
B4     2        e     u  ]      )
B4     4        q     u
A#4    4        q     u
measure 30
B4     4        q     u
rest   4        q
rest   8        h
measure 31
B4     4        q     u         &f
rest   4        q
rest   8        h
measure 32
B4     4        q     u
rest   4        q
rest   8        h
measure 33
B#4    4        q     u
rest   4        q
rest   8        h
measure 34
C#5    4        q     d
rest   4        q
rest   8        h
measure 35
B4     4        q     u
rest   4        q
C#5    4        q     d
rest   4        q
measure 36
A4     4        q     u
rest   4        q
rest   8        h
measure 37
D5     4        q     d
C#5    4        q     d
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 3
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-02/3} [KHM:2024933179]
TIMESTAMP: DEC/26/2001 [md5sum:b28c448c1e361d6db8f12d08f33abc29]
04/04/90 E. Correia
WK#:56        MV#:1,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Viola
1 72
Group memberships: score
score: part 3 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:13   D:Larghetto e piano
B3     2        e     u  [      .(
B3     2        e     u  =      .
B3     2        e     u  =      .
B3     2        e     u  ]      .)
B3     2        e     u  [      .(
B3     2        e     u  =      .
B3     2        e     u  =      .
B3     2        e     u  ]      .)
measure 2
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
A3     2        e     u  [      (
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]      )
measure 3
B3     2        e     u  [      (
B3     2        e     u  =      )
A3     2        e     u  =      (
A3     2        e     u  ]      )
B3     2        e     u  [      (
B3     2        e     u  =      )
A3     2        e     u  =      (
A3     2        e     u  ]      )
measure 4
G#3    4        q     u
rest   4        q
E4     3        e.    u  [
E3     1        s     u  ]\
E3     4        q     u
measure 5
B3     2        e     u  [      .(
B3     2        e     u  =      .
B3     2        e     u  =      .
B3     2        e     u  ]      .)
B3     2        e     u  [      .(
B3     2        e     u  =      .
B3     2        e     u  =      .
B3     2        e     u  ]      .)
measure 6
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
B3     2        e     d  [      (
B3     2        e     d  =      )
F#4    2        e     d  =      (
F#4    2        e     d  ]      )
measure 7
E4     3        e.    d  [
B3     1        s     d  ]\
B3     4        q     u
E4     3        e.    u  [
E3     1        s     u  ]\
E3     4        q     u
measure 8
rest  16                        F
measure 9
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
measure 10
C#4    2        e     u  [      (
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]      )
C#4    2        e     u  [      (
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]      )
measure 11
D#4    2        e     d  [      (
D#4    2        e     d  =
D#4    2        e     d  =
D#4    2        e     d  ]      )
B4     3        e.    d  [
B3     1        s     d  ]\
B3     4        q     u
measure 12
rest   8        h
B3     3        e.    u  [
F#3    1        s     u  ]\
B3     4        q     u
measure 13
rest   8        h
E4     3        e.    d  [
F#4    1        s     d  ]\
G#4    4        q     d
measure 14
E4     2        e     d  [      .(
E4     2        e     d  =      .
E4     2        e     d  =      .
E4     2        e     d  ]      .)
G#3    2        e     u  [      (
G#3    2        e     u  =
G#3    2        e     u  =
G#3    2        e     u  ]      )
measure 15
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
B3     2        e     u  [      (
B3     2        e     u  =
B3     2        e     u  =
B3     2        e     u  ]      )
measure 16
B3     2        e     d  [      (
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]      )
D4     2        e     d  [      (
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]      )
measure 17
A3     2        e     u  [      (
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]      )
A3     2        e     u  [      (
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]      )
measure 18
C#4    2        e     d  [      (
C#4    2        e     d  =
C#4    2        e     d  =
C#4    2        e     d  ]      )
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
measure 19
B4     2        e     d  [      (
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]      )
B4     3        e.    d  [
F#4    1        s     d  ]\
F#4    4        q     d
measure 20
rest  16
measure 21
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
measure 22
G#3    2        e     d  [      (
G#3    2        e     d  =      )
G#4    2        e     d  =      (
G#4    2        e     d  ]      )
F#4    2        e     u  [      (
F#4    2        e     u  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
measure 23
F#4    3        e.    d  [
F#4    1        s     d  ]\
F#4    4        q     d
B3     3        e.    u  [
C#4    1        s     u  ]\
D#4    4        q     d
measure 24
B3    16        w     u
measure 25
C#4    2        e     u  [      (
C#4    2        e     u  =
C#4    2        e     u  =
C#4    2        e     u  ]      )
C#4    4        q     u
rest   4        q
measure 26
rest  16
measure 27
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
measure 28
F#4    2        e     d  [      (
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]      )
E4     2        e     d  [      (
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]      )
measure 29
F#4    2        e     d  [      (
F#4    2        e     d  =      )
E4     2        e     d  =      (
E4     2        e     d  ]      )
F#4    4        q     d
E4     3        e.    d  [
D#4    1        s     d  ]\
measure 30
D#4    4        q     d
rest   4        q
rest   8        h
measure 31
D#4    4        q     d         &f
rest   4        q
rest   8        h
measure 32
E4     4        q     d
rest   4        q
rest   8        h
measure 33
G#4    4        q     d
rest   4        q
rest   8        h
measure 34
G#4    4        q     d
rest   4        q
rest   8        h
measure 35
E4     4        q     d
rest   4        q
A4     4        q     d
rest   4        q
measure 36
F#4    4        q     d
rest   4        q
rest   8        h
measure 37
E4     4        q     d
E4     4        q     d
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 4
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-02/4} [KHM:2024933179]
TIMESTAMP: DEC/26/2001 [md5sum:5707e9e5b914ee52c7c4584f5ea25c2b]
04/04/90 E. Correia
WK#:56        MV#:1,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Tenore
1 72 T
Group memberships: score
score: part 4 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:34   D:Larghetto e piano
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
B4     3        e.    u                    Com-
A4     1        s     u                    fort
G#4    4        q     u                    ye!
rest   8        h
measure 5
rest   8        h
E5     8-       h     d        -           com-
measure 6
E5     6        q.    d                    -
F#5    1        s     d  [[                fort_
G#5    1        s     d  ]]                _
B4     4        q     u         (          ye_
A4     3        e.    u         )          _
G#4    1        s     u                    my
measure 7
G#4    1        s     u  [[                peo-
F#4    1        s     u  ]]                -
E4     2        e     u                    ple!
rest   4        q
rest   8        h
measure 8
*               D +     ad libitum
E5     8-       h     d        -           Com-
E5     3        e.    d                    -
B4     1        s     u                    fort
B4     4        q     u                    ye,
measure 9
rest   8        h
E5     8-       h     d        -           com-
measure 10
E5     6        q.    d                    -
D#5    2        e     d                    fort
E5     6        q.    d                    ye
F#5    2        e     d                    my
measure 11
D#5    1        s     d  [[                peo-
C#5    1        s     d  ]]                -
B4     2        e     d                    ple!
rest   4        q
rest   8        h
measure 12
G#4    4        q     u                    saith
A#4    4        q     u                    your
B4     4        q     u                    God,
rest   4        q
measure 13
C#5    4        q     d                    saith
D#5    4        q     d                    your
E5     4        q     d                    God.
rest   4        q
measure 14
rest  16
measure 15
rest   8        h
B4     6        q.    u                    Speak
B4     2        e     u                    ye
measure 16
E5     3        e.    d                    com-
B4     1        s     u                    for-
B4     2        e     u                    ta-
C#5    2        e     d                    bly
D5     6        q.    d                    to
E5     2        e     d                    Je-
measure 17
C#5    3        e.    d                    ru-
B4     1        s     u                    sa-
A4     4        q     u                    lem,
rest   4        q
C#5    3        e.    d                    speak
C#5    1        s     d                    ye
measure 18
F#5    3        e.    d                    com-
F#4    1        s     u                    for-
F#4    2        e     u                    ta-
F#4    2        e     u                    bly
C#5    6        q.    d                    to
E5     2        e     d                    Je-
measure 19
D#5    3        e.    d                    ru-
C#5    1        s     d                    sa-
B4     4        q     d                    lem,
rest   4        q
rest   2        e
F#4    2        e     u                    and
measure 20
F#5    4        q     d                    cry
D#5    2        e     d                    un-
C#5    1        s     d  [[                to_
B4     1        s     d  ]]                _
B4     4        q     u                    her
B4     2        e     u                    that
B4     2        e     u                    her
measure 21
B4     6        q.    u         (          war-
C#5    1        s     d  [[                -
B4     1        s     d  ]]     )          -
B4     6        q.    u                    fare,
B4     2        e     u                    her
measure 22
C#5    6        q.    d         (          war-
D#5    1        s     d  [[                -
C#5    1        s     d  ]]     )          -
C#5    4        q     d                    fare
D#5    3        e.    d                    is
E5     1        s     d                    ac-
measure 23
D#5    1        s     d  [[                com-
C#5    1        s     d  ]]                -
B4     2        e     u                    plish'd,
rest   4        q
rest   2        e
B4     2        e     u                    that
B4     2        e     u                    her
B4     2        e     u                    i-
measure 24
E#5    6        q.    d                    ni-
E#5    2        e     d                    qui-
E#5    4        q     d                    ty
rest   2        e
F#5    2        e     d                    is
measure 25
A#4    2        e     u                    par-
A#4    2        e     u                    don'd,
rest   4        q
rest   2        e
F#4    2        e     u                    that
A#4    2        e     u                    her
C#5    2        e     d                    i-
measure 26
E5     2        e     d                    ni-
C#5    2        e     d                    qui-
D#5    2        e     d                    ty
B4     2        e     u                    is
C#5    8        h     d                    par-
measure 27
B4     4        q     u                    don'd.
rest   4        q
rest   8        h
measure 28
rest  16
measure 29
rest  16
measure 30
rest   4        q
rest   2        e
F#4    2        e     u                    The
B4     4        q     u                    voice
rest   2        e
B4     2        e     u                    of
measure 31
D#5    4        q     d                    him
rest   2        e
D#5    2        e     d                    that
F#5    4        q     d                    crieth
F#5    2        e     d                    in
B4     2        e     u                    the
measure 32
E5     3        e.    d                    wil-
E5     1        s     d                    der-
E5     4        q     d                    ness:
rest   4        q
rest   2        e
G#4    2        e     u                    Pre-
measure 33
B#4    4        q     u                    pare
B#4    2        e     u                    ye
D#5    2        e     d                    the
F#5    4        q     d                    way
F#5    2        e     d                    of
E5     2        e     d                    the
measure 34
C#5    8        h     d                    Lord,
rest   4        q
C#5    4        q     d                    make
measure 35
E5     4        q     d                    straight
E5     2        e     d                    in
B4     2        e     d                    the
C#5    2        e     d                    de-
C#5    2        e     d                    sert
rest   2        e
E5     2        e     d                    a
measure 36
F#5    4        q     d                    high-
D5     4        q     d                    way
rest   4        q
D5     2        e     d                    for
C#5    2        e     d                    our
measure 37
A4     4        q     u                    God.
rest   4        q
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = 5
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1990, 2002 Center for Computer Assisted Research in the Humanities.
ID: {handel/chry/messiah/stage2/1-02/5} [KHM:2024933179]
TIMESTAMP: DEC/26/2001 [md5sum:063452675241112e6977adb8989f6c59]
04/04/90 E. Correia
WK#:56        MV#:1,2
Messiah/Chrysander/Aug.1901/ChB 1316
Messiah
Recit. accomp.
Bassi
1 72
Group memberships: score
score: part 5 of 5
&
Tranfer from old stage2 to new stage2
&
$ K:4   Q:4   T:1/1   C:22   D:Larghetto e piano
E3     8        h     d
f1              6
G#2    2        e     u  [      .(
G#2    2        e     u  =      .
G#2    2        e     u  =      .
G#2    2        e     u  ]      .)
measure 2
f1              4
B2     4        q     u
f1              3
rest   4        q
f1              6
F#2    2        e     u  [      (
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  ]      )
measure 3
G#2    2        e     u  [      (
G#2    2        e     u  =      )
C#3    2        e     u  =      (
C#3    2        e     u  ]      )
B2     2        e     u  [      (
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]      )
measure 4
E2     4        q     u
rest   4        q
rest   8        h
measure 5
E3     2        e     d  [      .(
E3     2        e     d  =      .
E3     2        e     d  =      .
E3     2        e     d  ]      .)
G#3    2        e     d  [      .(
G#3    2        e     d  =      .
G#3    2        e     d  =      .
G#3    2        e     d  ]      .)
measure 6
B3     2        e     d  [      (
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]      )
B3     2        e     d  [      (
B3     2        e     d  =      )
B2     2        e     d  =      (
B2     2        e     d  ]      )
measure 7
E3     3        e.    u  [
E2     1        s     u  ]\
E2     4        q     u
rest   8        h
measure 8
rest  16                        F
measure 9
E3     2        e     d  [      (
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]      )
G#3    2        e     d  [      (
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]      )
measure 10
C#3    2        e     u  [      (
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]      )
C#3    2        e     u  [      (
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]      )
measure 11
B2     4        q     u
rest   4        q
rest   8        h
measure 12
E3     4        q     d
C#3    4        q     u
B2     4        q     u
rest   4        q
measure 13
A3     4        q     d
F#3    4        q     d
E3     4        q     d
rest   4        q
$ C:12
measure 14
*               D       Violonc.
E4     2        e     d  [      (
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]      )
G#3    2        e     d  [      (
G#3    2        e     d  =
G#3    2        e     d  =
G#3    2        e     d  ]      )
measure 15
B3     2        e     d  [      (
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]      )
$ C:22
*               D       Tutti
*               G +     p
B2     2        e     u  [      (
B2     2        e     u  =      )
A2     2        e     u  =      (
A2     2        e     u  ]      )
measure 16
G#2    2        e     u  [      (
G#2    2        e     u  =
G#2    2        e     u  =
G#2    2        e     u  ]      )
f1              5n
G#2    2        e     u  [      (
G#2    2        e     u  =
G#2    2        e     u  =
G#2    2        e     u  ]      )
measure 17
A2     2        e     u  [      (
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]      )
A2     2        e     u  [      (
A2     2        e     u  =
A2     2        e     u  =
A2     2        e     u  ]      )
measure 18
A#2    2        e     u  [      (
A#2    2        e     u  =
A#2    2        e     u  =
A#2    2        e     u  ]      )
A#2    2        e     u  [      (
A#2    2        e     u  =
A#2    2        e     u  =
A#2    2        e     u  ]      )
measure 19
B2     2        e     u  [      (
B2     2        e     u  =
B2     2        e     u  =
B2     2        e     u  ]      )
B3     3        e.    d  [
B2     1        s     d  ]\
B2     4        q     u
measure 20
rest  16
measure 21
B3     2        e     d  [      (
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]      )
D#3    2        e     u  [      (
D#3    2        e     u  =
D#3    2        e     u  =
D#3    2        e     u  ]      )
measure 22
E3     2        e     d  [      (
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]      )
F#3    2        e     d  [      (
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]      )
measure 23
B3     3        e.    d  [
B2     1        s     d  ]\
B2     4        q     u
rest   8        h
measure 24
f1              6+
G#2   16        w     u
measure 25
F#2    2        e     u  [      (
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  ]      )
F#2    4        q     u
rest   4        q
measure 26
rest   2        e
A#3    2        e     d  [
B3     2        e     d  =
G#3    2        e     d  ]
F#3    4        q     d
F#2    4        q     u
measure 27
B3     2        e     d  [      (
B3     2        e     d  =
B3     2        e     d  =
B3     2        e     d  ]      )
D#3    2        e     u  [      (
D#3    2        e     u  =
D#3    2        e     u  =
D#3    2        e     u  ]      )
measure 28
F#3    4        q     d
rest   4        q
C#3    2        e     u  [      (
C#3    2        e     u  =
C#3    2        e     u  =
C#3    2        e     u  ]      )
measure 29
D#3    2        e     d  [      (
D#3    2        e     d  =      )
G#3    2        e     d  =      (
G#3    2        e     d  ]      )
F#3    4        q     d
F#2    4        q     u
measure 30
B2     4        q     u
rest   4        q
rest   8        h
measure 31
f2              4 2
A2     4        q     u
rest   4        q
rest   8        h
measure 32
f1              6
G#2    4        q     u
rest   4        q
rest   8        h
measure 33
f2              4+ 2
F#3    4        q     d
rest   4        q
rest   8        h
measure 34
f1              6
E3     4        q     d
rest   4        q
rest   8        h
measure 35
G#3    4        q     d
rest   4        q
A3     4        q     d
rest   4        q
measure 36
D3     4        q     u
rest   4        q
rest   8        h
measure 37
E3     4        q     d
A2     4        q     u
rest   8        h
mdouble
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
PART = s[0-9]*
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
