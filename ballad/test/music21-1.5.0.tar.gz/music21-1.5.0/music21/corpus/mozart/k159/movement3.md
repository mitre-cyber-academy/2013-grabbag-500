&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/03/01} [KHM:3429996710]
TIMESTAMP: DEC/26/2001 [md5sum:be36343aaf594eff2dbf761984db982c]
06/20/94 E. Correia
WK#:159       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello
Rondo
Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-2   Q:12   T:2/4  C:4  D:Allegro grazioso
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 2
C5     6        e     d
rest   6        e
F5     6        e     d
rest   6        e
measure 3
D5     6        e     d
rest   6        e
Bf5    6        e     d
rest   6        e
measure 4
A5     3        s     d  [[    (f
Bf5    3        s     d  ==
C6     3        s     d  ==
Bf5    3        s     d  ]]
A5    12        q     d        )
measure 5
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 6
G5     6        e     d
rest   6        e
Ef5    6        e     d
rest   6        e
measure 7
C5     6        e     d
rest   6        e
A4     6        e     u
rest   6        e
measure 8
Bf4    3        s     d  [[    (f
C5     3        s     d  ==
D5     3        s     d  ==
C5     3        s     d  ]]
Bf4   12        q     d        )
mheavy2 9       :|
Bf5    6        e     d  [     .p
A5     6        e     d  =     .
D6     6        e     d  =     .
C6     6        e     d  ]     .
measure 10
Bf5    6        e     d  [     .
A5     6        e     d  =     .
D6     6        e     d  =     .
C6     6        e     d  ]     .
measure 11
Bf5    6        e     d  [     .
A5     6        e     d  =     .
G5     6        e     d  =     .
F5     6        e     d  ]     .
measure 12
F5    12        q     d        (
E5    12        q n   d        )
measure 13
G5    18        q.    d        f
Bf4    6        e     d
measure 14
A4     3        s     d  [[    (
C5     3        s     d  ==    )
Bf4    3        s     d  ==    (
D5     3        s     d  ]]    )
C5    12        q     d
measure 15
G5    18        q.    d
Bf4    6        e     d
measure 16
A4     3        s     d  [[    (
C5     3        s     d  ==    )
Bf4    3        s     d  ==    (
D5     3        s     d  ]]    )
C5    12        q     d
measure 17
rest   6        e
C6     6        e     d  [     (p
B5     6        e n   d  =
C6     6        e     d  ]     )
measure 18
rest   6        e
D5     6        e     d  [     (
C#5    6        e #   d  =
D5     6        e     d  ]     )
measure 19
rest   6        e
Bf5    6        e f   d  [     (+
A5     6        e     d  =
Bf5    6        e     d  ]     )
measure 20
rest   6        e
C5     6        e n   d  [     (+
B4     6        e n   d  =
C5     6        e     d  ]     )
measure 21
A5    18        q.    d        f
G5     6        e     d
measure 22
F5     6        e     d  [
E5     6        e n   d  =
D5     6        e     d  =
C5     6        e     d  ]
measure 23
gC5    5        s     u
S C1:t50
Bf4   12        q     d
A4     6        e     u  [
G4     6        e     u  ]
measure 24
F4    12        q     u
 C4   12        q     u
rest  12        q
mheavy3 25      |:
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 26
C5     6        e     d
rest   6        e
F5     6        e     d
rest   6        e
measure 27
D5     6        e     d
rest   6        e
Bf5    6        e     d
rest   6        e
measure 28
A5     3        s     d  [[    (f
Bf5    3        s     d  ==
C6     3        s     d  ==
Bf5    3        s     d  ]]
A5    12        q     d        )
measure 29
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 30
G5     6        e     d
rest   6        e
Ef5    6        e f   d        +
rest   6        e
measure 31
C5     6        e     d
rest   6        e
A4     6        e     u
rest   6        e
measure 32
Bf4    3        s     d  [[    (f
C5     3        s     d  ==
D5     3        s     d  ==
C5     3        s     d  ]]
Bf4   12        q     d        )
mheavy2 33      :|
D5     4        e  3  d  [     (*
G5     4        e  3  d  =
D5     4        e  3  d  ]     )!
D5     4        e  3  d  [     .*
D5     4        e  3  d  =     .
D5     4        e  3  d  ]     .!
measure 34
D5     4        e  3  d  [     (
A5     4        e  3  d  =
D5     4        e  3  d  ]     )
D5     4        e  3  d  [     .
D5     4        e  3  d  =     .
D5     4        e  3  d  ]     .
measure 35
D5     4        e  3  d  [     (
Bf5    4        e  3  d  =
D5     4        e  3  d  ]     )
D5     4        e  3  d  [     .
D5     4        e  3  d  =     .
D5     4        e  3  d  ]     .
measure 36
D5     4        e  3  d  [     (
A5     4        e  3  d  =
D5     4        e  3  d  ]     )
D5     4        e  3  d  [     .
D5     4        e  3  d  =     .
D5     4        e  3  d  ]     .
measure 37
D5     4        e  3  d  [     (*
Bf5    4        e  3  d  ]     )
Bf5    4        e  3  d        .!
A5     4        e  3  d  [     (*
D5     4        e  3  d  ]     )
D5     4        e  3  d        .!
measure 38
C5     4        e  3  d  [     (*
G5     4        e  3  d  ]     )
G5     4        e  3  d        .!
F5     4        e  3  d  [     (*
Bf4    4        e  3  d  ]     )
Bf4    4        e  3  d        .!
measure 39
A4     4        e  3  d  [     (
C5     4        e  3  d  =
D5     4        e  3  d  ]
Ef5    4        e  3  d  [
C5     4        e  3  d  =
A4     4        e  3  d  ]     )
measure 40
G4    12        q     u        (
F#4   12        q #   u        )
measure 41
D5    12        q     d
D5     4        e  3  d  [     .
C5     4        e  3  d  =     .
Bf4    4        e  3  d  ]     .
measure 42
A4    12        q     u
F#4    4        e #3  u  [     .
G4     4        e  3  u  =     .
A4     4        e  3  u  ]     .
measure 43
Bf4   12        q     d
Bf5    4        e  3  d  [     .
A5     4        e  3  d  =     .
G5     4        e  3  d  ]     .
measure 44
F#5   12        q #   d
D5     4        e  3  d  [     .
E5     4        e n3  d  =     .
F#5    4        e  3  d  ]     .
measure 45
G5     4        e  3  d        .
G5     4        e  3  d  [     (
Bf5    4        e  3  d  ]     )
D5     4        e  3  d        .
D5     4        e  3  d  [     (
G5     4        e  3  d  ]     )
measure 46
Ef5    4        e f3  d        .+
Ef5    4        e  3  d  [     (
G5     4        e  3  d  ]     )
A4     4        e  3  u        .
A4     4        e  3  u  [     (
C5     4        e  3  u  ]     )
measure 47
Bf4    4        e  3  d        .
Bf4    4        e  3  d  [     (
D5     4        e  3  d  ]     )
F#4    4        e #3  u        .
F#4    4        e  3  u  [     (
A4     4        e  3  u  ]     )
measure 48
G4    12        q     u
G3    12        q     u
measure 49
D5     6        e     d        p
rest   6        e
F5     6        e n   d        +
rest   6        e
measure 50
C5     6        e     d
rest   6        e
F5     6        e     d
rest   6        e
measure 51
D5     6        e     d
rest   6        e
Bf5    6        e     d
rest   6        e
measure 52
A5     3        s     d  [[    (f
Bf5    3        s     d  ==
C6     3        s     d  ==
Bf5    3        s     d  ]]
A5    12        q     d        )
measure 53
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 54
G5     6        e     d
rest   6        e
Ef5    6        e     d
rest   6        e
measure 55
C5     6        e     d
rest   6        e
A4     6        e     u
rest   6        e
measure 56
Bf4    3        s     d  [[    (f
C5     3        s     d  ==
D5     3        s     d  ==
C5     3        s     d  ]]
Bf4   12        q     d        )
measure 57
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
measure 58
Ef5    3        s     d  [[
F5     3        s     d  ==
Ef5    3        s     d  ==
F5     3        s     d  ]]
Ef5    3        s     d  [[
F5     3        s     d  ==
Ef5    3        s     d  ==
F5     3        s     d  ]]
measure 59
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
measure 60
C5     3        s     d  [[
Ef5    3        s     d  ==
C5     3        s     d  ==
Ef5    3        s     d  ]]
Ef5    3        s     d  [[
F5     3        s     d  ==
C5     3        s     d  ==
F5     3        s     d  ]]
measure 61
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
D5     3        s     d  [[
F5     3        s     d  ==
D5     3        s     d  ==
F5     3        s     d  ]]
measure 62
Bf4    3        s     d  [[
G5     3        s     d  ==
Bf4    3        s     d  ==
G5     3        s     d  ]]
Bf4    3        s     d  [[
G5     3        s     d  ==
Bf4    3        s     d  ==
G5     3        s     d  ]]
measure 63
A4     3        s     d  [[
C5     3        s     d  ==
A4     3        s     d  ==
C5     3        s     d  ]]
A4     3        s     d  [[
C5     3        s     d  ==
A4     3        s     d  ==
C5     3        s     d  ]]
measure 64
Bf4    3        s     u  [[
D4     3        s     u  ==
F4     3        s     u  ==
D4     3        s     u  ]]
Bf3   12        q     u
measure 65
F5    12        q     d        (p
Gf5   12        q f   d
measure 66
Ef5   12        q     d
F5    12        q     d        )
measure 67
Df5   12        q f   d        (
Ef5   12        q     d
measure 68
F5    24        h     d        )
measure 69
Gf5   12        q f   d        (
A4    12        q     u
measure 70
Bf4   12        q     d
C5    12        q     d        )
measure 71
Df5   18        q.f   d        (t
S C33:n10s10t90
C5     3        s     d  [[
Df5    3        s     d  ]]    )
measure 72
C5    12        q     d
rest  12        q
measure 73
F5    12        q     d        (f
Gf5   12        q f   d
measure 74
Ef5   12        q     d
F5    12        q     d        )
measure 75
Df5   12        q f   d        (
Ef5   12        q     d
measure 76
F5    24        h     d        )
measure 77
Gf5   12        q f   d        (
A4    12        q     u
measure 78
Bf4   12        q     d
Ef5   12        q     d        )
measure 79
Df5   12        q f   d        (
C5    12        q     d        )
measure 80
Bf4   24        h     d
measure 81
Df5   24        h f   d        (p
measure 82
C5    12        q     d
Bf4   12        q     d        )
measure 83
Df5   24        h f   d        (
measure 84
C5    12        q     d
Bf4   12        q     d        )
measure 85
Af5   24        h f   d        (
measure 86
Gf5   12        q f   d
F5    12        q     d        )
measure 87
E5    24        h n   d        (
measure 88
F5    12        q     d        )
rest  12        q
measure 89
Df5   24        h f   d        (f
measure 90
C5    12        q     d
Bf4   12        q     d        )
measure 91
Df5   24        h f   d        (
measure 92
C5    12        q     d
Bf4   12        q     d        )
measure 93
Gf5   24        h f   d        (
measure 94
F5    12        q     d
Ef5   12        q f   d        )+
measure 95
Df5   12        q f   d        (
C5    12        q     d        )
measure 96
Bf4   24        h     d
measure 97
D5     6        e n   d        p+
rest   6        e
F5     6        e     d
rest   6        e
measure 98
C5     6        e     d
rest   6        e
F5     6        e     d
rest   6        e
measure 99
D5     6        e     d
rest   6        e
Bf5    6        e     d
rest   6        e
measure 100
A5     3        s n   d  [[    (f+
Bf5    3        s     d  ==
C6     3        s     d  ==
Bf5    3        s     d  ]]
A5    12        q     d        )
measure 101
D5     6        e     d        .p
rest   6        e
F5     6        e     d        .
rest   6        e
measure 102
G5     6        e n   d        +&1.
rest   6        e
Ef5    6        e     d        &1.
rest   6        e
measure 103
C5     6        e     d        &1.
rest   6        e
A4     6        e     u        &1.
rest   6        e
measure 104
Bf4    3        s     d  [[    (f
C5     3        s     d  ==
D5     3        s     d  ==
C5     3        s     d  ]]
Bf4   12        q     d        )
measure 105
rest   6        e
G5     3        s     d  [[    (p
F5     3        s     d  ]]    )
rest   6        e
Ef5    3        s     d  [[    (
D5     3        s     d  ]]    )
measure 106
rest   6        e
F5     3        s     d  [[    (
Ef5    3        s     d  ]]    )
rest   6        e
D5     3        s     d  [[    (
C5     3        s     d  ]]    )
measure 107
rest   6        e
Ef5    3        s     d  [[    (
D5     3        s     d  ]]    )
rest   6        e
C5     3        s     d  [[    (
Bf4    3        s     d  ]]    )
measure 108
rest   6        e
D5     3        s     d  [[    (
C5     3        s     d  ]]    )
rest   6        e
Bf4    3        s     u  [[    (
A4     3        s     u  ]]    )
measure 109
rest   6        e
G5     3        s     d  [[    (
F5     3        s     d  ]]    )
rest   6        e
Ef5    3        s     d  [[    (
D5     3        s     d  ]]    )
measure 110
rest   6        e
C6     3        s     d  [[    (
Bf5    3        s     d  ]]    )
rest   6        e
A5     3        s     d  [[    (
G5     3        s     d  ]]    )
measure 111
F5     6        e     d  [     .
Ef5    6        e     d  =     .
D5     6        e     d  =     .
C5     6        e     d  ]     .
measure 112
C5    12        q     d        (
Bf4    6        e     d        )
rest   6        e
measure 113
F5     4        e  3  d  [     .*f
G5     4        e  3  d  =     .
A5     4        e  3  d  ]     .!
Bf5    4        e  3  d  [     .*
C6     4        e  3  d  =     .
D6     4        e  3  d  ]     .!
measure 114
Ef6   24        h     d
measure 115
D6     4        e  3  d  [     .*
C6     4        e  3  d  =     .
Bf5    4        e  3  d  ]     .!
A5     4        e  3  d  [     .*
G5     4        e  3  d  =     .
F5     4        e  3  d  ]     .!
measure 116
Ef5   24        h     d
measure 117
D5     4        e  3  d  [     .
Ef5    4        e  3  d  =     .
F5     4        e  3  d  ]     .
G5     4        e  3  d  [     .
A5     4        e  3  d  =     .
Bf5    4        e  3  d  ]     .
measure 118
C5    24        h     d
measure 119
G5     4        e  3  d  [     &1.
F5     4        e  3  d  =     &1.
Ef5    4        e  3  d  ]     &1.
D5     4        e  3  d  [     &1.
C5     4        e  3  d  =     &1.
Bf4    4        e  3  d  ]     &1.
measure 120
A4    24        h     u
measure 121
F5     6        e     d        .p
rest   6        e
Bf5    6        e     d        .
rest   6        e
measure 122
A5     6        e     d        .
rest   6        e
Ef5    6        e     d        .
rest   6        e
measure 123
D5     6        e     d        .
rest   6        e
E5     6        e n   d        .
rest   6        e
measure 124
F5     6        e     d        .
rest   6        e
F#5    6        e #   d        .
rest   6        e
measure 125
G5     6        e     d        .
rest   6        e
A4     6        e     u        .
rest   6        e
measure 126
Bf4    6        e     d        .
rest   6        e
Ef5    6        e f   d        .+
rest   6        e
measure 127
D5     6        e     d        .
rest   6        e
C5     6        e     d        .
rest   6        e
measure 128
Bf4   12        q     d        .
rest  12        q
measure 129
D5     3        s     d  [[    /f
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]
D5     3        s     d  [[
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]    \
measure 130
C5     3        s     d  [[    /
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]
C5     3        s     d  [[
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]    \
measure 131
Ef5    3        s     d  [[    /
Ef5    3        s     d  ==
Ef5    3        s     d  ==
Ef5    3        s     d  ]]
Ef5    3        s     d  [[
Ef5    3        s     d  ==
Ef5    3        s     d  ==
Ef5    3        s     d  ]]    \
measure 132
D5     3        s     d  [[    /
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]
D5     3        s     d  [[
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]    \
measure 133
Bf5    3        s     d  [[    /
Bf5    3        s     d  ==
Bf5    3        s     d  ==
Bf5    3        s     d  ]]
Bf5    3        s     d  [[
Bf5    3        s     d  ==
Bf5    3        s     d  ==
Bf5    3        s     d  ]]    \
measure 134
Bf5    3        s     d  [[    /
Bf5    3        s     d  ==
Bf5    3        s     d  ==
Bf5    3        s     d  ]]
Bf5    3        s     d  [[
Bf5    3        s     d  ==
Bf5    3        s     d  ==
Bf5    3        s     d  ]]    \
measure 135
A5     3        s     d  [[    /
A5     3        s     d  ==
A5     3        s     d  ==
A5     3        s     d  ]]
A5     3        s     d  [[
A5     3        s     d  ==
A5     3        s     d  ==
A5     3        s     d  ]]    \
measure 136
Bf5   12        q     d
rest  12        q
measure 137
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 138
C5     6        e     d
rest   6        e
F5     6        e     d
rest   6        e
measure 139
D5     6        e     d
rest   6        e
Bf5    6        e     d
rest   6        e
measure 140
A5     3        s     d  [[    (f
Bf5    3        s     d  ==
C6     3        s     d  ==
Bf5    3        s     d  ]]
A5    12        q     d        )
measure 141
D5     6        e     d        p
rest   6        e
F5     6        e     d
rest   6        e
measure 142
G5     6        e     d
rest   6        e
Ef5    6        e     d
rest   6        e
measure 143
C5     6        e     d
rest   6        e
A4     6        e     u
rest   6        e
measure 144
Bf4    3        s     d  [[    (f
C5     3        s     d  ==
D5     3        s     d  ==
C5     3        s     d  ]]
Bf4   12        q     d        )
measure 145
D4     3        s     u  [[    (
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 146
Ef4    3        s     u  [[    (
F4     3        s     u  ==
G4     3        s     u  ==
F4     3        s     u  ]]
Ef4   12        q     u        )
measure 147
G5     6        e     d        .p
rest   6        e
A5     6        e     d        .
rest   6        e
measure 148
Bf5   12        q     d        (
F5     6        e     d        )
rest   6        e
measure 149
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 150
Ef4    3        s     u  [[    (
F4     3        s     u  ==
G4     3        s     u  ==
F4     3        s     u  ]]
Ef4   12        q     u        )
measure 151
G5    12        q     d
A4    12        q     u
measure 152
Bf4    4        e  3  d  [
D6     4        e  3  d  =
C6     4        e  3  d  ]
Bf5    4        e  3  d  [
A5     4        e  3  d  =
G5     4        e  3  d  ]
measure 153
F5     4        e  3  d  [
G5     4        e  3  d  =
F5     4        e  3  d  ]
Ef5    4        e  3  d  [
D5     4        e  3  d  =
C5     4        e  3  d  ]
measure 154
Bf4    4        e  3  d  [
D5     4        e  3  d  =
C5     4        e  3  d  ]
Bf4    4        e  3  u  [
A4     4        e  3  u  =
G4     4        e  3  u  ]
measure 155
F4     4        e  3  u  [
G4     4        e  3  u  =
F4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 156
Bf3    4        e  3  u  [
C4     4        e  3  u  =
D4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 157
Bf3    4        e  3  u  [
C4     4        e  3  u  =
D4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 158
Bf3   12        q     u
Bf5   12        q     d
 Bf4  12        q     d
 D4   12        q     d
measure 159
Bf5   12        q     d
 Bf4  12        q     d
 D4   12        q     d
rest  12        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/03/02} [KHM:3429996710]
TIMESTAMP: DEC/26/2001 [md5sum:002e8892f2fd93b6582653a474c5385b]
06/20/94 E. Correia
WK#:159       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello
Rondo
Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-2   Q:12   T:2/4  C:4  D:Allegro grazioso
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 2
Ef4    6        e     u  [     .
F4     6        e     u  =     .
C4     6        e     u  =     .
F4     6        e     u  ]     .
measure 3
Bf3    6        e     u  [     .
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 4
C4     3        s     u  [[    (f
P C33:y10
D4     3        s     u  ==
Ef4    3        s     u  ==
D4     3        s     u  ]]
C4    12        q     u        )
measure 5
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 6
Bf3    6        e     u  [     .
Ef4    6        e     u  =     .
G4     6        e     u  =     .
Bf3    6        e     u  ]     .
measure 7
A3     6        e     u  [     .
C4     6        e     u  =     .
F4     6        e     u  =     .
Ef4    6        e     u  ]     .
measure 8
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
mheavy2 9       :|
D5     6        e     d  [     .p
C5     6        e     d  =     .
Bf4    6        e     d  =     .
A4     6        e     d  ]     .
measure 10
D5     6        e     d  [     .
C5     6        e     d  =     .
Bf4    6        e     d  =     .
A4     6        e     d  ]     .
measure 11
D5     6        e     d  [     .
C5     6        e     d  =     .
Bf4    6        e     d  =     .
A4     6        e     d  ]     .
measure 12
A4    12        q     u        (
G4    12        q     u        )
measure 13
Bf4   18        q.    d        f
P C32:y5
G4     6        e     u
measure 14
F4     3        s     u  [[    (
A4     3        s     u  ==    )
G4     3        s     u  ==    (
Bf4    3        s     u  ]]    )
A4    12        q     u
measure 15
Bf4   18        q.    d
G4     6        e     u
measure 16
F4     3        s     u  [[    (
A4     3        s     u  ==    )
G4     3        s     u  ==    (
Bf4    3        s     u  ]]    )
A4    12        q     u
measure 17
rest   6        e
C5     6        e     d  [     (p
B4     6        e n   d  =
C5     6        e     d  ]     )
measure 18
rest   6        e
D4     6        e     u  [     (
C#4    6        e #   u  =
D4     6        e     u  ]     )
measure 19
rest   6        e
Bf4    6        e f   u  [     (+
A4     6        e     u  =
Bf4    6        e     u  ]     )
measure 20
rest   6        e
C4     6        e n   u  [     (+
B3     6        e n   u  =
C4     6        e     u  ]     )
measure 21
A4    18        q.    u        f
G4     6        e     u
measure 22
F4     6        e     u  [
E4     6        e n   u  =
D4     6        e     u  =
C4     6        e     u  ]
measure 23
D4    12        q     u
E4    12        q n   u
measure 24
F4    12        q     u
rest  12        q
mheavy3 25      |:
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 26
Ef4    6        e f   u  [     .+
F4     6        e     u  =     .
C4     6        e     u  =     .
F4     6        e     u  ]     .
measure 27
Bf3    6        e     u  [     .
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 28
C4     3        s     u  [[    (f
P C33:y10
D4     3        s     u  ==
Ef4    3        s     u  ==
D4     3        s     u  ]]
C4    12        q     u        )
measure 29
Bf3    6        e     u  [     p&1.
F4     6        e     u  =      &1.
D4     6        e     u  =      &1.
F4     6        e     u  ]      &1.
measure 30
Bf3    6        e     u  [      &1.
Ef4    6        e     u  =      &1.
G4     6        e     u  =      &1.
Bf3    6        e     u  ]      &1.
measure 31
A3     6        e     u  [      &1.
C4     6        e     u  =      &1.
F4     6        e     u  =      &1.
Ef4    6        e     u  ]      &1.
measure 32
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
mheavy2 33      :|
P C0:t3
Bf4   12    @   q     d
@ Source has staccato here, which violates the character of this section.
D5     4        e  3  d  [     .*
C5     4        e  3  d  =     .
Bf4    4        e  3  d  ]     .!
measure 34
A4    12        q     u
F#4    4        e #3  u  [     .*
G4     4        e  3  u  =     .
A4     4        e  3  u  ]     .!
measure 35
Bf4   12        q     d
Bf4    4        e  3  u  [     .
A4     4        e  3  u  =     .
G4     4        e  3  u  ]     .
measure 36
F#4   12        q #   u
D4     4        e  3  u  [     .
E4     4        e n3  u  =     .
F#4    4        e  3  u  ]     .
measure 37
G4     8        q  3  u
rest   4        e  3
D4     4        e  3  u  [     (*
A4     4        e  3  u  ]     )
A4     4        e  3  u        .!
measure 38
G4     4        e  3  u  [     (*
A3     4        e  3  u  ]     )
A3     4        e  3  u        .!
Bf3    4        e  3  u  [     (*
F4     4        e n3  u  ]     )+
F4     4        e  3  u        .!
measure 39
Ef4   12        q     u
A3     4        e  3  u  [     (
C4     4        e  3  u  =
Ef4    4        e  3  u  ]     )
measure 40
Bf3   12        q     u        (
A3    12        q     u        )
measure 41
D4     4        e  3  u  [     (
G4     4        e  3  u  =
D4     4        e  3  u  ]     )
D4     4        e  3  u  [     .
D4     4        e  3  u  =     .
D4     4        e  3  u  ]     .
measure 42
D4     4        e  3  u  [     (
A4     4        e  3  u  =
D4     4        e  3  u  ]     )
D4     4        e  3  u  [     .
D4     4        e  3  u  =     .
D4     4        e  3  u  ]     .
measure 43
D4     4        e  3  u  [     (
Bf4    4        e  3  u  =
D4     4        e  3  u  ]     )
D4     4        e  3  u  [     .
D4     4        e  3  u  =     .
D4     4        e  3  u  ]     .
measure 44
D4     4        e  3  u  [     (
A4     4        e  3  u  =
D4     4        e  3  u  ]     )
D4     4        e  3  u  [     .
D4     4        e  3  u  =     .
D4     4        e  3  u  ]     .
measure 45
D4    12        q     u        (
G4    12        q     u        )
measure 46
G4    12        q     u
Ef4    4        e  3  u        .
Ef4    4        e  3  u  [     (
A4     4        e  3  u  ]     )
measure 47
G4     4        e  3  u        .
D4     4        e  3  u  [     (
Bf3    4        e  3  u  ]     )
A3     4        e  3  u        .
A3     4        e  3  u  [     (
C4     4        e  3  u  ]     )
measure 48
Bf3   12        q     u
rest  12        q
measure 49
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 50
Ef4    6        e     u  [     .
F4     6        e     u  =     .
C4     6        e     u  =     .
F4     6        e     u  ]     .
measure 51
Bf3    6        e     u  [     .
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 52
C4     3        s     u  [[    (f
P C33:y10
D4     3        s     u  ==
Ef4    3        s     u  ==
D4     3        s     u  ]]
C4    12        q     u        )
measure 53
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 54
Bf3    6        e     u  [     .
Ef4    6        e     u  =     .
G4     6        e     u  =     .
Bf3    6        e     u  ]     .
measure 55
A3     6        e     u  [     .
C4     6        e     u  =     .
F4     6        e     u  =     .
Ef4    6        e     u  ]     .
measure 56
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 57
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
measure 58
C5     3        s     u  [[
F4     3        s     u  ==
C5     3        s     u  ==
F4     3        s     u  ]]
C5     3        s     u  [[
F4     3        s     u  ==
C5     3        s     u  ==
F4     3        s     u  ]]
measure 59
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
measure 60
A4     6        e     u  [
Bf4    6        e     u  =
C5     6        e     u  =
A4     6        e     u  ]
measure 61
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
Bf4    3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
measure 62
G4     3        s     u  [[
Bf4    3        s     u  ==
G4     3        s     u  ==
Bf4    3        s     u  ]]
G4     3        s     u  [[
Bf4    3        s     u  ==
G4     3        s     u  ==
Bf4    3        s     u  ]]
measure 63
C4     3        s     u  [[
Ef4    3        s     u  ==
C4     3        s     u  ==
Ef4    3        s     u  ]]
C4     3        s     u  [[
Ef4    3        s     u  ==
C4     3        s     u  ==
Ef4    3        s     u  ]]
measure 64
D4     3        s     u  [[
F4     3        s     u  ==
Bf4    3        s     u  ==
F4     3        s     u  ]]
D4    12        q     u
measure 65
F4    12        q     u        (p
P C33:y10
Gf4   12        q f   u
measure 66
Ef4   12        q     u
F4    12        q     u        )
measure 67
Df4   12        q f   u        (
Ef4   12        q     u        )
measure 68
C4    24-       h     u        -
measure 69
C4    12        q     u
Gf4   12        q f   u
measure 70
F4    24-       h     u        -
measure 71
F4    12        q     u        (
G4    12        q n   u        +
measure 72
A4    12        q     u        )
rest  12        q
measure 73
F4    12        q     u        (f
P C33:y10
Gf4   12        q f   u
measure 74
Ef4   12        q     u
F4    12        q     u        )
measure 75
Df4   12        q f   u        (
Ef4   12        q     u        )
measure 76
C4    24-       h     u        -
measure 77
C4    12        q     u
Gf4   12        q f   u        (
measure 78
F4    12        q     u
Bf3   12-       q     u        )-
measure 79
Bf3   12        q     u        (
A3    12        q     u        )
measure 80
Bf3   24        h     u
measure 81
rest  12        q
Bf4   12        q     d        (p
measure 82
A4    12        q     u
Bf4   12        q     d        )
measure 83
rest  12        q
Bf4   12        q     d        (
measure 84
A4    12        q     u
Bf4   12        q     d        )
measure 85
Bf4   24-       h     d        -
measure 86
Bf4   24-       h     d        -
measure 87
Bf4   24        h     d
measure 88
A4    12        q     u
rest  12        q
measure 89
rest  12        q
G4    12        q     u        (f
P C33:y10
measure 90
Gf4   12        q f   u
F4    12        q     u        )
measure 91
rest  12        q
G4    12        q n   u        (+
measure 92
Gf4   12        q f   u
F4    12        q     u        )
measure 93
rest  12        q
Ef5   12        q     d        (
measure 94
Df5   12        q f   d
C5    12        q     d        )
measure 95
Bf4   12        q     d        (
A4    12        q     u        )
measure 96
Bf4   24        h     d
measure 97
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e n   u  =     .+
F4     6        e     u  ]     .
measure 98
Ef4    6        e     u  [     .
F4     6        e     u  =     .
C4     6        e     u  =     .
F4     6        e     u  ]     .
measure 99
Bf3    6        e     u  [     .
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 100
C4     3        s     u  [[    (f
P C33:y10
D4     3        s     u  ==
Ef4    3        s     u  ==
D4     3        s     u  ]]
C4    12        q     u        )
measure 101
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 102
Bf3    6        e     u  [     .
Ef4    6        e     u  =     .
G4     6        e n   u  =     .+
Bf3    6        e     u  ]     .
measure 103
A3     6        e     u  [     .
C4     6        e     u  =     .
F4     6        e     u  =     .
Ef4    6        e     u  ]     .
measure 104
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 105
rest  24
measure 106
rest  24
measure 107
rest   6        e
G4     3        s     u  [[    (p
P C33:y5
F4     3        s     u  ]]    )
rest   6        e
Ef4    3        s     u  [[    (
D4     3        s     u  ]]    )
measure 108
rest   6        e
F4     3        s     u  [[    (
Ef4    3        s     u  ]]    )
rest   6        e
D4     3        s     u  [[    (
C4     3        s     u  ]]    )
measure 109
rest   6        e
Ef4    3        s     u  [[    (
D4     3        s     u  ]]    )
rest   6        e
C4     3        s     u  [[    (
Bf3    3        s     u  ]]    )
measure 110
rest   6        e
A4     3        s     u  [[    (
G4     3        s     u  ]]    )
rest   6        e
F4     3        s     u  [[    (
Ef4    3        s     u  ]]    )
measure 111
D4     6        e     u  [     .
C4     6        e     u  =     .
Bf3    6        e     u  =     .
A3     6        e     u  ]     .
measure 112
A3    12        q     u        (
Bf3    6        e     u        )
rest   6        e
measure 113
F4     4        e  3  u  [     .*f
G4     4        e  3  u  =     .
A4     4        e  3  u  ]     .!
Bf4    4        e  3  d  [     .*
C5     4        e  3  d  =     .
D5     4        e  3  d  ]     .!
measure 114
Ef5   24        h     d
measure 115
D5     4        e  3  d  [     .*
C5     4        e  3  d  =     .
Bf4    4        e  3  d  ]     .!
A4     4        e  3  u  [     .*
G4     4        e  3  u  =     .
F4     4        e  3  u  ]     .!
measure 116
Ef4   24        h     u
measure 117
D4     4        e  3  u  [     .
Ef4    4        e  3  u  =     .
F4     4        e  3  u  ]     .
G4     4        e  3  u  [     .
A4     4        e  3  u  =     .
Bf4    4        e  3  u  ]     .
measure 118
C4    24        h     u
measure 119
G4     4        e  3  u  [     &1.
F4     4        e  3  u  =     &1.
Ef4    4        e  3  u  ]     &1.
D4     4        e  3  u  [     &1.
C4     4        e  3  u  =     &1.
Bf3    4        e  3  u  ]     &1.
measure 120
A3    24        h     u
measure 121
D5     6        e     d        .p
rest   6        e
C5     6        e     d        .
rest   6        e
measure 122
C5     6        e     d        .
rest   6        e
C5     6        e     d        .
rest   6        e
measure 123
Bf4    6        e     d        .
rest   6        e
G4     6        e     u        .
rest   6        e
measure 124
F4     6        e     u        .
rest   6        e
A4     6        e     u        .
rest   6        e
measure 125
G4     6        e     u        .
rest   6        e
F4     6        e     u        .
rest   6        e
measure 126
F4     6        e     u        .
rest   6        e
Bf4    6        e     d        .
rest   6        e
measure 127
Bf4    6        e     d        .
rest   6        e
A4     6        e     u        .
rest   6        e
measure 128
Bf4   12        q     d        .
rest  12        q
measure 129
Bf4    3        s     d  [[    /f
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]
Bf4    3        s     d  [[
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]    \
measure 130
Bf4    3        s     d  [[    /
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]
Bf4    3        s     d  [[
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]    \
measure 131
A4     3        s     u  [[    /
A4     3        s     u  ==
A4     3        s     u  ==
A4     3        s     u  ]]
A4     3        s     u  [[
A4     3        s     u  ==
A4     3        s     u  ==
A4     3        s     u  ]]    \
measure 132
Bf4    3        s     d  [[    /
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]
Bf4    3        s     d  [[
Bf4    3        s     d  ==
Bf4    3        s     d  ==
Bf4    3        s     d  ]]    \
measure 133
D5     3        s     d  [[    /
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]
D5     3        s     d  [[
D5     3        s     d  ==
D5     3        s     d  ==
D5     3        s     d  ]]    \
measure 134
C5     3        s     d  [[    /
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]
C5     3        s     d  [[
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]    \
measure 135
C5     3        s     d  [[    /
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]
C5     3        s     d  [[
C5     3        s     d  ==
C5     3        s     d  ==
C5     3        s     d  ]]    \
measure 136
Bf4   12        q     d
rest  12        q
measure 137
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 138
Ef4    6        e     u  [     .
F4     6        e     u  =     .
C4     6        e     u  =     .
F4     6        e     u  ]     .
measure 139
Bf3    6        e     u  [     .
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 140
C4     3        s     u  [[    (f
P C33:y10
D4     3        s     u  ==
Ef4    3        s     u  ==
D4     3        s     u  ]]
C4    12        q     u        )
measure 141
Bf3    6        e     u  [     .p
F4     6        e     u  =     .
D4     6        e     u  =     .
F4     6        e     u  ]     .
measure 142
Bf3    6        e     u  [     .
Ef4    6        e     u  =     .
G4     6        e     u  =     .
Bf3    6        e     u  ]     .
measure 143
A3     6        e     u  [     .
C4     6        e     u  =     .
F4     6        e     u  =     .
Ef4    6        e     u  ]     .
measure 144
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 145
D4     3        s     u  [[    (
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 146
Ef4    3        s     u  [[    (
F4     3        s     u  ==
G4     3        s     u  ==
F4     3        s     u  ]]
Ef4   12        q     u        )
measure 147
Ef5    6        e     d        p
rest   6        e
C5     6        e     d
rest   6        e
measure 148
D5    12        q     d
rest  12        q
measure 149
D4     3        s     u  [[    (f
P C33:y10
Ef4    3        s     u  ==
F4     3        s     u  ==
Ef4    3        s     u  ]]
D4    12        q     u        )
measure 150
Ef4    3        s     u  [[    (
F4     3        s     u  ==
G4     3        s     u  ==
F4     3        s     u  ]]
Ef4   12        q     u        )
measure 151
Ef5   12        q     d
Ef4   12        q     u
measure 152
D4     4        e  3  d  [
F5     4        e  3  d  =
Ef5    4        e  3  d  ]
D5     4        e  3  d  [
C5     4        e  3  d  =
Bf4    4        e  3  d  ]
measure 153
A4     4        e  3  d  [
Ef5    4        e  3  d  =
D5     4        e  3  d  ]
C5     4        e  3  d  [
Bf4    4        e  3  d  =
A4     4        e  3  d  ]
measure 154
Bf4    4        e  3  d  [
D5     4        e  3  d  =
C5     4        e  3  d  ]
Bf4    4        e  3  u  [
A4     4        e  3  u  =
G4     4        e  3  u  ]
measure 155
F4     4        e  3  u  [
G4     4        e  3  u  =
F4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 156
Bf3    4        e  3  u  [
C4     4        e  3  u  =
D4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 157
Bf3    4        e  3  u  [
C4     4        e  3  u  =
D4     4        e  3  u  ]
Ef4    4        e  3  u  [
D4     4        e  3  u  =
C4     4        e  3  u  ]
measure 158
Bf3   12        q     u
D5    12        q     u
 F4   12        q     u
 Bf3  12        q     u
measure 159
D5    12        q     u
 F4   12        q     u
 Bf3  12        q     u
rest  12        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/03/03} [KHM:3429996710]
TIMESTAMP: DEC/26/2001 [md5sum:e3a70d12f3badba2e04e978c7ef6c8bb]
06/20/94 E. Correia
WK#:159       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello
Rondo
Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-2   Q:12   T:2/4  C:13  D:Allegro grazioso
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 2
rest   6        e
A4     6        e     d        .
C5     6        e     d  [     (
A4     6        e     d  ]     )
measure 3
rest   6        e
Bf4    6        e     d        .
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 4
A4     3        s     d  [[    (f
Bf4    3        s     d  ==
C5     3        s     d  ==
Bf4    3        s     d  ]]
A4    12        q     d        )
measure 5
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 6
rest   6        e
G4     6        e     d        .
C5     6        e     d  [     (
G4     6        e     d  ]     )
measure 7
rest   6        e
F4     6        e     d        .
C4     6        e     u  [     (
A3     6        e     u  ]     )
measure 8
Bf3    3        s     u  [[    (f
C4     3        s     u  ==
D4     3        s     u  ==
C4     3        s     u  ]]
Bf3   12        q     u        )
mheavy2 9       :|
rest  24
measure 10
rest  24
measure 11
rest  24
measure 12
rest  24
measure 13
C4     3        s     d  [[    /f
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]
C4     3        s     d  [[
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]    \
measure 14
C4     6        e     u  [
F4     6        e     u  =
F3     6        e     u  =
F4     6        e     u  ]
measure 15
C4     3        s     d  [[    /
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]
C4     3        s     d  [[
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]    \
measure 16
C4     6        e     u  [
F4     6        e     u  =
F3     6        e     u  =
F4     6        e     u  ]
measure 17
F3    12        q     u        p
rest  12        q
measure 18
F4    12        q     d
rest  12        q
measure 19
D4    12        q     d
rest  12        q
measure 20
G3    12        q     u
rest  12        q
measure 21
C4    18        q.    d        f
P C32:y5
C#4    6        e #   d
measure 22
D4     6        e     u  [
C4     6        e n   u  =     +
Bf3    6        e     u  =
A3     6        e     u  ]
measure 23
G3    12        q     u
C4     6        e     u  [
Bf3    6        e     u  ]
measure 24
A3    12        q     u
rest  12        q
mheavy3 25      |:
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 26
rest   6        e
A4     6        e     d        .
C5     6        e     d  [     (
A4     6        e     d  ]     )
measure 27
rest   6        e
Bf4    6        e     d        .
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 28
A4     3        s     d  [[    (f
Bf4    3        s     d  ==
C5     3        s     d  ==
Bf4    3        s     d  ]]
A4    12        q     d        )
measure 29
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 30
rest   6        e
G4     6        e     d        .
Bf4    6        e     d  [     (
G4     6        e     d  ]     )
measure 31
rest   6        e
Ef4    6        e     d        &1.
C4     6        e     u  [     (
A3     6        e     u  ]     )
measure 32
Bf3    3        s     u  [[    (f
C4     3        s     u  ==
D4     3        s     u  ==
C4     3        s     u  ]]
Bf3   12        q     u        )
mheavy2 33      :|
G4    12        q     d
Bf4    4        e  3  d  [     .*
A4     4        e  3  d  =     .
G4     4        e  3  d  ]     .!
measure 34
F#4   12        q #   d
D4     4        e  3  d  [     .
E4     4        e n3  d  =     .
F#4    4        e  3  d  ]     .
measure 35
G4    12        q     d
D4     4        e  3  d  [     .
C4     4        e  3  d  =     .
Bf3    4        e  3  d  ]     .
measure 36
A3    12        q     u
F#3    4        e #3  u  [     .
G3     4        e  3  u  =     .
A3     4        e  3  u  ]     .
measure 37
Bf3    8        q  3  u
rest   4        e  3
A3     4        e  3  d  [     (*
F4     4        e n3  d  ]     )+
F4     4        e  3  d        .!
measure 38
Ef4    4        e  3  d  [     (*
C4     4        e  3  d  ]     )
C4     4        e  3  d        .!
F4     4        e  3  d  [     (*
D4     4        e  3  d  ]     )
D4     4        e  3  d        .!
measure 39
C4    12        q     d
rest   6        e
C4     6        e     d
measure 40
D4    24        h     d
measure 41
G3    12        q     u
rest  12        q
measure 42
D4    12        q     d
rest  12        q
measure 43
G3    12        q     u
rest  12        q
measure 44
D3    12        q     u
C4     4        e  3  u  [     .
Bf3    4        e  3  u  =     .
A3     4        e  3  u  ]     .
measure 45
G3    12        q     u
Bf3    4        e  3  u        .
Bf3    4        e  3  u  [     (
D4     4        e  3  u  ]     )
measure 46
C4     4        e  3  d        .
C4     4        e  3  d  [     (
Ef4    4        e  3  d  ]     )
G4    12        q     d        .
measure 47
D4    12        q     d
D3    12        q     u
measure 48
D3    12        q     u
rest  12        q
measure 49
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 50
rest   6        e
A4     6        e     d        .
C5     6        e     d  [     (
A4     6        e     d  ]     )
measure 51
rest   6        e
Bf4    6        e     d        .
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 52
A4     3        s     d  [[    (f
Bf4    3        s     d  ==
C5     3        s     d  ==
Bf4    3        s     d  ]]
A4    12        q     d        )
measure 53
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 54
rest   6        e
G4     6        e     d        .
C5     6        e     d  [     (
G4     6        e     d  ]     )
measure 55
rest   6        e
F4     6        e     d        .
C4     6        e     u  [     (
A3     6        e     u  ]     )
measure 56
Bf3    3        s     u  [[    (f
C4     3        s     u  ==
D4     3        s     u  ==
C4     3        s     u  ]]
Bf3   12        q     u        )
measure 57
D4     3        s     d  [[
Bf3    3        s     d  ==
D4     3        s     d  ==
Bf3    3        s     d  ]]
D4     3        s     d  [[
Bf3    3        s     d  ==
D4     3        s     d  ==
Bf3    3        s     d  ]]
measure 58
A3     3        s     u  [[
C4     3        s     u  ==
A3     3        s     u  ==
C4     3        s     u  ]]
A3     3        s     u  [[
C4     3        s     u  ==
A3     3        s     u  ==
C4     3        s     u  ]]
measure 59
Bf3    3        s     d  [[
D4     3        s     d  ==
Bf3    3        s     d  ==
D4     3        s     d  ]]
Bf3    3        s     d  [[
D4     3        s     d  ==
Bf3    3        s     d  ==
D4     3        s     d  ]]
measure 60
F4     3        s     d  [[
F4     3        s     d  ==
F4     3        s     d  ==
F4     3        s     d  ]]
F4     3        s     d  [[
F4     3        s     d  ==
F4     3        s     d  ==
F4     3        s     d  ]]
measure 61
F4     3        s     d  [[
D4     3        s     d  ==
F4     3        s     d  ==
D4     3        s     d  ]]
F4     3        s     d  [[
D4     3        s     d  ==
F4     3        s     d  ==
D4     3        s     d  ]]
measure 62
Ef4    3        s     d  [[
C4     3        s     d  ==
Ef4    3        s     d  ==
C4     3        s     d  ]]
Ef4    3        s     d  [[
C4     3        s     d  ==
Ef4    3        s     d  ==
C4     3        s     d  ]]
measure 63
F4     3        s     d  [[
A3     3        s     d  ==
F4     3        s     d  ==
A3     3        s     d  ]]
F4     3        s     d  [[
A3     3        s     d  ==
F4     3        s     d  ==
A3     3        s     d  ]]
measure 64
Bf3   12        q     u
F3    12        q     u
measure 65
rest  12        q
Df4   12        q f   d        p
measure 66
C4    24        h     d
measure 67
Bf3   24-       h     u        -
measure 68
Bf3   12        q     u
A3    12-       q     u        -
measure 69
A3    12        q     u        (
P C32:o
C4    12        q     d
measure 70
Df4   12        q f   d
A3    12        q     u        )
measure 71
Bf3   24        h     u
measure 72
F4    12        q     d
rest  12        q
measure 73
rest  12        q
Df4   12        q f   d        f
measure 74
C4    24        h     d
measure 75
Bf3   24-       h     u        -
measure 76
Bf3   12        q     u
A3    12-       q     u        -
measure 77
A3    12        q     u        (
C4    12        q     d
measure 78
Df4   12        q f   d
Ef4   12        q     d        )
measure 79
F4    24        h     d
measure 80
Df4   24        h f   d
measure 81
rest  12        q
G4    12        q     d        (p
measure 82
Gf4   12        q f   d
F4    12        q     d        )
measure 83
rest  12        q
G4    12        q n   d        (+
measure 84
Gf4   12        q f   d
F4    12        q     d        )
measure 85
F4    24        h     d        (
measure 86
Ef4   12        q     d        )
Df4   12-       q f   d        -
measure 87
Df4   12        q     d        (
P C32:u
C4     6        e     u  [
Bf3    6        e     u  ]     )
measure 88
C4    12        q     d
rest  12        q
measure 89
rest  12        q
Bf3   12        q     u        (f
measure 90
A3    12        q     u
Bf3   12        q     u        )
measure 91
rest  12        q
Bf3   12        q     u        (
measure 92
A3    12        q     u
Bf3   12        q     u        )
measure 93
rest  12        q
C5    12        q     d        (
measure 94
F4    12        q     d
Gf4   12        q f   d        )
measure 95
F4    12        q     d        (
Ef4   12        q     d        )
measure 96
Df4   24        h f   d
measure 97
rest   6        e
Bf4    6        e     d        .p
D5     6        e n   d  [     (+
Bf4    6        e     d  ]     )
measure 98
rest   6        e
A4     6        e     d        .
C5     6        e     d  [     (
A4     6        e     d  ]     )
measure 99
rest   6        e
Bf4    6        e     d        .
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 100
A4     3        s     d  [[    (f
Bf4    3        s     d  ==
C5     3        s     d  ==
Bf4    3        s     d  ]]
A4    12        q     d        )
measure 101
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 102
rest   6        e
G4     6        e n   d        .+
Bf4    6        e     d  [     (
G4     6        e     d  ]     )
measure 103
rest   6        e
Ef4    6        e     d        .
C4     6        e     u  [     (
A3     6        e     u  ]     )
measure 104
Bf3    3        s     u  [[    (f
C4     3        s     u  ==
D4     3        s     u  ==
C4     3        s     u  ]]
Bf3   12        q     u        )
measure 105
rest  24
measure 106
rest  24
measure 107
rest  24
measure 108
rest  24
measure 109
Bf3   24-       h     u        -p
measure 110
Bf3   24        h     u
measure 111
F3    18        q.    u
Ef4    6        e     d
measure 112
Ef4   12        q     d        (
D4     6        e     d        )
rest   6        e
measure 113
D4    12        q     d        f
F4    12        q     d
measure 114
G4    12        q     d
A4    12        q     d
measure 115
Bf4   12        q     d
Bf3   12        q     u
measure 116
G3    12        q     u
A3    12        q     u
measure 117
Bf3   12        q     u
Bf3   12        q     u
measure 118
G3    12        q     u
F3    12        q     u
measure 119
Ef3   12        q     u
G3    12        q     u
measure 120
C4    12        q     d
F3    12        q     u
measure 121
F3     6        e     u        .p
rest   6        e
G3     6        e     u        .
rest   6        e
measure 122
A3     6        e     u        .
rest   6        e
F4     6        e     d        .
rest   6        e
measure 123
F4     6        e     d        .
rest   6        e
C4     6        e     d        .
rest   6        e
measure 124
C4     6        e     d        .
rest   6        e
C4     6        e     d        .
rest   6        e
measure 125
Bf3    6        e     u        .
rest   6        e
C4     6        e     d        .
rest   6        e
measure 126
D4     6        e     d        .
rest   6        e
Ef4    6        e     d        .
rest   6        e
measure 127
F4     6        e     d        .
rest   6        e
Ef4    6        e     d        .
rest   6        e
measure 128
D4    12        q     d        .
rest  12        q
measure 129
G4     3        s     d  [[    /f
G4     3        s     d  ==
G4     3        s     d  ==
G4     3        s     d  ]]
G4     3        s     d  [[
G4     3        s     d  ==
G4     3        s     d  ==
G4     3        s     d  ]]    \
measure 130
G4     3        s     d  [[    /
G4     3        s     d  ==
G4     3        s     d  ==
G4     3        s     d  ]]    \
Ef4    3        s     d  [[    /
Ef4    3        s     d  ==
Ef4    3        s     d  ==
Ef4    3        s     d  ]]    \
measure 131
C4     3        s     d  [[    /
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]
C4     3        s     d  [[
C4     3        s     d  ==
C4     3        s     d  ==
C4     3        s     d  ]]    \
measure 132
Bf3    3        s     u  [[    /
Bf3    3        s     u  ==
Bf3    3        s     u  ==
Bf3    3        s     u  ]]
Bf3    3        s     u  [[
Bf3    3        s     u  ==
Bf3    3        s     u  ==
Bf3    3        s     u  ]]    \
measure 133
F4     3        s     d  [[    /
F4     3        s     d  ==
F4     3        s     d  ==
F4     3        s     d  ]]
F4     3        s     d  [[
F4     3        s     d  ==
F4     3        s     d  ==
F4     3        s     d  ]]    \
measure 134
G4     3        s     d  [[    /
G4     3        s     d  ==
G4     3        s     d  ==
G4     3        s     d  ]]
G4     3        s     d  [[
G4     3        s     d  ==
G4     3        s     d  ==
G4     3        s     d  ]]    \
measure 135
F4     3        s     d  [[    /
F4     3        s     d  ==
F4     3        s     d  ==
F4     3        s     d  ]]    \
Ef4    3        s     d  [[    /
Ef4    3        s     d  ==
Ef4    3        s     d  ==
Ef4    3        s     d  ]]    \
measure 136
D4    12        q     d
rest  12        q
measure 137
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 138
rest   6        e
A4     6        e     d        .
C5     6        e     d  [     (
A4     6        e     d  ]     )
measure 139
rest   6        e
Bf4    6        e     d        .
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 140
A4     3        s     d  [[    (f
Bf4    3        s     d  ==
C5     3        s     d  ==
Bf4    3        s     d  ]]
A4    12        q     d        )
measure 141
rest   6        e
Bf4    6        e     d        .p
D5     6        e     d  [     (
Bf4    6        e     d  ]     )
measure 142
rest   6        e
G4     6        e     d        .
C5     6        e     d  [     (
G4     6        e     d  ]     )
measure 143
rest   6        e
F4     6        e     d        .
C4     6        e     u  [     (
A3     6        e     u  ]     )
measure 144
Bf3    3        s     u  [[    (f
C4     3        s     u  ==
D4     3        s     u  ==
C4     3        s     u  ]]
Bf3   12        q     u        )
measure 145
D4     3        s     d  [[    (
Ef4    3        s     d  ==
F4     3        s     d  ==
Ef4    3        s     d  ]]
D4    12        q     d        )
measure 146
Ef4    3        s     d  [[    (
F4     3        s     d  ==
G4     3        s     d  ==
F4     3        s     d  ]]
Ef4   12        q     d        )
measure 147
C4     6        e     d        p
rest   6        e
F4     6        e     d
rest   6        e
measure 148
Bf3   12        q     u
rest  12        q
measure 149
D4     3        s     d  [[    (f
P C33:y10
Ef4    3        s     d  ==
F4     3        s     d  ==
Ef4    3        s     d  ]]
D4    12        q     d        )
measure 150
Ef4    3        s     d  [[    (
F4     3        s     d  ==
G4     3        s     d  ==
F4     3        s     d  ]]
Ef4   12        q     d        )
measure 151
C4    12        q     d
C4    12        q     d
measure 152
Bf3   12        q     u
rest  12        q
measure 153
rest  24
measure 154
Bf4    4        e  3  d  [
D5     4        e  3  d  =
C5     4        e  3  d  ]
Bf4    4        e  3  d  [
A4     4        e  3  d  =
G4     4        e  3  d  ]
measure 155
F4     4        e  3  d  [
G4     4        e  3  d  =
F4     4        e  3  d  ]
Ef4    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
measure 156
Bf3    4        e  3  d  [
C4     4        e  3  d  =
D4     4        e  3  d  ]
Ef4    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
measure 157
Bf3    4        e  3  d  [
C4     4        e  3  d  =
D4     4        e  3  d  ]
Ef4    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
measure 158
Bf3   12        q     u
Bf4   12        q     d
measure 159
Bf3   12        q     u
rest  12        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/03/04} [KHM:3429996710]
TIMESTAMP: DEC/26/2001 [md5sum:9627114476f3eaf0b3ade241f4d9ee68]
06/20/94 E. Correia
WK#:159       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello
Rondo
Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-2   Q:12   T:2/4  C:22  D:Allegro grazioso
Bf3   12        q     d        p
rest  12        q
measure 2
A3    12        q     d
rest  12        q
measure 3
Bf3   12        q     d
rest  12        q
measure 4
F3    12        q     d        f
F3    12        q     d
measure 5
Bf3   12        q     d        p
rest  12        q
measure 6
Ef3   12        q     d
rest  12        q
measure 7
F3    12        q     d
rest  12        q
measure 8
Bf2   12        q     u        f
Bf2   12        q     u
mheavy2 9       :|
rest  24
measure 10
rest  24
measure 11
rest  24
measure 12
rest  24
measure 13
rest   6        e
C3     6        e     d  [     f
D3     6        e     d  =
E3     6        e n   d  ]
measure 14
F3    12        q     d
F2    12        q     u
measure 15
rest   6        e
C3     6        e     d  [
D3     6        e     d  =
E3     6        e n   d  ]
measure 16
F3    12        q     d
F2    12        q     u
measure 17
A2    12        q     u        p
rest  12        q
measure 18
Bf2   12        q     u
rest  12        q
measure 19
G3    12        q     d
rest  12        q
measure 20
E3    12        q n   d
rest  12        q
measure 21
F3    18        q.    d        &1f
E3     6        e n   d
measure 22
D3     6        e     u  [
C3     6        e     u  =
Bf2    6        e     u  =
A2     6        e     u  ]
measure 23
G2    12        q     u
C3    12        q     u
measure 24
F2    12        q     u
rest  12        q
mheavy3 25      |:
Bf3   12        q     d        &1p
rest  12        q
measure 26
A3    12        q     d
rest  12        q
measure 27
Bf3   12        q     d
rest  12        q
measure 28
F3    12        q     d        f
F3    12        q     d
measure 29
Bf3   12        q     d        p
rest  12        q
measure 30
Ef3   12        q f   d        +
rest  12        q
measure 31
F3    12        q     d
rest  12        q
measure 32
Bf2   12        q     u        f
Bf2   12        q     u
mheavy2 33      :|
G3    12        q     d
rest  12        q
measure 34
D4    12        q     d
rest  12        q
measure 35
G3    12        q     d
rest  12        q
measure 36
D3    12        q     d
C3     4        e  3  u  [
Bf2    4        e  3  u  =
A2     4        e  3  u  ]
measure 37
G2    12        q     u
F2    12        q n   u        +
measure 38
Ef2   12        q     u
D2    12        q     u
measure 39
C2    12        q     u
C3    12        q     u
measure 40
D3    24        h     d
measure 41
Bf3   12        q     d
Bf3    4        e  3  d  [     .
A3     4        e  3  d  =     .
G3     4        e  3  d  ]     .
measure 42
F#3   12        q #   d
D3     4        e  3  d  [     .
E3     4        e n3  d  =     .
F#3    4        e  3  d  ]     .
measure 43
G3    12        q     d
D4     4        e  3  d  [     .
C4     4        e  3  d  =     .
Bf3    4        e  3  d  ]     .
measure 44
A3    12        q     d
F#3    4        e #3  d  [     .
G3     4        e  3  d  =     .
A3     4        e  3  d  ]     .
measure 45
Bf3   12        q     d
Bf2   12        q     u
measure 46
C3    12        q     u
C4    12        q     d
measure 47
D4    12        q     d
D3    12        q     d
measure 48
G2    12        q     u
rest  12        q
measure 49
Bf3   12        q     d        p
rest  12        q
measure 50
A3    12        q     d
rest  12        q
measure 51
Bf3   12        q     d
rest  12        q
measure 52
F3    12        q     d        f
F3    12        q     d
measure 53
Bf3   12        q     d        p
rest  12        q
measure 54
Ef3   12        q     d
rest  12        q
measure 55
F3    12        q     d
rest  12        q
measure 56
Bf2   12        q     u        f
Bf2   12        q     u
measure 57
Bf2    6        e     u  [
Bf2    6        e     u  =
Bf2    6        e     u  =
Bf2    6        e     u  ]
measure 58
A2     6        e     u  [
A2     6        e     u  =
A2     6        e     u  =
A2     6        e     u  ]
measure 59
Bf2    6        e     u  [
Bf2    6        e     u  =
Bf2    6        e     u  =
Bf2    6        e     u  ]
measure 60
F3     6        e     d  [
F3     6        e     d  =
F3     6        e     d  =
F3     6        e     d  ]
measure 61
Bf3    6        e     d  [
Bf3    6        e     d  =
Bf3    6        e     d  =
Bf3    6        e     d  ]
measure 62
Ef3    6        e     d  [
Ef3    6        e     d  =
Ef3    6        e     d  =
Ef3    6        e     d  ]
measure 63
F3     6        e     d  [
F3     6        e     d  =
F3     6        e     d  =
F3     6        e     d  ]
measure 64
Bf2   12        q     u
Bf2   12        q     u
measure 65
rest  12        q
Bf3   12-       q     d        -p
measure 66
Bf3   12        q     d
A3    12        q     d
measure 67
Bf3   12        q     d        (
Gf3   12        q f   d        )
measure 68
F3    24        h     d
measure 69
Ef3   24        h     d
measure 70
Df3   12        q f   d
C3    12        q     u
measure 71
Bf2   12        q     u
E3    12        q n   d
measure 72
F3    12        q     d
F2    12        q     u
measure 73
rest  12        q
Bf3   12-       q     d        -f
measure 74
Bf3   12        q     d
A3    12        q     d
measure 75
Bf3   12        q     d        (
Gf3   12        q f   d        )
measure 76
F3    24        h     d
measure 77
Ef3   24        h     d
measure 78
Df3   12        q f   d
Gf3   12        q f   d
measure 79
F3    24        h     d
measure 80
Bf2   24        h     u
measure 81
rest  12        q
E3    12        q n   d        (p
measure 82
Ef3   12        q f   d        +
Df3   12        q f   d        )
measure 83
rest  12        q
E3    12        q n   d        (
measure 84
Ef3   12        q f   d        +
Df3   12        q f   d        )
measure 85
rest  12        q
D3    12        q n   d        (+
measure 86
Ef3   12        q     d
F3    12        q     d        )
measure 87
Gf3   24        h f   d        (
measure 88
F3    12        q     d        )
rest  12        q
measure 89
rest  12        q
E3    12        q n   d        (f
measure 90
Ef3   12        q f   d        +
Df3   12        q f   d        )
measure 91
rest  12        q
E3    12        q n   d        (
measure 92
Ef3   12        q f   d        +
Df3   12        q f   d        )
measure 93
rest  12        q
A3    12        q     d
measure 94
Bf3   12        q     d
Ef3   12        q     d
measure 95
F3    12        q     d
F2    12        q     u
measure 96
Bf2   24        h     u
measure 97
Bf3   12        q     d        p
rest  12        q
measure 98
A3    12        q     d
rest  12        q
measure 99
Bf3   12        q     d
rest  12        q
measure 100
F3    12        q     d        f
F3    12        q     d
measure 101
Bf3   12        q     d        p
rest  12        q
measure 102
Ef3   12        q     d
rest  12        q
measure 103
F3    12        q     d
rest  12        q
measure 104
Bf2   12        q     u        f
Bf2   12        q     u
measure 105
D4     6        e n   d        .p+
rest   6        e
Bf3    6        e     d        .
rest   6        e
measure 106
C4     6        e     d        .
rest   6        e
A3     6        e     d        .
rest   6        e
measure 107
Bf3    6        e     d        .
rest   6        e
Bf2    6        e     u        .
rest   6        e
measure 108
F3     6        e     d        .
rest   6        e
F2     6        e     u        .
rest   6        e
measure 109
Bf2    6        e     u        .
rest   6        e
Bf3    6        e     d        .
rest   6        e
measure 110
Ef3    6        e     d        .
rest   6        e
Ef2    6        e     u        .
rest   6        e
measure 111
F2     6        e     u        &1.
rest   6        e
F3     6        e     d        &1.
rest   6        e
measure 112
Bf2   12-       q     u        -
Bf2    6        e     u
rest   6        e
measure 113
Bf2   12        q     u        f
D3    12        q     d
measure 114
C3    12        q     u
F3    12        q     d
measure 115
Bf3   12        q     d
D3    12        q     d
measure 116
C3    12        q     u
F2    12        q     u
measure 117
Bf2   12        q     u
G3    12        q     d
measure 118
Ef3   12        q     d
D3    12        q     d
measure 119
C3    12        q     u
E3    12        q n   d
measure 120
F3    12        q     d
Ef3   12        q f   d        +
measure 121
D3     6        e     d        .p
rest   6        e
E3     6        e n   d        .
rest   6        e
measure 122
F3     6        e     d        .
rest   6        e
A3     6        e     d        .
rest   6        e
measure 123
Bf3    6        e     d        .
rest   6        e
Bf3    6        e     d        .
rest   6        e
measure 124
A3     6        e     d        .
rest   6        e
D3     6        e     d        .
rest   6        e
measure 125
Ef3    6        e f   d        .+
rest   6        e
Ef3    6        e     d        .
rest   6        e
measure 126
D3     6        e     d        .
rest   6        e
G3     6        e     d        .
rest   6        e
measure 127
F3     6        e     d        .
rest   6        e
F2     6        e     u        .
rest   6        e
measure 128
Bf2   12        q     u        .
rest  12        q
measure 129
G3    12        q     d        (f
Bf3   12        q     d        )
measure 130
Ef3   12        q     d        (
G3    12        q     d        )
measure 131
F3    12        q     d
F#3   12        q #   d
measure 132
G3    12        q     d
G2    12        q     u
measure 133
D3    12        q     d        (
Bf2   12        q     u        )
measure 134
Ef3   12        q     d        (
G3    12        q     d        )
measure 135
F3    12        q n   d        +
F2    12        q     u
measure 136
Bf2   12        q     u
rest  12        q
measure 137
Bf3   12        q     d        p
rest  12        q
measure 138
A3    12        q     d
rest  12        q
measure 139
Bf3   12        q     d
rest  12        q
measure 140
F3    12        q     d        f
F3    12        q     d
measure 141
Bf3   12        q     d        p
rest  12        q
measure 142
Ef3   12        q     d
rest  12        q
measure 143
F3    12        q     d
rest  12        q
measure 144
Bf2   12        q     u        f
Bf2   12        q     u
measure 145
D3     3        s     d  [[    (
Ef3    3        s     d  ==
F3     3        s     d  ==
Ef3    3        s     d  ]]
D3    12        q     d        )
measure 146
Ef3    3        s     d  [[    (
F3     3        s     d  ==
G3     3        s     d  ==
F3     3        s     d  ]]
Ef3   12        q     d        )
measure 147
rest  24
measure 148
rest  24
measure 149
D3     3        s     d  [[    (f
Ef3    3        s     d  ==
F3     3        s     d  ==
Ef3    3        s     d  ]]
D3    12        q     d        )
measure 150
Ef3    3        s     d  [[    (
F3     3        s     d  ==
G3     3        s     d  ==
F3     3        s     d  ]]
Ef3   12        q     d        )
measure 151
C3    12        q     u
F3    12        q     d
measure 152
Bf2   12        q     u
rest  12        q
measure 153
rest  24
measure 154
Bf3    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
Bf3    4        e  3  d  [
A3     4        e  3  d  =
G3     4        e  3  d  ]
measure 155
F3     4        e  3  d  [
G3     4        e  3  d  =
F3     4        e  3  d  ]
Ef3    4        e  3  d  [
D3     4        e  3  d  =
C3     4        e  3  d  ]
measure 156
Bf2    4        e  3  u  [
C3     4        e  3  u  =
D3     4        e  3  u  ]
Ef3    4        e  3  d  [
D3     4        e  3  d  =
C3     4        e  3  d  ]
measure 157
Bf2    4        e  3  u  [
C3     4        e  3  u  =
D3     4        e  3  u  ]
Ef3    4        e  3  d  [
D3     4        e  3  d  =
C3     4        e  3  d  ]
measure 158
Bf2   12        q     u
Bf3   12        q     d
measure 159
Bf2   12        q     u
rest  12        q
mheavy2
/END
/eof
//
