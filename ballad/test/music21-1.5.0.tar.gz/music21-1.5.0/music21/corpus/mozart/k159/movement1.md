&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/01/01} [KHM:1309059632]
TIMESTAMP: DEC/26/2001 [md5sum:3a21cb5cdcd505322bd2c13ea954f72d]
06/13/94 E. Correia
WK#:159       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-2   Q:24   T:1/1  C:4  D:Andante
rest  96
measure 2
rest  96
measure 3
rest  96
measure 4
rest  96
measure 5
rest  96
measure 6
rest  96
measure 7
rest  96
measure 8
rest  96
measure 9
F5    24        q     d        .&0f
F5    24        q     d        .
rest  24        q
A5     9        s.    d  [[    (
F5     3        t     d  ==\   )
A5     9        s.    d  ==    (
F5     3        t     d  ]]\   )
measure 10
Bf5   24        q     d        .
Bf5   24        q     d        .
rest  24        q
Bf5    9        s.    d  [[    (
G5     3        t     d  ==\   )
Bf5    9        s.    d  ==    (
G5     3        t     d  ]]\   )
measure 11
E5    24        q n   d        .
E5    24        q     d        .
rest  24        q
G5     9        s.    d  [[    (
E5     3        t     d  ==\   )
G5     9        s.    d  ==    (
Bf4    3        t     d  ]]\   )
measure 12
A4    24        q     u
A4    24        q     u
gD5    4        t     u  [[[   (
S C1:t8
gE5    4        t n   u  ]]]
S C1:t8
F5    36        q.    d        )
E5     6        s n   d  [[    +
D5     6        s     d  ]]
measure 13
gD5    5        s     u
S C1:t50
C5    12        e     d  [
Bf4    6        s     d  =[
A4     6        s     d  ]]
A4    24        q     u
gD5    4        t     u  [[[   (
S C1:t8
gE5    4        t n   u  ]]]
S C1:t8
F5    36        q.    d        )
E5     6        s n   d  [[    +
D5     6        s     d  ]]
measure 14
gD5    5        s     u
S C1:t50
C5    12        e     d  [
Bf4    6        s     d  =[
A4     6        s     d  ]]
A4    24        q     u
F5    18        e.    d  [     (
C5     6        s     d  =\    )
G5    18        e.    d  =     (
C5     6        s     d  ]\    )
measure 15
A5    36        q.    d        (
G5     6        s     d  [[
A5     6        s     d  ]]
Bf5   12        e     d  [     )
A5    12        e     d  =     .
G5    12        e     d  =     .
F5    12        e     d  ]     .
measure 16
gF5    5        s     u
S C1:t50
E5    12        e n   d  [
D5     6        s     d  =[
C5     6        s     d  ]]
C5    24        q     d
C#5   12        e #   d  [     (p
D5    12        e     d  =     )
C#5   12        e     d  =     (
D5    12        e     d  ]     )
measure 17
G4    18        e.    u  [     (f
P C33:y10
A4     3        t     u  =[[
Bf4    3        t     u  ]]]   )
A4    24        q     u        .
C#5   12        e #   d  [     (p
D5    12        e     d  ]     )
C#5    6        s     d  [[    (
D5     6        s     d  ==    )
C#5    6        s     d  ==    (
D5     6        s     d  ]]    )
measure 18
G4    18        e.    u  [     (f
P C33:y10
A4     3        t     u  =[[
Bf4    3        t     u  ]]]   )
A4    24        q     u        .
C5    18        e.n   d  [     +
D5     3        t     d  =[[
E5     3        t n   d  ]]]
F5     6        s     d  [[    .
G5     6        s     d  ==    .
A5     6        s     d  ==    .
Bf5    6        s     d  ]]    .
measure 19
C6    12        e     d  [     .
Bf5    6        s     d  =[    (p
C6     3        t     d  ==[
Bf5    3        t     d  ]]]
A5    12        e     d        )
G5     6        s     d  [[    (
A5     3        t     d  ==[
G5     3        t     d  =]]
F5    12        e     d  ]     )
Ef5    6        s f   d  [[    (+
F5     3        t     d  ==[
Ef5    3        t     d  =]]
D5    12        e     d  ]     )
C#5   12        e #   d        (f
measure 20
D5    24        q     d        )
rest  24        q
G4    24        q     u        (p
A4    24        q     u        )
measure 21
Bf4   12        e     d
D5    24        q     d        (fp
C5    12        e     d        )
rest  12        e
Bf4   12        e     u  [     (p
A4    12        e     u  =
G4    12        e     u  ]     )
measure 22
G#4   24        q #   u        (
A4    24        q     u        )
G4    24        q n   u        (
A4    24        q     u        )
measure 23
Bf4   12        e     d
D5    24        q     d        (fp
C5    12        e     d        )
rest  12        e
Bf4   12        e     u  [     (p
A4    12        e     u  =
G4    12        e     u  ]     )
measure 24
rest  12        e
A5    24        q     d        (fp
F5    12        e     d        )
rest  12        e
F5    24        q     d        (fp
D5    12        e     d        )
measure 25
C5    18        e.    d  [     (p
D5     3        t     d  =[[
Bf4    3        t     d  ]]]   )
A4    12        e     u  [     .
A4    12        e     u  ]     .
rest  12        e
A4    12        e     u  [     (
Bf4   12        e     u  =
G4    12        e     u  ]     )
measure 26
rest  12        e
A5    24        q     d        (fp
F5    12        e     d        )
rest  12        e
F5    24        q     d        (fp
D5    12        e     d        )
measure 27
C5    18        e.    d  [     (p
D5     3        t     d  =[[
Bf4    3        t     d  ]]]   )
A4    12        e     u  [     .
A4    12        e     u  ]     .
rest  12        e
A4    12        e     u  [     (
Bf4   12        e     u  =
G4    12        e     u  ]     )
measure 28
F4    12        e     u  [     (
E4    12        e n   u  =
F4    12        e     u  =
G4    12        e     u  ]
A4    12        e     d  [
Bf4   12        e     d  =
C5    12        e     d  =
D5    12        e     d  ]     )
measure 29
Ef5   12        e f   d        .+
rest  12        e
C5    12        e     d        .
rest  12        e
A4    12        e     u        .
rest  12        e
rest  24        q
mheavy4 30      :|:
A5    12        e     d        .f
G5     6        s     d  [[    (
A5     3        t     d  ==[
G5     3        t     d  =]]
F#5   12        e #   d  ]     )
Ef5    6        s     d  [[    (
F5     3        t n   d  ==[
Ef5    3        t     d  =]]
D5    12        e     d  ]     )
C5     6        s     d  [[    (
D5     3        t     d  ==[
C5     3        t     d  =]]
Bf4   12        e     d  ]     )
A4     6        s     u  [[    (
P C32:u
Bf4    3        t     u  ==[
A4     3        t     u  ]]]
measure 31
Bf4   24        q     d        )
rest  24        q
rest  48        h
measure 32
G5    12        e     d        .
F5     6        s n   d  [[    (+
G5     3        t     d  ==[
F5     3        t     d  =]]
E5    12        e n   d  ]     )
D5     6        s     d  [[    (
E5     3        t     d  ==[
D5     3        t     d  =]]
C5    12        e     d  ]     )
Bf4    6        s     d  [[    (
C5     3        t     d  ==[
Bf4    3        t     d  =]]
A4    12        e     d  ]     )
G4     6        s     u  [[    (
A4     3        t     u  ==[
G4     3        t     u  ]]]
measure 33
A4    24        q     u        )
rest  24        q
rest  48        h
measure 34
F5    12        e     d        .
Ef5    6        s f   d  [[    (+
F5     3        t     d  ==[
Ef5    3        t     d  ]]]
D5    12        e     d        )
C5     6        s     d  [[    (
D5     3        t     d  ==[
C5     3        t     d  ]]]
Bf4   12        e     d        )
Af4    6        s f   u  [[    (
Bf4    3        t     u  ==[
Af4    3        t     u  ]]]
G4    12        e     u        )
F#4   12        e #   u        (
measure 35
G4    24        q     u        )
rest  24        q
F#5   12        e #   d  [     (p
G5    12        e     d  =     )
F#5   12        e     d  =     (
G5    12        e     d  ]     )
measure 36
B4    18        e.n   d  [     (f
C5     3        t     d  =[[
D5     3        t     d  ]]]   )
C5    24        q     d
E5    12        e n   d  [     (p
F5    12        e n   d  =     )+
E5    12        e     d  =     (
F5    12        e     d  ]     )
measure 37
A4    18        e.    d  [     (f
Bf4    3        t f   d  =[[   +
C5     3        t     d  ]]]   )
Bf4   24        q     d        .
C4    24        q     u        (p
P C33:y7
D4    24        q     u        )
measure 38
Ef4   12        e     u
G4    24        q     u        (fp
P C33:y10
F4    12        e n   u        )+
rest  12        e
F4    12        e     u  [     (p
P C33:y9
Ef4   12        e     u  =
D4    12        e     u  ]     )
measure 39
C4    12        e     u
F5    24        q     d        (fp
C5    12        e     d        )
rest  12        e
F5    24        q     d        (fp
D5    12        e     d        )
measure 40
C5    18        e.    d  [     (p
D5     3        t     d  =[[
C5     3        t     d  ]]]   )
A4    12        e     u  [     .
A4    12        e     u  ]     .
rest  12        e
A4    12        e     u  [     (
Bf4   12        e     u  =
G4    12        e     u  ]     )
measure 41
rest  12        e
F5    24        q     d        (fp
C5    12        e     d        )
rest  12        e
F5    24        q     d        (fp
D5    12        e     d        )
measure 42
C5    18        e.    d  [     (p
D5     3        t     d  =[[
Bf4    3        t     d  ]]]   )
A4    12        e     u  [     .
A4    12        e     u  ]     .
rest  12        e
A4    12        e     u  [     (
Bf4   12        e     u  =
G4    12        e     u  ]     )
measure 43
F4    12        e     u  [     (
E4    12        e n   u  =
F4    12        e     u  =
G4    12        e     u  ]
A4    12        e     d  [
Bf4   12        e     d  =
C5    12        e     d  =
D5    12        e     d  ]     )
measure 44
Ef5   12        e f   d        .+
rest  12        e
C5    12        e     d        .
rest  12        e
A4    12        e     u        .
rest  12        e
rest  24        q
measure 45
rest  96
measure 46
rest  96
measure 47
rest  96
measure 48
rest  96
measure 49
rest  96
measure 50
rest  96
measure 51
rest  96
measure 52
Bf5   24        q     d        .
Bf5   24        q     d        .
rest  24        q
Bf5    9        s.    d  [[    (
G5     3        t     d  ==\   )
C6     9        s.    d  ==    (
Bf5    3        t     d  ]]\   )
measure 53
Af5   24        q f   d
F5     9        s.    d  [[    (
C5     3        t     d  ==\   )
F5     9        s.    d  ==    (
Ef5    3        t     d  ]]\   )
D5    24        q     d
Af4    9        s.f   u  [[    (
F4     3        t     u  ==\   )
Bf4    9        s.    u  ==    (
Af4    3        t     u  ]]\   )
measure 54
G4    24        q     u
G4    24        q     u
gC5    4        t     u  [[[   (
S C1:t8
gD5    4        t     u  ]]]
S C1:t8
Ef5   36        q.    d        )
D5     6        s     d  [[
C5     6        s     d  ]]
measure 55
gC5    5        s     u
S C1:t50
Bf4   12        e     u  [
Af4    6        s f   u  =[
G4     6        s     u  ]]
G4    24        q     u
gC5    4        t     u  [[[   (
S C1:t8
gD5    4        t     u  ]]]
S C1:t8
Ef5   36        q.    d        )
D5     6        s     d  [[
C5     6        s     d  ]]
measure 56
gC5    5        s     u
S C1:t50
Bf4   12        e     u  [
Af4    6        s f   u  =[
G4     6        s     u  ]]
G4    24        q     u
Ef5   18        e.    d  [     (
Bf4    6        s     d  =\    )
F5    18        e.    d  =     (
Bf4    6        s     d  ]\    )
measure 57
G5    36        q.    d        (
A5    12        e n   d        )+
Bf5    8        e  3  d  [     (*.
A5     8        e  3  d  =       .
G5     8        e  3  d  ]      !.
F5     8        e  3  d  [      *.
Ef5    8        e  3  d  =       .
D5     8        e  3  d  ]     )!.
measure 58
D5    18        e.    d  [     (t
S C33:hn6s17t84
C5     3        t     d  =[[
D5     3        t     d  ]]]   )
C5    24        q     d
F#5   12        e #   d  [     (p
G5    12        e     d  =     )
F#5   12        e     d  =     (
G5    12        e     d  ]     )
measure 59
C5    18        e.    d  [     (f
D5     3        t     d  =[[
Ef5    3        t     d  ]]]   )
D5    24        q     d        .
F#5   12        e #   d  [     (p
G5    12        e     d  ]     )
F#5    6        s     d  [[    (
G5     6        s     d  ==    )
F#5    6        s     d  ==    (
G5     6        s     d  ]]    )
measure 60
C5    18        e.    d  [     (f
D5     3        t     d  =[[
Ef5    3        t     d  ]]]   )
D5    24        q     d        .
D5    18        e.    d  [
Ef5    3        t     d  =[[
F5     3        t n   d  ]]]   +
G5     6        s     d  [[    .
A5     6        s     d  ==    .
Bf5    6        s     d  ==    .
C6     6        s     d  ]]    .
measure 61
D6    12        e     d        .
C6     6        s     d  [[    (p
D6     3        t     d  ==[
C6     3        t     d  =]]
Bf5   12        e     d  ]     )
A5     6        s     d  [[    (
Bf5    3        t     d  ==[
A5     3        t     d  =]]
G5    12        e     d  ]     )
F5     6        s     d  [[    (
G5     3        t     d  ==[
F5     3        t     d  =]]
Ef5   12        e     d  ]     )
D5    12        e     d        (f
measure 62
Ef5   24        q     d        )
rest  24        q
C4    24        q     u        (p
P C33:y7
D4    24        q     u        )
measure 63
Ef4   12        e     u
G4    24        q     u        (fp
P C33:y10
F4    12        e     u        )
rest  12        e
Ef4   12        e     u  [     (p
P C33:y9
D4    12        e     u  =
C4    12        e     u  ]     )
measure 64
C#4   24        q #   u        (
D4    24        q     u        )
C5    24        q     d        (
D5    24        q     d        )
measure 65
Ef5   12        e     d
G5    24        q     d        (fp
F5    12        e     d        )
rest  12        e
Ef5   12        e     d  [     (p
D5    12        e     d  =
C5    12        e     d  ]     )
measure 66
rest  12        e
Bf5   24        q     d        (fp
F5    12        e     d        )
rest  12        e
Bf5   24        q     d        (fp
G5    12        e     d        )
measure 67
F5    18        e.    d  [     (p
G5     3        t     d  =[[
Ef5    3        t     d  ]]]   )
D5    12        e     d  [     .
D5    12        e     d  ]     .
rest  12        e
D5    12        e     d  [     (
Ef5   12        e     d  =
C5    12        e     d  ]     )
measure 68
rest  12        e
Bf4   24        q     d        (fp
P C33:y5
F4    12        e     u        )
rest  12        e
Bf4   24        q     d        (fp
P C33:y5
G4    12        e     u        )
measure 69
F4    18        e.    u  [     (p
P C33:y10
G4     3        t     u  =[[
Ef4    3        t     u  ]]]   )
D4    12        e     u  [     .
D4    12        e     u  ]     .
rest  12        e
D4    12        e     u  [     (
Ef4   12        e     u  =
C4    12        e     u  ]     )
measure 70
Bf3   12        e     u  [     (
A3    12        e     u  =
Bf3   12        e     u  =
C4    12        e     u  ]
D4    12        e     u  [
Ef4   12        e     u  =
F4    12        e     u  =
D4    12        e     u  ]     )
measure 71
Bf3   12        e     u        .
rest  12        e
D4    12        e     u        .
rest  12        e
Bf3   12        e     u        .
rest  12        e
rest  24        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/01/02} [KHM:1309059632]
TIMESTAMP: DEC/26/2001 [md5sum:5ec78d9f39467731da058e2f6708ac45]
06/13/94 E. Correia
WK#:159       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-2   Q:24   T:1/1  C:4  D:Andante
F5    24        q     d        .&0f
F5    24        q     d        .
rest  24        q
A5     9        s.    d  [[    (
F5     3        t     d  ==\   )
A5     9        s.    d  ==    (
F5     3        t     d  ]]\   )
measure 2
Bf5   24        q     d        .
Bf5   24        q     d        .
rest  24        q
F5     9        s.    d  [[    (
D5     3        t     d  ==\   )
F5     9        s.    d  ==    (
D5     3        t     d  ]]\   )
measure 3
C5    24        q     d
C5    24        q     d
rest  24        q
Ef5    9        s.    d  [[    (
C5     3        t     d  ==\   )
Ef5    9        s.    d  ==    (
C5     3        t     d  ]]\   )
measure 4
Bf4   24        q     d
Bf4   24        q     d
gG5    4        t     u  [[[   (
S C1:t8
gA5    4        t     u  ]]]
S C1:t8
Bf5   36        q.    d        )
A5     6        s     d  [[
G5     6        s     d  ]]
measure 5
gG5    5        s     u
S C1:t50
F5    12        e     d  [
Ef5    6        s     d  =[
D5     6        s     d  ]]
D5    24        q     d
gG5    4        t     u  [[[   (
S C1:t8
gA5    4        t     u  ]]]
S C1:t8
Bf5   36        q.    d        )
A5     6        s     d  [[
G5     6        s     d  ]]
measure 6
gG5    5        s     u
S C1:t50
F5    12        e     d  [
Ef5    6        s     d  =[
D5     6        s     d  ]]
D5    24        q     d
Bf4   18        e.    u  [     (
F4     6        s     u  =\    )
C5    18        e.    u  =     (
F4     6        s     u  ]\    )
measure 7
D5    12        e     d
Ef5   24        q     d
D5    24        q     d
C5    24        q     d
A4    12        e     u
measure 8
Bf4    8        e  3  d  [     (*
C5     8        e  3  d  =
D5     8        e  3  d  ]     )!
D5    24        q     d
Bf4   18        e.    u  [     (
F4     6        s     u  =\    )
C5    18        e.    u  =     (
F4     6        s     u  ]\    )
measure 9
D5    12        e     d
Ef5   24        q     d
D5    24        q     d
C5    24        q     d
A4    12        e     u
measure 10
E4    12        e n   u  [
E4    12        e     u  =
E4    12        e     u  =
E4    12        e     u  ]
E4    12        e     u  [
E4    12        e     u  =
E4    12        e     u  =
E4    12        e     u  ]
measure 11
G4    12        e     u  [
G4    12        e     u  =
G4    12        e     u  =
G4    12        e     u  ]
E4    12        e n   u  [
E4    12        e     u  =
E4    12        e     u  =
E4    12        e     u  ]
measure 12
F4    12        e     u  [     (
C4    12        e     u  =     )
F4    12        e     u  =     (
C4    12        e     u  ]     )
gD4    4        t     u  [[[   (
S C1:t8
gE4    4        t n   u  ]]]
S C1:t8
F4    36        q.    u        )
E4     6        s n   u  [[    +
D4     6        s     u  ]]
measure 13
gD4    5        s     u
S C1:t50
C4    12        e     u  [
Bf3    6        s     u  =[
A3     6        s     u  ]]
A3    24        q     u
gD4    4        t     u  [[[   (
S C1:t8
gE4    4        t n   u  ]]]
S C1:t8
F4    36        q.    u        )
E4     6        s n   u  [[    +
D4     6        s     u  ]]
measure 14
gD4    5        s     u
S C1:t50
C4    12        e     u  [
Bf3    6        s     u  =[
A3     6        s     u  ]]
A3    24        q     u
A3    18        e.    u  [     (
C4     6        s     u  =\    )
E4    18        e.n   u  =     (
C4     6        s     u  ]\    )
measure 15
F4    12        e     u
C5    24        q     d        (
Bf4    6        s     d  [[
C5     6        s     d  ]]
D5    12        e     d  [     )
C5    12        e     d  =     .
Bf4   12        e     d  =     .
A4    12        e     d  ]     .
measure 16
gA4    5        s     u
S C1:t50
G4    12        e     u  [
F4     6        s     u  =[
E4     6        s n   u  ]]
E4    24        q     u
C#4   12        e #   u  [     (p
P C33:y10
D4    12        e     u  =     )
C#4   12        e     u  =     (
D4    12        e     u  ]     )
measure 17
G3    18        e.    u  [     (f
P C33:y10
A3     3        t     u  =[[
Bf3    3        t     u  ]]]   )
A3    24        q     u        .
C#4   12        e #   u  [     (p
P C33:y10
D4    12        e     u  ]     )
C#4    6        s     u  [[    (
D4     6        s     u  ==    )
C#4    6        s     u  ==    (
D4     6        s     u  ]]    )
measure 18
G3    18        e.    u  [     (f
P C33:y10
A3     3        t     u  =[[
Bf3    3        t     u  ]]]   )
A3    24        q     u        .
A3    18        e.    u  [
Bf3    3        t     u  =[[
C4     3        t n   u  ]]]   +
D4     6        s     u  [[    .
E4     6        s n   u  ==    .
F4     6        s     u  ==    .
G4     6        s     u  ]]    .
measure 19
A4    12        e     u  [     .
G4     6        s     u  =[    (p
P C33:y3
A4     3        t     u  ==[
G4     3        t     u  ]]]
F4    12        e     u        )
Ef4    6        s f   u  [[    (+
F4     3        t     u  ==[
Ef4    3        t     u  =]]
D4    12        e     u  ]     )
C4     6        s     u  [[    (
D4     3        t     u  ==[
C4     3        t     u  =]]
Bf3   12        e     u  ]     )
A3    12        e     u        (f
P C33:y10
measure 20
Bf3   24        q     u        )
rest  24        q
E4    24        q n   u        (p
P C33:y3
F4    24        q     u        )
measure 21
G4    12        e     u
Bf4   24        q     d        (fp
P C33:y5
A4    12        e     u        )
rest  12        e
G4    12        e     u  [     (p
P C33:y10
F4    12        e     u  =
E4    12        e n   u  ]     )
measure 22
E4    24        q n   u        (
F4    24        q     u        )
E4    24        q     u        (
F4    24        q     u        )
measure 23
G4    12        e     u
Bf4   24        q     d        (fp
P C33:y5
A4    12        e     u        )
rest  12        e
G4    12        e     u  [     (p
P C33:y10
F4    12        e     u  =
E4    12        e n   u  ]     )
measure 24
rest  12        e
A4    24        q     u        (fp
P C33:y10
F4    12        e     u        )
rest  12        e
F4    24        q     u        (fp
P C33:y15
D4    12        e     u        )
measure 25
C4    18        e.    u  [     (p
P C33:y5
D4     3        t     u  =[[
Bf3    3        t     u  ]]]   )
A3    12        e     u  [     .
A3    12        e     u  ]     .
rest  12        e
A3    12        e     u  [     (
Bf3   12        e     u  =
G3    12        e     u  ]     )
measure 26
rest  12        e
A4    24        q     u        (fp
P C33:y10
F4    12        e     u        )
rest  12        e
F4    24        q     u        (fp
P C33:y15
D4    12        e     u        )
measure 27
C4    18        e.    u  [     (p
P C33:y5
D4     3        t     u  =[[
Bf3    3        t     u  ]]]   )
A3    12        e     u  [     .
A3    12        e     u  ]     .
rest  12        e
A3    12        e     u  [     (
Bf3   12        e     u  =
G3    12        e     u  ]     )
measure 28
A3    12        e     u
rest  12        e
F4    12        e     u  [     (
G4    12        e     u  ]
A4    12        e     d  [
Bf4   12        e     d  =
C5    12        e     d  =
D5    12        e     d  ]     )
measure 29
Ef5   12        e f   d        .+
rest  12        e
C5    12        e     d        .
rest  12        e
A4    12        e     u        .
rest  12        e
rest  24        q
mheavy4 30      :|:
F#5   12        e #   d        .f
Ef5    6        s     d  [[    (
F5     3        t n   d  ==[
Ef5    3        t     d  =]]
D5    12        e     d  ]     )
C5     6        s     d  [[    (
D5     3        t     d  ==[
C5     3        t     d  =]]
Bf4   12        e     d  ]     )
A4     6        s     u  [[    (
Bf4    3        t     u  ==[
A4     3        t     u  =]]
G4    12        e     u  ]     )
F#4    6        s #   u  [[    (
G4     3        t     u  ==[
F#4    3        t     u  ]]]
measure 31
G4    24        q     u        )
rest  24        q
rest  48        h
measure 32
E5    12        e n   d        .
D5     6        s     d  [[    (
E5     3        t     d  ==[
D5     3        t     d  =]]
C5    12        e     d  ]     )
Bf4    6        s     d  [[    (
C5     3        t     d  ==[
Bf4    3        t     d  =]]
A4    12        e     d  ]     )
G4     6        s     u  [[    (
A4     3        t     u  ==[
G4     3        t     u  =]]
F4    12        e n   u  ]     )+
E4     6        s n   u  [[    (
F4     3        t     u  ==[
E4     3        t     u  ]]]
measure 33
F4    24        q     u        )
rest  24        q
rest  48        h
measure 34
D5    12        e     d        .
C5     6        s     d  [[    (
D5     3        t     d  ==[
C5     3        t     d  ]]]
Bf4   12        e     d        )
Af4    6        s f   u  [[    (
Bf4    3        t     u  ==[
Af4    3        t     u  ]]]
G4    12        e     u        )
F4     6        s     u  [[    (
G4     3        t     u  ==[
F4     3        t     u  ]]]
Ef4   12        e f   u        )+
D4    12        e     u        (
measure 35
Ef4   24        q     u        )
rest  24        q
F#4   12        e #   u  [     (p
P C33:y5
G4    12        e     u  =     )
F#4   12        e     u  =     (
G4    12        e     u  ]     )
measure 36
B3    18        e.n   u  [     (f
P C33:y10
C4     3        t     u  =[[
D4     3        t     u  ]]]   )
C4    24        q     u
E4    12        e n   u  [     (p
P C33:y5
F4    12        e n   u  =     )+
E4    12        e     u  =     (
F4    12        e     u  ]     )
measure 37
A3    18        e.    u  [     (f
P C33:y10
Bf3    3        t f   u  =[[   +
C4     3        t     u  ]]]   )
Bf3   24        q     u        .
A3    24        q     u        (p
P C33:y5
B3    24        q n   u        )
measure 38
C4    12        e     u
Ef4   24        q     u        (fp
P C33:y15
D4    12        e     u        )
rest  12        e
D4    12        e     u  [     (p
P C33:y9
C4    12        e     u  =
Bf3   12        e f   u  ]     )+
measure 39
A3    12        e     u
C5    24        q     d        (fp
A4    12        e     u        )
rest  12        e
D5    24        q     d        (fp
Bf4   12        e     d        )
measure 40
A4    18        e.    u  [     (p
Bf4    3        t     u  =[[
A4     3        t     u  ]]]   )
F4    12        e     u  [     .
F4    12        e     u  ]     .
rest  12        e
F4    12        e     u  [     (
G4    12        e     u  =
E4    12        e n   u  ]     )
measure 41
rest  12        e
C5    24        q     d        (fp
A4    12        e     u        )
rest  12        e
D5    24        q     d        (fp
Bf4   12        e     d        )
measure 42
A4    18        e.    u  [     (p
Bf4    3        t     u  =[[
A4     3        t     u  ]]]   )
F4    12        e     u  [     .
F4    12        e     u  ]     .
rest  12        e
F4    12        e     u  [     (
G4    12        e     u  =
E4    12        e n   u  ]     )
measure 43
F4    12        e     u  [     (
E4    12        e n   u  =
F4    12        e     u  =
G4    12        e     u  ]
A4    12        e     d  [
Bf4   12        e     d  =
C5    12        e     d  =
D5    12        e     d  ]     )
measure 44
Ef5   12        e f   d        .+
rest  12        e
C5    12        e     d        .
rest  12        e
A4    12        e     u        .
rest  12        e
rest  24        q
measure 45
F5    24        q     d        .f
F5    24        q     d        .
rest  24        q
A5     9        s.    d  [[    (
F5     3        t     d  ==\   )
A5     9        s.    d  ==    (
F5     3        t     d  ]]\   )
measure 46
Bf5   24        q     d        .
Bf5   24        q     d        .
rest  24        q
F5     9        s.    d  [[    (
D5     3        t     d  ==\   )
F5     9        s.    d  ==    (
D5     3        t     d  ]]\   )
measure 47
C5    24        q     d        .
C5    24        q     d        .
rest  24        q
Ef5    9        s.    d  [[    (
C5     3        t     d  ==\   )
Ef5    9        s.    d  ==    (
C5     3        t     d  ]]\   )
measure 48
Bf4   24        q     d        .
Bf4   24        q     d        .
gG5    4        t     u  [[[   (
S C1:t8
gA5    4        t     u  ]]]
S C1:t8
Bf5   36        q.    d        )
A5     6        s     d  [[
G5     6        s     d  ]]
measure 49
gG5    5        s     u
S C1:t50
F5    12        e     d  [
Ef5    6        s     d  =[
D5     6        s     d  ]]
D5    24        q     d
gG5    4        t     u  [[[   (
S C1:t8
gA5    4        t     u  ]]]
S C1:t8
Bf5   36        q.    d        )
A5     6        s     d  [[
G5     6        s     d  ]]
measure 50
gG5    5        s     u
S C1:t50
F5    12        e     d  [
Ef5    6        s     d  =[
D5     6        s     d  ]]
D5    24        q     d
Bf4   18        e.    u  [     (
F4     6        s     u  =\    )
C5    18        e.    u  =     (
F4     6        s     u  ]\    )
measure 51
D5    12        e     d
Ef5   24        q     d
D5    24        q     d
C5    24        q     d
A4    12        e     u
measure 52
Bf4    8        e  3  d  [     (*
C5     8        e  3  d  =
D5     8        e  3  d  ]     )!
D5    24        q     d
Ef5    8        e  3  d  [     (*
F5     8        e  3  d  =
G5     8        e  3  d  ]     )!
G5    24        q     d
measure 53
C5    12        e     d  [
C5    12        e     d  =
C5    12        e     d  =
C5    12        e     d  ]
Bf4   12        e     d  [
Bf4   12        e     d  =
Bf4   12        e     d  =
Bf4   12        e     d  ]
measure 54
Bf4   12        e     u  [     (
G4    12        e     u  ]     )
Ef4   12        e     u  [     (
Bf3   12        e     u  ]     )
gC4    4        t     u  [[[   (
S C1:t8
gD4    4        t     u  ]]]
S C1:t8
Ef4   36        q.    u        )
D4     6        s     u  [[
C4     6        s     u  ]]
measure 55
gC4    5        s     u
S C1:t50
Bf3   12        e     u  [
Af3    6        s f   u  =[
G3     6        s     u  ]]
G3    24        q     u
gC4    4        t     u  [[[   (
S C1:t8
gD4    4        t     u  ]]]
S C1:t8
Ef4   36        q.    u        )
D4     6        s     u  [[
C4     6        s     u  ]]
measure 56
gC4    5        s     u
S C1:t50
Bf3   12        e     u  [
Af3    6        s f   u  =[
G3     6        s     u  ]]
G3    24        q     u
Bf3   24        q     u        (
D4    24        q     u        )
measure 57
Ef4   36        q.    u        (
F4    12        e     u        )
G4     8        e  3  u  [     (.*
F4     8        e  3  u  =      .
Ef4    8        e  3  u  ]      .!
D4     8        e  3  u  [      .*
C4     8        e  3  u  =      .
Bf3    8        e  3  u  ]     ).!
measure 58
Bf3   18        e.    u  [     (t
S C33:n6s17t84
A3     3        t n   u  =[[   +
Bf3    3        t     u  ]]]   )
A3    24        q     u
F#4   12        e #   u  [     (p
P C33:y10
G4    12        e     u  =     )
F#4   12        e     u  =     (
G4    12        e     u  ]     )
measure 59
C4    18        e.    u  [     (f
P C33:y10
D4     3        t     u  =[[
Ef4    3        t     u  ]]]   )
D4    24        q     u        .
F#4   12        e #   u  [     (p
P C33:y5
G4    12        e     u  ]     )
F#4    6        s     u  [[    (
G4     6        s     u  ==    )
F#4    6        s     u  ==    (
G4     6        s     u  ]]    )
measure 60
C4    18        e.    u  [     (f
P C33:y10
D4     3        t     u  =[[
Ef4    3        t     u  ]]]   )
D4    24        q     u        .
Bf3   18        e.    u  [
C4     3        t     u  =[[
D4     3        t     u  ]]]
Ef4    6        s     u  [[    .
F4     6        s n   u  ==    .+
G4     6        s     u  ==    .
A4     6        s     u  ]]    .
measure 61
Bf4   12        e     d        .
A4     6        s     u  [[    (p
P C33:y5
Bf4    3        t     u  ==[
A4     3        t     u  =]]
G4    12        e     u  ]     )
F4     6        s     u  [[    (
G4     3        t     u  ==[
F4     3        t     u  =]]
Ef4   12        e     u  ]     )
D4     6        s     u  [[    (
Ef4    3        t     u  ==[
D4     3        t     u  =]]
C4    12        e     u  ]     )
B3    12        e n   u        (f
P C33:y10
measure 62
C4    24        q     u        )
rest  24        q
A3    24        q     u        (p
P C33:y7
Bf3   24        q f   u        )+
measure 63
C4    12        e     u
Ef4   24        q     u        (fp
P C33:y14
D4    12        e     u        )
rest  12        e
C4    12        e     u  [     (p
P C33:y9
Bf3   12        e     u  =
A3    12        e     u  ]     )
measure 64
A3    24        q     u        (
Bf3   24        q     u        )
A4    24        q     u        (
Bf4   24        q     d        )
measure 65
C5    12        e     d
Ef5   24        q     d        (fp
D5    12        e     d        )
rest  12        e
C5    12        e     d  [     (p
Bf4   12        e     d  =
A4    12        e     d  ]     )
measure 66
rest  12        e
Bf4   24        q     d        (fp
P C33:y5
F4    12        e     u        )
rest  12        e
Bf4   24        q     d        (fp
P C33:y7
G4    12        e     u        )
measure 67
F4    18        e.    u  [     (p
P C33:y10
G4     3        t     u  =[[
Ef4    3        t     u  ]]]   )
D4    12        e     u  [     .
D4    12        e     u  ]     .
rest  12        e
D4    12        e     u  [     (
Ef4   12        e     u  =
C4    12        e     u  ]     )
measure 68
rest  12        e
F4    24        q     u        (fp
P C33:y15
D4    12        e     u        )
rest  12        e
G4    24        q     u        (fp
P C33:y12
Ef4   12        e     u        )
measure 69
D4    18        e.    u  [     (p
P C33:y10
Ef4    3        t     u  =[[
C4     3        t     u  ]]]   )
Bf3   12        e     u  [     .
Bf3   12        e     u  ]     .
rest  12        e
Bf3   12        e     u  [     (
C4    12        e     u  =
A3    12        e     u  ]     )
measure 70
Bf3   12        e     u  [     (
A3    12        e     u  =
Bf3   12        e     u  =
C4    12        e     u  ]
D4    12        e     u  [
Ef4   12        e     u  =
F4    12        e     u  =
D4    12        e     u  ]     )
measure 71
Bf3   12        e     u        .
rest  12        e
D4    12        e     u        .
rest  12        e
Bf3   12        e     u        .
rest  12        e
rest  24        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/01/03} [KHM:1309059632]
TIMESTAMP: DEC/26/2001 [md5sum:01ee041cac2b69f648e1b24f100facd9]
06/13/94 E. Correia
WK#:159       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-2   Q:24   T:1/1  C:13  D:Andante
D4    12        e     d  [     (&0f
F4    12        e     d  =
D4    12        e     d  =
F4    12        e     d  ]     )
C4    12        e     d  [     (
F4    12        e     d  =
C4    12        e     d  =
F4    12        e     d  ]     )
measure 2
Bf3   12        e     d  [     (
D4    12        e     d  =
Bf3   12        e     d  =
D4    12        e     d  ]     )
F3    12        e     u  [     (
Bf3   12        e     u  =
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 3
G3    12        e     u  [     (
Bf3   12        e     u  =
G3    12        e     u  =
Bf3   12        e     u  ]     )
A3    12        e     d  [     (
C4    12        e     d  =     )
C4    12        e     d  =     (
Ef4   12        e     d  ]     )
measure 4
D4    12        e     d  [     (
Bf3   12        e     d  =
D4    12        e     d  =
Bf3   12        e     d  ]     )
gEf4   4        t     u  [[[   (
S C1:t8
gF4    4        t     u  ]]]
S C1:t8
G4    36        q.    d        )
F4     6        s     d  [[
Ef4    6        s     d  ]]
measure 5
gEf4   5        s     u
S C1:t50
D4    12        e     d  [
C4     6        s     d  =[
Bf3    6        s     d  ]]
Bf3   24        q     u
gEf4   4        t     u  [[[   (
S C1:t8
gF4    4        t     u  ]]]
S C1:t8
G4    36        q.    d        )
F4     6        s     d  [[
Ef4    6        s     d  ]]
measure 6
gEf4   5        s     u
S C1:t50
D4    12        e     d  [
C4     6        s     d  =[
Bf3    6        s     d  ]]
Bf3   24        q     u
Bf3   24        q     u        (
A3    24        q     u        )
measure 7
Bf3   12        e     u
G4    24        q     d
F4    24        q     d
Ef4   24        q     d
C4    12        e     d
measure 8
D4     8        e  3  d  [     (*
Ef4    8        e  3  d  =
F4     8        e  3  d  ]     )!
F4    24        q     d
Bf3   24        q     u        (
A3    24        q     u        )
measure 9
Bf3   12        e     u
A3    24        q     u
Bf3   24        q     u
Ef4   24        q     d
C4    12        e     d
measure 10
C4    12        e     d  [
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
C4    12        e     d  [
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
measure 11
Bf3   12        e     u  [
Bf3   12        e     u  =
Bf3   12        e     u  =
Bf3   12        e     u  ]
G3    12        e     u  [
G3    12        e     u  =
G3    12        e     u  =
G3    12        e     u  ]
measure 12
F3    24        q     u
rest  24        q
gBf3   4        t     u  [[[   (
S C1:t8
gC4    4        t     u  ]]]
S C1:t8
D4    36        q.    d        )
C4     6        s     u  [[
Bf3    6        s     u  ]]
measure 13
gBf3   5        s     u
S C1:t50
A3    12        e     u  [
G3     6        s     u  =[
F3     6        s     u  ]]
F3    24        q     u
gBf3   4        t     u  [[[   (
S C1:t8
gC4    4        t     u  ]]]
S C1:t8
D4    36        q.    d        )
C4     6        s     u  [[
Bf3    6        s     u  ]]
measure 14
gBf3   5        s     u
S C1:t50
A3    12        e     u  [
G3     6        s     u  =[
F3     6        s     u  ]]
F3    24        q     u
F4    18        e.    d  [     (
C4     6        s     d  =\    )
G4    18        e.    d  =     (
C4     6        s     d  ]\    )
measure 15
A4    36        q.    d        (
G4     6        s     d  [[
A4     6        s     d  ]]
Bf4   12        e     d  [     )
A4    12        e     d  =     .
G4    12        e     d  =     .
F4    12        e     d  ]     .
measure 16
gF4    5        s     u
S C1:t50
E4    12        e n   d  [
D4     6        s     d  =[
C4     6        s     d  ]]
C4    24        q     d
rest  48        h
measure 17
E3    18        e.n   u  [     (
F3     3        t     u  =[[
G3     3        t     u  ]]]   )
F3    24        q     u        .
rest  48        h
measure 18
E3    18        e.n   u  [     (
F3     3        t     u  =[[
G3     3        t     u  ]]]   )
F3    24        q     u        .
rest  48        h
measure 19
rest  96
measure 20
rest  48        h
C4    48        h     d        p
measure 21
rest  12        e
G4    24        q     d        (fp
C4    12        e     d        )
D4    24        q     d        (p
C4    24        q     d        )
measure 22
C4    48        h     d
C4    48        h     d
measure 23
rest  12        e
G4    24        q     d        (fp
C4    12        e     d        )
D4    24        q     d        (p
C4    24        q     d        )
measure 24
rest  12        e
F4    24        q     d        (fp
C4    12        e     d        )
rest  12        e
D4    24        q     d        (fp
Bf3   12        e     u        )
measure 25
A3    18        e.    u  [     (p
P C33:y5
Bf3    3        t     u  =[[
G3     3        t     u  ]]]   )
F3    12        e     u  [     .
F3    12        e     u  ]     .
rest  12        e
F3    12        e     u  [     (
G3    12        e     u  =
E3    12        e n   u  ]     )
measure 26
rest  12        e
F4    24        q     d        (fp
C4    12        e     d        )
rest  12        e
D4    24        q     d        (fp
Bf3   12        e     u        )
measure 27
A3    18        e.    u  [     (p
P C33:y5
Bf3    3        t     u  =[[
G3     3        t     u  ]]]   )
F3    12        e     u  [     .
F3    12        e     u  ]     .
rest  12        e
F3    12        e     u  [     (
G3    12        e     u  =
E3    12        e n   u  ]     )
measure 28
F3    12        e     u  [     (
E3    12        e n   u  =
F3    12        e     u  =
G3    12        e     u  ]
A3    12        e     u  [
Bf3   12        e     u  =
C4    12        e     u  =
D4    12        e     u  ]     )
measure 29
Ef4   12        e f   d        .+
rest  12        e
C4    12        e     d        .
rest  12        e
A3    12        e     u        .
rest  12        e
rest  24        q
mheavy4 30      :|:
D4    24        q     d        f
rest  24        q
rest  48        h
measure 31
Bf3   12        e     u        .
C4     6        s     d  [[    (
D4     3        t     d  ==[
C4     3        t     d  ]]]
D4    12        e     d        )
Ef4    6        s     d  [[    (
F4     3        t     d  ==[
Ef4    3        t     d  ]]]
F#4   12        e #   d        )
G4     6        s     d  [[    (
A4     3        t     d  ==[
G4     3        t     d  =]]
A4    12        e     d  ]     )
Bf4   12        e     d        .
measure 32
G4    24        q     d
rest  24        q
rest  48        h
measure 33
A3    12        e     u        .
Bf3    6        s     u  [[    (
P C32:u
C4     3        t     u  ==[
Bf3    3        t     u  ]]]
C4    12        e     d        )
D4     6        s     d  [[    (
E4     3        t n   d  ==[
D4     3        t     d  ]]]
E4    12        e     d        )
F4     6        s n   d  [[    (+
G4     3        t     d  ==[
F4     3        t     d  =]]
G4    12        e     d  ]     )
A4    12        e     d        .
measure 34
D4    24        q     d
rest  24        q
rest  48        h
measure 35
rest  12        e
G4    12        e     d  [     (
F#4   12        e #   d  =
G4    12        e     d  ]     )
rest  48        h
measure 36
Af3   24        q f   u        (
G3    24        q     u        )
rest  48        h
measure 37
C4    24        q     d        (
F3    24        q     u        )
F3    48        h     u        p
measure 38
rest  12        e
C4    24        q     d        (fp
P C33:y5
D4    12        e     d        )
G3    48        h     u        p
measure 39
A3    12        e     u
A4    24        q     d        (fp
F4    12        e     d        )
rest  12        e
Bf4   24        q     d        (fp
F4    12        e     d        )
measure 40
F4    24        q     d        p
C4    48        h     d        (
Bf3   24        q     u        )
measure 41
A3    12        e     u
A4    24        q     d        (fp
F4    12        e     d        )
rest  12        e
Bf4   24        q     d        (fp
F4    12        e     d        )
measure 42
F4    24        q     d        p
C4    48        h     d        (
Bf3   24        q     u        )
measure 43
A3    24        q     u
F3    12        e     u  [     (
G3    12        e     u  ]
A3    12        e     u  [
Bf3   12        e     u  =
C4    12        e     u  =
D4    12        e     u  ]     )
measure 44
Ef4   12        e f   d        .+
rest  12        e
C4    12        e     d        .
rest  12        e
A3    12        e     u        .
rest  12        e
rest  24        q
measure 45
D4    12        e     d  [     (f
F4    12        e     d  =
D4    12        e     d  =
F4    12        e     d  ]     )
C4    12        e     d  [     (
F4    12        e     d  =
C4    12        e     d  =
F4    12        e     d  ]     )
measure 46
Bf3   12        e     d  [     (
D4    12        e     d  =
Bf3   12        e     d  =
D4    12        e     d  ]     )
F3    12        e     u  [     (
Bf3   12        e     u  =
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 47
G3    12        e     u  [     (
Bf3   12        e     u  =
G3    12        e     u  =
Bf3   12        e     u  ]     )
A3    12        e     d  [     (
C4    12        e     d  =     )
C4    12        e     d  =     (
Ef4   12        e     d  ]     )
measure 48
D4    12        e     d  [     (
Bf3   12        e     d  =
D4    12        e     d  =
Bf3   12        e     d  ]     )
gEf4   4        t     u  [[[   (
S C1:t8
gF4    4        t     u  ]]]
S C1:t8
G4    36        q.    d        )
F4     6        s     d  [[
Ef4    6        s     d  ]]
measure 49
gEf4   5        s     u
S C1:t50
D4    12        e     d  [
C4     6        s     d  =[
Bf3    6        s     d  ]]
Bf3   24        q     u
gEf4   4        t     u  [[[   (
S C1:t8
gF4    4        t     u  ]]]
S C1:t8
G4    36        q.    d        )
F4     6        s     d  [[
Ef4    6        s     d  ]]
measure 50
gEf4   5        s     u
S C1:t50
D4    12        e     d  [
C4     6        s     d  =[
Bf3    6        s     d  ]]
Bf3   24        q     u
Bf3   24        q     u        (
A3    24        q     u        )
measure 51
Bf3   12        e     u
G4    24        q     d
F4    24        q     d
Ef4   24        q     d
C4    12        e     d
measure 52
D4     8        e  3  d  [     (*
Ef4    8        e  3  d  =
F4     8        e  3  d  ]     )!
F4    24        q     d
G4     8        e  3  d  [     (*
Af4    8        e f3  d  =
Bf4    8        e  3  d  ]     )!
Bf4   24        q     d
measure 53
F4    12        e     d  [
F4    12        e     d  =
F4    12        e     d  =
F4    12        e     d  ]
F4    12        e     d  [
F4    12        e     d  =
F4    12        e     d  =
F4    12        e     d  ]
measure 54
G4    12        e     d  [     (
Ef4   12        e     d  ]     )
Bf3   12        e     u  [     (
G3    12        e     u  ]     )
gAf3   4        t f   u  [[[   (
S C1:t8
gBf3   4        t     u  ]]]
S C1:t8
C4    36        q.    d        )
Bf3    6        s     u  [[
Af3    6        s f   u  ]]    +
measure 55
gAf3   5        s f   u
S C1:t50
G3    12        e     u  [
F3     6        s     u  =[
Ef3    6        s     u  ]]
Ef3   24        q     u
gAf3   4        t     u  [[[   (
S C1:t8
gBf3   4        t     u  ]]]
S C1:t8
C4    36        q.    d        )
Bf3    6        s     u  [[
Af3    6        s     u  ]]
measure 56
gAf3   5        s f   u
S C1:t50
G3    12        e     u  [
F3     6        s     u  =[
Ef3    6        s     u  ]]
Ef3   24        q     u
Bf3   48-       h     u        -
measure 57
Bf3   24        q     u
Ef3   48        h     u
G3    24        q     u
measure 58
F3    48        h     u
rest  48        h
measure 59
A3    18        e.n   u  [     (+
Bf3    3        t     u  =[[
C4     3        t     u  ]]]   )
Bf3   24        q     u        .
rest  48        h
measure 60
A3    18        e.    u  [     (
Bf3    3        t     u  =[[
C4     3        t     u  ]]]   )
Bf3   24        q     u        .
rest  48        h
measure 61
rest  96
measure 62
rest  48        h
F3    48        h     u        p
measure 63
rest  12        e
C4    24        q     d        (fp
P C33:y5
F3    12        e     u        )
G3    24        q     u        (p
P C33:y10
F3    24        q     u        )
measure 64
F3    48        h     u
F4    48        h     d
measure 65
rest  12        e
C5    24        q     d        (fp
F4    12        e     d        )
G4    24        q     d        (p
F4    12        e     d  [
Ef4   12        e     d  ]     )
measure 66
D4    12        e     d
F4    24        q     d        (fp
D4    12        e     d        )
rest  12        e
G4    24        q     d        (fp
Ef4   12        e     d        )
measure 67
D4    18        e.    d  [     (p
Ef4    3        t     d  =[[
C4     3        t     d  ]]]   )
Bf3   12        e     u  [     .
Bf3   12        e     u  ]     .
rest  12        e
Bf3   12        e     u  [     (
C4    12        e     u  =
A3    12        e     u  ]     )
measure 68
rest  12        e
D4    24        q     d        (fp
Bf3   12        e     u        )
rest  12        e
Ef4   24        q     d        (fp
Bf3   12        e     u        )
measure 69
Bf3   24        q     u
F3    48        h     u        (
Ef3   24        q     u        )
measure 70
D3    24        q     u
Bf3   12        e     u  [     (
C4    12        e     u  ]
D4    12        e     d  [
Ef4   12        e     d  =
F4    12        e     d  =
D4    12        e     d  ]     )
measure 71
Bf3   12        e     u        .
rest  12        e
D4    12        e     d        .
rest  12        e
Bf3   12        e     u        .
rest  12        e
rest  24        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/01/04} [KHM:1309059632]
TIMESTAMP: DEC/26/2001 [md5sum:275ef5045f19e9d7d4697cb2b88ea01b]
06/13/94 E. Correia
WK#:159       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-2   Q:8   T:1/1  C:22  D:Andante
Bf3   16        h     d        (&0f
A3    16        h     d        )
measure 2
G3    16        h     d        (
D3    16        h     d        )
measure 3
Ef3   16        h     d        (
F3    16        h     d        )
measure 4
G3     8        q     d
rest   8        q
Ef3    8        q     d
G3     8        q     d
measure 5
Bf3    8        q     d
rest   8        q
Ef3    8        q     d
G3     8        q     d
measure 6
Bf3    8        q     d
rest   8        q
D3     8        q     d        (
C3     8        q     u        )
measure 7
Bf2    8        q     u
Bf3    8        q     d
Ef3    8        q     d
F3     8        q     d
measure 8
Bf2    8        q     u
rest   8        q
D3     8        q     d        (
C3     8        q     u        )
measure 9
Bf2    8        q     u
Bf3    8        q     d
F3     8        q     d
F2     8        q     u
measure 10
G2     4        e     u  [
G2     4        e     u  =
G2     4        e     u  =
G2     4        e     u  ]
G3     4        e     d  [
G3     4        e     d  =
G3     4        e     d  =
G3     4        e     d  ]
measure 11
C3     4        e     u  [
C3     4        e     u  =
C3     4        e     u  =
C3     4        e     u  ]
C3     4        e     u  [
C3     4        e     u  =
C3     4        e     u  =
C3     4        e     u  ]
measure 12
F3     8        q     d
rest   8        q
Bf2    8        q     u
D3     8        q     d
measure 13
F3     8        q     d
rest   8        q
Bf2    8        q     u
D3     8        q     d
measure 14
F3     8        q     d
rest   8        q
F3     8        q     d
C3     8        q     u
measure 15
rest   8        q
F3     8        q     d
Bf2   12        q.    u        (
B2     4        e n   u        )
measure 16
C3     8        q     u
rest   8        q
rest  16        h
measure 17
C3     8        q     u
F2     8        q     u
rest  16        h
measure 18
C2     8        q     u
F2     8        q     u
rest  16        h
measure 19
rest  32
measure 20
rest  16        h
Bf3    8        q     d        (p
A3     8        q     d        )
measure 21
G3     4        e     d
E3     8        q n   d        (fp
F3     4        e     d        )
Bf2    8        q     u        (p
P C33:y5
C3     8        q     u        )
measure 22
F3    16        h     d
Bf3    8        q     d        (
A3     8        q     d        )
measure 23
G3     4        e     d
E3     8        q n   d        (fp
F3     4        e     d        )
Bf2    8        q     u        (p
P C33:y5
C3     4        e     u  [
Bf2    4        e     u  ]     )
measure 24
A2     8        q     u        f
P C32:y5
rest   8        q
Bf2    8        q     u
rest   8        q
measure 25
C3    16        h     u        p
C2    16        h     u
measure 26
A2     8        q     u        f
P C32:y5
rest   8        q
Bf2    8        q     u
rest   8        q
measure 27
C3    16        h     u        p
C2    16        h     u
measure 28
F2     4        e     u  [     (
E2     4        e n   u  =
F2     4        e     u  =
G2     4        e     u  ]
A2     4        e     u  [
Bf2    4        e     u  =
C3     4        e     u  =
D3     4        e     u  ]     )
measure 29
Ef3    4        e f   d        .+
rest   4        e
C3     4        e     u        .
rest   4        e
A2     4        e     u        .
rest   4        e
rest   8        q
mheavy4 30      :|:
D3     8        q     d        f
P C32:y5
rest   8        q
rest  16        h
measure 31
G2     4        e     u        .
A2     2        s     u  [[    (
Bf2    1        t     u  ==[
A2     1        t     u  ]]]
Bf2    4        e     u        )
C3     2        s     u  [[    (
P C32:u
D3     1        t     u  ==[
C3     1        t     u  ]]]
D3     4        e     d        )
Ef3    2        s     d  [[    (
F3     1        t     d  ==[
Ef3    1        t     d  =]]
F#3    4        e #   d  ]     )
G3     4        e     d        .
measure 32
C3     8        q     u
rest   8        q
rest  16        h
measure 33
F2     4        e     u        .
G2     2        s     u  [[    (
A2     1        t     u  ==[
G2     1        t     u  ]]]
A2     4        e     u        )
Bf2    2        s     u  [[    (
C3     1        t     u  ==[
Bf2    1        t     u  ]]]
C3     4        e     u        )
D3     2        s     d  [[    (
E3     1        t n   d  ==[
D3     1        t     d  =]]
E3     4        e     d  ]     )
F3     4        e n   d        .+
measure 34
Bf2    8        q     u
rest   8        q
rest  16        h
measure 35
rest   4        e
Ef3    4        e f   d  [     (+
D3     4        e     d  =
Ef3    4        e     d  ]     )
rest  16        h
measure 36
F3     8        q     d        (
Ef3    8        q     d        )
rest  16        h
measure 37
Ef3    8        q     d        (
D3     8        q     d        )
Ef3    8        q     d        (p
D3     8        q     d        )
measure 38
C3     4        e     u
A2     8        q     u        (fp
P C33:y10
Bf2    4        e     u        )
Ef3   12        q.    d        (p
E3     4        e n   d        )
measure 39
F3     8        q     d        f
rest   8        q
F2     8        q     u
rest   8        q
measure 40
F3    16        h     d        (p
C3    16        h     u        )
measure 41
F2     8        q     u        f
P C32:y5
rest   8        q
F3     8        q     d
rest   8        q
measure 42
F2    16        h     u        (p
P C33:y10
C2    16        h     u        )
measure 43
F2     4        e     u  [     (
E2     4        e n   u  =
F2     4        e     u  =
G2     4        e     u  ]
A2     4        e     u  [
Bf2    4        e     u  =
C3     4        e     u  =
D3     4        e     u  ]     )
measure 44
Ef3    4        e f   d        .+
rest   4        e
C3     4        e     u        .
rest   4        e
A2     4        e     u        .
rest   4        e
rest   8        q
measure 45
Bf3   16        h     d        (f
A3    16        h     d        )
measure 46
G3    16        h     d        (
D3    16        h     d        )
measure 47
Ef3   16        h     d        (
F3    16        h     d        )
measure 48
G3     8        q     d
rest   8        q
Ef3    8        q     d
G3     8        q     d
measure 49
Bf3    8        q     d
rest   8        q
Ef3    8        q     d
G3     8        q     d
measure 50
Bf3    8        q     d
rest   8        q
D3     8        q     d        (
C3     8        q     u        )
measure 51
Bf2    8        q     u
Bf3    8        q     d
Ef3    8        q     d
F3     8        q     d
measure 52
Bf3    8        q     d        (
Af3    8        q f   d
G3     8        q     d
Ef3    8        q     d        )
measure 53
F3     8        q     d
Af3    8        q f   d
Bf3    8        q     d
D3     8        q     d
measure 54
Ef3    8        q     d
rest   8        q
Af2    8        q f   u
C3     8        q     u
measure 55
Ef3    8        q     d
rest   8        q
Af2    8        q f   u
C3     8        q     u
measure 56
Ef3    8        q     d
rest   8        q
G3     8        q     d        (
F3     8        q     d        )
measure 57
Ef3    8        q     d
Ef3    8        q     d
Ef3    8        q     d
Ef3    4        e     d  [     (
E3     4        e n   d  ]     )
measure 58
F3     8        q     d
F2     8        q     u
rest  16        h
measure 59
F3     8        q     d
Bf2    8        q     u
rest  16        h
measure 60
F2     8        q     u
Bf2    8        q     u
rest  16        h
measure 61
rest  32
measure 62
rest  16        h
Ef3    8        q     d        (p
D3     8        q     d        )
measure 63
C3     4        e     u
A2     8        q     u        (fp
P C33:y10
Bf2    4        e     u        )
Ef2    8        q     u        (p
P C33:y5
F2     8        q     u        )
measure 64
Bf2   16        h     u
Ef4    8        q     d        (
D4     8        q     d        )
measure 65
C4     4        e     d
A3     8        q     d        (fp
Bf3    4        e     d        )
Ef3    8        q     d        (p
F3     8        q     d        )
measure 66
Bf2    8        q     u        f
P C32:y5
rest   8        q
Ef3    8        q     d
rest   8        q
measure 67
F3    16        h     d        p
F2    16        h     u
measure 68
Bf2    8        q     u        f
P C32:y5
rest   8        q
Ef3    8        q     d
rest   8        q
measure 69
F3    16        h     d        p
F2    16        h     u
measure 70
Bf2    4        e     u  [     (
A2     4        e     u  =
Bf2    4        e     u  =
C3     4        e     u  ]
D3     4        e     d  [
Ef3    4        e     d  =
F3     4        e     d  =
D3     4        e     d  ]     )
measure 71
Bf2    4        e     u        .
rest   4        e
D3     4        e     d        .
rest   4        e
Bf2    4        e     u        .
rest   4        e
rest   8        q
mheavy2         :|
/END
/eof
//
