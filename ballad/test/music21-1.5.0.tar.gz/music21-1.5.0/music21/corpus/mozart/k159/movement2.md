&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/02/01} [KHM:2139995797]
TIMESTAMP: DEC/26/2001 [md5sum:5f6c9ccdb03a9c41b23dbd44c2832fe5]
06/16/94 E. Correia
WK#:159       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violino 1
0 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-2   Q:8   T:3/4  C:4  D:Allegro
G5     8        q     d        f
D5     8        q     d
D5     8        q     d
measure 2
D5     6        e.    d  [     (t
S C33:hn6s17t84
C#5    1        t #   d  =[[
D5     1        t     d  ]]]   )
rest   8        q
rest   8        q
measure 3
A5     8        q     d
D5     8        q     d
D5     8        q     d
measure 4
D5     6        e.    d  [     (t
S C33:hn6s17t84
C#5    1        t #   d  =[[
D5     1        t     d  ]]]   )
rest   8        q
rest   8        q
measure 5
Bf5    8        q     d        (
A5     8        q     d        )
D5     8        q     d        .
measure 6
G5     8        q     d        (
F5     8        q     d        )
Bf4    8        q     d        .
measure 7
G5     8        q     d        (
F5     8        q     d        )
Bf4    8        q     d        .
measure 8
Ef5    8        q     d        (
D5     8        q     d        )
D5     6        e.    d  [     (
C5     2        s     d  ]\    )
measure 9
Bf4    8        q     d
A4     8        q     u
G4     8        q     u
measure 10
F#4    8        q #   u        (
D5     8        q     d        )
F4     8        q n   u        .
measure 11
E4     8        q n   u        (
C5     8        q     d        )
Ef4    8        q f   u        &1.
measure 12
D4     8        q     u        .
D5     8        q     d        .
rest   8        q
measure 13
B4     8        q n   d        (p
C5     8        q     d
D5     8        q     d        )
measure 14
Ef5    8        q     d        (
C5     8        q     d
A4     8        q     u        )
measure 15
Bf4    8        q f   d        (+
G5     8        q     d
F5     8        q     d
measure 16
E5     8        q n   d
F5     8        q     d
A4     8        q     u        )
measure 17
G4     8        q     u        (
P C32:o
Ef5    8        q f   d        +
D5     8        q     d
measure 18
C#5    8        q #   d
D5     8        q     d
F4     8        q     u        )
measure 19
Ef4    8        q     u        (
C5     8        q n   d        +
Bf4    8        q     d
measure 20
A4     8        q     u
Bf4    8        q     d
F5     8        q     d        )
measure 21
E5    24        h.n   d        f
measure 22
Bf5   24        h.    d
measure 23
A5    24        h.    d
measure 24
Ef5   24        h.f   d        +
measure 25
D5     8        q     d
Bf5    2        s     d  [[    (
A5     2        s     d  ==
G5     2        s     d  ==
F5     2        s     d  ]]
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ]]    )
measure 26
Af4   16        h f   u        (
F#4    8        q #   u        )
measure 27
G4     8        q     u
Bf5    2        s     d  [[    (
A5     2        s     d  ==
G5     2        s     d  ==
F5     2        s     d  ]]
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ]]    )
measure 28
Af4   16        h f   u        (
F#4    8        q #   u        )
measure 29
G4     8        q     u
rest   8        q
rest   8        q
measure 30
B4     8        q n   d        (p
C5     8        q     d        )
D5     8        q     d        (
measure 31
Ef5    8        q     d        )
F#5    8        q #   d        (
G5     8        q     d        )
measure 32
F5     8        q n   d        +
rest   4        e
F5     4        e     d  [     .
F5     4        e     d  =     .
F5     4        e     d  ]     .
measure 33
Bf5    8        q     d        (
F5     8        q     d
D5     8        q     d        )
measure 34
Ef5    8        q     d
rest   4        e
C5     4        e     d  [     .
C5     4        e     d  =     .
C5     4        e     d  ]     .
measure 35
Ef5    8        q     d        (
C5     8        q     d
A4     8        q     u        )
measure 36
Bf4    4        e f   u  [     f+
Bf3    4        e     u  =
Bf3    4        e     u  =
Bf3    4        e     u  =
Bf3    4        e     u  =
Bf3    4        e     u  ]
measure 37
gC4    5        s     u
S C1:t50
Bf3    4        e     u  [     (
A3     2        s     u  =[
Bf3    2        s     u  ]]    )
A3     8        q     u
rest   8        q
measure 38
rest   4        e
D4     4        e     u  [
D4     4        e     u  =
D4     4        e     u  =
D4     4        e     u  =
D4     4        e     u  ]
measure 39
gEf4   5        s     u
S C1:t50
D4     4        e     u  [     (
C4     2        s     u  =[
D4     2        s     u  ]]    )
C4     8        q     u
rest   8        q
measure 40
rest   4        e
F4     4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
F4     4        e     u  =
F4     4        e     u  ]
measure 41
gG4    5        s     u
S C1:t50
F4     4        e     u  [     (
Ef4    2        s     u  =[
F4     2        s     u  ]]    )
Ef4    4        e     d  [
Ef5    4        e     d  =
Ef5    4        e     d  =
Ef5    4        e     d  ]
measure 42
A5     4        e     d  [
Ef5    4        e     d  =
C6     4        e     d  =
Ef5    4        e     d  =
Ef6    4        e     d  =
Ef5    4        e     d  ]
measure 43
C6     4        e     d  [
Ef5    4        e     d  =
A5     4        e     d  =
Ef5    4        e     d  =
Ef5    4        e     d  =
Ef5    4        e     d  ]
measure 44
A5     4        e     d  [
Ef5    4        e     d  =
C6     4        e     d  =
Ef5    4        e     d  =
Ef6    4        e     d  =
Ef5    4        e     d  ]
measure 45
C6     4        e     d  [
Ef5    4        e     d  =
A5     4        e     d  =
Ef5    4        e     d  =
Ef5    4        e     d  =
Ef5    4        e     d  ]
measure 46
A5     4        e     d  [
Ef5    4        e     d  =
C6     4        e     d  =
Ef5    4        e     d  =
Ef6    4        e     d  =
Ef5    4        e     d  ]
measure 47
D6     4        e     d  [
Bf4    4        e     d  =
C5     4        e     d  =
D5     4        e     d  =
Ef5    4        e     d  =
F5     4        e     d  ]
measure 48
F#5    8        q #   d        (
G5     8        q     d        )
rest   8        q
measure 49
G5     8        q     d
F5     8        q n   d        +
A5     8        q     d
 C5    8        q     d
 F4    8        q     d
measure 50
Bf5    4        e     d
 D5    4        e     d
 F4    4        e     d
Bf4    4        e     d  [
C5     4        e     d  =
D5     4        e     d  =
Ef5    4        e     d  =
F5     4        e     d  ]
measure 51
F#5    8        q #   d        (
G5     8        q     d        )
rest   8        q
measure 52
G5     8        q     d
F5     8        q n   d        +
A5     8        q     d
 C5    8        q     d
 F4    8        q     d
measure 53
Bf5    8        q     d
 D5    8        q     d
 F4    8        q     d
rest   8        q
F4     8        q     u        .
measure 54
Df5    8        q f   d        (
C5     8        q     d        )
F4     8        q     u        .
measure 55
Ef5    8        q     d        (
Df5    8        q f   d        )
F4     8        q     u        .
measure 56
Gf5    8        q f   d        (
F5     8        q     d        )
Bf4    8        q     d        .
measure 57
Df6    8        q f   d        (
C6     8        q     d        )
rest   8        q
measure 58
rest  24
measure 59
rest  24
measure 60
rest  24
measure 61
rest   8        q
rest   8        q
F#5    8        q #   d        (
measure 62
G5     8        q     d
A5     8        q     d
Bf5    8        q     d        )
measure 63
C5     8        q     d
C5     6        e.    d  [     (
D5     2        s     d  =\    )
C5     6        e.    d  =     (
D5     2        s     d  ]\    )
measure 64
C5     8        q     d        (
G5     8        q     d
F5     8        q     d        )
measure 65
gF5    5        s     u
S C1:t25
Ef5    8        q     d
D5     8        q     d
C5     8        q     d
measure 66
Bf4    8        q     d
G5     2        s     d  [/    (p
F5     6        e.    d  ]     )
E5     2        s n   d  [/    (
F5     6        e.    d  ]     )
measure 67
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
E5     2        s n   d  [/    (
F5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
measure 68
E5     2        s n   d  [/    (
F5     6        e.    d  ]     )
Bf5    2        s     d  [/    (
A5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
measure 69
D5     2        s     d  [/    (
Ef5    6        e.f   d  ]     )+
B4     2        s n   d  [/    (
C5     6        e.    d  ]     )
F5     2        s     d  [/    (
Ef5    6        e.    d  ]     )
measure 70
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
E5     2        s n   d  [/    (
F5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
measure 71
E5     2        s n   d  [/    (
F5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
E5     2        s     d  [/    (
F5     6        e.    d  ]     )
measure 72
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
Bf5    2        s     d  [/    (
A5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
measure 73
F#5    2        s #   d  [/    (
G5     6        e.    d  ]     )
F5     2        s n   d  [/    (
Ef5    6        e.f   d  ]     )+
D5     2        s     d  [/    (
C5     6        e.    d  ]     )
measure 74
Bf4    4        e     d
D6     8        q     d        f
D6     8        q     d
D6     4        e     d
measure 75
rest   4        e
C6     8        q     d
C6     8        q     d
C6     4        e     d
measure 76
rest   4        e
Bf5    8        q     d
Bf5    8        q     d
Bf5    4        e     d
measure 77
rest   4        e
Af5    8        q f   d
Af5    8        q     d
Af5    4        e     d
measure 78
rest   4        e
G5     8        q     d
G5     8        q     d
G5     4        e     d
measure 79
rest   4        e
F5     8        q n   d        +
F5     8        q     d
F5     4        e     d
measure 80
Ef5    4        e     d  [
D5     4        e     d  =
C5     4        e     d  =
Bf4    4        e     d  =
A4     4        e     d  =
G4     4        e     d  ]
measure 81
F#4    4        e #   u  [
D5     4        e     u  =
G4     4        e     u  =
D5     4        e     u  =
A4     4        e     u  =
D5     4        e     u  ]
measure 82
Bf4    4        e     d  [
D5     4        e     d  =
A4     4        e     d  =
D5     4        e     d  =
G4     4        e     d  =
D5     4        e     d  ]
measure 83
F#4    4        e #   u  [
D5     4        e     u  =
G4     4        e     u  =
D5     4        e     u  =
A4     4        e     u  =
D5     4        e     u  ]
measure 84
Bf4    4        e     d  [
D5     4        e     d  =
A4     4        e     d  =
D5     4        e     d  =
G4     4        e     d  =
D5     4        e     d  ]
measure 85
F#4    4        e #   u  [
D5     4        e     u  =
G4     4        e     u  =
D5     4        e     u  =
A4     4        e     u  =
D5     4        e     u  ]
measure 86
Bf4    4        e     d  [
D5     4        e     d  =
A4     4        e     d  =
D5     4        e     d  =
G4     4        e     d  =
D5     4        e     d  ]
measure 87
F#4    8        q #   u
F#5    8        q #   u
 A4    8        q     u
 D4    8        q     u
A5     8        q     d
 A4    8        q     d
 D4    8        q     d
measure 88
C6     8        q     d
 A4    8        q     d
 D4    8        q     d
rest   8        q
rest   8        q
mheavy4 89      :|:
G5     8        q     d        (p
D5     8        q     d        )
rest   8        q
measure 90
G5     8        q     d        (
Ef5    8        q     d        )
rest   8        q
measure 91
Af5    8        q f   d        (
G5     8        q     d
B4     8        q n   d        )
measure 92
B4     8        q n   d        (
C5     8        q     d        )
D5     6        e.    d  [     (t
S C33:hn6s17t84
C5     1        t     d  =[[
D5     1        t     d  ]]]   )
measure 93
Ef5    8        q     d        (
E5     8        q n   d
F5     8        q     d        )
measure 94
F#5    4        e #   d  [     (
G5     4        e     d  =     )
F5     4        e n   d  =     (
Ef5    4        e f   d  =     +
D5     4        e     d  =
C5     4        e     d  ]     )
measure 95
F5     8        q     d        (
C5     8        q     d        )
rest   8        q
measure 96
F5     8        q     d        (
D5     8        q     d        )
rest   8        q
measure 97
G5     8        q     d        (
F5     8        q     d        )
A4     8        q     u
measure 98
A4     8        q     u        (
Bf4    8        q f   d        )+
C5     6        e.    d  [     (t
S C33:n6s17t84
Bf4    1        t     d  =[[
C5     1        t     d  ]]]   )
measure 99
C#5    8        q #   d        (
D5     8        q     d
Ef5    8        q     d        )
measure 100
B4     8        q n   d        (
C5     8        q n   d        +
D5     4        e     d  [
A4     4        e     d  ]     )
measure 101
C5     4        e     u  [     (
Bf4    4        e f   u  =     +
A4     4        e     u  =
G4     4        e     u  =
F#4    4        e #   u  =
G4     4        e     u  ]     )
measure 102
A4     8        q     u        (
D4     8        q     u        )
D4     8        q     u        .
measure 103
Ef4   24-       h.    u        -
measure 104
Ef4    8        q     u        (
D4     8        q     u        )
D4     8        q     u        .
measure 105
Ef4   24-       h.    u        -
measure 106
Ef4    8        q     u        (
D4     8        q     u        )
D4     8        q     u        .
measure 107
Ef4   24-       h.    u        -
measure 108
Ef4    8        q     u        (
D4     8        q     u        )
rest   8        q              F
measure 109
G5     8        q     u        f
 Bf4   8        q     u
 D4    8        q     u
 G3    8        q     u
D5     8        q     d
D5     8        q     d
measure 110
D5     6        e.    d  [     (t
S C33:hn6s17t84
C#5    1        t #   d  =[[
D5     1        t     d  ]]]   )
rest   8        q
rest   8        q
measure 111
A5     8        q     d
 A4    8        q     d
 D4    8        q     d
D5     8        q     d
D5     8        q     d
measure 112
D5     6        e.    d  [     (t
S C33:hn6s17t84
C#5    1        t #   d  =[[
D5     1        t     d  ]]]   )
rest   8        q
rest   8        q
measure 113
Bf5    8        q     d        (
A5     8        q     d        )
D5     8        q     d        .
measure 114
G5     8        q     d        (
F5     8        q     d        )
Bf4    8        q     d        .
measure 115
G5     8        q     d        (
F5     8        q     d        )
Bf4    8        q     d        .
measure 116
Ef5    8        q     d        (
D5     8        q     d        )
D5     6        e.    d  [     (
C5     2        s     d  ]\    )
measure 117
Bf4    8        q     d
A4     8        q     u
G4     8        q     u
measure 118
F#4    8        q #   u        (
D5     8        q     d        )
F4     8        q n   u        .
measure 119
E4     8        q n   u        (
C5     8        q     d        )
Ef4    8        q f   u        .
measure 120
D4     8        q     u        .
D5     8        q     d        .
rest   8        q
measure 121
F#5    8        q #   d        (p
G5     8        q     d
D5     8        q     d        )
measure 122
F5     8        q n   d        (+
D5     8        q     d
B4     8        q n   d        )
measure 123
C5     8        q     d        .
Af5    8        q f   d        (
G5     8        q     d
measure 124
F#5    8        q #   d
G5     8        q     d
Bf4    8        q f   d        )+
measure 125
Af4    8        q f   u        (
P C32:o
F5     8        q n   d        +
Ef5    8        q     d
measure 126
D5     8        q     d
Ef5    8        q     d
G4     8        q     u        )
measure 127
F4     8        q     u        (
Df5    8        q f   d
C5     8        q     d
measure 128
B4     8        q n   d
C5     8        q     d        )
G4     8        q     u
measure 129
F#4   24        h.#   u        f
measure 130
C5    24        h.    d
measure 131
B4    24        h.n   d
measure 132
F5    24        h.    d
measure 133
Ef5    8        q     d
G5     2        s     d  [[    (
F5     2        s     d  ==
Ef5    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     u  [[
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]    )
measure 134
F#4   16        h #   u        (
F4     8        q n   u        )
measure 135
Ef4    8        q     u
G5     2        s     d  [[    (
F5     2        s     d  ==
Ef5    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     u  [[
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]    )
measure 136
F#4   16        h #   u        (
F4     8        q n   u        )
measure 137
Ef4    8        q     u
rest   8        q
rest   8        q
measure 138
Af5    8        q f   d        (p
E5     8        q n   d
F5     8        q     d
measure 139
C#5    8        q #   d
D5     8        q     d
F5     8        q     d        )
measure 140
Ef5    8        q f   d        +
rest   4        e
Ef5    4        e     d  [
Ef5    4        e     d  =
Ef5    4        e     d  ]
measure 141
G5     8        q     d        (
Ef5    8        q     d
C5     8        q n   d        )+
measure 142
B4     8        q n   d
rest   4        e
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  ]
measure 143
F5     8        q     d        (
D5     8        q     d
B4     8        q n   d        )
measure 144
C5     4        e     u  [     f
C4     4        e     u  =
C4     4        e     u  =
C4     4        e     u  =
C4     4        e     u  =
C4     4        e     u  ]
measure 145
gD4    5        s     u
S C1:t50
C4     4        e     u  [     (
B3     2        s n   u  =[
C4     2        s     u  ]]    )
B3     8        q     u
rest   8        q
measure 146
rest   4        e
Ef4    4        e     u  [
Ef4    4        e     u  =
Ef4    4        e     u  =
Ef4    4        e     u  =
Ef4    4        e     u  ]
measure 147
gF4    5        s     u
S C1:t50
Ef4    4        e     u  [     (
D4     2        s     u  =[
Ef4    2        s     u  ]]    )
D4     8        q     u
rest   8        q
measure 148
rest   4        e
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 149
gC5    5        s     u
S C1:t50
Bf4    4        e     u  [     (
A4     2        s     u  =[
Bf4    2        s     u  ]]    )
G4     8        q     u
G5     8        q     d
measure 150
F#5    8        q #   d
rest   4        e
C5     4        e     d  [
C5     4        e     d  =
C5     4        e     d  ]
measure 151
F#5    4        e #   d  [
C5     4        e     d  =
A5     4        e n   d  =     +
C5     4        e     d  =
C6     4        e     d  =
C5     4        e     d  ]
measure 152
A5     4        e     d  [
C5     4        e     d  =
F#5    4        e #   d  =
C5     4        e     d  =
C5     4        e     d  =
C5     4        e     d  ]
measure 153
F#5    4        e     d  [     &1^
C5     4        e     d  =
A5     4        e     d  =
C5     4        e     d  =
C6     4        e     d  =
C5     4        e     d  ]
measure 154
A5     4        e     d  [
C5     4        e     d  =
F#5    4        e #   d  =
C5     4        e     d  =
C5     4        e     d  =
C5     4        e     d  ]
measure 155
F#5    4        e #   d  [
C5     4        e     d  =
A5     4        e     d  =
C5     4        e     d  =
C6     4        e     d  =
C5     4        e     d  ]
measure 156
Bf5    4        e     d  [
G4     4        e     d  =
A4     4        e     d  =
Bf4    4        e     d  =
C5     4        e     d  =
D5     4        e     d  ]
measure 157
Ef5    8        q     d        (
D5     8        q     d        )
rest   8        q
measure 158
gD5    5        s     u
S C1:t25
C5     8        q     d        p
Bf4    8        q     d        (
A4     8        q     u        )
measure 159
Bf4    4        e     d  [
Bf5    4        e     d  =     f
G5     4        e     d  =
F5     4        e n   d  =     +
Ef5    4        e     d  =
D5     4        e     d  ]
measure 160
C5     8        q     d        (
Bf4    8        q     d        )
rest   8        q
measure 161
gBf4   5        s     u
S C1:t25
Af4    8        q f   u        p
G4     8        q     u        (
F#4    8        q #   u        )
measure 162
G4     8        q     u
rest   8        q
D4     8        q     u        f
measure 163
F#4    8        q #   u        (
G4     8        q     u        )
D4     8        q     u        .
measure 164
C5     8        q     d        (
Bf4    8        q     d        )
G4     8        q     u        .
measure 165
Ef5    8        q     d        (
D5     8        q     d        )
G4     8        q     u        .
measure 166
Bf5    8        q     d        (
A5     8        q     d        )
rest   8        q
measure 167
rest  24
measure 168
rest  24
measure 169
rest  24
measure 170
rest   8        q
rest   8        q
D5     8        q     d        (
measure 171
Ef5    8        q     d
F#5    8        q #   d
G5     8        q     d        )
measure 172
A4     8-       q     u        -
A4     6        e.    u  [     (
Bf4    2        s     u  =\
A4     6        e.    u  =
Bf4    2        s     u  ]\    )
measure 173
A4     8        q     u        (
Ef5    8        q     d
D5     8        q     d        )
measure 174
gD5    5        s     u
S C1:t25
C5     8        q     d
Bf4    8        q     d
A4     8        q     u
measure 175
G4     8        q     u
Ef5    2        s     d  [/    (p
D5     6        e.    d  ]     )
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
measure 176
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
measure 177
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
measure 178
B4     2        s n   d  [/    (
C5     6        e.n   d  ]     )+
G#4    2        s #   u  [/    (
A4     6        e.    u  ]     )
D5     2        s     d  [/    (
C5     6        e.    d  ]     )
measure 179
A4     2        s     u  [/    (
Bf4    6        e.f   u  ]     )+
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
measure 180
C#5    2        s #   d  [/    (
D5     6        e.    d  ]     )
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
C#5    2        s     d  [/    (
D5     6        e.    d  ]     )
measure 181
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
G5     2        s     d  [/    (
F5     6        e.    d  ]     )
Ef5    2        s     d  [/    (
D5     6        e.    d  ]     )
measure 182
D5     2        s     d  [/    (
Ef5    6        e.    d  ]     )
D5     2        s     d  [/    (
C5     6        e.n   d  ]     )+
Bf4    2        s     u  [/    (
A4     6        e.    u  ]     )
measure 183
G4     4        e     u
Bf5    8        q     d        f
Bf5    8        q     d
Bf5    4        e     d
measure 184
rest   4        e
A5     8        q     d
A5     8        q     d
A5     4        e     d
measure 185
rest   4        e
Af5    8        q f   d
Af5    8        q     d
Af5    4        e     d
measure 186
rest   4        e
G5     8        q     d
G5     8        q     d
G5     4        e     d
measure 187
rest   4        e
F#5    8        q #   d
F#5    8        q     d
F#5    4        e     d
measure 188
rest   4        e
G5     8        q     d
G5     8        q     d
G5     4        e     d
measure 189
Ef5    4        e     d  [
D5     4        e     d  =
C5     4        e     d  =
Bf4    4        e     d  =
A4     4        e     d  =
G4     4        e     d  ]
measure 190
F#4    4        e #   u  [
D5     4        e     u  =
G4     4        e     u  =
D5     4        e     u  =
A4     4        e     u  =
D5     4        e     u  ]
measure 191
Bf4    4        e     d  [
D5     4        e     d  =
A4     4        e     d  =
D5     4        e     d  =
G4     4        e     d  =
D5     4        e     d  ]
measure 192
F#4    4        e #   u  [
D5     4        e     u  =
G4     4        e     u  =
D5     4        e     u  =
A4     4        e     u  =
D5     4        e     u  ]
measure 193
Bf4    4        e     d  [
D5     4        e     d  =
A4     4        e     d  =
D5     4        e     d  ]
G4     4        e     u  [
A4     2        s     u  =[
Bf4    2        s     u  ]]
measure 194
C5     4        e     d  [
D5     4        e     d  ]
Ef5    8        q     d
F#5    8        q #   u
 A4    8        q     u
 D4    8        q     u
measure 195
G5    16        h     u
 Bf4  16        h     u
 D4   16        h     u
rest   8        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/02/02} [KHM:2139995797]
TIMESTAMP: DEC/26/2001 [md5sum:7089b659308d141f4377edf600304cc6]
06/16/94 E. Correia
WK#:159       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violino 2
0 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-2   Q:4   T:3/4  C:4  D:Allegro
Bf4    2        e     u  [     .f
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  ]     .
measure 2
Bf4    2        e     u  [     .
G4     2        e     u  =     .
D4     2        e     u  =     .
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  ]     .
measure 3
C5     2        e     d  [     .
A4     2        e     d  =     .
C5     2        e     d  =     .
A4     2        e     d  =     .
C5     2        e     d  =     .
A4     2        e     d  ]     .
measure 4
C5     2        e     u  [     .
A4     2        e     u  =     .
D4     2        e     u  =     .
A4     2        e     u  =     .
C5     2        e     u  =     .
A4     2        e     u  ]     .
measure 5
Bf4    4        q     d        (
A4     4        q     u        )
D4     4        q     u        .
measure 6
G4     4        q     u        (
F4     4        q     u        )
Bf3    4        q     u        .
measure 7
G4     4        q     u        (
F4     4        q     u        )
Bf3    4        q     u        .
measure 8
Ef4    4        q     u        (
D4     4        q     u        )
D5     3        e.    d  [     &1(
C5     1        s     d  ]\    &1)
measure 9
Bf4    4        q     d
A4     4        q     u
G4     4        q     u
measure 10
F#4    4        q #   u        (
D5     4        q     d        )
F4     4        q n   u        .
measure 11
E4     4        q n   u        (
C5     4        q     d        )
Ef4    4        q f   u        &1.
measure 12
D4     4        q     u        .
D5     4        q     d        .
rest   4        q
measure 13
B3     4        q n   u        (p
P C33:y5
C4     4        q     u
D4     4        q     u        )
measure 14
Ef4    4        q     u        (
C4     4        q     u
A3     4        q     u        )
measure 15
Bf3    4        q f   u        (+
G4     4        q     u
F4     4        q     u
measure 16
E4     4        q n   u
F4     4        q     u
A3     4        q     u        )
measure 17
G3     4        q     u        (
Ef4    4        q f   u        +
D4     4        q     u
measure 18
C#4    4        q #   u
D4     4        q     u        )
rest   4        q
measure 19
rest   4        q
C4     4        q n   u        (+
Bf3    4        q     u
measure 20
A3     4        q     u
Bf3    4        q     u        )
rest   4        q
measure 21
Bf4    2        e     d  [     f
Bf4    2        e     d  =
Bf4    2        e     d  =
Bf4    2        e     d  =
Bf4    2        e     d  =
Bf4    2        e     d  ]
measure 22
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 23
F4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
measure 24
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 25
Bf4    4        q     d
rest   4        q
rest   4        q
measure 26
Bf3    2        e     u
Bf3    4        q     u
Bf3    4        q     u
Bf3    2-       e     u        -
measure 27
Bf3    4        q     u
rest   4        q
rest   4        q
measure 28
Bf3    2        e     u
Bf3    4        q     u
Bf3    4        q     u
Bf3    2-       e     u        -
measure 29
Bf3    4        q     u
rest   4        q
rest   4        q
measure 30
B3     4        q n   u        (p
P C33:y5
C4     4        q     u        )
D4     4        q     u        (
measure 31
Ef4    4        q     u        )
F#4    4        q #   u        (
G4     4        q     u        )
measure 32
D4     4        q     u
rest   2        e
D5     2        e     d  [     .
D5     2        e     d  =     .
D5     2        e     d  ]     .
measure 33
F5     4        q     d        (
D5     4        q     d
B4     4        q n   d        )
measure 34
C5     4        q     d
rest   2        e
A4     2        e     u  [     .
A4     2        e     u  =     .
A4     2        e     u  ]     .
measure 35
C5     4        q     d        (
Ef4    4        q     u
C4     4        q     u        )
measure 36
D4     4        q     u
rest   4        q
rest   4        q
measure 37
rest   2        e
C4     2        e     u  [     f
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 38
gD4    5        s     u
S C1:t50
C4     2        e     u  [     (
Bf3    1        s     u  =[
C4     1        s     u  ]]    )
Bf3    4        q     u
rest   4        q
measure 39
rest   2        e
Ef4    2        e     u  [
Ef4    2        e     u  =
Ef4    2        e     u  =
Ef4    2        e     u  =
Ef4    2        e     u  ]
measure 40
gF4    5        s     u
S C1:t50
Ef4    2        e     u  [     (
D4     1        s     u  =[
Ef4    1        s     u  ]]    )
D4     4        q     u
rest   4        q
measure 41
rest   2        e
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 42
F4     4        q     u
rest   2        e
F4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  ]
measure 43
A4     2        e     u  [
F4     2        e     u  =
C5     2        e     u  =
F4     2        e     u  =
Ef5    2        e     u  =
F4     2        e     u  ]
measure 44
C5     2        e     u  [
F4     2        e     u  =
A4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
measure 45
A4     2        e     u  [
F4     2        e     u  =
C5     2        e     u  =
F4     2        e     u  =
Ef5    2        e     u  =
F4     2        e     u  ]
measure 46
C5     2        e     u  [
F4     2        e     u  =
A4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
measure 47
F5     4        q     d
rest   4        q
rest   4        q
measure 48
C5     4        q     d        (
Bf4    4        q     d        )
rest   4        q
measure 49
Ef5    4        q     d
D5     4        q     d
C5     4        q     u
 F4    4        q     u
measure 50
Bf4    4        q     u
 D4    4        q     u
rest   4        q
rest   4        q
measure 51
C5     4        q     d        (
Bf4    4        q     d        )
rest   4        q
measure 52
Ef5    4        q     d
D5     4        q     d
C5     4        q     u
 F4    4        q     u
measure 53
Bf4    4        q     u
 D4    4        q     u
rest   4        q
F4     4        q     u        .
measure 54
Bf4    4        q     d        (
A4     4        q     u        )
F4     4        q     u        .
measure 55
C5     4        q     d        (
Bf4    4        q     d        )
F4     4        q     u        .
measure 56
Ef5    4        q     d        (
Df5    4        q f   d        )
Bf4    4        q     d        .
measure 57
Bf5    4        q     d        (
A5     4        q     d        )
F#4    4        q #   u        (
P C32:u
measure 58
G4     4        q     u
A4     4        q     u
Bf4    4        q     d        )
measure 59
C4     4        q     u
C4     3        e.    u  [     (
D4     1        s     u  =\    )
C4     3        e.    u  =     (
D4     1        s     u  ]\    )
measure 60
C4     4        q     u        (
G4     4        q     u
F4     4        q     u        )
measure 61
gF4    5        s     u
S C1:t25
Ef4    4        q     u        (
D4     4        q     u
C4     4        q     u        )
measure 62
Bf3    4        q     u        (
Ef4    4        q     u
D4     4        q     u        )
measure 63
Bf4    2        e     u  [     (
G4     2        e     u  =
Bf4    2        e     u  =
G4     2        e     u  =
Bf4    2        e     u  =
G4     2        e     u  ]     )
measure 64
F4     4        q     u        (
Ef5    4        q     d
D5     4        q     d        )
measure 65
gD5    5        s     u
S C1:t25
C5     4        q     d
Bf4    4        q     d
A4     4        q     u
measure 66
Bf4    4        q     d
G4     1        s     u  [/    (p
P C33:y5
F4     3        e.    u  ]     )
E4     1        s n   u  [/    (
F4     3        e.    u  ]     )
measure 67
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
E4     1        s n   u  [/    (
F4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
measure 68
E4     1        s n   u  [/    (
F4     3        e.    u  ]     )
Bf4    1        s     u  [/    (
A4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
measure 69
D4     1        s     u  [/    (
Ef4    3        e.f   u  ]     )+
B3     1        s n   u  [/    (
C4     3        e.    u  ]     )
F4     1        s     u  [/    (
Ef4    3        e.    u  ]     )
measure 70
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
E4     1        s n   u  [/    (
F4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
measure 71
E4     1        s n   u  [/    (
F4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
E4     1        s     u  [/    (
F4     3        e.    u  ]     )
measure 72
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
Bf4    1        s     u  [/    (
A4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
measure 73
F#4    1        s #   u  [/    (
G4     3        e.    u  ]     )
F4     1        s n   u  [/    (
Ef4    3        e.f   u  ]     )+
D4     1        s     u  [/    (
C4     3        e.    u  ]     )
measure 74
Bf3    2        e     u
Bf5    4        q     d        f
Bf5    4        q     d
Bf5    2        e     d
measure 75
rest   2        e
A5     4        q     d
A5     4        q     d
A5     2        e     d
measure 76
rest   2        e
G5     4        q     d
G5     4        q     d
G5     2        e     d
measure 77
rest   2        e
F5     4        q     d
F5     4        q     d
F5     2        e     d
measure 78
rest   2        e
Ef5    4        q     d
Ef5    4        q     d
Ef5    2        e     d
measure 79
rest   2        e
D5     4        q     d
D5     4        q     d
D5     2        e     d
measure 80
Ef5    2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  =
G4     2        e     d  ]
measure 81
D4     4        q     u
D5     4        q     d
D5     4        q     d
measure 82
D5     4        q     d        (
F#5    4        q #   d
G5     4        q     d        )
measure 83
D4     4        q     u
D5     4        q     d
D5     4        q     d
measure 84
D5     4        q     d        (
F#5    4        q #   d
G5     4        q     d        )
measure 85
F#4    2        e #   u  [
D5     2        e     u  =
G4     2        e     u  =
D5     2        e     u  =
A4     2        e     u  =
D5     2        e     u  ]
measure 86
Bf4    2        e     d  [
D5     2        e     d  =
A4     2        e     d  =
D5     2        e     d  =
G4     2        e     d  =
D5     2        e     d  ]
measure 87
F#4    4        q #   u
D5     4        q     u
 D4    4        q     u
F#5    4        q #   u
 A4    4        q     u
 D4    4        q     u
measure 88
A5     4        q     d
 A4    4        q     d
 D4    4        q     d
rest   4        q
rest   4        q
mheavy4 89      :|:
D5     4        q     d        (p
G4     4        q     u        )
rest   4        q
measure 90
Ef5    4        q     d        (
C5     4        q     d        )
rest   4        q
measure 91
C4     4        q     u        (
B3     4        q n   u
D4     4        q     u        )
measure 92
F4     4        q n   u        (+
Ef4    4        q     u        )
rest   4        q
measure 93
rest  12
measure 94
rest  12
measure 95
C5     4        q     d        (
F4     4        q     u        )
rest   4        q
measure 96
D5     4        q     d        (
Bf4    4        q     d        )
rest   4        q
measure 97
Bf3    4        q f   u        (+
A3     4        q     u
C4     4        q     u        )
measure 98
Ef4    4        q     u        (
D4     4        q     u        )
F4     4        q     u        .
measure 99
F4     8        h     u
Bf4    4        q     d
measure 100
Ef4    8        h     u
A4     2        e     u  [     (
F#4    2        e #   u  ]     )
measure 101
D4     4        q     u
rest   4        q
rest   4        q
measure 102
F#4    8        h #   u        (
A3     4        q     u
measure 103
Bf3    4        q     u
C4     4        q     u
Bf3    4        q     u        )
measure 104
A3    12        h.    u
measure 105
Bf3    4        q     u        (
C4     4        q     u
Bf3    4        q     u        )
measure 106
A3    12        h.    u
measure 107
Bf3    4        q     u        (
C4     4        q     u
Bf3    4        q     u        )
measure 108
A3     8        h     u
rest   4        q              F
measure 109
Bf4    2        e     u  [     .f
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  ]     .
measure 110
Bf4    2        e     u  [     .
G4     2        e     u  =     .
D4     2        e     u  =     .
G4     2        e     u  =     .
Bf4    2        e     u  =     .
G4     2        e     u  ]     .
measure 111
C5     2        e     d  [     .
A4     2        e     d  =     .
C5     2        e     d  =     .
A4     2        e     d  =     .
C5     2        e     d  =     .
A4     2        e     d  ]     .
measure 112
C5     2        e     u  [     .
A4     2        e     u  =     .
D4     2        e     u  =     .
A4     2        e     u  =     .
C5     2        e     u  =     .
A4     2        e     u  ]     .
measure 113
Bf4    4        q     d        (
A4     4        q     u        )
D4     4        q     u        .
measure 114
G4     4        q     u        (
F4     4        q n   u        )+
Bf3    4        q     u        .
measure 115
G4     4        q     u        (
F4     4        q     u        )
Bf3    4        q     u        .
measure 116
Ef4    4        q     u        (
D4     4        q     u        )
D5     3        e.    d  [     (
C5     1        s     d  ]\    )
measure 117
Bf4    4        q     d
A4     4        q     u
G4     4        q     u
measure 118
F#4    4        q #   u        (
D5     4        q     d        )
F4     4        q n   u        .
measure 119
E4     4        q n   u        (
C5     4        q     d        )
Ef4    4        q f   u        .
measure 120
D4     4        q     u        .
D5     4        q     d        .
rest   4        q
measure 121
F#4    4        q #   u        (p
P C33:y10
G4     4        q     u
D4     4        q     u        )
measure 122
F4     4        q n   u        (+
D4     4        q     u
B3     4        q n   u        )
measure 123
C4     4        q     u        .
Af4    4        q f   u        (
G4     4        q     u
measure 124
F#4    4        q #   u
G4     4        q     u
Bf3    4        q f   u        )+
measure 125
Af3    4        q f   u        (
F4     4        q n   u        +
Ef4    4        q     u
measure 126
D4     4        q     u
Ef4    4        q     u        )
rest   4        q
measure 127
rest   4        q
Df4    4        q f   u        (
C4     4        q     u
measure 128
B3     4        q n   u
C4     4        q     u        )
rest   4        q
measure 129
C4     2        e     u  [     f
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 130
A4     2        e n   u  [     +
A4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  ]
measure 131
D4     2        e n   u  [     +
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 132
B4     2        e n   d  [
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  =
B4     2        e     d  ]
measure 133
C5     4        q     d
rest   4        q
rest   4        q
measure 134
Ef4    8        h     u        (
D4     4        q     u        )
measure 135
C4     4        q     u
rest   4        q
rest   4        q
measure 136
Ef4    8        h     u        (
D4     4        q     u        )
measure 137
C4     4        q     u
rest   4        q
rest   4        q
measure 138
Af4    4        q f   u        (p
P C33:y5
E4     4        q n   u
F4     4        q     u
measure 139
C#4    4        q #   u
D4     4        q     u
F4     4        q     u        )
measure 140
Ef4    4        q f   u        +
rest   2        e
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  ]
measure 141
Ef5    4        q     d        (
C5     4        q     d
Ef4    4        q     u        )
measure 142
D4     4        q     u
rest   2        e
B4     2        e n   d  [
B4     2        e     d  =
B4     2        e     d  ]
measure 143
D5     4        q     d        (
F4     4        q     u
D4     4        q     u        )
measure 144
Ef4    4        q     u        f
rest   4        q
rest   4        q
measure 145
rest   2        e
D4     2        e     u  [
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  =
D4     2        e     u  ]
measure 146
gEf4   5        s     u
S C1:t50
D4     2        e     u  [     (
C4     1        s     u  =[
D4     1        s     u  ]]    )
C4     4        q     u
rest   4        q
measure 147
rest   2        e
F4     2        e     u  [
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  =
F4     2        e     u  ]
measure 148
gG4    5        s     u
S C1:t50
F4     2        e     u  [     (
Ef4    1        s     u  =[
F4     1        s     u  ]]    )
Ef4    4        q     u
rest   4        q
measure 149
rest   2        e
C#5    2        e #   d  [
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  =
C#5    2        e     d  ]
measure 150
gEf5   5        s     u
S C1:t50
D5     2        e     d  [     (
C#5    1        s     d  =[    &0^
D5     1        s     d  ]]    )
A4     2        e n   u  [     +
A4     2        e     u  =
A4     2        e     u  =
A4     2        e     u  ]
measure 151
A4     4        q     u
rest   2        e
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  ]
measure 152
F#4    2        e #   u  [
C4     2        e     u  =
A4     2        e     u  =
C4     2        e     u  =
C5     2        e     u  =
C4     2        e     u  ]
measure 153
A4     2        e     u  [
C4     2        e     u  =
F#4    2        e #   u  =
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 154
F#4    2        e #   u  [
C4     2        e     u  =
A4     2        e     u  =
C4     2        e     u  =
C5     2        e     u  =
C4     2        e     u  ]
measure 155
A4     2        e     u  [
C4     2        e     u  =
F#4    2        e #   u  =
C4     2        e     u  =
C4     2        e     u  =     (
D4     2        e     u  ]     )
measure 156
D4     4        q     u
rest   4        q
rest   4        q
measure 157
C5     4        q     d        (
Bf4    4        q     d        )
rest   4        q
measure 158
gBf4   5        s     u
S C1:t25
A4     4        q     u        p
G4     4        q     u        (
F#4    4        q #   u        )
measure 159
G4     4        q     u
rest   4        q
rest   4        q
measure 160
A4     4        q     u        (f
P C33:y10
G4     4        q     u        )
rest   4        q
measure 161
Ef4    4        q     u        (p
P C33:y10
D4     4        q     u
C4     4        q     u        )
measure 162
Bf3    4        q     u
rest   4        q
rest   4        q
measure 163
Ef4    4        q     u        (f
P C33:y15
D4     4        q     u        )
rest   4        q
measure 164
A4     4        q     u        (
G4     4        q     u        )
rest   4        q
measure 165
A4     4        q     u        (
Bf4    4        q     d        )
rest   4        q
measure 166
G5     4        q     d        (
F#5    4        q #   d        )
D4     4        q     u
measure 167
Ef4    4        q     u        (
F#4    4        q #   u
G4     4        q     u        )
measure 168
A3     4-       q     u        -
A3     3        e.    u  [     (
Bf3    1        s     u  =\
A3     3        e.    u  =
Bf3    1        s     u  ]\    )
measure 169
A3     4        q     u        (
Ef4    4        q     u
D4     4        q     u        )
measure 170
gD4    5        s     u
S C1:t25
C4     4        q     u        (
Bf3    4        q     u
Af3    4        q f   u        )
measure 171
G3     4        q     u        (
C4     4        q     u
Bf3    4        q     u        )
measure 172
G4     2        e     u  [     (
E4     2        e n   u  =
G4     2        e     u  =
E4     2        e     u  =
G4     2        e     u  =
E4     2        e     u  ]     )
measure 173
D4     4        q     u
C5     4        q     d        (
Bf4    4        q     d        )
measure 174
gBf4   5        s     u
S C1:t25
A4     4        q     u
G4     4        q     u
F#4    4        q #   u
measure 175
G4     4        q     u
Ef4    1        s f   u  [/    (p+
P C33:y10
D4     3        e.    u  ]     )
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
measure 176
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
measure 177
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
measure 178
B3     1        s n   u  [/    (
C4     3        e.n   u  ]     )+
G#3    1        s #   u  [/    (
A3     3        e.    u  ]     )
D4     1        s     u  [/    (
C4     3        e.    u  ]     )
measure 179
A3     1        s     u  [/    (
Bf3    3        e.f   u  ]     )+
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
measure 180
C#4    1        s #   u  [/    (
D4     3        e.    u  ]     )
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
C#4    1        s     u  [/    (
D4     3        e.    u  ]     )
measure 181
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
G4     1        s     u  [/    (
F4     3        e.    u  ]     )
Ef4    1        s     u  [/    (
D4     3        e.    u  ]     )
measure 182
D4     1        s     u  [/    (
Ef4    3        e.    u  ]     )
D4     1        s     u  [/    (
C4     3        e.n   u  ]     )+
Bf3    1        s     u  [/    (
A3     3        e.    u  ]     )
measure 183
G3     2        e     u
G5     4        q     d        f
G5     4        q     d
G5     2        e     d
measure 184
rest   2        e
F#5    4        q #   d
F#5    4        q     d
F#5    2        e     d
measure 185
rest   2        e
F5     4        q n   d        +
F5     4        q     d
F5     2        e     d
measure 186
rest   2        e
E5     4        q n   d
E5     4        q     d
E5     2        e     d
measure 187
rest   2        e
Ef5    4        q f   d        +
Ef5    4        q     d
Ef5    2        e     d
measure 188
rest   2        e
D5     4        q     d
D5     4        q     d
D5     2        e     d
measure 189
Ef5    2        e     d  [
D5     2        e     d  =
C5     2        e     d  =
Bf4    2        e     d  =
A4     2        e     d  =
G4     2        e     d  ]
measure 190
D4     4        q     u
D5     4        q     d
D5     4        q     d
measure 191
D5     4        q     d        (
F#5    4        q #   d
G5     4        q     d        )
measure 192
F#4    2        e #   u  [
D5     2        e     u  =
G4     2        e     u  =
D5     2        e     u  =
A4     2        e     u  =
D5     2        e     u  ]
measure 193
Bf4    2        e     d  [
D5     2        e     d  =
A4     2        e     d  =
D5     2        e     d  ]
G4     2        e     u  [
A4     1        s     u  =[
Bf4    1        s     u  ]]
measure 194
C5     2        e     d  [
D5     2        e     d  ]
Ef5    4        q     d
F#5    4        q #   u
 A4    4        q     u
 D4    4        q     u
measure 195
G5     8        h     u
 Bf4   8        h     u
 D4    8        h     u
rest   4        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/02/03} [KHM:2139995797]
TIMESTAMP: DEC/26/2001 [md5sum:f7054f005bd433b2cd88ce4abf3fb241]
06/16/94 E. Correia
WK#:159       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Viola
0 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-2   Q:4   T:3/4  C:13  D:Allegro
G3     2        e     u  [     .f
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  ]     .
measure 2
D4     2        e     u  [     .
Bf3    2        e     u  =     .
G3     2        e     u  =     .
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  ]     .
measure 3
A3     2        e     d  [     .
F#4    2        e #   d  =     .
A4     2        e     d  =     .
F#4    2        e     d  =     .
A4     2        e     d  =     .
F#4    2        e     d  ]     .
measure 4
A4     2        e     d  [     .
F#4    2        e #   d  =     .
A3     2        e     d  =     .
D4     2        e     d  =     .
A4     2        e     d  =     .
F#4    2        e     d  ]     .
measure 5
D4     8        h     d
rest   4        q
measure 6
Bf3    8        h     u
rest   4        q
measure 7
Bf3    8        h     u
rest   4        q
measure 8
G3     8        h     u
D4     3        e.    d  [     (
C4     1        s     d  ]\    )
measure 9
Bf3    4        q     u
A3     4        q     u
G3     4        q     u
measure 10
F#3    4        q #   u        (
D4     4        q     d        )
F3     4        q n   u        .
measure 11
E3     4        q n   u        (
C4     4        q     d        )
Ef3    4        q f   u        .
measure 12
D3     4        q     u        .
D4     4        q     d        .
rest   4        q
measure 13
rest  12
measure 14
rest  12
measure 15
rest   4        q
D4     4        q     d        (p
C4     4        q     d
measure 16
Bf3    4        q     u
C4     4        q     d        )
rest   4        q
measure 17
rest   4        q
Bf3    4        q     u        (
A3     4        q     u
measure 18
G3     4        q     u
A3     4        q     u        )
F3     4        q     u        (
measure 19
Ef3    4        q     u
G3     4        q     u
F3     4        q     u
measure 20
Ef3    4        q     u
F3     4        q     u        )
rest   4        q
measure 21
G4     2        e     d  [     f
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 22
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 23
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 24
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 25
F4     4        q     d
rest   4        q
rest   4        q
measure 26
Af3    8        h f   u        (
F#3    4        q #   u        )
measure 27
G3     4        q     u        .
rest   4        q
rest   4        q
measure 28
Af3    8        h f   u        (
F#3    4        q #   u        )
measure 29
G3     4        q     u
rest   4        q
rest   4        q
measure 30
rest  12
measure 31
rest  12
measure 32
F3     2        e n   u  [     p+
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  ]
measure 33
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  ]
measure 34
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  ]
measure 35
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  =
F3     2        e     u  ]
measure 36
Bf3    4        q     u
rest   4        q
rest   4        q
measure 37
F3     4        q     u        f
A3     4        q     u
F3     4        q     u
measure 38
Bf3    4        q     u
Bf3    4        q     u
rest   4        q
measure 39
A3     8        h     u
C4     4        q     d
measure 40
gD4    5        s     u
S C1:t50
C4     2        e     d  [     (
Bf3    1        s     d  =[
C4     1        s     d  ]]    )
Bf3    4        q     u
Bf4    4-       q     d        -
measure 41
Bf4    4        q     d
rest   2        e
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  ]
measure 42
C4     4        q     d
rest   4        q
rest   4        q
measure 43
F3     4        q     u
A3     4        q     u
C4     4        q     d
measure 44
A3     4        q     u
F3     4        q     u
rest   4        q
measure 45
F4     4        q     d
A4     4        q     d
C5     4        q     d
measure 46
A4     4        q     d
F4     4        q     d
A4     4        q     d
measure 47
Bf4    4        q     d
rest   4        q
rest   4        q
measure 48
A4     4        q     d        (
G4     4        q     d        )
rest   4        q
measure 49
Bf4    4        q     d
Bf3    4        q     u
Ef4    4        q     d
measure 50
D4     4        q     d
rest   4        q
rest   4        q
measure 51
A4     4        q     d        (
G4     4        q     d        )
rest   4        q
measure 52
Bf4    4        q     d
Bf3    4        q     u
Ef4    4        q     d
measure 53
D4     4        q     d
rest   4        q
rest   4        q
measure 54
F4     8        h     d
rest   4        q
measure 55
F4     8        h     d
rest   4        q
measure 56
A4     4        q     d        (
Bf4    4        q     d        )
rest   4        q
measure 57
E4     4        q n   d        (
F4     4        q     d        )
rest   4        q
measure 58
rest  12
measure 59
Bf3    2        e     u  [     (
G3     2        e     u  =
Bf3    2        e     u  =
G3     2        e     u  =
Bf3    2        e     u  =
G3     2        e     u  ]     )
measure 60
A3     4        q     u        (
Ef4    4        q f   d        +
D4     4        q     d        )
measure 61
gD4    5        s     u
S C1:t25
C4     4        q     d        (
Bf3    4        q     u
A3     4        q     u        )
measure 62
G3     4        q     u        (
P C32:o
C4     4        q     d
Bf3    4        q     u        )
measure 63
G4     2        e     d  [     (
E4     2        e n   d  =
G4     2        e     d  =
E4     2        e     d  =
G4     2        e     d  =
Bf3    2        e     d  ]     )
measure 64
A3     4        q     u        (
C4     4        q     d
D4     4        q     d        )
measure 65
G4     4        q     d
F4     4        q     d
Ef4    4        q f   d        +
measure 66
D4     4        q     d        .
rest   4        q
D4     4        q     d        .p
measure 67
C4     4        q     d        .
rest   4        q
Ef4    4        q     d        .
measure 68
D4     4        q     d        .
rest   4        q
Bf3    4        q     u        .
measure 69
G3     8        h     u        (
A3     4        q     u        )
measure 70
A3     1        s     u  [/    (
Bf3    3        e.    u  ]     )
rest   4        q
D4     4        q     d        .
measure 71
C4     4        q     d        .
rest   4        q
Ef4    4        q     d        .
measure 72
D4     4        q     d
G4     1        s     d  [/    (
F4     3        e.    d  ]     )
Ef4    1        s     d  [/    (
D4     3        e.    d  ]     )
measure 73
D4     1        s     d  [/    (
Ef4    3        e.    d  ]     )
D4     1        s     d  [/    (
C4     3        e.    d  ]     )
Bf3    1        s     u  [/    (
A3     3        e.    u  ]     )
measure 74
Bf3    1        s     d  [[    (f
C4     1        s     d  ==
D4     1        s     d  ==
Ef4    1        s     d  ]]    )
F4     4        q     d        .
rest   4        q
measure 75
A4     1        s     d  [[    (
G4     1        s     d  ==
F4     1        s     d  ==
Ef4    1        s     d  ]]    )
D4     4        q     d        .
rest   4        q
measure 76
G3     1        s     u  [[    (
A3     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]    )
D4     4        q     d        .
rest   4        q
measure 77
F4     1        s     d  [[    (
Ef4    1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]    )
Bf3    4        q     u        .
rest   4        q
measure 78
Ef4    1        s     d  [[    (
F4     1        s     d  ==
G4     1        s     d  ==
A4     1        s     d  ]]    )
Bf4    4        q     d        .
rest   4        q
measure 79
D4     1        s     u  [[    (
C4     1        s     u  ==
B3     1        s n   u  ==
A3     1        s     u  ]]    )
G3     4        q     u        .
rest   4        q
measure 80
G4     2        e     d  [
F4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  =
C4     2        e     d  =
Bf3    2        e f   d  ]     +
measure 81
A3     4        q     u        (
Bf3    4        q     u
C4     4        q     d
measure 82
D4     4        q     d
C4     4        q     d
Bf3    4        q     u        )
measure 83
A3     4        q     u        (
Bf3    4        q     u
C4     4        q     d
measure 84
D4     4        q     d
C4     4        q     d
Bf3    4        q     u        )
measure 85
F#4    4        q #   d        .
G4     4        q     d        .
A4     4        q     d        .
measure 86
Bf4    4        q     d        .
A4     4        q     d        .
G4     4        q     d        .
measure 87
F#4    4        q #   d
C5     4        q     d
A4     4        q     d
measure 88
F#4    4        q #   d
rest   4        q
rest   4        q
mheavy4 89      :|:
rest   4        q
D4     4        q     d        (p
B3     4        q n   u        )
measure 90
rest   4        q
G4     4        q     d        (
Ef4    4        q     d        )
measure 91
D4     8        h     d        (
F4     4        q f   d        )+
measure 92
D4     4        q     d        (
C4     4        q     d        )
rest   4        q
measure 93
rest  12
measure 94
rest  12
measure 95
rest   4        q
C4     4        q     d        (
A3     4        q     u        )
measure 96
rest   4        q
F4     4        q     d        (
D4     4        q     d        )
measure 97
C4     8        h     d        (
Ef4    4        q     d        )
measure 98
C4     4        q     d        (
Bf3    4        q     u        )
A3     4        q     u
measure 99
Bf3   12        h.    u
measure 100
A3    12        h.    u
measure 101
G3     4        q     u
rest   4        q
rest   4        q
measure 102
rest   4        q
A3     4        q     u
D4     4-       q     d        -
measure 103
D4     4        q     d
C4     4        q     d
C4     4        q     d
measure 104
C4     4        q     d        (
A3     4        q     u        )
D4     4-       q     d        -
measure 105
D4     4        q     d
C4     4        q     d
C4     4        q     d
measure 106
C4     4        q     d        (
A3     4        q     u        )
D4     4-       q     d        -
measure 107
D4     4        q     d
C4     4        q     d
C4     4        q     d
measure 108
C4     8        h     d
rest   4        q              F
measure 109
G3     2        e     u  [     .f
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  ]     .
measure 110
D4     2        e     u  [     .
Bf3    2        e     u  =     .
G3     2        e     u  =     .
Bf3    2        e     u  =     .
D4     2        e     u  =     .
Bf3    2        e     u  ]     .
measure 111
A3     2        e     d  [     .
F#4    2        e #   d  =     .
A4     2        e     d  =     .
F#4    2        e     d  =     .
A4     2        e     d  =     .
F#4    2        e     d  ]     .
measure 112
A4     2        e     d  [     .
F#4    2        e #   d  =     .
A3     2        e     d  =     .
D4     2        e     d  =     .
A4     2        e     d  =     .
F#4    2        e     d  ]     .
measure 113
D4     8        h     d
rest   4        q
measure 114
Bf3    8        h     u
rest   4        q
measure 115
Bf3    8        h     u
rest   4        q
measure 116
G3     8        h     u
D4     3        e.    d  [     (
C4     1        s     d  ]\    )
measure 117
Bf3    4        q     u
A3     4        q     u
G3     4        q     u
measure 118
F#3    4        q #   u        (
D4     4        q     d        )
F3     4        q n   u        .
measure 119
E3     4        q n   u        (
C4     4        q     d        )
Ef3    4        q f   u        .
measure 120
D3     4        q     u        .
D4     4        q     d        .
rest   4        q
measure 121
rest  12
measure 122
rest  12
measure 123
rest   4        q
Ef4    4        q     d        (p
D4     4        q     d
measure 124
C4     4        q     d
D4     4        q     d        )
rest   4        q
measure 125
rest   4        q
C4     4        q     d        (
P C32:u
Bf3    4        q     u
measure 126
Af3    4        q f   u
Bf3    4        q     u        )
G3     4        q     u        (
measure 127
F3     4        q     u
Af3    4        q f   u
G3     4        q     u
measure 128
F3     4        q     u
G3     4        q     u        )
rest   4        q
measure 129
A3     2        e n   u  [     f+
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 130
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 131
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 132
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 133
C4     4        q     d
rest   4        q
rest   4        q
measure 134
C4     8        h     d        (
Af3    4        q f   u        )
measure 135
G3     4        q     u
rest   4        q
rest   4        q
measure 136
C4     8        h     d        (
Af3    4        q f   u        )
measure 137
G3     4        q     u
rest   4        q
rest   4        q
measure 138
rest  12
measure 139
rest  12
measure 140
G3     2        e     u  [     p
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 141
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 142
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 143
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 144
G3     4        q     u        f
rest   4        q
rest   4        q
measure 145
G3     4        q     u
B3     4        q n   u
G3     4        q     u
measure 146
C4     4        q     d
C3     4        q     u
rest   4        q
measure 147
F3     8        h     u
B3     4        q n   u
measure 148
B3     4        q n   u        (
C4     4        q     d        )
Ef4    4        q     d        .
measure 149
G4     4        q     d
Bf3    4        q f   u        +
Bf3    2        e     u  [     (
G3     2        e     u  ]     )
measure 150
A3     4        q n   u        +
F#4    2        e #   d  [
F#4    2        e     d  =
F#4    2        e     d  =
F#4    2        e     d  ]
measure 151
C4     4        q     d
rest   4        q
rest   4        q
measure 152
D3     4        q     u
F#3    4        q #   u
A3     4        q     u
measure 153
F#3    4        q #   u
D3     4        q     u
rest   4        q
measure 154
D4     4        q     d
F#4    4        q #   d
A4     4        q     d
measure 155
F#4    4        q #   d
D4     4        q     d
F#4    4        q     d
measure 156
G4     4        q     d
rest   4        q
rest   4        q
measure 157
A4     4        q     d        (
D4     4        q     d        )
rest   4        q
measure 158
Ef4    4        q     d        (p
D4     4        q     d
C4     4        q     d        )
measure 159
Bf3    4        q     u
rest   4        q
rest   4        q
measure 160
F#4    4        q #   d        (f
G4     4        q     d        )
rest   4        q
measure 161
C4     4        q     d        (p
P C32:u
Bf3    4        q     u
A3     4        q     u        )
measure 162
G3     4        q     u
rest   4        q
rest   4        q
measure 163
C4     4        q     d        (f
P C33:y5
D4     4        q     d        )
rest   4        q
measure 164
Ef4    4        q     d        (
D4     4        q     d        )
rest   4        q
measure 165
F#4    4        q #   d        (
G4     4        q     d        )
rest   4        q
measure 166
E4     4        q n   d        (
F#4    4        q #   d        )
rest   4        q
measure 167
rest  12
measure 168
G3     2        e     u  [     (
E3     2        e n   u  =
G3     2        e     u  =
E3     2        e     u  =
G3     2        e     u  =
E3     2        e     u  ]     )
measure 169
F#3    4        q #   u        (
C4     4        q     d
Bf3    4        q     u        )
measure 170
gBf3   5        s     u
S C1:t25
A3     4        q     u        (
G3     4        q     u
F3     4        q n   u        )+
measure 171
Ef3    4        q     u        (
A3     4        q     u
G3     4        q     u        )
measure 172
E4     2        e n   d  [     (
C#4    2        e #   d  =
E4     2        e     d  =
C#4    2        e     d  =
E4     2        e     d  =
G3     2        e     d  ]     )
measure 173
F#3    4        q #   u        (
A3     4        q     u
Bf3    4        q     u        )
measure 174
Ef4    4        q f   d        +
D4     4        q     d
C4     4        q n   d        +
measure 175
Bf3    4        q     u        .
rest   4        q
Bf3    4        q     u        .p
measure 176
A3     4        q     u        .
rest   4        q
C4     4        q     d        .
measure 177
Bf3    4        q     u        .
rest   4        q
G3     4-       q     u        -
measure 178
G3     4        q     u
F#3    4        q #   u
A3     4        q     u
measure 179
F#3    1        s #   u  [/    (
G3     3        e.    u  ]     )
rest   4        q
Bf3    4        q     u        .
measure 180
A3     4        q     u        .
rest   4        q
C4     4        q     d        .
measure 181
Bf3    4        q     u        .
rest   4        q
G3     4        q     u
measure 182
B3     1        s n   u  [/    (
C4     3        e.    u  ]     )
Bf3    1        s f   u  [/    (
A3     3        e.    u  ]     )
G3     1        s     u  [/    (
F#3    3        e.#   u  ]     )
measure 183
G3     1        s     u  [[    (f
P C33:y10
A3     1        s     u  ==
Bf3    1        s     u  ==
C4     1        s     u  ]]    )
D4     4        q     d        .
rest   4        q
measure 184
A4     1        s     d  [[    (
G4     1        s     d  ==
F#4    1        s #   d  ==
E4     1        s n   d  ]]    )
D4     4        q     d        .
rest   4        q
measure 185
D4     1        s     d  [[    (
Ef4    1        s f   d  ==    +
F4     1        s n   d  ==    +
Ef4    1        s     d  ]]    )
D4     4        q     d        .
rest   4        q
measure 186
C4     1        s     d  [[    (
D4     1        s     d  ==
E4     1        s n   d  ==
D4     1        s     d  ]]    )
C4     4        q     d        .
rest   4        q
measure 187
C4     1        s     d  [[    (
D4     1        s     d  ==
Ef4    1        s f   d  ==    +
D4     1        s     d  ]]    )
C4     4        q     d        .
rest   4        q
measure 188
Bf3    1        s     d  [[    (
C4     1        s     d  ==
D4     1        s     d  ==
C4     1        s     d  ]]    )
Bf3    4        q     u        .
rest   4        q
measure 189
G4     2        e     d  [
F4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  =
C4     2        e     d  =
Bf3    2        e     d  ]
measure 190
A3     4        q     u        (
Bf3    4        q     u
C4     4        q     d        )
measure 191
D4     4        q     d        (
C4     4        q     d
Bf3    4        q     u        )
measure 192
F#4    4        q #   d        .
G4     4        q     d        .
A4     4        q     d        .
measure 193
Bf4    4        q     d        .
A4     4        q     d        .
Bf4    2        e     d  [     .
A4     2        e     d  ]     .
measure 194
G4     2        e     d  [     .
F4     2        e n   d  =     .+
Ef4    2        e     d  =     .
C4     2        e     d  =     .
A3     2        e     d  =     .
D4     2        e     d  ]     .
measure 195
D4     8        h     d
 Bf3   8        h     d
rest   4        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k159/stage2/02/04} [KHM:2139995797]
TIMESTAMP: DEC/26/2001 [md5sum:da72ac894a1537de3fb8463d678eec69]
06/16/94 E. Correia
WK#:159       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 6 for 2 violins, viola, and violoncello

Violoncello
0 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-2   Q:4   T:3/4  C:22  D:Allegro
G2     4        q     u        f
rest   4        q
rest   4        q
measure 2
G2     4        q     u
Bf2    4        q     u
G2     4        q     u
measure 3
D3     4        q     d
rest   4        q
rest   4        q
measure 4
D3     4        q     d
F#3    4        q #   d
D3     4        q     d
measure 5
G3     4        q     d        (
F3     4        q n   d        )+
rest   4        q
measure 6
Ef3    4        q     d        (
D3     4        q     d        )
rest   4        q
measure 7
Ef3    4        q     d        (
D3     4        q     d        )
rest   4        q
measure 8
C3     4        q     u        (
Bf2    4        q     u        )
D4     3        e.    d  [     (
C4     1        s     d  ]\    )
measure 9
Bf3    4        q     d
A3     4        q     d
G3     4        q     d
measure 10
F#3    4        q #   d        (
D4     4        q     d        )
F3     4        q n   d        .
measure 11
E3     4        q n   d        (
C4     4        q     d        )
Ef3    4        q f   d        .
measure 12
D3     4        q     d        .
D4     4        q     d        .
rest   4        q
measure 13
rest  12
measure 14
rest  12
measure 15
rest   4        q
Bf3    4        q     d        (p
A3     4        q     d
measure 16
G3     4        q     d
A3     4        q     d        )
rest   4        q
measure 17
rest   4        q
G3     4        q     d        (
F3     4        q     d
measure 18
E3     4        q n   d
F3     4        q     d        )
rest   4        q
measure 19
rest   4        q
Ef3    4        q f   d        (+
D3     4        q     d
measure 20
C3     4        q     u
D3     4        q     d        )
rest   4        q
measure 21
C3     2        e     u  [     f
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
measure 22
E3     2        e n   d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 23
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 24
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 25
Bf3    4        q     d
rest   4        q
rest   4        q
measure 26
F3     8        h     d        (
D3     4        q     d        )
measure 27
Ef3    4        q f   d        .+
rest   4        q
rest   4        q
measure 28
F3     8        h     d        (
D3     4        q     d        )
measure 29
Ef3    4        q     d
rest   4        q
rest   4        q
measure 30
rest  12
measure 31
rest  12
measure 32
rest  12
measure 33
rest  12
measure 34
rest  12
measure 35
rest  12
measure 36
Bf2    4        q     u        f
D3     4        q     d
Bf2    4        q     u
measure 37
F3     4        q     d
F2     4        q     u
rest   4        q
measure 38
Bf2    4        q     u
D3     4        q     d
Bf2    4        q     u
measure 39
C3     4        q     u
C4     4        q     d
rest   4        q
measure 40
D3     4        q     d
F3     4        q     d
D3     4        q     d
measure 41
Ef3    4        q     d
C3     4        q     u
rest   4        q
measure 42
F3     4        q     d
A3     4        q     d
C4     4        q     d
measure 43
A3     4        q     d
F3     4        q     d
rest   4        q
measure 44
F2     4        q     u
A2     4        q     u
C3     4        q     u
measure 45
A2     4        q     u
F2     4        q     u
rest   4        q
measure 46
F3     4        q     d
A3     4        q     d
C4     4        q     d
measure 47
Bf3    4        q     d
rest   4        q
rest   4        q
measure 48
D3     4        q     d        (
Ef3    4        q     d        )
rest   4        q
measure 49
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 50
Bf2    4        q     u
rest   4        q
rest   4        q
measure 51
D3     4        q     d        (
Ef3    4        q     d        )
rest   4        q
measure 52
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 53
Bf2    4        q     u
rest   4        q
rest   4        q
measure 54
Bf3    4        q     d        (
F3     4        q     d        )
rest   4        q
measure 55
A3     4        q     d        (
Bf3    4        q     d        )
rest   4        q
measure 56
C4     4        q     d        (
Df4    4        q f   d        )
rest   4        q
measure 57
E3     4        q n   d        (
F3     4        q     d        )
rest   4        q
measure 58
rest  12
measure 59
E3     4        q n   d
E3     4        q     d
E3     4        q     d
measure 60
F3     4        q     d        (
A3     4        q     d
Bf3    4        q     d        )
measure 61
Ef3    4        q f   d        (+
F3     4        q     d
D3     4        q     d        )
measure 62
Ef3    4        q     d        (
F3     4        q     d
G3     4        q     d        )
measure 63
E3     4        q n   d
E3     4        q     d
E3     4        q     d
measure 64
Ef3    4        q f   d        (+
A2     4        q     u
Bf2    4        q     u        )
measure 65
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 66
Bf2    4        q     u
rest   4        q
Bf3    4        q     d        .p
measure 67
A3     4        q     d        .
rest   4        q
C4     4        q     d        .
measure 68
Bf3    4        q     d        .
rest   4        q
D3     4        q     d        .
measure 69
C3     4        q     u        .
rest   4        q
F2     4        q     u        .
measure 70
Bf2    4        q     u        .
rest   4        q
Bf3    4        q     d        .
measure 71
A3     4        q     d        .
rest   4        q
C4     4        q     d        .
measure 72
Bf3    4        q     d        .
rest   4        q
rest   4        q
measure 73
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 74
Bf2    4        q     u        f
D3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
Bf2    2        e     u  ]
measure 75
F3     4        q     d
F#3    2        e #   d  [
E3     2        e n   d  =
F#3    2        e     d  =
D3     2        e     d  ]
measure 76
G3     4        q     d
Bf2    2        e     u  [
A2     2        e     u  =
Bf2    2        e     u  =
G2     2        e     u  ]
measure 77
D3     4        q     d
D3     2        e     u  [
C3     2        e     u  =
D3     2        e     u  =
Bf2    2        e     u  ]
measure 78
Ef3    4        q f   d        +
G3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
Ef3    2        e     d  ]
measure 79
G3     4        q     d
B2     2        e n   u  [
A2     2        e     u  =
B2     2        e     u  =
G2     2        e     u  ]
measure 80
C3     4        q     u
rest   4        q
rest   4        q
measure 81
C3     4        q     u        (
Bf2    4        q f   u        +
A2     4        q     u
measure 82
G2     4        q     u
A2     4        q     u
Bf2    4        q     u        )
measure 83
C3     4        q     u        (
Bf2    4        q     u
A2     4        q     u
measure 84
G2     4        q     u
A2     4        q     u
Bf2    4        q     u        )
measure 85
F#3    4        q #   d        .
G3     4        q     d        .
A3     4        q     d        .
measure 86
Bf3    4        q     d        .
A3     4        q     d        .
G3     4        q     d        .
measure 87
F#3    4        q #   d
C4     4        q     d
A3     4        q     d
measure 88
F#3    4        q #   d
rest   4        q
rest   4        q
mheavy4 89      :|:
rest   4        q
B3     4        q n   d        (p
G3     4        q     d        )
measure 90
rest   4        q
Ef3    4        q     d        (
C3     4        q     u        )
measure 91
F3     4        q n   d        +
G3     4        q     d
G2     4        q     u
measure 92
C3     8        h     u
rest   4        q
measure 93
rest  12
measure 94
rest  12
measure 95
rest   4        q
A3     4        q     d        (
F3     4        q     d        )
measure 96
rest   4        q
D4     4        q     d        (
Bf3    4        q f   d        )+
measure 97
Ef3    4        q     d
F3     4        q     d
F2     4        q     u
measure 98
Bf2    8        h     u
rest   4        q
measure 99
rest   4        q
Bf3    4        q     d        (
G3     4        q     d        )
measure 100
rest   4        q
A3     4        q     d        (
F#3    4        q #   d        )
measure 101
G3     4        q     d
F3     4        q n   d        +
Ef3    4        q     d
measure 102
D3     8        h     d        (
F#3    4        q #   d
measure 103
G3     4        q     d
A3     4        q     d
G3     4        q     d        )
measure 104
F#3   12        h.#   d
measure 105
G3     4        q     d        (
A3     4        q     d
G3     4        q     d        )
measure 106
F#3   12        h.#   d
measure 107
G3     4        q     d        (
A3     4        q     d
G3     4        q     d        )
measure 108
F#3    8        h #   d
rest   4        q              F
measure 109
G3     4        q     d        f
rest   4        q
rest   4        q
measure 110
G2     4        q     u
Bf2    4        q     u
G2     4        q     u
measure 111
D3     4        q     d
rest   4        q
rest   4        q
measure 112
D3     4        q     d
F#3    4        q #   d
D3     4        q     d
measure 113
G3     4        q     d        (
F3     4        q n   d        )+
rest   4        q
measure 114
Ef3    4        q     d        (
D3     4        q     d        )
rest   4        q
measure 115
Ef3    4        q     d        (
D3     4        q     d        )
rest   4        q
measure 116
C3     4        q     u        (
Bf2    4        q     u        )
D4     3        e.    d  [     (
C4     1        s     d  ]\    )
measure 117
Bf3    4        q     d
A3     4        q     d
G3     4        q     d
measure 118
F#3    4        q #   d        (
D4     4        q     d        )
F3     4        q n   d        .
measure 119
E3     4        q n   d        (
C4     4        q     d        )
Ef3    4        q f   d        .
measure 120
D3     4        q     d        .
D4     4        q     d        .
rest   4        q
measure 121
rest  12
measure 122
rest  12
measure 123
rest   4        q
C4     4        q     d        (p
Bf3    4        q     d
measure 124
A3     4        q     d
Bf3    4        q     d        )
rest   4        q
measure 125
rest   4        q
Af3    4        q f   d        (
G3     4        q     d
measure 126
F3     4        q     d
G3     4        q     d        )
rest   4        q
measure 127
rest   4        q
F3     4        q     d        (
Ef3    4        q     d
measure 128
D3     4        q     d
Ef3    4        q     d        )
rest   4        q
measure 129
D3     2        e     d  [     f
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 130
F#2    2        e #   u  [
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  =
F#2    2        e     u  ]
measure 131
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 132
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 133
C3     4        q     u
rest   4        q
rest   4        q
measure 134
A2     8        h n   u        (+
B2     4        q n   u        )
measure 135
C3     4        q     u
rest   4        q
rest   4        q
measure 136
A2     8        h     u        (
B2     4        q n   u        )
measure 137
C3     4        q     u
rest   4        q
rest   4        q
measure 138
rest  12
measure 139
rest  12
measure 140
rest  12
measure 141
rest  12
measure 142
rest  12
measure 143
rest  12
measure 144
C3     4        q     u        f
Ef3    4        q     d
C3     4        q     u
measure 145
G3     4        q     d
G2     4        q     u
rest   4        q
measure 146
C3     4        q     u
rest   4        q
C3     4        q     u
measure 147
D3     4        q     d
D2     4        q     u
D3     4        q     d
measure 148
Ef3    4        q     d
G3     4        q     d
C4     4        q     d
measure 149
Ef3    4        q     d
Ef2    4        q     u
Ef3    4        q     d
measure 150
D3     4        q     d
rest   4        q
rest   4        q
measure 151
D3     4        q     d
F#3    4        q #   d
A3     4        q     d
measure 152
F#3    4        q #   d
D3     4        q     d
rest   4        q
measure 153
D2     4        q     u
F#2    4        q #   u
A2     4        q     u
measure 154
F#2    4        q #   u
D2     4        q     u
rest   4        q
measure 155
D3     4        q     d
F#3    4        q #   d
A3     4        q     d
measure 156
G3     4        q     d
rest   4        q
rest   4        q
measure 157
F#3    4        q #   d        (
G3     4        q     d        )
rest   4        q
measure 158
C3     4        q     u        p
D3     4        q     d
D3     4        q     d
measure 159
G3     4        q     d
rest   4        q
rest   4        q
measure 160
D3     4        q     d        (f
P C33:y5
Ef3    4        q     d        )
rest   4        q
measure 161
C3     4        q     u        p
D3     4        q     d
D2     4        q     u
measure 162
G2     4        q     u
rest   4        q
rest   4        q
measure 163
A3     4        q     d        (f
Bf3    4        q     d        )
rest   4        q
measure 164
F#3    4        q #   d        (
G3     4        q     d        )
rest   4        q
measure 165
C3     4        q     u        (
Bf2    4        q     u        )
rest   4        q
measure 166
C#3    4        q #   u        (
D3     4        q     d        )
rest   4        q
measure 167
rest  12
measure 168
C#3    4        q #   u
C#3    4        q     u
C#3    4        q     u
measure 169
D3     4        q     d        (
F#3    4        q #   d
G3     4        q     d        )
measure 170
C3     4        q n   u        (+
P C32:o
D3     4        q     d
B2     4        q n   u        )
measure 171
C3     4        q     u        (
D3     4        q     d
Ef3    4        q     d        )
measure 172
C#3    4        q #   u
C#3    4        q     u
C#3    4        q     u
measure 173
D3     4        q     d        (
F#3    4        q #   d
G3     4        q     d        )
measure 174
C4     4        q     d
D4     4        q     d
D3     4        q     d
measure 175
G3     4        q     d        .
rest   4        q
G3     4        q     d        .p
measure 176
F#3    4        q #   d        .
rest   4        q
A3     4        q     d        .
measure 177
G3     4        q     d        .
rest   4        q
Bf2    4        q     u
measure 178
A2     4        q     u
D3     4        q     d
F#2    4        q #   u
measure 179
G2     4        q     u
rest   4        q
G3     4        q     d        .
measure 180
F#3    4        q #   d        .
rest   4        q
A3     4        q     d        .
measure 181
G3     4        q     d        .
rest   4        q
Bf2    4        q     u
measure 182
C3     4        q     u
D3     4        q     d
D2     4        q     u
measure 183
G2     4        q     u        f
Bf2    2        e     u  [
A2     2        e     u  =
Bf2    2        e     u  =
G2     2        e     u  ]
measure 184
D3     4        q     d
D3     2        e     d  [
Ef3    2        e     d  =
D3     2        e     d  =
C3     2        e     d  ]
measure 185
B2     4        q n   u
B3     2        e n   d  [
C4     2        e     d  =
D4     2        e     d  =
B3     2        e     d  ]
measure 186
C4     4        q     d
C3     2        e     u  [
D3     2        e     u  =
C3     2        e     u  =
Bf2    2        e f   u  ]     +
measure 187
A2     4        q     u
A3     2        e     d  [
Bf3    2        e f   d  =     +
C4     2        e     d  =
A3     2        e     d  ]
measure 188
Bf3    4        q     d
G3     2        e     d  [
A3     2        e     d  =
Bf3    2        e     d  =
Bf2    2        e     d  ]
measure 189
C3     4        q     u
rest   4        q
rest   4        q
measure 190
C3     4        q     u        (
Bf2    4        q     u
A2     4        q     u        )
measure 191
G2     4        q     u        (
A2     4        q     u
Bf2    4        q     u        )
measure 192
F#3    4        q #   d        .
G3     4        q     d        .
A3     4        q     d        .
measure 193
Bf3    4        q     d        .
A3     4        q     d        .
G3     2        e     d  [     .
F3     2        e n   d  ]     .+
measure 194
Ef3    2        e     u  [     .
D3     2        e     u  =     .
C3     2        e     u  =     .
A2     2        e     u  =     .
D3     2        e     u  =     &1.
D2     2        e     u  ]     &1.
measure 195
G2     8        h     u
rest   4        q
mheavy2         :|
/END
/eof
//
