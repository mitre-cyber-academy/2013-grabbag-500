&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/01/01} [KHM:2017828942]
TIMESTAMP: DEC/26/2001 [md5sum:acd459ec28a51725591b824ae5bdf9e3]
02/17/94 E. Correia
WK#:157       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:0   Q:8   T:1/1  C:4
C4    12        q.    u        (p
P C33:y10
D4     4        e     u        )
E4     8        q     u        .
E4     8        q     u        .
measure 2
E4     4        e     u  [     (
D4     4        e     u  =
F4     4        e     u  =
E4     4        e     u  ]
D4     8        q     u        )
rest   8        q
measure 3
D4    12        q.    u        (
E4     4        e     u        )
F4     8        q     u        .
F4     8        q     u        .
measure 4
F4     4        e     u  [     (
E4     4        e     u  =
G4     4        e     u  =
F4     4        e     u  ]
E4     8        q     u        )
rest   8        q
measure 5
A4    12        q.    u        (
B4     4        e     d
C5     8        q     d        )
C5     8        q     d        .
measure 6
C5     8        q     d        (
B4     8        q     d        )
A4     8        q     u        .
G4     8        q     u        .
measure 7
G4     8        q     u        (
F4     8        q     u        )
E4     8        q     u        .
D4     8        q     u        .
measure 8
C4     8        q     u
rest   8        q
rest  16        h
measure 9
C5    12        q.    d        (f
D5     4        e     d        )
E5     8        q     d        &1.
E5     8        q     d        .
measure 10
E5     4        e     d  [     (
D5     4        e     d  =
F5     4        e     d  =
E5     4        e     d  ]
D5     8        q     d        )
rest   8        q
measure 11
D5    12        q.    d        (
E5     4        e     d        )
F5     8        q     d        &1.
F5     8        q     d        &1.
measure 12
F5     4        e     d  [     (
E5     4        e     d  =
G5     4        e     d  =
F5     4        e     d  ]
E5     8        q     d        )
rest   8        q
measure 13
G5    12        q.    d
E5     2        s     d  [[
F5     2        s     d  ]]
G5     4        e     d  [
A5     2        s     d  =[
B5     2        s     d  ]]
gD6    5        s     u
S C1:t50
C6     4        e     d  [
B5     2        s     d  =[
A5     2        s     d  ]]
measure 14
G5    12        q.    d
E5     2        s     d  [[
F5     2        s     d  ]]
G5     4        e     d  [
A5     2        s     d  =[
B5     2        s     d  ]]
gD6    5        s     u
S C1:t50
C6     4        e     d  [
B5     2        s     d  =[
A5     2        s     d  ]]
measure 15
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
D5     4        e     d  [
E5     4        e     d  ]
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
C5     4        e     d  [
D5     4        e     d  ]
measure 16
E5     6        e.    d  [     (
C5     2        s     d  ]\    )
A4     6        e.    d  [     (
D5     2        s     d  ]\    )
C5     8        q     d        (
B4     8        q     d        )
measure 17
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
D5     2        s     d  [[    (
E5     2        s     d  ==    )
D5     2        s     d  ==    (
E5     2        s     d  ]]    )
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
C5     2        s     d  [[    (
D5     2        s     d  ==    )
C5     2        s     d  ==    (
D5     2        s     d  ]]    )
measure 18
E5     2        s     d  [[    (
D5     2        s     d  ==
E5     2        s     d  ==    )
C5     2        s     d  ]]    .
A4     2        s     d  [[    (
B4     2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]    )
C5     8        q     d        (
B4     8        q     d        )
measure 19
C5    12        q.    d        (
D5     2        s     d  [[
E5     2        s     d  ]]    )
F5     4        e     d  [     (
G5     4        e     d  =
A5     4        e     d  =
F5     4        e     d  ]     )
measure 20
E5    16        h     d        (
D5     8        q     d        )
rest   8        q
measure 21
B5    16        h     d
gA5    5        s     u
S C1:t25
G5     8        q     d
gF5    5        s     u
S C1:t25
E5     8        q     d
measure 22
D5     4        e     d  [     (
C5     4        e     d  =     )
B4     4        e     d  =     (
C5     4        e     d  ]     )
A3     8        q     u
rest   8        q
measure 23
A5    16        h     d
gG5    5        s     u
S C1:t25
F#5    8        q #   d
gE5    5        s     u
S C1:t25
D5     8        q     d
measure 24
C5     4        e     d  [     (
B4     4        e     d  =     )
A4     4        e     d  =     (
B4     4        e     d  ]     )
G3     8        q     u
rest   8        q
measure 25
E5     6        e.    d  [     (
G5     2        s     d  ]\    )
G5     6        e.    d  [     (t
P C33:y-3
S C33:n6s17t84
F#5    1        t #   d  =[[
G5     1        t     d  ]]]   )
D5    12        q.    d        (
B4     4        e     d        )
measure 26
C5     2        s     d  [[    (
D5     2        s     d  ==
C5     2        s     d  ==
B4     2        s     d  ]]
C5     2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
C5     2        s     d  ]]    )
B4    16        h     d
measure 27
E5     6        e.    d  [     (
G5     2        s     d  ]\    )
G5     6        e.    d  [     (t
P C33:y-3
S C33:n6s17t84
F#5    1        t #   d  =[[
G5     1        t     d  ]]]   )
D5    12        q.    d        (
B4     4        e     d        )
measure 28
C5     2        s     d  [[    (
D5     2        s     d  ==
C5     2        s     d  ==
B4     2        s     d  ]]
C5     2        s     d  [[
D5     2        s     d  ==
E5     2        s     d  ==
C5     2        s     d  ]]    )
B4    16        h     d
measure 29
A4     8        q     u
A5    16        h     d
G5     8        q     d
measure 30
gG5    5        s     u
S C1:t50
F#5    4        e #   d  [
E5     2        s     d  =[
D5     2        s     d  ]]
D5     4        e     d  [
D5     4        e     d  ]
D5     8        q     d
rest   8        q
measure 31
G5     4        e     d  [     .p
G5     4        e     d  ]     .
rest   4        e
A5     2        s     d  [[    (
F#5    2        s #   d  ]]    )
G5     4        e     d  [     .
D5     4        e     d  =     .
G5     4        e     d  =     .
B5     4        e     d  ]     .
measure 32
G5     4        e     d  [     .
G5     4        e     d  ]     .
rest   4        e
A5     2        s     d  [[    (
F#5    2        s #   d  ]]    )
G5     4        e     d  [     .
D5     4        e     d  =     .
G5     4        e     d  =     .
B5     4        e     d  ]     .
measure 33
D6    32-       w     d        -
measure 34
D6    32-       w     d        -
measure 35
D6    16        h     d
C6    16-       h     d        -
measure 36
C6    16        h     d
B5    16        h     d
measure 37
A5    12        q.    d
C6     2        s     d  [[    (
A5     2        s     d  ]]    )
G5     8        q     d
F#5    8        q #   d
measure 38
G5     4        e     d  [     (
D5     4        e     d  =     )
D5     4        e     d  =     .
D5     4        e     d  ]     .
D5     4        e     d  [
D5     4        e     d  =
D5     4        e     d  =
D5     4        e     d  ]
measure 39
D5    16        h     d
C5    16-       h     d        -
measure 40
C5    16        h     d
B4    16        h     d
measure 41
A4    12        q.    u        (
C5     2        s     d  [[
E5     2        s     d  ]]    )
G4     8        q     u        (
F#4    8        q #   u        )
measure 42
G4     4        e     u  [     (f
P C33:y10
B4     4        e     u  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
A4     4        e     d  [     (f
C5     4        e     d  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
measure 43
B4     4        e     d  [     (f
D5     4        e     d  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
gD5    5        s     u
S C1:t50
C5     4        e     d  [     f
P C32:y5
B4     2        s     d  =[
A4     2        s     d  ]]
gB4    5        s     u
S C1:t50
A4     4        e     u  [
G4     2        s     u  =[
F#4    2        s #   u  ]]
measure 44
G4     4        e     u  [     (f
P C33:y10
B4     4        e     u  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
A4     4        e     d  [     (f
C5     4        e     d  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
measure 45
B4     4        e     d  [     (f
D5     4        e     d  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
gD5    5        s     u
S C1:t50
C5     4        e     d  [     f
P C32:y5
B4     2        s     d  =[
A4     2        s     d  ]]
gB4    5        s     u
S C1:t50
A4     4        e     u  [
G4     2        s     u  =[
F#4    2        s #   u  ]]
measure 46
G4     8        q     u
G5     8        q     d        (p
A5     8        q     d
B5     8        q     d        )
measure 47
C6     8        q     d        (f
B5     8        q     d        )
gB5    5        s     u
S C1:pt50
A5     4        e     d  [     (p
G5     4        e     d  =
A5     4        e     d  =
B5     4        e     d  ]     )
measure 48
G5     8        q     d
G4     8        q     u        (p
A4     8        q     u
B4     8        q     u        )
measure 49
C5     8        q     d        (f
B4     8        q     d        )
gB4    5        s     u
S C1:pt50
A4     4        e     u  [     (p
G4     4        e     u  =
A4     4        e     u  =
B4     4        e     u  ]     )
measure 50
G4    16        h     u
gB4    5        s     u
S C1:pt50
A4     4        e     u  [     (
G4     4        e     u  =
A4     4        e     u  =
B4     4        e     u  ]     )
measure 51
G4    16        h     u
gB4    5        s     u
S C1:pt50
A4     4        e     u  [     (
G4     4        e     u  =
A4     4        e     u  =
B4     4        e     u  ]     )
measure 52
G4     8        q     u
G5     8        q     u        f
 B4    8        q     u
 D4    8        q     u
G5     8        q     u
 B4    8        q     u
 D4    8        q     u
 G3    8        q     u
rest   8        q
mheavy4 53      :|:
G4     4        e     u  [     (f
P C33:y10
B4     4        e     u  ]     )
D4     4        e     u  [     .p
D4     4        e     u  ]     .
B4     4        e     d  [     (f
D5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
measure 54
D5     4        e     d  [     (f
G5     4        e     d  ]     )
B4     4        e     d  [     .p
B4     4        e     d  ]     .
gA5    5        s     u
S C1:t50
G5     4        e     d  [     f
F5     2        s n   d  =[    +
E5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 55
C5     4        e     d  [     (f
E5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
E5     4        e     d  [     (f
G5     4        e     d  ]     )
C5     4        e     d  [     .p
C5     4        e     d  ]     .
measure 56
G5     4        e     d  [     (f
C6     4        e     d  ]     )
E5     4        e     d  [     .p
E5     4        e     d  ]     .
gA5    5        s     u
S C1:t50
G5     4        e     d  [     f
F5     2        s     d  =[
E5     2        s     d  ]]
gF5    5        s     u
S C1:t50
E5     4        e     d  [
D5     2        s     d  =[
C5     2        s     d  ]]
measure 57
B4     4        e     d  [     (f
D5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
D5     4        e     d  [     (f
F5     4        e     d  ]     )
B4     4        e     d  [     .p
B4     4        e     d  ]     .
measure 58
F5     4        e     d  [     (f
B5     4        e     d  ]     )
D5     4        e     d  [     .p
D5     4        e     d  ]     .
gG5    5        s     u
S C1:t50
F5     4        e     d  [     f
E5     2        s     d  =[
D5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 59
E5     4        e     d  [     (f
A5     4        e     d  ]     )
C5     4        e     d  [     .p
C5     4        e     d  ]     .
gF5    5        s     u
S C1:t50
E5     4        e     d  [     f
D5     2        s     d  =[
C5     2        s     d  ]]
gD5    5        s     u
S C1:t50
C5     4        e     d  [
B4     2        s     d  =[
A4     2        s     d  ]]
measure 60
G#4    8        q #   u
E5     8        q     d
 B4    8        q     d
 G#4   8        q     d
E5     8        q     d
 B4    8        q     d
 G#4   8        q     d
rest   8        q
measure 61
A4     4        e     u  [      .p
A4     4        e     u  ]      .
rest   4        e
B4     2        s     u  [[     (
G#4    2        s #   u  ]]     )
A4     4        e     u  [      .
E4     4        e     u  =      .
A4     4        e     u  =      .
C5     4        e     u  ]      .
measure 62
A4     4        e     u  [      .
A4     4        e     u  ]      .
rest   4        e
B4     2        s     u  [[     (
G#4    2        s #   u  ]]     )
A4     4        e     d  [      .
A4     4        e     d  =      .
C5     4        e     d  =      .
E5     4        e     d  ]      .
measure 63
A5    32-       w     d        -
measure 64
A5    32        w     d
measure 65
G5    32-       w     d        -
measure 66
G5    32-       w     d        -
measure 67
G5    16        h     d
F5    16-       h     d        -
measure 68
F5    16        h     d
E5    16        h     d
measure 69
Ef5   16        h f   d        (f
D5     8        q     d
C5     8        q     d        )
measure 70
B4     2        s     d  [[    (
G5     2        s     d  ==    )
G5     2        s     d  ==    .
G5     2        s     d  ]]    .
G5     2        s     d  [[    (
D5     2        s     d  ==    )
E5     2        s n   d  ==    (+
C5     2        s     d  ]]    )
D5     2        s     d  [[    (
G5     2        s     d  ==    )
G5     2        s     d  ==    .
G5     2        s     d  ]]    .
G5     2        s     d  [[    (
D5     2        s     d  ==    )
E5     2        s     d  ==    (
C5     2        s     d  ]]    )
measure 71
B4     4        e     d        .
D5     4        e     d  [     (p
G5     4        e     d  =
B5     4        e     d  ]     )
rest   4        e
C6     4        e     d  [     (p
A5     4        e     d  =
F5     4        e     d  ]     )
measure 72
rest   4        e
E5     4        e     d  [     (
G5     4        e     d  =
B5     4        e     d  ]     )
rest   4        e
A5     4        e     d  [     (
F5     4        e     d  =
D5     4        e     d  ]     )
measure 73
rest   4        e
C5     4        e     d  [     (
E5     4        e     d  =
G5     4        e     d  ]     )
F5     2        s     d  [[    (f
G5     2        s     d  ==
E5     2        s     d  ==
G5     2        s     d  ]]
F5     2        s     d  [[
G5     2        s     d  ==
E5     2        s     d  ==
G5     2        s     d  ]]    )
measure 74
F5     4        e     d  [     (
D5     4        e     d  =
B4     4        e     d  =
G4     4        e     d  ]     )
F#4    4        e #   u  [     (
F4     4        e n   u  =
D4     4        e     u  =
B3     4        e     u  ]     )
measure 75
C4    12        q.    u        (p
P C33:y10
D4     4        e     u
E4     8        q     u        )
E4     8        q     u        .
measure 76
E4     4        e     u  [     (
D4     4        e     u  =
F4     4        e     u  =
E4     4        e     u  ]
D4     8        q     u        )
rest   8        q
measure 77
D4    12        q.    u        (
E4     4        e     u
F4     8        q     u        )
F4     8        q     u        .
measure 78
F4     4        e     u  [     (
E4     4        e     u  =
G4     4        e     u  =
F4     4        e     u  ]
E4     8        q     u        )
rest   8        q
measure 79
A4    12        q.    u        (
B4     4        e     d
C5     8        q     d        )
C5     8        q     d        .
measure 80
C5     8        q     d        (
B4     8        q     d        )
A4     8        q     u        .
G4     8        q     u        .
measure 81
G4     8        q     u        (
F4     8        q     u        )
E4     8        q     u        .
D4     8        q     u        .
measure 82
C4     8        q     u        .
rest   8        q
rest  16        h
measure 83
C5    12        q.    d        (f
D5     4        e     d
E5     8        q     d        )
E5     8        q     d        .
measure 84
E5     4        e     d  [     (
D5     4        e     d  =
F5     4        e     d  =
E5     4        e     d  ]
D5     8        q     d        )
rest   8        q
measure 85
D5    12        q.    d        (
E5     4        e     d
F5     8        q     d        )
F5     8        q     d        .
measure 86
F5     4        e     d  [     (
E5     4        e     d  =
G5     4        e     d  =
F5     4        e     d  ]
E5     8        q     d        )
rest   8        q
measure 87
G5    12        q.    d
E5     2        s     d  [[
F5     2        s     d  ]]
G5     4        e     d  [
A5     2        s     d  =[
B5     2        s     d  ]]
gD6    5        s     u
S C1:t50
C6     4        e     d  [
B5     2        s     d  =[
A5     2        s     d  ]]
measure 88
G5    12        q.    d
E5     2        s     d  [[
F5     2        s     d  ]]
G5     4        e     d  [
A5     2        s     d  =[
B5     2        s     d  ]]
gD6    5        s     u
S C1:t50
C6     4        e     d  [
B5     2        s     d  =[
A5     2        s     d  ]]
measure 89
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
D5     4        e     d  [
E5     4        e     d  ]
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
C5     4        e     d  [
D5     4        e     d  ]
measure 90
E5     6        e.    d  [     (
C5     2        s     d  ]\    )
A4     6        e.    d  [     (
D5     2        s     d  ]\    )
C5     8        q     d
B4     8        q     d
measure 91
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
D5     2        s     d  [[    (
E5     2        s     d  ==    )
D5     2        s     d  ==    (
E5     2        s     d  ]]    )
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
C5     2        s     d  [[    (
D5     2        s     d  ==    )
C5     2        s     d  ==    (
D5     2        s     d  ]]    )
measure 92
E5     2        s     d  [[    (
D5     2        s     d  ==
E5     2        s     d  ==    )
C5     2        s     d  ]]    .
A4     2        s     d  [[    (
B4     2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]    )
C5     8        q     d        (
B4     8        q     d        )
measure 93
C5    12        q.    d        (
D5     2        s     d  [[
E5     2        s     d  ]]    )
F5     4        e     d  [     (
G5     4        e     d  =
A5     4        e     d  =
F5     4        e     d  ]     )
measure 94
E5    16        h     d        (
D5     8        q     d        )
rest   8        q
measure 95
Bf5   16        h f   d
gA5    5        s     u
S C1:t25
G5     8        q     d
gF5    5        s     u
S C1:t25
E5     8        q     d
measure 96
E5     4        e     d  [     (
F5     4        e     d  =
C#5    4        e #   d  =
D5     4        e     d  ]     )
D4     8        q     u
rest   8        q
measure 97
A5    16        h     d
gG5    5        s     u
S C1:t25
F5     8        q     d
gE5    5        s     u
S C1:t25
D5     8        q     d
measure 98
D5     4        e     d  [     (
E5     4        e     d  =
B4     4        e     d  =
C5     4        e     d  ]     )
C4     8        q     u
rest   8        q
measure 99
A5     6        e.    d  [     (
C6     2        s     d  ]\    )
C6     6        e.    d  [     (t
P C33:y-5
S C33:n6s17t84
B5     1        t     d  =[[
C6     1        t     d  ]]]   )
G5    12        q.    d        (
E5     4        e     d        )
measure 100
F5     2        s     d  [[    (
G5     2        s     d  ==
F5     2        s     d  ==
E5     2        s     d  ]]
F5     2        s     d  [[
G5     2        s     d  ==
A5     2        s     d  ==
F5     2        s     d  ]]    )
E5    16        h     d
measure 101
A4     6        e.    d  [     (
C5     2        s     d  ]\    )
C5     6        e.    d  [     (t
S C33:n6s17t84
B4     1        t     d  =[[
C5     1        t     d  ]]]   )
G4    12        q.    u        (
E4     4        e     u        )
measure 102
F4     2        s     u  [[    (
G4     2        s     u  ==
F4     2        s     u  ==
E4     2        s     u  ]]
F4     2        s     u  [[
G4     2        s     u  ==
A4     2        s     u  ==
F4     2        s     u  ]]    )
E4    16        h     u
measure 103
D4     8        q     u
D5    16        h     d
C5     8        q     d
measure 104
gC5    5        s     u
S C1:t50
B4     4        e     u  [
A4     2        s     u  =[
G4     2        s     u  ]]
G4     4        e     u  [
G4     4        e     u  ]
G4     8        q     u
rest   8        q
measure 105
C5     4        e     d  [     .p
C5     4        e     d  ]     .
rest   4        e
D5     2        s     d  [[    (
B4     2        s     d  ]]    )
C5     4        e     d  [     .
G4     4        e     d  =     .
C5     4        e     d  =     .
E5     4        e     d  ]     .
measure 106
C5     4        e     d  [     .
C5     4        e     d  ]     .
rest   4        e
D5     2        s     d  [[    (
B4     2        s     d  ]]    )
C5     4        e     d  [     .
G4     4        e     d  =     .
C5     4        e     d  =     .
E5     4        e     d  ]     .
measure 107
G5    32-       w     d        -
measure 108
G5    32-       w     d        -
measure 109
G5    16        h     d
F5    16-       h     d        -
measure 110
F5    16        h     d
E5    16        h     d
measure 111
D5    12        q.    d        (
F5     2        s     d  [[
A5     2        s     d  ]]    )
C5     8        q     d        (
B4     8        q     d        )
measure 112
C5     4        e     u  [     (
G4     4        e     u  ]     )
G4     4        e     u  [     .
G4     4        e     u  ]     .
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 113
G4    16        h     u
F4    16-       h     u        -
measure 114
F4    16        h     u
E4    16        h     u
measure 115
D4    12        q.    u        (
F4     2        s     u  [[
A4     2        s     u  ]]    )
C4     8        q     u        (
B3     8        q     u        )
measure 116
C4     4        e     u  [     (f
P C33:y10
E4     4        e     u  ]     )
G3     4        e     u  [     .p
G3     4        e     u  ]     .
D4     4        e     u  [     (f
P C33:y10
F4     4        e     u  ]     )
G3     4        e     u  [     .p
G3     4        e     u  ]     .
measure 117
E4     4        e     u  [     (f
P C33:y10
G4     4        e     u  ]     )
C5     4        e     d  [     .p
C5     4        e     d  ]     .
gG5    5        s     u
S C1:t50
F5     4        e     d  [     f
E5     2        s     d  =[
D5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 118
C5     4        e     d  [     (f
E5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
D5     4        e     d  [     (f
F5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
measure 119
E5     4        e     d  [     (f
G5     4        e     d  ]     )
G4     4        e     u  [     .p
G4     4        e     u  ]     .
gG5    5        s     u
S C1:t50
F5     4        e     d  [     f
E5     2        s     d  =[
D5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 120
C5     8        q     d
C5     8        q     d        (p
D5     8        q     d
E5     8        q     d        )
measure 121
F5     8        q     d        (f
E5     8        q     d        )
gE5    5        s     u
S C1:pt50
D5     4        e     d  [     (p
C5     4        e     d  =
D5     4        e     d  =
E5     4        e     d  ]     )
measure 122
C5     8        q     d
C4     8        q     u        (
D4     8        q     u
E4     8        q     u        )
measure 123
F4     8        q     u        (f
P C33:y15
E4     8        q     u        )
gE4    5        s     u
S C1:pt50
D4     4        e     u  [     (p
C4     4        e     u  =
D4     4        e     u  =
E4     4        e     u  ]     )
measure 124
C4    16        h     u
gE4    5        s     u
S C1:pt50
D4     4        e     u  [     (
C4     4        e     u  =
D4     4        e     u  =
E4     4        e     u  ]     )
measure 125
C4    16        h     u
gE4    5        s     u
S C1:pt50
D4     4        e     u  [     (
C4     4        e     u  =
D4     4        e     u  =
E4     4        e     u  ]     )
measure 126
C4     8        q     u
C6     8        q     d        f
 E5    8        q     d
C6     8        q     d
 E5    8        q     d
rest   8        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/01/02} [KHM:2017828942]
TIMESTAMP: DEC/26/2001 [md5sum:cf99a40541341ef8835a911baac10bad]
02/17/94 E. Correia
WK#:157       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:0   Q:8   T:1/1  C:4
C4    12        q.    u        (p
P C33:y10
B3     4        e     u        )
C4     8        q     u        .
C4     8        q     u        .
measure 2
C4     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
C4     4        e     u  ]
B3     8        q     u        )
rest   8        q
measure 3
B3    12        q.    u        (
C4     4        e     u        )
D4     8        q     u        .
D4     8        q     u        .
measure 4
D4     4        e     u  [     (
C4     4        e     u  =
E4     4        e     u  =
D4     4        e     u  ]
C4     8        q     u        )
rest   8        q
measure 5
D4    24        h.    u        (
A4     8        q     u        )
measure 6
A4     8        q     u        (
G4     8        q     u        )
F4     8        q     u        .
E4     8        q     u        .
measure 7
E4     8        q     u        (
D4     8        q     u        )
C4     8        q     u        .
B3     8        q     u        .
measure 8
C4     8        q     u
rest   8        q
rest  16        h
measure 9
C5    12        q.    d        (f
B4     4        e     d        )
C5     8        q     d        .
C5     8        q     d        .
measure 10
C5     4        e     d  [     (
B4     4        e     d  =
D5     4        e     d  =
C5     4        e     d  ]
B4     8        q     d        )
rest   8        q
measure 11
B4    12        q.    d        (
C5     4        e     d        )
D5     8        q     d        &1.
D5     8        q     d        &1.
measure 12
D5     4        e     d  [     (
C5     4        e     d  =
E5     4        e     d  =
D5     4        e     d  ]
C5     8        q     d        )
rest   8        q
measure 13
E5    12        q.    d
C5     2        s     d  [[
D5     2        s     d  ]]
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
gB5    5        s     u
S C1:t50
A5     4        e     d  [
G5     2        s     d  =[
F5     2        s     d  ]]
measure 14
E5    12        q.    d
C5     2        s     d  [[
D5     2        s     d  ]]
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
gB5    5        s     u
S C1:t50
A5     4        e     d  [
G5     2        s     d  =[
F5     2        s     d  ]]
measure 15
gF5    5        s     u
S C1:t50
E5     4        e     d  [
D5     2        s     d  =[
C5     2        s     d  ]]
B4     4        e     d  [
C5     4        e     d  ]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
A4     4        e     u  [
B4     4        e     u  ]
measure 16
C5     6        e.    u  [     (
E4     2        s     u  ]\    )
C4     6        e.    u  [     (
F4     2        s     u  ]\    )
E4     8        q     u        (
D4     8        q     u        )
measure 17
gF4    5        s     u
S C1:t50
E4     4        e     u  [
D4     2        s     u  =[
C4     2        s     u  ]]
B3     2        s     u  [[    (
C4     2        s     u  ==    )
B3     2        s     u  ==    (
C4     2        s     u  ]]    )
gE4    5        s     u
S C1:t50
D4     4        e     u  [
C4     2        s     u  =[
B3     2        s     u  ]]
A3     2        s     u  [[    (
B3     2        s     u  ==    )
A3     2        s     u  ==    (
B3     2        s     u  ]]    )
measure 18
C4     8        q     u
C4     2        s     u  [[    (
D4     2        s     u  ==
E4     2        s     u  ==
F4     2        s     u  ]]    )
E4     8        q     u        (
D4     8        q     u        )
measure 19
C4    12        q.    u        (
D4     2        s     u  [[
E4     2        s     u  ]]    )
F4     4        e     u  [     (
G4     4        e     u  =
A4     4        e     u  =     )
D5     4        e     u  ]     .
measure 20
C5    16        h     d        (
B4     8        q     d        )
rest   8        q
measure 21
rest  32
measure 22
E5    16        h     d
gD5    5        s     u
S C1:t25
C5     8        q     d
gB4    5        s     u
S C1:t25
A4     8        q     u
measure 23
G4     4        e     u  [     (
F#4    4        e #   u  =     )
E4     4        e     u  =     (
F#4    4        e     u  ]     )
A3     8        q     u
rest   8        q
measure 24
D5    16        h     d
gC5    5        s     u
S C1:t25
B4     8        q     d
gA4    5        s     u
S C1:t25
G4     8        q     u
measure 25
G4     8        q     u
rest   8        q
G3     6        e.    u  [     (
G4     2        s     u  ]\    )
G4     6        e.    u  [     (t
S C33:n6s17t84
F#4    1        t #   u  =[[
G4     1        t     u  ]]]   )
measure 26
G3    16-       h     u        -
G3     2        s     u  [[
G4     2        s     u  ==    (
F#4    2        s #   u  ==
G4     2        s     u  ]]
A4     2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]    )
measure 27
G4     8        q     u
rest   8        q
G3     6        e.    u  [     (
G4     2        s     u  ]\    )
G4     6        e.    u  [     (t
S C33:n6s17t84
F#4    1        t #   u  =[[
G4     1        t     u  ]]]   )
measure 28
G3    16-       h     u        -
G3     2        s     u  [[
G4     2        s     u  ==    (
F#4    2        s #   u  ==
G4     2        s     u  ]]
A4     2        s     u  [[
G4     2        s     u  ==
F#4    2        s     u  ==
G4     2        s     u  ]]    )
measure 29
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
G4     4        e     d  [
G4     4        e     d  =
E5     4        e     d  =
E5     4        e     d  ]
measure 30
D5     8        q     d
A4     8        q     u
F#4    8        q #   u
rest   8        q
measure 31
rest   8        q
C5     8        q     d        (p
B4     8        q     d        )
rest   8        q
measure 32
rest   8        q
C5     8        q     d        (
B4     8        q     d        )
rest   8        q
measure 33
G4     4        e     u  [     .
G4     4        e     u  ]     .
rest   4        e
A4     2        s     u  [[    (
F#4    2        s #   u  ]]    )
G4     4        e     u  [     .
D4     4        e     u  =     .
G4     4        e     u  =     .
A4     4        e     u  ]     .
measure 34
B4     4        e     d  [     .
B4     4        e     d  ]     .
rest   4        e
C5     2        s     d  [[    (
A4     2        s     d  ]]    )
B4     4        e     d  [     .
G4     4        e     d  =     .
D5     4        e     d  =     .
C5     4        e     d  ]     .
measure 35
B4     8        q     d
E5    16        h     d
A4     8-       q     u        -
measure 36
A4     8        q     u
D5    16        h     d
G4     8-       q     u        -
measure 37
G4    12        q.    u
E5     2        s     d  [[    (
C5     2        s     d  ]]    )
B4     8        q     d
A4     8        q     u
measure 38
G4     8        q     u
rest   8        q
rest  16        h
measure 39
G#4    8        q #   u        (
B4     8        q     d        )
C5     4        e     u  [     (
B4     4        e     u  =
A4     4        e     u  =
G4     4        e n   u  ]     )
measure 40
F#4    8        q #   u        (
A4     8        q     u        )
B4     4        e     u  [     (
A4     4        e     u  =
G4     4        e     u  =
F#4    4        e     u  ]     )
measure 41
E4    12        q.    u        (
C4     4        e     u        )
B3     8        q     u        (
A3     8        q     u        )
measure 42
B3     8        q     u        f
rest   8        q
C4     8        q     u
rest   8        q
measure 43
B3     8        q     u
rest   8        q
E4     8        q     u        (
C4     8        q     u        )
measure 44
B3     8        q     u
rest   8        q
D4     8        q     u
rest   8        q
measure 45
D4     8        q     u
rest   8        q
E4     8        q     u        (
C4     8        q     u        )
measure 46
B3     8        q     u
G4     8        q     u        (p
A4     8        q     u
B4     8        q     u        )
measure 47
C5     8        q     d        (f
B4     8        q     d        )
gB4    5        s     u
S C1:pt50
A4     4        e     u  [     (p
G4     4        e     u  =
A4     4        e     u  =
B4     4        e     u  ]     )
measure 48
G4     8        q     u
D4     8        q     u        (p
F#4    8        q #   u
G4     8        q     u        )
measure 49
A4     8        q     u        (f
P C33:y10
G4     8        q     u        )
gD4    5        s     u
S C1:pt50
C4     4        e     u  [     (p
B3     4        e     u  =
C4     4        e     u  =
D4     4        e     u  ]     )
measure 50
B3    16        h     u
gD4    5        s     u
S C1:pt50
C4     4        e     u  [     (
B3     4        e     u  =
C4     4        e     u  =
D4     4        e     u  ]     )
measure 51
B3    16        h     u
gD4    5        s     u
S C1:pt50
C4     4        e     u  [     (
B3     4        e     u  =
C4     4        e     u  =
D4     4        e     u  ]     )
measure 52
B3     8        q     u
B4     8        q     u        f
 D4    8        q     u
B4     8        q     u
 D4    8        q     u
 G3    8        q     u
rest   8        q
mheavy4 53      :|:
D4     8        q     u
rest   8        q
G4     8        q     u
rest   8        q
measure 54
B4     8        q     d
rest   8        q
rest  16        h
measure 55
E4     8        q     u
rest   8        q
G4     8        q     u
rest   8        q
measure 56
C5     8        q     d
rest   8        q
rest  16        h
measure 57
F4     8        q     u
rest   8        q
D4     8        q     u
rest   8        q
measure 58
D5     8        q     d
rest   8        q
rest  16        h
measure 59
C5     8        q     d
rest   8        q
A4     8        q     u
E4     8        q     u
measure 60
E4     8        q     u
G#4    8        q #   u
 B3    8        q     u
G#4    8        q     u
 B3    8        q     u
rest   8        q
measure 61
rest   8        q
D4     8        q     u        (p
P C33:y10
C4     8        q     u        )
rest   8        q
measure 62
rest   8        q
D4     8        q     u        (
C4     8        q     u        )
rest   8        q
measure 63
E4     4        e     u  [     .
E4     4        e     u  ]     .
rest   4        e
G4     2        s     u  [[    (
E4     2        s     u  ]]    )
F4     4        e     u  [     .
F4     4        e     u  ]     .
rest   4        e
F5     2        s     d  [[    (
D5     2        s     d  ]]    )
measure 64
C#5    4        e #   u  [     .
E5     4        e     u  =     .
E4     4        e     u  =     .
G4     4        e     u  ]     .
F4     4        e     u  [     .
G4     4        e     u  =     .
F4     4        e     u  =     .
E4     4        e     u  ]     .
measure 65
D4     4        e     u  [     .
D4     4        e     u  ]     .
rest   4        e
F4     2        s     u  [[    (
D4     2        s     u  ]]    )
E4     4        e     u  [     .
E4     4        e     u  ]     .
rest   4        e
E5     2        s     d  [[    (
C5     2        s     d  ]]    )
measure 66
B4     4        e     u  [     .
D5     4        e     u  =     .
D4     4        e     u  =     .
F4     4        e     u  ]     .
E4     4        e     u  [     .
G4     4        e     u  =     .
C5     4        e     u  =     .
G4     4        e     u  ]     .
measure 67
E4     8        q     u
A4    16        h     u
D4     8-       q     u        -
measure 68
D4     8        q     u
G4    16        h     u
C4     8        q     u
measure 69
C4    16        h     u        (f
P C33:y10
D4     8        q     u
Ef4    8        q f   u        )
measure 70
D4     8        q     u
B4     4        e     d  [     (
C5     4        e     d  ]     )
B4     8        q     d
B3     4        e     u  [     (
C4     4        e     u  ]     )
measure 71
B3     2        s     u  [[    .
G4     2        s     u  ==    .p
G4     2        s     u  ==    .
G4     2        s     u  ]]    .
G4     2        s     u  [[    (
B4     2        s     u  ==    )
B4     2        s     u  ==    (
G4     2        s     u  ]]    )
G4     2        s     u  [[    (p
P C33:y10
F4     2        s     u  ==    )
F4     2        s     u  ==    .
F4     2        s     u  ]]    .
F4     2        s     u  [[    (
A4     2        s     u  ==    )
A4     2        s     u  ==    (
C5     2        s     u  ]]    )
measure 72
C5     2        s     d  [[    (
B4     2        s     d  ==    )
B4     2        s     d  ==    .
B4     2        s     d  ]]    .
B4     2        s     u  [[    (
G4     2        s     u  ==    )
G4     2        s     u  ==    (
E4     2        s     u  ]]    )
E4     2        s     u  [[    (
D4     2        s     u  ==    )
D4     2        s     u  ==    .
D4     2        s     u  ]]    .
D4     2        s     u  [[    (
F4     2        s     u  ==    )
F4     2        s     u  ==    (
A4     2        s     u  ]]    )
measure 73
A4     2        s     u  [[    (
G4     2        s     u  ==    )
G4     2        s     u  ==    .
G4     2        s     u  ]]    .
G4     2        s     u  [[    (
E4     2        s     u  ==    )
E4     2        s     u  ==    (
C4     2        s     u  ]]    )
B3     4        e     u  [     (f
P C33:y10
C4     4        e     u  =
B3     4        e     u  =
C4     4        e     u  ]     )
measure 74
B3     8        q     u
rest   8        q
rest  16        h
measure 75
C4    12        q.    u        (p
P C33:y10
B3     4        e     u
C4     8        q     u        )
C4     8        q     u        .
measure 76
C4     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
C4     4        e     u  ]
B3     8        q     u        )
rest   8        q
measure 77
B3    12        q.    u        (
C4     4        e     u
D4     8        q     u        )
D4     8        q     u        .
measure 78
D4     4        e     u  [     (
C4     4        e     u  =
E4     4        e     u  =
D4     4        e     u  ]
C4     8        q     u        )
rest   8        q
measure 79
D4    24        h.    u        (
A4     8        q     u        )
measure 80
A4     8        q     u        (
G4     8        q     u        )
F4     8        q     u        .
E4     8        q     u        .
measure 81
E4     8        q     u        (
D4     8        q     u        )
C4     8        q     u        .
B3     8        q     u        .
measure 82
C4     8        q     u
rest   8        q
rest  16        h
measure 83
C5    12        q.    d        (f
B4     4        e     d
C5     8        q     d        )
C5     8        q     d        .
measure 84
C5     4        e     d  [     (
B4     4        e     d  =
D5     4        e     d  =
C5     4        e     d  ]
B4     8        q     d        )
rest   8        q
measure 85
B4    12        q.    d        (
C5     4        e     d
D5     8        q     d        )
D5     8        q     d        .
measure 86
D5     4        e     d  [     (
C5     4        e     d  =
E5     4        e     d  =
D5     4        e     d  ]
C5     8        q     d        )
rest   8        q
measure 87
E5    12        q.    d
C5     2        s     d  [[
D5     2        s     d  ]]
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
gB5    5        s     u
S C1:t50
A5     4        e     d  [
G5     2        s     d  =[
F5     2        s     d  ]]
measure 88
E5    12        q.    d
C5     2        s     d  [[
D5     2        s     d  ]]
E5     4        e     d  [
F5     2        s     d  =[
G5     2        s     d  ]]
gB5    5        s     u
S C1:t50
A5     4        e     d  [
G5     2        s     d  =[
F5     2        s     d  ]]
measure 89
gF5    5        s     u
S C1:t50
E5     4        e     d  [
D5     2        s     d  =[
C5     2        s     d  ]]
B4     4        e     d  [
C5     4        e     d  ]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
A4     4        e     u  [
B4     4        e     u  ]
measure 90
C5     6        e.    u  [     (
E4     2        s     u  ]\    )
C4     6        e.    u  [     (
F4     2        s     u  ]\    )
E4     8        q     u
D4     8        q     u
measure 91
gF4    5        s     u
S C1:t50
E4     4        e     u  [
D4     2        s     u  =[
C4     2        s     u  ]]
B3     2        s     u  [[    (
C4     2        s     u  ==    )
B3     2        s     u  ==    (
C4     2        s     u  ]]    )
gE4    5        s     u
S C1:t50
D4     4        e     u  [
C4     2        s     u  =[
B3     2        s     u  ]]
A3     2        s     u  [[    (
B3     2        s     u  ==    )
A3     2        s     u  ==    (
B3     2        s     u  ]]    )
measure 92
C4     8        q     u
C4     2        s     u  [[    (
D4     2        s     u  ==
E4     2        s     u  ==
F4     2        s     u  ]]    )
E4     8        q     u        (
D4     8        q     u        )
measure 93
C4    12        q.    u        (
D4     2        s     u  [[
E4     2        s     u  ]]    )
F4     4        e     u  [     (
G4     4        e     u  =
A4     4        e     u  =     )
D5     4        e     u  ]     .
measure 94
C5    16        h     d        (
B4     8        q     d        )
rest   8        q
measure 95
rest  32
measure 96
A5    16        h     d
gG5    5        s     u
S C1:t25
F5     8        q     d
gE5    5        s     u
S C1:t25
D5     8        q     d
measure 97
C5     4        e     d  [     (
B4     4        e     d  =
D5     4        e     d  =
C5     4        e     d  ]     )
B4     8        q     d
rest   8        q
measure 98
G5    16        h     d
gF5    5        s     u
S C1:t25
E5     8        q     d
gD5    5        s     u
S C1:t25
C5     8        q     d
measure 99
C5     8        q     d
rest   8        q
C4     6        e.    u  [
C5     2        s     u  ]\
C5     6        e.    d  [     (t
S C33:n6s17t84
B4     1        t     d  =[[
C5     1        t     d  ]]]   )
measure 100
C4    16-       h     u        -
C4     2        s     u  [[
C5     2        s     u  ==    (
B4     2        s     u  ==
C5     2        s     u  ]]
D5     2        s     d  [[
C5     2        s     d  ==
B4     2        s     d  ==
C5     2        s     d  ]]    )
measure 101
C4     8        q     u
rest   8        q
C4     6        e.    u  [
C5     2        s     u  ]\
C5     6        e.    d  [     (t
S C33:n6s17t84
B4     1        t     d  =[[
C5     1        t     d  ]]]   )
measure 102
C4    16-       h     u        -
C4     2        s     u  [[
C5     2        s     u  ==    (
B4     2        s     u  ==
C5     2        s     u  ]]
D5     2        s     d  [[
C5     2        s     d  ==
B4     2        s     d  ==
C5     2        s     d  ]]    )
measure 103
C4     4        e     u  [
C4     4        e     u  =
C4     4        e     u  =
C4     4        e     u  ]
C4     4        e     u  [
C4     4        e     u  =
A4     4        e     u  =
A4     4        e     u  ]
measure 104
gE4    5        s     u
S C1:t50
D4     4        e     u  [
C4     2        s     u  =[
B3     2        s     u  ]]
B3     4        e     u  [
B3     4        e     u  ]
B3     8        q     u
rest   8        q
measure 105
rest   8        q
F4     8        q     u        (p
P C33:y10
E4     8        q     u        )
rest   8        q
measure 106
rest   8        q
F4     8        q     u        (
E4     8        q     u        )
rest   8        q
measure 107
C4     4        e     u  [     .
C4     4        e     u  ]     .
rest   4        e
D4     2        s     u  [[    (
B3     2        s     u  ]]    )
C4     4        e     u  [     .
G3     4        e     u  =     .
C4     4        e     u  =     .
D4     4        e     u  ]     .
measure 108
E4     4        e     u  [     .
E4     4        e     u  ]     .
rest   4        e
F4     2        s     u  [[    (
D4     2        s     u  ]]    )
E4     4        e     u  [     .
C4     4        e     u  =     .
G4     4        e     u  =     .
F4     4        e     u  ]     .
measure 109
E4     8        q     u
A4    16        h     u
D4     8-       q     u        -
measure 110
D4     8        q     u
G4    16        h     u
C4     8        q     u
measure 111
A4    12        q.    u        (
F4     4        e     u        )
E4     4        e     u  [     (
G4     4        e     u  =     )
F4     4        e     u  =     (
D4     4        e     u  ]     )
measure 112
C4     8        q     u
rest   8        q
rest  16        h
measure 113
C#4    8        q #   u        (
E4     8        q     u        )
F4     4        e     u  [     (
E4     4        e     u  =
D4     4        e     u  =
C4     4        e n   u  ]     )
measure 114
B3     8        q     u        (
D4     8        q     u        )
E4     4        e     u  [     (
D4     4        e     u  =
C4     4        e     u  =
B3     4        e     u  ]     )
measure 115
A3     8        q     u        (
F4     8        q     u        )
E4     8        q     u        (
D4     8        q     u        )
measure 116
C4     8        q     u        f
rest   8        q
G3     8        q     u
rest   8        q
measure 117
G3     8        q     u
rest   8        q
D4     8        q     u        (
F4     8        q     u        )
measure 118
E4     8        q     u
rest   8        q
G4     8        q     u
rest   8        q
measure 119
G4     8        q     u
rest   8        q
A4     8        q     u        (
F4     8        q     u        )
measure 120
E4     8        q     u
G4     8        q     u        (p
B4     8        q     d
C5     8        q     d        )
measure 121
D5     8        q     d        (f
C5     8        q     d        )
gG4    5        s     u
S C1:pt50
F4     4        e     u  [     (p
E4     4        e     u  =
F4     4        e     u  =
G4     4        e     u  ]     )
measure 122
E4     8        q     u
G3     8        q     u        (
B3     8        q     u
C4     8        q     u        )
measure 123
D4     8        q     u        (f
P C33:y15
C4     8        q     u        )
B3    16        h     u        (p
measure 124
C4    16        h     u
B3    16        h     u
measure 125
C4    16        h     u
B3    16        h     u        )
measure 126
C4     8        q     u
E5     8        q     d        f
 C5    8        q     d
E5     8        q     d
 C5    8        q     d
 G4    8        q     d
rest   8        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/01/03} [KHM:2017828942]
TIMESTAMP: DEC/26/2001 [md5sum:95ba76fbdb66a77ca8a641934ec0263e]
02/17/94 E. Correia
WK#:157       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:0   Q:8   T:1/1  C:13
G3    32-       w     u        -p
P C33:y10
measure 2
G3    16-       h     u        -
G3     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
B3     4        e     u  ]     )
measure 3
G3    32-       w     u        -
measure 4
G3    16-       h     u        -
P C32:u
G3     4        e     d  [
E4     4        e     d  =     (
G4     4        e     d  =
E4     4        e     d  ]     )
measure 5
C4    16        h     d        (
A3     8        q     u
D4     8        q     d        )
measure 6
G3    16        h     u
rest  16        h
measure 7
G3    16        h     u
rest  16        h
measure 8
rest   4        e
E3     4        e     u  [     .f
F3     4        e     u  =     .
G3     4        e     u  ]     .
A3     4        e     u  [     .
B3     4        e     u  =     .
C4     4        e     u  =     .
D4     4        e     u  ]     .
measure 9
E4     4        e     d
G4     8        q     d
G4     8        q     d
G4     8        q     d
G4     4-       e     d        -
measure 10
G4     4        e     d
G4     8        q     d
G4     8        q     d
G4     4        e     d  [     (
F#4    4        e #   d  =
G4     4        e     d  ]     )
measure 11
G3     4        e     u
G4     8        q     d
G4     8        q     d
G4     8        q     d
G4     4-       e     d        -
measure 12
G4     4        e     d
G4     8        q     d
G4     8        q     d
C5     4        e     d  [     (
B4     4        e     d  =
C5     4        e     d  ]     )
measure 13
C4     8        q     d
rest   8        q
rest   4        e
C4     4        e     d  [     (
B3     4        e     d  =
C4     4        e     d  ]     )
measure 14
C3     8        q     u
rest   8        q
rest   4        e
C5     4        e     d  [     (
B4     4        e     d  =
C5     4        e     d  ]     )
measure 15
C4     4        e     d        .
G4     4        e     d  [     (
F4     4        e     d  =
E4     4        e     d  ]     )
rest   4        e
F4     4        e     d  [     (
E4     4        e     d  =
D4     4        e     d  ]     )
measure 16
C4     8        q     d
rest   4        e
A3     4        e     u
G3    16        h     u
measure 17
rest   4        e
G3     4        e     u  [     (
F3     4        e     u  =
E3     4        e     u  ]     )
rest   4        e
F3     4        e     u  [     (
E3     4        e     u  =
D3     4        e     u  ]     )
measure 18
C3     8        q     u
rest   4        e
A3     4        e     u
G3    16        h     u
measure 19
G3     4        e     u  [
G3     4        e     u  =
E3     4        e     u  =
E3     4        e     u  ]
C4     4        e     d  [     (
E4     4        e     d  =
F4     4        e     d  =
A4     4        e     d  ]     )
measure 20
G4     4        e     d  [
G4     4        e     d  =
G4     4        e     d  =
G4     4        e     d  ]
G3     4        e     d  [
G4     4        e     d  =
D4     4        e     d  =
B3     4        e     d  ]
measure 21
G3     8        q     u
rest   8        q
rest  16        h
measure 22
rest   8        q
A3     8        q     u        (
E4     8        q     d
C4     8        q     d        )
measure 23
D4     8        q     d
rest   8        q
rest  16        h
measure 24
rest   8        q
G3     8        q     u        (
D4     8        q     d
B3     8        q     u        )
measure 25
C4     2        s     d  [[    (
D4     2        s     d  ==
C4     2        s     d  ==
B3     2        s     d  ]]
C4     2        s     d  [[
D4     2        s     d  ==
E4     2        s     d  ==
C4     2        s     d  ]]    )
B3    16        h     u
measure 26
E4     6        e.    d  [     (
G4     2        s     d  ]\    )
G4     6        e.    d  [     (t
S C33:n6s17t84
F#4    1        t #   d  =[[
G4     1        t     d  ]]]   )
D4    12        q.    d        (
B3     4        e     u        )
measure 27
C4     2        s     d  [[    (
D4     2        s     d  ==
C4     2        s     d  ==
B3     2        s     d  ]]
C4     2        s     d  [[
E4     2        s     d  ==
D4     2        s     d  ==
C4     2        s     d  ]]    )
B3    16        h     u
measure 28
E4     6        e.    d  [     (
G4     2        s     d  ]\    )
G4     6        e.    d  [     (t
S C33:n6s17t84
F#4    1        t #   d  =[[
G4     1        t     d  ]]]   )
D4    12        q.    d        (
B3     4        e     u        )
measure 29
E4     4        e     d  [
E4     4        e     d  =
E4     4        e     d  =
E4     4        e     d  ]
E4     4        e     d  [
E4     4        e     d  =
A4     4        e     d  =
A4     4        e     d  ]
measure 30
A4     8        q     d
F#4    8        q #   d
A3     8        q     u
rest   8        q
measure 31
rest   8        q
A4     8        q     d        (p
G4     8        q     d        )
rest   8        q
measure 32
rest   8        q
A4     8        q     d        (
G4     8        q     d        )
rest   8        q
measure 33
B3     4        e     u  [     .
B3     4        e     u  ]     .
rest   4        e
C4     2        s     u  [[    (
A3     2        s     u  ]]    )
B3     4        e     d  [     .
B3     4        e     d  =     .
D4     4        e     d  =     .
F#4    4        e #   d  ]     .
measure 34
G4     4        e     d  [     .
G4     4        e     d  ]     .
rest   4        e
A4     2        s     d  [[    (
F#4    2        s #   d  ]]    )
G4     4        e     d  [     .
D4     4        e     d  =     .
B4     4        e     d  =     .
A4     4        e     d  ]     .
measure 35
G#4    8        q #   d        (
B4     8        q     d        )
C5     4        e     d  [     (
B4     4        e     d  =
A4     4        e     d  =
G4     4        e n   d  ]     )
measure 36
F#4    8        q #   d        (
A4     8        q     d        )
B4     4        e     d  [     (
A4     4        e     d  =
G4     4        e     d  =
F#4    4        e     d  ]     )
measure 37
E4     4        e     d  [
E4     4        e     d  =
E4     4        e     d  =
E4     4        e     d  ]
D4     4        e     d  [
D4     4        e     d  =
C4     4        e     d  =
C4     4        e     d  ]
measure 38
B3     8        q     u
rest   8        q
rest  16        h
measure 39
B3     8        q     u
E4    16        h     d
A3     8-       q     u        -
measure 40
A3     8        q     u
D4    16        h     d
G3     8-       q     u        -
measure 41
G3    12        q.    u        (
E3     4        e     u        )
D3    16        h     u
measure 42
D3     8        q     u        f
rest   8        q
D4     8        q     d
rest   8        q
measure 43
D4     8        q     d
rest   8        q
A3    16        h     u
measure 44
G3     8        q     u
rest   8        q
C4     8        q     d
rest   8        q
measure 45
B3     8        q     u
rest   8        q
A3    16        h     u
measure 46
G3     8        q     u
D4     8        q     d        (p
F#4    8        q #   d
G4     8        q     d        )
measure 47
E4     8        q     d        (f
D4     8        q     d        )
gD4    5        s     u
S C1:pt50
C4     4        e     d  [     (p
B3     4        e     d  =
C4     4        e     d  =
D4     4        e     d  ]     )
measure 48
B3     8        q     u
B3     8        q     u        (p
C4     8        q     d
D4     8        q     d        )
measure 49
D4    16        h     d        f
F#3   16        h #   u        (p
P C33:y5
measure 50
G3    16        h     u        )
F#4   16        h #   d        (
measure 51
G4    16        h     d        )
F#3   16        h #   u        (
measure 52
G3     8        q     u        )
D4     8        q     d        f
D4     8        q     u
 G3    8        q     u
rest   8        q
mheavy4 53      :|:
B3     8        q     u
rest   8        q
D4     8        q     d
rest   8        q
measure 54
G4     8        q     d
rest   8        q
rest  16        h
measure 55
C4     8        q     d
rest   8        q
E4     8        q     d
rest   8        q
measure 56
E4     8        q     d
rest   8        q
rest  16        h
measure 57
D4     8        q     d
rest   8        q
B3     8        q     u
rest   8        q
measure 58
B3     8        q     u
rest   8        q
rest  16        h
measure 59
A4     8        q     d
rest   8        q
C4     8        q     d
C4     8        q     d
measure 60
B3     8        q     u
E3     8        q     u
E3     8        q     u
rest   8        q
measure 61
rest   8        q
B3     8        q     u        (p
A3     8        q     u        )
rest   8        q
measure 62
rest   8        q
B3     8        q     u        (
A3     8        q     u        )
rest   8        q
measure 63
C#4    4        e #   d  [     .
C#4    4        e     d  ]     .
rest   4        e
E4     2        s     d  [[    (
C#4    2        s     d  ]]    )
D4     4        e     d  [     .
D4     4        e     d  ]     .
rest   4        e
A4     2        s     d  [[    (
F4     2        s     d  ]]    )
measure 64
E4     4        e     d  [     .
G4     4        e     d  =     .
C#4    4        e #   d  =     .
E4     4        e     d  ]     .
D4     4        e     d  [     .
E4     4        e     d  =     .
D4     4        e     d  =     .
C4     4        e n   d  ]     .
measure 65
B3     4        e     u  [     .
B3     4        e     u  ]     .
rest   4        e
D4     2        s     d  [[    (
B3     2        s     d  ]]    )
C4     4        e     d  [     .
C4     4        e     d  ]     .
rest   4        e
G4     2        s     d  [[    (
E4     2        s     d  ]]    )
measure 66
D4     4        e     d  [     .
F4     4        e     d  =     .
B3     4        e     d  =     .
D4     4        e     d  ]     .
C4     4        e     d  [     .
E4     4        e     d  =     .
G4     4        e     d  =     .
E4     4        e     d  ]     .
measure 67
C#4    4        e #   d  [     .
C#4    4        e     d  ]     .
rest   4        e
E4     2        s     d  [[    (
C#4    2        s     d  ]]    )
F4     4        e     d  [     (
E4     4        e     d  =
D4     4        e     d  =
C4     4        e n   d  ]     )
measure 68
B3     4        e     u  [     .
B3     4        e     u  ]     .
rest   4        e
D4     2        s     d  [[    (
B3     2        s     d  ]]    )
E4     4        e     d  [     (
D4     4        e     d  =
C4     4        e     d  =
B3     4        e     d  ]     )
measure 69
A3     4        e     u  [     f
A3     4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
A3     4        e     u  [
A3     4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
measure 70
B3     8        q     u
rest   4        e
G4     4        e     d
G4     4        e     d  [
G3     4        e     d  ]
rest   4        e
G3     4        e     u
measure 71
G3     8        q     u
rest   4        e
D4     4        e     d        (p
C4     8        q     d        )
rest   4        e
A4     4        e     d        (
measure 72
G4     8        q     d        )
rest   4        e
B3     4        e     u        (
A3     8        q     u        )
rest   4        e
B3     4        e     u        (
P C32:u
measure 73
C4     8        q     d        )
rest   8        q
G4     8        q     d        f
 G3    8        q     d
G4     8        q     d
 G3    8        q     d
measure 74
G4     8        q     d
 G3    8        q     d
rest   8        q
rest  16        h
measure 75
G3    32-       w     u        -p
P C33:y10
measure 76
G3    16-       h     u        -
G3     4        e     u  [     (
B3     4        e     u  =
D4     4        e     u  =
B3     4        e     u  ]     )
measure 77
G3    32-       w     u        -
measure 78
G3    16-       h     u        -
P C32:u
G3     4        e     d  [
E4     4        e     d  =     (
G4     4        e     d  =
E4     4        e     d  ]     )
measure 79
C4    16        h     d        (
A3     8        q     u        )
D4     8        q     d        .
measure 80
G3    16        h     u
rest  16        h
measure 81
G3    16        h     u
rest  16        h
measure 82
rest   4        e
E3     4        e     u  [     .f
F3     4        e     u  =     .
G3     4        e     u  ]     .
A3     4        e     u  [     .
B3     4        e     u  =     .
C4     4        e     u  =     .
D4     4        e     u  ]     .
measure 83
E4     4        e     d
G4     8        q     d
G4     8        q     d
G4     8        q     d
G4     4-       e     d        -
measure 84
G4     4        e     d
G4     8        q     d
G4     8        q     d
G4     4        e     d  [     (
F#4    4        e #   d  =
G4     4        e     d  ]     )
measure 85
G3     4        e     u
G4     8        q     d
G4     8        q     d
G4     8        q     d
G4     4-       e     d        -
measure 86
G4     4        e     d
G4     8        q     d
G4     8        q     d
C5     4        e     d  [     (
B4     4        e     d  =
C5     4        e     d  ]     )
measure 87
C4     8        q     d
rest   8        q
rest   4        e
C4     4        e     d  [     (
B3     4        e     d  =
C4     4        e     d  ]     )
measure 88
C3     8        q     u
rest   8        q
rest   4        e
C5     4        e     d  [     (
B4     4        e     d  =
C5     4        e     d  ]     )
measure 89
C4     4        e     d
G4     4        e     d  [     (
F4     4        e     d  =
E4     4        e     d  ]     )
rest   4        e
F4     4        e     d  [     (
E4     4        e     d  =
D4     4        e     d  ]     )
measure 90
C4     8        q     d
rest   4        e
A3     4        e     u
G3    16        h     u
measure 91
rest   4        e
G3     4        e     u  [     (
F3     4        e     u  =
E3     4        e     u  ]     )
rest   4        e
F3     4        e     u  [     (
E3     4        e     u  =
D3     4        e     u  ]     )
measure 92
C3     8        q     u
rest   4        e
A3     4        e     u
G3    16        h     u
measure 93
G3     4        e     u  [
G3     4        e     u  =
E3     4        e     u  =
E3     4        e     u  ]
C4     4        e     d  [     (
E4     4        e     d  =
F4     4        e     d  =     )
A4     4        e     d  ]     .
measure 94
G4     4        e     d  [
G4     4        e     d  =
G4     4        e     d  =
G4     4        e     d  ]
G3     4        e     d  [
F4     4        e     d  =
E4     4        e     d  =
D4     4        e     d  ]
measure 95
C#4    4        e #   d  [
C#4    4        e     d  =
C#4    4        e     d  =
C#4    4        e     d  ]
Bf4    4        e f   d  [
Bf4    4        e     d  =
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 96
A4     4        e     d  [
A4     4        e     d  =
A4     4        e     d  =
A4     4        e     d  ]
A3     4        e     u  [
A3     4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
measure 97
D4     4        e     d  [
D4     4        e     d  =
D4     4        e     d  =
D4     4        e     d  ]
B4     4        e n   d  [     +
B4     4        e     d  =
B4     4        e     d  =
B4     4        e     d  ]
measure 98
G4     4        e     d  [
G4     4        e     d  =
G4     4        e     d  =
G4     4        e     d  ]
G4     4        e     d  [
G4     4        e     d  =
G4     4        e     d  =
G4     4        e     d  ]
measure 99
F4     2        s     d  [[    (
G4     2        s     d  ==
F4     2        s     d  ==
E4     2        s     d  ]]
F4     2        s     d  [[
G4     2        s     d  ==
A4     2        s     d  ==
F4     2        s     d  ]]    )
E4    16        h     d
measure 100
A4     6        e.    d  [     (
C5     2        s     d  ]\    )
C5     6        e.    d  [     (t
S C33:n6s17t84
B4     1        t     d  =[[
C5     1        t     d  ]]]   )
G4    12        q.    d        (
E4     4        e     d        )
measure 101
F4     2        s     d  [[    (
G4     2        s     d  ==
F4     2        s     d  ==
E4     2        s     d  ]]
F4     2        s     d  [[
G4     2        s     d  ==
A4     2        s     d  ==
F4     2        s     d  ]]    )
E4     8        q     d        (
G3     8        q     u        )
measure 102
A3     6        e.    u  [     (
C4     2        s     u  ]\    )
C4     6        e.    u  [     (t
S C33:n6s17t84
B3     1        t     u  =[[
C4     1        t     u  ]]]   )
G3    12        q.    u        (
E4     4        e     d        )
measure 103
A3     4        e     u  [
A3     4        e     u  =
A3     4        e     u  =
A3     4        e     u  ]
A3     4        e     u  [
A3     4        e     u  =
D4     4        e     u  =
D4     4        e     u  ]
measure 104
D4     8        q     d
D4     8        q     d
D4     8        q     u
 G3    8        q     u
rest   8        q
measure 105
rest   8        q
D4     8        q     d        (p
C4     8        q     d        )
rest   8        q
measure 106
rest   8        q
D4     8        q     d        (
C4     8        q     d        )
rest   8        q
measure 107
E3     4        e     u  [     .
E3     4        e     u  ]     .
rest   4        e
F3     2        s     u  [[    (
D3     2        s     u  ]]    )
E3     8        q     u
G3     4        e     u  [     .
B3     4        e     u  ]     .
measure 108
C4     4        e     d  [     .
C4     4        e     d  ]     .
rest   4        e
D4     2        s     d  [[    (
B3     2        s     d  ]]    )
C4     4        e     u  [     .
G3     4        e     u  =     .
E4     4        e     u  =     .
D4     4        e     u  ]     .
measure 109
C#4    8        q #   d        (
E4     8        q     d        )
F4     4        e     d  [     (
E4     4        e     d  =
D4     4        e     d  =
C4     4        e n   d  ]     )
measure 110
B3     8        q     u        (
D4     8        q     d        )
E4     4        e     d  [     (
D4     4        e     d  =
C4     4        e     d  =
B3     4        e     d  ]     )
measure 111
C4    12        q.    d        (
A3     4        e     u        )
G3     4        e     d  [     .
E4     4        e     d  =     (
D4     4        e     d  =
F4     4        e     d  ]     )
measure 112
E4     8        q     d
rest   8        q
rest  16        h
measure 113
E3     8        q     u
A3    16        h     u
D3     8-       q     u        -
measure 114
D3     8        q     u
G3    16        h     u
C3     8-       q     u        -
measure 115
C3     8        q     u        (
A3     8        q     u        )
G3     8        q     u        (
F3     8        q     u        )
measure 116
E3     8        q     u        f
rest   8        q
F3     8        q     u
rest   8        q
measure 117
E3     8        q     u
rest   8        q
A3     8        q     u        (
D4     8        q     d        )
measure 118
C4     8        q     d
rest   8        q
F4     8        q     d
rest   8        q
measure 119
E4     8        q     d
rest   8        q
D4    16        h     d
measure 120
C4     8        q     d
E4     8        q     d        (p
F4     8        q     d
G4     8        q     d        )
measure 121
G4    16        h     d        f
B3    16        h     u        (p
measure 122
C4     8        q     d        )
E3     8        q     u        (
F3     8        q     u
G3     8        q     u        )
measure 123
A3     8        q     u        (f
P C33:y12
G3     8        q     u        )
gG3    5        s     u
S C1:pt50
F3     4        e     u  [     (p
E3     4        e     u  =
F3     4        e     u  =
G3     4        e     u  ]     )
measure 124
E3    16        h     u
gG3    5        s     u
S C1:pt50
F3     4        e     u  [     (
E3     4        e     u  =
F3     4        e     u  =
G3     4        e     u  ]     )
measure 125
E3    16        h     u
gG3    5        s     u
S C1:pt50
F3     4        e     u  [     (
E3     4        e     u  =
F3     4        e     u  =
G3     4        e     u  ]     )
measure 126
E3     8        q     u
G3     8        q     u        f
P C32:y10
C4     8        q     d
rest   8        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/01/04} [KHM:2017828942]
TIMESTAMP: DEC/26/2001 [md5sum:6356c2d7a09dfdb374e53451f1fc27e5]
02/17/94 E. Correia
WK#:157       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:0   Q:4   T:1/1  C:22
C3     2        e     u  [     p
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
measure 2
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     4        q     u
rest   4        q
measure 3
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 4
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
C3     4        q     u
rest   4        q
measure 5
F#3    2        e #   d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 6
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 7
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 8
C3     2        e     u
C3     2        e     d  [     .f
D3     2        e     d  =     .
E3     2        e     d  ]     .
F3     2        e n   d  [     .+
G3     2        e     d  =     .
A3     2        e     d  =     .
B3     2        e     d  ]     .
measure 9
C4     4        q     d
G3     4        q     d
E3     4        q     d
C3     4        q     u
measure 10
G3     4        q     d
G2     4        q     u
rest   8        h
measure 11
G3     4        q     d
D3     4        q     d
B2     4        q     u
G2     4        q     u
measure 12
C3     4        q     u
C4     4        q     d
rest   8        h
measure 13
rest   2        e
C4     2        e     d  [     (
B3     2        e     d  =
C4     2        e     d  ]     )
C3     4        q     u
rest   4        q
measure 14
rest   2        e
C3     2        e     u  [     (
B2     2        e     u  =
C3     2        e     u  ]     )
C2     4        q     u
rest   4        q
measure 15
C3     4        q     u
rest   4        q
G3     4        q     d
rest   4        q
measure 16
C4     4        q     d        (
F3     4        q     d        )
G3     4        q     d        (
G2     4        q     u        )
measure 17
C3     4        q     u
rest   4        q
G2     4        q     u
rest   4        q
measure 18
C3     4        q     u        (
F2     4        q     u        )
G2     4        q     u        (
F3     4        q     d        )
measure 19
E3     2        e     d  [
E3     2        e     d  =
C3     2        e     d  =
C3     2        e     d  ]
A3     2        e     d  [     (
G3     2        e     d  =
F3     2        e     d  =
D3     2        e     d  ]     )
measure 20
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G2     4        q     u
rest   4        q
measure 21
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 22
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 23
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 24
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 25
C3     4        q     u
rest   4        q
B2     4        q     u
rest   4        q
measure 26
E3     4        q     d
rest   4        q
D3     4        q     d
rest   4        q
measure 27
C3     4        q     u
rest   4        q
B2     4        q     u
rest   4        q
measure 28
E3     4        q     d
rest   4        q
D3     4        q     d
rest   4        q
measure 29
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
C3     2        e     u  [
C3     2        e     u  =
C#3    2        e #   u  =
C#3    2        e     u  ]
measure 30
D3     4        q     d
D3     4        q     d
D3     4        q     d
rest   4        q
measure 31
rest   4        q
D3     4        q     d        (p
G2     4        q     u        )
rest   4        q
measure 32
rest   4        q
D3     4        q     d        (
G2     4        q     u        )
rest   4        q
measure 33
G3     4        q     d
D3     4        q     d
G2     4        q     u
rest   4        q
measure 34
G3     4        q     d
D3     4        q     d
G2     4        q     u
rest   4        q
measure 35
E3     2        e     d  [     .
E3     2        e     d  ]     .
rest   2        e
G#3    1        s #   d  [[    (
E3     1        s     d  ]]    )
A3     2        e     d  [     (
G3     2        e n   d  =
F#3    2        e #   d  =
E3     2        e     d  ]     )
measure 36
D3     2        e     d  [     .
D3     2        e     d  ]     .
rest   2        e
F#3    1        s #   d  [[    (
D3     1        s     d  ]]    )
G3     2        e     d  [     (
F#3    2        e     d  =
E3     2        e     d  =
D3     2        e     d  ]     )
measure 37
C3     2        e n   u  [     +
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 38
G3     4        q     d
rest   4        q
rest   8        h
measure 39
E3     2        e     d  [     .
E3     2        e     d  ]     .
rest   2        e
G#3    1        s #   d  [[    (
E3     1        s     d  ]]    )
A3     2        e     d  [     (
G3     2        e n   d  =
F#3    2        e #   d  =
E3     2        e     d  ]     )
measure 40
D3     2        e     d  [     .
D3     2        e     d  ]     .
rest   2        e
F#3    1        s #   d  [[    (
D3     1        s     d  ]]    )
G3     2        e     d  [     (
F#3    2        e     d  =
E3     2        e     d  =
D3     2        e     d  ]     )
measure 41
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
D3     2        e     d  [
D3     2        e     d  =
D3     2        e     d  =
D3     2        e     d  ]
measure 42
G2     4        q     u        f
rest   4        q
F#2    4        q #   u
rest   4        q
measure 43
G2     4        q     u
rest   4        q
C3     4        q     u
D3     4        q     d
measure 44
G2     4        q     u
rest   4        q
F#2    4        q #   u
rest   4        q
measure 45
G2     4        q     u
rest   4        q
C3     4        q     u        (
D3     4        q     d        )
measure 46
G2     4        q     u
B3     4        q     d        (p
A3     4        q     d
G3     4        q     d        )
measure 47
F#3    4        q #   d        (f
G3     4        q     d        )
D3     4        q     d        p
D3     4        q     d
measure 48
G2     4        q     u
B3     4        q     d        (p
A3     4        q     d
G3     4        q     d        )
measure 49
F#3    4        q #   d        (f
G3     4        q     d        )
D3     4        q     d        p
D3     4        q     d
measure 50
G2    16-       w     u        -
measure 51
G2    16-       w     u        -
measure 52
G2     4        q     u
G3     4        q     d        f
G2     4        q     u
rest   4        q
mheavy4 53      :|:
G3     4        q     d
rest   4        q
G3     4        q     d
rest   4        q
measure 54
G3     4        q     d
rest   4        q
rest   8        h
measure 55
G3     4        q     d
rest   4        q
G3     4        q     d
rest   4        q
measure 56
G3     4        q     d
rest   4        q
rest   8        h
measure 57
G3     4        q     d
rest   4        q
G3     4        q     d
rest   4        q
measure 58
G#3    4        q #   d
rest   4        q
rest   8        h
measure 59
A3     4        q     d
rest   4        q
A2     4        q     u
A2     4        q     u
measure 60
E3     4        q     d
E2     4        q     u
E2     4        q     u
rest   4        q
measure 61
rest   4        q
E3     4        q     d        (p
A2     4        q     u        )
rest   4        q
measure 62
rest   4        q
E3     4        q     d        (
A2     4        q     u        )
rest   4        q
measure 63
rest   4        q
A3     4        q     d
F3     4        q     d
D3     4        q     d
measure 64
A2     4        q     u
A3     4        q     d
D3     4        q     d
F3     4        q     d
measure 65
G2     4        q     u
G3     4        q     d
E3     4        q     d
C3     4        q     u
measure 66
G2     4        q     u
G3     4        q     d
C3     4        q     u
E3     4        q     d
measure 67
A3     2        e     d  [     .
A3     2        e     d  ]     .
rest   2        e
C#4    1        s #   d  [[    (
A3     1        s     d  ]]    )
D4     2        e     d  [     (
C4     2        e n   d  =
B3     2        e     d  =
A3     2        e     d  ]     )
measure 68
G3     2        e     d  [     .
G3     2        e     d  ]     .
rest   2        e
B3     1        s     d  [[    (
G3     1        s     d  ]]    )
C4     2        e     d  [     (
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]     )
measure 69
F#3    2        e #   d  [     f
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 70
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 71
G3     2        e     d  [     fp
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
A3     2        e     d  [
A3     2        e     d  =
A3     2        e     d  =
A3     2        e     d  ]
measure 72
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
F3     2        e n   d  [     +
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 73
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
D3     2        e     u  [     (f
C3     2        e     u  =
D3     2        e     u  =
C3     2        e     u  ]     )
measure 74
D3     4        q     d
rest   4        q
rest   8        h
measure 75
C3     2        e     u  [     p
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
measure 76
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     4        q     u
rest   4        q
measure 77
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 78
C3     2        e     u  [
C3     2        e     u  =
C3     2        e     u  =
C3     2        e     u  ]
C3     4        q     u
rest   4        q
measure 79
F#3    2        e #   d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
F#3    2        e     d  [
F#3    2        e     d  =
F#3    2        e     d  =
F#3    2        e     d  ]
measure 80
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 81
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 82
C3     2        e     u
C3     2        e     d  [     .f
D3     2        e     d  =     .
E3     2        e     d  ]     .
F3     2        e n   d  [     .+
G3     2        e     d  =     .
A3     2        e     d  =     .
B3     2        e     d  ]     .
measure 83
C4     4        q     d
G3     4        q     d
E3     4        q     d
C3     4        q     u
measure 84
G3     4        q     d
G2     4        q     u
rest   8        h
measure 85
G3     4        q     d
D3     4        q     d
B2     4        q     u
G2     4        q     u
measure 86
C3     4        q     u
C4     4        q     d
rest   8        h
measure 87
rest   2        e
C4     2        e     d  [     (
B3     2        e     d  =
C4     2        e     d  ]     )
C3     4        q     u
rest   4        q
measure 88
rest   2        e
C3     2        e     u  [     (
B2     2        e     u  =
C3     2        e     u  ]     )
C2     4        q     u
rest   4        q
measure 89
C3     4        q     u
rest   4        q
G3     4        q     d
rest   4        q
measure 90
C4     4        q     d        (
F3     4        q     d        )
G3     4        q     d        (
G2     4        q     u        )
measure 91
C3     4        q     u
rest   4        q
G2     4        q     u
rest   4        q
measure 92
C3     4        q     u        (
F2     4        q     u        )
G2     4        q     u        (
F3     4        q     d        )
measure 93
E3     2        e     d  [
E3     2        e     d  =
C3     2        e     d  =
C3     2        e     d  ]
A3     2        e     d  [     (
G3     2        e     d  =
F3     2        e     d  =     )
D3     2        e     d  ]     .
measure 94
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G2     4        q     u
rest   4        q
measure 95
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 96
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 97
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
measure 98
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
E3     2        e     d  [
E3     2        e     d  =
E3     2        e     d  =
E3     2        e     d  ]
measure 99
F3     4        q     d
rest   4        q
E3     4        q     d
rest   4        q
measure 100
A3     4        q     d
rest   4        q
G3     4        q     d
rest   4        q
measure 101
F3     4        q     d
rest   4        q
E3     4        q     d
rest   4        q
measure 102
A3     4        q     d
rest   4        q
G3     4        q     d
rest   4        q
measure 103
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
F3     2        e     d  [
F3     2        e     d  =
F#3    2        e #   d  =
F#3    2        e     d  ]
measure 104
G3     4        q     d
G2     4        q     u
G2     4        q     u
rest   4        q
measure 105
rest   4        q
G3     4        q     d        (p
C3     4        q     u        )
rest   4        q
measure 106
rest   4        q
G3     4        q     d        (
C3     4        q     u        )
rest   4        q
measure 107
C3     4        q     u
G2     4        q     u
C2     4        q     u
rest   4        q
measure 108
C2     4        q     u
G2     4        q     u
C3     4        q     u
rest   4        q
measure 109
A3     2        e     d  [     .
A3     2        e     d  ]     .
rest   2        e
C#4    1        s #   d  [[    (
A3     1        s     d  ]]    )
D4     2        e     d  [     (
C4     2        e n   d  =
B3     2        e     d  =
A3     2        e     d  ]     )
measure 110
G3     2        e     d  [     .
G3     2        e     d  ]     .
rest   2        e
B3     1        s     d  [[    (
G3     1        s     d  ]]    )
C4     2        e     d  [     (
B3     2        e     d  =
A3     2        e     d  =
G3     2        e     d  ]     )
measure 111
F3     2        e     d  [
F3     2        e     d  =
F3     2        e     d  =
F3     2        e     d  ]
G3     2        e     d  [
G3     2        e     d  =
G3     2        e     d  =
G3     2        e     d  ]
measure 112
C3     4        q     u
rest   4        q
rest   8        h
measure 113
A2     2        e     u  [     .
A2     2        e     u  ]     .
rest   2        e
C#3    1        s #   u  [[    (
A2     1        s     u  ]]    )
D3     2        e     u  [     (
C3     2        e n   u  =
B2     2        e     u  =
A2     2        e     u  ]     )
measure 114
G2     2        e     u  [     .
G2     2        e     u  ]     .
rest   2        e
B2     1        s     u  [[    (
G2     1        s     u  ]]    )
C3     2        e     u  [     (
B2     2        e     u  =
A2     2        e     u  =
G2     2        e     u  ]     )
measure 115
F2     2        e     u  [
F2     2        e     u  =
F2     2        e     u  =
F2     2        e     u  ]
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  =
G2     2        e     u  ]
measure 116
C3     4        q     u        f
rest   4        q
B2     4        q     u
rest   4        q
measure 117
C3     4        q     u
rest   4        q
F3     4        q     d        (
G3     4        q     d        )
measure 118
C3     4        q     u
rest   4        q
B2     4        q     u
rest   4        q
measure 119
C3     4        q     u
rest   4        q
F3     4        q     d
G3     4        q     d
measure 120
C3     4        q     u
E4     4        q     d        (p
D4     4        q     d
C4     4        q     d        )
measure 121
B3     4        q     d        (f
C4     4        q     d        )
G3     4        q     d        p
G2     4        q     u
measure 122
C3     4        q     u
E3     4        q     d        (
D3     4        q     d
C3     4        q     u        )
measure 123
B2     4        q     u        (f
P C33:y10
C3     4        q     u        )
G2     4        q     u        p
G2     4        q     u
measure 124
C2    16-       w     u        -
measure 125
C2    16-       w     u        -
measure 126
C2     4        q     u
C3     4        q     u        f
P C32:y10
C2     4        q     u
rest   4        q
mheavy2         :|
/END
/eof
//
