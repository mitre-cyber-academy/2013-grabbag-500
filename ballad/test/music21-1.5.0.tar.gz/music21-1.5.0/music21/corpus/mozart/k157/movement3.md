&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/03/01} [KHM:2109903583]
TIMESTAMP: DEC/26/2001 [md5sum:ce7a6eb66798185d8ad9e66d92bae074]
03/25/94 E. Correia
WK#:157       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:0   Q:8   T:2/4  C:4  D:Presto
C5     4        e     d  [     .f
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 2
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 3
C5     4        e     d
F5     8        q     d
E5     4        e     d
measure 4
gE5    5        s     u
S C1:t25
D5     8        q     d
C5     8        q     d
measure 5
C5     4        e     d
A5     8        q     d
G5     4        e     d
measure 6
gG5    5        s     u
S C1:t25
F5     8        q     d
E5     8        q     d
measure 7
D5     4        e     d  [
C5     4        e     d  =
B4     4        e     d  =
C5     4        e     d  ]
measure 8
D5     8        q     d
G4     8        q     u
measure 9
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 10
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 11
C5     4        e     d
F5     8        q     d
E5     4-       e     d        -
measure 12
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 13
C5     4        e     d
C6     8        q     d
B5     4-       e     d        -
measure 14
B5     4        e     d
A5     8        q     d
G5     4-       e     d        -
measure 15
G5     4        e     d
F5     8        q     d
D5     4        e     d
measure 16
C5     8        q     d
rest   8        q
mheavy2 17      :|
E5     1        t     d  [[[   (
F#5    1        t #   d  =]]
G5     6        e.    d  ]     )
F#5    2        s     d  [[    (
E5     2        s     d  ==
D5     2        s     d  ==
C5     2        s     d  ]]    )
measure 18
B4     1        t     d  [[[   (
C5     1        t     d  =]]
D5     6        e.    d  ]     )
C5     2        s     u  [[    (
B4     2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]    )
measure 19
C5     1        t     d  [[[   (
D5     1        t     d  =]]
E5     6        e.    d  ]     )
C5     2        s     u  [[    (
B4     2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]    )
measure 20
F#4    1        t #   u  [[[   (
G4     1        t     u  =]]
A4     6        e.    u  ]     )
G4     2        s     u  [[    (
F#4    2        s     u  ==
E4     2        s     u  ==
D4     2        s     u  ]]    )
measure 21
rest   4        e
C5     4        e     d  [     (p
E5     4        e     d  =
D5     4        e     d  ]     )
measure 22
D5     4        e     d  [     (
B4     4        e     d  ]     )
D5     8        q     d
measure 23
rest   4        e
C5     4        e     d  [     (
E5     4        e     d  =
D5     4        e     d  ]     )
measure 24
D5     4        e     d  [     (
B4     4        e     d  ]     )
D5     8        q     d
measure 25
gA5    5        s     u
S C1:t50
G5     4        e     d  [     f
F#5    2        s #   d  =[
E5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 26
B4     8        q     d        (
A4     4        e     u  [     )
B4     4        e     u  ]     .
measure 27
gD5    5        s     u
S C1:t50
C5     4        e     d  [
B4     2        s     d  =[
A4     2        s     d  ]]
gB4    5        s     u
S C1:t50
A4     4        e     u  [
G4     2        s     u  =[
F#4    2        s #   u  ]]
measure 28
F#4    8        q #   u        (
G4     4        e     u  [     )
B4     4        e     u  ]     .
measure 29
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F#5    2        s #   d  =[
E5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 30
B4     8        q     d        (
A4     4        e     u  [     )
B4     4        e     u  ]     .
measure 31
gD5    5        s     u
S C1:t50
C5     4        e     d  [
B4     2        s     d  =[
A4     2        s     d  ]]
gB4    5        s     u
S C1:t50
A4     4        e     u  [
G4     2        s     u  =[
F#4    2        s #   u  ]]
measure 32
G4     8        q     u
rest   8        q
measure 33
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 34
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 35
C5     4        e     d
F5     8        q     d
E5     4        e     d
measure 36
gE5    5        s     u
S C1:t25
D5     8        q     d
C5     8        q     d
measure 37
C5     4        e     d
A5     8        q     d
G5     4        e     d
measure 38
gG5    5        s     u
S C1:t25
F5     8        q     d
E5     8        q     d
measure 39
D5     4        e     d  [
C5     4        e     d  =
B4     4        e     d  =
C5     4        e     d  ]
measure 40
D5     8        q     d
G4     8        q     u
measure 41
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 42
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 43
C5     4        e     d
F5     8        q     d
E5     4-       e     d        -
measure 44
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 45
C5     4        e     d
C6     8        q     d
B5     4-       e     d        -
measure 46
B5     4        e     d
A5     8        q     d
G5     4-       e     d        -
measure 47
G5     4        e     d
F5     8        q     d
D5     4        e     d
measure 48
C5     8        q     d
rest   8        q
measure 49
G4     8        q     u        (p
P C33:y5
F4     4        e     u  [     )
Ef4    4        e f   u  ]     &1.
measure 50
Af4    4        e f   u  [     (
F4     4        e     u  ]     )
rest   8        q
measure 51
F4     8        q     u        (
Ef4    4        e f   u  [     )
D4     4        e     u  ]     .
measure 52
G4     4        e     u  [     (
Ef4    4        e f   u  ]     )
rest   8        q
measure 53
D4     8        q     u        (
Ef4    4        e f   u  [     )
F4     4        e     u  ]     .
measure 54
Ef4    8        q f   u        (
F4     4        e     u  [     )
G4     4        e     u  ]     .
measure 55
Af4    8        q f   u        (
G4     4        e     u  [
F#4    4        e #   u  ]     )
measure 56
G4    16        h     u
measure 57
Af4    8        q f   u        (
G4     4        e     u  [     )
F4     4        e n   u  ]     .+
measure 58
Bf4    4        e f   u  [     (
G4     4        e     u  ]     )
rest   8        q
measure 59
Af4    8        q f   u        (
G4     4        e     u  [     )
F4     4        e     u  ]     .
measure 60
Bf4    4        e f   u  [     (
G4     4        e     u  ]     )
rest   8        q
measure 61
F5     4        e     d  [     (
B4     4        e n   d  ]     )+
rest   8        q
measure 62
G5     4        e     d  [     (
C5     4        e     d  ]     )
rest   8        q
measure 63
D5     8        q     d        (
C5     4        e     d  [     )
B4     4        e n   d  ]     .+
measure 64
C5    16        h     d
measure 65
C5     4        e     d  [     .f
E5     4        e n   d  =     .+
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 66
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 67
C5     4        e     d
F5     8        q     d        (
E5     4        e     d        )
measure 68
gE5    5        s     u
S C1:t25
D5     8        q     d
C5     8        q     d
measure 69
C5     4        e     d
A5     8        q n   d        +
G5     4        e     d
measure 70
gG5    5        s     u
S C1:t25
F5     8        q     d
E5     8        q     d
measure 71
D5     4        e     d  [
C5     4        e     d  =
B4     4        e     d  =
C5     4        e     d  ]
measure 72
D5     8        q     d
G4     8        q     u
measure 73
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 74
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 75
C5     4        e     d
F5     8        q     d
E5     4-       e     d        -
measure 76
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 77
C5     4        e     d
C6     8        q     d
B5     4-       e     d        -
measure 78
B5     4        e     d
A5     8        q     d
G5     4-       e     d        -
measure 79
G5     4        e     d
F5     8        q     d
D5     4        e     d
measure 80
C5     8        q     d
rest   8        q
measure 81
rest   4        e
F5     4        e     d  [     (p
A5     4        e     d  =
G5     4        e     d  ]     )
measure 82
G5     4        e     d  [     (
E5     4        e     d  ]     )
G5     8        q     d
measure 83
rest   4        e
F5     4        e     d  [     (
A5     4        e     d  =
G5     4        e     d  ]     )
measure 84
G5     4        e     d  [     (
E5     4        e     d  ]     )
G5     8        q     d
measure 85
gD6    5        s     u
S C1:t50
C6     4        e     d  [     f
B5     2        s     d  =[
A5     2        s     d  ]]
gA5    5        s     u
S C1:t50
G5     4        e     d  [
F5     2        s     d  =[
E5     2        s     d  ]]
measure 86
E5     8        q     d        (
D5     4        e     d  [     )
E5     4        e     d  ]     .
measure 87
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 88
B4     8        q     d        (
C5     8        q     d        )
measure 89
rest   4        e
F4     4        e     u  [     (p
P C33:y5
A4     4        e     u  =
G4     4        e     u  ]     )
measure 90
G4     4        e     u  [     (
E4     4        e     u  ]     )
G4     8        q     u
measure 91
rest   4        e
E4     4        e     u  [     (
A4     4        e     u  =
G4     4        e     u  ]     )
measure 92
G4     4        e     u  [     (
E4     4        e     u  ]     )
G4     8        q     u
measure 93
gD5    5        s     u
S C1:t50
C5     4        e     d  [     f
B4     2        s     d  =[
A4     2        s     d  ]]
gA4    5        s     u
S C1:t50
G4     4        e     u  [
F4     2        s     u  =[
E4     2        s     u  ]]
measure 94
E4     8        q     u        (
D4     4        e     u  [     )
E4     4        e     u  ]     .
measure 95
gG4    5        s     u
S C1:t50
F4     4        e     u  [
E4     2        s     u  =[
D4     2        s     u  ]]
gE4    5        s     u
S C1:t50
D4     4        e     u  [
C4     2        s     u  =[
B3     2        s     u  ]]
measure 96
B3     8        q     u        (
C4     4        e     u  [     )
E4     4        e     u  ]     .
measure 97
gD5    5        s     u
S C1:t50
C5     4        e     d  [
B4     2        s     d  =[
A4     2        s     d  ]]
gA4    5        s     u
S C1:t50
G4     4        e     u  [
F4     2        s     u  =[
E4     2        s     u  ]]
measure 98
E4     8        q     u        (
D4     4        e     u  [     )
D5     4        e     u  ]     .
measure 99
gG5    5        s     u
S C1:t50
F5     4        e     d  [
E5     2        s     d  =[
D5     2        s     d  ]]
gE5    5        s     u
S C1:t50
D5     4        e     d  [
C5     2        s     d  =[
B4     2        s     d  ]]
measure 100
C5     8        q     d
rest   8        q
measure 101
C5     4        e     d  [     .f
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 102
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 103
C5     4        e     d
F5     8        q     d
E5     4        e     d
measure 104
gE5    5        s     u
S C1:t25
D5     8        q     d
C5     8        q     d
measure 105
C5     4        e     d
A5     8        q     d
G5     4        e     d
measure 106
gG5    5        s     u
S C1:t25
F5     8        q     d
E5     8        q     d
measure 107
D5     4        e     d  [
C5     4        e     d  =
B4     4        e     d  =
C5     4        e     d  ]
measure 108
D5     8        q     d
G4     8        q     u
measure 109
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 110
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 111
C5     4        e     d
F5     8        q     d
E5     4-       e     d        -
measure 112
E5     4        e     d
D5     8        q     d
C5     4-       e     d        -
measure 113
C5     4        e     d
C6     8        q     d
B5     4-       e     d        -
measure 114
B5     4        e     d
A5     8        q     d
G5     4-       e     d        -
measure 115
G5     4        e     d
F5     8        q     d
D5     4        e     d
measure 116
C5     8        q     d
rest   8        q
measure 117
C5     4        e     d  [     .p
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 118
C5     4        e     d  [     .
E5     4        e     d  =     .
D5     4        e     d  =     .
B4     4        e     d  ]     .
measure 119
E5     4        e     d  [     .
G5     4        e     d  =     .
F5     4        e     d  =     .
D5     4        e     d  ]     .
measure 120
E5     4        e     d  [     .
G5     4        e     d  =     .
F5     4        e     d  =     .
D5     4        e     d  ]     .
measure 121
*               D       cresc.
P C17:f33 C17:y-10
G5     2        s     d  [[
G5     2        s     d  ==
G5     2        s     d  ==
G5     2        s     d  ]]
G5     2        s     d  [[
G5     2        s     d  ==
G5     2        s     d  ==
G5     2        s     d  ]]
measure 122
G5     2        s     d  [[
G5     2        s     d  ==
G5     2        s     d  ==
G5     2        s     d  ]]
G5     2        s     d  [[
G5     2        s     d  ==
G5     2        s     d  ==
G5     2        s     d  ]]
measure 123
G5     4        e     d
rest   4        e
B5     6        e.    d  [     (tf
S C33:hn4s25t75
A5     1        t     d  =[[
B5     1        t     d  ]]]   )
measure 124
C6     4        e     d
rest   4        e
B5     6        e.    d  [     (t
S C33:hn4s25t75
A5     1        t     d  =[[
B5     1        t     d  ]]]   )
measure 125
C6     4        e     d
rest   4        e
C5     8        q     u
 E4    8        q     u
 G3    8        q     u
measure 126
C5     8        q     u
 E4    8        q     u
 G3    8        q     u
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/03/02} [KHM:2109903583]
TIMESTAMP: DEC/26/2001 [md5sum:e94a2a3523dd839256cfc726b2b42ac4]
03/25/94 E. Correia
WK#:157       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:0   Q:4   T:2/4  C:4  D:Presto
E4     2        e     u  [     .f
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 2
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 3
E4     2        e     u
F4     4        q     u
E4     2        e     u
measure 4
gE4    5        s     u
S C1:t25
D4     4        q     u
C4     4        q     u
measure 5
C4     2        e     u
A4     4        q     u
G4     2        e     u
measure 6
gG4    5        s     u
S C1:t25
F4     4        q     u
E4     4        q     u
measure 7
D4     2        e     u  [
C4     2        e     u  =
B3     2        e     u  =
C4     2        e     u  ]
measure 8
B3     4        q     u
D4     4        q     u
measure 9
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 10
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 11
E4     2        e     u
F4     4        q     u
E4     2-       e     u        -
measure 12
E4     2        e     u
D4     4        q     u
C4     2-       e     u        -
measure 13
C4     2        e     u
C5     4        q     d
B4     2-       e     d        -
measure 14
B4     2        e     d
A4     4        q     u
G4     2-       e     u        -
measure 15
G4     2        e     u
F4     4        q     u
D4     2        e     u
measure 16
C4     4        q     u
rest   4        q
mheavy2 17      :|
rest   4        q
A4     4        q     u
measure 18
rest   4        q
G4     4        q     u
measure 19
rest   4        q
G4     4        q     u
measure 20
rest   4        q
D4     4        q     u
measure 21
rest   2        e
C4     2        e     u  [     (p
P C33:y5
E4     2        e     u  =
D4     2        e     u  ]     )
measure 22
D4     2        e     u  [     (
B3     2        e     u  ]     )
D4     4        q     u
measure 23
rest   2        e
C4     2        e     u  [     (
E4     2        e     u  =
D4     2        e     u  ]     )
measure 24
D4     2        e     u  [     (
B3     2        e     u  ]     )
D4     4        q     u
measure 25
G4     2        e     u  [     f
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 26
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 27
F#4    2        e #   u  [
F#4    2        e     u  =
F#4    2        e     u  =
C4     2        e     u  ]
measure 28
C4     4        q     u        (
B3     2        e     u        )
rest   2        e
measure 29
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 30
G4     2        e     u  [
G4     2        e     u  =
G4     2        e     u  =
G4     2        e     u  ]
measure 31
E4     4        q     u
C4     4        q     u
measure 32
B3     2        e     u  [
G4     2        e     u  =     (
F4     2        e n   u  =     +
D4     2        e     u  ]     )
measure 33
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 34
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 35
E4     2        e     u
F4     4        q     u
E4     2        e     u
measure 36
gE4    5        s     u
S C1:t25
D4     4        q     u
C4     4        q     u
measure 37
C4     2        e     u
A4     4        q     u
G4     2        e     u
measure 38
gG4    5        s     u
S C1:t25
F4     4        q     u
E4     4        q     u
measure 39
D4     2        e     u  [
C4     2        e     u  =
B3     2        e     u  =
C4     2        e     u  ]
measure 40
B3     4        q     u
D4     4        q     u
measure 41
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 42
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 43
C4     2        e     u
F4     4        q     u
E4     2-       e     u        -
measure 44
E4     2        e     u
D4     4        q     u
C4     2-       e     u        -
measure 45
C4     2        e     u
C5     4        q     d
B4     2-       e     d        -
measure 46
B4     2        e     d
A4     4        q     u
G4     2-       e     u        -
measure 47
G4     2        e     u
F4     4        q     u
D4     2        e     u
measure 48
C4     4        q     u
rest   4        q
measure 49
Ef4    4        q f   u        (p
P C33:y7
D4     2        e     u  [     )
C4     2        e     u  ]     &1.
measure 50
F4     2        e     u  [     (
D4     2        e     u  ]     )
rest   4        q
measure 51
D4     4        q     u        (
C4     2        e     u  [     )
B3     2        e n   u  ]     .+
measure 52
Ef4    2        e f   u  [     (
C4     2        e     u  ]     )
rest   4        q
measure 53
B3     4        q     u        (
C4     2        e     u  [     )
D4     2        e     u  ]     .
measure 54
C4     4        q     u        (
D4     2        e     u  [     )
Ef4    2        e f   u  ]     .
measure 55
C4     4        q     u        (
B3     2        e     u  [     )
C4     2        e     u  ]     .
measure 56
D4     8        h     u
measure 57
F4     4        q     u        (
Ef4    2        e f   u  [     )
D4     2        e     u  ]     .
measure 58
G4     2        e     u  [     (
Ef4    2        e f   u  ]     )
rest   4        q
measure 59
F4     4        q     u        (
Ef4    2        e f   u  [     )
D4     2        e     u  ]     .
measure 60
G4     2        e     u  [     (
Ef4    2        e f   u  ]     )
rest   4        q
measure 61
Af4    2        e f   u  [     (
D4     2        e     u  ]     )
rest   4        q
measure 62
C5     2        e     u  [     (
Ef4    2        e f   u  ]     )
rest   4        q
measure 63
F4     4        q     u        (
Ef4    2        e f   u  [     )
D4     2        e     u  ]     .
measure 64
Ef4    8        h f   u
measure 65
E4     2        e n   u  [     .f+
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 66
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 67
C4     2        e     u
F4     4        q     u
E4     2        e     u
measure 68
gE4    5        s     u
S C1:t25
D4     4        q     u
C4     4        q     u
measure 69
C4     2        e     u
A4     4        q n   u        +
G4     2        e     u
measure 70
gG4    5        s     u
S C1:t25
F4     4        q     u
E4     4        q     u
measure 71
D4     2        e     u  [
C4     2        e     u  =
B3     2        e     u  =
C4     2        e     u  ]
measure 72
B3     4        q     u
D4     4        q     u
measure 73
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 74
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 75
C4     2        e     u
F4     4        q     u
E4     2-       e     u        -
measure 76
E4     2        e     u
D4     4        q     u
C4     2-       e     u        -
measure 77
C4     2        e     u
C5     4        q     d
B4     2-       e     d        -
measure 78
B4     2        e     d
A4     4        q     u
G4     2-       e     u        -
measure 79
G4     2        e     u
F4     4        q     u
D4     2        e     u
measure 80
C4     4        q     u
rest   4        q
measure 81
rest   2        e
F4     2        e     u  [     (p
P C33:y5
A4     2        e     u  =
G4     2        e     u  ]     )
measure 82
G4     2        e     u  [     (
E4     2        e     u  ]     )
G4     4        q     u
measure 83
rest   2        e
F4     2        e     u  [     (
A4     2        e     u  =
G4     2        e     u  ]     )
measure 84
G4     2        e     u  [     (
E4     2        e     u  ]     )
G4     4        q     u
measure 85
C5     2        e     d  [     f
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 86
C5     2        e     d  [
C5     2        e     d  =
C5     2        e     d  =
C5     2        e     d  ]
measure 87
B4     4        q     d        (
F4     4        q     u        )
measure 88
F4     4        q     u        (
E4     4        q     u        )
measure 89
C4     4        q     u        (p
P C33:y5
D4     4        q     u        )
measure 90
E4     2        e     u  [     (
C4     2        e     u  ]     )
C4     4        q     u
measure 91
C4     4        q     u        (
D4     4        q     u        )
measure 92
E4     2        e     u  [     (
C4     2        e     u  ]     )
C4     4        q     u
measure 93
C4     2        e     u  [     f
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 94
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 95
B3     4        q     u
rest   2        e
D4     2        e     u
measure 96
D4     4        q     u        (
C4     2        e     u        )
rest   2        e
measure 97
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 98
C4     2        e     u  [
C4     2        e     u  =
C4     2        e     u  =
C4     2        e     u  ]
measure 99
B3     2        e     u  [
B3     2        e     u  =
D4     2        e     u  =
F4     2        e     u  ]
measure 100
E4     4        q     u
rest   4        q
measure 101
E4     2        e     u  [     .f
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 102
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 103
E4     2        e     u
F4     4        q     u
E4     2        e     u
measure 104
gE4    5        s     u
S C1:t25
D4     4        q     u
C4     4        q     u
measure 105
C4     2        e     u
A4     4        q     u
G4     2        e     u
measure 106
gG4    5        s     u
S C1:t25
F4     4        q     u
E4     4        q     u
measure 107
D4     2        e     u  [
C4     2        e     u  =
B3     2        e     u  =
C4     2        e     u  ]
measure 108
B3     4        q     u
D4     4        q     u
measure 109
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 110
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 111
E4     2        e     u
F4     4        q     u
E4     2-       e     u        -
measure 112
E4     2        e     u
D4     4        q     u
C4     2-       e     u        -
measure 113
C4     2        e     u
C5     4        q     d
B4     2-       e     d        -
measure 114
B4     2        e     d
A4     4        q     u
G4     2-       e     u        -
measure 115
G4     2        e     u
F4     4        q     u
D4     2        e     u
measure 116
C4     4        q     u
rest   4        q
measure 117
rest   8
measure 118
rest   8
measure 119
C4     2        e     u  [     .p
E4     2        e     u  =     .
D4     2        e     u  =     .
B3     2        e     u  ]     .
measure 120
C4     2        e     u  [     .
E4     2        e     u  =     .
D4     2        e     u  =     .
B3     2        e     u  ]     .
measure 121
*               D       cresc.
P C17:f33
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 122
E4     2        e     u  [     .
G4     2        e     u  =     .
F4     2        e     u  =     .
D4     2        e     u  ]     .
measure 123
G4     1        s     u  [[    f
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ]]
 G3    1        s     u
G4     1        s     u  [[
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ]]
 G3    1        s     u
measure 124
G4     1        s     u  [[
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ]]
 G3    1        s     u
G4     1        s     u  [[
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ==
 G3    1        s     u
G4     1        s     u  ]]
 G3    1        s     u
measure 125
G4     2        e     u
 G3    2        e     u
rest   2        e
C5     4        q     u
 E4    4        q     u
 G3    4        q     u
measure 126
C5     4        q     u
 E4    4        q     u
 G3    4        q     u
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/03/03} [KHM:2109903583]
TIMESTAMP: DEC/26/2001 [md5sum:7f4516372ebc89adfae0ffac328884fa]
03/25/94 E. Correia
WK#:157       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:0   Q:4   T:2/4  C:13  D:Presto
rest   8
measure 2
rest   8
measure 3
C4     2        e     d  [     f
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 4
B3     4        q     u
C4     4        q     d
measure 5
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 6
B3     4        q     u
C4     4        q     d
measure 7
A3     2        e     u  [
G3     2        e     u  =
F3     2        e     u  =
E3     2        e     u  ]
measure 8
G3     4        q     u
B3     4        q     u
measure 9
rest   8
measure 10
rest   8
measure 11
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 12
C4     2        e     d
B3     4        q     u
C4     2-       e     d        -
measure 13
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 14
C4     2        e     d
C4     4        q     d
E4     2-       e     d        -
measure 15
E4     2        e     d
D4     4        q     d
B3     2        e     u
measure 16
C4     4        q     d
rest   4        q
mheavy2 17      :|
rest   4        q
F#4    4        q #   d
measure 18
rest   4        q
D4     4        q     d
measure 19
rest   4        q
E4     4        q     d
measure 20
rest   4        q
A3     4        q     u
measure 21
G3     4        q     u        (p
P C33:y5
A3     4        q     u
measure 22
B3     4        q     u        )
rest   4        q
measure 23
G3     4        q     u        (
A3     4        q     u
measure 24
B3     4        q     u        )
rest   4        q
measure 25
D4     2        e     d  [     f
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 26
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
E4     2        e     d  ]
measure 27
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 28
A3     4        q     u        (
G3     2        e     u        )
rest   2        e
measure 29
D4     2        e     d  [
D4     2        e     d  =
D4     2        e     d  =
D4     2        e     d  ]
measure 30
E4     2        e     d  [
E4     2        e     d  =
E4     2        e     d  =
D4     2        e     d  ]
measure 31
A3     4        q     u
A3     4        q     u
measure 32
G3     4        q     u
rest   4        q
measure 33
rest   8
measure 34
rest   8
measure 35
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 36
B3     4        q     u
C4     4        q     d
measure 37
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 38
B3     4        q     u
C4     4        q     d
measure 39
A3     2        e     u  [
G3     2        e     u  =
F3     2        e     u  =
E3     2        e     u  ]
measure 40
G3     4        q     u
B3     4        q     u
measure 41
rest   8
measure 42
rest   8
measure 43
E4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 44
C4     2        e     d
B3     4        q     u
C4     2-       e     d        -
measure 45
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 46
C4     2        e     d
C4     4        q     d
E4     2-       e     d        -
measure 47
E4     2        e     d
D4     4        q     d
B3     2        e     u
measure 48
C4     4        q     d
rest   4        q
measure 49
rest   8
measure 50
rest   2        e
Af3    2        e f   u  [     (p
P C33:y5
G3     2        e     u  =
Af3    2        e     u  ]     )
measure 51
rest   8
measure 52
rest   2        e
Ef3    2        e f   u  [     (
D3     2        e     u  =
Ef3    2        e     u  ]     )
measure 53
G3     8        h     u
measure 54
G3     8        h     u
measure 55
rest   4        q
rest   2        e
C4     2        e     d        .
measure 56
B3     4        q n   u        (+
Bf3    4        q f   u        )
measure 57
Bf3    4        q f   u
rest   4        q
measure 58
rest   2        e
Bf3    2        e f   u  [     (
Af3    2        e f   u  =
G3     2        e     u  ]     )
measure 59
rest   8
measure 60
rest   2        e
Bf3    2        e f   u  [     (
Af3    2        e f   u  =
G3     2        e     u  ]     )
measure 61
rest   2        e
Af3    2        e f   u  [     (
G3     2        e     u  =
F3     2        e     u  ]     )
measure 62
rest   2        e
G3     2        e     u  [     (
F3     2        e     u  =
Ef3    2        e f   u  ]     )
measure 63
Af3    4        q f   u        (
G3     4        q     u        )
measure 64
G3     8        h     u
measure 65
rest   8
measure 66
rest   8
measure 67
C4     2        e     d  [     f
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 68
B3     4        q n   u        +
C4     4        q     d
measure 69
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 70
B3     4        q     u
C4     4        q     d
measure 71
A3     2        e n   u  [     +
G3     2        e     u  =
F3     2        e     u  =
E3     2        e n   u  ]     +
measure 72
G3     4        q     u
B3     4        q     u
measure 73
rest   8
measure 74
rest   8
measure 75
E4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 76
C4     2        e     d
B3     4        q     u
C4     2-       e     d        -
measure 77
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 78
C4     2        e     d
C4     4        q     d
E4     2-       e     d        -
measure 79
E4     2        e     d
D4     4        q     d
B3     2        e     u
measure 80
C4     4        q     d
rest   4        q
measure 81
C4     4        q     d        (p
D4     4        q     d
measure 82
E4     4        q     d        )
rest   4        q
measure 83
C4     4        q     d        (
D4     4        q     d
measure 84
E4     4        q     d        )
rest   4        q
measure 85
G4     2        e     d  [     f
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 86
A4     2        e     d  [
A4     2        e     d  =
A4     2        e     d  =
A4     2        e     d  ]
measure 87
D4     8        h     d
measure 88
D4     4        q     d        (
C4     4        q     d        )
measure 89
rest   4        q
G3     4-       q     u        -p
P C33:y5
measure 90
G3     4        q     u
rest   4        q
measure 91
rest   4        q
G3     4-       q     u        -
measure 92
G3     4        q     u
rest   4        q
measure 93
G3     2        e     u  [     f
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 94
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 95
D3     2        e     u  [
D3     2        e     u  =
D3     2        e     u  =
F3     2        e     u  ]
measure 96
F3     4        q     u        (
E3     2        e     u        )
rest   2        e
measure 97
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 98
A3     2        e     u  [
A3     2        e     u  =
A3     2        e     u  =
A3     2        e     u  ]
measure 99
D4     2        e     d  [
D4     2        e     d  =
F4     2        e     d  =
D4     2        e     d  ]
measure 100
C4     4        q     d
rest   4        q
measure 101
rest   8
measure 102
rest   8
measure 103
C4     2        e     d  [     f
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 104
B3     4        q     u
C4     4        q     d
measure 105
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 106
B3     4        q     u
C4     4        q     d
measure 107
A3     2        e     u  [
G3     2        e     u  =
F3     2        e     u  =
E3     2        e     u  ]
measure 108
G3     4        q     u
B3     4        q     u
measure 109
rest   8
measure 110
rest   8
measure 111
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 112
C4     2        e     d
B3     4        q     u
C4     2-       e     d        -
measure 113
C4     2        e     d
C4     4        q     d
C4     2-       e     d        -
measure 114
C4     2        e     d
C4     4        q     d
E4     2-       e     d        -
measure 115
E4     2        e     d
D4     4        q     d
B3     2        e     u
measure 116
C4     4        q     d
rest   4        q
measure 117
rest   8
measure 118
rest   8
measure 119
rest   8
measure 120
rest   8
measure 121
*               D       cresc.
P C17:f33 C17:x15
C4     2        e     d  [     .p
P C33:x-10
E4     2        e     d  =     .
D4     2        e     d  =     .
B3     2        e     d  ]     .
measure 122
C4     2        e     d  [     .
E4     2        e     d  =     .
D4     2        e     d  =     .
B3     2        e     d  ]     .
measure 123
E4     1        s     d  [[    f
E4     1        s     d  ==
E4     1        s     d  ==
E4     1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
measure 124
E4     1        s     d  [[
E4     1        s     d  ==
G4     1        s     d  ==
G4     1        s     d  ]]
F4     1        s     d  [[
F4     1        s     d  ==
D4     1        s     d  ==
D4     1        s     d  ]]
measure 125
E4     2        e     d
rest   2        e
E4     4        q     u
 G3    4        q     u
measure 126
E4     4        q     u
 G3    4        q     u
 C3    4        q     u
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/03/04} [KHM:2109903583]
TIMESTAMP: DEC/26/2001 [md5sum:315193e95e0b1ecf398eb8c1dd3d320c]
03/25/94 E. Correia
WK#:157       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:0   Q:2   T:2/4  C:22  D:Presto
rest   4
measure 2
rest   4
measure 3
C3     1        e     u        f
A3     2        q     d
G3     1        e     d
measure 4
gG3    5        s     u
S C1:t25
F3     2        q     d
E3     2        q     d
measure 5
E3     1        e     d
F3     2        q     d
E3     1        e     d
measure 6
gE3    5        s     u
S C1:t25
D3     2        q     d
C3     2        q     u
measure 7
F3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  =
C3     1        e     d  ]
measure 8
G3     2        q     d
G2     2        q     u
measure 9
rest   4
measure 10
rest   4
measure 11
C3     2        q     u
G3     2        q     d
measure 12
F3     2        q     d
E3     2        q     d
measure 13
A3     2        q     d
G3     2        q     d
measure 14
F3     2        q     d
E3     2        q     d
measure 15
F3     2        q     d
G3     2        q     d
measure 16
C3     2        q     u
rest   2        q
mheavy2 17      :|
rest   2        q
D3     2        q     d
measure 18
rest   2        q
G3     2        q     d
measure 19
rest   2        q
C3     2        q     u
measure 20
rest   2        q
D3     2        q     d
measure 21
E3     2        q     d        (p
F#3    2        q #   d
measure 22
G3     2        q     d
B3     2        q     d        )
measure 23
E3     2        q     d        (
F#3    2        q #   d
measure 24
G3     2        q     d
B3     2        q     d        )
measure 25
B2     1        e     u  [     f
B2     1        e     u  =
B2     1        e     u  =
B2     1        e     u  ]
measure 26
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 27
D3     1        e     d  [
D3     1        e     d  =
D3     1        e     d  =
D3     1        e     d  ]
measure 28
E3     1        e     d  [
E3     1        e     d  =
E3     1        e     d  =
E3     1        e     d  ]
measure 29
B2     1        e     u  [
B2     1        e     u  =
B2     1        e     u  =
B2     1        e     u  ]
measure 30
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
B2     1        e     u  ]
measure 31
A2     2        q     u
D3     2        q     d
measure 32
G2     2        q     u
rest   2        q
measure 33
rest   4
measure 34
rest   4
measure 35
C3     1        e     u
A3     2        q     d
G3     1        e     d
measure 36
gG3    5        s     u
S C1:t25
F3     2        q     d
E3     2        q     d
measure 37
E3     1        e     d
F3     2        q     d
E3     1        e     d
measure 38
gE3    5        s     u
S C1:t25
D3     2        q     d
C3     2        q     u
measure 39
F3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  =
C3     1        e     d  ]
measure 40
G3     2        q     d
G2     2        q     u
measure 41
rest   4
measure 42
rest   4
measure 43
C3     2        q     u
G3     2        q     d
measure 44
F3     2        q     d
E3     2        q     d
measure 45
A3     2        q     d
G3     2        q     d
measure 46
F3     2        q     d
E3     2        q     d
measure 47
F3     2        q     d
G3     2        q     d
measure 48
C3     2        q     u
rest   2        q
measure 49
rest   4
measure 50
rest   1        e
F3     1        e     d  [     (p
E3     1        e     d  =
F3     1        e     d  ]     )
measure 51
rest   4
measure 52
rest   1        e
C3     1        e     u  [     (
B2     1        e     u  =
C3     1        e     u  ]     )
measure 53
G2     4        h     u
measure 54
C3     4        h     u
measure 55
F3     2        q     d        (
G3     1        e     d  [     )
Af3    1        e f   d  ]     .
measure 56
G3     4        h     d
measure 57
F3     2        q     d
rest   2        q
measure 58
rest   1        e
G3     1        e     d  [     (
F3     1        e     d  =
Ef3    1        e f   d  ]     )
measure 59
rest   4
measure 60
rest   1        e
G3     1        e     d  [     (
F3     1        e     d  =
Ef3    1        e f   d  ]     )
measure 61
rest   1        e
F3     1        e     d  [     (
Ef3    1        e f   d  =
D3     1        e     d  ]     )
measure 62
rest   1        e
Ef3    1        e f   d  [     (
D3     1        e     d  =
C3     1        e     d  ]     )
measure 63
F3     2        q     d        (
G3     2        q     d        )
measure 64
C3     4        h     u
measure 65
rest   4
measure 66
rest   4
measure 67
C3     1        e     u        f
A3     2        q n   d        +
G3     1        e     d
measure 68
gG3    5        s     u
S C1:t25
F3     2        q     d
E3     2        q n   d        +
measure 69
E3     1        e     d
F3     2        q     d
E3     1        e     d
measure 70
gE3    5        s     u
S C1:t25
D3     2        q     d
C3     2        q     u
measure 71
F3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  =
C3     1        e     d  ]
measure 72
G3     2        q     d
G2     2        q     u
measure 73
rest   4
measure 74
rest   4
measure 75
C3     2        q     u
G3     2        q     d
measure 76
F3     2        q     d
E3     2        q     d
measure 77
A3     2        q     d
G3     2        q     d
measure 78
F3     2        q     d
E3     2        q     d
measure 79
F3     2        q     d
G3     2        q     d
measure 80
C3     2        q     u
rest   2        q
measure 81
A3     2        q     d        (p
B3     2        q     d
measure 82
C4     2        q     d
E4     2        q     d        )
measure 83
A3     2        q     d        (
B3     2        q     d
measure 84
C4     2        q     d
E4     2        q     d        )
measure 85
E3     1        e     d  [     f
E3     1        e     d  =
E3     1        e     d  =
E3     1        e     d  ]
measure 86
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
measure 87
G3     1        e     d  [
G3     1        e     d  =
G3     1        e     d  =
G3     1        e     d  ]
measure 88
C3     4        h     u
measure 89
A2     2        q     u        (p
B2     2        q     u
measure 90
C3     2        q     u
E3     2        q     d        )
measure 91
A2     2        q     u        (
B2     2        q     u
measure 92
C3     2        q     u
E3     2        q     d        )
measure 93
E2     1        e     u  [     f
E2     1        e     u  =
E2     1        e     u  =
E2     1        e     u  ]
measure 94
F2     1        e     u  [
F2     1        e     u  =
F2     1        e     u  =
F2     1        e     u  ]
measure 95
G2     1        e     u  [
G2     1        e     u  =
G2     1        e     u  =
G2     1        e     u  ]
measure 96
A2     1        e     u  [
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  ]
measure 97
E3     1        e     d  [
E3     1        e     d  =
E3     1        e     d  =
E3     1        e     d  ]
measure 98
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
measure 99
G3     1        e     d  [
G3     1        e     d  =
G3     1        e     d  =
G3     1        e     d  ]
measure 100
C3     2        q     u
rest   2        q
measure 101
rest   4
measure 102
rest   4
measure 103
C3     1        e     u        f
A3     2        q     d
G3     1        e     d
measure 104
gG3    5        s     u
S C1:t25
F3     2        q     d
E3     2        q     d
measure 105
E3     1        e     d
F3     2        q     d
E3     1        e     d
measure 106
gE3    5        s     u
S C1:t25
D3     2        q     d
C3     2        q     u
measure 107
F3     1        e     d  [
E3     1        e     d  =
D3     1        e     d  =
C3     1        e     d  ]
measure 108
G3     2        q     d
G2     2        q     u
measure 109
rest   4
measure 110
rest   4
measure 111
C3     2        q     u
G3     2        q     d
measure 112
F3     2        q     d
E3     2        q     d
measure 113
A3     2        q     d
G3     2        q     d
measure 114
F3     2        q     d
E3     2        q     d
measure 115
F3     2        q     d
G3     2        q     d
measure 116
C3     2        q     u
rest   2        q
measure 117
rest   4
measure 118
rest   4
measure 119
rest   4
measure 120
rest   4
measure 121
rest   4
measure 122
rest   4
measure 123
C3     1        e     u  [     f
E3     1        e     u  =
D3     1        e     u  =
G2     1        e     u  ]
measure 124
C3     1        e     u  [
E3     1        e     u  =
D3     1        e     u  =
G2     1        e     u  ]
measure 125
C3     2        q     u
C3     2        q     u
measure 126
C3     2        q     u
rest   2        q
mheavy2
/END
/eof
//
