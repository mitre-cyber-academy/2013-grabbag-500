&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/02/01} [KHM:3699691340]
TIMESTAMP: DEC/26/2001 [md5sum:5ab7ee75d3b2db1d0130363cf97f35de]
02/22/94 E. Correia
WK#:157       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 1
0 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-3   Q:4   T:3/8  C:4  D:Andante
rest   2        e
G5     2        e     d  [     .p
G5     2        e     d  ]     .
measure 2
G5     2        e     d  [     (
Ef5    2        e     d  =
C5     2        e     d  ]     )
measure 3
rest   2        e
B4     2        e n   d  [     .
Af5    2        e     d  ]     .
measure 4
G5     2        e     d  [     (
Ef5    2        e     d  =     )
C5     2        e     d  ]     .
measure 5
rest   2        e
Df5    2        e f   d  [     .
Df5    2        e     d  ]     .
measure 6
Df5    2        e f   d  [     (
B4     2        e n   d  =
C5     2        e     d  ]
measure 7
Df5    2        e f   d  [
B4     2        e n   d  =
C5     2        e     d  ]     )
measure 8
F#5    6        q.#   d        (
measure 9
F5     6        q.n   d        )+
measure 10
Ef5    2        e     d  [     (
G5     2        e     d  ]     )
C5     2-       e     d        -
measure 11
C5     2        e     d  [
D5     2        e n   d  =     +
B4     2        e n   d  ]
measure 12
C5     4        q     d
rest   2        e
measure 13
rest   6
measure 14
rest   2        e
Bf5    2    @   e     d  [     f&1.
@ Staccatos have been added to this movement when readily inferred from
@ neighboring tracks and parallel passages.
Bf5    2        e     d  ]     &1.
measure 15
Bf5    2        e     d  [     (
D5     2        e     d  =     )
D5     2        e     d  ]     .
measure 16
rest   2        e
Ef5    2        e     d  [     .
Ef5    2        e     d  ]     .
measure 17
Ef5    2        e     d  [     (
Bf4    2        e     d  =     )
Bf4    2        e     d  ]     .
measure 18
rest   2        e
Af4    2        e     u  [     .
Af4    2        e     u  ]     .
measure 19
Af5    2        e     d  [     (
F5     2        e     d  =
Bf5    2        e     d  ]     )
measure 20
G5     2        e     d  [     (
Ef5    2        e     d  =
Af5    2        e     d  ]     )
measure 21
G5     4        q     d        (
F5     2        e     d        )
measure 22
rest   2        e
F4     2        e     u  [     (p
P C33:y5
Bf4    2        e     u  ]     )
measure 23
Af4    2        e     u  [     (
Gf4    2        e f   u  =     )
Gf4    2        e     u  ]     .
measure 24
rest   2        e
Bf4    2        e     u  [     (
Gf4    2        e f   u  ]     )
measure 25
E4     2        e n   u  [     (
F4     2        e     u  =     )
F4     2        e     u  ]     .
measure 26
rest   1        s
G4     1        s n   d  [[    (f+
Bf4    1        s     d  ==
Ef5    1        s     d  ==
G5     1        s     d  ==
G4     1        s     d  ]]    )
measure 27
rest   1        s
Bf4    1        s     d  [[    (
D5     1        s     d  ==
F5     1        s     d  ==
Bf5    1        s     d  ==
Bf4    1        s     d  ]]    )
measure 28
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
C5     1        s     u  ==
Ef5    1        s     u  ==
Ef4    1        s     u  ]]    )
measure 29
rest   1        s
G4     1        s     d  [[    (
Bf4    1        s     d  ==
D5     1        s     d  ==
G5     1        s     d  ==
G4     1        s     d  ]]    )
measure 30
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
Af4    1        s     u  ==
C5     1        s     u  ==
C4     1        s     u  ]]    )
measure 31
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Bf4    1        s     u  ==
Ef5    1        s     u  ==
Ef4    1        s     u  ]]    )
measure 32
F4     1        s     u  [[    (
C5     1        s     u  ]]    )
Bf4    1        s     u  [[    .
Af4    1        s     u  ==    .
G4     1        s     u  ==    .
F4     1        s     u  ]]    .
measure 33
Ef4    2        e     u        .
rest   2        e
rest   2        e
measure 34
Df5    2        e f   d        .p
rest   2        e
rest   2        e
measure 35
C5     2        e     d        .
rest   2        e
rest   2        e
measure 36
Af5    2        e     d        .
rest   2        e
rest   2        e
measure 37
G5     2        e     d        .
rest   2        e
rest   2        e
measure 38
Bf5    2        e     d        .
rest   2        e
rest   2        e
measure 39
Af5    2        e     d        .
rest   2        e
rest   2        e
measure 40
D5     2        e n   d        .+
rest   2        e
rest   2        e
measure 41
Ef5    4        q     d
rest   2        e
measure 42
rest   6
measure 43
rest   6
measure 44
rest   6
mheavy4 45      :|:
rest   2        e
C4     2        e     u  [     f&1.
C4     2        e     u  ]     &1.
measure 46
C4     2        e     u  [     (
Df4    2        e f   u  =     )
Bf3    2        e     u  ]     .
measure 47
Bf3    2        e     u  [     (
C4     2        e     u  =     )
Af3    2        e     u  ]     .
measure 48
Af3    2        e     u  [     (
Bf3    2        e     u  =     )
G3     2        e     u  ]     .
measure 49
Af3    2        e     u
Ef5    2        e     d  [     .
Ef5    2        e     d  ]     .
measure 50
Ef5    2        e     d  [     (
Bf5    2        e     d  =     )
Ef5    2        e     d  ]     .
measure 51
Ef5    2        e     d  [     (
C6     2        e     d  =     )
Ef5    2        e     d  ]     .
measure 52
Ef5    2        e     d  [     (
Df6    2        e f   d  ]     )
rest   2        e
measure 53
rest   2        e
Df6    2        e f   d  [     (
Ef5    2        e     d  ]     )
measure 54
Ef5    2        e     d  [     (
C6     2        e     d  =     )
Ef5    2        e     d  ]     .
measure 55
Ef5    2        e     d  [     (
Bf5    2        e     d  =     )
Ef5    2        e     d  ]     .
measure 56
Ef5    2        e     d  [     (
Af5    2        e     d  ]     )
rest   2        e
measure 57
rest   2        e
C5     2        e     d  [     (
Af5    2        e     d  ]     )
measure 58
rest   2        e
C6     2        e     d  [     (
G5     2        e     d  ]     )
measure 59
rest   2        e
C6     2        e     d  [     (
Af5    2        e     d  ]     )
measure 60
rest   2        e
Bf5    2        e     d  [     (
E5     2        e n   d  ]     )
measure 61
rest   2        e
G5     2        e     d  [     (
Bf5    2        e     d  ]     )
measure 62
rest   2        e
F5     2        e     d  [     (
Af5    2        e     d  ]     )
measure 63
rest   2        e
E5     2        e n   d  [     (
G5     2        e     d  ]     )
measure 64
rest   2        e
Af5    2        e     d  [     (
F5     2        e     d  ]     )
measure 65
rest   1        s
G4     1        s     d  [[    (
B4     1        s n   d  ==
D5     1        s     d  ==
G5     1        s     d  ==
D5     1        s     d  ]]    )
measure 66
rest   1        s
G4     1        s     d  [[    (
B4     1        s n   d  ==
D5     1        s     d  ==
F5     1        s     d  ==
D5     1        s     d  ]]    )
measure 67
rest   1        s
G4     1        s     d  [[    (
C5     1        s     d  ==
Ef5    1        s     d  ==
G5     1        s     d  ==
Ef5    1        s     d  ]]    )
measure 68
rest   1        s
D5     1        s     d  [[    (
B4     1        s n   d  ==
D5     1        s     d  ==
G4     1        s     d  ==
B4     1        s     d  ]]    )
measure 69
rest   1        s
G5     1        s     d  [[    (
D5     1        s     d  ==
G5     1        s     d  ==
B4     1        s n   d  ==
D5     1        s     d  ]]    )
measure 70
rest   1        s
C5     1        s     d  [[    (
Ef5    1        s     d  ==
G5     1        s     d  ==
Ef5    1        s     d  ==
C5     1        s     d  ]]    )
measure 71
rest   1        s
F5     1        s     d  [[    (
D5     1        s     d  ==
B4     1        s n   d  ==
G4     1        s     d  ==
F5     1        s     d  ]]    )
measure 72
rest   1        s
Ef5    1        s     d  [[    (
G5     1        s     d  ==
Ef5    1        s     d  ==
B4     1        s n   d  ==
C5     1        s     d  ]]    )
measure 73
Ef5    2        e     d  [     (
D5     2        e     d  =
C5     2        e     d  ]     )
measure 74
Ef5    2        e     d  [     (
D5     2        e     d  =
C5     2        e     d  ]     )
measure 75
C5     6        q.    d        (
measure 76
B4     2        e n   d        )
rest   2        e
rest   2        e
measure 77
rest   2        e
G5     2        e     d  [     .p
G5     2        e     d  ]     .
measure 78
G5     2        e     d  [     (
Ef5    2        e     d  =     )
C5     2        e     d  ]     .
measure 79
rest   2        e
B4     2        e n   d  [     .
Af5    2        e     d  ]     .
measure 80
G5     2        e     d  [     (
Ef5    2        e     d  =     )
C5     2        e     d  ]     .
measure 81
rest   2        e
Df5    2        e f   d  [     .
Df5    2        e     d  ]     .
measure 82
Df5    2        e f   d  [     (
B4     2        e n   d  =     )
C5     2        e     d  ]     .
measure 83
Df5    2        e f   d  [     (
B4     2        e n   d  =     )
C5     2        e     d  ]     .
measure 84
F#5    6        q.#   d        (
measure 85
F5     6        q.n   d        )+
measure 86
Ef5    2        e     d  [     (
G5     2        e     d  ]     )
C5     2-       e     d        -
measure 87
C5     2        e     d  [     (
D5     2        e n   d  =     +
B4     2        e n   d  ]     )
measure 88
C5     2        e     d  [     .
G5     2        e     d  =     .f
P C33:y5
G5     2        e     d  ]     .
measure 89
G5     2        e     d  [     (
B4     2        e n   d  ]     )
B4     2        e     d        .
measure 90
rest   2        e
C6     2        e     d  [     .
C6     2        e     d  ]     .
measure 91
C6     2        e     d  [     (
G5     2        e     d  ]     )
G5     2        e     d        &1.
measure 92
rest   2        e
F5     2        e     d  [     .
F5     2        e     d  ]     .
measure 93
F5     2        e     d  [     (
D5     2        e     d  =
G5     2        e     d  ]     )
measure 94
Ef5    2        e     d  [     (
C5     2        e     d  =
F5     2        e     d  ]     )
measure 95
Ef5    4        q     d        (
D5     2        e     d        )
measure 96
rest   2        e
D4     2        e     u  [     (p
G4     2        e     u  ]     )
measure 97
F4     2        e     u  [     (
Ef4    2        e     u  =     )
Ef4    2        e     u  ]     .
measure 98
rest   2        e
G4     2        e     u  [     (
Ef4    2        e     u  ]     )
measure 99
C#4    2        e #   u  [     (
D4     2        e     u  =     )
D4     2        e     u  ]     .
measure 100
rest   1        s
Ef4    1        s     u  [[    (f
P C33:y10
G4     1        s     u  ==
C5     1        s     u  ==
Ef5    1        s     u  ==
Ef4    1        s     u  ]]    )
measure 101
rest   1        s
G4     1        s     d  [[    (
Bf4    1        s     d  ==
D5     1        s     d  ==
G5     1        s     d  ==
G4     1        s     d  ]]    )
measure 102
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
Af4    1        s     u  ==
C5     1        s     u  ==
C4     1        s     u  ]]    )
measure 103
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Bf4    1        s     u  ==
Ef5    1        s     u  ==
Ef4    1        s     u  ]]    )
measure 104
rest   1        s
Af3    1        s     u  [[    (
C4     1        s     u  ==
F4     1        s     u  ==
Af4    1        s     u  ==
Af3    1        s     u  ]]    )
measure 105
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
G4     1        s     u  ==
C5     1        s     u  ==
C4     1        s     u  ]]    )
measure 106
D4     1        s     u  [[    (
Af4    1        s     u  ]]    )
G4     1        s     u  [[    .
F4     1        s     u  ==    .
Ef4    1        s     u  ==    .
D4     1        s     u  ]]    .
measure 107
C4     2        e     u        &1.
rest   2        e
rest   2        e
measure 108
Bf4    2        e     d        .p
rest   2        e
rest   2        e
measure 109
Af4    2        e     u        .
rest   2        e
rest   2        e
measure 110
F5     2        e     d        .
rest   2        e
rest   2        e
measure 111
Ef5    2        e     d        .
rest   2        e
rest   2        e
measure 112
Bf5    2        e     d        .
rest   2        e
rest   2        e
measure 113
Af5    2        e     d        .
rest   2        e
rest   2        e
measure 114
B4     2        e n   d        .
rest   2        e
rest   2        e
measure 115
C5     2        e     d        .
rest   2        e
rest   2        e
measure 116
rest   6
measure 117
rest   6
measure 118
rest   6
mheavy2 119     :|
$  D:Coda
rest   2        e
G5     2        e     d  [     .f
G5     2        e     d  ]     .
measure 120
G5     2        e     d  [     (
B4     2        e n   d  =
D5     2        e     d  ]     )
measure 121
C5     2        e     d  [     (
Ef5    2        e     d  =
G5     2        e     d  ]     )
measure 122
G5     2        e     d  [     (
B4     2        e n   d  =
D5     2        e     d  ]     )
measure 123
C5     2        e     u  [
G4     2        e     u  =     p
G4     2        e     u  ]
measure 124
G4     2        e     u  [     (
Af4    2        e     u  =
F4     2        e     u  ]     )
measure 125
F4     6        q.    u        (
measure 126
Ef4    2        e     u        )
rest   2        e
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/02/02} [KHM:3699691340]
TIMESTAMP: DEC/26/2001 [md5sum:e7844959a183264c788a2abff6d4480d]
02/22/94 E. Correia
WK#:157       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violino 2
0 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-3   Q:4   T:3/8  C:4  D:Andante
rest   1        s
Ef4    1        s     u  [[    (p
P C33:y5
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 2
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 3
rest   1        s
F4     1        s     u  [[    (
Af4    1        s     u  ==
F4     1        s     u  ==
B4     1        s n   u  ==
F4     1        s     u  ]]    )
measure 4
rest   1        s
C5     1        s     u  [[    (
G4     1        s     u  ==
C5     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ]]    )
measure 5
rest   1        s
Af4    1        s     u  [[    (
F4     1        s     u  ==
Af4    1        s     u  ==
Af3    1        s     u  ==
Af4    1        s     u  ]]    )
measure 6
rest   1        s
Af4    1        s     u  [[    (
D4     1        s     u  ==
Af4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 7
rest   1        s
Af4    1        s     u  [[    (
D4     1        s     u  ==
Af4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 8
rest   1        s
Ef4    1        s     u  [[    (
A4     1        s n   u  ==
Ef4    1        s     u  ==
A4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 9
rest   1        s
D4     1        s     u  [[    (
Af4    1        s f   u  ==    +
D4     1        s     u  ==
G4     1        s     u  ==
D4     1        s     u  ]]    )
measure 10
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
C4     1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 11
rest   1        s
Ef4    1        s     u  [[    (
F4     1        s     u  ==
D4     1        s     u  ==
G4     1        s     u  ==
F4     1        s     u  ]]    )
measure 12
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 13
rest   1        s
F4     1        s     u  [[    (
D4     1        s     u  ==
F4     1        s     u  ==
Bf3    1        s     u  ==
F4     1        s     u  ]]    )
measure 14
Ef4    2        e     u  [
Bf4    2        e     u  =     .f
Bf4    2        e     u  ]     .
measure 15
Bf4    2        e     u  [     (
D4     2        e     u  =     )
D4     2        e     u  ]     .
measure 16
rest   2        e
Ef4    2        e     u  [     .
Ef4    2        e     u  ]     .
measure 17
Ef4    2        e     u  [     (
Bf3    2        e     u  =     )
Bf3    2        e     u  ]     .
measure 18
rest   2        e
Af3    2        e     u  [     .
Af3    2        e     u  ]     .
measure 19
Af4    2        e     u  [     (
F4     2        e     u  =
Bf4    2        e     u  ]     )
measure 20
G4     2        e     u  [     (
Ef4    2        e     u  =
Af4    2        e     u  ]     )
measure 21
G4     4        q     u        (
F4     2        e     u        )
measure 22
rest   1        s
Bf3    1        s     u  [[    (p
P C33:y5
D4     1        s     u  ==
Bf3    1        s     u  ==
F4     1        s     u  ==
D4     1        s     u  ]]    )
measure 23
rest   1        s
Bf3    1        s     u  [[    (
Ef4    1        s     u  ==
Bf3    1        s     u  ==
Ef4    1        s     u  ==
Bf3    1        s     u  ]]    )
measure 24
rest   1        s
Bf3    1        s     u  [[    (
Gf4    1        s f   u  ==
Bf3    1        s     u  ==
Ef4    1        s     u  ==
Bf3    1        s     u  ]]    )
measure 25
rest   1        s
Bf3    1        s     u  [[    (
D4     1        s     u  ==
Bf3    1        s     u  ==
D4     1        s     u  ==
Bf3    1        s     u  ]]    )
measure 26
Bf4    2        e     d        f
P C32:y5
rest   2        e
rest   2        e
measure 27
D5     2        e     d
rest   2        e
rest   2        e
measure 28
G4     2        e     u
rest   2        e
rest   2        e
measure 29
Bf4    2        e     d
rest   2        e
rest   2        e
measure 30
Ef4    2        e     u
rest   2        e
rest   2        e
measure 31
G4     2        e     u
rest   2        e
rest   2        e
measure 32
rest   1        s
Af4    1        s     u        .
G4     1        s     u  [[    .
F4     1        s     u  ==    .
Ef4    1        s     u  ==    .
D4     1        s     u  ]]    .
measure 33
Ef4    2        e     u        &1.
rest   2        e
rest   2        e
measure 34
G4     2        e     u        .p
rest   2        e
rest   2        e
measure 35
Af4    2        e     u        .
rest   2        e
rest   2        e
measure 36
D5     2        e     d        .
rest   2        e
rest   2        e
measure 37
Ef5    2        e     d        .
rest   2        e
rest   2        e
measure 38
Df5    2        e f   d        .
rest   2        e
rest   2        e
measure 39
C5     2        e     d        .
rest   2        e
rest   2        e
measure 40
F4     2        e     u        .
rest   2        e
rest   2        e
measure 41
Ef4    2        e     u
G4     2        e     u  [     .
G4     2        e     u  ]     .
measure 42
G4     2        e     u  [     (f
P C33:y10
Af4    2        e     u  ]     )
F4     2        e     u        .p
measure 43
F4     2        e     u  [     (f
P C33:y10
G4     2        e     u  ]     )
Ef4    2        e     u        .p
measure 44
Ef4    2        e     u  [     (f
P C33:y10
F4     2        e     u  ]     )
D4     2        e     u        .p
mheavy4 45      :|:
C4     2        e     u
C4     2        e     u  [     f&1.
C4     2        e     u  ]     &1.
measure 46
C4     2        e     u  [     (
Df4    2        e f   u  =     )
Bf3    2        e     u  ]     .
measure 47
Bf3    2        e     u  [     (
C4     2        e     u  =     )
Af3    2        e     u  ]     .
measure 48
Af3    2        e     u  [     (
Bf3    2        e     u  =     )
G3     2        e     u  ]     .
measure 49
Af3    1        s     u        .
Af3    1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 50
rest   1        s
Bf3    1        s     u  [[    (
Df4    1        s f   u  ==
Ef4    1        s     u  ==
Df4    1        s     u  ==
Bf3    1        s     u  ]]    )
measure 51
rest   1        s
Af3    1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 52
rest   1        s
G3     1        s     u  [[    (
Bf3    1        s     u  ==
Ef4    1        s     u  ==
Bf3    1        s     u  ==
G3     1        s     u  ]]    )
measure 53
rest   1        s
Bf3    1        s     u  [[    (
Df4    1        s f   u  ==
Ef4    1        s     u  ==
Df4    1        s     u  ==
Bf3    1        s     u  ]]    )
measure 54
rest   1        s
Af3    1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 55
rest   1        s
G3     1        s     u  [[    (
Bf3    1        s     u  ==
Ef4    1        s     u  ==
Bf3    1        s     u  ==
G3     1        s     u  ]]    )
measure 56
rest   1        s
Af3    1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 57
rest   2        e
C4     2        e     u  [     .
C4     2        e     u  ]     .
measure 58
C4     2        e     u  [     (
G4     2        e     u  ]     )
C4     2        e     u        .
measure 59
C4     2        e     u  [     (
Af4    2    @   e     u  ]     )
@ B&H has F4 here; cf. vn1, m51 and vc, m67.
C4     2        e     u        .
measure 60
C4     2        e     u  [     (
Bf4    2        e     u  ]     )
rest   2        e
measure 61
rest   2        e
Bf4    2        e     u  [     (
C4     2        e     u  ]     )
measure 62
C4     2        e     u  [     (
Af4    2        e     u  ]     )
C4     2        e     u        .
measure 63
C4     2        e     u  [     (
G4     2        e     u  ]     )
C4     2        e     u        .
measure 64
C4     2        e     u  [     (
F4     2        e     u  ]     )
rest   2        e
measure 65
rest   1        s
G3     1        s     u  [[    (
B3     1        s n   u  ==
D4     1        s     u  ==
G4     1        s     u  ==
D4     1        s     u  ]]    )
measure 66
rest   1        s
G3     1        s     u  [[    (
B3     1        s n   u  ==
D4     1        s     u  ==
F4     1        s     u  ==
D4     1        s     u  ]]    )
measure 67
rest   1        s
G3     1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 68
rest   1        s
D4     1        s     u  [[    (
B3     1        s n   u  ==
D4     1        s     u  ==
G3     1        s     u  ==
B3     1        s     u  ]]    )
measure 69
rest   1        s
G4     1        s     u  [[    (
D4     1        s     u  ==
G4     1        s     u  ==
B3     1        s n   u  ==
D4     1        s     u  ]]    )
measure 70
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ]]    )
measure 71
rest   1        s
F4     1        s     u  [[    (
D4     1        s     u  ==
B3     1        s n   u  ==
G3     1        s     u  ==
F4     1        s     u  ]]    )
measure 72
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Ef4    1        s     u  ==
B3     1        s n   u  ==
C4     1        s     u  ]]    )
measure 73
F#4    6        q.#   u
measure 74
F#4    6        q.#   u
measure 75
F#4    6        q.#   u        (
measure 76
G4     2        e     u        )
rest   2        e
rest   2        e
measure 77
rest   1        s
Ef4    1        s     u  [[    (p
P C33:y10
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 78
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 79
rest   1        s
F4     1        s     u  [[    (
Af4    1        s     u  ==
F4     1        s     u  ==
B4     1        s n   u  ==
F4     1        s     u  ]]    )
measure 80
rest   1        s
C5     1        s     u  [[    (
G4     1        s     u  ==
C5     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ]]    )
measure 81
rest   1        s
Af4    1        s     u  [[    (
F4     1        s     u  ==
Af4    1        s     u  ==
F4     1        s     u  ==
Af4    1        s     u  ]]    )
measure 82
rest   1        s
Af4    1        s     u  [[    (
D4     1        s     u  ==
Af4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 83
rest   1        s
Af4    1        s     u  [[    (
D4     1        s     u  ==
Af4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 84
rest   1        s
Ef4    1        s     u  [[    (
A4     1        s n   u  ==
Ef4    1        s     u  ==
A4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 85
rest   1        s
D4     1        s     u  [[    (
Af4    1        s f   u  ==    +
D4     1        s     u  ==
G4     1        s     u  ==
D4     1        s     u  ]]    )
measure 86
rest   1        s
C4     1        s     u  [[    (
Ef4    1        s     u  ==
C4     1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 87
rest   1        s
Ef4    1        s     u  [[    (
F4     1        s     u  ==
D4     1        s     u  ==
G4     1        s     u  ==
F4     1        s     u  ]]    )
measure 88
Ef4    2        e     u  [     .
G4     2        e     u  =     .f
G4     2        e     u  ]     .
measure 89
G4     2        e     u  [     (
B3     2        e n   u  ]     )
B3     2        e     u        .
measure 90
rest   2        e
C5     2        e     d  [     .
C5     2        e     d  ]     .
measure 91
C5     2        e     u  [     (
G4     2        e     u  ]     )
G4     2        e     u        &1.
measure 92
rest   2        e
F4     2        e     u  [     .
F4     2        e     u  ]     .
measure 93
F4     2        e     u  [     (
D4     2        e     u  =
G4     2        e     u  ]     )
measure 94
Ef4    2        e     u  [     (
C4     2        e     u  =
F4     2        e     u  ]     )
measure 95
Ef4    4        q     u        (
D4     2        e     u        )
measure 96
rest   1        s
G3     1        s     u  [[    (p
B3     1        s n   u  ==
G3     1        s     u  ==
D4     1        s     u  ==
B3     1        s     u  ]]    )
measure 97
rest   1        s
G3     1        s     u  [[    (
C4     1        s     u  ==
G3     1        s     u  ==
C4     1        s     u  ==
G3     1        s     u  ]]    )
measure 98
rest   1        s
G3     1        s     u  [[    (
Ef4    1        s     u  ==
G3     1        s     u  ==
C4     1        s     u  ==
G3     1        s     u  ]]    )
measure 99
rest   1        s
G3     1        s     u  [[    (
B3     1        s n   u  ==
G3     1        s     u  ==
B3     1        s     u  ==
G3     1        s     u  ]]    )
measure 100
G4     2        e     u        f
rest   2        e
rest   2        e
measure 101
Bf4    2        e     d
rest   2        e
rest   2        e
measure 102
Ef4    2        e     u
rest   2        e
rest   2        e
measure 103
G4     2        e     u
rest   2        e
rest   2        e
measure 104
C4     2        e     u
rest   2        e
rest   2        e
measure 105
Ef4    2        e     u
rest   2        e
rest   2        e
measure 106
rest   1        s
F4     1        s     u        &1.
Ef4    1        s     u  [[    .
D4     1        s     u  ==    .
C4     1        s     u  ==    .
B3     1        s n   u  ]]    .
measure 107
C4     2        e     u        &1.
rest   2        e
rest   2        e
measure 108
G4     2        e     u        p&1.
rest   2        e
rest   2        e
measure 109
F4     2        e     u        .
rest   2        e
rest   2        e
measure 110
B4     2        e n   d        .
rest   2        e
rest   2        e
measure 111
C5     2        e     d        .
rest   2        e
rest   2        e
measure 112
E4     2        e n   u        .
rest   2        e
rest   2        e
measure 113
F4     2        e     u        .
rest   2        e
rest   2        e
measure 114
F4     2        e     u        .
rest   2        e
rest   2        e
measure 115
Ef4    2        e f   u  [     +
G4     2        e     u  =     &1.
G4     2        e     u  ]     &1.
measure 116
G4     2        e     u  [     (f
P C33:y10
Af4    2        e     u  ]     )
F4     2        e     u        .p
measure 117
F4     2        e     u  [     (f
P C33:y10
G4     2        e     u  ]     )
Ef4    2        e     u        .p
measure 118
Ef4    2        e     u  [     (f
P C33:y10
F4     2        e     u  ]     )
D4     2        e     u        .p
mheavy2 119     :|
$  D:Coda
C4     1        s     u  [[    f
P C32:y5
Ef4    1        s     u  ==    (
G4     1        s     u  ==
Ef4    1        s     u  ==
G4     1        s     u  ==
Ef4    1        s     u  ]]    )
measure 120
rest   1        s
F4     1        s     u  [[    (
D4     1        s     u  ==
F4     1        s     u  ==
D4     1        s     u  ==
F4     1        s     u  ]]    )
measure 121
rest   1        s
Ef4    1        s     u  [[    (
G4     1        s     u  ==
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ]]    )
measure 122
rest   1        s
D4     1        s     u  [[    (
F4     1        s     u  ==
D4     1        s     u  ==
G4     1        s     u  ==
F4     1        s     u  ]]    )
measure 123
Ef4    2        e     u  [
Ef4    2        e     u  =     p
Ef4    2        e     u  ]
measure 124
Ef4    2        e     u  [     (
F4     2        e     u  =
D4     2        e     u  ]     )
measure 125
D4     6        q.    u        (
measure 126
C4     2        e     u        )
rest   2        e
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/02/03} [KHM:3699691340]
TIMESTAMP: DEC/26/2001 [md5sum:974359760a8b8b038de1f065124d28bc]
03/24/94 E. Correia
WK#:157       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Viola
0 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-3   Q:4   T:3/8  C:13  D:Andante
C3     4        q     u        p
rest   2        e
measure 2
C3     4        q     u
rest   2        e
measure 3
D3     4        q     u
rest   2        e
measure 4
Ef3    4        q     u
rest   2        e
measure 5
F3     4        q     u
rest   2        e
measure 6
F3     4        q     u        (
Ef3    2        e     u        )
measure 7
F3     4        q     u        (
Ef3    2        e     u        )
measure 8
C4     6        q.    d        (
measure 9
B3     6        q.n   u        )
measure 10
C4     4        q     d
rest   2        e
measure 11
G3     4        q     u
rest   2        e
measure 12
C3     2        e     u  [
C5     2        e     d  =
C5     2        e     d  ]
measure 13
C5     2        e     d  [     (
Bf4    2        e     d  =
Af4    2        e     d  ]     )
measure 14
G4     1        s     d  [[
Ef4    1        s     d  ==    (f
Bf3    1        s     d  ==
Ef4    1        s     d  ==
G3     1        s     d  ==
Ef4    1        s     d  ]]    )
measure 15
rest   1        s
D4     1        s     d  [[    (
F4     1        s     d  ==
Bf3    1        s     d  ==
F4     1        s     d  ==
Bf3    1        s     d  ]]    )
measure 16
rest   1        s
G3     1        s     u  [[    (
C4     1        s     u  ==
G3     1        s     u  ==
C4     1        s     u  ==
G3     1        s     u  ]]    )
measure 17
rest   1        s
Bf3    1        s     d  [[    (
G4     1        s     d  ==
Ef4    1        s     d  ==
Bf4    1        s     d  ==
G4     1        s     d  ]]    )
measure 18
rest   1        s
D4     1        s     d  [[    (
F4     1        s     d  ==
D4     1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ]]    )
measure 19
rest   1        s
Bf3    1        s     d  [[    (
D4     1        s     d  ==
Bf3    1        s     d  ==
F4     1        s     d  ==
Bf3    1        s     d  ]]    )
measure 20
rest   1        s
Bf3    1        s     d  [[    (
G4     1        s     d  ==
Ef4    1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]    )
measure 21
rest   1        s
Bf3    1        s     d  [[    (
Ef4    1        s     d  ==
Bf3    1        s     d  ==
D4     1        s     d  ==
Bf3    1        s     d  ]]    )
measure 22
F3     6        q.    u        (p
P C33:y5
measure 23
Ef3    6        q.    u        )
measure 24
Bf3    6-       q.    u        -
measure 25
Bf3    6        q.    u
measure 26
rest   2        e
G4     2        e     d  [     .f
P C33:y5
G4     2        e     d  ]     .
measure 27
F4     2        e     d  [     (
D4     2        e     d  =     )
D4     2        e     d  ]     .
measure 28
rest   2        e
Ef4    2        e     d  [     .
Ef4    2        e     d  ]     .
measure 29
D4     2        e     d  [     (
Bf3    2        e     d  ]     )
Bf3    2        e     u        &1.
measure 30
rest   2        e
C4     2        e     d  [     .
C4     2        e     d  ]     .
measure 31
Bf3    2        e     u  [     (
G3     2        e     u  ]     )
G3     2        e     u        .
measure 32
C4     2        e     d  [
Ef4    2        e     d  ]
Bf3    1        s     u  [[    (
Af3    1        s     u  ]]    )
measure 33
G3     2        e     u        &1.
rest   2        e
rest   2        e
measure 34
Bf3    2        e     u        .p
rest   2        e
rest   2        e
measure 35
C4     2        e     d        .
rest   2        e
rest   2        e
measure 36
F4     2        e     d        .
rest   2        e
rest   2        e
measure 37
Bf3    2        e     u        .
rest   2        e
rest   2        e
measure 38
G4     2        e     d        .
rest   2        e
rest   2        e
measure 39
Ef4    2        e     d        .
rest   2        e
rest   2        e
measure 40
Af3    2        e     u        .
rest   2        e
rest   2        e
measure 41
G3     2        e     u
Ef4    2        e     d  [     .
Ef4    2        e     d  ]     .
measure 42
Ef4    2        e     d  [     (f
F4     2        e     d  ]     )
D4     2        e     d        .p
measure 43
D4     2        e     d  [     (f
Ef4    2        e     d  ]     )
C4     2        e     d        .p
measure 44
C4     2        e     d  [     (f
D4     2        e     d  ]     )
B3     2        e n   u        p&1.
mheavy4 45      :|:
C4     2        e     d
C4     2        e     d  [     .&1f
C4     2        e     d  ]     .
measure 46
C4     2        e     d  [     (
Df4    2        e f   d  =     )
Bf3    2        e     d  ]     .
measure 47
Bf3    2        e     u  [     (
C4     2        e     u  =     )
Af3    2        e     u  ]     .
measure 48
Af3    2        e     u  [     (
Bf3    2        e     u  =     )
G3     2        e     u  ]     .
measure 49
Af3    2        e     u
C5     2        e     d  [     (
Af4    2        e     d  ]     )
measure 50
rest   2        e
Df5    2        e f   d  [     (
Bf4    2        e     d  ]     )
measure 51
rest   2        e
Af4    2        e     d  [     (
C5     2        e     d  ]     )
measure 52
rest   2        e
G4     2        e     d  [     (
Ef4    2        e     d  ]     )
measure 53
rest   2        e
Bf3    2        e     u  [     (
G3     2        e     u  ]     )
measure 54
rest   2        e
Af3    2        e     u  [     (
Ef3    2        e     u  ]     )
measure 55
rest   2        e
G4     2        e     d  [     (
Df4    2        e f   d  ]     )
measure 56
C4     2        e     d  [
Ef4    2        e     d  =
Af4    2        e     d  ]
measure 57
rest   1        s
C4     1        s     d  [[    (
F4     1        s     d  ==
Af4    1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ]]    )
measure 58
rest   1        s
G3     1        s     u  [[    (
Bf3    1        s     u  ==
C4     1        s     u  ==
Bf3    1        s     u  ==
G3     1        s     u  ]]    )
measure 59
rest   1        s
Af3    1        s     d  [[    (
C4     1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ==
Af3    1        s     d  ]]    )
measure 60
rest   1        s
Bf3    1        s     d  [[    (
E4     1        s n   d  ==
G4     1        s     d  ==
Bf4    1        s     d  ==
G4     1        s     d  ]]    )
measure 61
rest   1        s
C4     1        s     d  [[    (
E4     1        s n   d  ==
G4     1        s     d  ==
E4     1        s     d  ==
C4     1        s     d  ]]    )
measure 62
rest   1        s
C4     1        s     d  [[    (
F4     1        s     d  ==
Af4    1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ]]    )
measure 63
rest   1        s
Bf3    1        s     d  [[    (
C4     1        s     d  ==
E4     1        s n   d  ==
Bf3    1        s     d  ==
C4     1        s     d  ]]    )
measure 64
rest   1        s
Af3    1        s     d  [[    (
C4     1        s     d  ==
F4     1        s     d  ==
C4     1        s     d  ==
Af3    1        s     d  ]]    )
measure 65
G3     2        e     u
rest   2        e
rest   2        e
measure 66
B3     6        q.n   u        (
measure 67
C4     6        q.    d
measure 68
D4     6        q.    d
measure 69
B3     6        q.n   u
measure 70
C4     6        q.    d
measure 71
B3     6        q.n   u        )
measure 72
C4     4        q     d
rest   2        e
measure 73
C4     2        e     d  [     (
D4     2        e     d  =
Ef4    2        e     d  ]     )
measure 74
C4     2        e     d  [     (
D4     2        e     d  =
Ef4    2        e     d  ]     )
measure 75
Ef4    6        q.    d        (
measure 76
D4     2        e     d        )
rest   2        e
rest   2        e
measure 77
C3     4        q     u        p
rest   2        e
measure 78
C3     4        q     u
rest   2        e
measure 79
D3     4        q     u
rest   2        e
measure 80
Ef3    4        q     u
rest   2        e
measure 81
F3     4        q     u
rest   2        e
measure 82
F3     4        q     u        (
Ef3    2        e     u        )
measure 83
F3     4        q     u        (
Ef3    2        e     u        )
measure 84
C4     6        q.    d        (
measure 85
B3     6        q.n   u        )
measure 86
C4     4        q     d
rest   2        e
measure 87
G3     4        q     u
rest   2        e
measure 88
rest   1        s
G3     1        s     u  [[    (f
P C33:y10
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
G3     1        s     u  ]]    )
measure 89
rest   1        s
G3     1        s     d  [[    (
D4     1        s     d  ==
G4     1        s     d  ==
F4     1        s     d  ==
D4     1        s     d  ]]    )
measure 90
rest   1        s
Ef4    1        s     d  [[    (
C4     1        s     d  ==
Af3    1        s     d  ==
C4     1        s     d  ==
Ef4    1        s     d  ]]    )
measure 91
rest   1        s
G3     1        s     u  [[    (
C4     1        s     u  ==
Ef4    1        s     u  ==
C4     1        s     u  ==
G3     1        s     u  ]]    )
measure 92
rest   1        s
G3     1        s     u  [[    (
B3     1        s n   u  ==
G3     1        s     u  ==
C4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 93
rest   1        s
D4     1        s     u  [[    (
B3     1        s n   u  ==
D4     1        s     u  ==
G3     1        s     u  ==
D4     1        s     u  ]]    )
measure 94
rest   1        s
C4     1        s     u  [[    (
G3     1        s     u  ==
Ef4    1        s     u  ==
D4     1        s     u  ==
Af3    1        s     u  ]]    )
measure 95
rest   1        s
G3     1        s     u  [[    (
C4     1        s     u  ==
G3     1        s     u  ==
B3     1        s n   u  ==
G3     1        s     u  ]]    )
measure 96
D3     6        q.    u        (p
measure 97
C3     6        q.    u        )
measure 98
G3     6-       q.    u        -
measure 99
G3     6        q.    u
measure 100
rest   2        e
Ef4    2        e     d  [     .f
Ef4    2        e     d  ]     .
measure 101
D4     2        e     d  [     (
Bf3    2        e     d  =     )
Bf3    2        e     d  ]     .
measure 102
rest   2        e
C4     2        e     d  [     .
C4     2        e     d  ]     .
measure 103
Bf3    2        e     u  [     (
G3     2        e     u  ]     )
G3     2        e     u        .
measure 104
rest   2        e
Af3    2        e     u  [     .
Af3    2        e     u  ]     .
measure 105
G3     2        e     u  [     (
Ef3    2        e     u  ]     )
Ef3    2        e     u        .
measure 106
rest   2        e
G3     2        e     u  [     .
G3     2        e     u  ]     .
measure 107
Ef3    2        e     u        .
rest   2        e
rest   2        e
measure 108
E4     2        e n   d        p&1.
rest   2        e
rest   2        e
measure 109
C4     2        e     d        .
rest   2        e
rest   2        e
measure 110
D4     2        e     d        .
rest   2        e
rest   2        e
measure 111
G3     2        e     u        .
rest   2        e
rest   2        e
measure 112
G4     2        e     d        .
rest   2        e
rest   2        e
measure 113
C4     2        e     d        .
rest   2        e
rest   2        e
measure 114
D4     2        e     d        .
rest   2        e
rest   2        e
measure 115
G3     2        e     d  [
Ef4    2        e f   d  =     +&1.
Ef4    2        e     d  ]      &1.
measure 116
Ef4    2        e     d  [     (f
F4     2        e     d  ]     )
D4     2        e     d        .p
measure 117
D4     2        e     d  [     (f
Ef4    2        e     d  ]     )
C4     2        e     d        p&1.
measure 118
C4     2        e     d  [     (f
D4     2        e     d  ]     )
B3     2        e n   u        .p
mheavy2 119     :|
$  D:Coda
C4     2        e     d  [     f
G4     2        e     d  =     &1.
G4     2        e     d  ]     &1.
measure 120
G4     2        e     d  [     (
B3     2        e n   d  =
D4     2        e     d  ]     )
measure 121
C4     2        e     d  [     (
Ef4    2        e     d  =
G4     2        e     d  ]     )
measure 122
G4     2        e     d  [     (
B3     2        e n   d  =
D4     2        e     d  ]     )
measure 123
C4     4        q     d
rest   2        e
measure 124
B3     6        q.n   u        p
measure 125
B3     6        q.n   u        (
measure 126
C4     2        e     d        )
rest   2        e
rest   2        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k157/stage2/02/04} [KHM:3699691340]
TIMESTAMP: DEC/26/2001 [md5sum:0359d848c07b6351453b9508b8be1099]
03/24/94 E. Correia
WK#:157       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 4 for 2 violins, viola, and violoncello

Violoncello
0 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-3   Q:4   T:3/8  C:22  D:Andante
rest   6
measure 2
rest   6
measure 3
rest   6
measure 4
rest   6
measure 5
rest   6
measure 6
rest   6
measure 7
rest   6
measure 8
rest   6
measure 9
rest   6
measure 10
rest   6
measure 11
rest   6
measure 12
C3     6        q.    u        (p
measure 13
D3     6        q.    d        )
measure 14
Ef3    4        q     d        f
rest   2        e
measure 15
Bf2    4        q     u
rest   2        e
measure 16
C3     4        q     u
rest   2        e
measure 17
G2     4        q     u
rest   2        e
measure 18
F3     4        q     d        (
Ef3    2        e     d        )
measure 19
D3     6        q.    d
measure 20
Ef3    4        q     d        (
C3     2        e     u        )
measure 21
Bf2    6        q.    u
measure 22
Bf2    6-       q.    u        -p
measure 23
Bf2    6-       q.    u        -
measure 24
Bf2    6-       q.    u        -
measure 25
Bf2    6        q.    u
measure 26
rest   2        e
Ef4    2        e     d  [     .f
Ef4    2        e     d  ]     .
measure 27
D4     2        e     d  [     (
Bf3    2        e     d  =     )
Bf3    2        e     d  ]     .
measure 28
rest   2        e
C4     2        e     d  [     .
C4     2        e     d  ]     .
measure 29
Bf3    2        e     d  [     (
G3     2        e     d  ]     )
G3     2        e     d        &1.
measure 30
rest   2        e
Af3    2        e     d  [     .
Af3    2        e     d  ]     .
measure 31
G3     2        e     d  [     (
Ef3    2        e     d  ]     )
Ef3    2        e     d        .
measure 32
Af3    2        e     d  [
Bf3    2        e     d  =
Bf2    2        e     d  ]
measure 33
rest   1        s
Ef3    1        s     d  [[    (
G3     1        s     d  ==
Bf3    1        s     d  ==
G3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 34
rest   1        s
Ef3    1        s     d  [[    (p
P C33:y5
G3     1        s     d  ==
Bf3    1        s     d  ==
G3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 35
rest   1        s
Ef3    1        s     d  [[    (
Af3    1        s     d  ==
C4     1        s     d  ==
Af3    1        s     d  ==
Ef3    1        s     d  ]]    )
measure 36
rest   1        s
Ef3    1        s     d  [[    (
F3     1        s     d  ==
Af3    1        s     d  ==
F3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 37
rest   1        s
Ef3    1        s     d  [[    (
G3     1        s     d  ==
Bf3    1        s     d  ==
G3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 38
rest   1        s
Ef3    1        s     d  [[    (
G3     1        s     d  ==
Bf3    1        s     d  ==
G3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 39
rest   1        s
Ef3    1        s     d  [[    (
Af3    1        s     d  ==
C4     1        s     d  ==
Af3    1        s     d  ==
Ef3    1        s     d  ]]    )
measure 40
rest   1        s
Ef3    1        s     d  [[    (
F3     1        s     d  ==
Af3    1        s     d  ==
F3     1        s     d  ==
Ef3    1        s     d  ]]    )
measure 41
Ef2    4        q     u
rest   2        e
measure 42
rest   6
measure 43
rest   6
measure 44
rest   6
mheavy4 45      :|:
rest   2        e
C3     2        e     u  [     .&1f
C3     2        e     u  ]     .
measure 46
C3     2        e     u  [     (
Df3    2        e f   u  =     )
Bf2    2        e     u  ]     .
measure 47
Bf2    2        e     u  [     (
C3     2        e     u  =     )
Af2    2        e     u  ]     .
measure 48
Af2    2        e     u  [     (
Bf2    2        e     u  =     )
G2     2        e     u  ]     .
measure 49
Af2    6        q.    u
measure 50
G2     6        q.    u
measure 51
Af2    6        q.    u
measure 52
Bf2    6        q.    u
measure 53
G3     6        q.    d
measure 54
Af3    6        q.    d
measure 55
Ef3    6        q.    d
measure 56
Af2    6        q.    u
measure 57
F3     6        q.    d
measure 58
E3     6        q.n   d
measure 59
F3     6        q.    d
measure 60
G3     6        q.    d
measure 61
E3     6        q.n   d
measure 62
F3     6        q.    d
measure 63
C3     6        q.    u
measure 64
F2     6        q.    u
measure 65
rest   2        e
G2     2        e     u  [     &1.
G2     2        e     u  ]     &1.
measure 66
G2     2        e     u  [     (
D3     2        e     u  =     )
G2     2        e     u  ]     .
measure 67
G2     2        e     u  [     (
Ef3    2        e     u  =     )
G2     2        e     u  ]     .
measure 68
G2     2        e     u  [     (
F3     2        e     u  ]     )
rest   2        e
measure 69
rest   2        e
F3     2        e     u  [     (
G2     2        e     u  ]     )
measure 70
G2     2        e     u  [     (
Ef3    2        e     u  =     )
G2     2        e     u  ]     .
measure 71
G2     2        e     u  [     (
D3     2        e     u  =     )
G2     2        e     u  ]     .
measure 72
G2     2        e     u  [     (
C3     2        e     u  ]     )
rest   2        e
measure 73
Af2    6        q.    u
measure 74
Af2    6        q.    u
measure 75
G2     2        e     u  [
G2     2        e     u  =
G2     2        e     u  ]
measure 76
G2     2        e     u
rest   2        e
rest   2        e
measure 77
rest   6
measure 78
rest   6
measure 79
rest   6
measure 80
rest   6
measure 81
rest   6
measure 82
rest   6
measure 83
rest   6
measure 84
rest   6
measure 85
rest   6
measure 86
rest   6
measure 87
rest   6
measure 88
C3     4        q     u        f
rest   2        e
measure 89
G2     4        q     u
rest   2        e
measure 90
Af2    4        q     u
rest   2        e
measure 91
Ef2    4        q     u
rest   2        e
measure 92
D3     4        q     d        (
C3     2        e     u        )
measure 93
B2     6        q.n   u
measure 94
C3     4        q     u        (
F3     2        e     d        )
measure 95
G3     6        q.    d
measure 96
G2     6-       q.    u        -p
measure 97
G2     6-       q.    u        -
measure 98
G2     6-       q.    u        -
measure 99
G2     6        q.    u
measure 100
rest   2        e
C4     2        e     d  [     .f
C4     2        e     d  ]     .
measure 101
Bf3    2        e     d  [     (
G3     2        e     d  =     )
G3     2        e     d  ]     .
measure 102
rest   2        e
Af3    2        e     d  [     .
Af3    2        e     d  ]     .
measure 103
G3     2        e     d  [     (
Ef3    2        e     d  ]     )
Ef3    2        e     d        .
measure 104
rest   2        e
F3     2        e     d  [     .
F3     2        e     d  ]     .
measure 105
Ef3    2        e     d  [     (
C3     2        e     d  ]     )
C3     2        e     u        &1.
measure 106
F3     2        e     d  [
G3     2        e     d  =
G2     2        e     d  ]
measure 107
rest   1        s
C3     1        s     d  [[    (
Ef3    1        s     d  ==
G3     1        s     d  ==
Ef3    1        s     d  ==
C3     1        s     d  ]]    )
measure 108
rest   1        s
C3     1        s     d  [[    (p
E3     1        s n   d  ==
G3     1        s     d  ==
E3     1        s     d  ==
C3     1        s     d  ]]    )
measure 109
rest   1        s
C3     1        s     d  [[    (
F3     1        s     d  ==
Af3    1        s     d  ==
F3     1        s     d  ==
C3     1        s     d  ]]    )
measure 110
rest   1        s
C3     1        s     d  [[    (
D3     1        s     d  ==
F3     1        s     d  ==
D3     1        s     d  ==
C3     1        s     d  ]]    )
measure 111
rest   1        s
C3     1        s     d  [[    (
Ef3    1        s f   d  ==    +
G3     1        s     d  ==
Ef3    1        s     d  ==
C3     1        s     d  ]]    )
measure 112
rest   1        s
C3     1        s     d  [[    (
E3     1        s n   d  ==
G3     1        s     d  ==
E3     1        s     d  ==
C3     1        s     d  ]]    )
measure 113
rest   1        s
C3     1        s     d  [[    (
F3     1        s     d  ==
Af3    1        s     d  ==
F3     1        s     d  ==
C3     1        s     d  ]]    )
measure 114
rest   1        s
C3     1        s     d  [[    (
D3     1        s     d  ==
F3     1        s     d  ==
D3     1        s     d  ==
C3     1        s     d  ]]    )
measure 115
C2     4        q     u
rest   2        e
measure 116
rest   6
measure 117
rest   6
measure 118
rest   6
mheavy2 119     :|
$  D:Coda
C3     6        q.    u        (&1f
measure 120
G2     6        q.    u
measure 121
Ef2    6        q.    u
measure 122
G2     6        q.    u        )
measure 123
C2     4        q     u
rest   2        e
measure 124
G2     6        q.    u        p
measure 125
C3     6-       q.    u        -
measure 126
C3     2        e     u
rest   2        e
rest   2        e
mheavy2
/END
/eof
//
