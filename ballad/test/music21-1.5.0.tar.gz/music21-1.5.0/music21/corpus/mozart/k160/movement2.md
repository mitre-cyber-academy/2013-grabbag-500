&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/02/01} [KHM:1155094300]
TIMESTAMP: DEC/26/2001 [md5sum:496df17dedb2fcd6ee94bbe894271a1a]
06/29/94 E. Correia
WK#:160       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-4   Q:8   T:3/4  C:4  D:Un poco Adagio
Ef5    6        e.    d  [     (&0p
F5     2        s     d  ]\    )
D5     4        e n   d
rest   4        e
rest   8        q
measure 2
Df5    6        e.f   d  [     (+
Ef5    2        s     d  ]\    )
C5     4        e     d
rest   4        e
rest   8        q
measure 3
C5     4        e     d  [     (
Bf4    2        s     d  ]\    )
rest   2        s
Bf4    4        e     u  [     (
Af4    2        s     u  ]\    )
rest   2        s
Af4    4        e     u  [     (
G4     2        s     u  ]\    )
rest   2        s
measure 4
Af4    4        e     d  [     (
F5     4        e     d  ]     )
Ef5   16        h     d        fp
measure 5
Ef5    4        e     d  [     (
Df5    2        s     d  ]\    )
rest   2        s
Df5    4        e     d  [     (
C5     2        s     d  ]\    )
rest   2        s
C5     4        e     d  [     (
Bf4    2        s     d  ]\    )
rest   2        s
measure 6
Af4   24-       h.    u        -
measure 7
Af4    8        q     u
Af5   12        q.    d        (
G5     2        s     d  [[
F5     2        s     d  ]]    )
measure 8
gF5    5        s     u
S C1:t50
Ef5    4        e     d  [     (
Df5    2        s     d  =[
C5     2        s     d  ]]    )
gBf4   5        s     u        (
S C1:t25
Af4   16-       h     u        )-
measure 9
Af4    8        q     u
Af5   12        q.    d        (
G5     2        s     d  [[
F5     2        s     d  ]]    )
measure 10
gF5    5        s     u
S C1:t25
Ef5    8        q     d
Ef5   12        q.    d        (
E5     4        e n   d        )
measure 11
E5     8        q n   d        (
F5     2        s     d  [[    )
G5     2        s     d  ==    (.
Af5    2        s     d  ==     .
G5     2        s     d  ]]     .
F5     2        s     d  [[     .
Ef5    2        s f   d  ==     .
Df5    2        s     d  ==     .
C5     2        s     d  ]]    ).
measure 12
C5     6        e.    d  [     (t
S C33:hn10s10t90
Bf4    1        t     d  =[[
C5     1        t     d  ]]]   )
Bf4    8        q     d
rest   8        q
measure 13
F5    24-       h.    d        -&0f
measure 14
F5    16        h     d
G5     8        q     d
measure 15
Af5    6        e.    d  [     (
F5     2        s     d  ]\    )
Ef5    8        q     d
D5     8        q n   d
measure 16
D5     8        q     d        (&1^
Ef5    4        e     u  [     )
Ef4    4        e     u  =     (p
Af4    4        e     u  =
C5     4        e     u  ]     )
measure 17
Bf4    6        e.    d  [     (f
C5     2        s     d  ]\    )
Bf4    4        e     d
Ef4    4        e     u  [     (p
Af4    4        e     u  =
C5     4        e     u  ]     )
measure 18
Bf4    6        e.    d  [     (f
C5     2        s     d  ]\    )
Bf4    4        e     d
G5     1        t     d  [[[   (p
F5     1        t     d  ===
G5     1        t     d  ===
Af5    1        t     d  ]]]   )
Bf5    2        s     d  [[    .
Bf5    2        s     d  ==    .
Bf5    2        s     d  ==    .
Bf5    2        s     d  ]]    .
measure 19
Bf5    4        e     d  [     (
Af5    4        e     d  =
G5     4        e     d  =
F5     4        e     d  =
Ef5    4        e     d  =
Df5    4        e f   d  ]     )+
measure 20
*               D       cresc.
P C17:f33
C5     4        e     u  [     (
Bf4    4        e     u  =
Af4    4        e     u  =
G4     4        e     u  =
F4     4        e     u  =
E4     4        e n   u  ]     )
measure 21
F4     4        e     d  [     f
Af5    2        s     d  =[    (
F5     2        s     d  ]]    )
Ef5    8        q     d
D5     8        q n   d
measure 22
D5    16        h n   d        (
Ef5    4        e     d        )
rest   4        e
mheavy4 23      :|:
Bf4    6        e.    u  [     (p
G4     2        s     u  ]\    )
Bf4    8        q     d        (
C5     8        q     d        )
measure 24
C5    16        h     d        (fp
Df5    4        e f   d        )+
rest   4        e
measure 25
C5     6        e.    d  [     (p
Af4    2        s     d  ]\    )
C5     8        q     d        (
Df5    8        q     d        )
measure 26
D5    16        h n   d        (fp
Ef5    4        e     d        )
rest   4        e
measure 27
rest   8        q
Ef5    8        q     d
Ef5    8        q     d
measure 28
Ef5    8        q     d        (
Df5    8        q f   d        +
C5     8        q     d        )
measure 29
C5     8        q     d        (
Bf4    8        q     d
Af4    8        q     u        )
measure 30
Af4    6        e.    u  [     (t
S C33:n10s10t90
G4     1        t     u  =[[
Af4    1        t     u  ]]]   )
G4     8        q     u
rest   8        q
measure 31
Ef5    6        e.    d  [     (
F5     2        s     d  ]\    )
D5     4        e n   d        .
rest   4        e
rest   8        q
measure 32
Df5    6        e.f   d  [     (+
Ef5    2        s     d  ]\    )
C5     4        e     d        .
rest   4        e
rest   8        q
measure 33
C5     4        e     d  [     (
Bf4    2        s     d  ]\    )
rest   2        s
Bf4    4        e     u  [     (
Af4    2        s     u  ]\    )
rest   2        s
Af4    4        e     u  [     (
G4     2        s     u  ]\    )
rest   2        s
measure 34
Af4    4        e     d  [     (
F5     4        e     d  ]     )
Ef5   16        h     d        fp
measure 35
Ef5    4        e     d  [     (
Df5    2        s     d  ]\    )
rest   2        s
Df5    4        e     d  [     (
C5     2        s     d  ]\    )
rest   2        s
C5     4        e     d  [     (
Bf4    2        s     d  ]\    )
rest   2        s
measure 36
Af4   16        h     u
Gf4    8        q f   u
measure 37
F4    24-       h.    u        -
measure 38
F4    12        q.    u
F5     4        e     d
gEf5   5        s     u
S C1:t50
Df5    4        e     d  [     (
C5     2        s     d  =[
Bf4    2        s     d  ]]    )
measure 39
gAf4   5        s     u
S C1:t50
G4     4        e     u  [     (
F4     2        s     u  =[
Ef4    2        s     u  ]]    )
Ef4   16        h     u
measure 40
Ef4   12        q.    u
Ef5    4        e     d
gDf5   5        s     u
S C1:t50
C5     4        e     d  [     (
Bf4    2        s     d  =[
Af4    2        s     d  ]]    )
measure 41
E5     8        q n   d        (
F5     2        s     d  [[    )
G5     2        s     d  ==    (.
Af5    2        s     d  ==     .
G5     2        s     d  ]]     .
F5     2        s     d  [[     .
Ef5    2        s f   d  ==     .
Df5    2        s     d  ==     .
C5     2        s     d  ]]    ).
measure 42
C5     6        e.    d  [     (t
S C33:hn10s10t90
Bf4    1        t     d  =[[
C5     1        t     d  ]]]   )
Bf4    8        q     d
rest   8        q
measure 43
Gf5   24        h.f   d        &0f
measure 44
F5    24        h.    d
measure 45
Ef5   24        h.    d
measure 46
D5    24        h.n   d
measure 47
Df5   24        h.f   d        +
measure 48
C5     8        q     d        (
Df5    8        q     d
Ef5    8        q     d        )
measure 49
gEf5   5        s     u
S C1:t50
Df5    4        e     d  [     (
C5     2        s     d  =[
Bf4    2        s     d  ]]    )
Af4    8        q     u        (
G4     8        q     u        )
measure 50
G4     8        q     u        (
Af4    4        e     u        )
Af3    4        e     u  [     (p
Df4    4        e     u  =
F4     4        e     u  ]     )
measure 51
Ef4    6        e.    u  [     (f
P C33:y10
F4     2        s     u  ]\    )
Ef4    4        e     u
Af4    4        e     d  [     (p
Df5    4        e     d  =
F5     4        e     d  ]     )
measure 52
Ef5    6        e.    d  [     (f
F5     2        s     d  ]\    )
Ef5    4        e     d
C6     1        t     d  [[[   (p
Bf5    1        t     d  ===
C6     1        t     d  ===
Df6    1        t     d  ]]]   )
Ef6    2        s     d  [[    .
Ef6    2        s     d  ==    .
Ef6    2        s     d  ==    .
Ef6    2        s     d  ]]    .
measure 53
Ef6    4        e     d  [     (
Df6    4        e     d  =
C6     4        e     d  =
Bf5    4        e     d  =
Af5    4        e     d  =
Gf5    4        e f   d  ]     )
measure 54
*               D       cresc.
P C17:f33
F5     4        e     d  [     (
Ef5    4        e     d  =
Df5    4        e     d  =
C5     4        e     d  =
Bf4    4        e     d  =
A4     4        e n   d  ]     )
measure 55
Bf4    2        s     d  [[    (f
F5     2        s     d  ==
Df5    2        s     d  ==
Bf4    2        s     d  ]]    )
Af4    8        q f   u        (+
G4     8        q     u        )
measure 56
Af4    8        q     u
Af5    4        e     d  [     (p
G5     2        s     d  ]\    )
rest   2        s
F5     4        e     d  [     (
Ef5    2        s     d  ]\    )
rest   2        s
measure 57
Df5    4        e     d  [     (
C5     2        s     d  ]\    )
rest   2        s
Bf4    4        e     d  [     (
C5     2        s     d  ]\    )
rest   2        s
Df5    4        e     d  [     (
Ef5    2        s     d  ]\    )
rest   2        s
measure 58
B4     4        e n   d  [     (
C5     2        s     d  ]\    )
rest   2        s
Af5    4        e     d  [     (
G5     2        s     d  ]\    )
rest   2        s
F5     4        e     d  [     (
Ef5    2        s     d  ]\    )
rest   2        s
measure 59
Df5    4        e     d  [     (
C5     2        s     d  ]\    )
rest   2        s
Bf4    4        e f   d  [     (+
C5     2        s     d  ]\    )
rest   2        s
Df5    4        e     d  [     (
Bf4    2        s     d  ]\    )
rest   2        s
measure 60
Af4    4        e     u
Ef4    8        q     u        (
F4     4        e     u  [
Ef4    4        e     u  =
Df4    4        e     u  ]     )
measure 61
C4     4        e     u
C4     8        q     u        (
Df4    4        e     u  [
C4     4        e     u  =
Bf3    4        e     u  ]     )
measure 62
Bf3   16        h     u        (
Af3    4        e     u        )
rest   4        e
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/02/02} [KHM:1155094300]
TIMESTAMP: DEC/26/2001 [md5sum:a82875692271196c80e0a8e3a876c35d]
06/29/94 E. Correia
WK#:160       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-4   Q:8   T:3/4  C:4  D:Un poco Adagio
C5     8        q     d        (&0p
Bf4    4        e     d        )
rest   4        e
rest   8        q
measure 2
Bf4    8        q     d        (
Af4    4        e     u        )
rest   4        e
rest   8        q
measure 3
F4     8        q     u        (
Ef4    8        q     u
Df4    8        q     u        )
measure 4
C4     8        q     u
Bf3    8        q     u        (fp
P C33:y10
C4     8        q     u        )
measure 5
C4     4        e     u  [     (
Bf3    2        s     u  ]\    )
rest   2        s
Bf3    4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
Af3    4        e     u  [     (
G3     2        s     u  ]\    )
rest   2        s
measure 6
Af3    4        e     u
C4     8        q     u
Ef4    8        q     u
Gf4    4-       e f   u        -
measure 7
Gf4    4        e     u
F4     8        q     u
Df4    8        q     u
Af4    4-       e     u        -
measure 8
Af4    4        e     u
Ef4    8        q     u
Af3    8        q     u
Gf4    4-       e f   u        -
measure 9
Gf4    4        e     u
F4     8        q     u
Df4    8        q     u
Af4    4-       e     u        -
measure 10
Af4    2        s     u  [[    (
Ef4    2        s     u  ==
Df4    2        s     u  ==
C4     2        s     u  ]]    )
C4     8        q     u
Af3    8-       q     u        -
measure 11
Af3    4        e     u  [     (
C4     4        e     u  ]     )
Df4    2        s     u  [[    (.
Ef4    2        s     u  ==     .
F4     2        s     u  ==     .
Ef4    2        s     u  ]]     .
Df4    2        s     u  [[     .
C4     2        s     u  ==     .
Bf3    2        s     u  ==     .
Af3    2        s     u  ]]    ).
measure 12
Af3    6        e.    u  [     (t
S C33:n10s10t90
G3     1        t     u  =[[
Af3    1        t     u  ]]]   )
G3     8        q     u
rest   8        q
measure 13
Ef5   24        h.    d        &0f
measure 14
D5    16        h n   d
Ef5    8        q     d
measure 15
C5     6        e.    d  [     (
Af4    2        s     d  ]\    )
G4     8        q     u
F4     8        q     u
measure 16
F4     8        q     u        (
Ef4    8        q     u        )
Ef4    8        q     u        p
measure 17
F4     8        q     u        (f
P C33:y15
Ef4    8        q     u        )
Ef4    8        q     u        p
measure 18
F4     8        q     u        (f
P C33:y15
Ef4    4        e     u        )
Ef4    1        t     u  [[[   (p
D4     1        t n   u  ===
Ef4    1        t     u  ===
F4     1        t     u  ]]]   )
G4     2        s     u  [[    .
G4     2        s     u  ==    .
G4     2        s     u  ==    .
G4     2        s     u  ]]    .
measure 19
G4     4        e     u  [     (
F4     4        e     u  =
Ef4    4        e     u  =
Df4    4        e f   u  =     +
C4     4        e     u  =
Bf3    4        e     u  ]     )
measure 20
*               D       cresc.
P C17:f33 C17:y5
Af3    4        e     u
Ef4    8        q     u        (
Df4    4        e     u  [
C4     4        e     u  =
Bf3    4        e     u  ]     )
measure 21
C4     4        e     u  [     f
C5     2        s     u  =[    (
Af4    2        s     u  ]]    )
G4     8        q     u
F4     8        q     u
measure 22
F4    16        h     u        (
Ef4    4        e     u        )
rest   4        e
mheavy4 23      :|:
G4     6        e.    u  [     (p
P C33:y10
Ef4    2        s     u  ]\    )
G3     8        q     u        (
Af3    8        q     u        )
measure 24
A3    16        h n   u        (fp
P C33:y10
Bf3    4        e     u        )
rest   4        e
measure 25
Ef4    6        e.    u  [     (p
P C33:y10
C4     2        s     u  ]\    )
Af3    8        q f   u        (+
Bf3    8        q     u        )
measure 26
B3    16        h n   u        (fp
P C33:y10
C4     4        e     u        )
rest   4        e
measure 27
rest   8        q
Gf4    8        q f   u
Gf4    8        q     u
measure 28
F4    16        h     u
Ef4    8-       q     u        -
measure 29
Ef4    8        q     u        (
Df4    8        q     u
C4     8        q     u        )
measure 30
C4     6        e.    u  [     (t
S C33:hn10s10t90
Bf3    1        t     u  =[[
C4     1        t     u  ]]]   )
Bf3    8        q     u
rest   8        q
measure 31
C5     8        q     d        (
Bf4    4        e     d        )
rest   4        e
rest   8        q
measure 32
Bf4    8        q     d        (
Af4    4        e     u        )
rest   4        e
rest   8        q
measure 33
F4     8        q     u        (
Ef4    8        q     u
Df4    8        q     u        )
measure 34
C4     8        q     u
Bf3    8    @   q     u        (fp
P C33:y10
@ Beginning of slur corrected by analogy with measure 4.
C4     8        q     u        )
measure 35
C4     4        e     u  [     (
Bf3    2        s     u  ]\    )
rest   2        s
Bf3    4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
Af3    4        e     u  [     (
G3     2        s     u  ]\    )
rest   2        s
measure 36
Af3    4        e     u
C4     8        q     u
Ef4    8        q     u
Df4    4        e     u        (
measure 37
C4     4        e     u        )
C4     8        q     u
A3     8        q n   u
C4     4        e     u        (
measure 38
Df4    4        e     u        )
F4     8        q     u
Df4    8        q     u
F4     4        e     u
measure 39
Bf3    4        e     u
Df4    8        q     u
Bf3    8        q     u
G3     4        e     u
measure 40
Af3    4        e f   u        +
Ef4    8        q     u
C4     8        q     u
Ef4    4        e     u
measure 41
Af4    8-       q     u        -
Af4    2        s     u  [[
G4     2        s     u  ==    (.
F4     2        s     u  ==     .
Ef4    2        s     u  ]]     .
Df4    2        s     u  [[     .
C4     2        s     u  ==     .
Bf3    2        s     u  ==     .
Af3    2        s     u  ]]    ).
measure 42
Af3    6        e.    u  [     (t
S C33:n10s10t90
G3     1        t     u  =[[
Af3    1        t     u  ]]]   )
G3     8        q     u
rest   8        q
measure 43
Af4   24        h.    u        &0f
measure 44
Af4   24        h.    u
measure 45
F4    24        h.    u
measure 46
F4    24        h.    u
measure 47
Ef4   16        h     u        (
Bf4    8        q     d        )
measure 48
Af4    8        q     u        (
G4     8        q     u
Gf4    8        q f   u        )
measure 49
gGf4   5        s f   u
S C1:t50
F4     4        e     u  [     (
Ef4    2        s     u  =[
Df4    2        s     u  ]]    )
C4     8        q     u        (
Bf3    8        q     u        )
measure 50
Bf3    8        q     u        (
Af3    4        e     u        )
rest   4        e
Af3    8        q     u        p
measure 51
Bf3    8        q     u        (f
P C33:y10
Af3    8        q     u        )
Af4    8        q     u        p
measure 52
Df5    8        q     d        (f
C5     4        e     d        )
Af4    1        t     u  [[[   (&1p
G4     1        t     u  ===
Af4    1        t     u  ===
Bf4    1        t     u  ]]]   )
C5     2        s     d  [[    .
C5     2        s     d  ==    .
C5     2        s     d  ==    .
C5     2        s     d  ]]    .
measure 53
C5     4        e     u  [     (
Bf4    4        e     u  =
Af4    4        e     u  =
Gf4    4        e f   u  =
F4     4        e     u  =
Ef4    4        e     u  ]     )
measure 54
*               D       cresc.
P C17:f33
Df4    4        e     u
Af4    8        q     u        (
Gf4    4        e f   u  [
F4     4        e     u  =
Ef4    4        e     u  ]     )
measure 55
F4     2        s     u  [[    (f
P C33:y15
Af4    2        s     u  ==
F4     2        s     u  ==
Df4    2        s     u  ]]    )
C4     4        e     u  [     (
Ef4    4        e     u  ]     )
gEf4   5        s     u
S C1:t50
Df4    4        e     u  [     (
C4     2        s     u  =[
Bf3    2        s     u  ]]    )
measure 56
Af3    8        q     u
F4     4        e     u  [     (&1p
Ef4    2        s     u  ]\    )
rest   2        s
Df4    4        e     u  [     (
C4     2        s     u  ]\    )
rest   2        s
measure 57
Bf3    4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
G3     4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
Bf3    4        e     u  [     (
C4     2        s     u  ]\    )
rest   2        s
measure 58
G3     4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
F4     4        e     u  [     (
Ef4    2        s     u  ]\    )
rest   2        s
Df4    4        e     u  [     (
C4     2        s     u  ]\    )
rest   2        s
measure 59
Bf3    4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
G3     4        e     u  [     (
Af3    2        s     u  ]\    )
rest   2        s
Bf3    4        e     u  [     (
G3     2        s     u  ]\    )
rest   2        s
measure 60
Af3    4        e     u
C4     8        q     u        (
Df4    4        e     u  [
C4     4        e     u  =
Bf3    4        e     u  ]     )
measure 61
Af3    4        e     u
Af3    8        q     u
Af3    8        q     u
G3     4        e     u
measure 62
G3    16        h     u        (
Af3    4        e     u        )
rest   4        e
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/02/03} [KHM:1155094300]
TIMESTAMP: DEC/26/2001 [md5sum:7496872e49d824a38d25d55552b7fc37]
06/29/94 E. Correia
WK#:160       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-4   Q:4   T:3/4  C:13  D:Un poco Adagio
A4     4        q n   d        (&0p
Bf4    2        e     d        )
rest   2        e
rest   4        q
measure 2
G4     4        q     d        (
Af4    2        e f   d        )+
rest   2        e
rest   4        q
measure 3
Df4    4        q     d        (
C4     4        q     d
Bf3    4        q     u        )
measure 4
Af3    4        q     u
Df4    4        q     d        (fp
C4     4        q     d        )
measure 5
F3     4        q     u
Ef3    8        h     u
measure 6
rest   2        e
Af3    4        q     u
C4     4        q     d
Ef4    2-       e     d        -
measure 7
Ef4    2        e     d
Df4    4        q     d
F4     4        q     d
Ef4    1        s     d  [[    (
Df4    1        s     d  ]]    )
measure 8
gDf4   5        s     u
S C1:t50
C4     2        e     u  [     (
Bf3    1        s     u  =[
Af3    1        s     u  ]]    )
C4     4        q     d
Ef4    4-       q     d        -
measure 9
Ef4    2        e     d
Df4    4        q     d
F4     4        q     d
Ef4    1        s     d  [[    (
Df4    1        s     d  ]]    )
measure 10
gDf4   5        s     u
S C1:t50
C4     2        e     u  [     (
Bf3    1        s     u  =[
Af3    1        s     u  ]]    )
Af3    4        q     u
C4     4-       q     d        -
measure 11
C4     2        e     u  [     (
Af3    2        e     u  ]     )
Af3    4        q     u
rest   4        q
measure 12
rest   2        e
Ef4    2        e     d  [     (
D4     2        e n   d  =
Ef4    2        e     d  =
F4     2        e     d  =
G4     2        e     d  ]     )
measure 13
C4     2        e     d  [     &0f
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 14
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 15
F4     3        e.    d  [     (
C4     1        s     d  ]\    )
Bf3    4        q     u
Af3    4        q     u
measure 16
Af3    4        q     u        (
G3     4        q     u        )
C4     4        q     d        p
measure 17
Af3    4        q     u        (f
P C33:y10
G3     4        q     u        )
C4     4        q     d        p
measure 18
Af3    4        q     u        (f
P C33:y10
G3     4        q     u        )
rest   4        q
measure 19
Ef4   12        h.    d        p
measure 20
*               D       cresc.
P C17:f33
Ef4    2        e     d  [     (
Df4    2        e f   d  =     +
C4     2        e     d  =
Bf3    2        e     d  =
Af3    2        e     d  =
Df4    2        e     d  ]     )
measure 21
C4     4        q     d        (f
Bf3    4        q     u
Af3    4        q     u        )
measure 22
Af3    8        h     u        (
G3     2        e     u        )
rest   2        e
mheavy4 23      :|:
Ef4    2        e     d  [     p
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
measure 24
Ef3    2        e     u  [     fp
Ef3    2        e     u  =
Ef3    2        e     u  =
Ef3    2        e     u  =
Ef3    2        e     u  =
Ef3    2        e     u  ]
measure 25
Af3    2        e     u  [
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  ]
measure 26
Af3    2        e     u  [     fp
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  ]
measure 27
Af3    2        e     u  [
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  ]
measure 28
Af3    8        h     u        (
A3     4        q n   u        )
measure 29
Bf3    4        q     u        (
F3     4        q     u        )
F3     4        q     u        .
measure 30
Ef3    4        q     u
Ef3    4        q     u
rest   4        q
measure 31
Gf4    4        q f   d        (
F4     2        e     d        )
rest   2        e
rest   4        q
measure 32
Ef4    4-       q     d        -
Ef4    2        e     d
rest   2        e
rest   4        q
measure 33
Df4    4        q     d        (
C4     4        q     d
Bf3    4        q     u        )
measure 34
Af3    4        q f   u        +
Df4    4        q     d        (fp
C4     4        q     d        )
measure 35
F3     4        q     u
Ef3    8        h     u
measure 36
rest   2        e
Af3    4        q     u
C4     2        e     d
Bf3    2        e     u  [
Bf3    2        e     u  ]
measure 37
A3     2        e n   u
Ef4    4        q     d
C4     4        q     u
A3     2        e     u
measure 38
Bf3    2        e     u
Df4    4        q     d
Bf3    4        q     d
Df4    2-       e     d        -
measure 39
Df4    2        e     d
Bf3    4        q     u
G3     4        q     u
Df4    2        e     d
measure 40
C4     2        e     d
C4     4        q     d
Af3    4        q     u
C4     2        e     d
measure 41
C4     4        q     d        (
Df4    2        e     d        )
rest   2        e
rest   4        q
measure 42
rest   2        e
Ef4    2        e     d  [     (
D4     2        e n   d  =
Ef4    2        e     d  =
Df4    2        e f   d  =
Ef4    2        e     d  ]     )
measure 43
Ef4    2        e     d  [     &0f
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
measure 44
Df4    2        e     d  [
Df4    2        e     d  =
Df4    2        e     d  =
Df4    2        e     d  =
Df4    2        e     d  =
Df4    2        e     d  ]
measure 45
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 46
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 47
Bf3    8        h     u        (
Ef4    4        q     d        )
measure 48
Ef4    8        h     d        (
Af3    4        q     u        )
measure 49
rest   2        e
F3     2        e     u        (
Ef3    4        q     u
Df3    4        q     u        )
measure 50
Df3    4        q     u        (
C3     2        e     u        )
rest   2        e
F3     4        q     u        p
measure 51
Df3    4        q     u        (f
P C33:y10
C3     4        q     u        )
F4     4        q     d        p
measure 52
Bf4    4        q     d        (f
Af4    4        q     d        )
rest   4        q
measure 53
Af3   12        h.    u        p
measure 54
*               D       cresc.
P C17:f33
Af3    2        e     d  [     (
C4     2        e     d  =
Df4    2        e     d  =
Ef4    2        e     d  =
Df4    2        e     d  =
Gf4    2        e f   d  ]     )
measure 55
F4     2        e     d  [     f
Bf3    2        e     d  ]
Ef4    4        q     d
Ef3    4        q     u
measure 56
C4     4        q     d
rest   4        q
rest   4        q
measure 57
rest  12
measure 58
rest   4        q
Af4    2        e     d  [     (&1p
G4     1        s n   d  ]\    )+
rest   1        s
F4     2        e     d  [     (
Ef4    1        s     d  ]\    )
rest   1        s
measure 59
Df4    2        e     d  [     (
C4     1        s     d  ]\    )
rest   1        s
Bf3    2        e     u  [     (
C4     1        s     u  ]\    )
rest   1        s
Df4    2        e     d  [     (
Bf3    1        s     d  ]\    )
rest   1        s
measure 60
Af3   12-       h.    u        -
measure 61
Af3    2        e     u
Ef3    4        q     u        (
F3     2        e     u  [
Ef3    2        e     u  =
Df3    2        e     u  ]     )
measure 62
Df3    8        h     u        (
C3     2        e     u        )
rest   2        e
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/02/04} [KHM:1155094300]
TIMESTAMP: DEC/26/2001 [md5sum:5f5526b858807e78dc08a4264745da08]
06/29/94 E. Correia
WK#:160       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-4   Q:2   T:3/4  C:22  D:Un poco Adagio
F3     2        q     d        (&0p
Bf2    1        e     u        )
rest   1        e
rest   2        q
measure 2
Ef3    2        q     d        (
Af2    1        e     u        )
rest   1        e
rest   2        q
measure 3
Df3    2        q     d        (
Ef3    2        q     d
E3     2        q n   d        )
measure 4
F3     2        q     d
G3     2        q     d        (fp
Af3    2        q     d        )
measure 5
Df3    2        q     d
Ef3    2        q     d
Ef2    2        q     u
measure 6
Af2    2        q     u
Af3    2        q     d
C3     2        q     u
measure 7
Df3    2        q     d
Df3    2        q     d
Df3    2        q     d
measure 8
Af2    2        q     u
Af3    2        q     d
C3     2        q     u
measure 9
Df3    2        q     d
Df3    2        q     d
Df3    2        q     d
measure 10
Af3    2        q     d
Af2    2        q     u
C3     2        q     u
measure 11
Df3    2        q     d
Df3    2        q     d
rest   2        q
measure 12
rest   1        e
Ef3    1        e     d  [     (
D3     1        e n   d  =
Ef3    1        e     d  =
F3     1        e     d  =
G3     1        e     d  ]     )
measure 13
A2     1        e n   u  [     &0f
P C32:y5
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  ]
measure 14
Af2    1        e f   u  [     +
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
G2     1        e     u  =
G2     1        e     u  ]
measure 15
F2     1        e     u  [
Af2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 16
C3     4        h     u
C3     2        q     u        p
measure 17
D3     2        q n   d        (f
Ef3    2        q     d        )
C3     2        q     u        p
measure 18
D3     2        q n   d        (f
Ef3    2        q     d        )
rest   2        q
measure 19
Ef3    6        h.    d        p
measure 20
*               D       cresc.
P C17:f33 C17:y-10
Af3    1        e     d  [     (
Bf3    1        e     d  =
C4     1        e     d  =
Bf3    1        e     d  =
Af3    1        e     d  =
G3     1        e     d  ]     )
measure 21
Af3    2        q     d        f
Bf3    2        q     d
Bf2    2        q     u
measure 22
Ef3    4-       h     d        -
Ef3    1        e     d
rest   1        e
mheavy4 23      :|:
Ef3    1        e     d  [     p
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 24
Ef2    1        e     u  [     fp
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
measure 25
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
measure 26
Af2    1        e     u  [     fp
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
measure 27
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 28
Df3    1        e f   d  [     +
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  ]
measure 29
Df3    1        e     d  [
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  =
D3     1        e n   d  =
D3     1        e     d  ]
measure 30
Ef3    2        q     d
Ef2    2        q     u
rest   2        q
measure 31
A3     2        q n   d        (
Bf3    1        e     d        )
rest   1        e
rest   2        q
measure 32
G3     2        q     d        (
Af3    1        e f   d        )+
rest   1        e
rest   2        q
measure 33
Df3    2        q     d        (
Ef3    2        q     d
E3     2        q n   d        )
measure 34
F3     2        q     d
G3     2        q     d        (fp
Af3    2        q     d        )
measure 35
Df3    2        q     d
Ef3    2        q f   d        +
Ef2    2        q     u
measure 36
Af2    2        q     u
C3     2        q     u
Bf2    2        q     u
measure 37
A2     2        q n   u
F2     2        q     u
Ef3    2        q     d
measure 38
Df3    2        q     d
Bf2    2        q     u
Bf3    2        q     d
measure 39
Ef3    2        q     d
Df3    2        q     d
Bf2    2        q     u
measure 40
Af2    2        q f   u        +
C3     2        q     u
Af2    2        q     u
measure 41
Df3    2        q     d
Df3    2        q     d
rest   2        q
measure 42
rest   1        e
Ef3    1        e     d  [     (
D3     1        e n   d  =
Ef3    1        e     d  =
Df3    1        e f   d  =
Ef3    1        e     d  ]     )
measure 43
C3     1        e     u  [     &0f
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 44
Df3    1        e     d  [
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  =
Df3    1        e     d  ]
measure 45
A2     1        e n   u  [
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  =
A2     1        e     u  ]
measure 46
Af2    1        e f   u  [     +
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
measure 47
G2     1        e     u  [
G2     1        e     u  =
G2     1        e     u  =
G2     1        e     u  =
G2     1        e     u  =
G2     1        e     u  ]
measure 48
Af2    1        e     u  [
Af2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 49
Df3    1        e     u  [
Df3    1        e     u  =
Ef3    1        e     u  =
Ef2    1        e     u  =
E2     1        e n   u  =
E2     1        e     u  ]
measure 50
F2     4        h     u
F2     2        q     u        p
measure 51
G2     2        q     u        (f
P C33:y10
Af2    2        q     u        )
F3     2        q     d        p
measure 52
G3     2        q     d        (f
Af3    2        q     d        )
rest   2        q
measure 53
Af2    6        h.    u        p
measure 54
*               D       cresc.
P C17:f33
Df3    1        e     d  [     (
Ef3    1        e     d  =
F3     1        e     d  =
Ef3    1        e     d  =
Df3    1        e     d  =
C3     1        e     d  ]     )
measure 55
Df3    1        e     u  [     f
Df3    1        e     u  =
Ef3    1        e     u  =
Ef3    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
measure 56
Af2    1        e     u  [     p
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
measure 57
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 58
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
measure 59
Ef2    1        e     u  [
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
measure 60
Af2    2        q     u
Af2    2        q     u
Af2    2        q     u
measure 61
Af2    2        q     u
Af2    2        q     u
Af2    2        q     u
measure 62
Af2    4-       h     u        -
Af2    1        e     u
rest   1        e
mheavy2         :|
/END
/eof
//
