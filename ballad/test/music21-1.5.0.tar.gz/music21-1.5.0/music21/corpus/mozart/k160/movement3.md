&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/03/01} [KHM:610969372]
TIMESTAMP: DEC/26/2001 [md5sum:911c3e6a003122e492eb86c920d2ac4e]
07/01/94 E. Correia
WK#:160       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-3   Q:24   T:2/4  C:4  D:Presto
Ef4   24        q     u        f
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 2
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 3
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 4
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 5
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 6
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 7
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 8
Bf4   24        q     d
rest  24        q
measure 9
Af5   24        q     d
Af5   24        q     d
measure 10
gBf5   5        s     u
S C1:t50
Af5   12        e     d  [
G5     6        s     d  =[
F5     6        s     d  ]]
G5    24-       q     d        -
measure 11
G5    12        e     d  [
C5    12        e     d  =
F5    12        e     d  =
Ef5   12        e     d  ]
measure 12
gEf5   5        s     u
S C1:t50
D5    24        q     d
C5    12        e     d  [
Bf4   12        e     d  ]
measure 13
Bf5   36        q.    d
D5    12        e     d
measure 14
C5     6        s     d  [[
D5     6        s     d  ==
C5     6        s     d  ==
D5     6        s     d  ]]
Ef5    6        s     d  [[
F5     6        s     d  ==
Ef5    6        s     d  ==
F5     6        s     d  ]]
measure 15
G5    24        q     d
Bf4   24        q     d
measure 16
A4    24        q n   u
rest  24        q
measure 17
C5    12        e     d  [     .p
D5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 18
C5    12        e     d  [     .
D5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 19
C5    12        e     d        .
A5    12        e n   d  [     (f
C6    12        e     d  =
Bf5   12        e     d  ]
measure 20
A5    12        e n   d  [
G5    12        e     d  =
F5    12        e     d  =
Ef5   12        e     d  ]     )
measure 21
D5    12        e     d  [     .p
Ef5   12        e     d  =     .
F5    12        e     d  =     .
Ef5   12        e     d  ]     .
measure 22
D5    12        e     d  [     .
Ef5   12        e     d  =     .
F5    12        e     d  =     .
Ef5   12        e     d  ]     .
measure 23
D5    12        e     d        .
F5    12        e     d  [     (f
Bf5   12        e     d  =
A5    12        e n   d  ]
measure 24
G5    12        e     d  [
F5    12        e     d  =
Ef5   12        e     d  =
D5    12        e     d  ]     )
measure 25
C5    12        e     d  [     .p
D5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 26
C5    12        e     d  [     .
D5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 27
C5    12        e     d        &1.
A5    12        e n   d  [     (f
C6    12        e     d  =
Bf5   12        e     d  ]
measure 28
A5    12        e n   d  [
G5    12        e     d  =
F5    12        e     d  =
Ef5   12        e     d  ]     )
measure 29
D5    24        q     d
F5     8        e  3  d  [     .*
D5     8        e  3  d  =     .
Bf4    8        e  3  d  ]     .!
measure 30
G5     8        e  3  d  [     (*
F#5    8        e #3  d  =
G5     8        e  3  d  ]     )!
Bf5    8        e  3  d  [     .*
A5     8        e n3  d  =     .
G5     8        e  3  d  ]     .!
measure 31
F5    24        q n   d        +
F5     8        e  3  d  [     *
D5     8        e  3  d  =
Bf4    8        e  3  d  ]     !
measure 32
G5     8        e  3  d  [     (
F#5    8        e #3  d  =
G5     8        e  3  d  ]     )
Bf5    8        e  3  d  [     .
A5     8        e n3  d  =     .
G5     8        e  3  d  ]     .
measure 33
F5    18        e.n   d  [     (+
G5     3        t     d  =[[   p
A5     3        t n   d  ]]]   )
Bf5   12        e     d  [     .
C6    12        e     d  ]     .
measure 34
D6    12        e     d  [     .
C6    12        e     d  =     .
Bf5   12        e     d  =     .
A5    12        e n   d  ]     .
measure 35
G5    24        q     d
G5    24        q     u        f
 Bf4  24        q     u
 Ef4  24        q     u
measure 36
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
A4    24        q n   u
 Ef4  24        q     u
 C4   24        q     u
measure 37
Bf4   24        q     u
 D4   24        q     u
 Bf3  24        q     u
F5     8        e  3  d  [     .
D5     8        e  3  d  =     .
Bf4    8        e  3  d  ]     .
measure 38
G5     8        e  3  d  [     (
F#5    8        e #3  d  =
G5     8        e  3  d  ]     )
Bf5    8        e  3  d  [     .
A5     8        e n3  d  =     .
G5     8        e  3  d  ]     .
measure 39
F5    24        q n   d        +
F5     8        e  3  d  [
D5     8        e  3  d  =
Bf4    8        e  3  d  ]
measure 40
G5     8        e  3  d  [     (
F#5    8        e #3  d  =
G5     8        e  3  d  ]     )
Bf5    8        e  3  d  [     .
A5     8        e n3  d  =     .
G5     8        e  3  d  ]     .
measure 41
F5    18        e.n   d  [     (+
G5     3        t     d  =[[   p
A5     3        t n   d  ]]]   )
Bf5   12        e     d  [     .
C6    12        e     d  ]     .
measure 42
D6    12        e     d  [     .
C6    12        e     d  =     .
Bf5   12        e     d  =     .
A5    12        e n   d  ]     .
measure 43
G5    24        q     d
G5    24        q     u        f
 Bf4  24        q     u
 Ef4  24        q     u
measure 44
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
A4    24        q n   u
 Ef4  24        q     u
 C4   24        q     u
measure 45
Bf4   24        q     u
 D4   24        q     u
 Bf3  24        q     u
rest  24        q
measure 46
rest  48
measure 47
F5     8        e  3  d  [     (p
G5     8        e  3  d  =
F5     8        e  3  d  ]
Ef5    8        e  3  d  [
F5     8        e  3  d  =
Ef5    8        e  3  d  ]
measure 48
D5     8        e  3  d  [
Ef5    8        e  3  d  =
D5     8        e  3  d  ]
C5     8        e  3  d  [
D5     8        e  3  d  =
C5     8        e  3  d  ]     )
measure 49
Bf4   24        q     d
rest  24        q
measure 50
rest  48
measure 51
F5     8        e  3  d  [     (
G5     8        e  3  d  =
F5     8        e  3  d  ]
Ef5    8        e  3  d  [
F5     8        e  3  d  =
Ef5    8        e  3  d  ]
measure 52
D5     8        e  3  d  [
Ef5    8        e  3  d  =
D5     8        e  3  d  ]
C5     8        e  3  d  [
D5     8        e  3  d  =
C5     8        e  3  d  ]     )
measure 53
Bf4   24        q     d
Bf5   24        q     d        f
 Bf4  24        q     d
 D4   24        q     d
measure 54
Bf3   24        q     u
rest  24        q
mheavy4 55      :|:
rest  12        e
F5    12        e     d  [     (p
D5    12        e     d  =
Bf4   12        e     d  ]     )
measure 56
rest  12        e
F5    12        e     d  [     (
D5    12        e     d  =
Bf4   12        e     d  ]     )
measure 57
rest  12        e
A4    12        e n   d  [     (
C5    12        e     d  =
Ef5   12        e     d  ]     )
measure 58
rest  12        e
A4    12        e n   d  [     (
C5    12        e     d  =
Ef5   12        e     d  ]     )
measure 59
D5     8        e  3  d  [     f
Ef5    8        e  3  d  =
F5     8        e  3  d  ]
G5     8        e  3  d  [
A5     8        e n3  d  =
Bf5    8        e  3  d  ]
measure 60
A5     8        e n3  d  [
Bf5    8        e  3  d  =
A5     8        e  3  d  ]
G5     8        e  3  d  [
F5     8        e  3  d  =
Ef5    8        e  3  d  ]
measure 61
D5    24        q     d
rest  24        q
measure 62
rest  48
measure 63
rest  12        e
F5    12        e     d  [     (p
D5    12        e     d  =
Bf4   12        e     d  ]     )
measure 64
rest  12        e
F5    12        e     d  [     (
D5    12        e     d  =
Bf4   12        e     d  ]     )
measure 65
rest  12        e
A4    12        e n   d  [     (
C5    12        e     d  =
Ef5   12        e     d  ]     )
measure 66
rest  12        e
A4    12        e n   d  [     (
C5    12        e     d  =
Ef5   12        e     d  ]     )
measure 67
D5     8        e  3  d  [     f
Ef5    8        e  3  d  =
F5     8        e  3  d  ]
G5     8        e  3  d  [
A5     8        e n3  d  =
Bf5    8        e  3  d  ]
measure 68
A5     8        e n3  d  [
Bf5    8        e  3  d  =
A5     8        e  3  d  ]
G5     8        e  3  d  [
F5     8        e  3  d  =
Ef5    8        e  3  d  ]
measure 69
D5    24        q     d
rest  24        q
measure 70
rest  48
measure 71
Bf3    8        e  3  u  [     p
D4     8        e  3  u  =
C4     8        e  3  u  ]
Bf3    8        e  3  u  [
D4     8        e  3  u  =
C4     8        e  3  u  ]
measure 72
Bf3    8        e  3  u  [
D4     8        e  3  u  =
Ef4    8        e  3  u  ]
F4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
measure 73
C4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
C4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
measure 74
C4     8        e  3  u  [
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 75
D4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
D4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 76
D4     8        e  3  u  [
F4     8        e  3  u  =
G4     8        e  3  u  ]
Af4    8        e f3  u  [     +
G4     8        e  3  u  =
F4     8        e  3  u  ]
measure 77
Ef4    8        e  3  u  [
G4     8        e  3  u  =
F4     8        e  3  u  ]
Ef4    8        e  3  u  [
G4     8        e  3  u  =
F4     8        e  3  u  ]
measure 78
Ef4    8        e  3  u  [
G4     8        e  3  u  =
Af4    8        e  3  u  ]
Bf4    8        e  3  u  [
Af4    8        e  3  u  =
G4     8        e  3  u  ]
measure 79
F4     8        e  3  u  [
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
G4     8        e  3  u  ]
measure 80
Af4    8        e f3  u  [     +
G4     8        e  3  u  =
Af4    8        e  3  u  ]
Bf4    8        e  3  d  [
Af4    8        e  3  d  =
Bf4    8        e  3  d  ]
measure 81
*               D       crescendo
P C17:f33 C17:y-5
C5     8        e  3  d  [
Bf4    8        e  3  d  =
C5     8        e  3  d  ]
Bf4    8        e  3  u  [
Af4    8        e  3  u  =
Bf4    8        e  3  u  ]
measure 82
C5     8        e  3  d  [
Bf4    8        e  3  d  =
C5     8        e  3  d  ]
D5     8        e  3  d  [
C5     8        e  3  d  =
D5     8        e  3  d  ]
measure 83
Ef5   12        e     u  [     f
Ef4   12        e     u  =
G4    12        e     u  =
Bf4   12        e     u  ]
measure 84
Af4   12        e     u  [
G4    12        e     u  =
F4    12        e     u  =
Ef4   12        e     u  ]
measure 85
D4    24        q     u
Bf5   24        q     d
 Bf4  24        q     d
 D4   24        q     d
measure 86
Bf3   24        q     u
rest  24        q
measure 87
Ef4   24        q     u
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 88
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 89
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 90
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 91
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 92
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 93
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 94
Bf4   24        q     d
rest  24        q
measure 95
Af5   24        q     d
Af5   24        q     d
measure 96
gBf5   5        s     u
S C1:t50
Af5   12        e     d  [
G5     6        s     d  =[
F5     6        s     d  ]]
G5    24-       q     d        -
measure 97
G5    12        e     d  [
C5    12        e     d  =
F5    12        e     d  =
Ef5   12        e     d  ]
measure 98
gEf5   5        s     u
S C1:t50
D5    24        q     d
C5    12        e     d  [
Bf4   12        e     d  ]
measure 99
Ef4   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 100
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 101
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 102
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 103
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 104
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 105
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 106
Bf4   24        q     d
rest  24        q
measure 107
Af5   24        q     d
Af5   24        q     d
measure 108
gBf5   5        s     u
S C1:t50
Af5   12        e     d  [
G5     6        s     d  =[
F5     6        s     d  ]]
gAf5   5        s     u
S C1:t50
G5    12        e     d  [
F5     6        s     d  =[
Ef5    6        s     d  ]]
measure 109
C5    24        q     d
gEf5   5        s     u
S C1:t50
D5    12        e     d  [
C5     6        s     d  =[
D5     6        s     d  ]]
measure 110
Ef5   24        q     d
rest  24        q
measure 111
Af4   12        e     u  [     .p
G4    12        e     u  =     .
F4    12        e     u  =     .
G4    12        e     u  ]     .
measure 112
Af4   12        e     u  [     .
G4    12        e     u  =     .
F4    12        e     u  =     .
G4    12        e     u  ]     .
measure 113
Af4   12        e     u        .
D5    12        e     d  [     (f
F5    12        e     d  =
Ef5   12        e     d  ]
measure 114
D5    12        e     d  [
C5    12        e     d  =
Bf4   12        e     d  =
Af4   12        e     d  ]     )
measure 115
Bf4   12        e     u  [     .p
Af4   12        e     u  =     .
G4    12        e     u  =     .
Af4   12        e     u  ]     .
measure 116
Bf4   12        e     u  [     .
Af4   12        e     u  =     .
G4    12        e     u  =     .
Af4   12        e     u  ]     .
measure 117
Bf4   12        e     d        .
Ef5   12        e     d  [     (f
G5    12        e     d  =
F5    12        e     d  ]
measure 118
Ef5   12        e     d  [
D5    12        e     d  =
C5    12        e     d  =
Bf4   12        e     d  ]     )
measure 119
Af4   12        e     u  [     .p
G4    12        e     u  =     .
F4    12        e     u  =     .
G4    12        e     u  ]     .
measure 120
Af4   12        e     u  [     .
G4    12        e     u  =     .
F4    12        e     u  =     .
G4    12        e     u  ]     .
measure 121
Af4   12        e     u        .
D5    12        e     d  [     (f
F5    12        e     d  =
Ef5   12        e     d  ]
measure 122
D5    12        e     d  [
C5    12        e     d  =
Bf4   12        e     d  =
Af4   12        e     d  ]     )
measure 123
G4    24        q     u
Bf4    8        e  3  u  [
G4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 124
C5     8        e  3  d  [     (
B4     8        e n3  d  =
C5     8        e  3  d  ]     )
Ef5    8        e  3  d  [     .
D5     8        e  3  d  =     .
C5     8        e  3  d  ]     .
measure 125
Bf4   24        q f   d        +
Bf4    8        e  3  u  [
G4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 126
C5     8        e  3  d  [     (
B4     8        e n3  d  =
C5     8        e  3  d  ]     )
Ef5    8        e  3  d  [     .
D5     8        e  3  d  =     .
C5     8        e  3  d  ]     .
measure 127
Bf4   18        e.f   d  [     (+
C5     3        t     d  =[[   p
D5     3        t     d  ]]]   )
Ef5   12        e     d  [     .
F5    12        e     d  ]     .
measure 128
G5    12        e     d  [     .
F5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 129
C5    24        q     d
C5    24        q     u        f
 Ef4  24        q     u
 Af3  24        q     u
measure 130
Bf4   24        q     u
 Ef4  24        q     u
 G3   24        q     u
D5    24        q     u
 F4   24        q     u
 Bf3  24        q     u
measure 131
Ef5   24        q     u
 G4   24        q     u
 Bf3  24        q     u
Bf4    8        e  3  u  [
G4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 132
C5     8        e  3  d  [     (
B4     8        e n3  d  =
C5     8        e  3  d  ]     )
Ef5    8        e  3  d  [     .
D5     8        e  3  d  =     .
C5     8        e  3  d  ]     .
measure 133
Bf4   24        q f   d        +
Bf4    8        e  3  u  [
G4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 134
C5     8        e  3  d  [     (
B4     8        e n3  d  =
C5     8        e  3  d  ]     )
Ef5    8        e  3  d  [     .
D5     8        e  3  d  =     .
C5     8        e  3  d  ]     .
measure 135
Bf4   18        e.f   d  [     (+
C5     3        t     d  =[[   p
D5     3        t     d  ]]]   )
Ef5   12        e     d  [     .
F5    12        e     d  ]     .
measure 136
G5    12        e     d  [     .
F5    12        e     d  =     .
Ef5   12        e     d  =     .
D5    12        e     d  ]     .
measure 137
C5    24        q     d
C5    24        q     u        f
 Ef4  24        q     u
 Af3  24        q     u
measure 138
Bf4   24        q     u
 Ef4  24        q     u
 G3   24        q     u
D5    24        q     u
 F4   24        q     u
 Bf3  24        q     u
measure 139
Ef5   24        q     u
 G4   24        q     u
 Bf3  24        q     u
rest  24        q
measure 140
rest  48
measure 141
Bf5    8        e  3  d  [     (p
C6     8        e  3  d  =
Bf5    8        e  3  d  ]
Af5    8        e  3  d  [
Bf5    8        e  3  d  =
Af5    8        e  3  d  ]
measure 142
G5     8        e  3  d  [
Af5    8        e  3  d  =
G5     8        e  3  d  ]
F5     8        e  3  d  [
G5     8        e  3  d  =
F5     8        e  3  d  ]     )
measure 143
Ef5   24        q     d
rest  24        q
measure 144
rest  48
measure 145
Bf4    8        e  3  d  [     (
C5     8        e  3  d  =
Bf4    8        e  3  d  ]
Af4    8        e  3  u  [
Bf4    8        e  3  u  =
Af4    8        e  3  u  ]
measure 146
G4     8        e  3  u  [
Af4    8        e  3  u  =
G4     8        e  3  u  ]
F4     8        e  3  u  [
G4     8        e  3  u  =
F4     8        e  3  u  ]     )
measure 147
Ef4   24        q     u        f
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 148
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 149
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 150
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 151
Ef5   24        q     d
G5    24        q     d
 Bf4  24        q     d
 Ef4  24        q     d
measure 152
Af5   24        q     d
 C5   24        q     d
 Ef4  24        q     d
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
measure 153
Ef5   24        q     u
 Ef4  24        q     u
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 154
Ef4   24        q     u
 G3   24        q     u
rest  24        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/03/02} [KHM:610969372]
TIMESTAMP: DEC/26/2001 [md5sum:0725a061379d57f1074c3eccc36aabd5]
07/01/94 E. Correia
WK#:160       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-3   Q:24   T:2/4  C:4  D:Presto
Ef4   24        q     u        f
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 2
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 3
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 4
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 5
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 6
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 7
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 8
Bf4   24        q     d
rest  24        q
measure 9
C5    24        q     d
C5    24        q     d
measure 10
Bf4   24-       q     d        -
Bf4   12        e     u  [
Af4    6        s     u  =[
G4     6        s     u  ]]
measure 11
C5    36        q.    d
F4    12        e     u
measure 12
gG4    5        s     u
S C1:t50
F4    24        q     u
Ef4   12        e     u  [
D4    12        e     u  ]
measure 13
F5    36        q.    d
Bf4   12        e     d
measure 14
G4    24        q     u
C5     6        s     d  [[
D5     6        s     d  ==
C5     6        s     d  ==
D5     6        s     d  ]]
measure 15
Ef5   24        q     d
G4    24        q     u
measure 16
F4    24        q     u
rest  24        q
measure 17
A3    12        e n   u  [     .p
Bf3   12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 18
A3    12        e n   u  [     .
Bf3   12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 19
A3    12        e n   u        .
F4    12        e     u  [     (f
P C33:y10
A4    12        e n   u  =
G4    12        e     u  ]
measure 20
F4    12        e     u  [
Ef4   12        e     u  =
D4    12        e     u  =
C4    12        e     u  ]     )
measure 21
Bf3   12        e     u  [     .p
C4    12        e     u  =     .
D4    12        e     u  =     .
C4    12        e     u  ]     .
measure 22
Bf3   12        e     u  [     .
C4    12        e     u  =     .
D4    12        e     u  =     .
C4    12        e     u  ]     .
measure 23
Bf3   12        e     u        .
D4    12        e     u  [     (f
P C33:y10
G4    12        e     u  =
F4    12        e     u  ]
measure 24
Ef4   12        e     u  [
D4    12        e     u  =
C4    12        e     u  =
Bf3   12        e     u  ]     )
measure 25
A3    12        e n   u  [     .p
Bf3   12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 26
A3    12        e n   u  [     .
Bf3   12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 27
A3    12        e n   u        &1.
F4    12        e     u  [     (f
P C33:y10
A4    12        e n   u  =
G4    12        e     u  ]
measure 28
F4    12        e     u  [
Ef4   12        e     u  =
D4    12        e     u  =
C4    12        e     u  ]     )
measure 29
Bf3   24        q     u
Bf4   24-       q     d        -
measure 30
Bf4   24        q     d
G4     8        e  3  u  [     .*
F4     8        e  3  u  =     .
Ef4    8        e  3  u  ]     .!
measure 31
D4    24        q     u
Bf4   24-       q     d        -
measure 32
Bf4   24        q     d
G4     8        e  3  u  [     &1.
F4     8        e  3  u  =     &1.
Ef4    8        e  3  u  ]     &1.
measure 33
D4    18        e.    u  [     (
Ef4    3        t     u  =[[   p
P C32:y10
F4     3        t     u  ]]]   )
G4    12        e     u  [     .
A4    12        e n   u  ]     .
measure 34
Bf4   12        e     u  [     .
A4    12        e n   u  =     .
G4    12        e     u  =     .
F4    12        e     u  ]     .
measure 35
Ef4   24        q     u
G5    24        q     u        f
 Bf4  24        q     u
 Ef4  24        q     u
measure 36
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
A4    24        q n   u
 Ef4  24        q     u
 C4   24        q     u
measure 37
Bf4   24        q     u
 D4   24        q     u
 Bf3  24        q     u
Bf4   24-       q     d        -
measure 38
Bf4   24        q     d
G4     8        e  3  u  [     &1.
F4     8        e  3  u  =     &1.
Ef4    8        e  3  u  ]     &1.
measure 39
D4    24        q     u
Bf4   24-       q     d        -
measure 40
Bf4   24        q     d
G4     8        e  3  u  [     &1.
F4     8        e  3  u  =     &1.
Ef4    8        e  3  u  ]     &1.
measure 41
D4    18        e.    u  [     (
Ef4    3        t     u  =[[   p
P C32:y10
F4     3        t     u  ]]]   )
G4    12        e     u  [     .
A4    12        e n   u  ]     .
measure 42
Bf4   12        e     u  [     .
A4    12        e n   u  =     .
G4    12        e     u  =     .
F4    12        e     u  ]     .
measure 43
Ef4   24        q     u
G5    24        q     u        f
 Bf4  24        q     u
 Ef4  24        q     u
measure 44
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
A4    24        q n   u
 Ef4  24        q     u
 C4   24        q     u
measure 45
Bf4   24        q     u
 D4   24        q     u
 Bf3  24        q     u
F4     8        e  3  u  [     (p
P C33:y10
G4     8        e  3  u  =
F4     8        e  3  u  ]
measure 46
Ef4    8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
D4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]     )
measure 47
C4    48        h     u
measure 48
D4    24        q     u        (
Ef4   24        q     u        )
measure 49
D4    24        q     u
F4     8        e  3  u  [     (
G4     8        e  3  u  =
F4     8        e  3  u  ]
measure 50
Ef4    8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
D4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]     )
measure 51
C4    48        h     u
measure 52
D4    24        q     u        (
Ef4   24        q     u        )
measure 53
D4    24        q     u
D5    24        q     u        f
 F4   24        q     u
 Bf3  24        q     u
measure 54
Bf3   24        q     u
rest  24        q
mheavy4 55      :|:
rest  12        e
F4    12        e     u  [     (p
P C33:y10
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 56
rest  12        e
F4    12        e     u  [     (
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 57
rest  12        e
A3    12        e n   u  [     (
C4    12        e     u  =
Ef4   12        e     u  ]     )
measure 58
rest  12        e
A3    12        e n   u  [     (
C4    12        e     u  =
Ef4   12        e     u  ]     )
measure 59
D4     8        e  3  u  [     f
P C33:y5
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
A4     8        e n3  u  =
Bf4    8        e  3  u  ]
measure 60
A4     8        e n3  u  [
Bf4    8        e  3  u  =
A4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 61
D4    24        q     u
rest  24        q
measure 62
rest  48
measure 63
rest  12        e
F4    12        e     u  [     (p
P C33:y10
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 64
rest  12        e
F4    12        e     u  [     (
D4    12        e     u  =
Bf3   12        e     u  ]     )
measure 65
rest  12        e
A3    12        e n   u  [     (
C4    12        e     u  =
Ef4   12        e     u  ]     )
measure 66
rest  12        e
A3    12        e n   u  [     (
C4    12        e     u  =
Ef4   12        e     u  ]     )
measure 67
D4     8        e  3  u  [     f
P C33:y5
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
A4     8        e n3  u  =
Bf4    8        e  3  u  ]
measure 68
A4     8        e n3  u  [
Bf4    8        e  3  u  =
A4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 69
D4    24        q     u
rest  24        q
measure 70
rest  48
measure 71
rest  48
measure 72
rest  48
measure 73
rest  48
measure 74
rest  48
measure 75
Bf3    8        e  3  u  [     p
D4     8        e  3  u  =
C4     8        e  3  u  ]
Bf3    8        e  3  u  [
D4     8        e  3  u  =
C4     8        e  3  u  ]
measure 76
Bf3    8        e  3  u  [
D4     8        e  3  u  =
Ef4    8        e  3  u  ]
F4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
measure 77
C4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
C4     8        e  3  u  [
Ef4    8        e  3  u  =
D4     8        e  3  u  ]
measure 78
C4     8        e  3  u  [
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 79
D4     8        e  3  u  [
C4     8        e  3  u  =
D4     8        e  3  u  ]
Ef4    8        e  3  u  [
D4     8        e  3  u  =
Ef4    8        e  3  u  ]
measure 80
F4     8        e  3  u  [
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
G4     8        e  3  u  ]
measure 81
*               D       crescendo
P C17:f33 C17:y-10
Af4    8        e f3  u  [     +
G4     8        e  3  u  =
Af4    8        e  3  u  ]
G4     8        e  3  u  [
F4     8        e  3  u  =
G4     8        e  3  u  ]
measure 82
Af4    8        e  3  u  [
G4     8        e  3  u  =
Af4    8        e  3  u  ]
F4     8        e  3  u  [
Ef4    8        e  3  u  =
F4     8        e  3  u  ]
measure 83
Ef4   12        e     u  [     f
Ef4   12        e     u  =
G4    12        e     u  =
Bf4   12        e     u  ]
measure 84
Af4   12        e     u  [
G4    12        e     u  =
F4    12        e     u  =
Ef4   12        e     u  ]
measure 85
D4    24        q     u
Bf5   24        q     d
 Bf4  24        q     d
 D4   24        q     d
measure 86
Bf3   24        q     u
rest  24        q
measure 87
Ef4   24        q     u
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 88
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 89
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 90
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 91
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 92
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 93
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 94
Bf4   24        q     d
rest  24        q
measure 95
C5    24        q     d
C5    24        q     d
measure 96
Bf4   24-       q     d        -
Bf4   12        e     u  [
Af4    6        s     u  =[
G4     6        s     u  ]]
measure 97
C5    36        q.    d
F4    12        e     u
measure 98
gG4    5        s     u
S C1:t50
F4    24        q     u
Ef4   12        e     u  [
D4    12        e     u  ]
measure 99
Ef4   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 100
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 101
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 102
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 103
Ef5   12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
Ef5   12        e     u  ]
measure 104
D5    12        e     u  [
Ef4   12        e     u  =
Ef4   12        e     u  =
D5    12        e     u  ]
measure 105
C5    36        q.    d        (t
S C33:mn7s15t86
Bf4    6        s     d  [[
C5     6        s     d  ]]    )
measure 106
Bf4   24        q     d
rest  24        q
measure 107
C5    24        q     d
C5    24        q     d
measure 108
Bf4   24        q     d
gC5    5        s     u
S C1:t50
Bf4   12        e     u  [
Af4    6        s     u  =[
G4     6        s     u  ]]
measure 109
F4    12        e     u  [
Af4   12        e     u  ]
gG4    5        s     u
S C1:t50
F4    12        e     u  [
Ef4    6        s     u  =[
F4     6        s     u  ]]
measure 110
Ef4   24        q     u
rest  24        q
measure 111
F4    12        e     u  [     .p
Ef4   12        e     u  =     .
D4    12        e     u  =     .
Ef4   12        e     u  ]     .
measure 112
F4    12        e     u  [     .
Ef4   12        e     u  =     .
D4    12        e     u  =     .
Ef4   12        e     u  ]     .
measure 113
F4    12        e     u        .
Bf4   12        e     d  [     (f
D5    12        e     d  =
C5    12        e     d  ]
measure 114
Bf4   12        e     u  [
Af4   12        e     u  =
G4    12        e     u  =
F4    12        e     u  ]     )
measure 115
G4    12        e     u  [     .p
F4    12        e     u  =     .
Ef4   12        e     u  =     .
F4    12        e     u  ]     .
measure 116
G4    12        e     u  [     .
F4    12        e     u  =     .
Ef4   12        e     u  =     .
F4    12        e     u  ]     .
measure 117
G4    12        e     u        .
Bf4   12        e     d  [     (f
Ef5   12        e     d  =
D5    12        e     d  ]
measure 118
C5    12        e     u  [
Bf4   12        e     u  =
Af4   12        e     u  =
G4    12        e     u  ]     )
measure 119
F4    12        e     u  [     .p
Ef4   12        e     u  =     .
D4    12        e     u  =     .
Ef4   12        e     u  ]     .
measure 120
F4    12        e     u  [     .
Ef4   12        e     u  =     .
D4    12        e     u  =     .
Ef4   12        e     u  ]     .
measure 121
F4    12        e     u        .
Bf4   12        e     d  [     (f
D5    12        e     d  =
C5    12        e     d  ]
measure 122
Bf4   12        e     u  [
Af4   12        e     u  =
G4    12        e     u  =
F4    12        e     u  ]     )
measure 123
Ef4   24        q     u
Ef5   24-       q     d        -
measure 124
Ef5   24        q     d
C5     8        e  3  d  [     &1.
Bf4    8        e  3  d  =     &1.
Af4    8        e  3  d  ]     &1.
measure 125
G4    24        q     u
Ef5   24-       q     d        -
measure 126
Ef5   24        q     d
C4     8        e  3  u  [     &1.
Bf3    8        e  3  u  =     &1.
Af3    8        e  3  u  ]     &1.
measure 127
G3    18        e.    u  [     (
Af3    3        t     u  =[[   p
P C32:y10
Bf3    3        t     u  ]]]   )
C4    12        e     u  [     .
D4    12        e     u  ]     .
measure 128
Ef4   12        e     u  [     .
D4    12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 129
Af3   24        q     u
C5    24        q     u        &1f
 Ef4  24        q     u
 Af3  24        q     u
measure 130
Bf4   24        q     u
 Ef4  24        q     u
 G3   24        q     u
D5    24        q     u
 F4   24        q     u
 Bf3  24        q     u
measure 131
Ef5   24        q     u
 G4   24        q     u
 Bf3  24        q     u
Ef5   24-       q     d        -
measure 132
Ef5   24        q     d
C5     8        e  3  d  [     &1.
Bf4    8        e  3  d  =     &1.
Af4    8        e  3  d  ]     &1.
measure 133
G4    24        q     u
Ef5   24-       q     d        -
measure 134
Ef5   24        q     d
C4     8        e  3  u  [     &1.
Bf3    8        e  3  u  =     &1.
Af3    8        e  3  u  ]     &1.
measure 135
G3    18        e.    u  [     (
Af3    3        t     u  =[[   p
P C32:y10
Bf3    3        t     u  ]]]   )
C4    12        e     u  [     .
D4    12        e     u  ]     .
measure 136
Ef4   12        e     u  [     .
D4    12        e     u  =     .
C4    12        e     u  =     .
Bf3   12        e     u  ]     .
measure 137
Af3   24        q     u
C5    24        q     u        f
 Ef4  24        q     u
 Af3  24        q     u
measure 138
Bf4   24        q     u
 Ef4  24        q     u
 G3   24        q     u
D5    24        q     u
 F4   24        q     u
 Bf3  24        q     u
measure 139
Ef5   24        q     u
 Ef4  24        q     u
 G3   24        q     u
Bf4    8        e  3  d  [     (p
C5     8        e  3  d  =
Bf4    8        e  3  d  ]
measure 140
Af4    8        e  3  u  [
Bf4    8        e  3  u  =
Af4    8        e  3  u  ]
G4     8        e  3  u  [
Af4    8        e  3  u  =
G4     8        e  3  u  ]     )
measure 141
F4    48        h     u        (
measure 142
G4    24        q     u
Af4   24        q     u        )
measure 143
G4    24        q     u
G4     8        e  3  u  [     (
Af4    8        e  3  u  =
G4     8        e  3  u  ]
measure 144
F4     8        e  3  u  [
G4     8        e  3  u  =
F4     8        e  3  u  ]
Ef4    8        e  3  u  [
F4     8        e  3  u  =
Ef4    8        e  3  u  ]     )
measure 145
D4    48        h     u
measure 146
Ef4   24        q     u        (
D4    24        q     u        )
measure 147
Ef4   24        q     u        f
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 148
Ef4   24        q     u
 G3   24        q     u
G4    18        e.    u  [
Ef4    6        s     u  ]\
measure 149
Bf4   24        q     u
 D4   24        q     u
Bf4   18        e.    u  [
 D4   18        e.    u
Bf4    6        s     u  ]\
 D4    6        s     u
measure 150
Bf4   24        q     u
 D4   24        q     u
D5    18        e.    d  [
Bf4    6        s     d  ]\
measure 151
Ef5   24        q     d
G5    24        q     d
 Bf4  24        q     d
 Ef4  24        q     d
measure 152
Af5   24        q     d
 C5   24        q     d
 Ef4  24        q     d
F5    24        q     u
 Bf4  24        q     u
 D4   24        q     u
measure 153
Ef5   24        q     u
 Ef4  24        q     u
 G3   24        q     u
Ef4   18        e.    u  [
 G3   18        e.    u
Ef4    6        s     u  ]\
 G3    6        s     u
measure 154
Ef4   24        q     u
 G3   24        q     u
rest  24        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/03/03} [KHM:610969372]
TIMESTAMP: DEC/26/2001 [md5sum:e4e1f726ccaf162d0460fe7347be8053]
07/01/94 E. Correia
WK#:160       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-3   Q:12   T:2/4  C:13  D:Presto
Bf3   12        q     u        f
Bf3   12        q     u
measure 2
Bf3   12        q     u
rest  12        q
measure 3
F4    12        q     d
F4    12        q     d
measure 4
F4    12        q     d
rest  12        q
measure 5
Ef4   24        h     d
measure 6
Ef4   24        h     d
measure 7
Ef4   12        q     d
Af4   12        q     d
measure 8
G4     6        e     d  [
Af4    6        e     d  =
Bf4    6        e     d  =
G4     6        e     d  ]
measure 9
Af4    6        e     d  [
Bf4    6        e     d  =
Af4    6        e     d  =
G4     6        e     d  ]
measure 10
F4    12        q     d
Ef4   12-       q     d        -
measure 11
Ef4    6        e     d  [
E4     6        e n   d  =
F4     6        e     d  =
C4     6        e     d  ]
measure 12
Bf3   12        q     u
Bf3   12        q     u
measure 13
D4    18        q.    d
F4     6        e     d
measure 14
Ef4   12        q f   d        +
Ef4    3        s     d  [[
D4     3        s     d  ==
Ef4    3        s     d  ==
D4     3        s     d  ]]
measure 15
C4     6        e     d  [
C4     6        e     d  =
C4     6        e     d  =
C4     6        e     d  ]
measure 16
C4    12        q     d
rest  12        q
measure 17
rest  24
measure 18
rest  24
measure 19
F3    24-       h     u        -f
P C33:y10
measure 20
F3    24        h     u
measure 21
rest  24
measure 22
rest  24
measure 23
Bf3   24-       h     u        -
measure 24
Bf3   24        h     u
measure 25
rest  24
measure 26
rest  24
measure 27
F3    24-       h     u        -
measure 28
F3    24-       h     u        -
measure 29
F3    12        q     u
D4    12        q     d
measure 30
Ef4   12        q     d
Bf3   12        q     u
measure 31
Bf3   12        q     u
D4    12        q     d
measure 32
Ef4   12        q     d
Bf3   12        q     u
measure 33
Bf3   12        q     u
rest  12        q
measure 34
rest  24
measure 35
rest  12        q
Ef4   12        q     d
measure 36
F4    12        q     d
F3    12        q     u
measure 37
Bf3   12        q     u
D4    12        q     d
measure 38
Ef4   12        q     d
Bf3   12        q     u
measure 39
Bf3   12        q     u
D4    12        q     d
measure 40
Ef4   12        q     d
Bf3   12        q     u
measure 41
Bf3   12        q     u
rest  12        q
measure 42
rest  24
measure 43
rest  12        q
Ef4   12        q     d
measure 44
F4    12        q     d
F3    12        q     u
measure 45
Bf3   12        q     u
D4     4        e  3  d  [     (p
Ef4    4        e  3  d  =
D4     4        e  3  d  ]
measure 46
C4     4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
Bf3    4        e  3  u  [
C4     4        e  3  u  =
Bf3    4        e  3  u  ]     )
measure 47
A3    24        h n   u
measure 48
Bf3   12        q     u        (
A3    12        q n   u        )
measure 49
Bf3   12        q     u
D4     4        e  3  d  [     (
Ef4    4        e  3  d  =
D4     4        e  3  d  ]
measure 50
C4     4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
Bf3    4        e  3  u  [
C4     4        e  3  u  =
Bf3    4        e  3  u  ]     )
measure 51
A3    24        h n   u
measure 52
Bf3   12        q     u        (
A3    12        q n   u        )
measure 53
Bf3   12        q     u
D4    12        q     d        f
 Bf3  12        q     d
measure 54
Bf3   12        q     u
rest  12        q
mheavy4 55      :|:
D4    12        q     d        p
rest  12        q
measure 56
F3    12        q     u
rest  12        q
measure 57
Ef3   12        q     u
rest  12        q
measure 58
C4    12        q     d
rest  12        q
measure 59
Bf3    4        e  3  d  [     f
C4     4        e  3  d  =
D4     4        e  3  d  ]
Ef4    4        e  3  d  [
F4     4        e  3  d  =
G4     4        e  3  d  ]
measure 60
F4     4        e  3  d  [
G4     4        e  3  d  =
F4     4        e  3  d  ]
Ef4    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
measure 61
D4     4        e  3  d  [
Ef4    4        e  3  d  =
F4     4        e  3  d  ]
G4     4        e  3  d  [
A4     4        e n3  d  =
Bf4    4        e  3  d  ]
measure 62
A4     4        e n3  d  [
Bf4    4        e  3  d  =
A4     4        e  3  d  ]
G4     4        e  3  d  [
F4     4        e  3  d  =
Ef4    4        e  3  d  ]
measure 63
D4    12        q     d        p
rest  12        q
measure 64
F3    12        q     u
rest  12        q
measure 65
Ef3   12        q     u
rest  12        q
measure 66
C4    12        q     d
rest  12        q
measure 67
Bf3    4        e  3  d  [     f
C4     4        e  3  d  =
D4     4        e  3  d  ]
Ef4    4        e  3  d  [
F4     4        e  3  d  =
G4     4        e  3  d  ]
measure 68
F4     4        e  3  d  [
G4     4        e  3  d  =
F4     4        e  3  d  ]
Ef4    4        e  3  d  [
D4     4        e  3  d  =
C4     4        e  3  d  ]
measure 69
D4     4        e  3  d  [
Ef4    4        e  3  d  =
F4     4        e  3  d  ]
G4     4        e  3  d  [
A4     4        e n3  d  =
Bf4    4        e  3  d  ]
measure 70
A4     4        e n3  d  [
Bf4    4        e  3  d  =
A4     4        e  3  d  ]
G4     4        e  3  d  [
F4     4        e  3  d  =
Ef4    4        e  3  d  ]
measure 71
D4    12        q     d
rest  12        q
measure 72
rest  24
measure 73
rest  24
measure 74
rest  24
measure 75
Bf4   24-       h     d        -p
measure 76
Bf4   24-       h     d        -
measure 77
Bf4   24-       h     d        -
measure 78
Bf4   24        h     d
measure 79
Bf3   24-       h     u        -
measure 80
Bf3   24-       h     u        -
measure 81
*               D       crescendo
P C17:f33 C17:y-5
Bf3   24-       h     u        -
measure 82
Bf3   12        q     u
Af4   12        q f   d        +
measure 83
G4     6        e     d  [     f
Ef4    6        e     d  =
G4     6        e     d  =
Bf4    6        e     d  ]
measure 84
Af4    6        e     d  [
G4     6        e     d  =
F4     6        e     d  =
Ef4    6        e     d  ]
measure 85
Bf3   12        q     u
Bf4   12        q     d
measure 86
Bf3   12        q     u
rest  12        q
measure 87
Bf3   12        q     u
Bf3   12        q     u
measure 88
Bf3   12        q     u
rest  12        q
measure 89
F4    12        q     d
F4    12        q     d
measure 90
F4    12        q     d
rest  12        q
measure 91
Ef4   24-       h     d        -
measure 92
Ef4   24        h     d
measure 93
Ef4   12        q     d
Af4   12        q     d
measure 94
G4     6        e     d  [
Af4    6        e     d  =
Bf4    6        e     d  =
G4     6        e     d  ]
measure 95
Af4    6        e     d  [
Bf4    6        e     d  =
Af4    6        e     d  =
G4     6        e     d  ]
measure 96
F4    12        q     d
Ef4   12-       q     d        -
measure 97
Ef4    6        e     d  [
E4     6        e n   d  =
F4     6        e     d  =
C4     6        e     d  ]
measure 98
Bf3   12        q     u
Bf3   12        q     u
measure 99
Bf3   12        q     u
Bf3   12        q     u
measure 100
Bf3   12        q     u
rest  12        q
measure 101
F4    12        q     d
F4    12        q     d
measure 102
F4    12        q     d
rest  12        q
measure 103
Ef4   24-       h f   d        -+
measure 104
Ef4   24        h     d
measure 105
Ef4   12        q     d
Af4   12        q     d
measure 106
G4     6        e     d  [
Af4    6        e     d  =
Bf4    6        e     d  =
G4     6        e     d  ]
measure 107
Af4    6        e     d  [
Bf4    6        e     d  =
Af4    6        e     d  =
G4     6        e     d  ]
measure 108
F4    12        q     d
Ef4   12-       q     d        -
measure 109
Ef4    6        e     d  [
C4     6        e     d  =
Bf3    6        e     d  =
Af3    6        e     d  ]
measure 110
G3    12        q     u
rest  12        q
measure 111
rest  24
measure 112
rest  24
measure 113
Bf3   24-       h     u        -f
P C33:y10
measure 114
Bf3   24        h     u
measure 115
rest  24
measure 116
rest  24
measure 117
Ef3   24-       h     u        -
measure 118
Ef3   24        h     u
measure 119
rest  24
measure 120
rest  24
measure 121
Bf3   24-       h     u        -
measure 122
Bf3   24        h     u
measure 123
Bf3   12        q     u
G3    12        q     u
measure 124
Af3   12        q     u
Ef4   12        q     d
measure 125
Ef4   12        q     d
G3    12        q     u
measure 126
Af3   12        q     u
Ef3   12        q     u
measure 127
Ef3   12        q     u
rest  12        q
measure 128
rest  24
measure 129
rest  12        q
Af4   12        q     d
measure 130
Bf4   12        q     d
Bf3   12        q     u
measure 131
Ef4   12        q     d
G3    12        q     u
measure 132
Af3   12        q     u
Ef4   12        q     d
measure 133
Ef4   12        q     d
G3    12        q     u
measure 134
Af3   12        q     u
Ef3   12        q     u
measure 135
Ef3   12        q     u
rest  12        q
measure 136
rest  24
measure 137
rest  12        q
Af4   12        q     d
measure 138
Bf4   12        q     d
Bf3   12        q     u
measure 139
Bf3   12        q     u
G4     4        e  3  d  [     (p
Af4    4        e  3  d  =
G4     4        e  3  d  ]
measure 140
F4     4        e  3  d  [
G4     4        e  3  d  =
F4     4        e  3  d  ]
Ef4    4        e  3  d  [
F4     4        e  3  d  =
Ef4    4        e  3  d  ]     )
measure 141
D4    24        h     d
measure 142
Ef4   12        q     d        (
D4    12        q     d        )
measure 143
Ef4   12        q     d
Bf3    4        e  3  u  [     (
C4     4        e  3  u  =
Bf3    4        e  3  u  ]
measure 144
Af3    4        e  3  u  [
Bf3    4        e  3  u  =
Af3    4        e  3  u  ]
G3     4        e  3  u  [
Af3    4        e  3  u  =
G3     4        e  3  u  ]     )
measure 145
F3    24        h     u
measure 146
G3    12        q     u        (
Af3   12        q     u        )
measure 147
Bf3   12        q     u        f
Bf3   12        q     u
measure 148
Bf3   12        q     u
G4     9        e.    d  [
Ef4    3        s     d  ]\
measure 149
Bf4   12        q     d
F4    12        q     d
measure 150
F4    12        q     d
F4     9        e.    d  [
D4     3        s     d  ]\
measure 151
Bf3   12        q     u
Ef4   12        q     d
measure 152
F4    12        q     d
Af4   12        q     d
measure 153
G4    12        q     d
Bf3    9        e.    u  [
Bf3    3        s     u  ]\
measure 154
Bf3   12        q     u
rest  12        q
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/03/04} [KHM:610969372]
TIMESTAMP: DEC/26/2001 [md5sum:2feac5fa3eb4f4ed8dfdf0a55fffb870]
07/01/94 E. Correia
WK#:160       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-3   Q:12   T:2/4  C:22  D:Presto
Ef3   12        q     d        f
Ef3   12        q     d
measure 2
Ef3   12        q     d
rest  12        q
measure 3
D3    12        q     d
D3    12        q     d
measure 4
D3    12        q     d
rest  12        q
measure 5
C3    24        h     u
measure 6
Bf2   24        h     u
measure 7
Af2    6        e     u  [
Bf2    6        e     u  =
C3     6        e     u  =
D3     6        e     u  ]
measure 8
Ef3    6        e     d  [
F3     6        e     d  =
G3     6        e     d  =
Ef3    6        e     d  ]
measure 9
F3     6        e     d  [
G3     6        e     d  =
F3     6        e     d  =
Ef3    6        e     d  ]
measure 10
D3    12        q     d
Ef3   12        q     d
measure 11
Af2   18        q.    u
A2     6        e n   u
measure 12
Bf2   12        q     u
Bf2   12        q     u
measure 13
D3    12        q     d
D3    12        q     d
measure 14
Ef3   12        q     d
Ef3   12        q     d
measure 15
Ef3   12        q     d
E3    12        q n   d
measure 16
F3    12        q     d
rest  12        q
measure 17
rest  24
measure 18
rest  24
measure 19
F2    24-       h     u        -f
P C33:y10
measure 20
F2    24        h     u
measure 21
rest  24
measure 22
rest  24
measure 23
Bf2   24-       h     u        -
measure 24
Bf2   24        h     u
measure 25
rest  24
measure 26
rest  24
measure 27
F2    24-       h     u        -
measure 28
F2    24        h     u        (
measure 29
Bf2   12        q     u        )
D3    12        q     d
measure 30
Ef3   12        q     d
Ef2   12        q     u
measure 31
Bf2   12        q     u
D3    12        q     d
measure 32
Ef3   12        q     d
Ef2   12        q     u
measure 33
Bf2   12        q     u
rest  12        q
measure 34
rest  24
measure 35
rest  12        q
Ef3   12        q     d
measure 36
F3    12        q     d
F2    12        q     u
measure 37
Bf2   12        q     u
D3    12        q     d
measure 38
Ef3   12        q     d
Ef2   12        q     u
measure 39
Bf2   12        q     u
D3    12        q     d
measure 40
Ef3   12        q     d
Ef2   12        q     u
measure 41
Bf2   12        q     u
rest  12        q
measure 42
rest  24
measure 43
rest  12        q
Ef3   12        q     d
measure 44
F3    12        q     d
F2    12        q     u
measure 45
Bf2   12        q     u
rest  12        q
measure 46
rest  24
measure 47
F3    24-       h     d        -p
measure 48
F3    24        h     d
measure 49
Bf2   12        q     u
rest  12        q
measure 50
rest  24
measure 51
F3    24-       h     d        -
measure 52
F3    24        h     d
measure 53
Bf2   12        q     u
Bf2   12        q     u        f
measure 54
Bf2   12        q     u
rest  12        q
mheavy4 55      :|:
Bf2   12        q     u        p
rest  12        q
measure 56
D3    12        q     d
rest  12        q
measure 57
C3    12        q     u
rest  12        q
measure 58
F3    12        q     d
rest  12        q
measure 59
Bf2   12        q     u        f
rest  12        q
measure 60
rest  24
measure 61
Bf2    4        e  3  u  [
C3     4        e  3  u  =
D3     4        e  3  u  ]
Ef3    4        e  3  d  [
F3     4        e  3  d  =
G3     4        e  3  d  ]
measure 62
F3     4        e  3  d  [
G3     4        e  3  d  =
F3     4        e  3  d  ]
Ef3    4        e  3  d  [
D3     4        e  3  d  =
C3     4        e  3  d  ]
measure 63
Bf2   12        q     u        p
rest  12        q
measure 64
D3    12        q     d
rest  12        q
measure 65
C3    12        q     u
rest  12        q
measure 66
F3    12        q     d
rest  12        q
measure 67
Bf2   12        q     u        f
rest  12        q
measure 68
rest  24
measure 69
Bf2    4        e  3  u  [
C3     4        e  3  u  =
D3     4        e  3  u  ]
Ef3    4        e  3  d  [
F3     4        e  3  d  =
G3     4        e  3  d  ]
measure 70
F3     4        e  3  d  [
G3     4        e  3  d  =
F3     4        e  3  d  ]
Ef3    4        e  3  d  [
D3     4        e  3  d  =
C3     4        e  3  d  ]
measure 71
Bf2   12        q     u
Bf2   12        q     u        p
measure 72
Bf2   12        q     u
Bf2   12        q     u
measure 73
Bf2   12        q     u
Bf2   12        q     u
measure 74
Bf2   12        q     u
Bf2   12        q     u
measure 75
Bf2   12        q     u
Bf2   12        q     u
measure 76
Bf2   12        q     u
Bf2   12        q     u
measure 77
Bf2   12        q     u
Bf2   12        q     u
measure 78
Bf2   12        q     u
Bf2   12        q     u
measure 79
Bf2   12        q     u
Bf2   12        q     u
measure 80
Bf2   12        q     u
Bf2   12        q     u
measure 81
*               D       crescendo
P C17:f33 C17:y-10
Bf2   12        q     u
Bf2   12        q     u
measure 82
Bf2   12        q     u
Bf2   12        q     u
measure 83
Ef3    6        e     d  [     f
Ef3    6        e     d  =
G3     6        e     d  =
Bf3    6        e     d  ]
measure 84
Af3    6        e     d  [
G3     6        e     d  =
F3     6        e     d  =
Ef3    6        e     d  ]
measure 85
Bf2   12        q     u
Bf3   12        q     d
measure 86
Bf2   12        q     u
rest  12        q
measure 87
Ef3   12        q     d
Ef3   12        q     d
measure 88
Ef3   12        q     d
rest  12        q
measure 89
D3    12        q     d
D3    12        q     d
measure 90
D3    12        q     d
rest  12        q
measure 91
C3    24        h     u
measure 92
Bf2   24        h     u
measure 93
Af2    6        e     u  [
Bf2    6        e     u  =
C3     6        e     u  =
D3     6        e     u  ]
measure 94
Ef3    6        e     d  [
F3     6        e     d  =
G3     6        e     d  =
Ef3    6        e     d  ]
measure 95
F3     6        e     d  [
G3     6        e     d  =
F3     6        e     d  =
Ef3    6        e     d  ]
measure 96
D3    12        q     d
Ef3   12        q     d
measure 97
Af2   18        q.    u
A2     6        e n   u
measure 98
Bf2   12        q     u
Bf2   12        q     u
measure 99
Ef3   12        q     d
Ef3   12        q     d
measure 100
Ef3   12        q     d
rest  12        q
measure 101
D3    12        q     d
D3    12        q     d
measure 102
D3    12        q     d
rest  12        q
measure 103
C3    24        h     u
measure 104
Bf2   24        h     u
measure 105
Af2    6        e f   u  [     +
Bf2    6        e     u  =
C3     6        e     u  =
D3     6        e     u  ]
measure 106
Ef3    6        e     d  [
F3     6        e     d  =
G3     6        e     d  =
Ef3    6        e     d  ]
measure 107
F3     6        e     d  [
G3     6        e     d  =
F3     6        e     d  =
Ef3    6        e     d  ]
measure 108
D3    12        q     d
Ef3   12        q     d
measure 109
Af2   12        q     u
Bf2   12        q     u
measure 110
Ef2   12        q     u
rest  12        q
measure 111
rest  24
measure 112
rest  24
measure 113
Bf2   24-       h     u        -f
P C33:y10
measure 114
Bf2   24        h     u
measure 115
rest  24
measure 116
rest  24
measure 117
Ef2   24-       h     u        -
measure 118
Ef2   24        h     u
measure 119
rest  24
measure 120
rest  24
measure 121
Bf2   24-       h     u        -
measure 122
Bf2   24        h     u
measure 123
Ef3   12        q     d
G2    12        q     u
measure 124
Af2   12        q     u
Af3   12        q     d
measure 125
Ef3   12        q     d
G2    12        q     u
measure 126
Af2   12        q     u
Af2   12        q     u
measure 127
Ef2   12        q     u
rest  12        q
measure 128
rest  24
measure 129
rest  12        q
Af3   12        q     d
measure 130
Bf3   12        q     d
Bf2   12        q     u
measure 131
Ef3   12        q     d
G2    12        q     u
measure 132
Af2   12        q     u
Af3   12        q     d
measure 133
Ef3   12        q     d
G2    12        q     u
measure 134
Af2   12        q     u
Af2   12        q     u
measure 135
Ef2   12        q     u
rest  12        q
measure 136
rest  24
measure 137
rest  12        q
Af3   12        q     d
measure 138
Bf3   12        q     d
Bf2   12        q     u
measure 139
Ef3   12        q     d
rest  12        q
measure 140
rest  24
measure 141
Bf2   24-       h     u        -p
measure 142
Bf2   24        h     u
measure 143
Ef3   12        q     d
rest  12        q
measure 144
rest  24
measure 145
Bf2   24-       h     u        -
measure 146
Bf2   24        h     u
measure 147
Ef2   12        q     u        f
Ef2    9        e.    u  [
Ef2    3        s     u  ]\
measure 148
Ef2   12        q     u
G2     9        e.    u  [
Ef2    3        s     u  ]\
measure 149
Bf2   12        q     u
Bf2   12        q     u
measure 150
Bf3   12        q     d
Af3   12        q     d
measure 151
G3    12        q     d
Ef3   12        q     d
measure 152
Af3   12        q     d
Bf3   12        q     d
measure 153
Ef3   12        q     d
Ef2    9        e.    u  [
Ef2    3        s     u  ]\
measure 154
Ef2   12        q     u
rest  12        q
mheavy2         :|
/END
/eof
//
