&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/01/01} [KHM:14741725]
TIMESTAMP: DEC/26/2001 [md5sum:7822f6de3ed466758fae68f32a6b803e]
06/22/94 E. Correia
WK#:160       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-3   Q:8   T:1/1  C:4  D:Allegro
Bf5   16        h     d        &0f
gAf5   5        s     u
S C1:t25
G5     8        q     d
gF5    5        s     u
S C1:t25
Ef5    8        q     d
measure 2
D5    12        q.    d        (
Ef5    2        s     d  [[
F5     2        s     d  ]]
Ef5    8        q     d        )
rest   8        q
measure 3
gD5    5        s     u
S C1:t25
C5     8        q     d
C5    16        h     d
Ef5    4        e     d  [     (
C5     4        e     d  ]     )
measure 4
C5     6        e.    d  [     (t
S C33:n4s25t75
Bf4    1        t     d  =[[
C5     1        t     d  ]]]   )
Bf4    8        q     d
rest  16        h
measure 5
F5     6        e.    d  [     (
D5     2        s     d  ]\    )
F5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 6
G5     6        e.    d  [     (
Ef5    2        s     d  ]\    )
G5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 7
Bf4    4        e     u  [     (
Af4    4        e     u  ]     )
G4    16        h     u        (
F4     8        q     u        )
measure 8
G4     2        s     u  [[    (
Af4    2        s     u  ==
G4     2        s     u  ==
Af4    2        s     u  ]]    )
Bf4    8        q     d        .
rest  16        h
measure 9
Bf5   32-       w     d        -
measure 10
Bf5   16-       h     d        -
Bf5    4        e     d  [
G5     4        e     d  =     (
Ef5    4        e     d  =
Bf4    4        e     d  ]     )
measure 11
Bf4    4        e     u  [     (
Af4    4        e     u  ]     )
G4    16        h     u        (
F4     8        q     u        )
measure 12
Ef4   16-       h     u        -
 G3   16        h     u
Ef4    2        s     u  [[
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]
G4     2        s     u  [[
F4     2        s     u  ==
G4     2        s     u  ==
A4     2        s n   u  ]]
measure 13
Bf4   16-       h     d        -
Bf4    2        s     d  [[
A4     2        s n   d  ==
Bf4    2        s     d  ==
C5     2        s     d  ]]
D5     2        s     d  [[
C5     2        s     d  ==
D5     2        s     d  ==
Bf4    2        s     d  ]]
measure 14
Ef5    4        e     d  [
gF5    5        s     u
S C1:t50
Ef5    2        s     d  =[
D5     2        s     d  ]]
Ef5    4        e     d  [
F5     4        e     d  ]
G5     4        e     d  [
gAf5   5        s     u
S C1:t50
G5     2        s     d  =[
F5     2        s     d  ]]
G5     4        e     d  [
A5     4        e n   d  ]
measure 15
Bf5    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
rest   8        q
measure 16
rest  32
measure 17
rest  32
measure 18
rest  32
measure 19
rest  32
measure 20
F5    12        q.    d        (p
G5     2        s     d  [[
Ef5    2        s     d  ]]    )
D5     4        e     d  [     .
D5     4        e     d  =     .
Ef5    4        e     d  =     .
Ef5    4        e     d  ]     .
measure 21
F5    12        q.    d        (
G5     2        s     d  [[
F5     2        s     d  ]]    )
Bf5    4        e     d  [     (
A5     4        e n   d  =
G5     4        e     d  =
F5     4        e     d  ]     )
measure 22
Ef5   12        q.    d        (
F5     2        s     d  [[
D5     2        s     d  ]]    )
C5     4        e     d  [     .
C5     4        e     d  =     .
D5     4        e     d  =     .
D5     4        e     d  ]     .
measure 23
Ef5   12        q.    d        (
F5     2        s     d  [[
Ef5    2        s     d  ]]    )
C6     4        e     d  [     (
A5     4        e n   d  =
F5     4        e     d  =
Ef5    4        e     d  ]     )
measure 24
D5     8        q     d
rest   4        e
Bf5    4        e     d        .
F#5    4        e #   d  [     (
G5     4        e     d  ]     )
rest   4        e
Bf5    4        e     d        .
measure 25
E5     4        e n   d  [     (
F5     4        e n   d  ]     )+
rest   4        e
Bf5    4        e     d
C5    12        q.    d        (
D5     2        s     d  [[
Ef5    2        s f   d  ]]    )
measure 26
C#5    4        e #   d  [     (
D5     4        e     d  ]     )
rest   4        e
Bf5    4        e     d        .
F#5    4        e #   d  [     (
G5     4        e     d  ]     )
rest   4        e
Bf5    4        e     d        .
measure 27
E5     4        e n   d  [     (
F5     4        e     d  ]     )
rest   4        e
Bf5    4        e     d
C5    12        q.n   d        (+
D5     2        s     d  [[
Ef5    2        s f   d  ]]    )
measure 28
C#5    4        e #   d  [     (
D5     4        e     d  ]     )
rest   4        e
F5     4        e     d        .f
Ef5    4        e f   d  [     (+
D5     4        e     d  =
C5     4        e n   d  =
Bf4    4        e     d  ]     )
measure 29
A4     2        s n   u  [[    (p
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]
F4     2        s     u  [[
E4     2        s n   u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
A4     2        s     u  [[
G4     2        s     u  ==
F4     2        s     u  ==
E4     2        s     u  ]]
F4     2        s     u  [[
G4     2        s     u  ==
A4     2        s     u  ==
Bf4    2        s     u  ]]    )
measure 30
C5     2        s     d  [[    (
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ]]
*               DH      cresc.
P C17:f33
A4     2        s n   u  [[
G4     2        s     u  ==
A4     2        s     u  ==
Bf4    2        s     u  ]]
C5     2        s     u  [[
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]
A4     2        s     d  [[
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]    )
measure 31
Ef5    2        s     d  [[    (
F5     2        s     d  ==
Ef5    2        s     d  ==
D5     2        s     d  ]]
C5     2        s     d  [[
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
*               JG      f
Ef5    2        s     d  [[
F5     2        s     d  ==
G5     2        s     d  ==
A5     2        s n   d  ]]    )
measure 32
Bf5    8        q     d        .
rest   8        q
Af4   16        h f   u        (p+
measure 33
G4     8        q     u        )
rest   8        q
Af4   16        h     u        (
measure 34
G4     8        q     u        )
rest   8        q
G5     8        q     d        (
A5     4        e n   d  [     )
Bf5    4        e     d  ]     .
measure 35
gBf5   5        s     u        (
S C1:t50
A5     8        q n   d        )fp
G5     4        e     d  [     .
F5     4        e     d  ]     .
gF5    5        s     u        (
S C1:t50
Ef5    8        q     d        )fp
D5     4        e     d  [     .
C5     4        e     d  ]     .
measure 36
Bf4    2        s     d  [[
A4     2        s n   d  ==
Bf4    2        s     d  ==
C5     2        s     d  ]]
*               D       cresc.
P C17:f33
D5     2        s     d  [[
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
Ef5    2        s     d  [[
D5     2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
Ef5    2        s     d  [[    f
P C32:y15
F5     2        s     d  ==
G5     2        s     d  ==
A5     2        s n   d  ]]
measure 37
Bf5    8        q     d
rest   8        q
Af4   16        h f   u        (p+
measure 38
G4     8        q     u        )
rest   8        q
Af4   16        h     u        (
measure 39
G4     8        q     u        )
rest   8        q
G5     8        q     d        (
A5     4        e n   d  [     )
Bf5    4        e     d  ]     .
measure 40
Bf5    4        e     d  [     (fp
A5     4        e n   d  =     )
G5     4        e     d  =     .
F5     4        e     d  ]     .
F5     4        e     d  [     (fp
Ef5    4        e     d  =     )
D5     4        e     d  =     .
C5     4        e     d  ]     .
measure 41
Bf4    8        q     d
rest   8        q
rest   8        q
F5     4        e     d  [     (
D5     4        e     d  ]     )
measure 42
B4     8        q n   d        (
C5     8        q     d        )
rest   8        q
Ef5    4        e     d  [     (
C5     4        e     d  ]     )
measure 43
A4     8        q n   u        (
Bf4    8        q f   d        )+
rest   4        e
F5     4        e     d  [     (
D5     4        e     d  =
Bf4    4        e     d  ]     )
measure 44
B4     8        q n   d        (
C5     8        q     d        )
rest   4        e
Ef5    4        e     d  [     (
C5     4        e     d  =
A4     4        e n   d  ]     )
measure 45
Bf4    8        q f   d        f+
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
rest   8        q
measure 46
Af4    2        s f   u  [[    (p+
Bf4    2        s     u  ==
Af4    2        s     u  ==
G4     2        s     u  ]]
F4     2        s     u  [[
G4     2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
Af4    8        q     u        )
rest   8        q
measure 47
G4     8        q     u        f
 G3    8        q     u
G5     8        q     d
G5     8        q     d
rest   8        q
measure 48
F4     2        s     u  [[    (p
G4     2        s     u  ==
F4     2        s     u  ==
Ef4    2        s     u  ]]
D4     2        s     u  [[
Ef4    2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
F4     8        q     u        )
rest   8        q
measure 49
G5    16        h     d        f
gF5    5        s     u
S C1:t25
Ef5    8        q     d
gD5    5        s     u
S C1:t25
C5     8        q     d
measure 50
B4    12        q.n   d        (
C5     2        s     d  [[
D5     2        s     d  ]]
C5     8        q     d        )
rest   8        q
measure 51
gBf4   5        s f   u        +
S C1:t25
Af4    8        q f   u        +
Af4   16        h     u
C5     4        e     d  [     (
Af4    4        e     d  ]     )
measure 52
Af4    6        e.    u  [     (t
S C33:n4s25t75
G4     1        t     u  =[[
Af4    1        t     u  ]]]   )
G4     8        q     u
rest  16        h
measure 53
D5     6        e.    d  [     (
B4     2        s n   d  ]\    )
D5     4        e     d
rest   4        e
rest   4        e
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  ]
measure 54
Ef5    6        e.    d  [     (
C5     2        s     d  ]\    )
Ef5    4        e     d        .
rest   4        e
rest   4        e
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  ]
measure 55
Af4    8        q f   u        +
Af5   16        h f   d        +
G5     4        e     d  [     (
F5     4        e     d  ]     )
measure 56
E5    12        q.n   d        (
F5     2        s     d  [[
G5     2        s     d  ]]    )
F5     4        e     d  [     (
C5     4        e     d  =
F5     4        e     d  =
Ef5    4        e f   d  ]     )
measure 57
D5    12        q.    d        (
Ef5    2        s     d  [[
F5     2        s     d  ]]    )
Ef5    4        e     d  [     (
Bf4    4        e     d  =
Ef5    4        e     d  =
Df5    4        e f   d  ]     )
measure 58
Df5    8        q f   d        (
C5     4        e     d  [     )
Bf4    4        e     d  ]     .
Af4    4        e     u  [     .
G4     4        e     u  =     .
F4     4        e     u  =     .
Ef4    4        e     u  ]     .
measure 59
Ef4   16        h     u        (
D4     8        q     u        )
rest   8        q
measure 60
Bf5   16        h     d
gAf5   5        s     u        (
S C1:t25
G5     8        q     d        )
gF5    5        s     u        (
S C1:t25
Ef5    8        q     d        )
measure 61
D5    12        q.n   d        (+
Ef5    2        s     d  [[
F5     2        s     d  ]]
Ef5    8        q     d        )
rest   8        q
measure 62
gD5    5        s     u
S C1:t25
C5     8        q     d
C5    16        h     d
Ef5    4        e     d  [     (
C5     4        e     d  ]     )
measure 63
C5     6        e.    d  [     (t
S C33:n4s25t75
Bf4    1        t     d  =[[
C5     1        t     d  ]]]   )
Bf4    8        q     d
rest  16        h
measure 64
F5     6        e.    d  [     (
D5     2        s     d  ]\    )
F5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 65
G5     6        e.    d  [     (
Ef5    2        s     d  ]\    )
G5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 66
Bf4    4        e     u  [     (
Af4    4        e     u  ]     )
G4    16        h     u
F4     8        q     u
measure 67
G4     2        s     u  [[    (
Af4    2        s     u  ==
G4     2        s     u  ==
Af4    2        s     u  ]]    )
Bf4    8        q     d        .
rest  16        h
measure 68
Bf5   32-       w     d        -
measure 69
Bf5   16-       h     d        -
Bf5    4        e     d  [
G5     4        e     d  =     (
Ef5    4        e     d  =
Bf4    4        e     d  ]     )
measure 70
Bf4    4        e     u  [     (
Af4    4        e     u  ]     )
G4    16        h     u        (
F4     8        q     u        )
measure 71
Ef4   16-       h     u        -
 G3   16        h     u
Ef4    2        s     u  [[
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]
G4     2        s     u  [[
F4     2        s     u  ==
G4     2        s     u  ==
A4     2        s n   u  ]]
measure 72
Bf4   16-       h     d        -
Bf4    2        s     d  [[
A4     2        s n   d  ==
Bf4    2        s     d  ==
C5     2        s     d  ]]
D5     2        s     d  [[
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
measure 73
Ef5    4        e     d  [
gF5    5        s     u
S C1:t50
Ef5    2        s     d  =[
D5     2        s     d  ]]
Ef5    4        e     d  [
F5     4        e     d  ]
G5     4        e     d  [
gAf5   5        s     u
S C1:t50
G5     2        s     d  =[
F5     2        s     d  ]]
G5     4        e     d  [
A5     4        e n   d  ]
measure 74
Bf5    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
rest   8        q
measure 75
rest  32
measure 76
rest  32
measure 77
rest  32
measure 78
rest  32
measure 79
Bf5   12        q.    d        (p
C6     2        s     d  [[
Af5    2        s     d  ]]    )
G5     4        e     d  [     .
G5     4        e     d  =     .
Af5    4        e     d  =     .
Af5    4        e     d  ]     .
measure 80
Bf5   12        q.    d        (
C6     2        s     d  [[
Bf5    2        s     d  ]]    )
Ef6    4        e     d  [     (
D6     4        e     d  =
C6     4        e     d  =
Bf5    4        e     d  ]     )
measure 81
Af5   12        q.    d        (
Bf5    2        s     d  [[
G5     2        s     d  ]]    )
F5     4        e     d  [     .
F5     4        e     d  =     .
G5     4        e     d  =     .
G5     4        e     d  ]     .
measure 82
Af5   12        q.    d        (
Bf5    2        s     d  [[
Af5    2        s     d  ]]    )
F6     4        e     d  [     (
D6     4        e     d  =
Bf5    4        e     d  =
Af5    4        e     d  ]     )
measure 83
G5     8        q     d
rest   4        e
Ef6    4        e     d        .
B5     4        e n   d  [     (
C6     4        e     d  ]     )
rest   4        e
Ef6    4        e     d        .
measure 84
A5     4        e n   d  [     (
Bf5    4        e f   d  ]     )+
rest   4        e
Ef6    4        e     d        .
F5    12        q.    d        (
G5     2        s     d  [[
Af5    2        s f   d  ]]    )
measure 85
F#5    4        e #   d  [     (
G5     4        e     d  ]     )
rest   4        e
Ef5    4        e     d        &1.
B4     4        e n   d  [     (
C5     4        e     d  ]     )
rest   4        e
Ef5    4        e     d        &1.
measure 86
A4     4        e n   u  [     (
Bf4    4        e     u  ]     )
rest   4        e
Ef5    4        e     d        .
F4    12        q.    u        (
G4     2        s     u  [[
Af4    2        s f   u  ]]    )
measure 87
F#4    4        e #   u  [     (
G4     4        e     u  ]     )
rest   4        e
Bf4    4        e     d        .
Af4    4        e     u  [     (f
G4     4        e     u  =
F4     4        e n   u  =
Ef4    4        e     u  ]     )
measure 88
D4     2        s     u  [[    (p
Ef4    2        s     u  ==
D4     2        s     u  ==
C4     2        s     u  ]]
Bf3    2        s     u  [[
A3     2        s n   u  ==
Bf3    2        s     u  ==
C4     2        s     u  ]]
D4     2        s     u  [[
C4     2        s     u  ==
Bf3    2        s     u  ==
A3     2        s     u  ]]
Bf3    2        s     u  [[
C4     2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]    )
measure 89
F4     2        s     u  [[    (
G4     2        s     u  ==
F4     2        s     u  ==
Ef4    2        s     u  ]]
*               DH      cresc.
P C17:p5 C17:f33
P C18:p5
D4     2        s     u  [[
C4     2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
F4     2        s     u  [[
Ef4    2        s     u  ==
D4     2        s     u  ==
C4     2        s     u  ]]
D4     2        s     u  [[
Ef4    2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]    )
measure 90
Af4    2        s     u  [[    (
Bf4    2        s     u  ==
Af4    2        s     u  ==
G4     2        s     u  ]]
F4     2        s     u  [[
Ef4    2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
Af4    2        s     u  [[
G4     2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
*               JG      f
P C17:p5 C18:p5
Af4    2        s     u  [[
Bf4    2        s     u  ==
C5     2        s     u  ==
D5     2        s     u  ]]    )
measure 91
Ef5    8        q     d
rest   8        q
Df4   16        h f   u        (p
P C33:y5
measure 92
C4     8        q     u        )
rest   8        q
Df4   16        h f   u        (
measure 93
C4     8        q     u        )
rest   8        q
C5     8        q     d        (
D5     4        e     d  [     )
Ef5    4        e     d  ]     .
measure 94
gEf5   5        s     u        (
S C1:t50
D5     8        q     d        )fp
C5     4        e     d  [     .
Bf4    4        e     d  ]     .
gBf4   5        s     u        (
S C1:t50
Af4    8        q     u        )fp
G4     4        e     u  [     .
F4     4        e     u  ]     .
measure 95
Ef4    2        s     u  [[    (
D4     2        s n   u  ==    +
Ef4    2        s     u  ==
F4     2        s     u  ]]
*               D       cresc.
P C17:f33
G4     2        s     u  [[
Ef4    2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
Af4    2        s     u  [[
G4     2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
Af4    2        s     u  [[    f
P C32:y20
Bf4    2        s     u  ==
C5     2        s     u  ==
D5     2        s     u  ]]    )
measure 96
Ef5    8        q     d
rest   8        q
Df4   16        h f   u        (p
P C33:y5
measure 97
C4     8        q     u        )
rest   8        q
Df4   16        h f   u        (
measure 98
C4     8        q     u        )
rest   8        q
C5     8        q     d        (
D5     4        e     d  [     )
Ef5    4        e     d  ]     .
measure 99
Ef5    4        e     d  [     (fp
D5     4        e     d  =     )
C5     4        e     d  =     .
Bf4    4        e     d  ]     .
Bf4    4        e     u  [     (fp
Af4    4        e     u  =     )
G4     4        e     u  =     .
F4     4        e     u  ]     .
measure 100
Ef4    8        q     u
rest   8        q
rest   8        q
Bf5    4        e     d  [     (
G5     4        e     d  ]     )
measure 101
E5     8        q n   d        (
F5     8        q     d        )
rest   8        q
Af5    4        e     d  [     (
F5     4        e     d  ]     )
measure 102
D5     8        q     d        (
Ef5    8        q f   d        )+
rest   4        e
Bf4    4        e     u  [     (
G4     4        e     u  =
Ef4    4        e     u  ]     )
measure 103
E4     8        q n   u        (
F4     8        q     u        )
rest   4        e
Af4    4        e     u  [     (
F4     4        e     u  =
D4     4        e     u  ]     )
measure 104
Ef4    4        e f   u        .+
Ef4    2        s     u  [[    (f
P C33:y10
F4     2        s     u  ]]
G4     2        s     u  [[
Af4    2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]    )
Ef4    4        e     u        .
Ef4    2        s     u  [[    (
F4     2        s     u  ]]
G4     2        s     u  [[
Af4    2        s     u  ==
F4     2        s     u  ==
G4     2        s     u  ]]    )
measure 105
Ef4    8        q     u
G5     8        q     d
 Bf4   8        q     d
 Ef4   8        q     d
G5     8        q     d
 Bf4   8        q     d
 Ef4   8        q     d
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/01/02} [KHM:14741725]
TIMESTAMP: DEC/26/2001 [md5sum:8694e086857b2459d79f804676befa9f]
06/22/94 E. Correia
WK#:160       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-3   Q:8   T:1/1  C:4  D:Allegro
G4     4        e     u  [     &0f
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
Bf4    4        e     u  [
Bf4    4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 2
F4     4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
Af4    4        e     u  ]
G4     4        e     u  [     .
G4     4        e     u  =     (
Af4    4        e     u  =
Bf4    4        e     u  ]     )
measure 3
Af4    4        e     u  [
Af4    4        e     u  =
Af4    4        e     u  =
Af4    4        e     u  ]
Af4    4        e     u  [
Af4    4        e     u  =
C5     4        e     u  =     (
Af4    4        e     u  ]     )
measure 4
Af4    6        e.    u  [     (t
S C33:n4s25t75
G4     1        t     u  =[[
Af4    1        t     u  ]]]   )
G4     8        q     u
rest  16        h
measure 5
Bf5   32-       w     d        -
measure 6
Bf5   32-       w     d        -
measure 7
Bf5    4        e     d  [     (
Af5    4        e     d  ]     )
G5    16        h     d        (
F5     8        q     d        )
measure 8
G5     2        s     d  [[    (
Af5    2        s     d  ==
G5     2        s     d  ==
Af5    2        s     d  ]]    )
Bf5    8        q     d        .
rest  16        h
measure 9
F5     6        e.    d  [     (
D5     2        s     d  ]\    )
F5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 10
G5     6        e.    d  [     (
Ef5    2        s     d  ]\    )
G5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     u  [     .
Bf4    4        e     u  =     (
G4     4        e     u  ]     )
measure 11
G4     4        e     u  [     (
F4     4        e     u  ]     )
Ef4   16        h     u        (
D4     8        q     u        )
measure 12
Ef4   16-       h     u        -
 G3   16        h     u
Ef4    2        s     u  [[
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]
G4     2        s     u  [[
F4     2        s     u  ==
G4     2        s     u  ==
A4     2        s n   u  ]]
measure 13
Bf4   16-       h     d        -
Bf4    2        s     d  [[
A4     2        s n   d  ==
Bf4    2        s     d  ==
C5     2        s     d  ]]
D5     2        s     d  [[
C5     2        s     d  ==
D5     2        s     d  ==
Bf4    2        s     d  ]]
measure 14
Ef5    4        e     d  [
gF5    5        s     u
S C1:t50
Ef5    2        s     d  =[
D5     2        s     d  ]]
Ef5    4        e     d  [
F5     4        e     d  ]
G5     4        e     d  [
gAf5   5        s     u
S C1:t50
G5     2        s     d  =[
F5     2        s     d  ]]
G5     4        e     d  [
A5     4        e n   d  ]
measure 15
Bf5    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
rest   8        q
measure 16
F4    12        q.    u        (p
P C33:y10
G4     2        s     u  [[
Ef4    2        s     u  ]]    )
D4     4        e     u  [     .
D4     4        e     u  =     .
Ef4    4        e     u  =     .
Ef4    4        e     u  ]     .
measure 17
F4    12        q.    u        (
G4     2        s     u  [[
F4     2        s     u  ]]    )
Bf4    4        e     u  [     (
A4     4        e n   u  =
G4     4        e     u  =
F4     4        e     u  ]     )
measure 18
Ef4   12        q.    u        (
F4     2        s     u  [[
D4     2        s     u  ]]    )
C4     4        e     u  [     .
C4     4        e     u  =     .
D4     4        e     u  =     .
D4     4        e     u  ]     .
measure 19
Ef4   12        q.    u        (
F4     2        s     u  [[
Ef4    2        s     u  ]]    )
C5     4        e     u  [     (
A4     4        e n   u  =
F4     4        e     u  =
Ef4    4        e     u  ]     )
measure 20
D4    12        q.    u        (
Ef4    2        s     u  [[
C4     2        s     u  ]]    )
Bf3    4        e     u  [     .
Bf3    4        e     u  =     .
C4     4        e     u  =     .
C4     4        e     u  ]     .
measure 21
D4    12        q.    u        (
Ef4    2        s     u  [[
D4     2        s     u  ]]    )
G4     4        e     u  [     (
F4     4        e     u  =
Ef4    4        e     u  =
D4     4        e     u  ]     )
measure 22
C4    12        q.    u        (
D4     2        s     u  [[
Bf3    2        s     u  ]]    )
A3     4        e n   u  [     .
A3     4        e     u  =     .
Bf3    4        e     u  =     .
Bf3    4        e     u  ]     .
measure 23
C4    12        q.    u        (
D4     2        s     u  [[
C4     2        s     u  ]]    )
A4     4        e n   u  [     (
F4     4        e     u  =
D4     4        e     u  =
C4     4        e     u  ]     )
measure 24
Bf3    4        e     u  [     .
F4     4        e     u  ]     .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
rest   4        e
Bf4    4        e     d        .
A4     4        e n   u  [     (
G4     4        e     u  ]     )
measure 25
rest   4        e
F4     4        e     u        .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
rest   4        e
C4     4        e     u        .
Bf3    4        e     u  [     (
A3     4        e n   u  ]     )
measure 26
rest   4        e
F4     4        e     u        .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
rest   4        e
Bf4    4        e     d        .
A4     4        e n   u  [     (
G4     4        e     u  ]     )
measure 27
rest   4        e
F4     4        e     u        .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
rest   4        e
C4     4        e     u        .
Bf3    4        e     u  [     (
A3     4        e n   u  ]     )
measure 28
A3     4        e n   u  [     (
Bf3    4        e     u  ]     )
D5     4        e     d  [     .f
C5     4        e     d  ]     .
Bf4    4    &   e     u  [     (
A4     4    &   e n   u  =
G4     4    &   e     u  =
G4     4    &   e     u  ]     )
&
Source edition gives the following articulation, conflicting with the other parts.
Bf4    4        e     u  [     (
A4     4        e n   u  =
G4     4        e     u  =     )
G4     4        e     u  ]     .
&
measure 29
C4     8        q     u        p
rest   8        q
rest  16        h
measure 30
A4     2        s n   u  [[    (
Bf4    2        s     u  ==
A4     2        s     u  ==
G4     2        s     u  ]]
*               DH      cresc.
P C17:f33
F4     2        s     u  [[
E4     2        s n   u  ==
F4     2        s     u  ==
G4     2        s     u  ]]
A4     2        s     u  [[
G4     2        s     u  ==
F4     2        s     u  ==
E4     2        s     u  ]]
F4     2        s     u  [[
G4     2        s     u  ==
A4     2        s     u  ==
Bf4    2        s     u  ]]    )
measure 31
C5     2        s     d  [[    (
D5     2        s     d  ==
C5     2        s     d  ==
Bf4    2        s     d  ]]
A4     2        s n   u  [[
G4     2        s     u  ==
A4     2        s     u  ==
Bf4    2        s     u  ]]
C5     2        s     d  [[
Bf4    2        s     d  ==
A4     2        s     d  ==
Bf4    2        s     d  ]]
*               JG      f
C5     2        s     d  [[
D5     2        s     d  ==
Ef5    2        s     d  ==
C5     2        s     d  ]]    )
measure 32
F5     8        q     d        .
rest   8        q
F4    16        h     u        (p
P C33:y10
measure 33
Ef4    8        q f   u        )+
rest   8        q
F4    16        h     u        (
measure 34
Ef4    8        q     u        )
rest   8        q
G4     8        q     u        (
A4     4        e n   u  [     )
Bf4    4        e     u  ]     .
measure 35
gBf4   5        s     u        (
S C1:t50
A4     8        q n   u        )fp
G4     4        e     u  [     .
F4     4        e     u  ]     .
gF4    5        s     u        (
S C1:t50
Ef4    8        q     u        )fp
P C33:y10
D4     4        e     u  [     .
C4     4        e     u  ]     .
measure 36
D4     2        s     u  [[
C4     2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
*               D       cresc.
P C17:f33
F4     2        s     u  [[
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]
C4     2        s     u  [[
Bf3    2        s     u  ==
A3     2        s n   u  ==
Bf3    2        s     u  ]]
C4     2        s     u  [[    f
P C32:y5
D4     2        s     u  ==
Ef4    2        s     u  ==
C4     2        s     u  ]]
measure 37
F4     8        q     u
rest   8        q
B3    16        h n   u        (p
measure 38
C4     8        q     u        )
rest   8        q
B3    16        h n   u        (
measure 39
C4     8        q     u        )
rest   8        q
Ef5    8        q     d        (
F5     4        e     d  [     )
G5     4        e     d  ]     .
measure 40
G5     4        e     d  [     (fp
F5     4        e     d  =     )
Ef5    4        e     d  =     .
D5     4        e     d  ]     .
D5     4        e     d  [     (fp
C5     4        e     d  =     )
Bf4    4        e     d  =     .
A4     4        e n   d  ]     .
measure 41
Bf4    4        e     u  [
D4     2        s     u  =[    (
Ef4    2        s     u  ]]
F4     4        e     u  [     )
F4     4        e     u  ]     .
F4     4        e     u  [     (
D4     4        e     u  ]     )
rest   8        q
measure 42
rest   4        e
G4     2        s     u  [[    (
F4     2        s     u  ]]
Ef4    4        e     u  [     )
Ef4    4        e     u  ]     .
Ef4    4        e     u  [     (
C4     4        e     u  ]     )
rest   8        q
measure 43
rest   4        e
C4     2        s     u  [[    (
Ef4    2        s     u  ]]
D4     4        e     u  [     )
D4     4        e     u  ]     .
D4     4        e     u  [     (
F4     4        e     u  ]     )
rest   8        q
measure 44
rest   4        e
G4     2        s     u  [[    (
F4     2        s     u  ]]
Ef4    4        e     u  [     )
Ef4    4        e     u  ]     .
Ef4    4        e     u  [     (
C4     4        e     u  ]     )
rest   4        e
Ef4    4        e     u
measure 45
D4     8        q     u        f
D5     8        q     u
 F4    8        q     u
 Bf3   8        q     u
D5     8        q     u
 F4    8        q     u
 Bf3   8        q     u
rest   8        q
measure 46
F4     2        s     u  [[    (p
G4     2        s     u  ==
F4     2        s     u  ==
Ef4    2        s     u  ]]
D4     2        s     u  [[
Ef4    2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
F4     8        q     u        )
rest   8        q
measure 47
D4     8        q     u        f
 G3    8        q     u
D5     8        q     d
D5     8        q     d
rest   8        q
measure 48
D4     2        s     u  [[    (p
Ef4    2        s     u  ==
D4     2        s     u  ==
C4     2        s     u  ]]
B3     2        s n   u  [[
C4     2        s     u  ==
B3     2        s     u  ==
C4     2        s     u  ]]
D4     8        q     u        )
rest   8        q
measure 49
Ef4    4        e     u  [     f
Ef4    4        e     u  =
Ef4    4        e     u  =
Ef4    4        e     u  ]
G4     4        e     u  [
G4     4        e     u  =
Ef4    4        e     u  =
Ef4    4        e     u  ]
measure 50
D4     4        e     u  [
D4     4        e     u  =
D4     4        e     u  =
F4     4        e     u  ]
Ef4    4        e     u  [     &1.
G4     4        e     u  =     (
F4     4        e     u  =
Ef4    4        e     u  ]     )
measure 51
F4     4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
F4     4        e     u  ]
F4     4        e     u  [
F4     4        e     u  =
Af4    4        e f   u  =     (+
F4     4        e     u  ]     )
measure 52
F4     6        e.    u  [     (t
S C33:n4s25t75
Ef4    1        t     u  =[[
F4     1        t     u  ]]]   )
Ef4    8        q     u
rest  16        h
measure 53
G5    32-       w     d        -
measure 54
G5    32-       w     d        -
measure 55
G5     8        q     d        (
F5     4        e     d  [
Ef5    4        e     d  ]
D5    16        h     d        )
measure 56
Df5   16        h f   d        (
C5    16        h     d
measure 57
Cf5   16        h f   d
Bf4   16        h     d        )
measure 58
Bf4    8        q     d        (
Af4    4        e     u  [     )
G4     4        e     u  ]     .
F4     8        q     u        .
C4     8        q     u        .
measure 59
Bf3   16-       h     u        -
Bf3    8        q     u
rest   8        q
measure 60
G4     4        e     u  [
G4     4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
Bf4    4        e     u  [
Bf4    4        e     u  =
G4     4        e     u  =
G4     4        e     u  ]
measure 61
F4     4        e     u  [
F4     4        e     u  =
F4     4        e     u  =
Af4    4        e     u  ]
G4     4        e     u  [     .
Bf4    4        e     u  =     (
Af4    4        e     u  =
G4     4        e     u  ]     )
measure 62
Af4    4        e     u  [
Af4    4        e     u  =
Af4    4        e     u  =
Af4    4        e     u  ]
Af4    4        e     u  [
Af4    4        e     u  =
C5     4        e     u  =     (
Af4    4        e     u  ]     )
measure 63
Af4    6        e.    u  [     (t
S C33:n4s25t75
G4     1        t     u  =[[
Af4    1        t     u  ]]]   )
G4     8        q     u
rest  16        h
measure 64
Bf5   32-       w     d        -
measure 65
Bf5   32-       w     d        -
measure 66
Bf5    4        e     d  [     (
Af5    4        e     d  ]     )
G5    16        h     d        (
F5     8        q     d        )
measure 67
G5     2        s     d  [[    (
Af5    2        s     d  ==
G5     2        s     d  ==
Af5    2        s     d  ]]    )
Bf5    8        q     d        .
rest  16        h
measure 68
F5     6        e.    d  [     (
D5     2        s     d  ]\    )
F5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     d  [
Bf4    4        e     d  =
Bf4    4        e     d  ]
measure 69
G5     6        e.    d  [     (
Ef5    2        s     d  ]\    )
G5     4        e     d        .
rest   4        e
rest   4        e
Bf4    4        e     u  [     .
Bf4    4        e     u  =     (
G4     4        e     u  ]     )
measure 70
G4     4        e     u  [     (
F4     4        e     u  ]     )
Ef4   16        h     u        (
D4     8        q     u        )
measure 71
Ef4   16-       h     u        -
 G3   16        h     u
Ef4    2        s     u  [[
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]
G4     2        s     u  [[
F4     2        s     u  ==
G4     2        s     u  ==
A4     2        s n   u  ]]
measure 72
Bf4   16-       h     d        -
Bf4    2        s     d  [[
A4     2        s n   d  ==
Bf4    2        s     d  ==
C5     2        s     d  ]]
D5     2        s     d  [[
Bf4    2        s     d  ==
C5     2        s     d  ==
D5     2        s     d  ]]
measure 73
Ef5    4        e     d  [
gF5    5        s     u
S C1:t50
Ef5    2        s     d  =[
D5     2        s     d  ]]
Ef5    4        e     d  [
F5     4        e     d  ]
G5     4        e     d  [
gAf5   5        s     u
S C1:t50
G5     2        s     d  =[
F5     2        s     d  ]]
G5     4        e     d  [
A5     4        e n   d  ]
measure 74
Bf5    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
Bf5    8        q     d
 Bf4   8        q     d
 D4    8        q     d
rest   8        q
measure 75
Bf4   12        q.    d        (p
C5     2        s     d  [[
Af4    2        s     d  ]]    )
G4     4        e     u  [     .
G4     4        e     u  =     .
Af4    4        e     u  =     .
Af4    4        e     u  ]     .
measure 76
Bf4   12        q.    d        (
C5     2        s     d  [[
Bf4    2        s     d  ]]    )
Ef5    4        e     d  [     (
D5     4        e     d  =
C5     4        e     d  =
Bf4    4        e     d  ]     )
measure 77
Af4   12        q.    u        (
Bf4    2        s     u  [[
G4     2        s     u  ]]    )
F4     4        e     u  [     .
F4     4        e     u  =     .
G4     4        e     u  =     .
G4     4        e     u  ]     .
measure 78
Af4   12        q.    u        (
Bf4    2        s     u  [[
Af4    2        s     u  ]]    )
F5     4        e     d  [     (
D5     4        e     d  =
Bf4    4        e     d  =
Af4    4        e     d  ]     )
measure 79
G4    12        q.    u        (
Af4    2        s     u  [[
F4     2        s     u  ]]    )
Ef4    4        e     u  [     .
Ef4    4        e     u  =     .
F4     4        e     u  =     .
F4     4        e     u  ]     .
measure 80
G4    12        q.    u        (
Af4    2        s     u  [[
G4     2        s     u  ]]    )
C5     4        e     u  [     (
Bf4    4        e     u  =
Af4    4        e     u  =
G4     4        e     u  ]     )
measure 81
F4    12        q.    u        (
G4     2        s     u  [[
Ef4    2        s     u  ]]    )
D4     4        e     u  [     .
D4     4        e     u  =     .
Ef4    4        e     u  =     .
Ef4    4        e     u  ]     .
measure 82
F4    12        q.    u        (
G4     2        s     u  [[
F4     2        s     u  ]]    )
D5     4        e     u  [     (
Bf4    4        e     u  =
G4     4        e     u  =
F4     4        e     u  ]     )
measure 83
Ef4    4        e     u        .
Bf4    4        e     u  [     (
Af4    4        e     u  =
G4     4        e     u  ]     )
rest   4        e
Ef5    4        e     d        .
D5     4        e     d  [     (
C5     4        e     d  ]     )
measure 84
rest   4        e
Bf4    4        e     d        .
Af4    4        e     u  [     (
G4     4        e     u  ]     )
rest   4        e
F4     4        e     u        .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
measure 85
rest   4        e
Bf3    4        e     u        .
Af3    4        e     u  [     (
G3     4        e     u  ]     )
rest   4        e
Ef4    4        e     u        .
D4     4        e     u  [     (
C4     4        e     u  ]     )
measure 86
rest   4        e
Bf3    4        e     u        .
Af3    4        e     u  [     (
G3     4        e     u  ]     )
rest   4        e
F4     4        e     u        .
Ef4    4        e     u  [     (
D4     4        e     u  ]     )
measure 87
D4     4        e     u  [     (
Ef4    4        e     u  ]     )
Ef4    4        e     u  [     .
G4     4        e     u  ]     .
Ef4    4    &   e     u  [     (f
P C33:y10
D4     4    &   e     u  =
C4     4    &   e     u  =
C4     4    &   e     u  ]     )
&
Source edition gives the following articulation, conflicting with the other parts.
Ef4    4        e     u  [     (f
D4     4        e     u  =
C4     4        e     u  =     )
C4     4        e     u  ]     .
&
measure 88
Bf3    8        q     u        p
rest   8        q
rest  16        h
measure 89
D4     2        s     u  [[    (
Ef4    2        s     u  ==
D4     2        s     u  ==
C4     2        s     u  ]]
*               DH      cresc.
P C17:p15 C17:f33
P C18:p15
Bf3    2        s     u  [[
A3     2        s n   u  ==
Bf3    2        s     u  ==
C4     2        s     u  ]]
D4     2        s     u  [[
C4     2        s     u  ==
Bf3    2        s     u  ==
A3     2        s     u  ]]
Bf3    2        s     u  [[
C4     2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]    )
measure 90
F4     2        s     u  [[    (
G4     2        s     u  ==
F4     2        s     u  ==
Ef4    2        s     u  ]]
D4     2        s     u  [[
C4     2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
F4     2        s     u  [[
Ef4    2        s     u  ==
D4     2        s     u  ==
Ef4    2        s     u  ]]
*               JG      f
P C17:p15 C18:p15
F4     2        s     u  [[
G4     2        s     u  ==
Af4    2        s     u  ==
F4     2        s     u  ]]    )
measure 91
Bf4    8        q     d
rest   8        q
Bf3   16        h     u        (p
P C33:y5
measure 92
Af3    8        q     u        )
rest   8        q
Bf3   16        h     u        (
measure 93
Af3    8        q     u        )
rest   8        q
Af4    8        q     u        (
Bf4    4        e     d  [     )
C5     4        e     d  ]     .
measure 94
gC5    5        s     u        (
S C1:t50
Bf4    8        q     d        )fp
P C33:y5
Af4    4        e     u  [     .
G4     4        e     u  ]     .
gG4    5        s     u        (
S C1:t50
F4     8        q     u        )fp
P C33:y10
Ef4    4        e     u  [     .
D4     4        e     u  ]     .
measure 95
Ef4    8        q     u
*               D       cresc.
P C17:f33 C17:p15
Bf3    2        s     u  [[    (
G3     2        s     u  ==
Af3    2        s     u  ==
Bf3    2        s     u  ]]
C4     2        s     u  [[
Bf3    2        s     u  ==
Af3    2        s     u  ==
Bf3    2        s     u  ]]
C4     2        s     u  [[    f
P C32:y20
D4     2        s     u  ==
Ef4    2        s     u  ==
F4     2        s     u  ]]    )
measure 96
G4     8        q     u
rest   8        q
Bf3   16        h     u        (p
P C33:y5
measure 97
Af3    8        q     u        )
rest   8        q
Bf3   16        h     u        (
measure 98
Af3    8        q     u        )
rest   8        q
Af4    8        q     u        (
Bf4    4        e     d  [     )
C5     4        e     d  ]     .
measure 99
C5     4        e     u  [     (fp
Bf4    4        e     u  =     )
Af4    4        e     u  =     .
G4     4        e     u  ]     .
G4     4        e     u  [     (fp
P C33:y10
F4     4        e     u  =     )
Ef4    4        e     u  =     .
D4     4        e     u  ]     .
measure 100
Ef4    4        e     u  [
G4     2        s     u  =[    (
P C32:u
Af4    2        s     u  ]]
Bf4    4        e     d  [     )
Bf4    4        e     d  ]     .
Bf4    4        e     u  [     (
G4     4        e     u  ]     )
rest   8        q
measure 101
rest   4        e
Af4    2        s     u  [[    (
P C32:u
Bf4    2        s     u  ]]
C5     4        e     d  [     )
C5     4        e     d  ]     .
Af4    4        e     u  [     (
F4     4        e     u  ]     )
rest   8        q
measure 102
rest   4        e
F4     2        s     u  [[    (
Af4    2        s     u  ]]
G4     4        e     u  [     )
G4     4        e     u  ]     .
G4     4        e     u  [     (
Ef4    4        e     u  ]     )
rest   8        q
measure 103
rest   4        e
Bf3    2        s     u  [[    (
Df4    2        s f   u  ]]
C4     4        e     u  [     )
C4     4        e     u  ]     .
F4     4        e     u  [     (
D4     4        e n   u  ]     )
rest   4        e
Af3    4        e     u        &1.
measure 104
G3     4        e     u        .
G3     2        s     u  [[    (f
P C33:y10
Af3    2        s     u  ]]
Bf3    2        s     u  [[
C4     2        s     u  ==
Af3    2        s     u  ==
Bf3    2        s     u  ]]    )
G3     4        e     u        .
G3     2        s     u  [[    (
Af3    2        s     u  ]]
Bf3    2        s     u  [[
C4     2        s     u  ==
Af3    2        s     u  ==
Bf3    2        s     u  ]]    )
measure 105
G3     8        q     u
Bf4    8        q     u
 Ef4   8        q     u
 G3    8        q     u
Bf4    8        q     u
 Ef4   8        q     u
 G3    8        q     u
rest   8        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/01/03} [KHM:14741725]
TIMESTAMP: DEC/26/2001 [md5sum:0cb576a3861a5a3c78e633bd6b8141a6]
06/22/94 E. Correia
WK#:160       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-3   Q:4   T:1/1  C:13  D:Allegro
Ef4    2        e     d  [     &0f
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
measure 2
Af3    2        e     u  [
Af3    2        e     u  =
Af3    2        e     u  =
D4     2        e     u  ]
Ef4    2        e     d  [     .
Ef4    2        e     d  =     (
F4     2        e     d  =
G4     2        e     d  ]     )
measure 3
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
measure 4
Ef4    4        q     d
rest   2        e
Bf4    2        e     d        .
Af4    2        e     d  [     .
G4     2        e     d  =     .
F4     2        e     d  =     .
Ef4    2        e     d  ]     .
measure 5
D4     3        e.    d  [     (
Bf3    1        s     d  ]\    )
D4     2        e     d  [     .
Ef4    2        e     d  ]     .
F4     2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
F4     2        e     d  ]     .
measure 6
Bf4    3        e.    d  [     (
G4     1        s     d  ]\    )
Ef4    2        e     d  [     .
D4     2        e     d  ]     .
Ef4    2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
G4     2        e     d  ]     .
measure 7
G4     2        e     d  [     (
F4     2        e     d  ]     )
Ef4    8        h     d        (
D4     4        q     d        )
measure 8
Ef4    1        s     d  [[    (
F4     1        s     d  ==
Ef4    1        s     d  ==
F4     1        s     d  ]]    )
G4     2        e     d  [     .
Bf4    2        e     d  ]     .
Af4    2        e     d  [     .
G4     2        e     d  =     .
F4     2        e     d  =     .
Ef4    2        e     d  ]     .
measure 9
D4     3        e.    d  [     (
Bf3    1        s     d  ]\    )
D4     2        e     d  [     .
Ef4    2        e     d  ]     .
F4     2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
F4     2        e     d  ]     .
measure 10
Bf4    3        e.    d  [     (
G4     1        s     d  ]\    )
Ef4    2        e     d  [     .
D4     2        e     d  ]     .
Ef4    2        e     d  [     .
G4     2        e     d  =     .
Bf3    2        e     d  =     (
Ef4    2        e     d  ]     )
measure 11
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
Bf3    2        e     u  [
Bf3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  ]
measure 12
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 13
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 14
G4     4        q     d
rest   4        q
Ef4    4        q     d
rest   4        q
measure 15
D4     4        q     d
F4     4        q     d
F4     4        q     d
rest   4        q
measure 16
D4     6        q.    d        (p
Ef4    1        s     d  [[
C4     1        s     d  ]]    )
Bf3    2        e     u  [     .
Bf3    2        e     u  =     .
C4     2        e     u  =     .
C4     2        e     u  ]     .
measure 17
D4     6        q.    d        (
Ef4    1        s     d  [[
D4     1        s     d  ]]    )
G4     2        e     d  [     (
F4     2        e     d  =
Ef4    2        e     d  =
D4     2        e     d  ]     )
measure 18
C4     6        q.    d        (
D4     1        s     d  [[
Bf3    1        s     d  ]]    )
A3     2        e n   u  [     .
A3     2        e     u  =     .
Bf3    2        e     u  =     .
Bf3    2        e     u  ]     .
measure 19
C4     6        q.    d        (
D4     1        s     d  [[
C4     1        s     d  ]]    )
A4     2        e n   d  [     (
F4     2        e     d  =
D4     2        e     d  =
C4     2        e     d  ]     )
measure 20
Bf3    4        q     u
F3     8        h     u
F3     4-       q     u        -
measure 21
F3     4        q     u
F3     8        h     u
F3     4-       q     u        -
measure 22
F3     4        q     u
F3     8        h     u
F3     4-       q     u        -
measure 23
F3     4        q     u
F3     8        h     u
A3     4        q n   u
measure 24
Bf3    2        e     d  [     .
D4     2        e     d  ]     .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
rest   2        e
G4     2        e     d        .
F4     2        e     d  [     (
Ef4    2        e     d  ]     )
measure 25
rest   2        e
D4     2        e     d        .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
rest   2        e
A3     2        e n   u        .
G3     2        e     u  [     (
F3     2        e     u  ]     )
measure 26
rest   2        e
D4     2        e     d        .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
rest   2        e
G4     2        e     d        .
F4     2        e     d  [     (
Ef4    2        e     d  ]     )
measure 27
rest   2        e
D4     2        e     d        .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
rest   2        e
A3     2        e n   u        .
G3     2        e     u  [     (
F3     2        e     u  ]     )
measure 28
F3     4        q     u
rest   2        e
A4     2        e n   d        .f
G4     2        e     d  [     (
F4     2        e     d  =
Ef4    2        e     d  =
C4     2        e     d  ]     )
measure 29
F4     4        q     d        p
rest   4        q
rest   8        h
measure 30
rest  16
measure 31
*               DH      cresc.
P C17:f33
F4     2        e     d
F4     4        q     d
F4     4        q     d
*      2        JG      f
F4     4        q     d
F4     2        e     d
measure 32
F4     4        q     d        .
rest   4        q
B3     8        h n   u        (p
measure 33
C4     4        q     d        )
rest   4        q
B3     8        h n   u        (
measure 34
C4     4        q     d        )
rest   4        q
Ef4    4        q     d        (
F4     2        e     d  [     )
G4     2        e     d  ]     .
measure 35
gG4    5        s     u        (
S C1:t50
F4     4        q     d        )fp
Ef4    2        e     d  [     .
D4     2        e     d  ]     .
gD4    5        s     u        (
S C1:t50
C4     4        q     d        )fp
P C33:y5
Bf3    2        e f   u  [     .+
A3     2        e n   u  ]     .
measure 36
Bf3    2        e     u  [
Bf3    2        e     u  =
*               D       cresc.
P C17:f33 C17:p-10
Bf3    2        e     u  =
Bf3    2        e     u  ]
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =     f
P C32:y5
F4     2        e     d  ]
measure 37
D4     4        q     d
rest   4        q
F3     8        h     u        (p
measure 38
G3     4        q     u        )
rest   4        q
F3     8        h     u        (
measure 39
G3     4        q     u        )
rest   4        q
G4     4        q     d        (
A4     2        e n   d  [     )
Bf4    2        e     d  ]     .
measure 40
Bf4    2        e     d  [     (fp
A4     2        e n   d  =     )
G4     2        e     d  =     .
F4     2        e     d  ]     .
F4     2        e     d  [     (fp
Ef4    2        e     d  =     )
D4     2        e     d  =     .
C4     2        e     d  ]     .
measure 41
Bf3    2        e     u  [
Bf3    1        s     u  =[    (
P C32:u
C4     1        s     u  ]]
D4     2        e     d  [     )
D4     2        e     d  ]     .
D4     2        e     d  [     (
Bf3    2        e     d  ]     )
rest   4        q
measure 42
rest   2        e
Ef4    1        s     d  [[    (
D4     1        s     d  ]]
C4     2        e     d  [     )
C4     2        e     d  ]     .
C4     2        e     u  [     (
A3     2        e n   u  ]     )
rest   4        q
measure 43
rest   2        e
A3     1        s n   u  [[    (
C4     1        s     u  ]]
Bf3    2        e     u  [     )
Bf3    2        e     u  ]     .
Bf3    2        e     d  [     (
D4     2        e     d  ]     )
rest   4        q
measure 44
rest   2        e
Ef4    1        s     d  [[    (
D4     1        s     d  ]]
C4     2        e     d  [     )
C4     2        e     d  ]     .
C4     2        e     u  [     (
A3     2        e n   u  ]     )
rest   2        e
C4     2        e     d
measure 45
Bf3    4        q     u        f
F4     4        q     d
F4     4        q     d
rest   4        q
measure 46
rest  16
measure 47
B3     4        q n   u        f
B3     4        q     u
B3     4        q     u
rest   4        q
measure 48
rest  16
measure 49
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
C4     2        e     u  [
C4     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
measure 50
F3     2        e     u  [
F3     2        e     u  =
F3     2        e     u  =
B3     2        e n   u  ]
C4     2        e     d  [     .
Ef4    2        e     d  =     (
D4     2        e     d  =
C4     2        e     d  ]     )
measure 51
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
measure 52
C4     4        q     d
rest   2        e
G4     2        e     d        .
F4     2        e     d  [     .
Ef4    2        e     d  =     .
D4     2        e     d  =     .
C4     2        e     d  ]     .
measure 53
B3     3        e.n   u  [     (
G3     1        s     u  ]\    )
B3     2        e     d  [     .
F4     2        e     d  ]     .
Ef4    2        e     d  [     .
D4     2        e     d  =     .
C4     2        e     d  =     .
B3     2        e     d  ]     .
measure 54
C4     3        e.    d  [     (
Ef4    1        s     d  ]\    )
G4     2        e     d  [     .
G4     2        e     d  ]     .
F4     2        e     d  [     .
Ef4    2        e     d  =     .
D4     2        e     d  =     .
Ef4    2        e     d  ]     .
measure 55
C4     8        h     d        (
B3     8        h n   u        )
measure 56
Bf3    8        h f   u        (+
Af3    8        h     u        )
measure 57
F4     6        q.    d        (
Ef4    1        s     d  [[
D4     1        s     d  ]]    )
Ef4    8        h     d
measure 58
Ef4    8        h     d
C4     2        e     u  [     .
Bf3    2        e     u  =     .
Af3    2        e     u  =     .
G3     2        e     u  ]     .
measure 59
G3     8        h     u        (
F3     4        q     u        )
rest   4        q
measure 60
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
Bf3    2        e     d  =
Bf3    2        e     d  ]
measure 61
Af3    2        e     u  [
Af3    2        e     u  =
Af3    2        e     u  =
D4     2        e     u  ]
Ef4    2        e     d  [     .
G4     2        e     d  =     (
F4     2        e     d  =
Ef4    2        e     d  ]     )
measure 62
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
Ef4    2        e     d  [
Ef4    2        e     d  =
Ef4    2        e     d  =
Ef4    2        e     d  ]
measure 63
Ef4    4        q     d
rest   2        e
Bf4    2        e     d        .
Af4    2        e     d  [     .
G4     2        e     d  =     .
F4     2        e     d  =     .
Ef4    2        e     d  ]     .
measure 64
D4     3        e.    d  [     (
Bf3    1        s     d  ]\    )
D4     2        e     d  [     .
Ef4    2        e     d  ]     .
F4     2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
F4     2        e     d  ]     .
measure 65
Bf4    3        e.    d  [     (
G4     1        s     d  ]\    )
Ef4    2        e     d  [     .
D4     2        e     d  ]     .
Ef4    2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
G4     2        e     d  ]     .
measure 66
G4     2        e     d  [     (
F4     2        e     d  ]     )
Ef4    8        h     d        (
D4     4        q     d        )
measure 67
Ef4    1        s     d  [[    (
F4     1        s     d  ==
Ef4    1        s     d  ==
F4     1        s     d  ]]    )
G4     2        e     d  [     .
Bf4    2        e     d  ]     .
Af4    2        e     d  [     .
G4     2        e     d  =     .
F4     2        e     d  =     .
Ef4    2        e     d  ]     .
measure 68
D4     3        e.    d  [     (
Bf3    1        s     d  ]\    )
D4     2        e     d  [     .
Ef4    2        e     d  ]     .
F4     2        e     d  [     .
G4     2        e     d  =     .
Af4    2        e     d  =     .
F4     2        e     d  ]     .
measure 69
Bf4    3        e.    d  [     (
G4     1        s     d  ]\    )
Ef4    2        e     d  [     .
D4     2        e     d  ]     .
Ef4    2        e     d  [     .
G4     2        e     d  =     .
Bf3    2        e     d  =     (
Ef4    2        e     d  ]     )
measure 70
C4     2        e     d  [
C4     2        e     d  =
C4     2        e     d  =
C4     2        e     d  ]
Bf3    2        e     u  [
Bf3    2        e     u  =
Af3    2        e     u  =
Af3    2        e     u  ]
measure 71
G3     2        e     u  [
G3     2        e     u  =
G3     2        e     u  =
G3     2        e     u  ]
G4     2        e     d  [
G4     2        e     d  =
G4     2        e     d  =
G4     2        e     d  ]
measure 72
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
F4     2        e     d  [
F4     2        e     d  =
F4     2        e     d  =
F4     2        e     d  ]
measure 73
G4     4        q     d
rest   4        q
Ef4    4        q     d
rest   4        q
measure 74
D4     4        q     d
F4     4        q     d
F4     4        q     d
rest   4        q
measure 75
G4     6        q.    d        (p
Af4    1        s     d  [[
F4     1        s     d  ]]    )
Ef4    2        e     d  [     .
Ef4    2        e     d  =     .
F4     2        e     d  =     .
F4     2        e     d  ]     .
measure 76
G4     6        q.    d        (
Af4    1        s     d  [[
G4     1        s     d  ]]    )
C5     2        e     d  [     (
Bf4    2        e     d  =
Af4    2        e     d  =
G4     2        e     d  ]     )
measure 77
F4     6        q.    d        (
G4     1        s     d  [[
Ef4    1        s     d  ]]    )
D4     2        e     d  [     .
D4     2        e     d  =     .
Ef4    2        e     d  =     .
Ef4    2        e     d  ]     .
measure 78
F4     6        q.    d        (
G4     1        s     d  [[
F4     1        s     d  ]]    )
Af4    2        e     d  [     (
F4     2        e     d  =
D4     2        e     d  =
F4     2        e     d  ]     )
measure 79
Ef4    4        q     d
Bf3    8        h     u
Bf3    4-       q     u        -
measure 80
Bf3    4        q     u
Bf3    8        h     u
Bf3    4-       q     u        -
measure 81
Bf3    4        q     u
Bf3    8        h     u
Bf3    4-       q     u        -
measure 82
Bf3    4        q     u
Bf3    8        h     u
Bf3    4        q     u
measure 83
Bf3    2        e     u        .
G4     2        e     d  [     (
F4     2        e     d  =
Ef4    2        e     d  ]     )
rest   2        e
C5     2        e     d        .
Bf4    2        e     d  [     (
Af4    2        e     d  ]     )
measure 84
rest   2        e
G4     2        e     d        .
F4     2        e     d  [     (
Ef4    2        e     d  ]     )
rest   2        e
D4     2        e     d        .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
measure 85
rest   2        e
G3     2        e     u        .
F3     2        e     u  [     (
Ef3    2        e     u  ]     )
rest   2        e
C4     2        e     d        .
Bf3    2        e     u  [     (
Af3    2        e     u  ]     )
measure 86
rest   2        e
G3     2        e     u        .
F3     2        e     u  [     (
Ef3    2        e     u  ]     )
rest   2        e
D4     2        e     d        .
C4     2        e     u  [     (
Bf3    2        e     u  ]     )
measure 87
Bf3    4        q     u
Bf3    2        e     d  [     .
Ef4    2        e     d  ]     .
C4     2        e     u  [     (f
Bf3    2        e     u  =
Af3    2        e     u  =
F3     2        e     u  ]     )
measure 88
F3     4        q     u        p
rest   4        q
rest   8        h
measure 89
rest  16
measure 90
*               DH      cresc.
P C17:f33
Bf3    2        e     u  [
Bf3    2        e     u  =
Bf3    2        e     u  =
Bf3    2        e     u  ]
Bf3    2        e     u  [
Bf3    2        e     u  =
*               JG      f
Bf3    2        e     u  =
Bf3    2        e     u  ]
measure 91
Bf3    4        q     u
rest   4        q
E3     8        h n   u        (p
measure 92
F3     4        q     u        )
rest   4        q
E3     8        h n   u        (
measure 93
F3     4        q     u        )
rest   4        q
C4     4        q     d        (
D4     2        e     d  [     )
Ef4    2        e     d  ]     .
measure 94
gEf4   5        s     u        (
S C1:t50
D4     4        q     d        )fp
C4     2        e     u  [     .
Bf3    2        e     u  ]     .
gBf3   5        s     u        (
S C1:t50
Af3    4        q     u        )fp
P C33:y10
G3     2        e     u  [     .
F3     2        e     u  ]     .
measure 95
Ef3    2        e     u  [
Ef3    2        e     u  =
*               D       cresc.
P C17:f33 C17:p-10
Ef3    2        e     u  =
Ef3    2        e     u  ]
Ef3    2        e     u  [
Ef3    2        e     u  =
Af3    2        e     u  =     f
P C32:y10
Af3    2        e     u  ]
measure 96
Bf3    4        q     u
rest   4        q
E3     8        h n   u        (p
measure 97
F3     4        q     u        )
rest   4        q
E3     8        h n   u        (
measure 98
F3     4        q     u        )
rest   4        q
C4     4        q     d        (
D4     2        e     d  [     )
Ef4    2        e     d  ]     .
measure 99
Ef4    2        e     d  [     (fp
D4     2        e     d  =     )
C4     2        e     d  =     .
Bf3    2        e     d  ]     .
Bf3    2        e     u  [     (fp
P C33:y10
Af3    2        e     u  =     )
G3     2        e     u  =     .
F3     2        e     u  ]     .
measure 100
Ef3    2        e     d  [
Ef4    1        s     d  =[    (
F4     1        s     d  ]]
G4     2        e     d  [     )
G4     2        e     d  ]     .
Ef4    2        e     d  [     (
Bf3    2        e     d  ]     )
rest   4        q
measure 101
rest   2        e
F4     1        s     d  [[    (
G4     1        s     d  ]]
Af4    2        e     d  [     )
Af4    2        e     d  ]     .
F4     2        e     d  [     (
D4     2        e     d  ]     )
rest   4        q
measure 102
rest   2        e
D4     1        s     d  [[    (
F4     1        s     d  ]]
Ef4    2        e     d  [     )
Ef4    2        e     d  ]     .
Ef4    2        e     d  [     (
Bf3    2        e     d  ]     )
rest   4        q
measure 103
rest   2        e
G3     1        s     u  [[    (
Bf3    1        s     u  ]]
Af3    2        e     u  [     )
Af3    2        e     u  ]     .
Af3    2        e     u  [     (
F3     2        e     u  ]     )
rest   2        e
F3     2        e     u        .
measure 104
Ef3    4        q     u        f
rest   4        q
Bf3    4        q     u
rest   4        q
measure 105
Bf3    4        q     u
Bf3    4        q     u
Bf3    4        q     u
rest   4        q
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k160/stage2/01/04} [KHM:14741725]
TIMESTAMP: DEC/26/2001 [md5sum:bd4c64ee270c5df08ea0ef18e5390584]
06/22/94 E. Correia
WK#:160       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 7 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-3   Q:2   T:1/1  C:22  D:Allegro
Ef3    1        e     d  [     &0f
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 2
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 3
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 4
Ef3    2        q     d
rest   1        e
G3     1        e     d        .
F3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
C3     1        e     d  ]     .
measure 5
Bf2    2        q     u
Bf2    1        e     u  [     .
C3     1        e     u  ]     .
D3     1        e     d  [     .
Ef3    1        e     d  =     .
F3     1        e     d  =     .
D3     1        e     d  ]     .
measure 6
Ef3    1        e     d  [     .
G3     1        e     d  =     .
Bf3    1        e     d  =     .
Af3    1        e     d  ]     .
G3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
Ef3    1        e     d  ]     .
measure 7
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 8
Ef3    2        q     d
rest   1        e
G3     1        e     d        .
F3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
C3     1        e     d  ]     .
measure 9
Bf2    2        q     u
Bf2    1        e     u  [     .
C3     1        e     u  ]     .
D3     1        e     d  [     .
Ef3    1        e     d  =     .
F3     1        e     d  =     .
D3     1        e     d  ]     .
measure 10
Ef3    2        q     d
Bf3    1        e     d  [     .
Af3    1        e     d  ]     .
G3     1        e     d  [     .
Bf3    1        e     d  =     .
G3     1        e     d  =     (
Ef3    1        e     d  ]     )
measure 11
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 12
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 13
D3     1        e     d  [
D3     1        e     d  =
D3     1        e     d  =
D3     1        e     d  ]
D3     1        e     d  [
D3     1        e     d  =
D3     1        e     d  =
D3     1        e     d  ]
measure 14
C3     2        q     u
rest   2        q
C3     2        q     u
rest   2        q
measure 15
Bf2    2        q     u
Bf3    2        q     d
Bf2    2        q     u
rest   2        q
measure 16
Bf2    2        q     u        p
Bf3    2        q     d
rest   4        h
measure 17
rest   2        q
Bf3    2        q     d
Bf2    2        q     u
Bf3    2        q     d
measure 18
F3     2        q     d
F2     2        q     u
rest   4        h
measure 19
rest   2        q
F2     2        q     u
F3     2        q     d
F2     2        q     u
measure 20
Bf2    2        q     u
Bf3    2        q     d
rest   4        h
measure 21
rest   2        q
Bf3    2        q     d
Bf2    2        q     u
Bf3    2        q     d
measure 22
F3     2        q     d
F2     2        q     u
rest   4        h
measure 23
rest   2        q
F2     2        q     u
F3     2        q     d
F2     2        q     u
measure 24
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 25
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
F2     1        e     u  [
F2     1        e     u  =
F2     1        e     u  =
F2     1        e     u  ]
measure 26
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 27
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
F2     1        e     u  [
F2     1        e     u  =
F2     1        e     u  =
F2     1        e     u  ]
measure 28
Bf2    1        e     d  [
Bf2    1        e     d  =
Bf3    1        e     d  =     f
A3     1        e n   d  ]
G3     1        e     d  [     (
F3     1        e     d  =
Ef3    1        e     d  =
E3     1        e n   d  ]     )
measure 29
F3     1        e     d  [     p
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
measure 30
F3     1        e     d  [
F3     1        e     d  =
*               DH      cresc.
P C17:f33
F3     1        e     d  =
F3     1        e     d  ]
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
measure 31
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
F3     1        e     d  [
F3     1        e     d  =
*               JG      f
Ef3    1        e f   d  =     +
Ef3    1        e     d  ]
measure 32
D3     2        q     d        .
rest   2        q
D3     4        h     d        (p
measure 33
Ef3    2        q     d        )
rest   2        q
D3     4        h     d        (
measure 34
Ef3    2        q     d        )
rest   2        q
rest   4        h
measure 35
F3     4        h     d        fp
F2     4        h     u        fp
P C32:y5
measure 36
Bf2    1        e     u  [
Bf2    1        e     u  =
*               D       cresc.
P C17:f33 C17:p-10
Bf2    1        e     u  =
Bf2    1        e     u  ]
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =     f
P C32:y10
C3     1        e     u  ]
measure 37
D3     2        q     d
rest   2        q
D2     4        h     u        (p
measure 38
Ef2    2        q     u        )
rest   2        q
D2     4        h     u        (
measure 39
Ef2    2        q     u        )
rest   2        q
rest   4        h
measure 40
F2     4        h     u        fp
F3     4        h     d        fp
measure 41
Bf2    4        h     u        (
D3     4        h     d        )
measure 42
Ef3    4        h     d        (
F3     4        h     d        )
measure 43
G3     4        h     d        (
D3     4        h     d
measure 44
Ef3    4        h     d
F3     4        h     d        )
measure 45
Bf2    2        q     u        f
Bf3    2        q     d
Bf2    2        q     u
rest   2        q
measure 46
rest   8
measure 47
B2     2        q n   u        f
B2     2        q     u
B2     2        q     u
rest   2        q
measure 48
rest   8
measure 49
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 50
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 51
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
C3     1        e     u  [
C3     1        e     u  =
C3     1        e     u  =
C3     1        e     u  ]
measure 52
C3     2        q     u
rest   1        e
Ef3    1        e     d        .
D3     1        e     u  [     .
C3     1        e     u  =     .
B2     1        e n   u  =     .
C3     1        e     u  ]     .
measure 53
G2     2        q     u
rest   2        q
G3     1        e     d  [     .
F3     1        e     d  =     .
Ef3    1        e     d  =     .
D3     1        e     d  ]     .
measure 54
C3     2        q     u
rest   1        e
Ef3    1        e     d        .
D3     1        e     u  [     .
C3     1        e     u  =     .
B2     1        e n   u  =     .
C3     1        e     u  ]     .
measure 55
F3     1        e     d  [
F3     1        e     d  =
F3     1        e     d  =
F3     1        e     d  ]
G3     1        e     d  [
G3     1        e     d  =
G3     1        e     d  =
G3     1        e     d  ]
measure 56
G3     1        e     d  [
G3     1        e     d  =
G3     1        e     d  =
G3     1        e     d  ]
Af3    1        e     d  [
Af3    1        e     d  =
Af3    1        e     d  =
Af3    1        e     d  ]
measure 57
Af3    1        e     d  [
Af3    1        e     d  =
Af3    1        e     d  =
Af3    1        e     d  ]
G3     1        e     d  [
G3     1        e     d  =
G3     1        e     d  =
G3     1        e     d  ]
measure 58
Af3    1        e     d  [
Af3    1        e     d  =
Af3    1        e     d  =
Af3    1        e     d  ]
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
A2     1        e n   u  ]
measure 59
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     d  [
Af3    1        e     d  =
G3     1        e     d  =
F3     1        e     d  ]
measure 60
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 61
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 62
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 63
Ef3    2        q     d
rest   1        e
G3     1        e     d        .
F3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
C3     1        e     d  ]     .
measure 64
Bf2    2        q     u
Bf2    1        e     u  [     .
C3     1        e     u  ]     .
D3     1        e     d  [     .
Ef3    1        e     d  =     .
F3     1        e     d  =     .
D3     1        e     d  ]     .
measure 65
Ef3    1        e     d  [     (
G3     1        e     d  =
Bf3    1        e     d  =     )
Af3    1        e     d  ]     .
G3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
Ef3    1        e     d  ]     .
measure 66
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 67
Ef3    2        q     d
rest   1        e
G3     1        e     d        .
F3     1        e     d  [     .
Ef3    1        e     d  =     .
D3     1        e     d  =     .
C3     1        e     d  ]     .
measure 68
Bf2    2        q     u
Bf2    1        e     u  [     .
C3     1        e     u  ]     .
D3     1        e     d  [     .
Ef3    1        e     d  =     .
F3     1        e     d  =     .
D3     1        e     d  ]     .
measure 69
Ef3    2        q     d
Bf3    1        e     d  [     .
Af3    1        e     d  ]     .
G3     1        e     d  [     .
Bf3    1        e     d  =     .
G3     1        e     d  =     (
Ef3    1        e     d  ]     )
measure 70
Af2    1        e     u  [
Af2    1        e     u  =
Af2    1        e     u  =
Af2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 71
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 72
D3     1        e     d  [
D3     1        e     d  =
D3     1        e     d  =
D3     1        e     d  ]
D3     1        e     d  [
D3     1        e     d  =
D3     1        e     d  =
D3     1        e     d  ]
measure 73
C3     2        q     u
rest   2        q
C3     2        q     u
rest   2        q
measure 74
Bf2    2        q     u
Bf3    2        q     d
Bf2    2        q     u
rest   2        q
measure 75
Ef4    2        q     d        p
Ef3    2        q     d
rest   4        h
measure 76
rest   2        q
Ef3    2        q     d
Ef4    2        q     d
Ef3    2        q     d
measure 77
Bf2    2        q     u
Bf3    2        q     d
rest   4        h
measure 78
rest   2        q
Bf3    2        q     d
Bf2    2        q     u
Bf3    2        q     d
measure 79
Ef3    2        q     d
Ef2    2        q     u
rest   4        h
measure 80
rest   2        q
Ef2    2        q     u
Ef3    2        q     d
Ef2    2        q     u
measure 81
Bf2    2        q     u
Bf3    2        q     d
rest   4        h
measure 82
rest   2        q
Bf3    2        q     d
Bf2    2        q     u
Bf3    2        q     d
measure 83
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
measure 84
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =
Ef3    1        e     d  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 85
Ef2    1        e     u  [
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
Ef2    1        e     u  [
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
measure 86
Ef2    1        e     u  [
Ef2    1        e     u  =
Ef2    1        e     u  =
Ef2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 87
Ef3    1        e     d  [     .
Ef3    1        e     d  =     .
G3     1        e     d  =     .
Ef3    1        e     d  ]     .
C3     1        e     u  [     (f
Bf2    1        e     u  =
Af2    1        e     u  =
A2     1        e n   u  ]     )
measure 88
Bf2    1        e     u  [     p
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 89
Bf2    1        e     u  [
Bf2    1        e     u  =
*               DH      cresc.
P C17:f33
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
measure 90
Bf2    1        e     u  [
Bf2    1        e     u  =
Bf2    1        e     u  =
Bf2    1        e     u  ]
Bf2    1        e     u  [
Bf2    1        e     u  =
*               JG      f
Af2    1        e f   u  =     +
Af2    1        e     u  ]
measure 91
G2     2        q     u
rest   2        q
G2     4        h     u        (p
measure 92
Af2    2        q     u        )
rest   2        q
G2     4        h     u        (
measure 93
Af2    2        q     u        )
rest   2        q
rest   4        h
measure 94
Bf3    4        h     d        fp
Bf2    4        h     u        fp
measure 95
Ef3    1        e     d  [
Ef3    1        e     d  =
*               D       cresc.
P C17:f33 C17:p-10
Ef3    1        e     d  =
Ef3    1        e     d  ]
Ef3    1        e     d  [
Ef3    1        e     d  =
Ef3    1        e     d  =     f
Ef3    1        e     d  ]
measure 96
Ef3    2        q     d
rest   2        q
G2     4        h     u        (p
measure 97
Af2    2        q     u        )
rest   2        q
G2     4        h     u        (
measure 98
Af2    2        q     u        )
rest   2        q
rest   4        h
measure 99
Bf3    4        h     d        fp
Bf2    4        h     u        fp
measure 100
Ef3    4        h     d        (
G3     4        h     d        )
measure 101
Af3    4        h     d        (
Bf3    4        h     d        )
measure 102
C4     4        h     d        (
G2     4        h     u        )
measure 103
Af2    4        h     u
Bf2    4        h     u
measure 104
Ef2    2        q     u        f
rest   2        q
Ef2    2        q     u
rest   2        q
measure 105
Ef2    2        q     u
Ef3    2        q     d
Ef2    2        q     u
rest   2        q
mheavy2
/END
/eof
//
