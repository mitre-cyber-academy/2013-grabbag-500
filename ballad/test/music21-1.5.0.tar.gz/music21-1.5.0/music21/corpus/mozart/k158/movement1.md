&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/01/01} [KHM:4076231775]
TIMESTAMP: DEC/26/2001 [md5sum:6f768c74954fef81ef0896966c8f5e1f]
03/26/94 E. Correia
WK#:158       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-1   Q:24   T:3/4  C:4  D:Presto
F5     6        s     d        f
A5     8        e  3  d  [     (*
F5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 1
A4    24        q     u
rest  24        q
C5    24        q     d
measure 2
Bf4   24        q     d
rest  12        e
rest   6        s
E5     6        s     d
G5     8        e  3  d  [     (*
E5     8        e  3  d  =
Bf4    8        e  3  d  ]     )!
measure 3
G4    24        q     u
rest  24        q
Bf4   24        q     d
measure 4
A4    24        q     u
rest  12        e
rest   6        s
A4     6        s     u
C5     8        e  3  u  [     (*
A4     8        e  3  u  =
F4     8        e  3  u  ]     )!
measure 5
F5    72-       h.    d        -
measure 6
F5    72        h.    d
measure 7
F5    72-       h.    d        -
measure 8
F5    24        q     d
rest  12        e
rest   6        s
F5     6        s     d
D5     8        e  3  d  [     (*
Bf4    8        e  3  d  =
G4     8        e  3  d  ]     )!
measure 9
F4    48        h     u        (
gA4    5        s     u
S C1:t25
G4    24        q     u        )
measure 10
F4    24        q     u
rest  24        q
rest  24        q
measure 11
rest  72
measure 12
G5    72-       h.    d        -&0p
measure 13
G5    24        q     d
gF5    5        s     u
S C1:t25
E5    24        q     d
gD5    5        s     u
S C1:t25
C5    24        q     d
measure 14
C5    72        h.    d        (
measure 15
B4    24        q n   d        )
rest  24        q
rest  24        q
measure 16
F5    72-       h.    d        -
measure 17
F5    24        q     d
gE5    5        s     u
S C1:t25
D5    24        q     d
gC5    5        s     u
S C1:t25
B4    24        q n   d
measure 18
D5    72        h.    d        (
measure 19
C5    24        q     d        )
rest  24        q
rest  24        q
measure 20
A5    18        e.    d  [     (t
S C33:hn6s17t84
P C33:y-3
G5     3        t     d  =[[
A5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 21
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-3
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 22
D5    48-       h     d        -(
D5    12        e     d  [
E5     6        s     d  =[
F5     6        s     d  ]]     )
measure 23
E5    24        q     d
rest  24        q
rest  24        q
measure 24
A5    18        e.    d  [     (t
S C33:hn6s17t84
P C33:y-2
G5     3        t     d  =[[
A5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 25
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 26
D5    48-       h     d        -(
D5    12        e     d  [
E5     6        s     d  =[
F5     6        s     d  ]]     )
measure 27
E5    24        q     d
rest  24        q
rest  24        q
measure 28
C#5   12        e #   d  [     (
D5    12        e     d  =
E5    12        e     d  =
D5    12        e     d  =
G5    12        e     d  =
F5    12        e     d  ]     )
measure 29
A5    24        q     d        (
A4    24        q     u
D5    24        q     d        )
measure 30
C5    72        h.n   d        (+
measure 31
B4    24        q n   d        )
rest  24        q
rest  24        q
measure 32
rest  24        q
G5    24        q     d        .p
G5    24        q     d        .
measure 33
E5    24        q     d        (
F5    24        q     d        )
rest  24        q
measure 34
rest  24        q
F5    24        q     d        .
F5    24        q     d        .
measure 35
D5    24        q     d        (
E5    12        e     d        )
rest   6        s
E5     6        s     d        f
G5     8        e  3  d  [     (*
E5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 36
Bf5   48        h f   d        +
Bf3   24        q f   u        +
measure 37
A3    24        q     u
rest  12        e
rest   6        s
F5     6        s     d
A5     8        e  3  d  [     (*
F5     8        e  3  d  =
D5     8        e  3  d  ]     )!
measure 38
C6    24        q     d        (
G#5   24        q #   d
A5    24        q     d
measure 39
E5    24        q     d
F5    24        q     d
D5    24        q     d        )
measure 40
C5    48        h     d        (
gE5    5        s     u
S C1:t25
D5    24        q     d        )
measure 41
C5    12        e     d
rest  12        e
G5    12        e     d        p
rest  12        e
G5    12        e     d
rest  12        e
measure 42
G5    12        e     d
rest  12        e
G5    12        e     d
rest  12        e
G5    12        e     d
rest  12        e
measure 43
G5    24        q     d
rest  12        e
rest   6        s
E4     6        s     u
G4     8        e  3  u  [     (*
F4     8        e  3  u  =
E4     8        e  3  u  ]     )!
measure 44
D4    24        q     u
rest  12        e
rest   6        s
D4     6        s     u
F4     8        e  3  u  [     (*
E4     8        e  3  u  =
D4     8        e  3  u  ]     )!
measure 45
C4    24        q     u
rest  12        e
rest   6        s
mheavy4         :|:
rest   6        s
rest  24        q
measure 46
C4    12        e     u        .f
rest  12        e
E4    12        e     u        .p
rest  12        e
G4    12        e     u        .
rest  12        e
measure 47
Af4   12        e f   u        &1.
rest  12        e
F4    12        e     u        &1.
rest  12        e
rest  24        q
measure 48
C5    12        e     d        .f
rest  12        e
Af4   12        e f   u        .p
rest  12        e
F4    12        e     u        .
rest  12        e
measure 49
E4    12        e     u        &1.
rest  12        e
G4    12        e     u        &1.
rest  12        e
rest  24        q
measure 50
C4    12        e     u        .f
rest  12        e
E4    12        e     u        .p
rest  12        e
G4    12        e     u        .
rest  12        e
measure 51
Af4   12        e f   u        .
rest  12        e
E4    12        e     u        .
rest  12        e
F4    12        e     u        .
rest  12        e
measure 52
Df4   12        e f   u        &1.
rest  12        e
C4    12        e     u        &1.
rest  12        e
B3    12        e n   u        &1.
rest  12        e
measure 53
C4    24        q     u
rest  24        q
rest  24        q
measure 54
rest  24        q
rest  12        e
rest   6        s
C5     6        s     d        f
G5     8        e  3  d  [     (*
F5     8        e  3  d  =
E5     8        e  3  d  ]     )!
measure 55
D5    72-       h.    d        -
measure 56
D5    24        q     d
rest  12        e
rest   6        s
D5     6        s     d
F5     8        e  3  d  [     (*
E5     8        e  3  d  =
D5     8        e  3  d  ]     )!
measure 57
C5    72-       h.    d        -
measure 58
C5    24        q     d
rest  12        e
rest   6        s
C5     6        s     d
A5     8        e  3  d  [     (*
F5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 59
Bf4   72-       h.    d        -
measure 60
Bf4   24        q     d
rest  12        e
rest   6        s
Bf4    6        s     d
G5     8        e  3  d  [     (*
E5     8        e  3  d  =
Bf4    8        e  3  d  ]     )!
measure 61
A4    24        q     u
rest  24        q
rest  24        q
measure 62
rest  24        q
A5    24        q     d        .p
A5    24        q     d        .
measure 63
F#5   24        q #   d        (
G5    24        q     d        )
rest  24        q
measure 64
rest  24        q
G5    24        q     d        .
G5    24        q     d        .
measure 65
E5    24        q     d        (
F5    24        q n   d        )+
rest  24        q
measure 66
rest  24        q
F5    24        q     d        .
F5    24        q     d        .
measure 67
D5    24        q     d        (
Ef5   24        q f   d        )
rest  24        q
measure 68
rest  24        q
Ef5   24        q f   d        .
Ef5   24        q     d        .
measure 69
C#5   24        q #   d        (
D5    12        e     d        )
rest   6        s
D4     6        s     u
Bf4    8        e  3  u  [     (*
A4     8        e  3  u  =
G4     8        e  3  u  ]     )!
measure 70
D5    72-       h.    d        -
measure 71
D5    48        h     d        (
Bf5   24        q     d
measure 72
A5    24        q     d
G5    24        q     d
F5    24        q     d        )
measure 73
F5    12        e     d  [     (
E5    12        e     d  =     )
G5    12        e     d  =     (
E5    12        e     d  =     )
F5    12        e     d  =     (
D5    12        e     d  ]     )
measure 74
C5    24        q     d        f
rest  12        e
rest   6        s
F5     6        s     d
A5     8        e  3  d  [     (*
F5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 75
A4    24        q     u
rest  24        q
C5    24        q     d
measure 76
Bf4   24        q     d
rest  12        e
rest   6        s
E5     6        s     d
G5     8        e  3  d  [     (*
E5     8        e  3  d  =
Bf4    8        e  3  d  ]     )!
measure 77
G4    24        q     u
rest  24        q
Bf4   24        q     d
measure 78
A4    24        q     u
rest  12        e
rest   6        s
A4     6        s     u
C5     8        e  3  u  [     (*
A4     8        e  3  u  =
F4     8        e  3  u  ]     )!
measure 79
F5    72-       h.    d        -
measure 80
F5    72-       h.    d        -
measure 81
F5    72-       h.    d        -
measure 82
F5    24        q     d
rest  12        e
rest   6        s
F5     6        s     d
D5     8        e  3  d  [     (*
Bf4    8        e  3  d  =
G4     8        e  3  d  ]     )!
measure 83
F4    48        h     u        (
gA4    5        s     u
S C1:t25
G4    24        q     u        )
measure 84
F4    24        q     u
rest  24        q
rest  24        q
measure 85
rest  72
measure 86
F5    72-       h.    d        -&0p
measure 87
F5    24        q     d
gEf5   5        s f   u
S C1:t25
D5    24        q     d
gC5    5        s     u
S C1:t25
Bf4   24        q     d
measure 88
Bf4   72        h.    d        (
measure 89
A4    24        q     u        )
rest  24        q
rest  24        q
measure 90
Ef5   72-       h.f   d        -
measure 91
Ef5   24        q     d
gD5    5        s     u
S C1:t25
C5    24        q     d
gBf4   5        s     u
S C1:t25
A4    24        q     u
measure 92
C5    72        h.    d        (
measure 93
Bf4   24        q     d        )
rest  24        q
rest  24        q
measure 94
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-3
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 95
F5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
E5     3        t n   d  =[[   +
F5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 96
C5    48-       h     d        -(
C5    12        e     d  [
D5     6        s     d  =[
Ef5    6        s f   d  ]]     )
measure 97
D5    24        q     d
rest  24        q
rest  24        q
measure 98
D5    18        e.    d  [     (t
S C33:n6s17t84
C5     3        t     d  =[[
D5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 99
C5    18        e.    d  [     (t
S C33:n6s17t84
Bf4    3        t     d  =[[
C5     3        t     d  ]]]   )
rest  24        q
rest  24        q
measure 100
G4    48-       h     u        -(
G4    12        e     u  [
A4     6        s     u  =[
Bf4    6        s     u  ]]     )
measure 101
A4    24        q     u
rest  24        q
rest  24        q
measure 102
F#4   12        e #   u  [     (
G4    12        e     u  =
A4    12        e     u  =
G4    12        e     u  =
C5    12        e     u  =
Bf4   12        e     u  ]     )
measure 103
D5    24        q     d        (
D4    24        q     u
G4    24        q     u        )
measure 104
F4    72        h.n   u        (+
measure 105
E4    24        q     u        )
rest  24        q
rest  24        q
measure 106
rest  24        q
C6    24        q     d        .p
C6    24        q     d        .
measure 107
A5    24        q     d        (
Bf5   24        q     d        )
rest  24        q
measure 108
rest  24        q
Bf5   24        q     d        .
Bf5   24        q     d        .
measure 109
G5    24        q     d        (
A5    12        e     d        )
rest   6        s
A5     6        s     d        .f
C6     8        e  3  d  [     (*
A5     8        e  3  d  =
F5     8        e  3  d  ]     )!
measure 110
Ef6   48        h f   d
Ef5   24        q f   d
measure 111
D5    24        q     d
rest  12        e
rest   6        s
D5     6        s     d
Bf5    8        e  3  d  [     (*
G5     8        e  3  d  =
D5     8        e  3  d  ]     )!
measure 112
D6    24        q     d        (
A5    24        q     d
Bf5   24        q     d        )
measure 113
F#5   12        e #   d  [     (
G5    12        e     d  =     )
A5    12        e     d  =     (
G5    12        e     d  =
Bf5   12        e     d  =
G5    12        e     d  ]     )
measure 114
F5    48        h n   d        (+
gA5    5        s     u
S C1:t25
G5    24        q     d        )
measure 115
F5    12        e     d
rest  12        e
C5    12        e     d        p
rest  12        e
C5    12        e     d
rest  12        e
measure 116
C5    12        e     d
rest  12        e
C5    12        e     d
rest  12        e
C5    12        e     d
rest  12        e
measure 117
C5    24        q     d
rest  12        e
rest   6        s
A4     6        s     u
C5     8        e  3  d  [     (*
Bf4    8        e  3  d  =
A4     8        e  3  d  ]     )!
measure 118
G4    24        q     u
rest  12        e
rest   6        s
G4     6        s     u
Bf4    8        e  3  u  [     (*
A4     8        e  3  u  =
G4     8        e  3  u  ]     )!
measure 119
F4    24        q     u
rest  12        e
rest   6        s
F5     6        s     d        f
A5     8        e  3  d  [     (*
F5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 120
A4    24        q     u
rest  24        q
C5    24        q     d
measure 121
Bf4   24        q     d
rest  12        e
rest   6        s
E5     6        s     d
G5     8        e  3  d  [     (*
E5     8        e  3  d  =
C5     8        e  3  d  ]     )!
measure 122
G4    24        q     u
rest  24        q
Bf4   24        q     d
measure 123
A4    24        q     u
rest  24        q
A4    24        q     u        (
measure 124
Bf4   24        q     d        )
rest  24        q
C5    24        q     d        (
measure 125
D5    24        q     d        )
rest  12        e
rest   6        s
C#5    6        s #   d        p
D5     8        e  3  d  [     (*
Bf4    8        e  3  d  =
G4     8        e  3  d  ]     )!
measure 126
F4    48        h     u        (
gA4    5        s     u
S C1:t25
G4    24        q     u        )
measure 127
F4    24        q     u
rest  12        e
rest   6        s
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/01/02} [KHM:4076231775]
TIMESTAMP: DEC/26/2001 [md5sum:3668204ff997b3b54fa00866651b447e]
03/26/94 E. Correia
WK#:158       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-1   Q:12   T:3/4  C:4  D:Presto
rest   3        s
rest  12        q
measure 1
rest  12        q
rest  12        q
A4    12        q     u        f
measure 2
G4    12        q     u
rest  12        q
rest  12        q
measure 3
rest  12        q
rest  12        q
G4    12        q     u
measure 4
F4    12        q     u
rest  12        q
rest  12        q
measure 5
rest  12        q
rest   6        e
rest   3        s
A4     3        s     u
C5     4        e  3  u  [     (*
A4     4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 6
Ef5   12        q f   d
rest   6        e
rest   3        s
C5     3        s     d
Ef5    4        e  3  d  [     (*
C5     4        e  3  d  =
F4     4        e  3  d  ]     )!
measure 7
D5    12        q     d
rest   6        e
rest   3        s
F4     3        s     u
D5     4        e  3  u  [     (*
Bf4    4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 8
D4    12        q     u
rest  12        q
rest  12        q
measure 9
rest  12        q
C4    12        q     u        (
Bf3   12        q     u        )
measure 10
A3    12        q     u
rest   6        e
rest   3        s
F4     3        s     u
A4     4        e  3  u  [     (*
F4     4        e  3  u  =
D4     4        e  3  u  ]     )!
measure 11
B3    12        q n   u
rest  12        q
rest  12        q
measure 12
C4     6        e     u  [     (&0p
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  ]     )
measure 13
C4     6        e     u  [     (
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  ]     )
measure 14
G3     6        e     u  [     (
F4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  ]     )
measure 15
G3     6        e     u  [     (
F4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  ]     )
measure 16
B3     6        e n   u  [     (
D4     6        e     u  =
G4     6        e     u  =
D4     6        e     u  =
G4     6        e     u  =
D4     6        e     u  ]     )
measure 17
G3     6        e     u  [     (
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  ]     )
measure 18
B3     6        e n   u  [     (
D4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  ]     )
measure 19
E4     6        e     u  [     (
G4     6        e     u  =
C5     6        e     u  =
G4     6        e     u  =
E4     6        e     u  =
C4     6        e     u  ]     )
measure 20
C4     6        e     u  [     (
F4     6        e     u  =
A4     6        e     u  =
F4     6        e     u  =     )
C5     6        e     u  =     (
A4     6        e     u  ]     )
measure 21
C4     6        e     u  [     (
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  =     )
C5     6        e     u  =     (
G4     6        e     u  ]     )
measure 22
F4     6        e     u  [     (
G4     6        e     u  =     )
D4     6        e     u  =     (
G4     6        e     u  =     )
G3     6        e     u  =     (
G4     6        e     u  ]     )
measure 23
G3     6        e     u  [     (
C4     6        e     u  =
E4     6        e     u  =
C4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  ]     )
measure 24
C4     6        e     u  [     (
F4     6        e     u  =     )
A4     6        e     u  =     (
C5     6        e     u  =     )
C4     6        e     u  =     (
C5     6        e     u  ]     )
measure 25
C4     6        e     u  [     (
E4     6        e     u  =     )
G4     6        e     u  =     (
E4     6        e     u  =     )
C5     6        e     u  =     (
G4     6        e     u  ]     )
measure 26
F4     6        e     u  [     (
G4     6        e     u  =     )
D4     6        e     u  =     (
G4     6        e     u  =     )
G3     6        e     u  =     (
G4     6        e     u  ]     )
measure 27
C4     6        e     u  [     (
E4     6        e     u  =
G4     6        e     u  =
E4     6        e     u  =
C5     6        e     u  =
G4     6        e     u  ]     )
measure 28
A4    12        q     u
rest  12        q
rest  12        q
measure 29
rest  12        q
F4    12        q     u        (
A4     6        e     u  [
F4     6        e     u  ]     )
measure 30
E4    36        h.    u        (
measure 31
D4    12        q     u        )
rest  12        q
rest  12        q
measure 32
rest  12        q
E4    12        q     u        .p
E4    12        q     u        .
measure 33
C#4   12        q #   u        (
D4    12        q     u        )
rest  12        q
measure 34
rest  12        q
D4    12        q     u        .
D4    12        q     u        .
measure 35
B3    12        q n   u        (
C4    12        q n   u        )+
rest  12        q
measure 36
rest  12        q
C4    12        q     u        f
P C32:y5
C4    12        q     u
measure 37
C4    12        q     u
rest  12        q
rest  12        q
measure 38
rest  36
measure 39
rest  36
measure 40
rest  12        q
G4    12        q     u        (
B3    12        q n   u        )
measure 41
C4    12        q     u
rest   6        e
rest   3        s
C5     3        s     d        p
E5     4        e  3  d  [     (*
D5     4        e  3  d  =
C5     4        e  3  d  ]     )!
measure 42
B4    12        q n   d
rest   6        e
rest   3        s
D5     3        s     d
F5     4        e  3  d  [     (*
E5     4        e  3  d  =
D5     4        e  3  d  ]     )!
measure 43
E5    12        q     d
rest   6        e
rest   3        s
C4     3        s     u
E4     4        e  3  u  [     (*
D4     4        e  3  u  =
C4     4        e  3  u  ]     )!
measure 44
B3    12        q n   u
rest   6        e
rest   3        s
B3     3        s     u
D4     4        e  3  u  [     (*
C4     4        e  3  u  =
B3     4        e  3  u  ]     )!
measure 45
C4    12        q     u
rest   6        e
rest   3        s
mheavy4         :|:
rest   3        s
rest  12        q
measure 46
C4     6        e     u        .f
rest   6        e
E4     6        e     u        .p
rest   6        e
G4     6        e     u        .
rest   6        e
measure 47
Af4    6        e f   u        &1.
rest   6        e
F4     6        e     u        &1.
rest   6        e
rest  12        q
measure 48
C5     6        e     d        .f
rest   6        e
Af4    6        e f   u        .p
rest   6        e
F4     6        e     u        .
rest   6        e
measure 49
E4     6        e     u        &1.
rest   6        e
G4     6        e     u        &1.
rest   6        e
rest  12        q
measure 50
C4     6        e     u        .f
rest   6        e
E4     6        e     u        .p
rest   6        e
G4     6        e     u        .
rest   6        e
measure 51
Af4    6        e f   u        .
rest   6        e
E4     6        e     u        .
rest   6        e
F4     6        e     u        .
rest   6        e
measure 52
Df4    6        e f   u        &1.
rest   6        e
C4     6        e     u        &1.
rest   6        e
B3     6        e n   u        &1.
rest   6        e
measure 53
C4    12        q     u
rest   6        e
rest   3        s
C4     3        s     u        f
P C32:y5
G4     4        e  3  u  [     (*
E4     4        e  3  u  =
C4     4        e  3  u  ]     )!
measure 54
C5    36-       h.    d        -
measure 55
C5    12        q     d
rest   6        e
rest   3        s
A4     3        s     u
C5     4        e  3  d  [     (*
Bf4    4        e  3  d  =
A4     4        e  3  d  ]     )!
measure 56
Bf4   36-       h.    d        -
measure 57
Bf4   12        q     d
rest   6        e
rest   3        s
G4     3        s     u
Bf4    4        e  3  u  [     (*
A4     4        e  3  u  =
G4     4        e  3  u  ]     )!
measure 58
A4    36-       h.    u        -
measure 59
A4    12        q     u
rest   6        e
rest   3        s
F4     3        s     u
A4     4        e  3  u  [     (*
G4     4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 60
G4    36-       h.    u        -
measure 61
G4    12        q     u
rest  12        q
rest  12        q
measure 62
rest  12        q
F4    12        q     u        .p
F4    12        q     u        .
measure 63
D#4   12        q #   u        (
E4    12        q     u        )
rest  12        q
measure 64
rest  12        q
E4    12        q     u        .
E4    12        q     u        .
measure 65
C#4   12        q #   u        (
D4    12        q n   u        )+
rest  12        q
measure 66
rest  12        q
D4    12        q     u        .
D4    12        q     u        .
measure 67
B3    12        q n   u        (
C4    12        q n   u        )+
rest  12        q
measure 68
rest  12        q
C4    12        q     u        .
C4    12        q     u        .
measure 69
A3    12        q     u        (
Bf3   12        q f   u        )+
rest  12        q
measure 70
rest  12        q
rest   6        e
rest   3        s
G4     3        s     u
C5     4        e  3  d  [     (*
D5     4        e  3  d  =
C5     4        e  3  d  ]     )!
measure 71
Bf4   24        h     d        (
D5    12        q     d
measure 72
C5    12        q     d
Bf4   12        q     d
A4    12        q     u        )
measure 73
A4     6        e     u  [     (
G4     6        e     u  =     )
E4     6        e     u  =     (
G4     6        e     u  =     )
A4     6        e     u  =     (
F4     6        e     u  ]     )
measure 74
E4    12        q     u
rest  12        q
rest  12        q
measure 75
rest  12        q
rest  12        q
A4    12        q     u        f
measure 76
G4    12        q     u
rest  12        q
rest  12        q
measure 77
rest  12        q
rest  12        q
G4    12        q     u
measure 78
F4    12        q     u
rest  12        q
rest  12        q
measure 79
rest  12        q
rest   6        e
rest   3        s
A4     3        s     u
C5     4        e  3  u  [     (*
A4     4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 80
Ef5   12        q f   d
rest   6        e
rest   3        s
C5     3        s     d
Ef5    4        e  3  d  [     (*
C5     4        e  3  d  =
F4     4        e  3  d  ]     )!
measure 81
D5    12        q     d
rest   6        e
rest   3        s
Bf4    3        s     d
D5     4        e  3  u  [     (*
Bf4    4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 82
D4    12        q     u
rest  12        q
rest  12        q
measure 83
rest  12        q
C4    12        q     u        (
Bf3   12        q     u        )
measure 84
A3    12        q     u
rest   6        e
rest   3        s
F4     3        s     u
Ef4    4        e f3  u  [     (*
F4     4        e  3  u  =
G4     4        e  3  u  ]     )!
measure 85
A3    12        q     u
rest  12        q
rest  12        q
measure 86
Bf3    6        e     u  [     (&0p
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  ]     )
measure 87
Bf3    6        e     u  [     (
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  ]     )
measure 88
Ef4    6        e f   u  [     (
F4     6        e     u  =
Ef4    6        e     u  =
F4     6        e     u  =
Ef4    6        e     u  =
D4     6        e     u  ]     )
measure 89
C4     6        e     u  [     (
D4     6        e     u  =
Ef4    6        e f   u  =
D4     6        e     u  =
C4     6        e     u  =
Bf3    6        e     u  ]     )
measure 90
A3     6        e     u  [     (
C4     6        e     u  =
F4     6        e     u  =
C4     6        e     u  =
F4     6        e     u  =
C4     6        e     u  ]     )
measure 91
A3     6        e     u  [     (
C4     6        e     u  =
F4     6        e     u  =
C4     6        e     u  =
F4     6        e     u  =
Ef4    6        e f   u  ]     )
measure 92
A3     6        e     u  [     (
C4     6        e     u  =
F4     6        e     u  =
Ef4    6        e f   u  =
F4     6        e     u  =
Ef4    6        e     u  ]     )
measure 93
D4     6        e     u  [     (
F4     6        e     u  =     )
Bf4    6        e     u  =     (
F4     6        e     u  =     )
D4     6        e     u  =     (
Bf3    6        e     u  ]     )
measure 94
Ef4    6        e f   u  [     (
G4     6        e     u  =
Bf4    6        e     u  =
G4     6        e     u  =
F4     6        e     u  =
Ef4    6        e     u  ]     )
measure 95
D4     6        e     u  [     (
F4     6        e     u  =
Bf4    6        e     u  =
F4     6        e     u  =
D4     6        e     u  =
Bf3    6        e     u  ]     )
measure 96
A3     6        e     u  [     (
C4     6        e     u  =
F4     6        e     u  =
C4     6        e     u  =
A3     6        e     u  =
C4     6        e     u  ]     )
measure 97
Bf3    6        e     u  [     (
D4     6        e     u  =
F4     6        e     u  =
D4     6        e     u  =
Bf4    6        e     u  =
F4     6        e     u  ]     )
measure 98
D4     6        e     u  [     (
F4     6        e     u  =     )
Bf4    6        e     u  =     (
F4     6        e     u  =     )
D4     6        e     u  =     (
Bf3    6        e     u  ]     )
measure 99
A3     6        e     u  [     (
C4     6        e     u  =
F4     6        e     u  =
C4     6        e     u  =     )
A4     6        e     u  =     (
F4     6        e     u  ]     )
measure 100
E4     6        e n   u  [     (+
C4     6        e     u  =
E4     6        e     u  =
C4     6        e     u  =
E4     6        e     u  =
G4     6        e     u  ]     )
measure 101
F4     6        e     u  [     (
G4     6        e     u  =
A4     6        e     u  =
G4     6        e     u  =
F4     6        e     u  =
E4     6        e     u  ]     )
measure 102
D4    12        q     u
rest  12        q
rest  12        q
measure 103
rest  12        q
G3    12        q     u        (
Bf3   12        q     u        )
measure 104
A3    36        h.    u        (
measure 105
G3    12        q     u        )
rest  12        q
rest  12        q
measure 106
rest  12        q
A4    12        q     u        .p
A4    12        q     u        .
measure 107
F#4   12        q #   u        (
G4    12        q     u        )
rest  12        q
measure 108
rest  12        q
G4    12        q     u        .
G4    12        q     u        .
measure 109
E4    12        q     u        (
F4    12        q n   u        )+
rest  12        q
measure 110
rest  12        q
C5    12        q     d        f
C5    12        q     d
measure 111
Bf4   12        q     d
rest  12        q
rest  12        q
measure 112
rest  36
measure 113
rest  36
measure 114
rest  12        q
A4    12        q     u        (
E4    12        q     u        )
measure 115
F4    12        q     u
rest   6        e
rest   3        s
F4     3        s     u        p
A4     4        e  3  u  [     (*
G4     4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 116
E4    12        q     u
rest   6        e
rest   3        s
G4     3        s     u
Bf4    4        e  3  u  [     (*
A4     4        e  3  u  =
G4     4        e  3  u  ]     )!
measure 117
A4    12        q     u
rest   6        e
rest   3        s
F4     3        s     u
A4     4        e  3  u  [     (*
G4     4        e  3  u  =
F4     4        e  3  u  ]     )!
measure 118
E4    12        q     u
rest   6        e
rest   3        s
E4     3        s     u
G4     4        e  3  u  [     (*
F4     4        e  3  u  =
E4     4        e  3  u  ]     )!
measure 119
F4    12        q     u
 A3   12        q     u
rest  12        q
rest  12        q
measure 120
rest  12        q
rest  12        q
A4    12        q     u        f
measure 121
G4    12        q     u
rest  12        q
rest  12        q
measure 122
rest  12        q
rest  12        q
G4    12        q     u
measure 123
F4    12        q     u
rest  12        q
A3    12        q     u        (
measure 124
Bf3   12        q     u        )
rest  12        q
C4    12        q     u        (
measure 125
D4    12        q     u        )
rest  12        q
rest  12        q
measure 126
rest  12        q
C4    12        q     u        (p
P C33:y5
Bf3   12        q     u        )
measure 127
A3    12        q     u
rest   6        e
rest   3        s
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/01/03} [KHM:4076231775]
TIMESTAMP: DEC/26/2001 [md5sum:2395dd9d847089168c33137032913492]
03/28/94 E. Correia
WK#:158       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-1   Q:12   T:3/4  C:13  D:Allegro
rest   3        s
rest  12        q
measure 1
rest  12        q
rest  12        q
D4    12        q     d        f
measure 2
D4    12        q     d
rest  12        q
rest  12        q
measure 3
rest  12        q
rest  12        q
C4    12        q     d
measure 4
C4    12        q     d
rest  12        q
rest  12        q
measure 5
rest  12        q
C4    12        q     d
A3    12        q     u
measure 6
rest  12        q
C4    12        q     d
F4    12        q     d
measure 7
rest  12        q
D4    12        q     d
Bf3   12        q     u
measure 8
rest  12        q
D4    12        q     d
Bf3   12        q     u
measure 9
rest  12        q
A3    12        q     u        (
E3    12        q     u        )
measure 10
F3    12        q     u
rest   6        e
rest   3        s
F4     3        s     d
A4     4        e  3  d  [     (*
F4     4        e  3  d  =
D4     4        e  3  d  ]     )!
measure 11
B3    12        q n   u
rest  12        q
rest  12        q
measure 12
rest  12        q
G3    12        q     u        &0p
G3    12        q     u
measure 13
rest  12        q
G3    12        q     u
G3    12        q     u
measure 14
rest  12        q
G3    12        q     u
G3    12        q     u
measure 15
rest  12        q
G3    12        q     u
G3    12        q     u
measure 16
rest  12        q
G3    12        q     u
G3    12        q     u
measure 17
rest  12        q
G3    12        q     u
G3    12        q     u
measure 18
rest  12        q
B3    12        q n   u
B3    12        q     u
measure 19
rest  12        q
C4    12        q     d
C3    12        q     u
measure 20
rest  12        q
F4     6        e     d  [     (
C4     6        e     d  =     )
A4     6        e     d  =     (
F4     6        e     d  ]     )
measure 21
rest  12        q
E4     6        e     d  [     (
C4     6        e     d  =     )
G4     6        e     d  =     (
E4     6        e     d  ]     )
measure 22
D4    12        q     d        (
B3    12        q n   u        )
gG4    5        s     u
S C1:t50
F4     6        e     d  [     (
E4     3        s     d  =[
D4     3        s     d  ]]    )
measure 23
C4    12        q     d
rest  12        q
rest  12        q
measure 24
rest  12        q
F4     6        e     d  [     (
A4     6        e     d  =     )
F4     6        e     d  =     (
A4     6        e     d  ]     )
measure 25
rest  12        q
E4     6        e     d  [     (
C4     6        e     d  =     )
G4     6        e     d  =     (
E4     6        e     d  ]     )
measure 26
D4    12        q     d        (
B3    12        q n   u        )
gG4    5        s     u
S C1:t50
F4     6        e     d  [     (
E4     3        s     d  =[
D4     3        s     d  ]]    )
measure 27
C4    12        q     d
rest  12        q
rest  12        q
measure 28
F4    12        q     d
rest  12        q
rest  12        q
measure 29
rest  12        q
A3    12        q     u
F4    12        q     d
measure 30
G4    36-       h.    d        -
measure 31
G4    12        q     d
rest   6        e
rest   3        s
G4     3        s     d        &0f
A4     4        e  3  d  [     (*
F#4    4        e #3  d  =
G4     4        e  3  d  ]     )!
measure 32
G3    12        q     u
rest  12        q
rest  12        q
measure 33
rest  12        q
rest   6        e
rest   3        s
G4     3        s     d
A4     4        e  3  d  [     (*
F#4    4        e #3  d  =
G4     4        e  3  d  ]     )!
measure 34
G3    12        q     u
rest  12        q
rest  12        q
measure 35
rest  36
measure 36
rest  12        q
G3    12        q     u
G3    12        q     u
measure 37
F3    12        q     u
rest  12        q
rest  12        q
measure 38
rest  36
measure 39
rest  36
measure 40
E4    24        h     d        (
gG4    5        s     u
S C1:t25
F4    12        q     d        )
measure 41
E4    12        q     d
rest   6        e
rest   3        s
E4     3        s     d        p
G4     4        e  3  d  [     (*
F4     4        e  3  d  =
E4     4        e  3  d  ]     )!
measure 42
D4    12        q     d
rest   6        e
rest   3        s
B4     3        s n   d
D5     4        e  3  d  [     (*
C5     4        e  3  d  =
B4     4        e  3  d  ]     )!
measure 43
C5     6        e     d
rest   6        e
G4     6        e     d
rest   6        e
G4     6        e     d
rest   6        e
measure 44
G4     6        e     d
rest   6        e
G4     6        e     d
rest   6        e
G4     6        e     d
rest   6        e
measure 45
E4    12        q     u
 G3   12        q     u
rest   6        e
rest   3        s
mheavy4         :|:
rest   3        s
rest  12        q
measure 46
C4     6        e     d        .f
P C33:y5
rest   6        e
E4     6        e     d        .p
rest   6        e
G4     6        e     d        .
rest   6        e
measure 47
Af4    6        e f   d        .
rest   6        e
F4     6        e     d        .
rest   6        e
rest  12        q
measure 48
C5     6        e     d        .f
rest   6        e
Af4    6        e f   d        .p
rest   6        e
F4     6        e     d        .
rest   6        e
measure 49
E4     6        e     d        .
rest   6        e
G4     6        e     d        .
rest   6        e
rest  12        q
measure 50
C4     6        e     d        .f
P C33:y5
rest   6        e
E4     6        e     d        .p
rest   6        e
G4     6        e     d        .
rest   6        e
measure 51
Af4    6        e f   d        .
rest   6        e
E4     6        e     d        .
rest   6        e
F4     6        e     d        .
rest   6        e
measure 52
Df4    6        e f   d        &1.
rest   6        e
C4     6        e     d        &1.
rest   6        e
B3     6        e n   u        &1.
rest   6        e
measure 53
C4    12        q     d
rest  12        q
rest  12        q
measure 54
G4    36        h.    d        f
measure 55
A4    12        q     d
F#4   12        q #   d
D4    12        q     d
measure 56
G4    36-       h.    d        -
measure 57
G4    12        q     d
E4    12        q     d
C4    12        q     d
measure 58
F4    36-       h.n   d        -+
measure 59
F4    12        q     d
D4    12        q     d
Bf3   12        q     u
measure 60
E4    36-       h.    d        -
measure 61
E4    12        q     d
rest   6        e
rest   3        s
A4     3        s     d        .
Bf4    4        e  3  d  [     (*
G#4    4        e #3  d  =
A4     4        e  3  d  ]     )!
measure 62
A3    12        q     u
rest  12        q
rest  12        q
measure 63
rest  12        q
rest   6        e
rest   3        s
A4     3        s     d        .
Bf4    4        e  3  d  [     (*
G#4    4        e #3  d  =
A4     4        e  3  d  ]     )!
measure 64
A3    12        q     u
rest  12        q
rest  12        q
measure 65
rest  12        q
rest   6        e
rest   3        s
D4     3        s     d        &1.
E4     4        e  3  d  [     (*
C#4    4        e #3  d  =
D4     4        e  3  d  ]     )!
measure 66
D3    12        q     u
rest  12        q
rest  12        q
measure 67
rest  12        q
rest   6        e
rest   3        s
F4     3        s     d        &1.
G4     4        e n3  d  [     (*+
E4     4        e  3  d  =
F4     4        e  3  d  ]     )!
measure 68
F3    12        q     u
rest  12        q
rest  12        q
measure 69
rest  36
measure 70
rest  12        q
rest   6        e
rest   3        s
D4     3        s     d        &0p
F#4   12        q #   d
measure 71
G4    12        q     d
D4    12        q     d
rest  12        q
measure 72
rest  12        q
D4    12        q     d
D4    12        q     d
measure 73
C4    12        q     d
C4    12        q     d
C4    12        q     d
measure 74
G3    12        q     u
rest  12        q
rest  12        q
measure 75
rest  12        q
rest  12        q
D4    12        q     d        f
measure 76
D4    12        q     d
rest  12        q
rest  12        q
measure 77
rest  12        q
rest  12        q
C4    12        q     d
measure 78
C4    12        q     d
rest  12        q
rest  12        q
measure 79
rest  12        q
C4    12        q     d
A3    12        q     u
measure 80
rest  12        q
C4    12        q     d
F4    12        q     d
measure 81
rest  12        q
D4    12        q     d
Bf3   12        q     u
measure 82
rest  12        q
D4    12        q     d
Bf3   12        q     u
measure 83
rest  12        q
A3    12        q     u        (
E3    12        q     u        )
measure 84
F3    12        q     u
rest   6        e
rest   3        s
F4     3        s     d
Ef4    4        e f3  d  [     (*
F4     4        e  3  d  =
G4     4        e  3  d  ]     )!
measure 85
A3    12        q     u
rest  12        q
rest  12        q
measure 86
rest  12        q
F3    12        q     u        &0p
F3    12        q     u
measure 87
rest  12        q
F3    12        q     u
F3    12        q     u
measure 88
rest  12        q
F3    12        q     u
F3    12        q     u
measure 89
rest  12        q
F3    12        q     u
F3    12        q     u
measure 90
rest  12        q
F3    12        q     u
F3    12        q     u
measure 91
rest  12        q
F3    12        q     u
F3    12        q     u
measure 92
rest  12        q
A3    12        q     u
A3    12        q     u
measure 93
rest  12        q
Bf3   12        q     u
Bf3   12        q     u
measure 94
rest  12        q
G4     6        e     d  [     (
Ef4    6        e f   d  =     )
D4     6        e     d  =     (
Ef4    6        e     d  ]     )
measure 95
rest  12        q
F4     6        e     d  [     (
D4     6        e     d  =     )
Bf3    6        e     d  =     (
F3     6        e     d  ]     )
measure 96
Ef4   12        q f   d        (
C4    12        q     d
F3    12        q     u        )
measure 97
F3     6        e     d  [     (
Bf3    6        e     d  =     )
D4     6        e     d  =     (
Bf3    6        e     d  =
F4     6        e     d  =
D4     6        e     d  ]     )
measure 98
rest  12        q
F4     6        e     d  [     (
D4     6        e     d  =     )
Bf3    6        e     d  =     (
F3     6        e     d  ]     )
measure 99
rest  12        q
A3     6        e     u  [     (
F3     6        e     u  =     )
C4     6        e     u  =     (
A3     6        e     u  ]     )
measure 100
Bf3   12        q     u        (
G3    12        q     u
C4    12        q     d        )
measure 101
C4    12        q     d
rest  12        q
rest  12        q
measure 102
Bf3   12        q     u
rest  12        q
rest  12        q
measure 103
rest  12        q
G3    12        q     u        (
D3    12        q     u        )
measure 104
C3    12        q     u
C3    12        q     u
C3    12        q     u
measure 105
C3    12        q     u
rest   6        e
rest   3        s
C5     3        s     d        .&0f
D5     4        e  3  d  [     (*
B4     4        e n3  d  =
C5     4        e  3  d  ]     )!
measure 106
C4    12        q     d
rest  12        q
rest  12        q
measure 107
rest  12        q
rest   6        e
rest   3        s
C4     3        s     d        &1.
D4     4        e  3  d  [     (*
B3     4        e n3  d  =
C4     4        e  3  d  ]     )!
measure 108
C3    12        q     u
rest  12        q
rest  12        q
measure 109
rest  36
measure 110
rest  12        q
F4    12        q     d
F4    12        q     d
measure 111
F4    12        q     d
rest  12        q
rest  12        q
measure 112
rest  36
measure 113
rest  36
measure 114
rest  12        q
C4    12        q     d        (
Bf3   12        q f   u        )+
measure 115
A3    12        q     u
rest   6        e
rest   3        s
A3     3        s     u        p
C4     4        e  3  u  [     (*
Bf3    4        e  3  u  =
A3     4        e  3  u  ]     )!
measure 116
G3    12        q     u
rest   6        e
rest   3        s
E4     3        s     d
G4     4        e  3  d  [     (*
F4     4        e  3  d  =
E4     4        e  3  d  ]     )!
measure 117
F4     6        e     d
rest   6        e
C4     6        e     d
rest   6        e
C4     6        e     d
rest   6        e
measure 118
C4     6        e     d
rest   6        e
C4     6        e     d
rest   6        e
C4     6        e     d
rest   6        e
measure 119
C4    12        q     d
rest  12        q
rest  12        q
measure 120
rest  12        q
rest  12        q
F#4   12        q #   d        f
measure 121
D4    12        q     d
rest  12        q
rest  12        q
measure 122
rest  12        q
rest  12        q
E4    12        q     d
measure 123
C4    12        q     d
rest  12        q
F#3   12        q #   u        (
measure 124
G3    12        q     u        )
rest  12        q
A3    12        q     u        (
measure 125
Bf3   12        q     u        )
rest  12        q
rest  12        q
measure 126
rest  12        q
A3    12        q     u        (p
P C33:y5
E3    12        q     u        )
measure 127
F3    12        q n   u        +
rest   6        e
rest   3        s
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/01/04} [KHM:4076231775]
TIMESTAMP: DEC/26/2001 [md5sum:29977ba6bd4613f6976f3d427617ff34]
03/28/94 E. Correia
WK#:158       MV#:1
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-1   Q:12   T:3/4  C:22  D:Allegro
rest   3        s
rest  12        q
measure 1
rest  12        q
rest  12        q
F#3   12        q #   d        f
measure 2
G3    12        q     d
rest  12        q
rest  12        q
measure 3
rest  12        q
rest  12        q
E3    12        q     d
measure 4
F3    12        q n   d        +
rest  12        q
rest  12        q
measure 5
rest  12        q
F3    12        q     d
F3    12        q     d
measure 6
rest  12        q
A3    12        q     d
A3    12        q     d
measure 7
rest  12        q
Bf3   12        q     d
Bf3   12        q     d
measure 8
rest  12        q
Bf2   12        q     u
Bf2   12        q     u
measure 9
rest  12        q
C3    12        q     u
C3    12        q     u
measure 10
F3    12        q     d
rest   6        e
rest   3        s
F3     3        s     d
A3     4        e  3  d  [     (*
F3     4        e  3  d  =
D3     4        e  3  d  ]     )!
measure 11
B2    12        q n   u
rest  12        q
rest  12        q
measure 12
C3    12        q     u        &0p
rest  12        q
rest  12        q
measure 13
C3    12        q     u
rest  12        q
rest  12        q
measure 14
D3    12        q     d
rest  12        q
rest  12        q
measure 15
D3    12        q     d
rest  12        q
rest  12        q
measure 16
G2    12        q     u
rest  12        q
rest  12        q
measure 17
G2    12        q     u
rest  12        q
rest  12        q
measure 18
C3    12        q     u
rest  12        q
rest  12        q
measure 19
C3    12        q     u
rest  12        q
rest  12        q
measure 20
F3    12        q     d
rest  12        q
rest  12        q
measure 21
E3    12        q     d
rest  12        q
rest  12        q
measure 22
B2    36        h.n   u
measure 23
C3    12        q     u
rest  12        q
rest  12        q
measure 24
F3    12        q     d
rest  12        q
rest  12        q
measure 25
E3    12        q     d
rest  12        q
rest  12        q
measure 26
B2    36        h.n   u        (
measure 27
C3    12        q     u        )
rest  12        q
rest  12        q
measure 28
F3    12        q     d
rest  12        q
rest  12        q
measure 29
rest  12        q
D3    12        q     d        (
F3    12        q     d        )
measure 30
G3    12        q     d
G3    12        q     d
G3    12        q     d
measure 31
G2    12        q     u
rest   6        e
rest   3        s
G3     3        s     d        &0f
A3     4        e  3  d  [     (*
F#3    4        e #3  d  =
G3     4        e  3  d  ]     )!
measure 32
G2    12        q     u
rest  12        q
rest  12        q
measure 33
rest  12        q
rest   6        e
rest   3        s
G3     3        s     d
A3     4        e  3  d  [     (*
F#3    4        e #3  d  =
G3     4        e  3  d  ]     )!
measure 34
G2    12        q     u
rest  12        q
rest  12        q
measure 35
rest  36
measure 36
rest  12        q
E3    12        q     d
E3    12        q     d
measure 37
F3    12        q     d
rest  12        q
rest  12        q
measure 38
rest  36
measure 39
rest  36
measure 40
rest  12        q
G3    12        q     d
G2    12        q     u
measure 41
C3    12        q     u
rest  12        q
rest  12        q
measure 42
G3    12        q     d        p
rest  12        q
rest  12        q
measure 43
C4    12        q     d
rest  12        q
rest  12        q
measure 44
G3    12        q     d
rest  12        q
rest  12        q
measure 45
C3    12        q     u
rest   6        e
rest   3        s
mheavy4         :|:
rest   3        s
rest  12        q
measure 46
C3     6        e     u        .f
rest   6        e
E3     6        e     d        .p
rest   6        e
G3     6        e     d        .
rest   6        e
measure 47
Af3    6        e f   d        .
rest   6        e
F3     6        e     d        .
rest   6        e
rest  12        q
measure 48
C4     6        e     d        .f
rest   6        e
Af3    6        e f   d        .p
rest   6        e
F3     6        e     d        .
rest   6        e
measure 49
E3     6        e     d        .
rest   6        e
G3     6        e     d        .
rest   6        e
rest  12        q
measure 50
C3     6        e     u        .f
rest   6        e
E3     6        e     d        .p
rest   6        e
G3     6        e     d        .
rest   6        e
measure 51
Af3    6        e f   d        .
rest   6        e
E3     6        e     d        .
rest   6        e
F3     6        e     d        .
rest   6        e
measure 52
Df3    6        e f   d        &1.
rest   6        e
C3     6        e     u        &1.
rest   6        e
B2     6        e n   u        &1.
rest   6        e
measure 53
C3    12        q     u
C3    12        q     u
C3    12        q     u        f
measure 54
E3    12        q     d
E3    12        q     d
E3    12        q     d
measure 55
F#3   12        q #   d
D3    12        q     d
F#3   12        q     d
measure 56
G3    12        q     d
G3    12        q     d
F3    12        q n   d        +
measure 57
E3    12        q     d
C3    12        q     u
E3    12        q     d
measure 58
F3    12        q     d
F3    12        q     d
E3    12        q     d
measure 59
D3    12        q     d
Bf2   12        q     u
D3    12        q     d
measure 60
E3    12        q     d
E3    12        q     d
D3    12        q     d
measure 61
C#3   12        q #   u
rest   6        e
rest   3        s
A3     3        s     d        .
Bf3    4        e  3  d  [     (*
G#3    4        e #3  d  =
A3     4        e  3  d  ]     )!
measure 62
A2    12        q     u
rest  12        q
rest  12        q
measure 63
rest  12        q
rest   6        e
rest   3        s
A3     3        s     d        .
Bf3    4        e  3  d  [     (*
G#3    4        e #3  d  =
A3     4        e  3  d  ]     )!
measure 64
A2    12        q     u
rest  12        q
rest  12        q
measure 65
rest  12        q
rest   6        e
rest   3        s
D3     3        s     d        &1.
E3     4        e  3  d  [     (*
C#3    4        e #3  d  =
D3     4        e  3  d  ]     )!
measure 66
D2    12        q     u
rest  12        q
rest  12        q
measure 67
rest  12        q
rest   6        e
rest   3        s
F3     3        s     d        &1.
G3     4        e n3  d  [     (*+
E3     4        e  3  d  =
F3     4        e  3  d  ]     )!
measure 68
F2    12        q     u
rest  12        q
rest  12        q
measure 69
rest  36
measure 70
rest  12        q
Bf3   12        q     d        &0p
A3    12        q     d
measure 71
G3    12        q     d
rest  12        q
rest  12        q
measure 72
rest  12        q
Bf2   12        q     u        (
B2    12        q n   u        )
measure 73
C3    12        q     u
C3    12        q     u
C3    12        q     u
measure 74
C3    12        q     u
rest  12        q
rest  12        q
measure 75
rest  12        q
rest  12        q
F#3   12        q #   d        f
measure 76
G3    12        q     d
rest  12        q
rest  12        q
measure 77
rest  12        q
rest  12        q
E3    12        q     d
measure 78
F3    12        q     d
rest  12        q
rest  12        q
measure 79
rest  12        q
F3    12        q     d
F3    12        q     d
measure 80
rest  12        q
A3    12        q     d
A3    12        q     d
measure 81
rest  12        q
Bf3   12        q     d
Bf3   12        q     d
measure 82
rest  12        q
Bf2   12        q     u
Bf2   12        q     u
measure 83
rest  12        q
C3    12        q     u
C3    12        q     u
measure 84
F2    12        q     u
rest   6        e
rest   3        s
F3     3        s     d
Ef3    4        e f3  d  [     (*
F3     4        e  3  d  =
G3     4        e  3  d  ]     )!
measure 85
A2    12        q     u
rest  12        q
rest  12        q
measure 86
Bf2   12        q     u        &0p
rest  12        q
rest  12        q
measure 87
Bf2   12        q     u
rest  12        q
rest  12        q
measure 88
C3    12        q     u
rest  12        q
rest  12        q
measure 89
C3    12        q     u
rest  12        q
rest  12        q
measure 90
F2    12        q     u
rest  12        q
rest  12        q
measure 91
F2    12        q     u
rest  12        q
rest  12        q
measure 92
Bf2   12        q     u
rest  12        q
rest  12        q
measure 93
Bf2   12        q     u
rest  12        q
rest  12        q
measure 94
Bf2   12        q     u
rest  12        q
rest  12        q
measure 95
Bf2   12        q     u
rest  12        q
rest  12        q
measure 96
F2    36        h.    u        (
measure 97
Bf2   12        q     u        )
rest  12        q
rest  12        q
measure 98
Bf3   12        q     d
rest  12        q
rest  12        q
measure 99
F3    12        q     d
rest  12        q
rest  12        q
measure 100
C3    36        h.    u        (
measure 101
F3    12        q     d        )
rest  12        q
rest  12        q
measure 102
Bf2   12        q     u
rest  12        q
rest  12        q
measure 103
rest  12        q
Bf2   12        q     u        (
G2    12        q     u        )
measure 104
C3    12        q     u
C3    12        q     u
C3    12        q     u
measure 105
C3    12        q     u
rest   6        e
rest   3        s
C4     3        s     d        .&0f
D4     4        e  3  d  [     (*
B3     4        e n3  d  =
C4     4        e  3  d  ]     )!
measure 106
C3    12        q     u
rest  12        q
rest  12        q
measure 107
rest  12        q
rest   6        e
rest   3        s
C3     3        s     u        &1.
D3     4        e  3  u  [     (*
B2     4        e n3  u  =
C3     4        e  3  u  ]     )!
measure 108
C2    12        q     u
rest  12        q
rest  12        q
measure 109
rest  36
measure 110
rest  12        q
A2    12        q     u
A2    12        q     u
measure 111
Bf2   12        q f   u        +
rest  12        q
rest  12        q
measure 112
rest  36
measure 113
rest  36
measure 114
rest  12        q
C4    12        q     d
C3    12        q     u
measure 115
F3    12        q     d
rest  12        q
rest  12        q
measure 116
C3    12        q     u        p
rest  12        q
rest  12        q
measure 117
F3    12        q     d
rest  12        q
rest  12        q
measure 118
C3    12        q     u
rest  12        q
rest  12        q
measure 119
F3    12        q     d
rest  12        q
rest  12        q
measure 120
rest  12        q
rest  12        q
D3    12        q     d        f
P C32:y5
measure 121
G3    12        q     d
rest  12        q
rest  12        q
measure 122
rest  12        q
rest  12        q
C3    12        q     u
measure 123
F3    12        q     d
rest  12        q
F#2   12        q #   u        (
measure 124
G2    12        q     u        )
rest  12        q
A2    12        q     u        (
measure 125
Bf2   12        q     u        )
rest  12        q
rest  12        q
measure 126
rest  12        q
C3    12        q     u        p
C3    12        q     u
measure 127
F2    12        q n   u        +
rest   6        e
rest   3        s
mheavy2         :|
/END
/eof
//
