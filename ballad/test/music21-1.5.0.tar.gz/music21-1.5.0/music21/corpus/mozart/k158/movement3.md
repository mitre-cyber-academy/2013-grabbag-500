&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/03/01} [KHM:1785260819]
TIMESTAMP: DEC/26/2001 [md5sum:04af130d07c9eb14f7f5c0470ea56883]
03/30/94 E. Correia
WK#:158       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 1
1 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:-1   Q:24   T:3/4  C:4  D:Tempo di Minuetto
gG5    5        s     u
S C1:t50
F5    12        e     d  [     (p
E5     6        s     d  =[
D5     6        s     d  ]]    )
measure 1
C5    24        q     d        (
A4    24        q     u
Bf4   24        q     d        )
measure 2
C5    24        q     d
rest  24        q
F5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-3
E5     3        t     d  =[[
F5     3        t     d  ]]]   )
measure 3
A5    24        q     d
rest  24        q
F5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-3
E5     3        t     d  =[[
F5     3        t     d  ]]]   )
measure 4
C5    24        q     d
rest  24        q
gD5    5        s     u
S C1:t50
C5    12        e     d  [     (
Bf4    6        s     d  =[
A4     6        s     d  ]]    )
measure 5
G4    24        q     u        .
G4    24        q     u        (
A4    24        q     u        )
measure 6
Bf4   24        q     d        .
rest  24        q
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
measure 7
Bf5   24        q     d
rest  24        q
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
measure 8
E5    24        q     d
rest  24        q
rest  24        q
measure 9
rest  24        q
G#5   24        q #   d        (f
A5    24        q     d        )
measure 10
rest  24        q
C5    24        q     d        (p
B4    24        q n   d        )
measure 11
rest  24        q
B5    24        q n   d        (f
C6    24        q     d        )
measure 12
rest  24        q
G5    24        q n   d        (p+
F5    24        q     d        )
measure 13
E5    12        e     d        .
rest  12        e
D5    12        e     d        .
rest  12        e
E5    12        e     d        .
rest  12        e
measure 14
F5    48        h     d        (fp
E5    24        q     d        )
measure 15
E5    12        e     d        .
rest  12        e
D5    12        e     d        .
rest  12        e
E5    12        e     d        .
rest  12        e
measure 16
A5    48        h     d        (fp
G5    24        q     d        )
measure 17
rest  24        q
A5     6        s     d  [/    (
G5    18        e.    d  ]     )
F5     6        s     d  [/    (
E5    18        e.    d  ]     )
measure 18
C#5    6        s #   d  [/    (
D5    18        e.    d  ]     )
E5     6        s     d  [/    (
F5    18        e.    d  ]     )
G#5    6        s #   d  [/    (
A5    18        e.    d  ]     )
measure 19
C5    48        h n   d        f+
gE5    5        s     u
S C1:t50
D5    12        e     d  [     (
C5     6        s     d  =[
D5     6        s     d  ]]    )
measure 20
C5    24        q     d
rest  24        q
mheavy4         :|:
G5    12        e     d  [     .p
F5    12        e     d  ]     .
measure 21
E5    24        q     d        .
E5    24        q     d        .
E5    24        q     d        .
measure 22
F5    24        q     d        (
D5    24        q     d        )
rest  24        q
measure 23
rest  72
measure 24
rest  24        q
rest  24        q
gD5    5        s     u
S C1:t50
C5    12        e     d  [     (
Bf4    6        s f   d  =[    +
A4     6        s     d  ]]    )
measure 25
D5    48        h     d
gC5    5        s     u
S C1:t50
Bf4   12        e     u  [     (
A4     6        s     u  =[
G4     6        s     u  ]]    )
measure 26
C5    48        h     d
gBf4   5        s     u
S C1:t50
A4    12        e     u  [     (
G4     6        s     u  =[
F4     6        s     u  ]]    )
measure 27
C4    24        q     u
Bf4   24        q     d        (
A4    24        q     u        )
measure 28
G4    24        q     u
rest  24        q
C4     8        e  3  u  [     (*f
P C34:x-12y-5
D4     8        e  3  u  =
E4     8        e  3  u  ]     )!
measure 29
F4    24        q     u
rest  24        q
E4     8        e  3  u  [     (*
F4     8        e  3  u  =
G4     8        e  3  u  ]     )!
measure 30
A4    24        q     u
rest  24        q
G4     8        e  3  u  [     (*
A4     8        e  3  u  =
B4     8        e n3  u  ]     )!
measure 31
C5    24        q     d        .
D5    24        q     d        .
E5    24        q     d        .
measure 32
C5    24        q     d
rest  24        q
Bf4   18        e.f   u  [     (tf+
S C33:n6s17t84
P C34:y5
A4     3        t     u  =[[
Bf4    3        t     u  ]]]   )
measure 33
E5    24        q     d
rest  24        q
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
measure 34
Bf5   24        q f   d        +
rest  24        q
rest  24        q
measure 35
rest  72
measure 36
rest  72
measure 37
rest  72
measure 38
rest  72
measure 39
rest  72
measure 40
rest  24        q
rest  24        q
gG5    5        s     u
S C1:t50
F5    12        e     d  [     (p
E5     6        s     d  =[
D5     6        s     d  ]]    )
measure 41
C5    24        q     d        (
A4    24        q     u
Bf4   24        q     d        )
measure 42
C5    24        q     d        .
rest  24        q
F5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
E5     3        t     d  =[[
F5     3        t     d  ]]]   )
measure 43
A5    24        q     d
rest  24        q
F5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
E5     3        t     d  =[[
F5     3        t     d  ]]]   )
measure 44
C5    24        q     d
rest  24        q
gD5    5        s     u
S C1:t50
C5    12        e     d  [     (
Bf4    6        s     d  =[
A4     6        s     d  ]]    )
measure 45
G4    24        q     u        .
G4    24        q     u        (
A4    24        q     u        )
measure 46
Bf4   24        q     d        &1.
rest  24        q
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
measure 47
Bf5   24        q     d
rest  24        q
G5    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F5     3        t     d  =[[
G5     3        t     d  ]]]   )
measure 48
E5    24        q     d
rest  24        q
rest  24        q
measure 49
rest  24        q
B5    24        q n   d        (f
C6    24        q     d        )
measure 50
rest  24        q
Ef5   24        q f   d        (p
D5    24        q     d        )
measure 51
rest  24        q
A5    24        q     d        (f
Bf5   24        q     d        )
measure 52
rest  24        q
D5    24        q     d        (p
C5    24        q     d        )
measure 53
A5    12        e     d
rest  12        e
G5    12        e     d
rest  12        e
A5    12        e     d
rest  12        e
measure 54
Bf5   48        h     d        (fp
G5    24        q     d        )
measure 55
Bf5   12        e     d
rest  12        e
A5    12        e     d
rest  12        e
Bf5   12        e     d
rest  12        e
measure 56
C6    48        h     d        (fp
A5    24        q     d        )
measure 57
rest  24        q
D6     6        s     d  [/    (
C6    18        e.    d  ]     )
Bf5    6        s     d  [/    (
A5    18        e.    d  ]     )
measure 58
F#5    6        s #   d  [/    (
G5    18        e.    d  ]     )
A5     6        s     d  [/    (
G5    18        e.    d  ]     )
Bf5    6        s     d  [/    (
G5    18        e.    d  ]     )
measure 59
F5    48        h n   d        +
G5    12        e     d  [     (t
S C33:n6s17t84
P C33:y-2
F5     6        s     d  =[
G5     6        s     d  ]]    )
measure 60
F5    24        q     d
rest  24        q
rest  24        q
measure 61
rest  24        q
C#5    6        s #   d  [/    (f
D5    18        e.    d  ]     )
C5     6        s n   d  [/    (
Bf4   18        e.    d  ]     )
measure 62
A4     6        s     u  [/    (
G4    18        e.    u  ]     )
F#4    6        s #   u  [/    (
G4    18        e.    u  ]     )
Bf4    6        s     u  [/    (
G4    18        e.    u  ]     )
measure 63
F4    48        h n   u        +
gA4    5        s     u
S C1:t50
G4    12        e     u  [     (
F4     6        s     u  =[
G4     6        s     u  ]]    )
measure 64
F4    24        q     u
rest  24        q
S C8:F24
mdouble
S C0:|>
$  K:-4
C5    24        q     d
measure 65
F5    24        q     d        (
E5    24        q n   d        )
rest  24        q
measure 66
rest  24        q
rest  24        q
C5    24        q     d        .
measure 67
B4    24        q n   d        (
C5    24        q     d        )
rest  24        q
measure 68
rest  24        q
rest  24        q
C5    24        q     d        p
measure 69
Af5   72        h.    d
measure 70
Gf5   72        h.f   d
measure 71
F5    72        h.    d
measure 72
Ef5   72        h.f   d        +
measure 73
Df5   72        h.f   d        +
measure 74
C5    72        h.    d
measure 75
B4     6        s n   d  [[    (
C5     6        s     d  ==
B4     6        s     d  ==
C5     6        s     d  ]]
D5     6        s n   d  [[
Ef5    6        s     d  ==
D5     6        s     d  ==
Ef5    6        s     d  ]]
F5     6        s     d  [[
G5     6        s n   d  ==    +
F5     6        s     d  ==
G5     6        s     d  ]]    )
measure 76
Af5   24        q     d        (f
G5    24        q     d
F5    24        q     d        )
measure 77
Ef5   24        q     d
rest  24        q
C5    24        q     d        (p
measure 78
Df5   24        q f   d        )+
rest  24        q
B4    24        q n   d        (
measure 79
C5    12        e     d        )
rest  12        e
Ef4   12        e     u
rest  12        e
G4    12        e     u
rest  12        e
measure 80
C4    24        q     u
rest  24        q
mheavy4         :|:
Ef5   24        q     d        f
measure 81
Gf5   24        q f   d        (
F5    24        q     d        )
rest  24        q
measure 82
rest  24        q
rest  24        q
Df5   24        q     d
measure 83
F5    24        q     d        (
Ef5   24        q     d        )
rest  24        q
measure 84
rest  24        q
rest  24        q
C5    24        q     d        &1p
measure 85
Af5   72        h.    d
measure 86
G5    72        h.n   d        +
measure 87
F5    72        h.    d
measure 88
Ef5   72        h.    d
measure 89
Df5   72        h.    d
measure 90
C5    72-       h.    d        -
measure 91
C5    24        q     d        (
Bf4   24        q     d
Af4   24        q     u        )
measure 92
G4    24        q     u
rest  24        q
C5    24        q     d        .f
measure 93
F5    24        q     d        (
E5    24        q n   d        )
rest  24        q
measure 94
rest  24        q
rest  24        q
C5    24        q     d        .
measure 95
B4    24        q n   d        (
C5    24        q     d        )
rest  24        q
measure 96
rest  24        q
rest  24        q
C5    24        q     d        p
measure 97
Af5   72        h.    d
measure 98
Gf5   72        h.f   d
measure 99
F5    72        h.    d
measure 100
Ef5   72        h.f   d        +
measure 101
Df5   72        h.    d
measure 102
C5    72        h.    d
measure 103
B4     6        s n   d  [[    (
C5     6        s     d  ==
B4     6        s     d  ==
C5     6        s     d  ]]
D5     6        s n   d  [[
Ef5    6        s     d  ==
D5     6        s     d  ==
Ef5    6        s     d  ]]
F5     6        s     d  [[
G5     6        s n   d  ==    +
F5     6        s     d  ==
G5     6        s     d  ]]    )
measure 104
Af5   24        q     d        (f
G5    24        q     d
F5    24        q     d        )
measure 105
E5     6        s n   d  [[    (
F5     6        s     d  ==
E5     6        s     d  ==
F5     6        s     d  ]]
G5     6        s     d  [[
Af5    6        s     d  ==
G5     6        s     d  ==
Af5    6        s     d  ]]
Bf5    6        s     d  [[
C6     6        s     d  ==
Bf5    6        s     d  ==
C6     6        s     d  ]]    )
measure 106
Df6   24        q f   d        (+
C6    24        q     d
Bf5   24        q     d        )
measure 107
Af5   24        q     d        .
rest  24        q
F5    24        q     d        (p
measure 108
Gf5   24        q f   d        )
rest  24        q
E5    24        q n   d        (
measure 109
F5    12        e     d        )
rest  12        e
Af4   12        e     u
rest  12        e
C5    12        e     d
rest  12        e
measure 110
F4    24        q     u
rest  24        q
*               B       Da capo Tempo di Minuetto
*               B       senza Ritornello
P C17:y25
mheavy2         :|
S C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/03/02} [KHM:1785260819]
TIMESTAMP: DEC/26/2001 [md5sum:3a6d8905f53209f7a326ec4f79ff5df5]
03/30/94 E. Correia
WK#:158       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 2
1 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:-1   Q:12   T:3/4  C:4  D:Tempo di Minuetto
gG4    5        s     u
S C1:t50
F4     6        e     u  [     (p
P C33:y10
E4     3        s     u  =[
D4     3        s     u  ]]    )
measure 1
C4    12        q     u        (
A3    12        q     u
Bf3   12        q     u        )
measure 2
C4    12        q     u
rest  12        q
rest  12        q
measure 3
rest  36
measure 4
rest  12        q
rest  12        q
gD4    5        s     u
S C1:t50
C4     6        e     u  [     (
Bf3    3        s     u  =[
A3     3        s     u  ]]    )
measure 5
G3    12        q     u        .
G3    12        q     u        (
A3    12        q     u        )
measure 6
Bf3   12        q     u        .
rest  12        q
rest  12        q
measure 7
rest  36
measure 8
rest  12        q
rest  12        q
gC5    5        s     u
S C1:t50
Bf4    6        e     u  [     (
A4     3        s     u  =[
G4     3        s     u  ]]    )
measure 9
A4    12        q     u        f
rest  12        q
rest  12        q
measure 10
F4    12        q     u        p
rest  12        q
rest  12        q
measure 11
E4    12        q     u        f
P C32:y5
rest  12        q
rest  12        q
measure 12
D4    12        q     u        p
rest  12        q
rest  12        q
measure 13
C4     6        e     u  [
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  ]
measure 14
C4     6        e     u  [     fp
P C32:y5
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  ]
measure 15
C4     6        e     u  [
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  ]
measure 16
C4     6        e     u  [     fp
P C32:y5
C4     6        e     u  =
C4     6        e     u  =
C4     6        e     u  ]
C4    12        q     u
measure 17
rest  12        q
A4     3        s     u  [/    (
G4     9        e.    u  ]     )
F4     3        s     u  [/    (
E4     9        e.    u  ]     )
measure 18
C#4    3        s #   u  [/    (
D4     9        e.    u  ]     )
E4     3        s     u  [/    (
F4     9        e.    u  ]     )
G#4    3        s #   u  [/    (
A4     9        e.    u  ]     )
measure 19
E4    24        h     u        f
P C32:y5
gG4    5        s n   u        +
S C1:t50
F4     6        e     u  [     (
E4     3        s     u  =[
F4     3        s     u  ]]    )
measure 20
E4    12        q     u
rest  12        q
mheavy4         :|:
E4     6        e     u  [     .p
D4     6        e     u  ]     .
measure 21
C4    12        q     u        .
C4    12        q     u        .
C4    12        q     u        .
measure 22
D4    12        q     u        (
B3    12        q n   u        )
rest  12        q
measure 23
rest  36
measure 24
rest  36
measure 25
C5    12        q     d        (
Bf4   12        q f   d        )+
rest  12        q
measure 26
Bf4   12        q     d        (
A4    12        q     u        )
rest  12        q
measure 27
rest  12        q
G4    12        q     u        (
F4    12        q     u        )
measure 28
E4    12        q     u
rest  12        q
C4     4        e  3  u  [     (*f
P C34:x-12y-5
D4     4        e  3  u  =
E4     4        e  3  u  ]     )!
measure 29
F4    12        q     u
rest  12        q
E4     4        e  3  u  [     (*
F4     4        e  3  u  =
G4     4        e  3  u  ]     )!
measure 30
A4    12        q     u
rest  12        q
G4     4        e  3  u  [     (*
A4     4        e  3  u  =
B4     4        e n3  u  ]     )!
measure 31
C5    12        q     d        .
D5    12        q     d        .
E5    12        q     d        .
measure 32
C5    12        q     d
rest  12        q
rest  12        q
measure 33
rest  36
measure 34
rest  12        q
rest  12        q
Df5   12        q f   d
measure 35
F4    12        q     u        (
E4    12        q     u        )
Bf4   12        q f   d        .+
measure 36
Df4   12        q f   u        (
C4    12        q     u        )
Df5   12        q f   d
measure 37
F4    12        q     u        (
E4    12        q     u        )
Bf4   12        q     d        .
measure 38
Df4   12        q f   u        (
C4    12        q     u        )
rest  12        q
measure 39
rest  36
measure 40
rest  12        q
rest  12        q
gG4    5        s     u
S C1:t50
F4     6        e     u  [     (p
P C33:y10
E4     3        s     u  =[
D4     3        s n   u  ]]    )+
measure 41
C4    12        q     u        (
A3    12        q     u
Bf3   12        q     u        )
measure 42
C4    12        q     u        .
rest  12        q
rest  12        q
measure 43
rest  36
measure 44
rest  12        q
rest  12        q
gD4    5        s     u
S C1:t50
C4     6        e     u  [     (
Bf3    3        s     u  =[
A3     3        s     u  ]]    )
measure 45
G3    12        q     u        .
G3    12        q     u        (
A3    12        q     u        )
measure 46
Bf3   12        q     u        &1.
rest  12        q
rest  12        q
measure 47
rest  36
measure 48
rest  12        q
rest  12        q
gC5    5        s     u
S C1:t50
Bf4    6        e     u  [     (
A4     3        s     u  =[
G4     3        s     u  ]]    )
measure 49
A4    12        q     u        f
rest  12        q
rest  12        q
measure 50
Bf4   12        q     d        p
rest  12        q
rest  12        q
measure 51
D4    12        q     u        f
P C32:y5
rest  12        q
rest  12        q
measure 52
Bf4   12        q     d        p
rest  12        q
rest  12        q
measure 53
A4     6        e     u
rest   6        e
G4     6        e     u
rest   6        e
A4     6        e     u
rest   6        e
measure 54
Bf4   24        h     d        (fp
P C33:y5
G4    12        q     u        )
measure 55
Bf4    6        e     d
rest   6        e
A4     6        e     u
rest   6        e
Bf4    6        e     d
rest   6        e
measure 56
C5    24        h     d        (fp
A4    12        q     u        )
measure 57
rest  12        q
D5     3        s     d  [/    (
C5     9        e.    d  ]     )
Bf4    3        s     u  [/    (
A4     9        e.    u  ]     )
measure 58
F#4    3        s #   u  [/    (
G4     9        e.    u  ]     )
A4     3        s     u  [/    (
G4     9        e.    u  ]     )
Bf4    3        s     u  [/    (
G4     9        e.    u  ]     )
measure 59
F4    24        h n   u        (+
E4    12        q     u        )
measure 60
F4    12        q     u
rest  12        q
rest  12        q
measure 61
rest  12        q
C#4    3        s #   u  [/    (f
P C33:y10
D4     9        e.    u  ]     )
C4     3        s n   u  [/    (
Bf3    9        e.    u  ]     )
measure 62
A3     3        s     u  [/    (
G3     9        e.    u  ]     )
A3     3        s     u  [/    (
Bf3    9        e.    u  ]     )
D4     3        s     u  [/    (
Bf3    9        e.    u  ]     )
measure 63
A3    24        h     u
gC4    5        s     u
S C1:t50
Bf3    6        e     u  [     (
A3     3        s     u  =[
Bf3    3        s     u  ]]    )
measure 64
A3    12        q     u
rest  12        q
S C8:F12
mdouble
S C0:|>
$  K:-4
rest  12        q
measure 65
rest  12        q
rest  12        q
G4    12        q     u        .
measure 66
Af4   12        q     u        (
G4    12        q     u        )
rest  12        q
measure 67
rest  12        q
rest  12        q
G4    12        q     u        .
measure 68
Af4   12        q     u        (
G4    12        q     u        )
rest  12        q
measure 69
rest  12        q
C5    12        q     d        p
C5    12        q     d
measure 70
rest  12        q
C4    12        q     u
C4    12        q     u
measure 71
rest  12        q
Df4   12        q f   u        +
Df4   12        q     u
measure 72
rest  12        q
F4    12        q     u
F4    12        q     u
measure 73
rest  12        q
F4    12        q     u
F4    12        q     u
measure 74
rest  12        q
F4    12        q     u
F4    12        q     u
measure 75
F4    12        q     u
rest  12        q
rest  12        q
measure 76
F4    12        q     u        (f
P C33:y10
G4    12        q     u
Af4   12        q     u        )
measure 77
G4    12        q     u
rest  12        q
C4    12        q     u        (p
P C33:y5
measure 78
Df4   12        q f   u        )+
rest  12        q
B3    12        q n   u        (
measure 79
C4     6        e     u        )
rest   6        e
Ef4    6        e     u
rest   6        e
G4     6        e     u
rest   6        e
measure 80
C4    12        q     u
rest  12        q
mheavy4         :|:
C4    12        q     u        f
P C32:y5
measure 81
Ef4   12        q     u        (
Df4   12        q     u        )
rest  12        q
measure 82
rest  12        q
rest  12        q
Bf3   12        q f   u        +
measure 83
Df4   12        q     u        (
C4    12        q     u        )
rest  12        q
measure 84
rest  36
measure 85
rest  12        q
C5    12        q     d        p
Df5   12-       q     d        -
measure 86
Df5   12        q     d
B4    12        q n   d
C5    12-       q     d        -
measure 87
C5    12        q     d
A4    12        q n   u
Bf4   12-       q f   d        -+
measure 88
Bf4   12        q     d
G4    12        q     u
Af4   12-       q f   u        -+
measure 89
Af4   12        q     u
F4    12        q     u
Gf4   12-       q f   u        -
measure 90
Gf4   12        q     u
E4    12        q n   u
F4    12        q     u
measure 91
G4    24        h n   u        (+
F4    12        q     u        )
measure 92
E4    12        q n   u
rest  12        q
rest  12        q
measure 93
rest  12        q
rest  12        q
G4    12        q     u        .f
measure 94
Af4   12        q     u        (
G4    12        q     u        )
rest  12        q
measure 95
rest  12        q
rest  12        q
G4    12        q     u        .
measure 96
Af4   12        q     u        (
G4    12        q     u        )
rest  12        q
measure 97
rest  12        q
C5    12        q     d        p
C5    12        q     d
measure 98
rest  12        q
C4    12        q     u
C4    12        q     u
measure 99
rest  12        q
Df4   12        q f   u        +
Df4   12        q     u
measure 100
rest  12        q
F4    12        q     u
F4    12        q     u
measure 101
rest  12        q
F4    12        q     u
F4    12        q     u
measure 102
rest  12        q
F4    12        q     u
F4    12        q     u
measure 103
F4    12        q     u
rest  12        q
rest  12        q
measure 104
F4    12        q     u        (f
P C33:y10
G4    12        q     u
Af4   12        q     u        )
measure 105
G4    12        q     u
rest  12        q
rest  12        q
measure 106
Bf4   12        q     d        (
Af4   12        q     u
G4    12        q     u        )
measure 107
F4    12        q     u        &1.
rest  12        q
F4    12        q     u        (p
P C33:y5
measure 108
Gf4   12        q f   u        )
rest  12        q
E4    12        q n   u        (
measure 109
F4     6        e     u        )
rest   6        e
Af4    6        e     u
rest   6        e
C5     6        e     d
rest   6        e
measure 110
F4    12        q     u
rest  12        q
*               B       Da capo Tempo di Minuetto
*               B       senza Ritornello
P C17:y25
mheavy2         :|
S C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/03/03} [KHM:1785260819]
TIMESTAMP: DEC/26/2001 [md5sum:430b32a4a3f3a29dbfbf7665506c1197]
03/30/94 E. Correia
WK#:158       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Viola
1 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:-1   Q:24   T:3/4  C:13  D:Tempo di Minuetto
rest  24        q
measure 1
A3    24        q     u        (p
P C33:y5
F3    24        q     u
G3    24        q     u        )
measure 2
A3    24        q     u
rest  24        q
rest  24        q
measure 3
rest  72
measure 4
rest  72
measure 5
E3    24        q     u        .
E3    24        q     u        (
F3    24        q     u        )
measure 6
G3    24        q     u        .
rest  24        q
rest  24        q
measure 7
rest  72
measure 8
rest  24        q
rest  24        q
gA4    5        s     u
S C1:t50
G4    12        e     d  [
F4     6        s     d  =[
E4     6        s     d  ]]
measure 9
F4    24        q     d        f
rest  24        q
rest  24        q
measure 10
D4    24        q     d        p
rest  24        q
rest  24        q
measure 11
C4    24        q     d        f
P C32:y5
rest  24        q
rest  24        q
measure 12
G3    24        q     u        p
rest  24        q
rest  24        q
measure 13
E4    12        e     d        .
rest  12        e
D4    12        e     d        .
rest  12        e
E4    12        e     d        .
rest  12        e
measure 14
F4    48        h     d        (fp
E4    24        q     d        )
measure 15
E4    12        e     d        .
rest  12        e
D4    12        e     d        .
rest  12        e
E4    12        e     d        .
rest  12        e
measure 16
A4    48        h     d        (fp
G4    24        q     d        )
measure 17
G3    24        q     u
rest  24        q
rest  24        q
measure 18
A3    24        q     u
rest  24        q
rest  24        q
measure 19
G3    48        h     u        f
P C32:y5
B3    24        q n   u
measure 20
C4    24        q     d
rest  24        q
mheavy4         :|:
rest  24        q
measure 21
rest  72
measure 22
rest  24        q
rest  24        q
A4    12        e     d  [     .p
G4    12        e     d  ]     .
measure 23
F4    24        q     d        .
F4    24        q     d        .
F4    24        q     d        .
measure 24
G4    24        q     d        (
E4    24        q     d        )
rest  24        q
measure 25
A4    24        q     d        (
G4    24        q     d        )
rest  24        q
measure 26
G4    24        q     d        (
F4    24        q     d        )
rest  24        q
measure 27
rest  24        q
C4    24        q     d
C4    24        q     d
measure 28
C4    24        q     d
rest  24        q
C4     8        e  3  d  [     (*f
D4     8        e  3  d  =
E4     8        e  3  d  ]     )!
measure 29
F4    24        q     d
rest  24        q
E4     8        e  3  d  [     (*
F4     8        e  3  d  =
G4     8        e  3  d  ]     )!
measure 30
A4    24        q     d
rest  24        q
G4     8        e  3  d  [     (*
A4     8        e  3  d  =
B4     8        e n3  d  ]     )!
measure 31
C5    24        q     d
D5    24        q     d
E5    24        q     d
measure 32
C5    24        q     d
rest  24        q
rest  24        q
measure 33
rest  72
measure 34
rest  72
measure 35
rest  72
measure 36
rest  72
measure 37
rest  72
measure 38
rest  24        q
rest  24        q
C4    18        e.    d  [     (t
S C33:n6s17t84
B3     3        t n   d  =[[
C4     3        t     d  ]]]   )
measure 39
E4    24        q     d
rest  24        q
G4    18        e.    d  [     (t
S C33:n6s17t84
P C33:y-2
F4     3        t     d  =[[
G4     3        t     d  ]]]   )
measure 40
Bf4   24        q     d
rest  24        q
rest  24        q
measure 41
A3    24        q     u        (p
P C33:y5
F3    24        q     u
G3    24        q     u        )
measure 42
A3    24        q     u        .
rest  24        q
rest  24        q
measure 43
rest  72
measure 44
rest  72
measure 45
E3    24        q     u        .
E3    24        q     u        (
F3    24        q     u        )
measure 46
G3    24        q     u        .
rest  24        q
rest  24        q
measure 47
rest  72
measure 48
rest  24        q
rest  24        q
gA4    5        s     u
S C1:t50
G4    12        e     d  [     (
F4     6        s     d  =[
E4     6        s     d  ]]    )
measure 49
F4    24        q     d        f
rest  24        q
rest  24        q
measure 50
F4    24        q     d        p
rest  24        q
rest  24        q
measure 51
G3    24        q     u        f
P C32:y5
rest  24        q
rest  24        q
measure 52
G4    24        q     d        p
rest  24        q
rest  24        q
measure 53
C4    12        e     d  [
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
measure 54
C4    12        e     d  [     fp
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
measure 55
C4    12        e     d  [
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
measure 56
C4    12        e     d  [     fp
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  =
C4    12        e     d  ]
measure 57
F4    24        q     d
rest  24        q
rest  24        q
measure 58
D4    24        q     d
rest  24        q
rest  24        q
measure 59
A3    48        h     u        (
Bf3   24        q     u        )
measure 60
A3    24        q     u
rest  24        q
rest  24        q
measure 61
F3    24        q     u        f
P C32:y5
rest  24        q
rest  24        q
measure 62
rest  24        q
F#3    6        s #   u  [/    (
G3    18        e.    u  ]     )
Bf3    6        s     u  [/    (
G3    18        e.    u  ]     )
measure 63
C4    48        h     d
E3    24        q     u
measure 64
F3    24        q n   u        +
rest  24        q
S C8:F24
mdouble
S C0:|>
$  K:-4
rest  24        q
measure 65
rest  24        q
rest  24        q
E4    24        q n   d        .
measure 66
F4    24        q     d        (
E4    24        q n   d        )
rest  24        q
measure 67
rest  24        q
rest  24        q
E4    24        q n   d        .
measure 68
B3    24        q n   u        (
C4    24        q     d        )
rest  24        q
measure 69
rest  24        q
F4    24        q     d        p
F4    24        q     d
measure 70
rest  24        q
Af3   24        q     u
Af3   24        q     u
measure 71
rest  24        q
Af3   24        q     u
Af3   24        q     u
measure 72
rest  24        q
C4    24        q     d
C4    24        q     d
measure 73
rest  24        q
Bf3   24        q f   u        +
Bf3   24        q     u
measure 74
rest  24        q
C4    24        q     d
C4    24        q     d
measure 75
D4    24        q n   d
rest  24        q
rest  24        q
measure 76
D4    72        h.n   d        f
measure 77
Ef4   24        q f   d        +
rest  24        q
G3    24        q     u        (p
P C33:y5
measure 78
Af3   24        q     u        )
rest  24        q
F3    24        q     u        (
measure 79
Ef3   12        e     u        )
rest  12        e
Ef4   12        e     d
rest  12        e
G4    12        e     d
rest  12        e
measure 80
C4    24        q     d
rest  24        q
mheavy4         :|:
rest  24        q
measure 81
rest  24        q
rest  24        q
C5    24        q     d        f
measure 82
Ef5   24        q     d        (
Df5   24        q     d        )
rest  24        q
measure 83
rest  24        q
rest  24        q
Bf4   24        q     d
measure 84
Df5   24        q     d        (
C5    24        q     d        )
rest  24        q
measure 85
F4    72        h.    d        p
measure 86
E4    48        h n   d
Ef4   24        q f   d
measure 87
D4    48        h n   d
Df4   24        q f   d
measure 88
C4    72        h.    d
measure 89
Bf3   72        h.    u
measure 90
Af3   72        h.f   u
measure 91
E3    48        h n   u        (
F3    24        q     u        )
measure 92
C3    24        q     u
rest  24        q
rest  24        q
measure 93
rest  24        q
rest  24        q
E4    24        q n   d        .f
measure 94
F4    24        q     d        (
E4    24        q n   d        )
rest  24        q
measure 95
rest  24        q
rest  24        q
E4    24        q n   d        .
measure 96
B3    24        q n   u        (
C4    24        q     d        )
rest  24        q
measure 97
rest  24        q
F4    24        q     d        p
F4    24        q     d
measure 98
rest  24        q
Af3   24        q f   u
Af3   24        q     u
measure 99
rest  24        q
Af3   24        q f   u
Af3   24        q     u
measure 100
rest  24        q
A3    24        q n   u
A3    24        q     u
measure 101
rest  24        q
Bf3   24        q f   u        +
Bf3   24        q     u
measure 102
rest  24        q
C4    24        q     d
C4    24        q     d
measure 103
D4    24        q n   d
rest  24        q
rest  24        q
measure 104
D4    72        h.n   d        f
measure 105
Df4   24        q f   d        +
rest  24        q
rest  24        q
measure 106
G4    24        q     d        (
C4    24        q     d        )
C4    24        q     d        .
measure 107
C4    24        q     d
rest  24        q
C4    24        q     d        (p
measure 108
Df4   24        q     d        )
rest  24        q
Bf3   24        q     u        (
measure 109
Af3   12        e     u        )
rest  12        e
Af3   12        e     u
rest  12        e
C4    12        e     d
rest  12        e
measure 110
F3    24        q     u
rest  24        q
*               B       Da capo Tempo di Minuetto
*               B       senza Ritornello
P C17:y25
mheavy2         :|
S C0:d
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/03/04} [KHM:1785260819]
TIMESTAMP: DEC/26/2001 [md5sum:9d64e53a107c47cdb36862049d446480]
03/30/94 E. Correia
WK#:158       MV#:3
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violoncello
1 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:-1   Q:6   T:3/4  C:22  D:Tempo di Minuetto
rest   6        q
measure 1
A2     6        q     u        (p
P C33:y5
F2     6        q     u
G2     6        q     u        )
measure 2
A2     6        q     u
rest   6        q
rest   6        q
measure 3
rest  18
measure 4
rest  18
measure 5
E3     6        q     d        .
E3     6        q     d        (
F3     6        q     d        )
measure 6
G3     6        q     d        &1.
rest   6        q
rest   6        q
measure 7
rest  18
measure 8
rest  18
measure 9
F3     6        q     d        f
rest   6        q
rest   6        q
measure 10
G3     6        q     d        p
rest   6        q
rest   6        q
measure 11
A3     6        q     d        f
rest   6        q
rest   6        q
measure 12
B2     6        q n   u        p
rest   6        q
rest   6        q
measure 13
C3     3        e     u        .
rest   3        e
B2     3        e n   u        .
rest   3        e
C3     3        e     u        .
rest   3        e
measure 14
A3    12        h     d        (fp
G3     6        q     d        )
measure 15
G3     3        e     d        .
rest   3        e
F3     3        e     d        .
rest   3        e
G3     3        e     d        .
rest   3        e
measure 16
F3    12        h     d        (fp
E3     6        q     d        )
measure 17
E2     6        q     u
rest   6        q
rest   6        q
measure 18
F2     6        q     u
rest   6        q
rest   6        q
measure 19
rest   6        q
G3     6        q     d        f
G2     6        q     u
measure 20
C3     6        q     u
rest   6        q
mheavy4         :|:
rest   6        q
measure 21
rest  18
measure 22
rest   6        q
rest   6        q
F3     3        e     d  [     .p
E3     3        e     d  ]     .
measure 23
D3     6        q     d        .
D3     6        q     d        .
D3     6        q     d        .
measure 24
E3     6        q     d        (
C3     6        q     u        )
rest   6        q
measure 25
F#3    6        q #   d        (
G3     6        q     d        )
rest   6        q
measure 26
E3     6        q     d        (
F3     6        q n   d        )+
rest   6        q
measure 27
rest   6        q
E3     6        q     d        (
F3     6        q     d        )
measure 28
C3     6        q     u
rest   6        q
C3     2        e  3  d  [     (*f
D3     2        e  3  d  =
E3     2        e  3  d  ]     )!
measure 29
F3     6        q     d
rest   6        q
E3     2        e  3  d  [     (*
F3     2        e  3  d  =
G3     2        e  3  d  ]     )!
measure 30
A3     6        q     d
rest   6        q
G3     2        e  3  d  [     (*
A3     2        e  3  d  =
B3     2        e n3  d  ]     )!
measure 31
C4     6        q     d
D4     6        q     d
E4     6        q     d
measure 32
C4     6        q     d
rest   6        q
rest   6        q
measure 33
rest  18
measure 34
rest  18
measure 35
rest   6        q
rest   6        q
Df4    6        q f   d
measure 36
F3     6        q     d        (
E3     6        q     d        )
Bf3    6        q f   d        .+
measure 37
Df3    6        q f   d        (
C3     6        q     u        )
Df4    6        q f   d
measure 38
F3     6        q     d        (
E3     6        q     d        )
rest   6        q
measure 39
rest  18
measure 40
rest  18
measure 41
A2     6        q     u        (p
P C33:y5
F2     6        q     u
G2     6        q     u        )
measure 42
A2     6        q     u        .
rest   6        q
rest   6        q
measure 43
rest  18
measure 44
rest  18
measure 45
E2     6        q     u        .
E2     6        q     u        (
F2     6        q     u        )
measure 46
G2     6        q     u        &1.
rest   6        q
rest   6        q
measure 47
rest  18
measure 48
rest  18
measure 49
F3     6        q     d        f
rest   6        q
rest   6        q
measure 50
Bf2    6        q     u        p
rest   6        q
rest   6        q
measure 51
G3     6        q     d        f
rest   6        q
rest   6        q
measure 52
E3     6        q     d        p
rest   6        q
rest   6        q
measure 53
F3     3        e     d
rest   3        e
E3     3        e     d
rest   3        e
F3     3        e     d
rest   3        e
measure 54
G3    12        h     d        (fp
E3     6        q     d        )
measure 55
G3     3        e     d
rest   3        e
F3     3        e     d
rest   3        e
G3     3        e     d
rest   3        e
measure 56
A3    12        h     d        (fp
F3     6        q     d        )
measure 57
A2     6        q     u
rest   6        q
rest   6        q
measure 58
Bf2    6        q     u
rest   6        q
rest   6        q
measure 59
rest   6        q
C3     6        q     u        (
C#3    6        q #   u        )
measure 60
D3     6        q     d
rest   6        q
rest   6        q
measure 61
Bf2    6        q     u        f
rest   6        q
rest   6        q
measure 62
rest  18
measure 63
rest   6        q
C3     6        q     u
C2     6        q     u
measure 64
F2     6        q     u
rest   6        q
S C8:F6
mdouble
S C0:|>
$  K:-4
rest   6        q
measure 65
rest   6        q
rest   6        q
C4     6        q     d        .
measure 66
B3     6        q n   d        (
C4     6        q     d        )
rest   6        q
measure 67
rest   6        q
rest   6        q
C3     6        q     u        .
measure 68
F3     6        q     d        (
E3     6        q n   d        )
rest   6        q
measure 69
F3    18        h.    d        p
measure 70
Ef3   18        h.f   d        +
measure 71
Df3   18        h.f   d        +
measure 72
A2    18        h.n   u
measure 73
Bf2   18        h.    u
measure 74
Af2   18        h.f   u        +
measure 75
G2     6        q     u
rest   6        q
rest   6        q
measure 76
B2    18        h.n   u        f
P C32:y5
measure 77
C3     6        q     u
rest   6        q
Ef2    6        q     u        (&1p
measure 78
F2     6        q     u        )
rest   6        q
G2     6        q     u        (
measure 79
C3     3        e     u        )
rest   3        e
Ef3    3        e     d
rest   3        e
G3     3        e     d
rest   3        e
measure 80
C3     6        q     u
rest   6        q
mheavy4         :|:
rest   6        q
measure 81
rest   6        q
rest   6        q
A3     6        q n   d        f
measure 82
C4     6        q     d        (
Bf3    6        q     d        )
rest   6        q
measure 83
rest   6        q
rest   6        q
G3     6        q     d
measure 84
Bf3    6        q     d        (
Af3    6        q     d        )
rest   6        q
measure 85
rest  18
measure 86
rest  18
measure 87
rest  18
measure 88
rest  18
measure 89
rest  18
measure 90
rest  18
measure 91
rest  18
measure 92
rest  18
measure 93
rest   6        q
rest   6        q
C4     6        q     d        .f
measure 94
B3     6        q n   d        (
C4     6        q     d        )
rest   6        q
measure 95
rest   6        q
rest   6        q
C3     6        q     u        .
measure 96
F3     6        q     d        (
E3     6        q n   d        )
rest   6        q
measure 97
F3    18        h.    d        p
measure 98
Ef3   18        h.f   d        +
measure 99
Df3   18        h.    d
measure 100
C3    18        h.    u
measure 101
Bf2   18        h.    u
measure 102
Af2   18        h.    u
measure 103
G2     6        q     u
rest   6        q
rest   6        q
measure 104
B2    18        h.n   u        (f
P C33:y10
measure 105
Bf2    6        q f   u        )+
rest   6        q
rest   6        q
measure 106
E3    18        h.n   d        (
measure 107
F3     6        q     d        )
rest   6        q
Af2    6        q     u        (p
P C33:y5
measure 108
Bf2    6        q     u        )
rest   6        q
C3     6        q     u        (
measure 109
F3     3        e     d        )
rest   3        e
Af2    3        e     u
rest   3        e
C3     3        e     u
rest   3        e
measure 110
F2     6        q     u
rest   6        q
*               B       Da capo Tempo di Minuetto
*               B       senza Ritornello
P C17:y25
mheavy2         :|
S C0:d
/END
/eof
//
