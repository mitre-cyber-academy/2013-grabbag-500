&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 01
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/02/01} [KHM:1933660984]
TIMESTAMP: DEC/26/2001 [md5sum:6f76311952fcde9a2cd3699b27c2e408]
03/28/94 E. Correia
WK#:158       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 1
0 91 l. 14
Group memberships: score
score: part 1 of 4
$  K:0   Q:8   T:1/1  C:4  D:Andante un poco Allegretto
A4     4        e     d  [     (&0f
C5     4        e     d  =
E5     4        e     d  =
C5     4        e     d  ]     )
B4     4        e     d  [     (
D5     4        e     d  =
F5     4        e     d  =
D5     4        e     d  ]     )
measure 2
rest   2        s
C5     2        s     d  [[    (
E5     2        s     d  ==    )
E5     2        s     d  ]]    .
rest   2        s
C5     2        s     d  [[    (
E5     2        s     d  ==    )
E5     2        s     d  ]]    .
rest   2        s
G#4    2        s #   u  [[    (
B4     2        s     u  ==    )
B4     2        s     u  ]]    .
rest   2        s
G#4    2        s     u  [[    (
B4     2        s     u  ==    )
B4     2        s     u  ]]    .
measure 3
A4     8        q     u
A5     6        e.    d  [     (
E5     2        s     d  ]\    )
D5     6        e.    d  [     (
B4     2        s     d  ]\    )
G#4    2        s #   d  [[    (
B4     2        s     d  ==
D5     2        s     d  ==
F5     2        s     d  ]]    )
measure 4
F5     2        s     d  [[    (
E5     2        s     d  ]]    )
rest   2        s
E5     2        s     d  [[    (
C5     2        s     d  ==    )
A4     2        s     d  ]]    .
rest   2        s
A4     2        s     d  [[    (
G#4    2        s #   d  ==    )
F5     2        s     d  ]]    .
rest   2        s
F4     2        s     u  [[    (
D4     2        s     u  ==    )
D4     2        s     u  ]]    &1.
rest   2        s
G#4    2        s     u        (
P C32:u
measure 5
A4     4        e     d  [     )
C5     1        t     d  =[[   (
B4     1        t     d  ===
C5     1        t     d  ===
D5     1        t     d  ]]]   )
E5     4        e     d  [     (
A5     4        e     d  ]     )
rest   4        e
rest   2        s
C6     2        s     d  [[    (
A5     2        s     d  ==    )
A5     2        s     d  ]]    .
rest   2        s
C5     2        s     d        (
measure 6
B4    32        w     d        )p
P C33:y-10
measure 7
C5     4        e     d        f
G5     4        e     d  [     p.
E5     4        e     d  =      .
C5     4        e     d  ]      .
C6     6        e.    d  [     (
D6     1        t     d  =[[
B5     1        t     d  ]]]
C6     4        e     d        )
rest   4        e
measure 8
G4     4        e     u        f
 G3    4        e     u
D5     4        e     u  [     p.
B4     4        e     u  =      .
G4     4        e     u  ]      .
F5     6        e.    d  [     (
G5     1        t     d  =[[
E5     1        t     d  ]]]
F5     4        e     d        )
rest   4        e
measure 9
E5     6        e.    d  [     (f
F5     1        t     d  =[[
G5     1        t     d  ]]]   )
F5     2        s     d  [[    (
E5     2        s     d  ==    )
D5     2        s     d  ==    (
C5     2        s     d  ]]    )
B4     4        e     d  [     .
C5     4        e     d  =     .
F5     4        e     d  =     .
E5     4        e     d  ]     .
measure 10
E5     6        e.    d  [     (t
S C33:hn12s9t91
P C33:y-2
D5     1        t     d  =[[
E5     1        t     d  ]]]   )
D5     8        q     d
rest   4        e
G5     4        e     d  [
G5     4        e     d  =
G5     4        e     d  ]
measure 11
G5     6        e.    d  [     (
C6     2        s     d  ]\    )
G5     8        q     d
rest   4        e
G5     4        e     d  [
G5     4        e     d  =
G5     4        e     d  ]
measure 12
G5     6        e.    d  [     (
C6     2        s     d  ]\    )
G5     8        q     d
rest   4        e
C5     4        e     d  [     (
D5     4        e     d  =
E5     4        e     d  ]     )
measure 13
F5     6        e.    d  [     (
G5     2        s     d  ]\    )
A5     2        s     d  [[    .
A5     2        s     d  ==    .
A5     2        s     d  ==    .
A5     2        s     d  ]]    .
A5     2        s     d  [[    (
G5     2        s     d  ==    )
A5     2        s     d  ==    (
F5     2        s     d  ]]    )
E5     4        e     d  [     (
D5     4        e     d  ]     )
measure 14
rest   4        e
C5     4        e     d  [     (
D5     4        e     d  =
E5     4        e     d  ]     )
F5     6        e.    d  [     (
G5     2        s     d  ]\    )
A5     2        s     d  [[    .
A5     2        s     d  ==    .
A5     2        s     d  ==    .
A5     2        s     d  ]]    .
measure 15
A5     2        s     d  [[    (
G5     2        s     d  ==    )
A5     2        s     d  ==    (
F5     2        s     d  ]]    )
E5     4        e     d  [     (
D5     4        e     d  ]     )
C5     4        e     d
E5     4        e     d  [     (p
D#5    4        e #   d  =
E5     4        e     d  ]     )
measure 16
B4     8        q     d        (
C5     8        q     d
D5     8        q     d
E5     8        q     d        )
measure 17
D5     8        q     d        (
C5     8        q     d        )
B4     4        e     d        .
E5     4        e     d  [     (
D#5    4        e #   d  =
E5     4        e     d  ]     )
measure 18
B4     4        e     d  [
gD5    5        s     u
S C1:t50
C5     2        s     d  =[    (
B4     1        t     d  ==[
C5     1        t     d  ]]]   )
B4     4        e     d  [
gD5    5        s     u
S C1:t50
C5     2        s     d  =[    (
B4     1        t     d  ==[
C5     1        t     d  ]]]   )
B4     4        e     d  [     .
G#5    4        e #   d  =     .f
B5     4        e     d  ]     .
rest   4        e
mheavy4 19      :|:
rest  16        h
Bf4   16        h f   d        p
measure 20
A4    12        q.    u        (
D5     4        e     d        )
E5     8-       q     d        -
E5     6        e.    d  [     (
F5     1        t     d  =[[
G5     1        t     d  ]]]   )
measure 21
F5     8        q     d
rest   8        q
A4    16        h     u
measure 22
G4    12        q.    u        (
C5     4        e     d        )
D5     8-       q     d        -
D5     6        e.    d  [     (
E5     1        t     d  =[[
F5     1        t     d  ]]]   )
measure 23
E5     4        e     d
D#5    4        e #   d  [     (
E5     4        e     d  =
B4     4        e n   d  ]     )+
C5     4        e     d  [     (
G#4    4        e #   d  =
A4     4        e     d  =
B4     4        e     d  ]     )
measure 24
G#4    8        q #   u
rest   8        q
rest  16        h
measure 25
rest  32
measure 26
A4     4        e     d  [     (f
C5     4        e     d  =
E5     4        e     d  =
C5     4        e     d  ]     )
B4     4        e     d  [     (
D5     4        e     d  =
F5     4        e     d  =
D5     4        e     d  ]     )
measure 27
rest   2        s
C5     4        e     d  [
E5     4        e     d  =
A5     4        e     d  =
E5     2        s     d  ]\
rest   2        s
D5     4        e     d  [
B4     4        e     d  =
G#4    4        e #   d  =
B4     2        s     d  ]\
measure 28
A4     8-       q     u        -
A4     2        s     d  [[    (
C5     2        s     d  ==
E5     2        s     d  ==
A5     2        s     d  ]]    )
A5     2        s     d  [[    (
G#5    2        s #   d  =]    )
G#5    4        e     d  ]     .
rest   2        s
D5     2        s     d  [[    (
B5     2        s     d  ==
G#5    2        s     d  ]]    )
measure 29
A5     4        e     d  [     (
E5     4        e     d  =
C5     4        e     d  =
A4     4        e     d  ]     )
D5     4        e     d  [     (
F5     4        e     d  ]     )
D4     4        e     u  [     (
F4     4        e     u  ]     )
measure 30
E4     4        e     d  [     .
A5     4        e     d  =     (
G#5    4        e #   d  =
A5     4        e     d  ]     )
rest   4        e
C5     4        e     d  [     (
B4     4        e     d  =
C5     4        e     d  ]     )
measure 31
B4    32        w     d        p
P C32:y-10
measure 32
A4     4        e     u        .f
P C33:y5
E5     4        e     d  [     .p
C5     4        e     d  =     .
A4     4        e     d  ]     .
A5     6        e.    d  [     (
B5     1        t     d  =[[
G#5    1        t #   d  ]]]
A5     4        e     d        )
rest   4        e
measure 33
E5     4        e     u        f
P C32:y5
 B4    4        e     u
 E4    4        e     u
B4     4        e     u  [     .p
G#4    4        e #   u  =     .
E4     4        e     u  ]     .
D5     6        e.    d  [     (
E5     1        t     d  =[[
C#5    1        t #   d  ]]]
D5     4        e     d        )
rest   4        e
measure 34
C5     6        e.n   d  [     (+&0f
D5     1        t     d  =[[
E5     1        t     d  ]]]   )
D5     2        s     d  [[    (
C5     2        s     d  ==    )
B4     2        s     d  ==    (
A4     2        s     d  ]]    )
G#4    4        e #   d  [     .
A4     4        e     d  =     .
D5     4        e     d  =     .
C5     4        e     d  ]     .
measure 35
C5     6        e.    d  [     (t
S C33:n12s9t91
B4     1        t     d  =[[
C5     1        t     d  ]]]   )
B4     8        q     d
rest   4        e
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  ]
measure 36
E5     6        e.    d  [     (
A5     2        s     d  ]\    )
E5     8        q     d
rest   4        e
E5     4        e     d  [
E5     4        e     d  =
E5     4        e     d  ]
measure 37
E5     6        e.    d  [     (
A5     2        s     d  ]\    )
E5     8        q     d
rest   4        e
A4     4        e     d  [     (
B4     4        e     d  =
C#5    4        e #   d  ]     )
measure 38
D5     6        e.    d  [     (
E5     2        s     d  ]\    )
F5     2        s     d  [[    .
F5     2        s     d  ==    .
F5     2        s     d  ==    .
F5     2        s     d  ]]    .
F5     2        s     d  [[    (
E5     2        s     d  ==
F5     2        s     d  ==
D5     2        s     d  ]]    )
C5     4        e n   d  [     (+
B4     4        e     d  ]     )
measure 39
rest   4        e
A4     4        e     d  [     (
B4     4        e     d  =
C#5    4        e #   d  ]     )
D5     6        e.    d  [     (
E5     2        s     d  ]\    )
F5     2        s     d  [[    .
F5     2        s     d  ==    .
F5     2        s     d  ==    .
F5     2        s     d  ]]    .
measure 40
F5     2        s     d  [[    (
E5     2        s     d  ==
F5     2        s     d  ==
D5     2        s     d  ]]    )
C5     4        e n   d  [     (+
B4     4        e     d  ]     )
A4     4        e     u
A4     4        e     u  [     (p
G#4    4        e #   u  =
A4     4        e     u  ]     )
measure 41
E4     8        q     u        (
F4     8        q     u
G4     8        q n   u        +
A4     8        q     u        )
measure 42
G4     8        q     u        (
F4     8        q     u        )
E4     4        e     d  [     &1.
E5     4        e     d  =     (
D#5    4        e #   d  =
E5     4        e     d  ]     )
measure 43
A4    12        q.    u        (
gC5    5        s     u
S C1:t50
B4     4        e     d        )
A4     4        e     u        .
E5     4        e     d  [     (
D#5    4        e #   d  =
E5     4        e     d  ]     )
measure 44
A4    12        q.    u        (
gC5    5        s     u
S C1:t50
B4     4        e     d        )
A4     4        e     d  [     .
E5     4        e     d  =     .f
A5     4        e     d  ]     .
rest   4        e
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 02
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/02/02} [KHM:1933660984]
TIMESTAMP: DEC/26/2001 [md5sum:53e549e10d58579f4b388b96bbe4e024]
03/28/94 E. Correia
WK#:158       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violino 2
0 91 l. 14
Group memberships: score
score: part 2 of 4
$  K:0   Q:24   T:1/1  C:4  D:Andante un poco Allegretto
rest  96
measure 2
A3    12        e     u  [     (&0f
P C35:y10
C4    12        e     u  =
E4    12        e     u  =
C4    12        e     u  ]     )
B3    12        e     u  [     (
D4    12        e     u  =
F4    12        e     u  =
D4    12        e     u  ]     )
measure 3
rest   6        s
C4     6        s     u  [[    (
E4     6        s     u  ==    )
E4     6        s     u  ]]    .
rest   6        s
C5     6        s     d  [[    (
E5     6        s     d  ==    )
E5     6        s     d  ]]    .
rest   6        s
G#4    6        s #   u  [[    (
B4     6        s     u  ==    )
B4     6        s     u  ]]    .
rest   6        s
G#4    6        s     u  [[    (
B4     6        s     u  ==    )
B4     6        s     u  ]]    .
measure 4
A4    24        q     u
A5    18        e.    d  [     (
E5     6        s     d  ]\    )
D5    18        e.    d  [     (
B4     6        s     d  ]\    )
G#4    6        s #   d  [[    (
B4     6        s     d  ==
D5     6        s     d  ==
F5     6        s     d  ]]    )
measure 5
F5     6        s     d  [[    (
E5     6        s     d  ]]    )
rest   6        s
E5     6        s     d  [[    (
C5     6        s     d  ==    )
A4     6        s     d  ]]    .
rest   6        s
A4     6        s     d  [[    (
C5     6        s     d  ==    )
C5     6        s     d  ]]    .
rest   6        s
A5     6        s     d  [[    (
C5     6        s     d  ==    )
C5     6        s     d  ]]    .
rest   6        s
A4     6        s     u        (
measure 6
G#4   24        q #   u        )p
G#3   24        q #   u
G3    48        h n   u
measure 7
G3     6        s     u        f
E4     6        s     u  [[    .p
G4     6        s     u  ==    .
E4     6        s     u  ]]    .
G4     6        s     u  [[    .
E4     6        s     u  ==    .
G4     6        s     u  ==    .
E4     6        s     u  ]]    .
G4     6        s     u  [[    .
E4     6        s     u  ==    .
G4     6        s     u  ==    .
E4     6        s     u  ]]    .
G4     6        s     u  [[    .
E4     6        s     u  ==    .
G4     6        s     u  ==    .
E4     6        s     u  ]]    .
measure 8
F4     6        s     u        f
 G3    6        s     u
D4     6        s     u  [[    .p
F4     6        s     u  ==    .
D4     6        s     u  ]]    .
F4     6        s     u  [[    .
D4     6        s     u  ==    .
F4     6        s     u  ==    .
D4     6        s     u  ]]    .
G4     6        s     u  [[    .
D4     6        s     u  ==    .
G4     6        s     u  ==    .
D4     6        s     u  ]]    .
G4     6        s     u  [[    .
D4     6        s     u  ==    .
G4     6        s     u  ==    .
D4     6        s     u  ]]    .
measure 9
E4    18        e.    u  [     (f
P C33:y10
F4     3        t     u  =[[
G4     3        t     u  ]]]   )
F4     6        s     u  [[    (
E4     6        s     u  ==    )
D4     6        s     u  ==    (
C4     6        s     u  ]]    )
B3    12        e     u  [     .
C4    12        e     u  =     .
F4    12        e     u  =     .
E4    12        e     u  ]     .
measure 10
E4    18        e.    u  [     (t
S C33:hn12s9t91
D4     3        t     u  =[[
E4     3        t     u  ]]]   )
D4    24        q     u
F4     4        s  3  u  [[    (
G4     4        s  3  u  ==
F4     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
F4     4        s  3  u  [[    (
G4     4        s  3  u  ==
F4     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
measure 11
G4     4        s  3  u  [[    (
A4     4        s  3  u  ==
G4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
G4     4        s  3  u  [[    (
A4     4        s  3  u  ==
G4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
F4     4        s  3  u  [[    (
G4     4        s  3  u  ==
F4     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
F4     4        s  3  u  [[    (
G4     4        s  3  u  ==
F4     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
measure 12
G4     4        s  3  u  [[    (
A4     4        s  3  u  ==
G4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
G4     4        s  3  u  [[    (
A4     4        s  3  u  ==
G4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
G4    12        e     u  [     .
E4    12        e     u  =     (
F4    12        e     u  =
G4    12        e     u  ]     )
measure 13
F4    18        e.    u  [     (
G4     6        s     u  ]\    )
A4     6        s     u  [[    .
A4     6        s     u  ==    .
A4     6        s     u  ==    .
A4     6        s     u  ]]    .
A4     6        s     u  [[    (
G4     6        s     u  ==    )
A4     6        s     u  ==    (
F4     6        s     u  ]]    )
E4    12        e     u  [     (
D4    12        e     u  ]     )
measure 14
rest  12        e
C4    12        e     u  [     (
D4    12        e     u  =
E4    12        e     u  ]     )
F4    18        e.    u  [     (
E4     6        s     u  ]\    )
D4     6        s     u  [[    (
F4     6        s     u  ==    )
F4     6        s     u  ==    (
A4     6        s     u  ]]    )
measure 15
A4     6        s     u  [[    (
G4     6        s     u  ==    )
A4     6        s     u  ==    (
F4     6        s     u  ]]    )
E4    12        e     u  [     (
D4    12        e     u  ]     )
C4    24        q     u
rest  24        q
measure 16
rest  12        e
E4    12        e     u  [     (p
P C33:y10
D#4   12        e #   u  =
E4    12        e     u  ]     )
B3    24        q     u        (
C4    24        q     u        )
measure 17
B3    24        q     u        (
A3    24        q     u        )
G#3   24        q #   u
rest  24        q
measure 18
G#4   12        e #   u  [     (
P C32:u
A4    12        e     u  =
G#4   12        e     u  =
A4    12        e     u  ]
G#4   12        e     d  [     )
D5    12        e     d  =     .f
D5    12        e     d  ]     .
rest  12        e
mheavy4 19      :|:
A4     6        s     u  [[    p
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
measure 20
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
F4     6        s     u  [[
F4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
Bf4    6        s f   d  [[
Bf4    6        s     d  ==
Bf4    6        s     d  ==
Bf4    6        s     d  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
measure 21
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
F4     6        s     u  [[
F4     6        s     u  ==
F4     6        s     u  ==
F4     6        s     u  ]]
F4     6        s     u  [[
F4     6        s     u  ==
F4     6        s     u  ==
F4     6        s     u  ]]
E4     6        s     u  [[
E4     6        s     u  ==
E4     6        s     u  ==
E4     6        s     u  ]]
measure 22
D4     6        s     u  [[
D4     6        s     u  ==
D4     6        s     u  ==
D4     6        s     u  ]]
E4     6        s     u  [[
E4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
A4     6        s     u  [[
A4     6        s     u  ==
A4     6        s     u  ==
A4     6        s     u  ]]
G4     6        s     u  [[
G4     6        s     u  ==
G4     6        s     u  ==
G4     6        s     u  ]]
measure 23
G4    24        q     u
rest  12        e
D#4   12        e #   u        (
E4    12        e     u  [     )
D4    12        e n   u  =     (
C4    12        e     u  =
F#4   12        e #   u  ]     )
measure 24
B3    12        e     u  [     .
D#4   12        e #   u  =     (
E4    12        e     u  =
B3    12        e     u  ]
C4    12        e     u  [
G#3   12        e #   u  =
A3    12        e     u  =
B3    12        e     u  ]     )
measure 25
G#3   24        q #   u
rest  24        q
rest  48        h
measure 26
rest  96
measure 27
A3    12        e     u  [     (f
P C33:y10
C4    12        e     u  =
E4    12        e     u  =
C4    12        e     u  ]     )
B3    12        e     u  [     (
D4    12        e     u  =
F4    12        e     u  =
D4    12        e     u  ]     )
measure 28
rest   6        s
C4    12        e     u  [
E4    12        e     u  =
A4    12        e     u  =
E5     6        s     u  ]\
rest   6        s
D5    12        e     d  [
B4    12        e     d  =
G#4   12        e #   d  =
B4     6        s     d  ]\
measure 29
A4    24-       q     u        -
A4     6        s     d  [[    (
C5     6        s     d  ==
E5     6        s     d  ==
A5     6        s     d  ]]    )
A5     6        s     d  [[    (
G#5    6        s #   d  =]    )
G#5   12        e     d  ]     .
rest   6        s
D5     6        s     d  [[    (
B5     6        s     d  ==
G#5    6        s     d  ]]    )
measure 30
A5    12        e     d  [     .
C5    12        e     d  =     (
B4    12        e     d  =
C5    12        e     d  ]     )
rest  12        e
A4    12        e     u  [     (
G#4   12        e #   u  =
A4    12        e     u  ]     )
measure 31
G#4   48        h #   u        (p
P C33:y10
G#3   48        h #   u        )
measure 32
A3     6        s     u        f
P C32:y5
C4     6        s     u  [[    .p
E4     6        s     u  ==    .
C4     6        s     u  ]]    .
E4     6        s     u  [[    .
C4     6        s     u  ==    .
E4     6        s     u  ==    .
C4     6        s     u  ]]    .
E4     6        s     u  [[    .
C4     6        s     u  ==    .
E4     6        s     u  ==    .
C4     6        s     u  ]]    .
E4     6        s     u  [[    .
C4     6        s     u  ==    .
E4     6        s     u  ==    .
C4     6        s     u  ]]    .
measure 33
D4     6        s     u        f
P C32:y5
B3     6        s     u  [[    .p
P C33:y-5
D4     6        s     u  ==    .
B3     6        s     u  ]]    .
D4     6        s     u  [[    .
B3     6        s     u  ==    .
D4     6        s     u  ==    .
B3     6        s     u  ]]    .
E4     6        s     u  [[    .
B3     6        s     u  ==    .
E4     6        s     u  ==    .
B3     6        s     u  ]]    .
E4     6        s     u  [[    .
B3     6        s     u  ==    .
E4     6        s     u  ==    .
B3     6        s     u  ]]    .
measure 34
C4    18        e.    u  [     (f
P C33:y10
D4     3        t     u  =[[
E4     3        t     u  ]]]   )
D4     6        s     u  [[    (
C4     6        s     u  ==    )
B3     6        s     u  ==    (
A3     6        s     u  ]]    )
G#3   12        e #   u  [     .
A3    12        e     u  =     .
D4    12        e     u  =     .
C4    12        e     u  ]     .
measure 35
C4    18        e.    u  [     (t
S C33:n12s9t91
B3     3        t     u  =[[
C4     3        t     u  ]]]   )
B3    24        q     u
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
measure 36
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
C4     4        s  3  u  [[    (
D4     4        s  3  u  ==
C4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
C4     4        s  3  u  [[    (
D4     4        s  3  u  ==
C4     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
D4     4        s  3  u  [[    (
E4     4        s  3  u  ==
D4     4        s  3  u  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
measure 37
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
C4     4        s  3  u  [[    (
D4     4        s  3  u  ==
C4     4        s  3  u  ]]    )
E4     4        s  3  u  [[    (
F4     4        s  3  u  ==
E4     4        s  3  u  ]]    )
C4     4        s  3  u  [[    (
D4     4        s  3  u  ==
C4     4        s  3  u  ]]    )
C4    12        e     u  [     .
C4    12        e     u  =     (
D4    12        e     u  =
E4    12        e     u  ]     )
measure 38
F4    18        e.    u  [     (
G4     6        s     u  ]\    )
A4     6        s     u  [[    .
F4     6        s     u  ==    .
F4     6        s     u  ==    .
F4     6        s     u  ]]    .
F4     6        s     u  [[    (
E4     6        s     u  ==
F4     6        s     u  ==
D4     6        s     u  ]]    )
C4    12        e     u  [     (
B3    12        e     u  ]     )
measure 39
rest  12        e
A3    12        e     u  [     (
B3    12        e     u  =
C#4   12        e #   u  ]     )
D4    18        e.    u  [     (
E4     6        s     u  ]\    )
F4     6        s     u  [[    .
F4     6        s     u  ==    .
F4     6        s     u  ==    .
F4     6        s     u  ]]    .
measure 40
F4     6        s     u  [[    (
E4     6        s     u  ==
F4     6        s     u  ==
D4     6        s     u  ]]    )
C4    12        e n   u  [     (+
B3    12        e     u  ]     )
A3    24        q     u
rest  24        q
measure 41
rest  12        e
A4    12        e     u  [     (p
G#4   12        e #   u  =
A4    12        e     u  ]     )
E4    24        q     u        (
F4    24        q     u        )
measure 42
C#4   24        q #   u        (
D4    24        q     u        )
C4    24        q n   u        .
rest  24        q
measure 43
rest  12        e
F#4   12        e #   u  [     (
E4    12        e     u  =
D4    12        e     u  ]     )
C4    24        q     u        &1.
rest  24        q
measure 44
rest  12        e
C4    24        q     u        (
G#3   12        e #   u        )
A4    12        e     u  [
 A3   12        e     u        &1.
A4    12        e     u  =     .f
P C33:y5
C5    12        e     u  ]     .
rest  12        e
mheavy2         :|
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 03
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/02/03} [KHM:1933660984]
TIMESTAMP: DEC/26/2001 [md5sum:1e4c7506e350c2fe1f2387c899be82ad]
03/28/94 E. Correia
WK#:158       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Viola
0 91 l. 14
Group memberships: score
score: part 3 of 4
$  K:0   Q:24   T:1/1  C:13  D:Andante un poco Allegretto
rest  96
measure 2
rest  96
measure 3
A3    12        e     d  [     (&0f
C4    12        e     d  =
E4    12        e     d  =
C4    12        e     d  ]     )
B3    12        e     d  [     (
D4    12        e     d  =
F4    12        e     d  =
D4    12        e     d  ]     )
measure 4
rest   6        s
C4     6        s     d  [[    (
E4     6        s     d  ==    )
E4     6        s     d  ]]    .
rest   6        s
C4     6        s     d  [[    (
E4     6        s     d  ==    )
E4     6        s     d  ]]    .
rest   6        s
G#3    6        s #   u  [[    (
B3     6        s     u  ==    )
B3     6        s     u  ]]    .
rest   6        s
G#3    6        s     u  [[    (
B3     6        s     u  ==    )
B3     6        s     u  ]]    .
measure 5
C4     3        t     u  [[[   (
D4     3        t     u  ===
C4     3        t     u  ===
B3     3        t     u  =]]
A3    12        e     u  ]     )
A4     3        t     d  [[[   (
G#4    3        t #   d  ===
A4     3        t     d  ===
F4     3        t     d  =]]
E4    12        e     d  ]     )
rest   6        s
C5     6        s     d  [[    (
A4     6        s     d  ==    )
A4     6        s     d  ]]    .
rest   6        s
E4     6        s     d  [[    (
F#4    6        s #   d  ==    )
F#4    6        s     d  ]]    .
measure 6
B3    24        q     u        p
E4    48        h     d
F4     6        s n   d  [[    (+
E4     6        s     d  ==
F4     6        s     d  ==
D4     6        s     d  ]]    )
measure 7
E4    12        e     d        f
rest  12        e
rest  24        q
E4     6        s     d  [[    .p
C4     6        s     d  ==    .
E4     6        s     d  ==    .
C4     6        s     d  ]]    .
E4     6        s     d  [[    .
C4     6        s     d  ==    .
E4     6        s     d  ==    .
C4     6        s     d  ]]    .
measure 8
D4    12        e     u        f
P C32:y5
 G3   12        e     u
rest  12        e
rest  24        q
D4     6        s     d  [[    .p
B3     6        s     d  ==    .
D4     6        s     d  ==    .
B3     6        s     d  ]]    .
D4     6        s     d  [[    .
B3     6        s     d  ==    .
D4     6        s     d  ==    .
B3     6        s     d  ]]    .
measure 9
C4    24        q     d        f
P C32:y5
rest  24        q
G3    24        q     u
B3    12        e     u  [     .
C4    12        e     u  ]     .
measure 10
C4    18        e.    u  [     (t
S C33:n12s9t91
B3     3        t     u  =[[
C4     3        t     u  ]]]   )
B3    24        q     u
D4     4        s  3  d  [[    (
E4     4        s  3  d  ==
D4     4        s  3  d  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
D4     4        s  3  d  [[    (
E4     4        s  3  d  ==
D4     4        s  3  d  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
measure 11
E4     4        s  3  d  [[    (
F4     4        s  3  d  ==
E4     4        s  3  d  ]]    )
C4     4        s  3  d  [[    (
D4     4        s  3  d  ==
C4     4        s  3  d  ]]    )
E4     4        s  3  d  [[    (
F4     4        s  3  d  ==
E4     4        s  3  d  ]]    )
C4     4        s  3  d  [[    (
D4     4        s  3  d  ==
C4     4        s  3  d  ]]    )
D4     4        s  3  d  [[    (
E4     4        s  3  d  ==
D4     4        s  3  d  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
D4     4        s  3  d  [[    (
E4     4        s  3  d  ==
D4     4        s  3  d  ]]    )
B3     4        s  3  u  [[    (
C4     4        s  3  u  ==
B3     4        s  3  u  ]]    )
measure 12
E4     4        s  3  d  [[    (
F4     4        s  3  d  ==
E4     4        s  3  d  ]]    )
C4     4        s  3  d  [[    (
D4     4        s  3  d  ==
C4     4        s  3  d  ]]    )
E4     4        s  3  d  [[    (
F4     4        s  3  d  ==
E4     4        s  3  d  ]]    )
C4     4        s  3  d  [[    (
D4     4        s  3  d  ==
C4     4        s  3  d  ]]    )
E4    12        e     d  [     .
C4    12        e     d  =     (
D4    12        e     d  =
E4    12        e     d  ]     )
measure 13
C4    18        e.    d  [     (
E4     6        s     d  ]\    )
F4     6        s     d  [[    .
F4     6        s     d  ==    .
F4     6        s     d  ==    .
F4     6        s     d  ]]    .
F4     6        s     d  [[    (
E4     6        s     d  ==    )
F4     6        s     d  ==    (
D4     6        s     d  ]]    )
C4    12        e     u  [     (
B3    12        e     u  ]     )
measure 14
rest  12        e
E4    12        e     d  [     (
F4    12        e     d  =
G4    12        e     d  ]     )
A4    12        e     d  [     (
C4    12        e     d  ]     )
B3     6        s     d  [[    (
D4     6        s     d  ==    )
D4     6        s     d  ==    (
F4     6        s     d  ]]    )
measure 15
F4     6        s     d  [[    (
E4     6        s     d  ==    )
F4     6        s     d  ==    (
D4     6        s     d  ]]    )
C4    12        e     u  [     (
B3    12        e     u  ]     )
C4    24        q     d
rest  24        q
measure 16
rest  96
measure 17
rest  12        e
E4    12        e     d  [     (p
D#4   12        e #   d  =
E4    12        e     d  ]     )
B3    24        q     u
rest  24        q
measure 18
E4    12        e     d  [     (
D#4   12        e #   d  =
E4    12        e     d  =
D#4   12        e     d  ]
E4    12        e     d  [     )
E4    12        e     d  =     .f
E4    12        e     d  ]     .
rest  12        e
mheavy4 19      :|:
rest  24        q
C#4    6        s #   d  [[    p
C#4    6        s     d  ==
C#4    6        s     d  ==
C#4    6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
E4     6        s     d  [[
E4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
measure 20
C#4    6        s #   d  [[
C#4    6        s     d  ==
C#4    6        s     d  ==
C#4    6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
G4     6        s     d  ==
G4     6        s     d  ]]
E4     6        s     d  [[
E4     6        s     d  ==
C#4    6        s     d  ==
C#4    6        s     d  ]]
measure 21
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
D4     6        s     d  ==
D4     6        s     d  ]]
C4     6        s n   d  [[    +
C4     6        s     d  ==
C4     6        s     d  ==
C4     6        s     d  ]]
measure 22
B3     6        s     u  [[
B3     6        s     u  ==
B3     6        s     u  ==
B3     6        s     u  ]]
C4     6        s     d  [[
C4     6        s     d  ==
E4     6        s     d  ==
E4     6        s     d  ]]
C4     6        s     d  [[
C4     6        s     d  ==
F4     6        s     d  ==
F4     6        s     d  ]]
D4     6        s     d  [[
D4     6        s     d  ==
B3     6        s     d  ==
B3     6        s     d  ]]
measure 23
A3    24        q     u
rest  24        q
rest  12        e
B3    12        e     u  [     (
A3    12        e     u  =
F#3   12        e #   u  ]     )
measure 24
G#3   24        q #   u
rest  12        e
D#3   12        e #   u        (
E3    12        e     u  [     )
D3    12        e n   u  =     (
C3    12        e     u  =
F#3   12        e #   u  ]     )
measure 25
E3    12        e     u  [     .
E4    12        e     u  =     (
F4    12        e     u  =
C#4   12        e #   u  ]
D4    12        e     u  [
D#4   12        e #   u  =
E4    12        e     u  =
G#3   12        e #   u  ]     )
measure 26
A3    24        q     u        f
P C32:y5
rest  24        q
rest  48        h
measure 27
rest  96
measure 28
A3    12        e     d  [     (
C4    12        e     d  =
E4    12        e     d  =
C4    12        e     d  ]     )
B3    12        e     d  [     (
D4    12        e     d  =
F4    12        e     d  =
D4    12        e     d  ]     )
measure 29
rest   6        s
C4    12        e     d  [
E4    12        e     d  =
A4    12        e     d  =
E4     6        s     d  ]\
rest   6        s
D4    12        e     u  [
B3    12        e     u  =
G#3   12        e #   u  =
B3     6        s     u  ]\
measure 30
C4    24        q     d
rest  24        q
F#4   24        q #   d
rest  24        q
measure 31
B3    24        q     u        (p
D4    24        q     d
E4    24        q     d
F4    24        q n   d        )+
measure 32
E4    12        e     d        f
rest  12        e
rest  24        q
C4     6        s     u  [[    .p
A3     6        s     u  ==    .
C4     6        s     u  ==    .
A3     6        s     u  ]]    .
C4     6        s     u  [[    .
A3     6        s     u  ==    .
C4     6        s     u  ==    .
A3     6        s     u  ]]    .
measure 33
B3    12        e     u        f
rest  12        e
rest  24        q
B3     6        s     u  [[    .p
G#3    6        s #   u  ==    .
B3     6        s     u  ==    .
G#3    6        s     u  ]]    .
B3     6        s     u  [[    .
G#3    6        s     u  ==    .
B3     6        s     u  ==    .
G#3    6        s     u  ]]    .
measure 34
A3    24        q     u        f
P C32:y5
rest  24        q
E3    24        q     u
G#3   12        e #   u  [     .
A3    12        e     u  ]     .
measure 35
A3    18        e.    u  [     (t
S C33:n12s9t91
G#3    3        t #   u  =[[
A3     3        t     u  ]]]   )
G#3   24        q     u
B4     4        s  3  d  [[    (
C5     4        s  3  d  ==
B4     4        s  3  d  ]]    )
G#4    4        s #3  d  [[    (
A4     4        s  3  d  ==
G#4    4        s  3  d  ]]    )
B4     4        s  3  d  [[    (
C5     4        s  3  d  ==
B4     4        s  3  d  ]]    )
G#4    4        s  3  d  [[    (
A4     4        s  3  d  ==
G#4    4        s  3  d  ]]    )
measure 36
C5     4        s  3  d  [[    (
D5     4        s  3  d  ==
C5     4        s  3  d  ]]    )
A4     4        s  3  d  [[    (
B4     4        s  3  d  ==
A4     4        s  3  d  ]]    )
C5     4        s  3  d  [[    (
D5     4        s  3  d  ==
C5     4        s  3  d  ]]    )
A4     4        s  3  d  [[    (
B4     4        s  3  d  ==
A4     4        s  3  d  ]]    )
B4     4        s  3  d  [[    (
C5     4        s  3  d  ==
B4     4        s  3  d  ]]    )
G#4    4        s #3  d  [[    (
A4     4        s  3  d  ==
G#4    4        s  3  d  ]]    )
B4     4        s  3  d  [[    (
C5     4        s  3  d  ==
B4     4        s  3  d  ]]    )
G#4    4        s  3  d  [[    (
A4     4        s  3  d  ==
G#4    4        s  3  d  ]]    )
measure 37
C5     4        s  3  d  [[    (
D5     4        s  3  d  ==
C5     4        s  3  d  ]]    )
A4     4        s  3  d  [[    (
B4     4        s  3  d  ==
A4     4        s  3  d  ]]    )
C5     4        s  3  d  [[    (
D5     4        s  3  d  ==
C5     4        s  3  d  ]]    )
A4     4        s  3  d  [[    (
B4     4        s  3  d  ==
A4     4        s  3  d  ]]    )
E4    12        e     d        .
A3    12        e     u  [     (
B3    12        e     u  =
C#4   12        e #   u  ]     )
measure 38
D4    18        e.    d  [     (
E4     6        s     d  ]\    )
F4     6        s     d  [[    .
D4     6        s     d  ==    .
D4     6        s     d  ==    .
D4     6        s     d  ]]    .
D4     6        s     d  [[    (
C4     6        s n   d  ==    +
D4     6        s     d  ==
B3     6        s     d  ]]    )
A3    12        e     u  [     (
G#3   12        e #   u  ]     )
measure 39
A3    12        e     d  [     .
C4    12        e     d  =     (
D4    12        e     d  =
E4    12        e     d  ]     )
F4    18        e.    d  [     (
G4     6        s     d  ]\    )
A4     6        s     d  [[    (
F4     6        s     d  ==    )
D4     6        s     d  ==    (
B3     6        s     d  ]]    )
measure 40
C4    12        e     d  [     (
D4     6        s     d  =[
B3     6        s     d  ]]    )
A3    12        e     u  [     &1(
G#3   12        e #   u  ]     &1)
A3    24        q     u
rest  24        q
measure 41
rest  96
measure 42
rest  12        e
A3    12        e     u  [     (p
P C33:y5
G#3   12        e #   u  =
A3    12        e     u  ]     )
E3    24        q     u        &1.
rest  24        q
measure 43
rest  12        e
C4    24        q     d        (
G#3   12        e #   u        )
A3    24        q     u        &1.
rest  24        q
measure 44
rest  12        e
F#3   12        e #   u  [     (
E3    12        e     u  =
D3    12        e     u  ]     )
C3    12        e     u  [     &1.
C4    12        e     u  =     .f
P C33:y5
E4    12        e     u  ]     .
rest  12        e
mheavy2
/END
/eof
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
FILENAME = 04
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
(C) 1994, 2002 Center for Computer Assisted Research in the Humanities.
ID: {mozart/bh/qrtets/k158/stage2/02/04} [KHM:1933660984]
TIMESTAMP: DEC/26/2001 [md5sum:a2572991d8af635c79b23efc64948092]
03/28/94 E. Correia
WK#:158       MV#:2
Breitkopf & H\a3rtel, vol. 14
Quartet No. 5 for 2 violins, viola, and violoncello

Violoncello
0 91 l. 14
Group memberships: score
score: part 4 of 4
$  K:0   Q:4   T:1/1  C:22  D:Andante un poco Allegretto
rest  16
measure 2
rest  16
measure 3
rest  16
measure 4
A2     2        e     u  [     (&0f
P C35:y10
C3     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]     )
B2     2        e     d  [     (
D3     2        e     d  =
F3     2        e     d  =
D3     2        e     d  ]     )
measure 5
rest   1        s
C3     1        s     d  [[    (
E3     1        s     d  ==    )
E3     1        s     d  ]]    .
rest   1        s
A3     1        s     d  [[    (
C4     1        s     d  ==    )
C4     1        s     d  ]]    .
rest   1        s
A3     1        s     d  [[    (
F3     1        s     d  ==    )
F3     1        s     d  ]]    .
rest   1        s
A3     1        s     d  [[    (
D#3    1        s #   d  ==    )
D#3    1        s     d  ]]    .
measure 6
E3    12        h.    d        (p
D3     4        q n   d        )+
measure 7
C3     2        e     u        f
rest   2        e
rest   4        q
rest   8        h
measure 8
B2     2        e     u        f
rest   2        e
rest   4        q
rest   8        h
measure 9
C3     4        q     u        f
rest   4        q
F3     2        e     d  [     .
E3     2        e     d  =     .
D3     2        e     d  =     .
C3     2        e     d  ]     .
measure 10
G3     4        q     d
G2     4        q     u
G3     4        q     d
rest   4        q
measure 11
C3     4        q     u
rest   4        q
G3     4        q     d
rest   4        q
measure 12
C3     4        q     u
rest   4        q
C3     2        e     u        &1.
C4     2        e     d  [     (
B3     2        e     d  =
Bf3    2        e f   d  ]     )
measure 13
A3     3        e.    d  [     (
G3     1        s     d  ]\    )
F3     4        q     d
rest   2        e
F3     2        e     d  [
G3     2        e     d  =
G2     2        e     d  ]
measure 14
C3     2        e     d  [
C4     2        e     d  =     (
B3     2        e     d  =
Bf3    2        e f   d  ]     )
A3     3        e.    d  [     (
G3     1        s     d  ]\    )
F3     1        s     d  [[    (
D3     1        s     d  ==    )
D3     1        s     d  ==    (
B2     1        s     d  ]]    )
measure 15
C3     2        e     d  [
F3     2        e     d  =
G3     2        e     d  =
G2     2        e     d  ]
C3     4        q     u
rest   4        q
measure 16
rest   8        h
rest   2        e
E3     2        e     d  [     (p
D#3    2        e #   d  =
E3     2        e     d  ]     )
measure 17
G#2    4        q #   u        (
A2     4        q     u        )
E3     4        q     d
rest   4        q
measure 18
E3     4        q     d
E3     4        q     d
E3     2        e     d  [     .
B3     2        e     d  =     .f
G#3    2        e #   d  ]     .
rest   2        e
mheavy4 19      :|:
rest  16
measure 20
rest   2        e
A3     2        e     d  [     .p
F3     2        e     d  =     .
D3     2        e     d  ]     .
G3     2        e     d  [     .
E3     2        e     d  =     .
C#3    2        e #   d  =     .
A2     2        e     d  ]     .
measure 21
D3     4        q     d
rest   4        q
rest   8        h
measure 22
rest   2        e
G3     2        e     d  [     .
E3     2        e     d  =     .
C3     2        e n   d  ]     .+
F3     2        e     u  [     .
D3     2        e     u  =     .
B2     2        e     u  =     .
G2     2        e     u  ]     .
measure 23
C3     4        q     u
rest   4        q
rest   2        e
E3     2        e     d  [     (
F3     2        e     d  =
D#3    2        e #   d  ]     )
measure 24
E3     4        q     d
rest   4        q
rest   2        e
E2     2        e     u  [     (
F2     2        e     u  =
D#2    2        e #   u  ]     )
measure 25
E2     2        e     u  [     .
E3     2        e     u  =     (
F3     2        e     u  =
C#3    2        e #   u  ]
D3     2        e     u  [
D#3    2        e #   u  =
E3     2        e     u  =
G#2    2        e #   u  ]     )
measure 26
A2     4        q     u        f
P C32:y5
rest   4        q
rest   8        h
measure 27
rest  16
measure 28
rest  16
measure 29
A2     2        e     u  [     (
C3     2        e     u  =
E3     2        e     u  =
C3     2        e     u  ]     )
B2     2        e     d  [     (
D3     2        e     d  =
F3     2        e     d  =
D3     2        e     d  ]     )
measure 30
C3     4        q     u
rest   4        q
D#3    4        q #   d
rest   4        q
measure 31
E3     4        q     d        (p
F3     4        q     d
E3     4        q     d
D3     4        q n   d        )+
measure 32
C3     4        q     u        f
rest   4        q
rest   8        h
measure 33
G#2    4        q #   u        f
P C32:y5
rest   4        q
rest   8        h
measure 34
A2     4        q     u        f
P C32:y5
rest   4        q
D3     2        e     u  [     .
C3     2        e     u  =     .
B2     2        e     u  =     .
A2     2        e     u  ]     .
measure 35
E3     4        q     d
E2     4        q     u
E3     4        q     d
rest   4        q
measure 36
A3     4        q     d
rest   4        q
E3     4        q     d
rest   4        q
measure 37
A2     4        q     u
rest   4        q
A2     2        e     u        &1.
A3     2        e     d  [     (
G#3    2        e #   d  =
G3     2        e n   d  ]     )
measure 38
F3     3        e.    d  [     (
E3     1        s     d  ]\    )
D3     4        q     d
rest   2        e
D3     2        e     u  [
E3     2        e     u  =
E2     2        e     u  ]
measure 39
A2     2        e     d  [     .
A3     2        e     d  =     (
G#3    2        e #   d  =
G3     2        e n   d  ]     )
F3     3        e.    d  [     (
E3     1        s     d  ]\    )
D3     2        e     u  [     (
B2     1        s     u  =[
G#2    1        s #   u  ]]    )
measure 40
A2     2        e     u  [
D3     2        e     u  =
E3     2        e     u  =
E2     2        e     u  ]
A2     4        q     u
rest   4        q
measure 41
rest   8        h
rest   2        e
A3     2        e     d  [     (p
G#3    2        e #   d  =
A3     2        e     d  ]     )
measure 42
E3     4        q     d        (
F3     4        q     d        )
A2     4        q     u        .
rest   4        q
measure 43
D#3    4        q #   d        (
E3     4        q     d        )
A2     4        q     u        &1.
rest   4        q
measure 44
D#2    4        q #   u        (
E2     4        q     u        )
A2     2        e     u  [     .
A3     2        e     u  =     .f
P C33:y5
A2     2        e     u  ]     .
rest   2        e
mheavy2         :|
/END
/eof
//
